using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{


    // =====================================
    // VENTANA MAIN 3.4 (ACERO EN VIGAS)
    // =====================================
    public class AceroVigasMainForm : WinForms.Form
    {
        private const int ANCHO_MENU = 175;
        private const int ALTO_BOTONERA = 70;
        private const int ALTO_VISTA_PREVIA_FIJA = 250;

        private WinForms.Panel panelMenu;
        private WinForms.Panel panelContenido;
        private WinForms.Panel panelBotonera;
        private WinForms.Panel panelVistaPreviaFija;

        private WinForms.Button btnMenuSeleccionarVigas;
        private WinForms.Button btnMenuLongitudinal;
        private WinForms.Button btnMenuEstribos;

        private WinForms.Button btnEjecutarLongitudinalCompartido;

        private WinForms.Control previewLongitudinalFijo;
        private WinForms.Control previewEstribosFijo;

        // =========================================================
        // VISTA PRELIMINAR ÚNICA / GLOBAL
        // =========================================================
        // La vista preliminar ya no se mueve desde cada ventana.
        // Vive fija en el MAIN y solo cambia de modo según el menú.
        private WinForms.GroupBox grpVistaPreviaGlobal;
        private VistaPreviaVigasPanel vistaPreviaGlobal;


        // =========================================================
        // VISTA PRELIMINAR ÚNICA / GLOBAL
        // =========================================================
        private void CrearVistaPreviaGlobal()
        {
            if (panelVistaPreviaFija == null)
                return;

            panelVistaPreviaFija.Controls.Clear();

            grpVistaPreviaGlobal = new WinForms.GroupBox()
            {
                Text = "Vista preliminar",
                Left = 6,
                Top = 2,
                Width = Math.Max(200, panelVistaPreviaFija.ClientSize.Width - 12),
                Height = Math.Max(160, panelVistaPreviaFija.ClientSize.Height - 4),
                Anchor = WinForms.AnchorStyles.Top |
                         WinForms.AnchorStyles.Bottom |
                         WinForms.AnchorStyles.Left |
                         WinForms.AnchorStyles.Right,
                Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50),
                BackColor = Drawing.Color.FromArgb(245, 247, 250)
            };

            vistaPreviaGlobal = new VistaPreviaVigasPanel()
            {
                Left = 12,
                Top = 32,
                Width = Math.Max(100, grpVistaPreviaGlobal.ClientSize.Width - 24),
                Height = Math.Max(80, grpVistaPreviaGlobal.ClientSize.Height - 44),
                Anchor = WinForms.AnchorStyles.Top |
                         WinForms.AnchorStyles.Bottom |
                         WinForms.AnchorStyles.Left |
                         WinForms.AnchorStyles.Right,
                BackColor = Drawing.Color.White,
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };

            vistaPreviaGlobal.ConfigurarReferencias(
                VentanaLongitudinal,
                VentanaEstribos);

            vistaPreviaGlobal.TramoEstriboSeleccionado += VistaPreviaGlobal_TramoEstriboSeleccionado;

            grpVistaPreviaGlobal.Controls.Add(vistaPreviaGlobal);
            panelVistaPreviaFija.Controls.Add(grpVistaPreviaGlobal);

            AjustarVistaPreviaGlobal();
        }

        private void VistaPreviaGlobal_TramoEstriboSeleccionado(object sender, int index)
        {
            if (index < 0)
                return;

            if (vistaPreviaGlobal == null || vistaPreviaGlobal.Modo != ModoVistaPrevia.Estribos)
                return;

            if (VentanaEstribos == null || VentanaEstribos.IsDisposed)
                return;

            try
            {
                // No llamamos directamente a VentanaEstribos.SeleccionarTramoDesdePreview(index)
                // porque algunas versiones de ACERO_VIGAS_VENTANA_ESTRIBOS.cs
                // no tienen ese método y el MAIN dejaba de compilar.
                // Si el método existe, se invoca por reflexión; si no existe,
                // solo se actualiza el resaltado visual del tramo.
                InvocarSeleccionarTramoDesdePreviewSiExiste(index);

                vistaPreviaGlobal.TramoEstribosResaltado = index;
                RefrescarVistaPreviaGlobal();
            }
            catch
            {
                // No interrumpir la selección de tramo por un refresco visual.
            }
        }

        private void ConfigurarVistaPreviaGlobal(ModoVistaPrevia modo)
        {
            if (vistaPreviaGlobal == null)
                return;

            vistaPreviaGlobal.ConfigurarReferencias(
                VentanaLongitudinal,
                VentanaEstribos);

            vistaPreviaGlobal.Modo = modo;

            if (modo != ModoVistaPrevia.Estribos)
                vistaPreviaGlobal.TramoEstribosResaltado = -1;

            RefrescarVistaPreviaGlobal();
        }

        private void RefrescarVistaPreviaGlobal()
        {
            try
            {
                if (vistaPreviaGlobal != null)
                {
                    vistaPreviaGlobal.ConfigurarReferencias(
                        VentanaLongitudinal,
                        VentanaEstribos);

                    vistaPreviaGlobal.Invalidate();
                    vistaPreviaGlobal.Update();
                }

                if (grpVistaPreviaGlobal != null)
                {
                    grpVistaPreviaGlobal.Invalidate(true);
                    grpVistaPreviaGlobal.Update();
                }
            }
            catch
            {
            }
        }

        private void AjustarVistaPreviaGlobal()
        {
            if (panelVistaPreviaFija == null || grpVistaPreviaGlobal == null)
                return;

            grpVistaPreviaGlobal.Left = 6;
            grpVistaPreviaGlobal.Top = 2;
            grpVistaPreviaGlobal.Width = Math.Max(200, panelVistaPreviaFija.ClientSize.Width - 12);
            grpVistaPreviaGlobal.Height = Math.Max(160, panelVistaPreviaFija.ClientSize.Height - 4);
            grpVistaPreviaGlobal.Anchor = WinForms.AnchorStyles.Top |
                                          WinForms.AnchorStyles.Bottom |
                                          WinForms.AnchorStyles.Left |
                                          WinForms.AnchorStyles.Right;

            if (vistaPreviaGlobal != null)
            {
                vistaPreviaGlobal.Left = 12;
                vistaPreviaGlobal.Top = 32;
                vistaPreviaGlobal.Width = Math.Max(100, grpVistaPreviaGlobal.ClientSize.Width - 24);
                vistaPreviaGlobal.Height = Math.Max(80, grpVistaPreviaGlobal.ClientSize.Height - 44);
                vistaPreviaGlobal.Anchor = WinForms.AnchorStyles.Top |
                                           WinForms.AnchorStyles.Bottom |
                                           WinForms.AnchorStyles.Left |
                                           WinForms.AnchorStyles.Right;
                vistaPreviaGlobal.Invalidate();
            }
        }

        private void VentanaEstribos_PreviewEstribosActualizado()
        {
            RefrescarVistaPreviaGlobal();
        }

        // =========================================================
        // SELECTOR GLOBAL DE FORMA / SECCIÓN / DISPOSICIÓN
        // =========================================================
        // Este control vive en el MAIN para que aparezca en las 3 ventanas.
        // Solo cambia su título e imágenes según el botón activo del menú.
        private WinForms.Label lblSelectorFormaGlobal;
        private WinForms.ComboBox cmbSelectorFormaGlobal;
        private WinForms.CheckBox chkDetectarFormaGlobal;

        // Editor común de sección: reemplaza visualmente los selectores basados
        // en imágenes. El mismo botón aparece en Longitudinal y Estribos.
        private WinForms.Button btnEditarAceroSeccionGlobal;
        private WinForms.Label lblResumenAceroSeccionGlobal;
        private List<RebarBarType> tiposArmaduraEditorSeccion =
            new List<RebarBarType>();

        // Editor de sección incrustado directamente en la pestaña activa.
        // No se usa ShowDialog ni se abre una segunda ventana.
        private WinForms.SplitContainer splitConfiguracionEditorSeccion;
        private AceroVigaEditorSeccionForm editorSeccionIncrustado;
        private WinForms.Label lblEditorSinGeometria;
        private bool ajustandoSplitterEditorSeccion;

        private Drawing.Image imgGlobalRectangularActual;
        private Drawing.Image imgGlobalCumbreraActual;

        private ModoSelectorFormaGlobal modoSelectorFormaActual =
            ModoSelectorFormaGlobal.SeleccionVigas;

        private bool bloqueandoSelectorFormaGlobal = false;

        // =========================================================
        // GEOMETRÍA ACTUAL PARA NORMALIZAR FORMA DETECTADA
        // =========================================================
        // Si el selector global recibe "Cumbrera" desde la detección automática,
        // pero la sección transversal de las vigas cargadas tiene 4 lados,
        // el MAIN fuerza Rectangular. Esto corrige vigas trapezoidales de 4 lados.
        private List<VigaLongitudinalPreview> vigasPreviewGlobalActuales =
            new List<VigaLongitudinalPreview>();

        private enum ModoSelectorFormaGlobal
        {
            SeleccionVigas = 0,
            Estribos = 1,
            Longitudinal = 2
        }

        private class SelectorFormaGlobalItem
        {
            public AceroEstribosVigasForm.TipoFormaEstribo Tipo { get; set; }
            public string Nombre { get; set; }

            public SelectorFormaGlobalItem(
                AceroEstribosVigasForm.TipoFormaEstribo tipo,
                string nombre)
            {
                Tipo = tipo;
                Nombre = nombre;
            }

            public override string ToString()
            {
                return Nombre;
            }
        }

        private bool botonEjecutarLongitudinalPreparado = false;
        private bool mostrandoSeleccionVigas = false;

        public AceroLongitudinalVigasForm VentanaLongitudinal { get; private set; }
        public SeleccionarVigasForm VentanaSeleccionVigas { get; private set; }
        public AceroEstribosVigasForm VentanaEstribos { get; private set; }

        public AceroVigasMainForm()
            : this(new AceroLongitudinalVigasForm())
        {
        }

        public AceroVigasMainForm(AceroLongitudinalVigasForm ventanaLongitudinal)
        {
            // Cada apertura del módulo inicia con una sección limpia. El diseño
            // manual permanece compartido únicamente mientras esta ventana está
            // abierta y puede guardarse/cargarse desde el propio editor 2D.
            AceroVigaDisenoSeccionCompartido.Limpiar();

            VentanaLongitudinal = ventanaLongitudinal ?? new AceroLongitudinalVigasForm();
            ConfigurarVentanaLongitudinalComoControl();

            this.Text = "MYG - Acero en Vigas";
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.Sizable;
            this.ControlBox = true;
            this.MinimizeBox = true;
            this.MaximizeBox = true;
            this.ShowInTaskbar = true;
            this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;

            // La configuración automática y el editor gráfico se muestran
            // simultáneamente, lado a lado, dentro de la misma ventana.
            int anchoContenido = Math.Max(1320, VentanaLongitudinal.Width + 620);
            int altoTotal = Math.Max(900, VentanaLongitudinal.Height);

            this.ClientSize = new Drawing.Size(
                ANCHO_MENU + anchoContenido,
                altoTotal);
            this.MinimumSize = new Drawing.Size(1180, 780);

            CrearMenuLateral();
            CrearPanelContenido();
            CrearPanelBotonera();
            CrearPanelVistaPreviaFija();
            CrearVistaPreviaGlobal();
            CrearSelectorFormaGlobal();

            this.Controls.Add(panelContenido);
            this.Controls.Add(panelBotonera);
            this.Controls.Add(panelVistaPreviaFija);
            this.Controls.Add(panelMenu);

            TraerSelectorFormaGlobalAlFrente();

            PrepararBotonEjecutarLongitudinalCompartido();
            AsegurarVentanaSeleccionVigas();
            AsegurarVentanaEstribos();

            this.Resize += (s, e) =>
            {
                ActualizarLayoutBotonera(panelBotonera != null && panelBotonera.Visible);
            };

            CargarVentanaSeleccionVigas();

            this.FormClosed += (s, e) =>
            {
                try
                {
                    DestruirEditorSeccionIncrustado();

                    if (VentanaSeleccionVigas != null && !VentanaSeleccionVigas.IsDisposed)
                    {
                        VentanaSeleccionVigas.RestaurarVistaPreviaEnLongitudinal();
                        VentanaSeleccionVigas.Dispose();
                    }

                    if (VentanaEstribos != null && !VentanaEstribos.IsDisposed)
                        VentanaEstribos.Dispose();

                    if (VentanaLongitudinal != null && !VentanaLongitudinal.IsDisposed)
                        VentanaLongitudinal.Dispose();
                }
                catch
                {
                    // No interrumpir cierre.
                }
            };
        }

        private void CrearMenuLateral()
        {
            panelMenu = new WinForms.Panel()
            {
                Left = 0,
                Top = 0,
                Width = ANCHO_MENU,
                Height = this.ClientSize.Height,
                Anchor = WinForms.AnchorStyles.Top |
                         WinForms.AnchorStyles.Bottom |
                         WinForms.AnchorStyles.Left,
                BackColor = Drawing.Color.FromArgb(238, 240, 243),
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };

            WinForms.Label lblTitulo = new WinForms.Label()
            {
                Text = "MYG\nACERO EN VIGAS",
                Left = 14,
                Top = 18,
                Width = ANCHO_MENU - 28,
                Height = 55,
                TextAlign = Drawing.ContentAlignment.MiddleLeft,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(55, 55, 55)
            };

            WinForms.Panel linea = new WinForms.Panel()
            {
                Left = 0,
                Top = 82,
                Width = ANCHO_MENU,
                Height = 1,
                BackColor = Drawing.Color.FromArgb(210, 210, 210)
            };

            // 1ER BOTÓN
            btnMenuSeleccionarVigas = CrearBotonMenu("  Seleccionar vigas", 100);
            btnMenuSeleccionarVigas.Click += (s, e) =>
            {
                CargarVentanaSeleccionVigas();
            };

            // 2DO BOTÓN
            btnMenuEstribos = CrearBotonMenu("  Estribos", 145);
            btnMenuEstribos.Enabled = true;
            btnMenuEstribos.Click += (s, e) =>
            {
                CargarVentanaEstribos();
            };

            // 3ER BOTÓN
            btnMenuLongitudinal = CrearBotonMenu("  Acero longitudinal", 190);
            btnMenuLongitudinal.Click += (s, e) =>
            {
                CargarVentanaLongitudinal();
            };

            panelMenu.Controls.Add(lblTitulo);
            panelMenu.Controls.Add(linea);
            panelMenu.Controls.Add(btnMenuSeleccionarVigas);
            panelMenu.Controls.Add(btnMenuEstribos);
            panelMenu.Controls.Add(btnMenuLongitudinal);
        }

        private WinForms.Button CrearBotonMenu(string texto, int top)
        {
            WinForms.Button btn = new WinForms.Button()
            {
                Text = texto,
                Left = 0,
                Top = top,
                Width = ANCHO_MENU - 1,
                Height = 42,
                FlatStyle = WinForms.FlatStyle.Flat,
                TextAlign = Drawing.ContentAlignment.MiddleLeft,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand,
                BackColor = Drawing.Color.FromArgb(238, 240, 243),
                ForeColor = Drawing.Color.FromArgb(55, 55, 55)
            };

            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(225, 228, 232);
            btn.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(215, 218, 222);

            return btn;
        }

        private void CrearPanelContenido()
        {
            panelContenido = new WinForms.Panel()
            {
                Left = ANCHO_MENU,
                Top = 0,
                Width = this.ClientSize.Width - ANCHO_MENU,
                Height = this.ClientSize.Height,
                Anchor = WinForms.AnchorStyles.Top |
                         WinForms.AnchorStyles.Bottom |
                         WinForms.AnchorStyles.Left |
                         WinForms.AnchorStyles.Right,
                BackColor = Drawing.Color.FromArgb(245, 247, 250)
            };
        }

        private void CrearPanelBotonera()
        {
            panelBotonera = new WinForms.Panel()
            {
                Left = ANCHO_MENU,
                Top = this.ClientSize.Height - ALTO_VISTA_PREVIA_FIJA - ALTO_BOTONERA,
                Width = this.ClientSize.Width - ANCHO_MENU,
                Height = ALTO_BOTONERA,
                Anchor = WinForms.AnchorStyles.Left |
                         WinForms.AnchorStyles.Right |
                         WinForms.AnchorStyles.Bottom,
                BackColor = Drawing.Color.FromArgb(245, 247, 250),
                Visible = false
            };

            panelBotonera.Resize += (s, e) =>
            {
                CentrarBotonEjecutarLongitudinal();
            };
        }

        private void CrearPanelVistaPreviaFija()
        {
            panelVistaPreviaFija = new WinForms.Panel()
            {
                Left = ANCHO_MENU,
                Top = this.ClientSize.Height - ALTO_VISTA_PREVIA_FIJA,
                Width = this.ClientSize.Width - ANCHO_MENU,
                Height = ALTO_VISTA_PREVIA_FIJA,
                Anchor = WinForms.AnchorStyles.Left |
                         WinForms.AnchorStyles.Right |
                         WinForms.AnchorStyles.Bottom,
                BackColor = Drawing.Color.FromArgb(245, 247, 250),
                BorderStyle = WinForms.BorderStyle.None
            };
        }

        private void ConfigurarVentanaLongitudinalComoControl()
        {
            if (VentanaLongitudinal == null || VentanaLongitudinal.IsDisposed)
                return;

            try
            {
                VentanaLongitudinal.TopLevel = false;
                VentanaLongitudinal.FormBorderStyle = WinForms.FormBorderStyle.None;
                VentanaLongitudinal.ShowInTaskbar = false;
                VentanaLongitudinal.TopMost = false;

                VentanaLongitudinal.VisibleChanged -= VentanaLongitudinal_VisibleChanged;
                VentanaLongitudinal.VisibleChanged += VentanaLongitudinal_VisibleChanged;

                VentanaLongitudinal.PreviewVigasActualizadas -= VentanaLongitudinal_PreviewVigasActualizadas;
                VentanaLongitudinal.PreviewVigasActualizadas += VentanaLongitudinal_PreviewVigasActualizadas;

                // Compatibilidad: algunas versiones antiguas de AceroLongitudinalVigasForm
                // no tienen el evento PreviewLongitudinalParametrosActualizados.
                // Se conecta por reflexión para que el MAIN no falle al compilar.
                ConectarEventoPreviewLongitudinalParametrosActualizadosSiExiste();
            }
            catch
            {
                // No interrumpir.
            }
        }

        private void VentanaLongitudinal_VisibleChanged(object sender, EventArgs e)
        {
            if (!mostrandoSeleccionVigas)
                return;

            if (VentanaLongitudinal == null || VentanaLongitudinal.IsDisposed)
                return;

            if (!VentanaLongitudinal.Visible)
                return;

            try
            {
                this.BeginInvoke(new Action(() =>
                {
                    if (mostrandoSeleccionVigas &&
                        VentanaLongitudinal != null &&
                        !VentanaLongitudinal.IsDisposed &&
                        VentanaLongitudinal.Visible &&
                        VentanaLongitudinal.Parent != panelContenido)
                    {
                        VentanaLongitudinal.Hide();
                    }
                }));
            }
            catch
            {
                // No interrumpir.
            }
        }

        private void PrepararBotonEjecutarLongitudinalCompartido()
        {
            if (botonEjecutarLongitudinalPreparado)
                return;

            AsegurarVentanaLongitudinal();

            btnEjecutarLongitudinalCompartido = VentanaLongitudinal.btnEjecutar;

            if (btnEjecutarLongitudinalCompartido != null)
            {
                SepararControl(btnEjecutarLongitudinalCompartido);

                btnEjecutarLongitudinalCompartido.Visible = true;
                btnEjecutarLongitudinalCompartido.Enabled = true;
                btnEjecutarLongitudinalCompartido.Text = "EJECUTAR";
                btnEjecutarLongitudinalCompartido.Width = 220;
                btnEjecutarLongitudinalCompartido.Height = 36;
                btnEjecutarLongitudinalCompartido.FlatStyle = WinForms.FlatStyle.Flat;
                btnEjecutarLongitudinalCompartido.BackColor = Drawing.Color.FromArgb(0, 120, 215);
                btnEjecutarLongitudinalCompartido.ForeColor = Drawing.Color.White;
                btnEjecutarLongitudinalCompartido.Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold);
                btnEjecutarLongitudinalCompartido.Cursor = WinForms.Cursors.Hand;
                btnEjecutarLongitudinalCompartido.Anchor = WinForms.AnchorStyles.None;

                btnEjecutarLongitudinalCompartido.FlatAppearance.BorderSize = 0;
                btnEjecutarLongitudinalCompartido.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(0, 100, 190);
                btnEjecutarLongitudinalCompartido.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(0, 84, 160);

                panelBotonera.Controls.Add(btnEjecutarLongitudinalCompartido);
                CentrarBotonEjecutarLongitudinal();
            }

            botonEjecutarLongitudinalPreparado = true;
        }

        private void ActualizarLayoutBotonera(bool mostrarBotonera)
        {
            if (panelMenu != null)
            {
                panelMenu.Left = 0;
                panelMenu.Top = 0;
                panelMenu.Width = ANCHO_MENU;
                panelMenu.Height = this.ClientSize.Height;
            }

            int anchoDerecho = Math.Max(200, this.ClientSize.Width - ANCHO_MENU);

            if (panelVistaPreviaFija != null)
            {
                panelVistaPreviaFija.Left = ANCHO_MENU;
                panelVistaPreviaFija.Top = Math.Max(0, this.ClientSize.Height - ALTO_VISTA_PREVIA_FIJA);
                panelVistaPreviaFija.Width = anchoDerecho;
                panelVistaPreviaFija.Height = ALTO_VISTA_PREVIA_FIJA;
            }

            int altoDisponibleAntesPreview = this.ClientSize.Height - ALTO_VISTA_PREVIA_FIJA;

            if (panelBotonera != null)
            {
                panelBotonera.Visible = mostrarBotonera;
                panelBotonera.Left = ANCHO_MENU;
                panelBotonera.Width = anchoDerecho;
                panelBotonera.Height = mostrarBotonera ? ALTO_BOTONERA : 0;
                panelBotonera.Top = Math.Max(0, altoDisponibleAntesPreview - panelBotonera.Height);
            }

            if (panelContenido != null)
            {
                panelContenido.Left = ANCHO_MENU;
                panelContenido.Top = 0;
                panelContenido.Width = anchoDerecho;
                panelContenido.Height = Math.Max(120, altoDisponibleAntesPreview - (mostrarBotonera ? ALTO_BOTONERA : 0));
            }

            if (mostrarBotonera)
                CentrarBotonEjecutarLongitudinal();

            AjustarSelectorFormaGlobal();
            AjustarVistaPreviaFijaActual();
            AjustarVistaPreviaGlobal();
        }

        private void CentrarBotonEjecutarLongitudinal()
        {
            if (btnEjecutarLongitudinalCompartido == null || panelBotonera == null)
                return;

            btnEjecutarLongitudinalCompartido.Left =
                (panelBotonera.ClientSize.Width - btnEjecutarLongitudinalCompartido.Width) / 2;

            btnEjecutarLongitudinalCompartido.Top = Math.Min(
                panelBotonera.ClientSize.Height - btnEjecutarLongitudinalCompartido.Height - 4,
                ((panelBotonera.ClientSize.Height - btnEjecutarLongitudinalCompartido.Height) / 2) + 18);
        }



        // =========================================================
        // SELECTOR GLOBAL DE FORMA / SECCIÓN / DISPOSICIÓN
        // =========================================================
        private void CrearSelectorFormaGlobal()
        {
            lblSelectorFormaGlobal = new WinForms.Label()
            {
                Text = "Sección Transversal:",
                Left = 0,
                Top = 0,
                Width = 190,
                Height = 18,
                Font = new Drawing.Font("Segoe UI", 8.2F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(45, 45, 45),
                BackColor = Drawing.Color.FromArgb(245, 247, 250)
            };

            cmbSelectorFormaGlobal = new WinForms.ComboBox()
            {
                Left = 0,
                Top = 20,
                Width = 185,
                Height = 98,
                DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
                DrawMode = WinForms.DrawMode.OwnerDrawFixed,
                ItemHeight = 100,
                MaxDropDownItems = 4,
                IntegralHeight = false,
                DropDownHeight = 210,
                DropDownWidth = 225
            };

            cmbSelectorFormaGlobal.Items.Add(
                new SelectorFormaGlobalItem(
                    AceroEstribosVigasForm.TipoFormaEstribo.Rectangular,
                    "Rectangular"));

            cmbSelectorFormaGlobal.Items.Add(
                new SelectorFormaGlobalItem(
                    AceroEstribosVigasForm.TipoFormaEstribo.Cumbrera,
                    "Cumbrera"));

            cmbSelectorFormaGlobal.DrawItem += CmbSelectorFormaGlobal_DrawItem;

            cmbSelectorFormaGlobal.SelectedIndexChanged += (s, e) =>
            {
                RefrescarSelectorFormaGlobal();

                if (bloqueandoSelectorFormaGlobal)
                    return;

                SincronizarFormaGlobalConVentanas();
            };

            if (cmbSelectorFormaGlobal.Items.Count > 0)
                cmbSelectorFormaGlobal.SelectedIndex = 0;

            chkDetectarFormaGlobal = new WinForms.CheckBox()
            {
                Text = "Detectar automáticamente",
                Left = 0,
                Top = 152,
                Width = 225,
                Height = 18,
                Checked = true,
                BackColor = Drawing.Color.FromArgb(245, 247, 250),
                Font = new Drawing.Font("Segoe UI", 8.0F, Drawing.FontStyle.Regular),
                Cursor = WinForms.Cursors.Hand
            };

            chkDetectarFormaGlobal.CheckedChanged += (s, e) =>
            {
                ActualizarBloqueoSelectorFormaGlobal();
                SincronizarFormaGlobalConVentanas();
            };

            // Los controles históricos permanecen para compatibilidad con la
            // detección interna, pero ya no son visibles ni usan imágenes en la UI.
            lblSelectorFormaGlobal.Visible = false;
            cmbSelectorFormaGlobal.Visible = false;
            chkDetectarFormaGlobal.Visible = false;

            this.Controls.Add(lblSelectorFormaGlobal);
            this.Controls.Add(cmbSelectorFormaGlobal);
            this.Controls.Add(chkDetectarFormaGlobal);

            btnEditarAceroSeccionGlobal = new WinForms.Button()
            {
                Text = "EDITAR ACERO EN SECCIÓN",
                Width = 210,
                Height = 48,
                FlatStyle = WinForms.FlatStyle.Flat,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand,
                Visible = false
            };
            btnEditarAceroSeccionGlobal.FlatAppearance.BorderSize = 0;
            btnEditarAceroSeccionGlobal.Click += (s, e) => EnfocarEditorSeccionIncrustado();

            lblResumenAceroSeccionGlobal = new WinForms.Label()
            {
                Text = "Sin diseño manual de sección.",
                Width = 220,
                Height = 44,
                ForeColor = Drawing.Color.FromArgb(70, 70, 70),
                BackColor = Drawing.Color.FromArgb(245, 247, 250),
                Font = new Drawing.Font("Segoe UI", 7.8F),
                TextAlign = Drawing.ContentAlignment.TopLeft,
                Visible = false
            };

            this.Controls.Add(btnEditarAceroSeccionGlobal);
            this.Controls.Add(lblResumenAceroSeccionGlobal);

            CambiarModoSelectorFormaGlobal(ModoSelectorFormaGlobal.SeleccionVigas);
            ActualizarBloqueoSelectorFormaGlobal();
            AjustarSelectorFormaGlobal();
        }

        private AceroEstribosVigasForm.TipoFormaEstribo FormaSelectorGlobalSeleccionada
        {
            get
            {
                SelectorFormaGlobalItem item = cmbSelectorFormaGlobal != null
                    ? cmbSelectorFormaGlobal.SelectedItem as SelectorFormaGlobalItem
                    : null;

                if (item == null)
                    return AceroEstribosVigasForm.TipoFormaEstribo.Rectangular;

                return item.Tipo;
            }
        }

        private bool DetectarFormaGlobalAutomaticamente
        {
            get
            {
                return chkDetectarFormaGlobal != null &&
                       chkDetectarFormaGlobal.Checked;
            }
        }

        private void CambiarModoSelectorFormaGlobal(ModoSelectorFormaGlobal modo)
        {
            modoSelectorFormaActual = modo;

            // Ya no se cargan ni se muestran PNG. La geometría se dibuja en el
            // editor común usando el contorno real recuperado de Revit.
            imgGlobalRectangularActual = null;
            imgGlobalCumbreraActual = null;

            if (lblSelectorFormaGlobal != null)
                lblSelectorFormaGlobal.Visible = false;
            if (cmbSelectorFormaGlobal != null)
                cmbSelectorFormaGlobal.Visible = false;
            if (chkDetectarFormaGlobal != null)
                chkDetectarFormaGlobal.Visible = false;

            ActualizarVisibilidadEditorSeccionGlobal();
            AjustarSelectorFormaGlobal();
            TraerSelectorFormaGlobalAlFrente();

            // Se conserva la sincronización histórica para las rutinas automáticas
            // cuando todavía no existe un diseño manual.
            SincronizarFormaGlobalConVentanas();
        }

        private void ActualizarVisibilidadEditorSeccionGlobal()
        {
            // Los controles flotantes anteriores quedan permanentemente ocultos.
            // Toda la configuración ahora vive dentro del panel incrustado.
            if (btnEditarAceroSeccionGlobal != null)
                btnEditarAceroSeccionGlobal.Visible = false;

            if (lblResumenAceroSeccionGlobal != null)
                lblResumenAceroSeccionGlobal.Visible = false;

            ActualizarResumenEditorSeccionGlobal();
        }

        private void ActualizarResumenEditorSeccionGlobal()
        {
            if (lblResumenAceroSeccionGlobal == null)
                return;

            AceroVigaDisenoSeccion diseno =
                AceroVigaDisenoSeccionCompartido.ObtenerCopia();

            int nLong = diseno != null && diseno.Longitudinales != null
                ? diseno.Longitudinales.Count
                : 0;
            int nEstr = diseno != null && diseno.Estribos != null
                ? diseno.Estribos.Count
                : 0;

            lblResumenAceroSeccionGlobal.Text =
                nLong == 0 && nEstr == 0
                    ? "Sin diseño manual. Se usará la configuración automática."
                    : "Diseño manual activo: " + nLong.ToString() +
                      " longitudinal(es) y " + nEstr.ToString() +
                      " recorrido(s) de stirrup.";
        }

        private void AbrirEditorAceroSeccionGlobal()
        {
            // Compatibilidad con llamadas antiguas: ya no abre ShowDialog.
            // Únicamente asegura y enfoca el editor incrustado.
            EnfocarEditorSeccionIncrustado();
        }

        private void EnfocarEditorSeccionIncrustado()
        {
            ReconstruirEditorSeccionIncrustadoSiVisible();

            if (modoSelectorFormaActual ==
                    ModoSelectorFormaGlobal.Estribos &&
                VentanaEstribos != null &&
                !VentanaEstribos.IsDisposed)
            {
                VentanaEstribos.BringToFront();
                VentanaEstribos.Focus();
            }
            else if (VentanaLongitudinal != null &&
                     !VentanaLongitudinal.IsDisposed)
            {
                VentanaLongitudinal.BringToFront();
                VentanaLongitudinal.Focus();
            }
        }

        private void MostrarFormularioConEditorIntegradoEnPestana(
            WinForms.Form formulario,
            AceroVigaModoEditorInicial modoInicial)
        {
            if (formulario == null ||
                formulario.IsDisposed ||
                panelContenido == null)
            {
                return;
            }

            // V6: ya no existe un SplitContainer del MAIN ni una segunda ventana
            // visual. Cada pestaña contiene su configuración y su editor dentro
            // del mismo formulario embebido.
            DestruirEditorSeccionIncrustado();
            panelContenido.Controls.Clear();

            ConfigurarFormularioEmbebido(formulario);
            formulario.Dock = WinForms.DockStyle.Fill;
            panelContenido.Controls.Add(formulario);
            formulario.Show();
            formulario.BringToFront();

            List<AceroVigaPuntoMm> contorno =
                ObtenerContornoEditorSeccionGlobal();
            string nombre = ObtenerNombreSeccionEditorGlobal();
            AceroVigaDisenoSeccion diseno =
                AceroVigaDisenoSeccionCompartido.ObtenerCopia();

            RebarBarType tipoLongitudinal =
                VentanaLongitudinal != null &&
                !VentanaLongitudinal.IsDisposed
                    ? VentanaLongitudinal.TipoSuperiorSeleccionado
                    : null;

            RebarBarType tipoEstribo =
                VentanaEstribos != null &&
                !VentanaEstribos.IsDisposed
                    ? VentanaEstribos.TipoEstriboSeleccionado
                    : null;

            if (modoInicial == AceroVigaModoEditorInicial.Estribos)
            {
                if (VentanaEstribos != null &&
                    !VentanaEstribos.IsDisposed)
                {
                    VentanaEstribos.ConfigurarEditorSeccionIntegrado(
                        contorno,
                        tiposArmaduraEditorSeccion,
                        tipoLongitudinal,
                        diseno,
                        nombre);
                }
            }
            else
            {
                if (VentanaLongitudinal != null &&
                    !VentanaLongitudinal.IsDisposed)
                {
                    VentanaLongitudinal.ConfigurarEditorSeccionIntegrado(
                        contorno,
                        tiposArmaduraEditorSeccion,
                        tipoEstribo,
                        diseno,
                        nombre);
                }
            }
        }

        private void MostrarFormularioConEditorSeccion(
            WinForms.Form formulario,
            AceroVigaModoEditorInicial modoInicial)
        {
            if (formulario == null || formulario.IsDisposed || panelContenido == null)
                return;

            DestruirEditorSeccionIncrustado();
            panelContenido.Controls.Clear();

            // IMPORTANTE:
            // No se asignan Panel1MinSize, Panel2MinSize ni SplitterDistance
            // dentro del inicializador. En ese momento el SplitContainer todavía
            // conserva su ancho predeterminado de diseño y WinForms puede lanzar:
            // "SplitterDistance debe estar entre Panel1MinSize y Ancho -
            // Panel2MinSize". Primero se agrega y dimensiona; después se ajusta.
            splitConfiguracionEditorSeccion = new WinForms.SplitContainer
            {
                Dock = WinForms.DockStyle.Fill,
                Orientation = WinForms.Orientation.Vertical,
                BorderStyle = WinForms.BorderStyle.None,
                SplitterWidth = 7,
                BackColor = Drawing.Color.FromArgb(210, 216, 222),
                Panel1MinSize = 0,
                Panel2MinSize = 0
            };

            splitConfiguracionEditorSeccion.SizeChanged +=
                SplitConfiguracionEditorSeccion_SizeChanged;

            panelContenido.Controls.Add(splitConfiguracionEditorSeccion);
            splitConfiguracionEditorSeccion.BringToFront();

            // Fuerza el Dock=Fill antes de calcular límites del divisor.
            panelContenido.PerformLayout();
            splitConfiguracionEditorSeccion.PerformLayout();
            AjustarSplitterEditorSeccionSeguro();

            ConfigurarFormularioEmbebido(formulario);
            formulario.Dock = WinForms.DockStyle.Fill;
            formulario.AutoScroll = true;
            splitConfiguracionEditorSeccion.Panel1.AutoScroll = true;
            splitConfiguracionEditorSeccion.Panel1.BackColor =
                Drawing.Color.FromArgb(245, 247, 250);
            splitConfiguracionEditorSeccion.Panel1.Controls.Add(formulario);

            splitConfiguracionEditorSeccion.Panel2.BackColor = Drawing.Color.White;
            splitConfiguracionEditorSeccion.Panel2.Padding = new WinForms.Padding(2);

            CrearEditorSeccionIncrustado(
                splitConfiguracionEditorSeccion.Panel2,
                modoInicial);

            formulario.Show();
            formulario.BringToFront();

            // Segundo ajuste diferido: cubre el primer clic de pestaña cuando
            // WinForms termina de calcular el tamaño real después de Show().
            try
            {
                if (IsHandleCreated && !IsDisposed)
                {
                    BeginInvoke(new WinForms.MethodInvoker(delegate
                    {
                        AjustarSplitterEditorSeccionSeguro();
                    }));
                }
            }
            catch
            {
                // La ventana puede estar cerrándose; no interrumpir.
            }
        }

        private void SplitConfiguracionEditorSeccion_SizeChanged(
            object sender,
            EventArgs e)
        {
            AjustarSplitterEditorSeccionSeguro();
        }

        private void AjustarSplitterEditorSeccionSeguro()
        {
            if (ajustandoSplitterEditorSeccion ||
                splitConfiguracionEditorSeccion == null ||
                splitConfiguracionEditorSeccion.IsDisposed)
            {
                return;
            }

            int ancho = splitConfiguracionEditorSeccion.ClientSize.Width;
            int anchoDivisor = Math.Max(1, splitConfiguracionEditorSeccion.SplitterWidth);

            // Durante la construcción inicial el control puede reportar ancho cero.
            // En ese caso se deja el valor predeterminado y SizeChanged lo corregirá.
            if (ancho <= anchoDivisor + 2)
                return;

            ajustandoSplitterEditorSeccion = true;

            try
            {
                // Primero se liberan los mínimos anteriores. Esto es esencial al
                // reducir o maximizar la ventana, porque el nuevo ancho puede ser
                // menor que la suma de los mínimos guardados anteriormente.
                splitConfiguracionEditorSeccion.Panel1MinSize = 0;
                splitConfiguracionEditorSeccion.Panel2MinSize = 0;

                int disponible = Math.Max(1, ancho - anchoDivisor);

                const int minimoConfiguracionDeseado = 390;
                const int minimoEditorDeseado = 420;

                int minimoConfiguracion;
                int minimoEditor;

                if (disponible >=
                    minimoConfiguracionDeseado + minimoEditorDeseado)
                {
                    minimoConfiguracion = minimoConfiguracionDeseado;
                    minimoEditor = minimoEditorDeseado;
                }
                else
                {
                    // Ventanas estrechas: se reducen ambos mínimos de manera
                    // proporcional, evitando cualquier rango matemáticamente
                    // imposible para SplitterDistance.
                    minimoConfiguracion = Math.Max(0, disponible / 2);
                    minimoEditor = Math.Max(0, disponible - minimoConfiguracion);
                }

                int anchoEditorDeseado = Math.Max(
                    minimoEditor,
                    Math.Min(760, Math.Max(420, disponible / 2)));

                int distanciaDeseada = disponible - anchoEditorDeseado;
                int distanciaMinima = minimoConfiguracion;
                int distanciaMaxima = disponible - minimoEditor;

                if (distanciaMaxima < distanciaMinima)
                {
                    distanciaMinima = 0;
                    distanciaMaxima = disponible;
                }

                int distanciaSegura = Math.Max(
                    distanciaMinima,
                    Math.Min(distanciaMaxima, distanciaDeseada));

                splitConfiguracionEditorSeccion.SplitterDistance =
                    distanciaSegura;

                // Los mínimos se aplican únicamente después de ubicar el divisor
                // dentro de un rango válido para el ancho real del control.
                splitConfiguracionEditorSeccion.Panel1MinSize = Math.Min(
                    minimoConfiguracion,
                    splitConfiguracionEditorSeccion.SplitterDistance);

                int anchoPanel2Real = Math.Max(
                    0,
                    ancho - anchoDivisor -
                    splitConfiguracionEditorSeccion.SplitterDistance);

                splitConfiguracionEditorSeccion.Panel2MinSize = Math.Min(
                    minimoEditor,
                    anchoPanel2Real);
            }
            catch (ArgumentOutOfRangeException)
            {
                // Respaldo extremo para cambios de tamaño ocurridos durante el
                // mismo ciclo de Layout. Se deja una división central válida.
                try
                {
                    splitConfiguracionEditorSeccion.Panel1MinSize = 0;
                    splitConfiguracionEditorSeccion.Panel2MinSize = 0;

                    int disponible = Math.Max(1, ancho - anchoDivisor);
                    splitConfiguracionEditorSeccion.SplitterDistance =
                        Math.Max(0, Math.Min(disponible, disponible / 2));
                }
                catch
                {
                }
            }
            finally
            {
                ajustandoSplitterEditorSeccion = false;
            }
        }

        private void CrearEditorSeccionIncrustado(
            WinForms.Control contenedor,
            AceroVigaModoEditorInicial modoInicial)
        {
            if (contenedor == null || contenedor.IsDisposed)
                return;

            contenedor.Controls.Clear();

            List<AceroVigaPuntoMm> contorno = ObtenerContornoEditorSeccionGlobal();
            if (contorno == null || contorno.Count < 3)
            {
                lblEditorSinGeometria = new WinForms.Label
                {
                    Dock = WinForms.DockStyle.Fill,
                    Text = "EDITOR DE ACERO EN SECCIÓN\n\n" +
                           "Seleccione una o más vigas para obtener la sección " +
                           "transversal real y generar automáticamente el offset " +
                           "del recubrimiento.",
                    TextAlign = Drawing.ContentAlignment.MiddleCenter,
                    Font = new Drawing.Font("Segoe UI", 10F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(70, 70, 70),
                    BackColor = Drawing.Color.White,
                    Padding = new WinForms.Padding(30)
                };
                contenedor.Controls.Add(lblEditorSinGeometria);
                return;
            }

            RebarBarType tipoLong = VentanaLongitudinal != null &&
                !VentanaLongitudinal.IsDisposed
                    ? VentanaLongitudinal.TipoSuperiorSeleccionado
                    : null;

            RebarBarType tipoEstribo = VentanaEstribos != null &&
                !VentanaEstribos.IsDisposed
                    ? VentanaEstribos.TipoEstriboSeleccionado
                    : null;

            double recubrimientoCm = ObtenerRecubrimientoEditorSeccionGlobal();
            string nombre = ObtenerNombreSeccionEditorGlobal();
            AceroVigaDisenoSeccion actual =
                AceroVigaDisenoSeccionCompartido.ObtenerCopia();

            editorSeccionIncrustado = new AceroVigaEditorSeccionForm(
                contorno,
                tiposArmaduraEditorSeccion,
                tipoLong,
                tipoEstribo,
                recubrimientoCm,
                actual,
                modoInicial,
                nombre);

            editorSeccionIncrustado.ConfigurarComoEditorIncrustado();
            editorSeccionIncrustado.DisenoAplicado +=
                EditorSeccionIncrustado_DisenoAplicado;

            contenedor.Controls.Add(editorSeccionIncrustado);
            editorSeccionIncrustado.Show();
            editorSeccionIncrustado.BringToFront();
        }

        private void EditorSeccionIncrustado_DisenoAplicado(
            AceroVigaDisenoSeccion diseno)
        {
            if (diseno == null)
                return;

            AceroVigaDisenoSeccionCompartido.Establecer(diseno);

            if (modoSelectorFormaActual ==
                ModoSelectorFormaGlobal.Estribos)
            {
                double recubrimientoEstribos =
                    diseno.RecubrimientoEstribosCm > 0.0
                        ? diseno.RecubrimientoEstribosCm
                        : diseno.RecubrimientoCm;

                if (VentanaEstribos != null &&
                    !VentanaEstribos.IsDisposed)
                {
                    VentanaEstribos.EstablecerRecubrimientoDesdeEditor(
                        recubrimientoEstribos);
                }
            }
            else
            {
                double recubrimientoLongitudinal =
                    diseno.RecubrimientoLongitudinalCm > 0.0
                        ? diseno.RecubrimientoLongitudinalCm
                        : diseno.RecubrimientoCm;

                if (VentanaLongitudinal != null &&
                    !VentanaLongitudinal.IsDisposed)
                {
                    VentanaLongitudinal.EstablecerRecubrimientoDesdeEditor(
                        recubrimientoLongitudinal);
                }
            }

            ActualizarResumenEditorSeccionGlobal();
            RefrescarVistaPreviaGlobal();
        }

        private void DestruirEditorSeccionIncrustado()
        {
            WinForms.SplitContainer splitAnterior =
                splitConfiguracionEditorSeccion;

            try
            {
                if (editorSeccionIncrustado != null &&
                    !editorSeccionIncrustado.IsDisposed)
                {
                    try
                    {
                        AceroVigaDisenoSeccion trabajo =
                            editorSeccionIncrustado.ObtenerDisenoTrabajo();
                        AceroVigaDisenoSeccionCompartido.Establecer(trabajo);
                    }
                    catch
                    {
                    }

                    editorSeccionIncrustado.DisenoAplicado -=
                        EditorSeccionIncrustado_DisenoAplicado;

                    if (editorSeccionIncrustado.Parent != null)
                        editorSeccionIncrustado.Parent.Controls.Remove(
                            editorSeccionIncrustado);

                    editorSeccionIncrustado.Hide();
                    editorSeccionIncrustado.Dispose();
                }

                // Antes de destruir el SplitContainer se separan las ventanas
                // reutilizables para que WinForms no las elimine en cascada.
                if (splitAnterior != null && !splitAnterior.IsDisposed)
                {
                    splitAnterior.SizeChanged -=
                        SplitConfiguracionEditorSeccion_SizeChanged;

                    if (VentanaLongitudinal != null &&
                        !VentanaLongitudinal.IsDisposed &&
                        VentanaLongitudinal.Parent == splitAnterior.Panel1)
                    {
                        splitAnterior.Panel1.Controls.Remove(VentanaLongitudinal);
                    }

                    if (VentanaEstribos != null &&
                        !VentanaEstribos.IsDisposed &&
                        VentanaEstribos.Parent == splitAnterior.Panel1)
                    {
                        splitAnterior.Panel1.Controls.Remove(VentanaEstribos);
                    }

                    if (splitAnterior.Parent != null)
                        splitAnterior.Parent.Controls.Remove(splitAnterior);

                    splitAnterior.Dispose();
                }
            }
            catch
            {
            }

            editorSeccionIncrustado = null;
            lblEditorSinGeometria = null;
            splitConfiguracionEditorSeccion = null;
        }

        private void ReconstruirEditorSeccionIncrustadoSiVisible()
        {
            List<AceroVigaPuntoMm> contorno =
                ObtenerContornoEditorSeccionGlobal();
            string nombre = ObtenerNombreSeccionEditorGlobal();
            AceroVigaDisenoSeccion diseno =
                AceroVigaDisenoSeccionCompartido.ObtenerCopia();

            RebarBarType tipoLongitudinal =
                VentanaLongitudinal != null &&
                !VentanaLongitudinal.IsDisposed
                    ? VentanaLongitudinal.TipoSuperiorSeleccionado
                    : null;

            RebarBarType tipoEstribo =
                VentanaEstribos != null &&
                !VentanaEstribos.IsDisposed
                    ? VentanaEstribos.TipoEstriboSeleccionado
                    : null;

            if (modoSelectorFormaActual ==
                ModoSelectorFormaGlobal.Estribos)
            {
                if (VentanaEstribos != null &&
                    !VentanaEstribos.IsDisposed &&
                    VentanaEstribos.Visible)
                {
                    VentanaEstribos.ConfigurarEditorSeccionIntegrado(
                        contorno,
                        tiposArmaduraEditorSeccion,
                        tipoLongitudinal,
                        diseno,
                        nombre);
                }
            }
            else
            {
                if (VentanaLongitudinal != null &&
                    !VentanaLongitudinal.IsDisposed &&
                    VentanaLongitudinal.Visible)
                {
                    VentanaLongitudinal.ConfigurarEditorSeccionIntegrado(
                        contorno,
                        tiposArmaduraEditorSeccion,
                        tipoEstribo,
                        diseno,
                        nombre);
                }
            }
        }

        private List<AceroVigaPuntoMm> ObtenerContornoEditorSeccionGlobal()
        {
            List<AceroVigaPuntoMm> resultado =
                new List<AceroVigaPuntoMm>();

            if (VentanaLongitudinal == null || VentanaLongitudinal.IsDisposed)
                return resultado;

            List<VigaLongitudinalPreview> vistas =
                VentanaLongitudinal.ObtenerVigasPreviewActuales();

            if (vistas == null || vistas.Count == 0)
                return resultado;

            foreach (VigaLongitudinalPreview vista in vistas)
            {
                if (vista == null)
                    continue;

                List<AceroVigaPuntoMm> contorno =
                    AceroVigaContornoPreviewCompartido.ObtenerCopia(vista);

                if (contorno != null && contorno.Count >= 3)
                    return contorno;
            }

            return resultado;
        }

        private string ObtenerNombreSeccionEditorGlobal()
        {
            try
            {
                List<VigaLongitudinalPreview> vistas =
                    VentanaLongitudinal.ObtenerVigasPreviewActuales();
                VigaLongitudinalPreview vista = vistas != null
                    ? vistas.FirstOrDefault(x => x != null)
                    : null;
                return vista != null ? vista.Nombre ?? string.Empty : string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        private double ObtenerRecubrimientoEditorSeccionGlobal()
        {
            string texto = null;

            if (modoSelectorFormaActual == ModoSelectorFormaGlobal.Estribos &&
                VentanaEstribos != null && !VentanaEstribos.IsDisposed)
            {
                texto = VentanaEstribos.RecubrimientoTexto;
            }
            else if (VentanaLongitudinal != null && !VentanaLongitudinal.IsDisposed)
            {
                texto = VentanaLongitudinal.RecubrimientoTexto;
            }

            double valor;
            bool leido = double.TryParse(
                texto,
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out valor);

            if (!leido)
            {
                leido = double.TryParse(
                    texto,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.CurrentCulture,
                    out valor);
            }

            if (leido && valor > 0.0)
                return valor;

            AceroVigaDisenoSeccion diseno =
                AceroVigaDisenoSeccionCompartido.ObtenerCopia();

            if (diseno != null)
            {
                double recubrimientoGuardado =
                    modoSelectorFormaActual ==
                    ModoSelectorFormaGlobal.Estribos
                        ? diseno.RecubrimientoEstribosCm
                        : diseno.RecubrimientoLongitudinalCm;

                if (recubrimientoGuardado > 0.0)
                    return recubrimientoGuardado;

                if (diseno.RecubrimientoCm > 0.0)
                    return diseno.RecubrimientoCm;
            }

            return 4.0;
        }

        private void AplicarFormaGlobalDetectadaDesdeVentana(
            AceroEstribosVigasForm.TipoFormaEstribo tipo)
        {
            if (cmbSelectorFormaGlobal == null ||
                cmbSelectorFormaGlobal.Items.Count == 0)
                return;

            // FILTRO FINAL DEL MAIN:
            // Si la ventana/handler detecta Cumbrera, pero la sección real tiene
            // 4 lados, se fuerza Rectangular en el desplegable global.
            tipo = NormalizarFormaGlobalPorGeometriaActual(tipo);

            bloqueandoSelectorFormaGlobal = true;

            try
            {
                bool estadoPrevio = cmbSelectorFormaGlobal.Enabled;

                // Aunque el selector esté bloqueado por "Detectar automáticamente",
                // se habilita solo un instante para que WinForms cambie y repinte
                // la miniatura inmediatamente.
                cmbSelectorFormaGlobal.Enabled = true;
                SeleccionarFormaGlobal(tipo);
                cmbSelectorFormaGlobal.Enabled = estadoPrevio;

                RefrescarSelectorFormaGlobal();
                TraerSelectorFormaGlobalAlFrente();
            }
            finally
            {
                bloqueandoSelectorFormaGlobal = false;
            }

            SincronizarFormaGlobalConVentanas();
        }

        // =========================================================
        // NORMALIZACIÓN GLOBAL: 4 LADOS = RECTANGULAR
        // =========================================================
        private AceroEstribosVigasForm.TipoFormaEstribo NormalizarFormaGlobalPorGeometriaActual(
            AceroEstribosVigasForm.TipoFormaEstribo tipoDetectado)
        {
            // =========================================================
            // ORDEN CORRECTO DE DETECCIÓN
            // =========================================================
            // 1) Primero se cuentan lados geométricos reales.
            // 2) Si son 4 lados => Rectangular, aunque una cara sea inclinada.
            // 3) Si son más de 4 lados, recién se evalúa el quiebre de cumbrera.
            // 4) No se usa nombre/tipo/familia como criterio final.
            int lados = ObtenerCantidadLadosGeometricaActualDesdePreview();

            if (lados == 4)
                return AceroEstribosVigasForm.TipoFormaEstribo.Rectangular;

            if (lados > 4 && SeccionActualTieneIndicadorCumbreraDesdePreview())
                return AceroEstribosVigasForm.TipoFormaEstribo.Cumbrera;

            return tipoDetectado;
        }

        private int ObtenerCantidadLadosGeometricaActualDesdePreview()
        {
            if (vigasPreviewGlobalActuales == null || vigasPreviewGlobalActuales.Count == 0)
                return 0;

            int ladosMayor = 0;

            foreach (VigaLongitudinalPreview viga in vigasPreviewGlobalActuales)
            {
                if (viga == null)
                    continue;

                int lados = ContarLadosSeccionTransversal(viga);

                if (lados > ladosMayor)
                    ladosMayor = lados;
            }

            return ladosMayor;
        }

        private bool SeccionActualTieneIndicadorCumbreraDesdePreview()
        {
            if (vigasPreviewGlobalActuales == null || vigasPreviewGlobalActuales.Count == 0)
                return false;

            foreach (VigaLongitudinalPreview viga in vigasPreviewGlobalActuales)
            {
                if (viga == null)
                    continue;

                int lados = ContarLadosSeccionTransversal(viga);

                if (lados <= 4)
                    continue;

                if (PreviewIndicaCumbreraPorPropiedad(viga))
                    return true;

                if (PerfilPreviewTieneQuiebreCumbrera(viga))
                    return true;
            }

            return false;
        }

        private bool PreviewIndicaCumbreraPorPropiedad(VigaLongitudinalPreview viga)
        {
            if (viga == null)
                return false;

            try
            {
                object raw = ObtenerValorPropiedad(viga, "EsCumbreraDetectada");

                if (raw is bool)
                    return (bool)raw;

                if (raw != null)
                {
                    bool b;
                    if (bool.TryParse(raw.ToString(), out b))
                        return b;
                }
            }
            catch
            {
            }

            return false;
        }

        private bool NombrePreviewIndicaCumbrera(VigaLongitudinalPreview viga)
        {
            if (viga == null)
                return false;

            try
            {
                string nombre = viga.Nombre ?? "";

                if (string.IsNullOrWhiteSpace(nombre))
                    return false;

                string s = nombre.Trim().ToLowerInvariant();

                return s.Contains("cumbrera") ||
                       s.Contains("cumbr") ||
                       s.Contains("ridge") ||
                       s.Contains("cumbre");
            }
            catch
            {
                return false;
            }
        }

        private bool PerfilPreviewTieneQuiebreCumbrera(VigaLongitudinalPreview viga)
        {
            if (viga == null)
                return false;

            // Para forma transversal NO se usan PerfilSuperiorMm/PerfilInferiorMm,
            // porque esos perfiles describen la variación longitudinal X-Z.
            // La sección real se toma desde la geometría 3D proyectada en Y-Z.
            List<PuntoSeccionMain> puntos = ObtenerPuntosSeccionDesdeSolidos3D(viga);

            if (puntos == null || puntos.Count < 5)
                return false;

            puntos = LimpiarPuntosSeccion(puntos);

            if (puntos == null || puntos.Count < 5)
                return false;

            // Si la geometría limpia tiene 4 lados, es rectangular/trapezoidal.
            if (ContarLadosSeccionTransversal(viga) <= 4)
                return false;

            double aMin = puntos.Min(p => p.A);
            double aMax = puntos.Max(p => p.A);
            double bMin = puntos.Min(p => p.B);
            double bMax = puntos.Max(p => p.B);

            double ancho = aMax - aMin;
            double peralte = bMax - bMin;

            if (ancho <= 1e-9 || peralte <= 1e-9)
                return false;

            double aCentro = (aMin + aMax) / 2.0;
            double margenCentral = ancho * 0.28;
            double margenLateral = ancho * 0.18;
            double toleranciaQuiebre = Math.Max(15.0, peralte * 0.035); // mm

            PuntoSeccionMain topCentro = puntos
                .Where(p => p != null && Math.Abs(p.A - aCentro) <= margenCentral)
                .OrderByDescending(p => p.B)
                .FirstOrDefault();

            PuntoSeccionMain topIzq = puntos
                .Where(p => p != null && p.A <= aCentro - margenLateral)
                .OrderByDescending(p => p.B)
                .FirstOrDefault();

            PuntoSeccionMain topDer = puntos
                .Where(p => p != null && p.A >= aCentro + margenLateral)
                .OrderByDescending(p => p.B)
                .FirstOrDefault();

            if (topCentro != null && topIzq != null && topDer != null)
            {
                double bLinea = InterpolarBEnA(
                    topIzq.A,
                    topIzq.B,
                    topDer.A,
                    topDer.B,
                    topCentro.A);

                if (topCentro.B - bLinea >= toleranciaQuiebre)
                    return true;
            }

            PuntoSeccionMain botCentro = puntos
                .Where(p => p != null && Math.Abs(p.A - aCentro) <= margenCentral)
                .OrderBy(p => p.B)
                .FirstOrDefault();

            PuntoSeccionMain botIzq = puntos
                .Where(p => p != null && p.A <= aCentro - margenLateral)
                .OrderBy(p => p.B)
                .FirstOrDefault();

            PuntoSeccionMain botDer = puntos
                .Where(p => p != null && p.A >= aCentro + margenLateral)
                .OrderBy(p => p.B)
                .FirstOrDefault();

            if (botCentro != null && botIzq != null && botDer != null)
            {
                double bLinea = InterpolarBEnA(
                    botIzq.A,
                    botIzq.B,
                    botDer.A,
                    botDer.B,
                    botCentro.A);

                if (bLinea - botCentro.B >= toleranciaQuiebre)
                    return true;
            }

            return false;
        }

        private double InterpolarBEnA(double a1, double b1, double a2, double b2, double a)
        {
            if (Math.Abs(a2 - a1) <= 1e-9)
                return (b1 + b2) / 2.0;

            double t = (a - a1) / (a2 - a1);

            return b1 + (b2 - b1) * t;
        }

        private bool SeccionActualTieneCuatroLadosDesdePreview()
        {
            if (vigasPreviewGlobalActuales == null || vigasPreviewGlobalActuales.Count == 0)
                return false;

            bool encontroGeometriaValida = false;

            foreach (VigaLongitudinalPreview viga in vigasPreviewGlobalActuales)
            {
                int lados = ContarLadosSeccionTransversal(viga);

                if (lados <= 0)
                    continue;

                encontroGeometriaValida = true;

                // Si aparece una sección con más de 4 lados, no se fuerza rectangular.
                // Una viga trapezoidal/rectangular tiene 4 lados; una cumbrera real
                // tendrá más vértices en el perfil transversal.
                if (lados > 4)
                    return false;
            }

            return encontroGeometriaValida;
        }

        private int ContarLadosSeccionTransversal(VigaLongitudinalPreview viga)
        {
            if (viga == null)
                return 0;

            // El handler de selección ya calcula los lados desde la geometría real.
            // Si existe ese dato, se respeta primero.
            try
            {
                object raw = ObtenerValorPropiedad(viga, "LadosSeccionTransversalDetectados");

                if (raw != null)
                {
                    int ladosProp;

                    if (int.TryParse(raw.ToString(), out ladosProp) && ladosProp > 0)
                        return ladosProp;
                }
            }
            catch
            {
            }

            // Respaldo: usar la sección transversal Y-Z desde sólidos 3D.
            // No se usan PerfilSuperiorMm/PerfilInferiorMm porque son perfiles
            // longitudinales X-Z, no la forma transversal.
            List<PuntoSeccionMain> puntos = ObtenerPuntosSeccionDesdeSolidos3D(viga);

            if (puntos == null || puntos.Count < 3)
                return 0;

            return ContarLadosGeometricosMainDesdePuntos(puntos);
        }

        private int ContarLadosGeometricosMainDesdePuntos(
            List<PuntoSeccionMain> puntos)
        {
            puntos = LimpiarPuntosSeccion(puntos);

            if (puntos == null || puntos.Count < 3)
                return 0;

            if (puntos.Count <= 4)
                return puntos.Count;

            if (PerfilPreviewTieneQuiebreCumbreraDesdePuntos(puntos))
                return Math.Max(5, puntos.Count);

            return puntos.Count;
        }

        private bool PerfilPreviewTieneQuiebreCumbreraDesdePuntos(
            List<PuntoSeccionMain> puntos)
        {
            if (puntos == null || puntos.Count < 5)
                return false;

            double aMin = puntos.Min(p => p.A);
            double aMax = puntos.Max(p => p.A);
            double bMin = puntos.Min(p => p.B);
            double bMax = puntos.Max(p => p.B);

            double ancho = aMax - aMin;
            double peralte = bMax - bMin;

            if (ancho <= 1e-9 || peralte <= 1e-9)
                return false;

            double aCentro = (aMin + aMax) / 2.0;
            double margenCentral = ancho * 0.28;
            double margenLateral = ancho * 0.18;
            double toleranciaQuiebre = Math.Max(15.0, peralte * 0.035);

            PuntoSeccionMain topCentro = puntos
                .Where(p => p != null && Math.Abs(p.A - aCentro) <= margenCentral)
                .OrderByDescending(p => p.B)
                .FirstOrDefault();

            PuntoSeccionMain topIzq = puntos
                .Where(p => p != null && p.A <= aCentro - margenLateral)
                .OrderByDescending(p => p.B)
                .FirstOrDefault();

            PuntoSeccionMain topDer = puntos
                .Where(p => p != null && p.A >= aCentro + margenLateral)
                .OrderByDescending(p => p.B)
                .FirstOrDefault();

            if (topCentro != null && topIzq != null && topDer != null)
            {
                double bLinea = InterpolarBEnA(
                    topIzq.A,
                    topIzq.B,
                    topDer.A,
                    topDer.B,
                    topCentro.A);

                if (topCentro.B - bLinea >= toleranciaQuiebre)
                    return true;
            }

            PuntoSeccionMain botCentro = puntos
                .Where(p => p != null && Math.Abs(p.A - aCentro) <= margenCentral)
                .OrderBy(p => p.B)
                .FirstOrDefault();

            PuntoSeccionMain botIzq = puntos
                .Where(p => p != null && p.A <= aCentro - margenLateral)
                .OrderBy(p => p.B)
                .FirstOrDefault();

            PuntoSeccionMain botDer = puntos
                .Where(p => p != null && p.A >= aCentro + margenLateral)
                .OrderBy(p => p.B)
                .FirstOrDefault();

            if (botCentro != null && botIzq != null && botDer != null)
            {
                double bLinea = InterpolarBEnA(
                    botIzq.A,
                    botIzq.B,
                    botDer.A,
                    botDer.B,
                    botCentro.A);

                if (bLinea - botCentro.B >= toleranciaQuiebre)
                    return true;
            }

            return false;
        }

        private class PuntoSeccionMain
        {
            public double A;
            public double B;

            public PuntoSeccionMain(double a, double b)
            {
                A = a;
                B = b;
            }
        }

        private List<PuntoSeccionMain> ObtenerPuntosSeccionDesdePerfiles(
            VigaLongitudinalPreview viga)
        {
            List<PuntoSeccionMain> resultado = new List<PuntoSeccionMain>();

            try
            {
                object supObj = ObtenerValorPropiedad(viga, "PerfilSuperiorMm");
                object infObj = ObtenerValorPropiedad(viga, "PerfilInferiorMm");

                List<PuntoSeccionMain> sup = ConvertirListaPerfilASeccion(supObj);
                List<PuntoSeccionMain> inf = ConvertirListaPerfilASeccion(infObj);

                if (sup != null && sup.Count > 0)
                    resultado.AddRange(sup);

                if (inf != null && inf.Count > 0)
                {
                    inf.Reverse();
                    resultado.AddRange(inf);
                }
            }
            catch
            {
                resultado.Clear();
            }

            return resultado;
        }

        private List<PuntoSeccionMain> ConvertirListaPerfilASeccion(object listaObj)
        {
            List<PuntoSeccionMain> resultado = new List<PuntoSeccionMain>();

            System.Collections.IEnumerable enumerable =
                listaObj as System.Collections.IEnumerable;

            if (enumerable == null)
                return resultado;

            foreach (object p in enumerable)
            {
                if (p == null)
                    continue;

                double xMm;
                double zMm;

                if (!TryObtenerDoublePropiedad(p, "XMm", out xMm))
                    continue;

                if (!TryObtenerDoublePropiedad(p, "ZMm", out zMm))
                    continue;

                resultado.Add(new PuntoSeccionMain(xMm, zMm));
            }

            return resultado;
        }

        private List<PuntoSeccionMain> ObtenerPuntosSeccionDesdeSolidos3D(
            VigaLongitudinalPreview viga)
        {
            List<PuntoSeccionMain> resultado = new List<PuntoSeccionMain>();

            try
            {
                object solidosObj = ObtenerValorPropiedad(viga, "Solidos3D");
                System.Collections.IEnumerable solidos =
                    solidosObj as System.Collections.IEnumerable;

                if (solidos == null)
                    return resultado;

                foreach (object solido in solidos)
                {
                    if (solido == null)
                        continue;

                    object puntosObj = ObtenerValorPropiedad(solido, "Puntos");
                    System.Collections.IEnumerable puntos =
                        puntosObj as System.Collections.IEnumerable;

                    if (puntos == null)
                        continue;

                    foreach (object p in puntos)
                    {
                        if (p == null)
                            continue;

                        double yMm;
                        double zMm;

                        if (!TryObtenerDoublePropiedad(p, "YMm", out yMm))
                            continue;

                        if (!TryObtenerDoublePropiedad(p, "ZMm", out zMm))
                            continue;

                        // Para contar lados de sección, usamos la proyección Y-Z:
                        // rectangular/trapezoidal = 4 puntos; cumbrera real = más puntos.
                        resultado.Add(new PuntoSeccionMain(yMm, zMm));
                    }
                }
            }
            catch
            {
                resultado.Clear();
            }

            return resultado;
        }

        private List<PuntoSeccionMain> LimpiarPuntosSeccion(
            List<PuntoSeccionMain> puntos)
        {
            List<PuntoSeccionMain> unicos = new List<PuntoSeccionMain>();

            if (puntos == null)
                return unicos;

            foreach (PuntoSeccionMain p in puntos)
            {
                if (p == null)
                    continue;

                bool existe = false;

                foreach (PuntoSeccionMain q in unicos)
                {
                    if (Distancia2D(p, q) <= 1.0) // 1 mm
                    {
                        existe = true;
                        break;
                    }
                }

                if (!existe)
                    unicos.Add(new PuntoSeccionMain(p.A, p.B));
            }

            if (unicos.Count <= 2)
                return unicos;

            List<PuntoSeccionMain> ordenados = OrdenarPuntosAlrededorCentro(unicos);
            ordenados = EliminarPuntosColineales(ordenados, 2.0); // 2 mm

            return ordenados;
        }

        private List<PuntoSeccionMain> OrdenarPuntosAlrededorCentro(
            List<PuntoSeccionMain> puntos)
        {
            if (puntos == null || puntos.Count <= 2)
                return puntos ?? new List<PuntoSeccionMain>();

            double ca = puntos.Average(p => p.A);
            double cb = puntos.Average(p => p.B);

            return puntos
                .OrderBy(p => Math.Atan2(p.B - cb, p.A - ca))
                .ToList();
        }

        private List<PuntoSeccionMain> EliminarPuntosColineales(
            List<PuntoSeccionMain> puntos,
            double toleranciaMm)
        {
            List<PuntoSeccionMain> resultado = new List<PuntoSeccionMain>();

            if (puntos == null || puntos.Count <= 3)
                return puntos ?? resultado;

            for (int i = 0; i < puntos.Count; i++)
            {
                PuntoSeccionMain prev = puntos[(i - 1 + puntos.Count) % puntos.Count];
                PuntoSeccionMain act = puntos[i];
                PuntoSeccionMain next = puntos[(i + 1) % puntos.Count];

                double area2 = Math.Abs(
                    ((act.A - prev.A) * (next.B - prev.B)) -
                    ((act.B - prev.B) * (next.A - prev.A)));

                double baseLen = Distancia2D(prev, next);
                double altura = baseLen <= 1e-9 ? 0.0 : area2 / baseLen;

                if (altura > toleranciaMm)
                    resultado.Add(act);
            }

            return resultado;
        }

        private double Distancia2D(PuntoSeccionMain a, PuntoSeccionMain b)
        {
            if (a == null || b == null)
                return double.MaxValue;

            double da = a.A - b.A;
            double db = a.B - b.B;

            return Math.Sqrt((da * da) + (db * db));
        }

        private object ObtenerValorPropiedad(object obj, string nombrePropiedad)
        {
            if (obj == null || string.IsNullOrWhiteSpace(nombrePropiedad))
                return null;

            System.Reflection.PropertyInfo prop = obj.GetType().GetProperty(nombrePropiedad);

            if (prop == null)
                return null;

            return prop.GetValue(obj, null);
        }

        private bool TryObtenerDoublePropiedad(
            object obj,
            string nombrePropiedad,
            out double valor)
        {
            valor = 0.0;

            object raw = ObtenerValorPropiedad(obj, nombrePropiedad);

            if (raw == null)
                return false;

            try
            {
                valor = Convert.ToDouble(
                    raw,
                    System.Globalization.CultureInfo.InvariantCulture);

                return true;
            }
            catch
            {
                return false;
            }
        }

        private void SeleccionarFormaGlobal(
            AceroEstribosVigasForm.TipoFormaEstribo tipo)
        {
            if (cmbSelectorFormaGlobal == null ||
                cmbSelectorFormaGlobal.Items.Count == 0)
                return;

            for (int i = 0; i < cmbSelectorFormaGlobal.Items.Count; i++)
            {
                SelectorFormaGlobalItem item =
                    cmbSelectorFormaGlobal.Items[i] as SelectorFormaGlobalItem;

                if (item == null)
                    continue;

                if (item.Tipo == tipo)
                {
                    if (cmbSelectorFormaGlobal.SelectedIndex != i)
                        cmbSelectorFormaGlobal.SelectedIndex = i;

                    return;
                }
            }
        }

        private void SincronizarFormaGlobalConVentanas()
        {
            try
            {
                if (VentanaEstribos != null && !VentanaEstribos.IsDisposed)
                {
                    VentanaEstribos.EstablecerSelectorFormaDesdeMain(
                        FormaSelectorGlobalSeleccionada,
                        DetectarFormaGlobalAutomaticamente);
                }
            }
            catch
            {
                // No interrumpir cambio visual por sincronización.
            }
        }

        private void ActualizarBloqueoSelectorFormaGlobal()
        {
            if (cmbSelectorFormaGlobal == null)
                return;

            bool automatico = DetectarFormaGlobalAutomaticamente;

            cmbSelectorFormaGlobal.Enabled = !automatico;
            cmbSelectorFormaGlobal.TabStop = !automatico;
            cmbSelectorFormaGlobal.Cursor = automatico
                ? WinForms.Cursors.No
                : WinForms.Cursors.Hand;

            RefrescarSelectorFormaGlobal();
        }

        private void AjustarSelectorFormaGlobal()
        {
            int posicionX = Math.Max(
                ANCHO_MENU + 20,
                this.ClientSize.Width - 260);
            int posicionY = 86;

            if (lblSelectorFormaGlobal != null)
                lblSelectorFormaGlobal.Visible = false;
            if (cmbSelectorFormaGlobal != null)
                cmbSelectorFormaGlobal.Visible = false;
            if (chkDetectarFormaGlobal != null)
                chkDetectarFormaGlobal.Visible = false;

            if (btnEditarAceroSeccionGlobal != null)
            {
                btnEditarAceroSeccionGlobal.Left = posicionX;
                btnEditarAceroSeccionGlobal.Top = posicionY;
                btnEditarAceroSeccionGlobal.Width = 225;
            }

            if (lblResumenAceroSeccionGlobal != null)
            {
                lblResumenAceroSeccionGlobal.Left = posicionX;
                lblResumenAceroSeccionGlobal.Top = posicionY + 55;
                lblResumenAceroSeccionGlobal.Width = 225;
            }

            TraerSelectorFormaGlobalAlFrente();
        }

        private void TraerSelectorFormaGlobalAlFrente()
        {
            try
            {
                if (lblSelectorFormaGlobal != null)
                    lblSelectorFormaGlobal.BringToFront();

                if (cmbSelectorFormaGlobal != null)
                    cmbSelectorFormaGlobal.BringToFront();

                if (chkDetectarFormaGlobal != null)
                    chkDetectarFormaGlobal.BringToFront();


                if (btnEditarAceroSeccionGlobal != null)
                    btnEditarAceroSeccionGlobal.BringToFront();

                if (lblResumenAceroSeccionGlobal != null)
                    lblResumenAceroSeccionGlobal.BringToFront();
            }
            catch
            {
            }
        }

        private void RefrescarSelectorFormaGlobal()
        {
            try
            {
                if (cmbSelectorFormaGlobal != null)
                {
                    cmbSelectorFormaGlobal.Invalidate();
                    cmbSelectorFormaGlobal.Refresh();
                    cmbSelectorFormaGlobal.Update();
                }
            }
            catch
            {
            }
        }

        private void CmbSelectorFormaGlobal_DrawItem(
            object sender,
            WinForms.DrawItemEventArgs e)
        {
            if (cmbSelectorFormaGlobal == null ||
                cmbSelectorFormaGlobal.Items.Count == 0)
                return;

            int index = e.Index;

            if (index < 0)
                index = cmbSelectorFormaGlobal.SelectedIndex;

            if (index < 0 || index >= cmbSelectorFormaGlobal.Items.Count)
                return;

            e.DrawBackground();

            SelectorFormaGlobalItem item =
                cmbSelectorFormaGlobal.Items[index] as SelectorFormaGlobalItem;

            if (item == null)
                return;

            bool seleccionado =
                index == cmbSelectorFormaGlobal.SelectedIndex ||
                (e.State & WinForms.DrawItemState.Selected) == WinForms.DrawItemState.Selected;

            Drawing.Color fondo = seleccionado
                ? Drawing.Color.FromArgb(220, 235, 252)
                : Drawing.Color.White;

            using (Drawing.Brush brFondo = new Drawing.SolidBrush(fondo))
                e.Graphics.FillRectangle(brFondo, e.Bounds);

            Drawing.Rectangle iconRect = new Drawing.Rectangle(
                e.Bounds.Left + 8,
                e.Bounds.Top + 7,
                Math.Max(135, e.Bounds.Width - 22),
                Math.Max(78, e.Bounds.Height - 16));

            DibujarIconoSelectorFormaGlobal(
                e.Graphics,
                iconRect,
                item.Tipo,
                seleccionado);

            if (cmbSelectorFormaGlobal.Enabled)
                e.DrawFocusRectangle();
        }

        private Drawing.Image CargarImagenSelectorGlobal(
            string nombrePrincipal,
            string nombreRespaldo)
        {
            Drawing.Image img = CargarImagenSelectorGlobal(nombrePrincipal);

            if (img != null)
                return img;

            return CargarImagenSelectorGlobal(nombreRespaldo);
        }

        private Drawing.Image CargarImagenSelectorGlobal(string nombreArchivo)
        {
            // Compatibilidad binaria: el método permanece, pero el módulo ya no
            // busca ni carga archivos PNG para definir la sección.
            return null;
        }

        private string BuscarRutaIconoSelectorGlobal(string nombreArchivo)
        {
            if (string.IsNullOrWhiteSpace(nombreArchivo))
                return null;

            List<string> candidatos = new List<string>();

            try
            {
                string assemblyPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                string folder = System.IO.Path.GetDirectoryName(assemblyPath);

                if (!string.IsNullOrWhiteSpace(folder))
                {
                    candidatos.Add(System.IO.Path.Combine(folder, "iconos", nombreArchivo));
                    candidatos.Add(System.IO.Path.Combine(folder, nombreArchivo));
                }
            }
            catch
            {
            }

            try
            {
                string programData = Environment.GetFolderPath(
                    Environment.SpecialFolder.CommonApplicationData);

                if (!string.IsNullOrWhiteSpace(programData))
                {
                    candidatos.Add(System.IO.Path.Combine(
                        programData,
                        "Autodesk",
                        "Revit",
                        "Addins",
                        "2027",
                        "MYG",
                        "iconos",
                        nombreArchivo));
                }
            }
            catch
            {
            }

            foreach (string ruta in candidatos)
            {
                try
                {
                    if (!string.IsNullOrWhiteSpace(ruta) &&
                        System.IO.File.Exists(ruta))
                        return ruta;
                }
                catch
                {
                }
            }

            return null;
        }

        private void DibujarIconoSelectorFormaGlobal(
            Drawing.Graphics g,
            Drawing.Rectangle r,
            AceroEstribosVigasForm.TipoFormaEstribo tipo,
            bool seleccionado)
        {
            Drawing.Image img = tipo == AceroEstribosVigasForm.TipoFormaEstribo.Cumbrera
                ? imgGlobalCumbreraActual
                : imgGlobalRectangularActual;

            if (img != null)
            {
                System.Drawing.Drawing2D.InterpolationMode oldInterpolation = g.InterpolationMode;
                System.Drawing.Drawing2D.SmoothingMode oldSmoothing = g.SmoothingMode;
                System.Drawing.Drawing2D.PixelOffsetMode oldPixel = g.PixelOffsetMode;

                try
                {
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                    g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;

                    using (Drawing.Brush br = new Drawing.SolidBrush(Drawing.Color.White))
                        g.FillRectangle(br, r);

                    Drawing.Rectangle destino = AjustarImagenSelectorGlobal(img, r);
                    g.DrawImage(img, destino);

                    // LONGITUDINAL: la imagen base se mantiene, pero los puntos
                    // de acero se dibujan dinámicamente encima según las cantidades
                    // y capas configuradas en la ventana longitudinal.
                    DibujarDisposicionAcerosSobreSelectorGlobal(g, destino, tipo);
                    return;
                }
                finally
                {
                    g.InterpolationMode = oldInterpolation;
                    g.SmoothingMode = oldSmoothing;
                    g.PixelOffsetMode = oldPixel;
                }
            }

            DibujarMiniaturaSelectorGlobal(g, r, tipo, seleccionado);
        }

        private Drawing.Rectangle AjustarImagenSelectorGlobal(
            Drawing.Image img,
            Drawing.Rectangle r)
        {
            if (img == null || r.Width <= 0 || r.Height <= 0)
                return r;

            double ratioImg = (double)img.Width / Math.Max(1, img.Height);
            double ratioRect = (double)r.Width / Math.Max(1, r.Height);

            int w;
            int h;

            if (ratioImg > ratioRect)
            {
                w = r.Width;
                h = (int)Math.Round(w / ratioImg);
            }
            else
            {
                h = r.Height;
                w = (int)Math.Round(h * ratioImg);
            }

            int x = r.Left + (r.Width - w) / 2;
            int y = r.Top + (r.Height - h) / 2;

            return new Drawing.Rectangle(x, y, w, h);
        }

        private void DibujarMiniaturaSelectorGlobal(
            Drawing.Graphics g,
            Drawing.Rectangle r,
            AceroEstribosVigasForm.TipoFormaEstribo tipo,
            bool seleccionado)
        {
            if (g == null)
                return;

            System.Drawing.Drawing2D.SmoothingMode oldMode = g.SmoothingMode;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            try
            {
                using (Drawing.Brush br = new Drawing.SolidBrush(Drawing.Color.FromArgb(245, 248, 252)))
                using (Drawing.Pen penBorde = new Drawing.Pen(Drawing.Color.FromArgb(170, 190, 210), 1.0f))
                {
                    g.FillRectangle(br, r);
                    g.DrawRectangle(penBorde, r);
                }

                Drawing.Rectangle rr = new Drawing.Rectangle(
                    r.Left + 8,
                    r.Top + 6,
                    Math.Max(10, r.Width - 16),
                    Math.Max(10, r.Height - 12));

                using (Drawing.Pen penRojo = new Drawing.Pen(Drawing.Color.FromArgb(235, 0, 0), 2.0f))
                using (Drawing.Pen penAzul = new Drawing.Pen(Drawing.Color.FromArgb(0, 80, 210), 2.0f))
                using (Drawing.Pen penGris = new Drawing.Pen(Drawing.Color.FromArgb(110, 110, 110), 1.0f))
                {
                    if (tipo == AceroEstribosVigasForm.TipoFormaEstribo.Cumbrera)
                    {
                        int xMedio = rr.Left + rr.Width / 2;

                        Drawing.Point pLi = new Drawing.Point(rr.Left, rr.Top + (int)(rr.Height * 0.72));
                        Drawing.Point pLs = new Drawing.Point(rr.Left, rr.Top + (int)(rr.Height * 0.36));
                        Drawing.Point pCsup = new Drawing.Point(xMedio, rr.Top + 2);
                        Drawing.Point pCinf = new Drawing.Point(xMedio, rr.Bottom - 2);
                        Drawing.Point pRs = new Drawing.Point(rr.Right, rr.Top + (int)(rr.Height * 0.36));
                        Drawing.Point pRi = new Drawing.Point(rr.Right, rr.Top + (int)(rr.Height * 0.72));

                        if (modoSelectorFormaActual == ModoSelectorFormaGlobal.Longitudinal)
                        {
                            g.DrawLine(penAzul, rr.Left, rr.Top + 8, rr.Right, rr.Top + 8);
                            g.DrawLine(penRojo, rr.Left, rr.Bottom - 8, rr.Right, rr.Bottom - 8);
                            g.DrawLine(penGris, xMedio, rr.Top + 2, xMedio, rr.Bottom - 2);
                        }
                        else
                        {
                            g.DrawPolygon(penRojo, new Drawing.Point[] { pLi, pLs, pCsup, pCinf });
                            g.DrawPolygon(penAzul, new Drawing.Point[] { pCinf, pCsup, pRs, pRi });
                            g.DrawLine(penGris, xMedio, rr.Top + 1, xMedio, rr.Bottom - 1);
                        }
                    }
                    else
                    {
                        if (modoSelectorFormaActual == ModoSelectorFormaGlobal.Longitudinal)
                        {
                            g.DrawLine(penAzul, rr.Left, rr.Top + 8, rr.Right, rr.Top + 8);
                            g.DrawLine(penRojo, rr.Left, rr.Bottom - 8, rr.Right, rr.Bottom - 8);
                            g.DrawRectangle(penGris, rr);
                        }
                        else
                        {
                            g.DrawRectangle(penRojo, rr);
                        }
                    }
                }
                // Respaldo sin imagen: si no se encontró el PNG, se dibuja la
                // sección base y luego los puntos dinámicos encima.
                DibujarDisposicionAcerosSobreSelectorGlobal(g, rr, tipo);
            }
            finally
            {
                g.SmoothingMode = oldMode;
            }
        }




        // =========================================================
        // LONGITUDINAL - PUNTOS DINÁMICOS SOBRE LA IMAGEN DEL SELECTOR GLOBAL
        // =========================================================
        private void DibujarDisposicionAcerosSobreSelectorGlobal(
            Drawing.Graphics g,
            Drawing.Rectangle areaImagen,
            AceroEstribosVigasForm.TipoFormaEstribo tipo)
        {
            if (g == null)
                return;

            if (modoSelectorFormaActual != ModoSelectorFormaGlobal.Longitudinal)
                return;

            if (VentanaLongitudinal == null || VentanaLongitudinal.IsDisposed)
                return;

            if (areaImagen.Width <= 10 || areaImagen.Height <= 10)
                return;

            Drawing.Rectangle rectSeccion = CalcularRectSeccionLongitudinalSelectorGlobal(areaImagen);

            // Se cubre solamente el área de la sección para eliminar los puntos
            // estáticos que venían dentro del PNG y reemplazarlos por puntos dinámicos.
            DibujarSeccionBaseSelectorGlobal(g, rectSeccion, tipo);

            int capasSup = Math.Max(1, Math.Min(3, VentanaLongitudinal.CapasSuperiores));
            int capasInf = Math.Max(1, Math.Min(3, VentanaLongitudinal.CapasInferiores));

            int cantSup1 = ObtenerCantidadSelectorGlobal(VentanaLongitudinal.CantidadSuperiorTexto, 2);
            int cantInf1 = ObtenerCantidadSelectorGlobal(VentanaLongitudinal.CantidadInferiorTexto, 2);
            int cantSup2 = ObtenerCantidadSelectorGlobal(VentanaLongitudinal.CantidadSuperiorCapa2Texto, cantSup1);
            int cantSup3 = ObtenerCantidadSelectorGlobal(VentanaLongitudinal.CantidadSuperiorCapa3Texto, cantSup2);
            int cantInf2 = ObtenerCantidadSelectorGlobal(VentanaLongitudinal.CantidadInferiorCapa2Texto, cantInf1);
            int cantInf3 = ObtenerCantidadSelectorGlobal(VentanaLongitudinal.CantidadInferiorCapa3Texto, cantInf2);

            Drawing.Color colorSup = Drawing.Color.FromArgb(0, 90, 200);
            Drawing.Color colorInf = Drawing.Color.FromArgb(220, 120, 0);
            Drawing.Color colorCentral = Drawing.Color.FromArgb(0, 150, 70);

            if (capasSup >= 1)
                DibujarCapaPuntosSelectorGlobal(g, rectSeccion, cantSup1, 1, true, colorSup);
            if (capasSup >= 2)
                DibujarCapaPuntosSelectorGlobal(g, rectSeccion, cantSup2, 2, true, colorSup);
            if (capasSup >= 3)
                DibujarCapaPuntosSelectorGlobal(g, rectSeccion, cantSup3, 3, true, colorSup);

            if (capasInf >= 1)
                DibujarCapaPuntosSelectorGlobal(g, rectSeccion, cantInf1, 1, false, colorInf);
            if (capasInf >= 2)
                DibujarCapaPuntosSelectorGlobal(g, rectSeccion, cantInf2, 2, false, colorInf);
            if (capasInf >= 3)
                DibujarCapaPuntosSelectorGlobal(g, rectSeccion, cantInf3, 3, false, colorInf);

            if (VentanaLongitudinal.AceroCentral)
                DibujarCapaPuntosSelectorGlobal(g, rectSeccion, 2, 0, true, colorCentral);
        }

        private Drawing.Rectangle CalcularRectSeccionLongitudinalSelectorGlobal(
            Drawing.Rectangle areaImagen)
        {
            // Se amplía el ancho útil para que el rango horizontal de puntos
            // ocupe mejor el interior del estribo de la imagen base.
            int ancho = Math.Min(60, Math.Max(34, (int)Math.Round(areaImagen.Width * 0.40)));
            int alto = Math.Min(74, Math.Max(46, (int)Math.Round(areaImagen.Height * 0.80)));

            int x = areaImagen.Left + (areaImagen.Width - ancho) / 2;
            int y = areaImagen.Top + (areaImagen.Height - alto) / 2;

            return new Drawing.Rectangle(x, y, ancho, alto);
        }

        private void DibujarSeccionBaseSelectorGlobal(
            Drawing.Graphics g,
            Drawing.Rectangle rectSeccion,
            AceroEstribosVigasForm.TipoFormaEstribo tipo)
        {
            // Solo se limpia el interior para ocultar los puntos estáticos del PNG,
            // sin dibujar un nuevo recuadro encima de la imagen base.
            using (Drawing.SolidBrush brushConcreto = new Drawing.SolidBrush(Drawing.Color.FromArgb(245, 245, 245)))
            {
                if (tipo == AceroEstribosVigasForm.TipoFormaEstribo.Cumbrera)
                {
                    int xMedio = rectSeccion.Left + rectSeccion.Width / 2;

                    Drawing.Point[] poligono = new Drawing.Point[]
                    {
                        new Drawing.Point(rectSeccion.Left + 1, rectSeccion.Bottom - 1),
                        new Drawing.Point(rectSeccion.Left + 1, rectSeccion.Top + (int)(rectSeccion.Height * 0.38) + 1),
                        new Drawing.Point(xMedio, rectSeccion.Top + 1),
                        new Drawing.Point(rectSeccion.Right - 1, rectSeccion.Top + (int)(rectSeccion.Height * 0.38) + 1),
                        new Drawing.Point(rectSeccion.Right - 1, rectSeccion.Bottom - 1)
                    };

                    g.FillPolygon(brushConcreto, poligono);
                }
                else
                {
                    Drawing.Rectangle rectInterior = new Drawing.Rectangle(
                        rectSeccion.Left + 1,
                        rectSeccion.Top + 1,
                        Math.Max(1, rectSeccion.Width - 2),
                        Math.Max(1, rectSeccion.Height - 2));

                    g.FillRectangle(brushConcreto, rectInterior);
                }
            }
        }

        private int ObtenerCantidadSelectorGlobal(string texto, int valorDefecto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return Math.Max(0, valorDefecto);

            texto = texto.Trim();
            int valor;

            if (!int.TryParse(texto, out valor))
            {
                double valorDecimal;

                if (double.TryParse(
                    texto,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out valorDecimal))
                {
                    valor = (int)Math.Round(valorDecimal);
                }
                else if (double.TryParse(
                    texto,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.CurrentCulture,
                    out valorDecimal))
                {
                    valor = (int)Math.Round(valorDecimal);
                }
                else
                {
                    valor = valorDefecto;
                }
            }

            if (valor < 0)
                valor = 0;

            if (valor > 12)
                valor = 12;

            return valor;
        }

        private void DibujarCapaPuntosSelectorGlobal(
            Drawing.Graphics g,
            Drawing.Rectangle rectSeccion,
            int cantidad,
            int indiceCapa,
            bool superior,
            Drawing.Color color)
        {
            if (g == null || cantidad <= 0)
                return;

            int diametro = rectSeccion.Height <= 55 ? 5 : 6;
            // Se vuelve a abrir un poco la separación entre capas para que no
            // se vean tan juntas y para que las capas extremas lleguen más cerca
            // del tope interior del estribo.
            int separacionCapa = Math.Max(6, Math.Min(8, rectSeccion.Height / 9));
            int margenY = Math.Max(4, rectSeccion.Height / 14);
            // Se conserva el rango horizontal apenas abierto de la versión anterior.
            int margenX = Math.Max(3, rectSeccion.Width / 10);

            int ajusteSuperiorY = -1;
            int ajusteInferiorY = 1;
            int y;

            if (indiceCapa == 0)
            {
                y = rectSeccion.Top + rectSeccion.Height / 2;
            }
            else if (superior)
            {
                y = rectSeccion.Top + margenY + ((indiceCapa - 1) * separacionCapa) + ajusteSuperiorY;
            }
            else
            {
                y = rectSeccion.Bottom - margenY - ((indiceCapa - 1) * separacionCapa) + ajusteInferiorY;
            }

            int xInicio = rectSeccion.Left + margenX;
            int xFin = rectSeccion.Right - margenX;

            using (Drawing.SolidBrush brush = new Drawing.SolidBrush(color))
            {
                for (int i = 0; i < cantidad; i++)
                {
                    float t = cantidad == 1
                        ? 0.5F
                        : (float)i / (float)(cantidad - 1);

                    float x = xInicio + ((xFin - xInicio) * t);

                    Drawing.RectangleF punto = new Drawing.RectangleF(
                        x - (diametro / 2.0F),
                        y - (diametro / 2.0F),
                        diametro,
                        diametro);

                    g.FillEllipse(brush, punto);
                }
            }
        }


        // =========================================================
        // VISTA PRELIMINAR FIJA INFERIOR
        // =========================================================
        // El panel rojo del esquema ya no pertenece a cada pestaña.
        // Siempre vive en panelVistaPreviaFija y solo se cambia el contenido/gráfico
        // según el botón del menú izquierdo.
        private void CargarVistaPreviaLongitudinalFija(bool soloGeometria)
        {
            AsegurarVentanaLongitudinal();

            if (VentanaLongitudinal == null || VentanaLongitudinal.IsDisposed)
                return;

            try
            {
                VentanaLongitudinal.EstablecerVistaSoloGeometria(soloGeometria);
            }
            catch
            {
            }

            if (previewLongitudinalFijo == null || previewLongitudinalFijo.IsDisposed)
            {
                previewLongitudinalFijo = BuscarControlPorTexto<WinForms.GroupBox>(
                    VentanaLongitudinal,
                    "Vista preliminar");
            }

            if (previewLongitudinalFijo == null)
                return;

            MontarVistaPreviaFija(previewLongitudinalFijo);
        }

        private void CargarVistaPreviaEstribosFija()
        {
            AsegurarVentanaEstribos();

            if (VentanaEstribos == null || VentanaEstribos.IsDisposed)
                return;

            if (previewEstribosFijo == null || previewEstribosFijo.IsDisposed)
            {
                previewEstribosFijo = BuscarControlPorTexto<WinForms.GroupBox>(
                    VentanaEstribos,
                    "Vista preliminar de estribos por tramo");
            }

            if (previewEstribosFijo == null)
                return;

            MontarVistaPreviaFija(previewEstribosFijo);
        }

        private void MontarVistaPreviaFija(WinForms.Control preview)
        {
            if (preview == null || panelVistaPreviaFija == null)
                return;

            try
            {
                if (preview.Parent != null)
                    preview.Parent.Controls.Remove(preview);

                panelVistaPreviaFija.Controls.Clear();
                panelVistaPreviaFija.Controls.Add(preview);

                AjustarControlVistaPrevia(preview);

                preview.Visible = true;
                preview.BringToFront();
                preview.Invalidate(true);
            }
            catch
            {
                // No interrumpir cambio de pestaña por un refresco visual.
            }
        }

        private void AjustarVistaPreviaFijaActual()
        {
            if (panelVistaPreviaFija == null || panelVistaPreviaFija.Controls.Count == 0)
                return;

            AjustarControlVistaPrevia(panelVistaPreviaFija.Controls[0]);
        }

        private void AjustarControlVistaPrevia(WinForms.Control preview)
        {
            if (preview == null || panelVistaPreviaFija == null)
                return;

            preview.Left = 6;
            preview.Top = 2;
            preview.Width = Math.Max(200, panelVistaPreviaFija.ClientSize.Width - 12);
            preview.Height = Math.Max(160, panelVistaPreviaFija.ClientSize.Height - 4);
            preview.Anchor = WinForms.AnchorStyles.Top |
                             WinForms.AnchorStyles.Bottom |
                             WinForms.AnchorStyles.Left |
                             WinForms.AnchorStyles.Right;

            AjustarHijosVistaPrevia(preview);
        }

        private void AjustarHijosVistaPrevia(WinForms.Control raiz)
        {
            if (raiz == null)
                return;

            foreach (WinForms.Control ctrl in raiz.Controls)
            {
                WinForms.Panel panel = ctrl as WinForms.Panel;

                if (panel != null)
                {
                    int margenX = panel.Left <= 12 ? 12 : 15;
                    int topPanel = panel.Top;

                    panel.Left = margenX;
                    panel.Top = topPanel;
                    panel.Width = Math.Max(100, raiz.ClientSize.Width - (margenX * 2));
                    panel.Height = Math.Max(70, raiz.ClientSize.Height - topPanel - 14);
                    panel.Anchor = WinForms.AnchorStyles.Top |
                                   WinForms.AnchorStyles.Bottom |
                                   WinForms.AnchorStyles.Left |
                                   WinForms.AnchorStyles.Right;

                    panel.Invalidate();
                    continue;
                }

                WinForms.CheckBox chk = ctrl as WinForms.CheckBox;

                if (chk != null && (chk.Text ?? "").IndexOf("Graficar", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    chk.Left = Math.Max(15, raiz.ClientSize.Width - chk.Width - 25);
                    chk.Anchor = WinForms.AnchorStyles.Top | WinForms.AnchorStyles.Right;
                }

                WinForms.Label lbl = ctrl as WinForms.Label;

                if (lbl != null)
                    lbl.Width = Math.Max(100, raiz.ClientSize.Width - lbl.Left - 20);
            }
        }

        private T BuscarControlPorTexto<T>(WinForms.Control raiz, string texto) where T : WinForms.Control
        {
            if (raiz == null)
                return default(T);

            foreach (WinForms.Control ctrl in raiz.Controls)
            {
                T encontrado = ctrl as T;

                if (encontrado != null &&
                    string.Equals(
                        (ctrl.Text ?? "").Trim(),
                        texto,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return encontrado;
                }

                T encontradoHijo = BuscarControlPorTexto<T>(ctrl, texto);

                if (encontradoHijo != null)
                    return encontradoHijo;
            }

            return default(T);
        }

        private void VentanaLongitudinal_PreviewLongitudinalParametrosActualizados()
        {
            try
            {
                if (panelVistaPreviaFija != null)
                {
                    panelVistaPreviaFija.Invalidate(true);
                    panelVistaPreviaFija.Update();
                }

                RefrescarVistaPreviaGlobal();
                RefrescarSelectorFormaGlobal();
            }
            catch
            {
                // No interrumpir por un refresco visual en tiempo real.
            }
        }

        private void VentanaLongitudinal_PreviewVigasActualizadas(
            List<VigaLongitudinalPreview> vigas)
        {
            try
            {
                vigasPreviewGlobalActuales = vigas == null
                    ? new List<VigaLongitudinalPreview>()
                    : new List<VigaLongitudinalPreview>(vigas);

                AsegurarVentanaEstribos();

                if (VentanaEstribos != null && !VentanaEstribos.IsDisposed)
                {
                    VentanaEstribos.CargarDesdeVigasPreview(vigas);

                    if (DetectarFormaGlobalAutomaticamente)
                        VentanaEstribos.RecalcularFormaAutomaticamenteDesdeMain();
                }

                if (VentanaSeleccionVigas != null && !VentanaSeleccionVigas.IsDisposed)
                    VentanaSeleccionVigas.RefrescarVista3D();

                if (DetectarFormaGlobalAutomaticamente)
                {
                    if (SeccionActualTieneIndicadorCumbreraDesdePreview())
                        AplicarFormaGlobalDetectadaDesdeVentana(AceroEstribosVigasForm.TipoFormaEstribo.Cumbrera);
                    else if (SeccionActualTieneCuatroLadosDesdePreview())
                        AplicarFormaGlobalDetectadaDesdeVentana(AceroEstribosVigasForm.TipoFormaEstribo.Rectangular);
                }

                AjustarVistaPreviaFijaActual();

                if (panelVistaPreviaFija != null)
                {
                    panelVistaPreviaFija.Invalidate(true);
                    panelVistaPreviaFija.Update();
                }

                RefrescarVistaPreviaGlobal();
                RefrescarSelectorFormaGlobal();
                ReconstruirEditorSeccionIncrustadoSiVisible();
            }
            catch
            {
                // No se interrumpe el flujo de selección.
            }
        }

        private void CargarVentanaSeleccionVigas()
        {
            mostrandoSeleccionVigas = true;
            CambiarModoSelectorFormaGlobal(ModoSelectorFormaGlobal.SeleccionVigas);

            AsegurarVentanaLongitudinal();
            PrepararBotonEjecutarLongitudinalCompartido();
            AsegurarVentanaSeleccionVigas();

            ActualizarLayoutBotonera(false);

            if (btnEjecutarLongitudinalCompartido != null)
                btnEjecutarLongitudinalCompartido.Visible = false;

            this.AcceptButton = null;

            try
            {
                if (VentanaLongitudinal.Parent == panelContenido)
                    panelContenido.Controls.Remove(VentanaLongitudinal);

                if (VentanaEstribos != null &&
                    !VentanaEstribos.IsDisposed &&
                    VentanaEstribos.Parent == panelContenido)
                {
                    panelContenido.Controls.Remove(VentanaEstribos);
                    VentanaEstribos.Hide();
                }

                VentanaLongitudinal.Hide();
            }
            catch
            {
                // No interrumpir.
            }

            VentanaSeleccionVigas.ActivarSeleccion();

            DestruirEditorSeccionIncrustado();
            panelContenido.Controls.Clear();

            ConfigurarFormularioEmbebido(VentanaSeleccionVigas);

            panelContenido.Controls.Add(VentanaSeleccionVigas);

            VentanaSeleccionVigas.Show();
            VentanaSeleccionVigas.BringToFront();

            // Vista preliminar fija inferior: solo geometría al seleccionar vigas.
            ConfigurarVistaPreviaGlobal(ModoVistaPrevia.SeleccionVigas);

            PintarBotonActivo(btnMenuSeleccionarVigas, true);
            PintarBotonActivo(btnMenuLongitudinal, false);
            PintarBotonActivo(btnMenuEstribos, false);
        }

        private void CargarVentanaLongitudinal()
        {
            mostrandoSeleccionVigas = false;
            CambiarModoSelectorFormaGlobal(ModoSelectorFormaGlobal.Longitudinal);

            AsegurarVentanaLongitudinal();
            PrepararBotonEjecutarLongitudinalCompartido();
            SincronizarTipoEstriboReferenciaEnLongitudinal();

            if (VentanaSeleccionVigas != null && !VentanaSeleccionVigas.IsDisposed)
                VentanaSeleccionVigas.RestaurarVistaPreviaEnLongitudinal();

            VentanaLongitudinal.EstablecerVistaSoloGeometria(false);

            ActualizarLayoutBotonera(true);

            if (btnEjecutarLongitudinalCompartido != null)
            {
                btnEjecutarLongitudinalCompartido.Visible = true;
                this.AcceptButton = btnEjecutarLongitudinalCompartido;
            }

            try
            {
                if (VentanaSeleccionVigas != null &&
                    !VentanaSeleccionVigas.IsDisposed &&
                    VentanaSeleccionVigas.Parent == panelContenido)
                {
                    panelContenido.Controls.Remove(VentanaSeleccionVigas);
                    VentanaSeleccionVigas.Hide();
                }

                if (VentanaEstribos != null &&
                    !VentanaEstribos.IsDisposed &&
                    VentanaEstribos.Parent == panelContenido)
                {
                    panelContenido.Controls.Remove(VentanaEstribos);
                    VentanaEstribos.Hide();
                }
            }
            catch
            {
                // No interrumpir.
            }

            ConfigurarVentanaLongitudinalComoControl();

            MostrarFormularioConEditorIntegradoEnPestana(
                VentanaLongitudinal,
                AceroVigaModoEditorInicial.Longitudinales);

            // Vista preliminar fija inferior: geometría + aceros longitudinales.
            ConfigurarVistaPreviaGlobal(ModoVistaPrevia.Longitudinal);

            PintarBotonActivo(btnMenuSeleccionarVigas, false);
            PintarBotonActivo(btnMenuLongitudinal, true);
            PintarBotonActivo(btnMenuEstribos, false);
        }

        private void CargarVentanaEstribos()
        {
            mostrandoSeleccionVigas = false;
            CambiarModoSelectorFormaGlobal(ModoSelectorFormaGlobal.Estribos);

            AsegurarVentanaLongitudinal();
            PrepararBotonEjecutarLongitudinalCompartido();
            AsegurarVentanaEstribos();
            ConectarTipoEstriboReferenciaEnLongitudinal();
            SincronizarTipoEstriboReferenciaEnLongitudinal();

            // La ventana de estribos toma los mismos tramos cargados por Seleccionar vigas.
            VentanaEstribos.ActualizarDesdeVentanaLongitudinal(VentanaLongitudinal);

            ActualizarLayoutBotonera(false);

            if (btnEjecutarLongitudinalCompartido != null)
                btnEjecutarLongitudinalCompartido.Visible = false;

            this.AcceptButton = null;

            try
            {
                if (VentanaLongitudinal.Parent == panelContenido)
                    panelContenido.Controls.Remove(VentanaLongitudinal);

                if (VentanaSeleccionVigas != null &&
                    !VentanaSeleccionVigas.IsDisposed &&
                    VentanaSeleccionVigas.Parent == panelContenido)
                {
                    panelContenido.Controls.Remove(VentanaSeleccionVigas);
                    VentanaSeleccionVigas.Hide();
                }

                VentanaLongitudinal.Hide();
            }
            catch
            {
                // No interrumpir.
            }

            ConfigurarFormularioEmbebido(VentanaEstribos);

            MostrarFormularioConEditorIntegradoEnPestana(
                VentanaEstribos,
                AceroVigaModoEditorInicial.Estribos);

            // Vista preliminar fija inferior: configuración gráfica de estribos.
            ConfigurarVistaPreviaGlobal(ModoVistaPrevia.Estribos);

            PintarBotonActivo(btnMenuSeleccionarVigas, false);
            PintarBotonActivo(btnMenuLongitudinal, false);
            PintarBotonActivo(btnMenuEstribos, true);
        }

        private void ConfigurarFormularioEmbebido(WinForms.Form form)
        {
            if (form == null || form.IsDisposed)
                return;

            form.TopLevel = false;
            form.FormBorderStyle = WinForms.FormBorderStyle.None;
            form.ShowInTaskbar = false;
            form.TopMost = false;
            form.Dock = WinForms.DockStyle.Fill;
        }

        private void PintarBotonActivo(WinForms.Button btn, bool activo)
        {
            if (btn == null)
                return;

            if (activo)
            {
                btn.BackColor = Drawing.Color.FromArgb(0, 120, 215);
                btn.ForeColor = Drawing.Color.White;
                btn.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(0, 105, 200);
                btn.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(0, 90, 180);
            }
            else
            {
                btn.BackColor = Drawing.Color.FromArgb(238, 240, 243);
                btn.ForeColor = Drawing.Color.FromArgb(55, 55, 55);
                btn.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(225, 228, 232);
                btn.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(215, 218, 222);
            }
        }

        private void AsegurarVentanaLongitudinal()
        {
            if (VentanaLongitudinal != null && !VentanaLongitudinal.IsDisposed)
            {
                ConfigurarVentanaLongitudinalComoControl();
                return;
            }

            VentanaLongitudinal = new AceroLongitudinalVigasForm();

            if (tiposArmaduraEditorSeccion != null &&
                tiposArmaduraEditorSeccion.Count > 0)
            {
                VentanaLongitudinal.CargarTiposArmadura(
                    tiposArmaduraEditorSeccion);
            }

            ConfigurarVentanaLongitudinalComoControl();

            if (vistaPreviaGlobal != null)
                vistaPreviaGlobal.ConfigurarReferencias(VentanaLongitudinal, VentanaEstribos);

            botonEjecutarLongitudinalPreparado = false;
            btnEjecutarLongitudinalCompartido = null;
            previewLongitudinalFijo = null;
            previewEstribosFijo = null;

            if (panelBotonera != null)
                panelBotonera.Controls.Clear();

            if (VentanaSeleccionVigas != null && !VentanaSeleccionVigas.IsDisposed)
            {
                try { VentanaSeleccionVigas.Dispose(); }
                catch { }
            }

            if (VentanaEstribos != null && !VentanaEstribos.IsDisposed)
            {
                try { VentanaEstribos.Dispose(); }
                catch { }
            }

            VentanaSeleccionVigas = null;
            VentanaEstribos = null;
        }

        private void AsegurarVentanaSeleccionVigas()
        {
            if (VentanaSeleccionVigas != null && !VentanaSeleccionVigas.IsDisposed)
                return;

            VentanaSeleccionVigas = new SeleccionarVigasForm(VentanaLongitudinal);
            ConfigurarFormularioEmbebido(VentanaSeleccionVigas);
        }

        private void AsegurarVentanaEstribos()
        {
            if (VentanaEstribos != null && !VentanaEstribos.IsDisposed)
                return;

            VentanaEstribos = new AceroEstribosVigasForm();

            if (tiposArmaduraEditorSeccion != null &&
                tiposArmaduraEditorSeccion.Count > 0)
            {
                VentanaEstribos.CargarTiposArmadura(
                    tiposArmaduraEditorSeccion);
            }

            try
            {
                // No nos suscribimos directamente a PreviewEstribosActualizado
                // porque no todas las versiones de AceroEstribosVigasForm tienen ese evento.
                // Se conecta por reflexión solo si existe.
                ConectarEventoPreviewEstribosActualizadoSiExiste();

                if (vistaPreviaGlobal != null)
                    vistaPreviaGlobal.ConfigurarReferencias(VentanaLongitudinal, VentanaEstribos);

                VentanaEstribos.FormaDetectadaAutomaticamenteChanged +=
                    AplicarFormaGlobalDetectadaDesdeVentana;

                ConectarTipoEstriboReferenciaEnLongitudinal();
                SincronizarTipoEstriboReferenciaEnLongitudinal();

                VentanaEstribos.EstablecerSelectorFormaDesdeMain(
                    FormaSelectorGlobalSeleccionada,
                    DetectarFormaGlobalAutomaticamente);
            }
            catch
            {
            }

            ConfigurarFormularioEmbebido(VentanaEstribos);
        }


        private void InvocarSeleccionarTramoDesdePreviewSiExiste(int index)
        {
            if (VentanaEstribos == null || VentanaEstribos.IsDisposed)
                return;

            try
            {
                System.Reflection.MethodInfo metodo =
                    VentanaEstribos.GetType().GetMethod(
                        "SeleccionarTramoDesdePreview",
                        System.Reflection.BindingFlags.Instance |
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.NonPublic);

                if (metodo == null)
                    return;

                metodo.Invoke(VentanaEstribos, new object[] { index });
            }
            catch
            {
                // Compatibilidad: si la ventana de estribos no tiene ese método
                // o falla al invocarlo, no se interrumpe el MAIN.
            }
        }


        private void ConectarEventoPreviewLongitudinalParametrosActualizadosSiExiste()
        {
            if (VentanaLongitudinal == null || VentanaLongitudinal.IsDisposed)
                return;

            try
            {
                System.Reflection.EventInfo evento =
                    VentanaLongitudinal.GetType().GetEvent(
                        "PreviewLongitudinalParametrosActualizados",
                        System.Reflection.BindingFlags.Instance |
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.NonPublic);

                if (evento == null)
                    return;

                System.Reflection.MethodInfo metodo =
                    this.GetType().GetMethod(
                        "VentanaLongitudinal_PreviewLongitudinalParametrosActualizados",
                        System.Reflection.BindingFlags.Instance |
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.NonPublic);

                if (metodo == null)
                    return;

                Delegate delegado = Delegate.CreateDelegate(
                    evento.EventHandlerType,
                    this,
                    metodo,
                    false);

                if (delegado == null)
                    return;

                try
                {
                    evento.RemoveEventHandler(VentanaLongitudinal, delegado);
                }
                catch
                {
                }

                evento.AddEventHandler(VentanaLongitudinal, delegado);
            }
            catch
            {
                // No interrumpir por compatibilidad de eventos.
            }
        }

        private void ConectarTipoEstriboReferenciaEnLongitudinal()
        {
            if (VentanaEstribos == null || VentanaEstribos.IsDisposed)
                return;

            try
            {
                if (VentanaEstribos.cmbTipoEstribo != null)
                {
                    VentanaEstribos.cmbTipoEstribo.SelectedIndexChanged -= CmbTipoEstriboReferencia_SelectedIndexChanged;
                    VentanaEstribos.cmbTipoEstribo.SelectedIndexChanged += CmbTipoEstriboReferencia_SelectedIndexChanged;
                }
            }
            catch
            {
                // No interrumpir si la versión de la ventana no expone el combo.
            }
        }

        private void CmbTipoEstriboReferencia_SelectedIndexChanged(object sender, EventArgs e)
        {
            SincronizarTipoEstriboReferenciaEnLongitudinal();
            RefrescarVistaPreviaGlobal();
        }

        private void SincronizarTipoEstriboReferenciaEnLongitudinal()
        {
            if (VentanaLongitudinal == null || VentanaLongitudinal.IsDisposed)
                return;

            RebarBarType tipoEstribo = null;

            try
            {
                if (VentanaEstribos != null &&
                    !VentanaEstribos.IsDisposed &&
                    VentanaEstribos.cmbTipoEstribo != null)
                {
                    tipoEstribo = VentanaEstribos.cmbTipoEstribo.SelectedItem as RebarBarType;
                }
            }
            catch
            {
                tipoEstribo = null;
            }

            // Primero intenta usar el método nuevo de la ventana longitudinal:
            // EstablecerTipoEstriboReferencia(RebarBarType tipoEstribo).
            try
            {
                System.Reflection.MethodInfo metodoTipo =
                    VentanaLongitudinal.GetType().GetMethod(
                        "EstablecerTipoEstriboReferencia",
                        System.Reflection.BindingFlags.Instance |
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.NonPublic);

                if (metodoTipo != null)
                {
                    metodoTipo.Invoke(VentanaLongitudinal, new object[] { tipoEstribo });
                    return;
                }
            }
            catch
            {
            }

            // Respaldo: si la ventana no tiene el método anterior, intenta pasarle
            // directamente el diámetro en pies con EstablecerDiametroEstriboReferencia(double).
            try
            {
                double diametroFt = ObtenerDiametroBarraFtDesdeMain(tipoEstribo);

                System.Reflection.MethodInfo metodoDiametro =
                    VentanaLongitudinal.GetType().GetMethod(
                        "EstablecerDiametroEstriboReferencia",
                        System.Reflection.BindingFlags.Instance |
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.NonPublic);

                if (metodoDiametro != null)
                    metodoDiametro.Invoke(VentanaLongitudinal, new object[] { diametroFt });
            }
            catch
            {
                // Si la ventana longitudinal aún no tiene esos métodos, no se rompe el MAIN.
            }
        }

        private double ObtenerDiametroBarraFtDesdeMain(RebarBarType tipo)
        {
            if (tipo == null)
                return 0.0;

            string[] nombresParametros =
            {
        "Diámetro de barra",
        "Diámetro de barra de modelo",
        "Bar Diameter",
        "Model Bar Diameter",
        "Nominal Diameter",
        "Diámetro nominal"
    };

            foreach (string nombre in nombresParametros)
            {
                try
                {
                    Parameter p = tipo.LookupParameter(nombre);

                    if (p == null)
                        continue;

                    if (p.StorageType == StorageType.Double)
                    {
                        double v = p.AsDouble();
                        if (v > 0.0)
                            return v;
                    }
                }
                catch
                {
                }
            }

            try
            {
                Parameter p = tipo.get_Parameter(BuiltInParameter.REBAR_BAR_DIAMETER);

                if (p != null && p.StorageType == StorageType.Double)
                {
                    double v = p.AsDouble();
                    if (v > 0.0)
                        return v;
                }
            }
            catch
            {
            }

            return 0.0;
        }

        private void ConectarEventoPreviewEstribosActualizadoSiExiste()
        {
            if (VentanaEstribos == null || VentanaEstribos.IsDisposed)
                return;

            try
            {
                System.Reflection.EventInfo evento =
                    VentanaEstribos.GetType().GetEvent(
                        "PreviewEstribosActualizado",
                        System.Reflection.BindingFlags.Instance |
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.NonPublic);

                if (evento == null)
                    return;

                System.Reflection.MethodInfo metodo =
                    this.GetType().GetMethod(
                        "VentanaEstribos_PreviewEstribosActualizado",
                        System.Reflection.BindingFlags.Instance |
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.NonPublic);

                if (metodo == null)
                    return;

                Delegate delegado = Delegate.CreateDelegate(
                    evento.EventHandlerType,
                    this,
                    metodo,
                    false);

                if (delegado == null)
                    return;

                try
                {
                    evento.RemoveEventHandler(VentanaEstribos, delegado);
                }
                catch
                {
                }

                evento.AddEventHandler(VentanaEstribos, delegado);
            }
            catch
            {
                // Compatibilidad: si la ventana de estribos no tiene ese evento
                // o el tipo del delegado no coincide, el MAIN sigue funcionando.
            }
        }

        private void SepararControl(WinForms.Control ctrl)
        {
            if (ctrl == null)
                return;

            if (ctrl.Parent != null)
                ctrl.Parent.Controls.Remove(ctrl);
        }

        // =====================================
        // MÉTODOS PUENTE
        // =====================================
        public void CargarTiposArmadura(List<RebarBarType> tipos)
        {
            tiposArmaduraEditorSeccion = tipos == null
                ? new List<RebarBarType>()
                : tipos.Where(x => x != null).OrderBy(x => x.Name).ToList();

            if (VentanaLongitudinal != null && !VentanaLongitudinal.IsDisposed)
                VentanaLongitudinal.CargarTiposArmadura(tipos);

            if (VentanaEstribos != null && !VentanaEstribos.IsDisposed)
                VentanaEstribos.CargarTiposArmadura(tipos);

            ReconstruirEditorSeccionIncrustadoSiVisible();
        }

        public void ActualizarCantidad(int cantidad)
        {
            if (VentanaLongitudinal != null && !VentanaLongitudinal.IsDisposed)
                VentanaLongitudinal.ActualizarCantidad(cantidad);
        }

        public void ActualizarVistaPrevia(
            double longitudTotalMm,
            List<AceroLongitudinalVigasForm.ColumnaPreview> columnas,
            string nombreViga)
        {
            if (VentanaLongitudinal != null && !VentanaLongitudinal.IsDisposed)
            {
                VentanaLongitudinal.ActualizarVistaPrevia(
                    longitudTotalMm,
                    columnas,
                    nombreViga);
            }

            if (VentanaEstribos != null && !VentanaEstribos.IsDisposed)
            {
                VentanaEstribos.ActualizarDesdeVentanaLongitudinal(VentanaLongitudinal);

                if (DetectarFormaGlobalAutomaticamente)
                    VentanaEstribos.RecalcularFormaAutomaticamenteDesdeMain();
            }

            if (VentanaSeleccionVigas != null && !VentanaSeleccionVigas.IsDisposed)
                VentanaSeleccionVigas.RefrescarVista3D();

            SincronizarFormaGlobalConVentanas();
            AjustarVistaPreviaFijaActual();
            RefrescarVistaPreviaGlobal();
        }

        public void ActualizarVistaPreviaMultiple(
            List<VigaLongitudinalPreview> vigas)
        {
            vigasPreviewGlobalActuales = vigas == null
                ? new List<VigaLongitudinalPreview>()
                : new List<VigaLongitudinalPreview>(vigas);

            if (VentanaLongitudinal != null && !VentanaLongitudinal.IsDisposed)
                VentanaLongitudinal.ActualizarVistaPreviaMultiple(vigas);

            if (VentanaEstribos != null && !VentanaEstribos.IsDisposed)
            {
                VentanaEstribos.CargarDesdeVigasPreview(vigas);

                if (DetectarFormaGlobalAutomaticamente)
                    VentanaEstribos.RecalcularFormaAutomaticamenteDesdeMain();
            }

            if (VentanaSeleccionVigas != null && !VentanaSeleccionVigas.IsDisposed)
                VentanaSeleccionVigas.RefrescarVista3D();

            if (DetectarFormaGlobalAutomaticamente)
            {
                if (SeccionActualTieneIndicadorCumbreraDesdePreview())
                    AplicarFormaGlobalDetectadaDesdeVentana(AceroEstribosVigasForm.TipoFormaEstribo.Cumbrera);
                else if (SeccionActualTieneCuatroLadosDesdePreview())
                    AplicarFormaGlobalDetectadaDesdeVentana(AceroEstribosVigasForm.TipoFormaEstribo.Rectangular);
            }

            SincronizarFormaGlobalConVentanas();
            AjustarVistaPreviaFijaActual();
            RefrescarVistaPreviaGlobal();
        }
    }

}
