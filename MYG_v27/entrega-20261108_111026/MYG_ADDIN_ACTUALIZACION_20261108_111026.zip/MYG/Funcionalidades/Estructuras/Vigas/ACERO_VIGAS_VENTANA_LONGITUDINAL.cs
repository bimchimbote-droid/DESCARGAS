﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using MYG_Addin;
using Drawing = System.Drawing;
using WinForms = System.Windows.Forms;


// =====================================
// VENTANA EMERGENTE 3.4 - ACERO LONGITUDINAL EN VIGAS
// =====================================
public class AceroLongitudinalVigasForm : WinForms.Form
{
    public WinForms.ComboBox cmbTipoSuperior;
    public WinForms.ComboBox cmbTipoInferior;
    public WinForms.ComboBox cmbTipoCentral;

    // CAPAS ADICIONALES DE ACERO LONGITUDINAL
    public WinForms.ComboBox cmbCapasSuperior;
    public WinForms.ComboBox cmbCapasInferior;

    public WinForms.ComboBox cmbTipoSuperiorCapa2;
    public WinForms.ComboBox cmbTipoSuperiorCapa3;
    public WinForms.ComboBox cmbTipoSuperiorCapa4;
    public WinForms.ComboBox cmbTipoInferiorCapa2;
    public WinForms.ComboBox cmbTipoInferiorCapa3;
    public WinForms.ComboBox cmbTipoInferiorCapa4;

    WinForms.TextBox txtCantidadSuperior;
    WinForms.TextBox txtCantidadInferior;
    WinForms.TextBox txtCantidadSuperiorCapa2;
    WinForms.TextBox txtCantidadSuperiorCapa3;
    WinForms.TextBox txtCantidadSuperiorCapa4;
    WinForms.TextBox txtCantidadInferiorCapa2;
    WinForms.TextBox txtCantidadInferiorCapa3;
    WinForms.TextBox txtCantidadInferiorCapa4;
    WinForms.TextBox txtRecubrimiento;

    // Separación libre cara a cara entre capas longitudinales.
    // Un solo valor controla capas superiores e inferiores.
    WinForms.TextBox txtSeparacionCapas;
    WinForms.Label lblSeparacionCapas;
    WinForms.Label lblAyudaSeparacionCapas;

    WinForms.CheckBox chkDetectarColumnas;
    WinForms.CheckBox chkAceroCentral;

    WinForms.CheckBox chkCrearEmpalmes;
    WinForms.TextBox txtLongitudEmpalme;
    WinForms.TextBox txtLongitudBarra;
    WinForms.Label lblLongitudEmpalme;
    WinForms.Label lblCmEmpalme;
    WinForms.Label lblLongitudBarra;
    WinForms.Label lblMBarra;

    // 🔥 NUEVO: CÁLCULO RNE DIFERENCIADO DE EMPALMES
    WinForms.CheckBox chkUsarRNE;
    WinForms.Button btnConfigRNE;
    WinForms.ComboBox cmbResistenciaRNE;
    WinForms.Label lblInfoRNE;
    private bool actualizandoRNE = false;

    // 🔥 CONFIGURACIÓN DEL CÁLCULO RNE
    private double rneFcKgCm2 = 210.0;
    private double rneFyMpa = 420.0;
    private double rnePsiE = 1.0;
    private double rneLambda = 1.0;
    private double rneFactorEmpalme = 1.30;
    private double rneMinEmpalmeMm = 300.0;
    private double rnePsiSuperior = 1.30;
    private double rnePsiInferior = 1.00;
    private double rnePsiCentral = 1.00;

    private double empalmeRNESuperiorCm = 0.0;
    private double empalmeRNEInferiorCm = 0.0;
    private double empalmeRNECentralCm = 0.0;

    WinForms.Label lblTipoCentral;
    WinForms.Label lblCantidadCentralFija;

    WinForms.Label lblCapasSuperior;
    WinForms.Label lblCapasInferior;
    WinForms.Label lblTipoSuperiorCapa2;
    WinForms.Label lblCantidadSuperiorCapa2;
    WinForms.Label lblTipoSuperiorCapa3;
    WinForms.Label lblCantidadSuperiorCapa3;
    WinForms.Label lblTipoSuperiorCapa4;
    WinForms.Label lblCantidadSuperiorCapa4;
    WinForms.Label lblTipoInferiorCapa2;
    WinForms.Label lblCantidadInferiorCapa2;
    WinForms.Label lblTipoInferiorCapa3;
    WinForms.Label lblCantidadInferiorCapa3;
    WinForms.Label lblTipoInferiorCapa4;
    WinForms.Label lblCantidadInferiorCapa4;

    WinForms.Label lblColorSuperior;
    WinForms.Label lblColorInferior;
    WinForms.Label lblColorCentral;

    WinForms.CheckBox chkGanchoInicio;
    WinForms.CheckBox chkGanchoFin;

    WinForms.TextBox txtLongitudGanchoInicio;
    WinForms.TextBox txtLongitudGanchoFin;

    WinForms.TextBox txtLongitudDesarrolloInicio;
    WinForms.TextBox txtLongitudDesarrolloFin;

    // CHECKS INDEPENDIENTES: desarrollo hasta el fondo del apoyo, descontando recubrimiento.
    WinForms.CheckBox chkDesarrolloAutomaticoInicio;
    WinForms.CheckBox chkDesarrolloAutomaticoFin;

    // Estos flags indican si existe una COLUMNA real en cada extremo de la serie.
    // Solo controlan la opción Auto. El ingreso manual siempre queda disponible.
    private bool desarrolloInicioDisponible = false;
    private bool desarrolloFinDisponible = false;

    // Ancho real de la columna proyectado sobre el eje de la viga.
    // Se recibe desde SeleccionarVigasAceroLongitudinalHandler sin dibujar
    // la columna en la vista 2D ni agregarla a la vista 3D.
    private double anchoColumnaAutoInicioMm = 0.0;
    private double anchoColumnaAutoFinMm = 0.0;

    WinForms.Label lblLongitudGanchoInicio;
    WinForms.Label lblLongitudGanchoFin;
    WinForms.Label lblCmGanchoInicio;
    WinForms.Label lblCmGanchoFin;

    WinForms.Label lblLongitudDesarrolloInicio;
    WinForms.Label lblLongitudDesarrolloFin;
    WinForms.Label lblCmDesarrolloInicio;
    WinForms.Label lblCmDesarrolloFin;

    WinForms.Label lblEstadoInicio;
    WinForms.Label lblEstadoFin;

    WinForms.Label lblCantidad;
    WinForms.Label lblVistaInfo;

    WinForms.CheckBox chkGraficarEstribosCreados;

    WinForms.Panel panelPreview;

    // Controles principales conservados como campos para integrar el editor
    // dentro de esta misma pestaña sin SplitContainer ni ventana adicional.
    private WinForms.GroupBox grpParametrosPrincipal;
    private WinForms.GroupBox grpExtremosLongitudinalesPrincipal;
    private WinForms.GroupBox grpExtremoInicioPrincipal;
    private WinForms.GroupBox grpExtremoFinPrincipal;
    private WinForms.GroupBox grpPreviewLocal;
    private WinForms.Label lblTituloPrincipal;
    private WinForms.Label lblDescripcionPrincipal;
    private WinForms.Panel panelConfiguracionUnificada;
    private WinForms.Panel panelEditorSeccionIntegrado;
    private WinForms.Panel panelHerramientasEditorUnificado;
    private WinForms.Panel barraEdicionEditorUnificada;
    private AceroVigaEditorSeccionForm editorSeccionIntegrado;
    // V11.2 - XML del diseño completo pendiente de aplicar cuando todavía no
    // existe una sección real cargada en el editor incrustado.
    private string disenoSeccionPersistentePendienteXmlMYG = string.Empty;
    private WinForms.Label lblEditorSinGeometriaIntegrado;
    private RebarBarType tipoEstriboEditorReferencia;
    private readonly bool usarEditorManualUnificadoV5 = true;

    // V8 - formato visual equivalente al módulo de columnas.
    private WinForms.Panel panelFormatoColumnasV8Longitudinal;
    private WinForms.CheckBox chkCrearLongitudinalesV8;
    private WinForms.Button btnAplicarTipoV8;
    private WinForms.Label lblAyudaFormatoV8Longitudinal;

    // =========================================================
    // V11.20 - MODO ALTERNO POR ESTACIONES
    // =========================================================
    // CONTINUO conserva exactamente el comportamiento actual del add-in.
    // INTERMEDIO permite una cantidad distinta por tramo.
    // AVANZADO permite cantidades diferentes en zona izquierda, centro y
    // derecha de cada tramo. La ejecución resuelve automáticamente barras
    // continuas + refuerzos adicionales sin modificar el diseño de sección base.
    public enum ModoDistribucionLongitudinalMYG
    {
        Continuo = 0,
        EstacionesIntermedio = 1,
        EstacionesAvanzado = 2
    }

    public sealed class FilaConfiguracionEstacionMYG
    {
        public int TramoIndice { get; set; }
        public string GrupoId { get; set; }

        // Si tiene valor, esta fila representa una barra dibujada individualmente
        // en la sección principal. GrupoId usa una clave sintética estable para
        // poder reutilizar el mismo motor por estaciones.
        public string BarraIndividualId { get; set; }

        public string CapaEtiqueta { get; set; }
        public int CantidadMaxima { get; set; }
        public int CantidadIzquierda { get; set; }
        public int CantidadCentro { get; set; }
        public int CantidadDerecha { get; set; }

        // V11.23 - selección exacta por posición.
        // El índice corresponde al orden real de las barras dentro del grupo
        // distribuido. Esto permite quitar/agregar CUALQUIER barra con un clic,
        // no solamente reducir la cantidad de forma simétrica.
        public List<int> IndicesActivosIzquierda { get; set; } =
            new List<int>();
        public List<int> IndicesActivosCentro { get; set; } =
            new List<int>();
        public List<int> IndicesActivosDerecha { get; set; } =
            new List<int>();

        // Mantiene compatibilidad con configuraciones creadas antes de V11.23.
        // Si es false, los índices se reconstruyen desde la cantidad guardada.
        public bool SeleccionExplicitaIzquierda { get; set; }
        public bool SeleccionExplicitaCentro { get; set; }
        public bool SeleccionExplicitaDerecha { get; set; }

        public FilaConfiguracionEstacionMYG Copiar()
        {
            return new FilaConfiguracionEstacionMYG
            {
                TramoIndice = TramoIndice,
                GrupoId = GrupoId ?? string.Empty,
                BarraIndividualId = BarraIndividualId ?? string.Empty,
                CapaEtiqueta = CapaEtiqueta ?? string.Empty,
                CantidadMaxima = CantidadMaxima,
                CantidadIzquierda = CantidadIzquierda,
                CantidadCentro = CantidadCentro,
                CantidadDerecha = CantidadDerecha,
                IndicesActivosIzquierda = IndicesActivosIzquierda != null
                    ? new List<int>(IndicesActivosIzquierda)
                    : new List<int>(),
                IndicesActivosCentro = IndicesActivosCentro != null
                    ? new List<int>(IndicesActivosCentro)
                    : new List<int>(),
                IndicesActivosDerecha = IndicesActivosDerecha != null
                    ? new List<int>(IndicesActivosDerecha)
                    : new List<int>(),
                SeleccionExplicitaIzquierda = SeleccionExplicitaIzquierda,
                SeleccionExplicitaCentro = SeleccionExplicitaCentro,
                SeleccionExplicitaDerecha = SeleccionExplicitaDerecha
            };
        }
    }


    // =========================================================
    // V11.41 - CLASIFICACIÓN ESPECIAL BASTÓN / BALANCÍN POR TRAMO
    // =========================================================
    // La clasificación se guarda por TRAMO + GrupoId + índice exacto de barra.
    // Esto evita que al marcar una posición como BASTÓN/BALANCÍN en T1 se
    // marque automáticamente la misma posición en T2, T3, etc.
    public sealed class ClasificacionEspecialBarraMYG
    {
        public int TramoIndice { get; set; }
        public string GrupoId { get; set; }
        public List<int> IndicesBaston { get; set; } = new List<int>();
        public List<int> IndicesBalancin { get; set; } = new List<int>();

        public ClasificacionEspecialBarraMYG Copiar()
        {
            return new ClasificacionEspecialBarraMYG
            {
                TramoIndice = TramoIndice,
                GrupoId = GrupoId ?? string.Empty,
                IndicesBaston = IndicesBaston != null
                    ? new List<int>(IndicesBaston)
                    : new List<int>(),
                IndicesBalancin = IndicesBalancin != null
                    ? new List<int>(IndicesBalancin)
                    : new List<int>()
            };
        }
    }

    private sealed class BarraHitEstacionEspecialMYG
    {
        public FilaConfiguracionEstacionMYG Fila;
        public int Indice;
        public string GrupoId;
    }

    private readonly List<ClasificacionEspecialBarraMYG>
        clasificacionesEspecialesLongitudinalMYG =
            new List<ClasificacionEspecialBarraMYG>();

    private WinForms.ComboBox cmbModoDistribucionEstacionesMYG;
    private WinForms.Button btnConfigurarEstacionesMYG;
    private WinForms.Form ventanaConfiguracionEstacionesMYG;
    private WinForms.Button btnInvertirVistaPreviaMYG;
    private WinForms.Label lblModoDistribucionEstacionesMYG;
    private bool previewInvertirHorizontalMYG = false;
    private readonly List<FilaConfiguracionEstacionMYG>
        configuracionEstacionesLongitudinalMYG =
            new List<FilaConfiguracionEstacionMYG>();
    private double extensionCambiosEstacionesCmMYG = 60.0;

    // =========================================================
    // V11.32 - DESARROLLO DE CORTE POR DIÁMETRO
    // =========================================================
    // Cuando una barra deja de existir en la región/tramo siguiente, su extremo
    // se prolonga esta longitud dentro de la zona siguiente. La clave se guarda
    // en centésimas de mm para evitar usar double como clave persistente.
    private readonly Dictionary<int, double> desarrollosCortePorDiametroCmMYG =
        new Dictionary<int, double>();

    public sealed class DesarrolloDiametroPersistenteMYG
    {
        public int ClaveDiametro { get; set; }
        public double DiametroMm { get; set; }
        public string Etiqueta { get; set; }
        public double DesarrolloCm { get; set; }

        public DesarrolloDiametroPersistenteMYG()
        {
            Etiqueta = string.Empty;
        }
    }

    public sealed class EstadoLongitudinalAvanzadoPersistenteMYG
    {
        public int Version { get; set; }
        public int ModoDistribucion { get; set; }
        public bool VistaPreviaMirror { get; set; }
        public double ExtensionAlAparecerCm { get; set; }
        public List<DesarrolloDiametroPersistenteMYG> DesarrollosPorDiametro { get; set; }
        public List<FilaConfiguracionEstacionMYG> FilasEstaciones { get; set; }

        // V11.39 - clasificación exacta de barras especiales POR TRAMO.
        public List<ClasificacionEspecialBarraMYG> ClasificacionesEspeciales { get; set; }

        public EstadoLongitudinalAvanzadoPersistenteMYG()
        {
            Version = 3;
            ExtensionAlAparecerCm = 60.0;
            DesarrollosPorDiametro = new List<DesarrolloDiametroPersistenteMYG>();
            FilasEstaciones = new List<FilaConfiguracionEstacionMYG>();
            ClasificacionesEspeciales = new List<ClasificacionEspecialBarraMYG>();
        }
    }

    public ModoDistribucionLongitudinalMYG ModoDistribucionLongitudinalActualMYG
    {
        get
        {
            if (cmbModoDistribucionEstacionesMYG == null ||
                cmbModoDistribucionEstacionesMYG.SelectedIndex <= 0)
            {
                return ModoDistribucionLongitudinalMYG.Continuo;
            }

            return cmbModoDistribucionEstacionesMYG.SelectedIndex == 1
                ? ModoDistribucionLongitudinalMYG.EstacionesIntermedio
                : ModoDistribucionLongitudinalMYG.EstacionesAvanzado;
        }
    }

    public double ExtensionCambiosEstacionesCmMYG
    {
        get { return Math.Max(0.0, extensionCambiosEstacionesCmMYG); }
    }

    private int ObtenerClaveDiametroDesarrolloMYG(double diametroMm)
    {
        if (double.IsNaN(diametroMm) || double.IsInfinity(diametroMm) || diametroMm <= 0.0)
            return 0;

        return (int)Math.Round(diametroMm * 100.0);
    }

    public double ObtenerDesarrolloCortePorDiametroCmMYG(RebarBarType tipoBarra)
    {
        double diametroMm = ObtenerDiametroBarraMm(tipoBarra);
        int clave = ObtenerClaveDiametroDesarrolloMYG(diametroMm);
        double valor;

        if (clave > 0 && desarrollosCortePorDiametroCmMYG.TryGetValue(clave, out valor) &&
            valor >= 0.0 && !double.IsNaN(valor) && !double.IsInfinity(valor))
        {
            return valor;
        }

        // Compatibilidad: si todavía no se configuró ese diámetro, usa el
        // valor que antes se aplicaba globalmente en los cambios.
        return ExtensionCambiosEstacionesCmMYG;
    }

    private bool TryConvertirDesarrolloTextoACmMYG(string texto, out double valorCm)
    {
        valorCm = 0.0;
        if (string.IsNullOrWhiteSpace(texto))
            return false;

        string t = texto.Trim().ToLowerInvariant().Replace(",", ".")
            .Replace("pulgadas", "in")
            .Replace("pulgada", "in")
            .Replace("pulg", "in")
            .Replace("inches", "in")
            .Replace("inch", "in");

        double factorCm = 1.0; // sin unidad = cm
        string numero = t;

        if (t.EndsWith("mm"))
        {
            factorCm = 0.1;
            numero = t.Substring(0, t.Length - 2);
        }
        else if (t.EndsWith("cm"))
        {
            factorCm = 1.0;
            numero = t.Substring(0, t.Length - 2);
        }
        else if (t.EndsWith("in"))
        {
            factorCm = 2.54;
            numero = t.Substring(0, t.Length - 2);
        }
        else if (t.EndsWith("\""))
        {
            factorCm = 2.54;
            numero = t.Substring(0, t.Length - 1);
        }
        else if (t.EndsWith("ft"))
        {
            factorCm = 30.48;
            numero = t.Substring(0, t.Length - 2);
        }
        else if (t.EndsWith("'"))
        {
            factorCm = 30.48;
            numero = t.Substring(0, t.Length - 1);
        }
        else if (t.EndsWith("m"))
        {
            factorCm = 100.0;
            numero = t.Substring(0, t.Length - 1);
        }

        double valor;
        if (!double.TryParse(numero.Trim(),
                System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture,
                out valor) ||
            valor < 0.0 || double.IsNaN(valor) || double.IsInfinity(valor))
        {
            return false;
        }

        valorCm = valor * factorCm;
        return valorCm >= 0.0;
    }

    private string ObtenerEtiquetaDiametroDesarrolloMYG(RebarBarType tipo, double diametroMm)
    {
        string nombre = tipo != null ? (tipo.Name ?? string.Empty).Trim() : string.Empty;
        string mm = diametroMm.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture);

        if (!string.IsNullOrWhiteSpace(nombre))
            return nombre + "  (Ø " + mm + " mm)";

        return "Ø " + mm + " mm";
    }

    private void AsegurarDesarrollosPorDiametroDesdeDisenoMYG(
        AceroVigaDisenoSeccion diseno,
        Dictionary<int, double> destino)
    {
        if (destino == null || diseno == null || diseno.Longitudinales == null)
            return;

        foreach (AceroVigaBarraLongitudinal2D barra in diseno.Longitudinales
            .Where(b => b != null && b.TipoBarra != null))
        {
            double dbMm = ObtenerDiametroBarraMm(barra.TipoBarra);
            int clave = ObtenerClaveDiametroDesarrolloMYG(dbMm);
            if (clave <= 0 || destino.ContainsKey(clave))
                continue;

            double existente;
            if (desarrollosCortePorDiametroCmMYG.TryGetValue(clave, out existente))
                destino[clave] = Math.Max(0.0, existente);
            else
                destino[clave] = ExtensionCambiosEstacionesCmMYG;
        }
    }

    public string ExportarEstadoLongitudinalAvanzadoPersistenteMYG()
    {
        try
        {
            SincronizarConfiguracionEstacionesConModeloMYG();

            EstadoLongitudinalAvanzadoPersistenteMYG estado =
                new EstadoLongitudinalAvanzadoPersistenteMYG();
            estado.Version = 3;
            estado.ModoDistribucion = (int)ModoDistribucionLongitudinalActualMYG;
            estado.VistaPreviaMirror = previewInvertirHorizontalMYG;
            estado.ExtensionAlAparecerCm = ExtensionCambiosEstacionesCmMYG;
            estado.FilasEstaciones = configuracionEstacionesLongitudinalMYG
                .Where(f => f != null)
                .Select(f => f.Copiar())
                .ToList();
            estado.ClasificacionesEspeciales =
                clasificacionesEspecialesLongitudinalMYG
                    .Where(c => c != null && !string.IsNullOrWhiteSpace(c.GrupoId))
                    .Select(c => c.Copiar())
                    .ToList();

            foreach (KeyValuePair<int, double> par in desarrollosCortePorDiametroCmMYG
                .OrderBy(x => x.Key))
            {
                estado.DesarrollosPorDiametro.Add(
                    new DesarrolloDiametroPersistenteMYG
                    {
                        ClaveDiametro = par.Key,
                        DiametroMm = par.Key / 100.0,
                        DesarrolloCm = Math.Max(0.0, par.Value),
                        Etiqueta = string.Empty
                    });
            }

            System.Xml.Serialization.XmlSerializer serializador =
                new System.Xml.Serialization.XmlSerializer(
                    typeof(EstadoLongitudinalAvanzadoPersistenteMYG));

            System.Xml.XmlWriterSettings ajustes = new System.Xml.XmlWriterSettings
            {
                OmitXmlDeclaration = true,
                Indent = false
            };

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            using (System.Xml.XmlWriter xw = System.Xml.XmlWriter.Create(sb, ajustes))
                serializador.Serialize(xw, estado);

            return sb.ToString();
        }
        catch
        {
            return string.Empty;
        }
    }

    public bool ImportarEstadoLongitudinalAvanzadoPersistenteMYG(
        string contenidoXml,
        out string mensajeError)
    {
        mensajeError = string.Empty;
        if (string.IsNullOrWhiteSpace(contenidoXml))
            return true;

        try
        {
            System.Xml.Serialization.XmlSerializer serializador =
                new System.Xml.Serialization.XmlSerializer(
                    typeof(EstadoLongitudinalAvanzadoPersistenteMYG));

            EstadoLongitudinalAvanzadoPersistenteMYG estado;
            using (System.IO.StringReader sr = new System.IO.StringReader(contenidoXml))
            {
                estado = serializador.Deserialize(sr)
                    as EstadoLongitudinalAvanzadoPersistenteMYG;
            }

            if (estado == null)
                throw new InvalidOperationException("El estado longitudinal avanzado no es válido.");

            extensionCambiosEstacionesCmMYG = Math.Max(0.0, estado.ExtensionAlAparecerCm);
            previewInvertirHorizontalMYG = estado.VistaPreviaMirror;

            desarrollosCortePorDiametroCmMYG.Clear();
            if (estado.DesarrollosPorDiametro != null)
            {
                foreach (DesarrolloDiametroPersistenteMYG d in estado.DesarrollosPorDiametro)
                {
                    if (d == null) continue;
                    int clave = d.ClaveDiametro > 0
                        ? d.ClaveDiametro
                        : ObtenerClaveDiametroDesarrolloMYG(d.DiametroMm);
                    if (clave > 0)
                        desarrollosCortePorDiametroCmMYG[clave] = Math.Max(0.0, d.DesarrolloCm);
                }
            }

            configuracionEstacionesLongitudinalMYG.Clear();
            if (estado.FilasEstaciones != null)
            {
                configuracionEstacionesLongitudinalMYG.AddRange(
                    estado.FilasEstaciones
                        .Where(f => f != null)
                        .Select(f => f.Copiar()));
            }

            clasificacionesEspecialesLongitudinalMYG.Clear();
            if (estado.ClasificacionesEspeciales != null)
            {
                clasificacionesEspecialesLongitudinalMYG.AddRange(
                    estado.ClasificacionesEspeciales
                        .Where(c => c != null && !string.IsNullOrWhiteSpace(c.GrupoId))
                        .Select(c => c.Copiar()));
            }

            if (cmbModoDistribucionEstacionesMYG != null)
            {
                int indice = Math.Max(0, Math.Min(2, estado.ModoDistribucion));
                cmbModoDistribucionEstacionesMYG.SelectedIndex = indice;
            }

            SincronizarConfiguracionEstacionesConModeloMYG();

            if (btnInvertirVistaPreviaMYG != null)
            {
                btnInvertirVistaPreviaMYG.Text = "MIRROR";
                btnInvertirVistaPreviaMYG.BackColor = previewInvertirHorizontalMYG
                    ? Drawing.Color.FromArgb(225, 238, 250)
                    : Drawing.Color.White;
            }

            RefrescarPreviewLongitudinalEnTiempoReal();
            return true;
        }
        catch (Exception ex)
        {
            mensajeError = ex.Message;
            return false;
        }
    }

    // V11.27 MYG - solo cambia la orientación VISUAL de la elevación previa.
    // No invierte la serie lógica, no intercambia desarrollos y no modifica
    // la geometría que posteriormente se crea en Revit.
    public bool VistaPreviaInvertidaHorizontalMYG
    {
        get { return previewInvertirHorizontalMYG; }
    }

    private double AjustarParametroHorizontalPreviewMYG(double t)
    {
        if (t < 0.0) t = 0.0;
        if (t > 1.0) t = 1.0;

        return previewInvertirHorizontalMYG
            ? 1.0 - t
            : t;
    }

    public List<FilaConfiguracionEstacionMYG>
        ObtenerConfiguracionEstacionesLongitudinalMYG()
    {
        SincronizarConfiguracionEstacionesConModeloMYG();
        return configuracionEstacionesLongitudinalMYG
            .Where(x => x != null)
            .Select(x => x.Copiar())
            .ToList();
    }


    public List<int> ObtenerIndicesBastonGrupoTramoMYG(
        string grupoId,
        int tramoIndice)
    {
        if (string.IsNullOrWhiteSpace(grupoId) || tramoIndice < 0)
            return new List<int>();

        ClasificacionEspecialBarraMYG c =
            clasificacionesEspecialesLongitudinalMYG.FirstOrDefault(x =>
                x != null &&
                x.TramoIndice == tramoIndice &&
                string.Equals(x.GrupoId, grupoId, StringComparison.Ordinal));

        return c != null && c.IndicesBaston != null
            ? c.IndicesBaston.Where(i => i >= 0).Distinct().OrderBy(i => i).ToList()
            : new List<int>();
    }

    public List<int> ObtenerIndicesBalancinGrupoTramoMYG(
        string grupoId,
        int tramoIndice)
    {
        if (string.IsNullOrWhiteSpace(grupoId) || tramoIndice < 0)
            return new List<int>();

        ClasificacionEspecialBarraMYG c =
            clasificacionesEspecialesLongitudinalMYG.FirstOrDefault(x =>
                x != null &&
                x.TramoIndice == tramoIndice &&
                string.Equals(x.GrupoId, grupoId, StringComparison.Ordinal));

        return c != null && c.IndicesBalancin != null
            ? c.IndicesBalancin.Where(i => i >= 0).Distinct().OrderBy(i => i).ToList()
            : new List<int>();
    }

    // Compatibilidad interna: devuelve la unión de todos los tramos.
    // La ejecución V11.39 usa siempre los métodos POR TRAMO de arriba.
    public List<int> ObtenerIndicesBastonGrupoMYG(string grupoId)
    {
        if (string.IsNullOrWhiteSpace(grupoId))
            return new List<int>();

        return clasificacionesEspecialesLongitudinalMYG
            .Where(x =>
                x != null &&
                string.Equals(x.GrupoId, grupoId, StringComparison.Ordinal) &&
                x.IndicesBaston != null)
            .SelectMany(x => x.IndicesBaston)
            .Where(i => i >= 0)
            .Distinct()
            .OrderBy(i => i)
            .ToList();
    }

    public List<int> ObtenerIndicesBalancinGrupoMYG(string grupoId)
    {
        if (string.IsNullOrWhiteSpace(grupoId))
            return new List<int>();

        return clasificacionesEspecialesLongitudinalMYG
            .Where(x =>
                x != null &&
                string.Equals(x.GrupoId, grupoId, StringComparison.Ordinal) &&
                x.IndicesBalancin != null)
            .SelectMany(x => x.IndicesBalancin)
            .Where(i => i >= 0)
            .Distinct()
            .OrderBy(i => i)
            .ToList();
    }

    private Dictionary<int, List<Tuple<double, int>>> previewEstribosCreados =
        null;

    public WinForms.Button btnSeleccionarVigas;
    public WinForms.Button btnEjecutar;

    public ExternalEvent SeleccionarEvent;
    public ExternalEvent EjecutarEvent;

    private List<VigaLongitudinalPreview> previewVigas =
        new List<VigaLongitudinalPreview>();

    // Evento para que el MAIN actualice instantáneamente el selector global
    // y la vista 3D cuando el handler de selección cambie las vigas.
    public event Action<List<VigaLongitudinalPreview>> PreviewVigasActualizadas;

    // Evento exclusivo para cambios de parámetros de acero longitudinal.
    // No recarga geometría ni tramos; solo avisa al MAIN para redibujar
    // la vista preliminar global en tiempo real.
    public event Action PreviewLongitudinalParametrosActualizados;

    // =========================================================
    // REFERENCIA DEL ESTRIBO PARA UBICAR ACEROS LONGITUDINALES
    // =========================================================
    // El handler longitudinal usa este diámetro para ubicar el centro de las barras:
    // offset sección = recubrimiento + diámetro del estribo + radio de la barra longitudinal.
    private double diametroEstriboReferenciaFt = 0.0;

    public double DiametroEstriboReferenciaFt
    {
        get { return diametroEstriboReferenciaFt; }
    }

    public void EstablecerDiametroEstriboReferencia(double diametroFt)
    {
        if (double.IsNaN(diametroFt) || double.IsInfinity(diametroFt) || diametroFt < 0.0)
            diametroFt = 0.0;

        if (Math.Abs(diametroEstriboReferenciaFt - diametroFt) <= 1e-9)
            return;

        diametroEstriboReferenciaFt = diametroFt;
        RefrescarPreviewLongitudinalEnTiempoReal();
    }

    public void EstablecerTipoEstriboReferencia(RebarBarType tipoEstribo)
    {
        EstablecerDiametroEstriboReferencia(
            ObtenerDiametroBarraReferenciaFt(tipoEstribo));
    }

    private double ObtenerDiametroBarraReferenciaFt(RebarBarType tipo)
    {
        if (tipo == null)
            return 0.0;

        try
        {
            Parameter pDiam = tipo.get_Parameter(BuiltInParameter.REBAR_BAR_DIAMETER);
            if (pDiam != null && pDiam.StorageType == StorageType.Double)
            {
                double d = pDiam.AsDouble();
                if (d > 0.0)
                    return d;
            }
        }
        catch
        {
        }

        string[] nombres = new string[]
        {
                "Diámetro de barra",
                "Diámetro de barra de modelo",
                "Bar Diameter",
                "Model Bar Diameter"
        };

        foreach (string nombre in nombres)
        {
            try
            {
                Parameter p = tipo.LookupParameter(nombre);
                if (p != null && p.StorageType == StorageType.Double)
                {
                    double d = p.AsDouble();
                    if (d > 0.0)
                        return d;
                }
            }
            catch
            {
            }
        }

        return 0.0;
    }


    // =========================================================
    // MODELO COMPARTIDO SEGURO PARA EL HANDLER
    // =========================================================
    // Esta versión NO cambia el dibujo original de la ventana.
    // Solo expone un modelo lógico estable para que el handler pueda
    // consultarlo sin que la vista preliminar se deforme con puntos
    // crudos del sólido.
    public ModeloAceroLongitudinalPreview ModeloPreviewActual { get; private set; }

    public class PuntoRutaAceroPreview
    {
        public double XMm { get; set; }
        public double ZMm { get; set; }

        public PuntoRutaAceroPreview()
        {
            XMm = 0.0;
            ZMm = 0.0;
        }

        public PuntoRutaAceroPreview(double xMm, double zMm)
        {
            XMm = xMm;
            ZMm = zMm;
        }
    }

    public class SegmentoRutaAceroPreview
    {
        public double StartMm { get; set; }
        public double EndMm { get; set; }
        public bool EsEmpalme { get; set; }
        public bool UsaPerfilVariable { get; set; }
        public List<PuntoRutaAceroPreview> Puntos { get; set; }

        public SegmentoRutaAceroPreview()
        {
            StartMm = 0.0;
            EndMm = 0.0;
            EsEmpalme = false;
            UsaPerfilVariable = false;
            Puntos = new List<PuntoRutaAceroPreview>();
        }
    }

    public class RutaAceroLongitudinalPreview
    {
        public string Grupo { get; set; }
        public int TipoRuta { get; set; } // 1 superior, -1 inferior, 0 central.
        public bool Activa { get; set; }
        public double RecubrimientoMm { get; set; }
        public double OffsetNormalPreviewPx { get; set; }
        public List<SegmentoRutaAceroPreview> Segmentos { get; set; }

        public RutaAceroLongitudinalPreview()
        {
            Grupo = "";
            TipoRuta = 0;
            Activa = true;
            RecubrimientoMm = 0.0;
            OffsetNormalPreviewPx = 0.0;
            Segmentos = new List<SegmentoRutaAceroPreview>();
        }
    }

    public class ModeloAceroLongitudinalPreview
    {
        public bool Valido { get; set; }
        public double StartGlobalMm { get; set; }
        public double EndGlobalMm { get; set; }
        public double XBarraInicioMm { get; set; }
        public double XBarraFinMm { get; set; }
        public double RecubrimientoMm { get; set; }
        public bool CrearEmpalmes { get; set; }
        public double LongitudBarraMm { get; set; }
        public double LongitudEmpalmeSuperiorMm { get; set; }
        public double LongitudEmpalmeInferiorMm { get; set; }
        public double LongitudEmpalmeCentralMm { get; set; }
        public bool GanchoInicio { get; set; }
        public bool GanchoFin { get; set; }
        public double LongitudGanchoInicioMm { get; set; }
        public double LongitudGanchoFinMm { get; set; }
        public bool TienePerfilVariable { get; set; }
        public List<RutaAceroLongitudinalPreview> Rutas { get; set; }

        public ModeloAceroLongitudinalPreview()
        {
            Valido = false;
            StartGlobalMm = 0.0;
            EndGlobalMm = 0.0;
            XBarraInicioMm = 0.0;
            XBarraFinMm = 0.0;
            RecubrimientoMm = 0.0;
            CrearEmpalmes = false;
            LongitudBarraMm = 0.0;
            LongitudEmpalmeSuperiorMm = 0.0;
            LongitudEmpalmeInferiorMm = 0.0;
            LongitudEmpalmeCentralMm = 0.0;
            GanchoInicio = false;
            GanchoFin = false;
            LongitudGanchoInicioMm = 0.0;
            LongitudGanchoFinMm = 0.0;
            TienePerfilVariable = false;
            Rutas = new List<RutaAceroLongitudinalPreview>();
        }
    }

    private readonly Drawing.Color ColorAceroSuperior = Drawing.Color.FromArgb(0, 90, 200);
    private readonly Drawing.Color ColorAceroInferior = Drawing.Color.FromArgb(220, 120, 0);
    private readonly Drawing.Color ColorAceroCentral = Drawing.Color.FromArgb(0, 150, 70);

    // 🔴 COLOR SOLO PARA RESALTAR LA ZONA DE EMPALME EN LA VISTA PRELIMINAR
    private readonly Drawing.Color ColorEmpalmePreview = Drawing.Color.FromArgb(220, 45, 45);

    // =========================================================
    // COMPATIBILIDAD CON PESTAÑAS EXTERNAS / ESTRIBOS
    // =========================================================
    // IMPORTANTE:
    // Se agregan estos campos sin alterar la lógica original del dibujo.
    // Por defecto la ventana longitudinal se comporta igual que tu código original.
    public bool MostrarAcerosEnVistaPreliminar { get; set; } = true;

    private bool previewForzarLongitudinalesGris = false;
    private bool previewUsarAreaExterna = false;
    private Drawing.Rectangle previewAreaExterna = Drawing.Rectangle.Empty;
    private Dictionary<int, List<Tuple<double, int>>> previewEstribosExterno = null;

    // Se usa desde la pestaña Estribos para resaltar el tramo seleccionado
    // sin crear líneas adicionales fuera de la geometría original.
    private int previewTramoEstribosResaltado = -1;

    // =========================================================
    // NAVEGACIÓN 2D DE VISTA PRELIMINAR
    // Pan: arrastrar mouse izquierdo o rueda presionada.
    // Zoom: scroll del mouse.
    // Reset: doble click.
    // =========================================================
    private float previewZoom2D = 1.0f;
    private float previewPanX2D = 0.0f;
    private float previewPanY2D = 0.0f;
    private bool previewPanActivo2D = false;
    private Drawing.Point previewPanUltimoPunto2D = Drawing.Point.Empty;
    private const float PREVIEW_ZOOM_2D_MIN = 0.05f;
    private const float PREVIEW_ZOOM_2D_MAX = 40.0f;

    public class ColumnaPreview
    {
        public double CentroMm { get; set; }
        public double AnchoMm { get; set; }
        public string Nombre { get; set; }

        public ColumnaPreview(double centroMm, double anchoMm, string nombre)
        {
            CentroMm = centroMm;
            AnchoMm = anchoMm;
            Nombre = nombre;
        }
    }

    private class ColumnaCajaPreview
    {
        public double LeftMm { get; set; }
        public double RightMm { get; set; }

        public double WidthMm
        {
            get { return RightMm - LeftMm; }
        }

        public double CenterMm
        {
            get { return (LeftMm + RightMm) / 2.0; }
        }

        public ColumnaCajaPreview(double leftMm, double rightMm)
        {
            LeftMm = leftMm;
            RightMm = rightMm;
        }
    }

    private class IntervaloColumnaLocal
    {
        public double LeftFaceMm { get; set; }
        public double RightFaceMm { get; set; }
        public double AnchoMm { get; set; }
        public string Nombre { get; set; }

        public double CenterMm
        {
            get { return (LeftFaceMm + RightFaceMm) / 2.0; }
        }

        public IntervaloColumnaLocal(
            double leftFaceMm,
            double rightFaceMm,
            double anchoMm,
            string nombre)
        {
            LeftFaceMm = leftFaceMm;
            RightFaceMm = rightFaceMm;
            AnchoMm = anchoMm;
            Nombre = nombre;
        }
    }

    private class TramoVigaSeriePreview
    {
        public double StartMm { get; set; }
        public double EndMm { get; set; }
        public double AnguloGrados { get; set; }

        // V11.30 MYG - Marca de tipo del armazón estructural que originó
        // este tramo. Se usa únicamente para identificación visual.
        public string MarcaTipo { get; set; }

        // PERFIL LIMPIO DE SECCIÓN VARIABLE PARA VISTA PRELIMINAR.
        // Son valores de Z local en mm, solo inicio/fin del tramo.
        public bool TienePerfilSeccionVariable { get; set; }
        public double ZSuperiorInicioMm { get; set; }
        public double ZSuperiorFinMm { get; set; }
        public double ZInferiorInicioMm { get; set; }
        public double ZInferiorFinMm { get; set; }

        public double LengthMm
        {
            get { return EndMm - StartMm; }
        }

        public TramoVigaSeriePreview(double startMm, double endMm, double anguloGrados)
        {
            StartMm = startMm;
            EndMm = endMm;
            AnguloGrados = anguloGrados;
            MarcaTipo = string.Empty;

            TienePerfilSeccionVariable = false;
            ZSuperiorInicioMm = 0.0;
            ZSuperiorFinMm = 0.0;
            ZInferiorInicioMm = 0.0;
            ZInferiorFinMm = 0.0;
        }
    }

    private class TramoDibujoPreview
    {
        public TramoVigaSeriePreview Tramo { get; set; }
        public Drawing.PointF P0 { get; set; }
        public Drawing.PointF P1 { get; set; }
        public Drawing.PointF Normal { get; set; }
    }

    // 🔥 NUEVO: eje continuo de dibujo, incluye columnas/nodos y voladizos.
    private class EjeDibujoPreview
    {
        public double StartMm { get; set; }
        public double EndMm { get; set; }
        public Drawing.PointF P0 { get; set; }
        public Drawing.PointF P1 { get; set; }
        public Drawing.PointF Normal { get; set; }
    }

    private class SegmentoCotaPreview
    {
        public double StartMm { get; set; }
        public double EndMm { get; set; }

        public double LengthMm
        {
            get { return EndMm - StartMm; }
        }

        public SegmentoCotaPreview(double startMm, double endMm)
        {
            StartMm = startMm;
            EndMm = endMm;
        }
    }

    private class SerieContinuaPreview
    {
        public double LongitudVigasMm { get; set; }
        public double MinMm { get; set; }
        public double MaxMm { get; set; }

        public bool TieneColumnaInicioSerie { get; set; }
        public bool TieneColumnaFinSerie { get; set; }

        public List<TramoVigaSeriePreview> TramosViga { get; set; }
        public List<ColumnaCajaPreview> Columnas { get; set; }
        public List<SegmentoCotaPreview> SegmentosCota { get; set; }

        public SerieContinuaPreview()
        {
            LongitudVigasMm = 0.0;
            MinMm = 0.0;
            MaxMm = 0.0;

            TieneColumnaInicioSerie = false;
            TieneColumnaFinSerie = false;

            TramosViga = new List<TramoVigaSeriePreview>();
            Columnas = new List<ColumnaCajaPreview>();
            SegmentosCota = new List<SegmentoCotaPreview>();
        }
    }

    public RebarBarType TipoSuperiorSeleccionado
    {
        get { return cmbTipoSuperior.SelectedItem as RebarBarType; }
    }

    public RebarBarType TipoInferiorSeleccionado
    {
        get { return cmbTipoInferior.SelectedItem as RebarBarType; }
    }

    public RebarBarType TipoCentralSeleccionado
    {
        get { return cmbTipoCentral.SelectedItem as RebarBarType; }
    }

    public int CapasSuperiores
    {
        get { return ObtenerNumeroCapas(cmbCapasSuperior); }
    }

    public int CapasInferiores
    {
        get { return ObtenerNumeroCapas(cmbCapasInferior); }
    }

    public RebarBarType TipoSuperiorCapa2Seleccionado
    {
        get { return cmbTipoSuperiorCapa2 != null ? cmbTipoSuperiorCapa2.SelectedItem as RebarBarType : null; }
    }

    public RebarBarType TipoSuperiorCapa3Seleccionado
    {
        get { return cmbTipoSuperiorCapa3 != null ? cmbTipoSuperiorCapa3.SelectedItem as RebarBarType : null; }
    }

    public RebarBarType TipoSuperiorCapa4Seleccionado
    {
        get { return cmbTipoSuperiorCapa4 != null ? cmbTipoSuperiorCapa4.SelectedItem as RebarBarType : null; }
    }

    public RebarBarType TipoInferiorCapa2Seleccionado
    {
        get { return cmbTipoInferiorCapa2 != null ? cmbTipoInferiorCapa2.SelectedItem as RebarBarType : null; }
    }

    public RebarBarType TipoInferiorCapa3Seleccionado
    {
        get { return cmbTipoInferiorCapa3 != null ? cmbTipoInferiorCapa3.SelectedItem as RebarBarType : null; }
    }

    public RebarBarType TipoInferiorCapa4Seleccionado
    {
        get { return cmbTipoInferiorCapa4 != null ? cmbTipoInferiorCapa4.SelectedItem as RebarBarType : null; }
    }

    public string CantidadSuperiorCapa2Texto
    {
        get { return ObtenerTextoTextBox(txtCantidadSuperiorCapa2); }
    }

    public string CantidadSuperiorCapa3Texto
    {
        get { return ObtenerTextoTextBox(txtCantidadSuperiorCapa3); }
    }

    public string CantidadSuperiorCapa4Texto
    {
        get { return ObtenerTextoTextBox(txtCantidadSuperiorCapa4); }
    }

    public string CantidadInferiorCapa2Texto
    {
        get { return ObtenerTextoTextBox(txtCantidadInferiorCapa2); }
    }

    public string CantidadInferiorCapa3Texto
    {
        get { return ObtenerTextoTextBox(txtCantidadInferiorCapa3); }
    }

    public string CantidadInferiorCapa4Texto
    {
        get { return ObtenerTextoTextBox(txtCantidadInferiorCapa4); }
    }

    private int ObtenerNumeroCapas(WinForms.ComboBox cmb)
    {
        if (cmb == null || cmb.SelectedItem == null)
            return 1;

        string texto = cmb.SelectedItem.ToString();

        if (string.IsNullOrWhiteSpace(texto))
            return 1;

        if (texto.Contains("4"))
            return 4;

        if (texto.Contains("3"))
            return 3;

        if (texto.Contains("2"))
            return 2;

        return 1;
    }

    private string ObtenerTextoTextBox(WinForms.TextBox txt)
    {
        if (txt == null || txt.Text == null)
            return string.Empty;

        return txt.Text.Trim();
    }

    public bool AceroCentral
    {
        get { return chkAceroCentral != null && chkAceroCentral.Checked; }
    }

    public bool CrearEmpalmes
    {
        get { return chkCrearEmpalmes != null && chkCrearEmpalmes.Checked; }
    }

    public bool UsarRNE
    {
        get { return chkUsarRNE != null && chkUsarRNE.Checked; }
    }

    public string ResistenciaRNETexto
    {
        get { return rneFcKgCm2.ToString("0", System.Globalization.CultureInfo.InvariantCulture) + " kg/cm2"; }
    }

    public string LongitudEmpalmeTexto
    {
        get
        {
            // Compatibilidad con handlers antiguos:
            // si se usa RNE, devuelve el empalme inferior/central.
            if (UsarRNE)
                return LongitudEmpalmeInferiorCentralTexto;

            return txtLongitudEmpalme.Text.Trim();
        }
    }

    public string LongitudEmpalmeSuperiorTexto
    {
        get
        {
            if (UsarRNE)
                return FormatearCentimetrosEnteros(empalmeRNESuperiorCm);

            return txtLongitudEmpalme.Text.Trim();
        }
    }

    public string LongitudEmpalmeInferiorCentralTexto
    {
        get
        {
            if (UsarRNE)
                return FormatearCentimetrosEnteros(empalmeRNEInferiorCm);

            return txtLongitudEmpalme.Text.Trim();
        }
    }

    public string LongitudEmpalmeInferiorTexto
    {
        get { return LongitudEmpalmeInferiorCentralTexto; }
    }

    public string LongitudEmpalmeCentralTexto
    {
        get
        {
            if (UsarRNE)
                return FormatearCentimetrosEnteros(empalmeRNECentralCm);

            return txtLongitudEmpalme.Text.Trim();
        }
    }

    public string LongitudBarraTexto
    {
        get { return txtLongitudBarra.Text.Trim(); }
    }

    public string CantidadSuperiorTexto
    {
        get { return txtCantidadSuperior.Text.Trim(); }
    }

    public string CantidadInferiorTexto
    {
        get { return txtCantidadInferior.Text.Trim(); }
    }

    public string RecubrimientoTexto
    {
        get { return txtRecubrimiento.Text.Trim(); }
    }

    public void EstablecerRecubrimientoDesdeEditor(double recubrimientoCm)
    {
        if (txtRecubrimiento == null)
            return;

        if (double.IsNaN(recubrimientoCm) ||
            double.IsInfinity(recubrimientoCm) ||
            recubrimientoCm <= 0.0)
        {
            return;
        }

        txtRecubrimiento.Text = recubrimientoCm.ToString(
            "0.##",
            System.Globalization.CultureInfo.InvariantCulture);

        RefrescarPreviewLongitudinalEnTiempoReal();
    }

    public string SeparacionCapasTexto
    {
        get
        {
            if (txtSeparacionCapas == null || txtSeparacionCapas.Text == null)
                return "1\"";

            return txtSeparacionCapas.Text.Trim();
        }
    }

    // El handler llama este método después de interpretar la entrada con
    // UnitFormatUtils.TryParse. La ventana siempre muestra el resultado en metros.
    public void EstablecerSeparacionCapasDesdeValorInterno(double valorInternoFt)
    {
        if (txtSeparacionCapas == null)
            return;

        if (double.IsNaN(valorInternoFt) ||
            double.IsInfinity(valorInternoFt) ||
            valorInternoFt <= 0.0)
        {
            return;
        }

        double metros = UnitUtils.ConvertFromInternalUnits(
            valorInternoFt,
            UnitTypeId.Meters);

        txtSeparacionCapas.Text = metros.ToString(
            "0.####",
            System.Globalization.CultureInfo.InvariantCulture) + " m";
    }

    public bool DetectarColumnas
    {
        // Siempre se detectan columnas adyacentes.
        // El check visual fue retirado de la ventana.
        get { return true; }
    }

    public bool ColocarGancho
    {
        get { return GanchoInicio || GanchoFin; }
    }

    public string LongitudGanchoTexto
    {
        get
        {
            if (GanchoInicio)
                return LongitudGanchoInicioTexto;

            return LongitudGanchoFinTexto;
        }
    }

    public bool GanchoInicio
    {
        get { return chkGanchoInicio != null && chkGanchoInicio.Checked; }
    }

    public bool GanchoFin
    {
        get { return chkGanchoFin != null && chkGanchoFin.Checked; }
    }

    public string LongitudGanchoInicioTexto
    {
        get { return txtLongitudGanchoInicio.Text.Trim(); }
    }

    public string LongitudGanchoFinTexto
    {
        get { return txtLongitudGanchoFin.Text.Trim(); }
    }

    public bool DesarrolloAutomaticoInicio
    {
        get
        {
            return chkDesarrolloAutomaticoInicio != null &&
                   chkDesarrolloAutomaticoInicio.Checked;
        }
    }

    public bool DesarrolloAutomaticoFin
    {
        get
        {
            return chkDesarrolloAutomaticoFin != null &&
                   chkDesarrolloAutomaticoFin.Checked;
        }
    }

    // Compatibilidad interna: true si cualquiera de los extremos está en automático.
    public bool DesarrolloAutomaticoRecubrimiento
    {
        get { return DesarrolloAutomaticoInicio || DesarrolloAutomaticoFin; }
    }

    public string LongitudDesarrolloInicioTexto
    {
        get
        {
            if (DesarrolloAutomaticoInicio && desarrolloInicioDisponible)
                return FormatearCmParaTexto(CalcularDesarrolloAutomaticoInicioCm());

            return txtLongitudDesarrolloInicio != null
                ? txtLongitudDesarrolloInicio.Text.Trim()
                : "0";
        }
    }

    public string LongitudDesarrolloFinTexto
    {
        get
        {
            if (DesarrolloAutomaticoFin && desarrolloFinDisponible)
                return FormatearCmParaTexto(CalcularDesarrolloAutomaticoFinCm());

            return txtLongitudDesarrolloFin != null
                ? txtLongitudDesarrolloFin.Text.Trim()
                : "0";
        }
    }

    public bool LongitudDesarrolloInicioHabilitada
    {
        get
        {
            // Auto solo se aplica cuando se encontró una columna real.
            if (DesarrolloAutomaticoInicio)
                return desarrolloInicioDisponible;

            // Al desactivar Auto, el valor manual siempre queda habilitado,
            // incluso si el extremo es un voladizo o no existe columna.
            return txtLongitudDesarrolloInicio != null;
        }
    }

    public bool LongitudDesarrolloFinHabilitada
    {
        get
        {
            if (DesarrolloAutomaticoFin)
                return desarrolloFinDisponible;

            return txtLongitudDesarrolloFin != null;
        }
    }

    // =========================================================
    // DATOS DE COLUMNAS SOLO PARA DESARROLLO AUTOMÁTICO
    // =========================================================
    // No modifica la colección Columnas del preview y, por tanto, no dibuja
    // ningún elemento del entorno. Únicamente habilita Auto y guarda el ancho.
    public void EstablecerColumnasExtremosAuto(
        bool tieneColumnaInicio,
        double anchoInicioMm,
        bool tieneColumnaFin,
        double anchoFinMm)
    {
        desarrolloInicioDisponible =
            tieneColumnaInicio &&
            !double.IsNaN(anchoInicioMm) &&
            !double.IsInfinity(anchoInicioMm) &&
            anchoInicioMm > 1.0;

        desarrolloFinDisponible =
            tieneColumnaFin &&
            !double.IsNaN(anchoFinMm) &&
            !double.IsInfinity(anchoFinMm) &&
            anchoFinMm > 1.0;

        anchoColumnaAutoInicioMm = desarrolloInicioDisponible
            ? Math.Max(0.0, anchoInicioMm)
            : 0.0;

        anchoColumnaAutoFinMm = desarrolloFinDisponible
            ? Math.Max(0.0, anchoFinMm)
            : 0.0;

        // Si cambió la selección y ya no existe columna en un extremo,
        // Auto se desactiva. El campo manual vuelve a quedar editable.
        if (!desarrolloInicioDisponible &&
            chkDesarrolloAutomaticoInicio != null &&
            chkDesarrolloAutomaticoInicio.Checked)
        {
            chkDesarrolloAutomaticoInicio.Checked = false;
        }

        if (!desarrolloFinDisponible &&
            chkDesarrolloAutomaticoFin != null &&
            chkDesarrolloAutomaticoFin.Checked)
        {
            chkDesarrolloAutomaticoFin.Checked = false;
        }

        ActualizarEstadoDesarrolloPorVoladizo();
        ActualizarTextosDesarrolloAutomatico();
        RefrescarPreviewLongitudinalEnTiempoReal();
    }

    private bool TieneDisenoLongitudinalManualV5()
    {
        try
        {
            AceroVigaDisenoSeccion diseno =
                AceroVigaDisenoSeccionCompartido.ObtenerCopia();

            return diseno != null &&
                   diseno.Longitudinales != null &&
                   diseno.Longitudinales.Count > 0;
        }
        catch
        {
            return false;
        }
    }

    public AceroLongitudinalVigasForm()
    {
        this.Text = "MYG - Acero Longitudinal en Vigas";
        this.Width = 790;
        this.Height = 890;
        this.StartPosition = WinForms.FormStartPosition.CenterScreen;
        this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
        this.ControlBox = true;
        this.MinimizeBox = true;
        this.MaximizeBox = false;
        this.ShowInTaskbar = true;
        this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
        this.Font = new Drawing.Font("Segoe UI", 9F);
        this.TopMost = true;

        // Sin vigas de ejemplo.
        // Si aún no se selecciona nada, la vista preliminar debe mostrar
        // el mensaje "NO HAY VIGAS SELECCIONADAS".
        previewVigas.Clear();

        lblTituloPrincipal = new WinForms.Label()
        {
            Text = "Crear acero longitudinal en vigas",
            Left = 20,
            Top = 16,
            Width = 760,
            Height = 24,
            Font = new Drawing.Font("Segoe UI", 10F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.FromArgb(45, 45, 45)
        };

        lblDescripcionPrincipal = new WinForms.Label()
        {
            Text = "Configura los parámetros de acero longitudinal. La vista preliminar se actualizará con la geometría seleccionada.",
            Left = 20,
            Top = 42,
            Width = 820,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F),
            ForeColor = Drawing.Color.Gray
        };

        grpParametrosPrincipal = new WinForms.GroupBox()
        {
            Text = "Parámetros de acero longitudinal",
            Left = 20,
            Top = 72,
            Width = 720,
            Height = 315,
            Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.FromArgb(50, 50, 50)
        };

        WinForms.GroupBox grpParametros = grpParametrosPrincipal;

        WinForms.Label lblTipoSuperior = new WinForms.Label()
        {
            Text = "Barra Sup.:",
            Left = 20,
            Top = 30,
            Width = 82,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroSuperior
        };

        cmbTipoSuperior = new WinForms.ComboBox()
        {
            Left = 105,
            Top = 27,
            Width = 62,
            DropDownWidth = 62,
            Height = 24,
            DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
            MaxDropDownItems = 10,
            IntegralHeight = false
        };

        cmbTipoSuperior.SelectedIndexChanged += (s, e) =>
        {
            if (UsarRNE)
                CalcularYAplicarEmpalmeRNE();

            RefrescarPreviewLongitudinalEnTiempoReal();
            RefrescarEditorSeccionIntegrado();
        };

        WinForms.Label lblCantidadSuperior = new WinForms.Label()
        {
            Text = "Cant. Sup.:",
            Left = 360,
            Top = 30,
            Width = 90,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroSuperior
        };

        txtCantidadSuperior = new WinForms.TextBox()
        {
            Left = 452,
            Top = 27,
            Width = 42,
            Height = 24,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "2"
        };

        txtCantidadSuperior.TextChanged += (s, e) =>
        {
            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        lblColorSuperior = new WinForms.Label()
        {
            Text = "●",
            Left = 497,
            Top = 25,
            Width = 25,
            Height = 25,
            Font = new Drawing.Font("Segoe UI", 14F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroSuperior,
            TextAlign = Drawing.ContentAlignment.MiddleCenter
        };

        WinForms.Label lblTipoInferior = new WinForms.Label()
        {
            Text = "Barra Inf.:",
            Left = 20,
            Top = 65,
            Width = 82,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroInferior
        };

        cmbTipoInferior = new WinForms.ComboBox()
        {
            Left = 105,
            Top = 62,
            Width = 62,
            DropDownWidth = 62,
            Height = 24,
            DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
            MaxDropDownItems = 10,
            IntegralHeight = false
        };

        cmbTipoInferior.SelectedIndexChanged += (s, e) =>
        {
            if (UsarRNE)
                CalcularYAplicarEmpalmeRNE();

            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        WinForms.Label lblCantidadInferior = new WinForms.Label()
        {
            Text = "Cant. Inf.:",
            Left = 360,
            Top = 65,
            Width = 90,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroInferior
        };

        txtCantidadInferior = new WinForms.TextBox()
        {
            Left = 452,
            Top = 62,
            Width = 42,
            Height = 24,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "2"
        };

        txtCantidadInferior.TextChanged += (s, e) =>
        {
            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        lblColorInferior = new WinForms.Label()
        {
            Text = "●",
            Left = 497,
            Top = 60,
            Width = 25,
            Height = 25,
            Font = new Drawing.Font("Segoe UI", 14F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroInferior,
            TextAlign = Drawing.ContentAlignment.MiddleCenter
        };

        lblCapasSuperior = new WinForms.Label()
        {
            Text = "Capas Sup.:",
            Left = 180,
            Top = 30,
            Width = 82,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroSuperior
        };

        cmbCapasSuperior = new WinForms.ComboBox()
        {
            Left = 265,
            Top = 27,
            Width = 85,
            DropDownWidth = 95,
            Height = 24,
            DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
            MaxDropDownItems = 4,
            IntegralHeight = false
        };
        cmbCapasSuperior.Items.Add("1 capa");
        cmbCapasSuperior.Items.Add("2 capas");
        cmbCapasSuperior.Items.Add("3 capas");
        cmbCapasSuperior.Items.Add("4 capas");
        cmbCapasSuperior.SelectedIndex = 0;

        lblCapasInferior = new WinForms.Label()
        {
            Text = "Capas Inf.:",
            Left = 180,
            Top = 65,
            Width = 82,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroInferior
        };

        cmbCapasInferior = new WinForms.ComboBox()
        {
            Left = 265,
            Top = 62,
            Width = 85,
            DropDownWidth = 95,
            Height = 24,
            DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
            MaxDropDownItems = 4,
            IntegralHeight = false
        };
        cmbCapasInferior.Items.Add("1 capa");
        cmbCapasInferior.Items.Add("2 capas");
        cmbCapasInferior.Items.Add("3 capas");
        cmbCapasInferior.Items.Add("4 capas");
        cmbCapasInferior.SelectedIndex = 0;

        lblTipoSuperiorCapa2 = new WinForms.Label()
        {
            Text = "Sup. capa 2:",
            Left = 20,
            Top = 128,
            Width = 90,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroSuperior,
            Visible = false
        };

        cmbTipoSuperiorCapa2 = new WinForms.ComboBox()
        {
            Left = 112,
            Top = 124,
            Width = 58,
            DropDownWidth = 62,
            Height = 24,
            DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
            MaxDropDownItems = 10,
            IntegralHeight = false,
            Visible = false
        };

        lblCantidadSuperiorCapa2 = new WinForms.Label()
        {
            Text = "Cant.:",
            Left = 178,
            Top = 128,
            Width = 40,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroSuperior,
            Visible = false
        };

        txtCantidadSuperiorCapa2 = new WinForms.TextBox()
        {
            Left = 220,
            Top = 124,
            Width = 38,
            Height = 24,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "2",
            Visible = false
        };

        lblTipoSuperiorCapa3 = new WinForms.Label()
        {
            Text = "Sup. capa 3:",
            Left = 20,
            Top = 158,
            Width = 90,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroSuperior,
            Visible = false
        };

        cmbTipoSuperiorCapa3 = new WinForms.ComboBox()
        {
            Left = 112,
            Top = 154,
            Width = 58,
            DropDownWidth = 62,
            Height = 24,
            DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
            MaxDropDownItems = 10,
            IntegralHeight = false,
            Visible = false
        };

        lblCantidadSuperiorCapa3 = new WinForms.Label()
        {
            Text = "Cant.:",
            Left = 178,
            Top = 158,
            Width = 40,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroSuperior,
            Visible = false
        };

        txtCantidadSuperiorCapa3 = new WinForms.TextBox()
        {
            Left = 220,
            Top = 154,
            Width = 38,
            Height = 24,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "2",
            Visible = false
        };

        lblTipoSuperiorCapa4 = new WinForms.Label()
        {
            Text = "Sup. capa 4:",
            Left = 20,
            Top = 188,
            Width = 90,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroSuperior,
            Visible = false
        };

        cmbTipoSuperiorCapa4 = new WinForms.ComboBox()
        {
            Left = 112,
            Top = 184,
            Width = 58,
            DropDownWidth = 62,
            Height = 24,
            DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
            MaxDropDownItems = 10,
            IntegralHeight = false,
            Visible = false
        };

        lblCantidadSuperiorCapa4 = new WinForms.Label()
        {
            Text = "Cant.:",
            Left = 178,
            Top = 188,
            Width = 40,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroSuperior,
            Visible = false
        };

        txtCantidadSuperiorCapa4 = new WinForms.TextBox()
        {
            Left = 220,
            Top = 184,
            Width = 38,
            Height = 24,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "2",
            Visible = false
        };

        lblTipoInferiorCapa2 = new WinForms.Label()
        {
            Text = "Inf. capa 2:",
            Left = 275,
            Top = 128,
            Width = 90,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroInferior,
            Visible = false
        };

        cmbTipoInferiorCapa2 = new WinForms.ComboBox()
        {
            Left = 367,
            Top = 124,
            Width = 58,
            DropDownWidth = 62,
            Height = 24,
            DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
            MaxDropDownItems = 10,
            IntegralHeight = false,
            Visible = false
        };

        lblCantidadInferiorCapa2 = new WinForms.Label()
        {
            Text = "Cant.:",
            Left = 433,
            Top = 128,
            Width = 40,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroInferior,
            Visible = false
        };

        txtCantidadInferiorCapa2 = new WinForms.TextBox()
        {
            Left = 475,
            Top = 124,
            Width = 38,
            Height = 24,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "2",
            Visible = false
        };

        lblTipoInferiorCapa3 = new WinForms.Label()
        {
            Text = "Inf. capa 3:",
            Left = 275,
            Top = 158,
            Width = 90,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroInferior,
            Visible = false
        };

        cmbTipoInferiorCapa3 = new WinForms.ComboBox()
        {
            Left = 367,
            Top = 154,
            Width = 58,
            DropDownWidth = 62,
            Height = 24,
            DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
            MaxDropDownItems = 10,
            IntegralHeight = false,
            Visible = false
        };

        lblCantidadInferiorCapa3 = new WinForms.Label()
        {
            Text = "Cant.:",
            Left = 433,
            Top = 158,
            Width = 40,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroInferior,
            Visible = false
        };

        txtCantidadInferiorCapa3 = new WinForms.TextBox()
        {
            Left = 475,
            Top = 154,
            Width = 38,
            Height = 24,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "2",
            Visible = false
        };

        lblTipoInferiorCapa4 = new WinForms.Label()
        {
            Text = "Inf. capa 4:",
            Left = 275,
            Top = 188,
            Width = 90,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroInferior,
            Visible = false
        };

        cmbTipoInferiorCapa4 = new WinForms.ComboBox()
        {
            Left = 367,
            Top = 184,
            Width = 58,
            DropDownWidth = 62,
            Height = 24,
            DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
            MaxDropDownItems = 10,
            IntegralHeight = false,
            Visible = false
        };

        lblCantidadInferiorCapa4 = new WinForms.Label()
        {
            Text = "Cant.:",
            Left = 433,
            Top = 188,
            Width = 40,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
            ForeColor = ColorAceroInferior,
            Visible = false
        };

        txtCantidadInferiorCapa4 = new WinForms.TextBox()
        {
            Left = 475,
            Top = 184,
            Width = 38,
            Height = 24,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "2",
            Visible = false
        };

        cmbCapasSuperior.SelectedIndexChanged += (s, e) =>
        {
            ActualizarVisibilidadCapasLongitudinales();
            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        cmbCapasInferior.SelectedIndexChanged += (s, e) =>
        {
            ActualizarVisibilidadCapasLongitudinales();
            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        cmbTipoSuperiorCapa2.SelectedIndexChanged += (s, e) => RefrescarPreviewLongitudinalEnTiempoReal();
        cmbTipoSuperiorCapa3.SelectedIndexChanged += (s, e) => RefrescarPreviewLongitudinalEnTiempoReal();
        cmbTipoSuperiorCapa4.SelectedIndexChanged += (s, e) => RefrescarPreviewLongitudinalEnTiempoReal();
        cmbTipoInferiorCapa2.SelectedIndexChanged += (s, e) => RefrescarPreviewLongitudinalEnTiempoReal();
        cmbTipoInferiorCapa3.SelectedIndexChanged += (s, e) => RefrescarPreviewLongitudinalEnTiempoReal();
        cmbTipoInferiorCapa4.SelectedIndexChanged += (s, e) => RefrescarPreviewLongitudinalEnTiempoReal();
        txtCantidadSuperiorCapa2.TextChanged += (s, e) => RefrescarPreviewLongitudinalEnTiempoReal();
        txtCantidadSuperiorCapa3.TextChanged += (s, e) => RefrescarPreviewLongitudinalEnTiempoReal();
        txtCantidadSuperiorCapa4.TextChanged += (s, e) => RefrescarPreviewLongitudinalEnTiempoReal();
        txtCantidadInferiorCapa2.TextChanged += (s, e) => RefrescarPreviewLongitudinalEnTiempoReal();
        txtCantidadInferiorCapa3.TextChanged += (s, e) => RefrescarPreviewLongitudinalEnTiempoReal();
        txtCantidadInferiorCapa4.TextChanged += (s, e) => RefrescarPreviewLongitudinalEnTiempoReal();

        chkAceroCentral = new WinForms.CheckBox()
        {
            Text = "",
            Left = 20,
            Top = 98,
            Width = 18,
            Height = 20,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Checked = false
        };

        lblTipoCentral = new WinForms.Label()
        {
            Text = "Tipo barra central:",
            Left = 42,
            Top = 98,
            Width = 120,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold)
        };

        cmbTipoCentral = new WinForms.ComboBox()
        {
            Left = 168,
            Top = 94,
            Width = 62,
            DropDownWidth = 62,
            Height = 24,
            DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
            MaxDropDownItems = 10,
            IntegralHeight = false
        };

        lblCantidadCentralFija = new WinForms.Label()
        {
            Text = "Cantidad central: 2",
            Left = 255,
            Top = 98,
            Width = 145,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold)
        };

        lblColorCentral = new WinForms.Label()
        {
            Text = "●",
            Left = 405,
            Top = 93,
            Width = 25,
            Height = 25,
            Font = new Drawing.Font("Segoe UI", 14F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.Gray,
            TextAlign = Drawing.ContentAlignment.MiddleCenter
        };

        chkAceroCentral.CheckedChanged += (s, e) =>
        {
            ActualizarEstadoAceroCentral();

            if (UsarRNE)
                CalcularYAplicarEmpalmeRNE();

            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        cmbTipoCentral.SelectedIndexChanged += (s, e) =>
        {
            if (UsarRNE)
                CalcularYAplicarEmpalmeRNE();

            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        WinForms.Label lblRecubrimiento = new WinForms.Label()
        {
            Text = "Recubrimiento:",
            Left = 20,
            Top = 222,
            Width = 130,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold)
        };

        txtRecubrimiento = new WinForms.TextBox()
        {
            Left = 155,
            Top = 219,
            Width = 55,
            Height = 24,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "4"
        };

        txtRecubrimiento.TextChanged += (s, e) =>
        {
            ActualizarEstadoDesarrolloPorVoladizo();
            ActualizarTextosDesarrolloAutomatico();
            RefrescarPreviewLongitudinalEnTiempoReal();
            RefrescarEditorSeccionIntegrado();
        };

        WinForms.Label lblCmRec = new WinForms.Label()
        {
            Text = "cm",
            Left = 215,
            Top = 223,
            Width = 30,
            Height = 22,
            ForeColor = Drawing.Color.Gray
        };

        lblSeparacionCapas = new WinForms.Label()
        {
            Text = "Sep. capas:",
            Left = 255,
            Top = 222,
            Width = 82,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
            Visible = false
        };

        txtSeparacionCapas = new WinForms.TextBox()
        {
            Left = 340,
            Top = 219,
            Width = 82,
            Height = 24,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "1\"",
            Visible = false
        };

        txtSeparacionCapas.TextChanged += (s, e) =>
        {
            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        txtSeparacionCapas.Leave += (s, e) =>
        {
            double separacionMm;

            if (TryConvertirLongitudTextoAMmMYG(
                txtSeparacionCapas.Text,
                out separacionMm) &&
                separacionMm > 0.0)
            {
                txtSeparacionCapas.Text =
                    (separacionMm / 1000.0).ToString(
                        "0.####",
                        System.Globalization.CultureInfo.InvariantCulture) +
                    " m";
            }
        };

        lblAyudaSeparacionCapas = new WinForms.Label()
        {
            Text = "Ej.: 2\", 5cm",
            Left = 428,
            Top = 223,
            Width = 105,
            Height = 22,
            ForeColor = Drawing.Color.Gray,
            Font = new Drawing.Font("Segoe UI", 8F),
            Visible = false
        };

        chkDetectarColumnas = new WinForms.CheckBox()
        {
            Text = "Detectar columnas adyacentes para vista preliminar",
            Left = 235,
            Top = 220,
            Width = 270,
            Height = 24,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Checked = true,
            Font = new Drawing.Font("Segoe UI", 8.5F)
        };

        chkDetectarColumnas.CheckedChanged += (s, e) =>
        {
            ActualizarEstadoDesarrolloPorVoladizo();

            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        chkCrearEmpalmes = new WinForms.CheckBox()
        {
            Text = "Crear empalmes",
            Left = 20,
            Top = 249,
            Width = 125,
            Height = 22,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Checked = false,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold)
        };

        lblLongitudEmpalme = new WinForms.Label()
        {
            Text = "L. empalme:",
            Left = 155,
            Top = 251,
            Width = 82,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold)
        };

        txtLongitudEmpalme = new WinForms.TextBox()
        {
            Left = 240,
            Top = 248,
            Width = 45,
            Height = 24,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "60"
        };

        lblCmEmpalme = new WinForms.Label()
        {
            Text = "cm",
            Left = 290,
            Top = 252,
            Width = 30,
            Height = 22,
            ForeColor = Drawing.Color.Gray
        };

        lblLongitudBarra = new WinForms.Label()
        {
            Text = "Long. barra:",
            Left = 300,
            Top = 251,
            Width = 80,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold)
        };

        txtLongitudBarra = new WinForms.TextBox()
        {
            Left = 380,
            Top = 248,
            Width = 42,
            Height = 24,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "9"
        };

        lblMBarra = new WinForms.Label()
        {
            Text = "m",
            Left = 427,
            Top = 252,
            Width = 20,
            Height = 22,
            ForeColor = Drawing.Color.Gray
        };

        // 🔥 RNE: CHECK + BOTÓN DE CONFIGURACIÓN
        chkUsarRNE = new WinForms.CheckBox()
        {
            Text = "",
            Left = 452,
            Top = 250,
            Width = 18,
            Height = 20,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Checked = false
        };

        btnConfigRNE = new WinForms.Button()
        {
            Text = "Usar RNE...",
            Left = 472,
            Top = 247,
            Width = 92,
            Height = 26,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            ForeColor = Drawing.Color.FromArgb(40, 40, 40),
            FlatStyle = WinForms.FlatStyle.Flat,
            Font = new Drawing.Font("Segoe UI", 8.2F, Drawing.FontStyle.Bold),
            Cursor = WinForms.Cursors.Hand
        };
        btnConfigRNE.FlatAppearance.BorderColor = Drawing.Color.FromArgb(170, 170, 170);
        btnConfigRNE.FlatAppearance.BorderSize = 1;

        // Se mantiene oculto por compatibilidad interna, pero ahora la configuración se hace desde el botón.
        cmbResistenciaRNE = new WinForms.ComboBox()
        {
            Left = 472,
            Top = 275,
            Width = 80,
            Height = 24,
            DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
            MaxDropDownItems = 4,
            IntegralHeight = false,
            Enabled = false,
            Visible = false
        };

        cmbResistenciaRNE.Items.Add("175 kg/cm2");
        cmbResistenciaRNE.Items.Add("210 kg/cm2");
        cmbResistenciaRNE.Items.Add("280 kg/cm2");
        cmbResistenciaRNE.Items.Add("350 kg/cm2");
        cmbResistenciaRNE.SelectedIndex = 1;

        lblInfoRNE = new WinForms.Label()
        {
            Text = "",
            Left = 155,
            Top = 277,
            Width = 410,
            Height = 18,
            ForeColor = Drawing.Color.FromArgb(90, 90, 90),
            Font = new Drawing.Font("Segoe UI", 7.8F, Drawing.FontStyle.Bold),
            TextAlign = Drawing.ContentAlignment.MiddleLeft,
            Visible = false
        };

        chkCrearEmpalmes.CheckedChanged += (s, e) =>
        {
            if (!actualizandoRNE &&
                chkCrearEmpalmes != null &&
                !chkCrearEmpalmes.Checked &&
                chkUsarRNE != null &&
                chkUsarRNE.Checked)
            {
                actualizandoRNE = true;
                chkUsarRNE.Checked = false;
                actualizandoRNE = false;
            }

            ActualizarEstadoEmpalmes();
            ActualizarEstadoRNE();

            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        chkUsarRNE.CheckedChanged += (s, e) =>
        {
            if (!actualizandoRNE &&
                chkUsarRNE != null &&
                chkUsarRNE.Checked &&
                chkCrearEmpalmes != null &&
                !chkCrearEmpalmes.Checked)
            {
                actualizandoRNE = true;
                chkCrearEmpalmes.Checked = true;
                actualizandoRNE = false;
            }

            ActualizarEstadoEmpalmes();
            ActualizarEstadoRNE();

            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        btnConfigRNE.Click += (s, e) =>
        {
            AbrirConfiguracionRNE();
        };

        cmbResistenciaRNE.SelectedIndexChanged += (s, e) =>
        {
            if (UsarRNE)
                CalcularYAplicarEmpalmeRNE();

            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        txtLongitudEmpalme.TextChanged += (s, e) =>
        {
            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        txtLongitudBarra.TextChanged += (s, e) =>
        {
            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        grpParametros.Controls.Add(lblTipoSuperior);
        grpParametros.Controls.Add(cmbTipoSuperior);
        grpParametros.Controls.Add(lblCantidadSuperior);
        grpParametros.Controls.Add(txtCantidadSuperior);
        grpParametros.Controls.Add(lblColorSuperior);
        grpParametros.Controls.Add(lblCapasSuperior);
        grpParametros.Controls.Add(cmbCapasSuperior);

        grpParametros.Controls.Add(lblTipoInferior);
        grpParametros.Controls.Add(cmbTipoInferior);
        grpParametros.Controls.Add(lblCantidadInferior);
        grpParametros.Controls.Add(txtCantidadInferior);
        grpParametros.Controls.Add(lblColorInferior);
        grpParametros.Controls.Add(lblCapasInferior);
        grpParametros.Controls.Add(cmbCapasInferior);

        grpParametros.Controls.Add(lblTipoSuperiorCapa2);
        grpParametros.Controls.Add(cmbTipoSuperiorCapa2);
        grpParametros.Controls.Add(lblCantidadSuperiorCapa2);
        grpParametros.Controls.Add(txtCantidadSuperiorCapa2);
        grpParametros.Controls.Add(lblTipoSuperiorCapa3);
        grpParametros.Controls.Add(cmbTipoSuperiorCapa3);
        grpParametros.Controls.Add(lblCantidadSuperiorCapa3);
        grpParametros.Controls.Add(txtCantidadSuperiorCapa3);
        grpParametros.Controls.Add(lblTipoSuperiorCapa4);
        grpParametros.Controls.Add(cmbTipoSuperiorCapa4);
        grpParametros.Controls.Add(lblCantidadSuperiorCapa4);
        grpParametros.Controls.Add(txtCantidadSuperiorCapa4);

        grpParametros.Controls.Add(lblTipoInferiorCapa2);
        grpParametros.Controls.Add(cmbTipoInferiorCapa2);
        grpParametros.Controls.Add(lblCantidadInferiorCapa2);
        grpParametros.Controls.Add(txtCantidadInferiorCapa2);
        grpParametros.Controls.Add(lblTipoInferiorCapa3);
        grpParametros.Controls.Add(cmbTipoInferiorCapa3);
        grpParametros.Controls.Add(lblCantidadInferiorCapa3);
        grpParametros.Controls.Add(txtCantidadInferiorCapa3);
        grpParametros.Controls.Add(lblTipoInferiorCapa4);
        grpParametros.Controls.Add(cmbTipoInferiorCapa4);
        grpParametros.Controls.Add(lblCantidadInferiorCapa4);
        grpParametros.Controls.Add(txtCantidadInferiorCapa4);

        grpParametros.Controls.Add(chkAceroCentral);
        grpParametros.Controls.Add(lblTipoCentral);
        grpParametros.Controls.Add(cmbTipoCentral);
        grpParametros.Controls.Add(lblCantidadCentralFija);
        grpParametros.Controls.Add(lblColorCentral);

        grpParametros.Controls.Add(lblRecubrimiento);
        grpParametros.Controls.Add(txtRecubrimiento);
        grpParametros.Controls.Add(lblCmRec);

        grpParametros.Controls.Add(lblSeparacionCapas);
        grpParametros.Controls.Add(txtSeparacionCapas);
        grpParametros.Controls.Add(lblAyudaSeparacionCapas);

        // Se retiró el check "Detectar columnas adyacentes".
        // La detección queda siempre activa mediante la propiedad DetectarColumnas = true.

        grpParametros.Controls.Add(chkCrearEmpalmes);
        grpParametros.Controls.Add(lblLongitudEmpalme);
        grpParametros.Controls.Add(txtLongitudEmpalme);
        grpParametros.Controls.Add(lblCmEmpalme);
        grpParametros.Controls.Add(lblLongitudBarra);
        grpParametros.Controls.Add(txtLongitudBarra);
        grpParametros.Controls.Add(lblMBarra);

        // 🔥 NUEVO
        grpParametros.Controls.Add(chkUsarRNE);
        grpParametros.Controls.Add(btnConfigRNE);
        grpParametros.Controls.Add(cmbResistenciaRNE);
        grpParametros.Controls.Add(lblInfoRNE);

        // =========================================================
        // V5 - CONFIGURACIÓN MANUAL UNIFICADA
        // =========================================================
        // La disposición superior/inferior por cantidades queda como respaldo
        // interno para datas antiguas, pero ya no se duplica en la interfaz.
        // El tipo seleccionado en cmbTipoSuperior es el tipo ACTUAL de dibujo;
        // cada barra creada conserva su propio RebarBarType.
        lblTipoSuperior.Text = "Tipo barra actual:";
        lblTipoSuperior.Left = 20;
        lblTipoSuperior.Top = 31;
        lblTipoSuperior.Width = 120;
        cmbTipoSuperior.Left = 142;
        cmbTipoSuperior.Top = 27;
        cmbTipoSuperior.Width = 125;
        cmbTipoSuperior.DropDownWidth = 180;

        lblRecubrimiento.Left = 292;
        lblRecubrimiento.Top = 31;
        lblRecubrimiento.Width = 110;
        txtRecubrimiento.Left = 402;
        txtRecubrimiento.Top = 27;
        lblCmRec.Left = 462;
        lblCmRec.Top = 31;

        lblCantidadSuperior.Visible = false;
        txtCantidadSuperior.Visible = false;
        lblColorSuperior.Visible = false;
        lblCapasSuperior.Visible = false;
        cmbCapasSuperior.Visible = false;

        lblTipoInferior.Visible = false;
        cmbTipoInferior.Visible = false;
        lblCantidadInferior.Visible = false;
        txtCantidadInferior.Visible = false;
        lblColorInferior.Visible = false;
        lblCapasInferior.Visible = false;
        cmbCapasInferior.Visible = false;

        chkAceroCentral.Visible = false;
        lblTipoCentral.Visible = false;
        cmbTipoCentral.Visible = false;
        lblCantidadCentralFija.Visible = false;
        lblColorCentral.Visible = false;

        lblTipoSuperiorCapa2.Visible = false;
        cmbTipoSuperiorCapa2.Visible = false;
        lblCantidadSuperiorCapa2.Visible = false;
        txtCantidadSuperiorCapa2.Visible = false;
        lblTipoSuperiorCapa3.Visible = false;
        cmbTipoSuperiorCapa3.Visible = false;
        lblCantidadSuperiorCapa3.Visible = false;
        txtCantidadSuperiorCapa3.Visible = false;
        lblTipoSuperiorCapa4.Visible = false;
        cmbTipoSuperiorCapa4.Visible = false;
        lblCantidadSuperiorCapa4.Visible = false;
        txtCantidadSuperiorCapa4.Visible = false;

        lblTipoInferiorCapa2.Visible = false;
        cmbTipoInferiorCapa2.Visible = false;
        lblCantidadInferiorCapa2.Visible = false;
        txtCantidadInferiorCapa2.Visible = false;
        lblTipoInferiorCapa3.Visible = false;
        cmbTipoInferiorCapa3.Visible = false;
        lblCantidadInferiorCapa3.Visible = false;
        txtCantidadInferiorCapa3.Visible = false;
        lblTipoInferiorCapa4.Visible = false;
        cmbTipoInferiorCapa4.Visible = false;
        lblCantidadInferiorCapa4.Visible = false;
        txtCantidadInferiorCapa4.Visible = false;

        lblSeparacionCapas.Visible = false;
        txtSeparacionCapas.Visible = false;
        lblAyudaSeparacionCapas.Visible = false;

        chkCrearEmpalmes.Left = 20;
        chkCrearEmpalmes.Top = 68;
        lblLongitudEmpalme.Left = 145;
        lblLongitudEmpalme.Top = 70;
        txtLongitudEmpalme.Left = 228;
        txtLongitudEmpalme.Top = 67;
        lblCmEmpalme.Left = 278;
        lblCmEmpalme.Top = 71;
        lblLongitudBarra.Left = 308;
        lblLongitudBarra.Top = 70;
        txtLongitudBarra.Left = 388;
        txtLongitudBarra.Top = 67;
        lblMBarra.Left = 435;
        lblMBarra.Top = 71;
        chkUsarRNE.Left = 438;
        chkUsarRNE.Top = 69;
        btnConfigRNE.Left = 458;
        btnConfigRNE.Top = 66;
        btnConfigRNE.Width = 82;
        lblInfoRNE.Left = 20;
        lblInfoRNE.Top = 103;
        lblInfoRNE.Width = 510;

        grpParametros.Height = 138;

        // Botón mantenido solo como objeto interno para compatibilidad,
        // pero ya NO se agrega a la ventana porque la selección de vigas
        // se realizará desde una pestaña previa.
        btnSeleccionarVigas = new WinForms.Button()
        {
            Text = "SELECCIONAR VIGAS / ARMAZONES",
            Left = 20,
            Top = 364,
            Width = 300,
            Height = 34,
            BackColor = Drawing.Color.FromArgb(100, 100, 100),
            ForeColor = Drawing.Color.White,
            FlatStyle = WinForms.FlatStyle.Flat,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
            Cursor = WinForms.Cursors.Hand,
            Visible = false
        };

        btnSeleccionarVigas.FlatAppearance.BorderSize = 0;

        btnSeleccionarVigas.Click += (s, e) =>
        {
            SeleccionarEvent?.Raise();
        };

        lblCantidad = new WinForms.Label()
        {
            Text = "Vigas seleccionadas: 0",
            Left = 20,
            Top = 366,
            Width = 280,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.FromArgb(50, 50, 50)
        };

        btnEjecutar = new WinForms.Button()
        {
            Text = "EJECUTAR",
            Left = 295,
            Top = 877,
            Width = 180,
            Height = 38,
            BackColor = Drawing.Color.FromArgb(0, 120, 215),
            ForeColor = Drawing.Color.White,
            FlatStyle = WinForms.FlatStyle.Flat,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
            Cursor = WinForms.Cursors.Hand
        };

        btnEjecutar.FlatAppearance.BorderSize = 0;
        btnEjecutar.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(0, 100, 190);
        btnEjecutar.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(0, 84, 160);

        btnEjecutar.Click += (s, e) =>
        {
            if (cmbTipoSuperior.SelectedItem == null)
            {
                WinForms.MessageBox.Show("Debe seleccionar el tipo de barra superior.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return;
            }

            if (!TieneDisenoLongitudinalManualV5() &&
                cmbTipoInferior.SelectedItem == null)
            {
                WinForms.MessageBox.Show("Debe seleccionar el tipo de barra inferior.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return;
            }

            if (!TieneDisenoLongitudinalManualV5() &&
                AceroCentral && cmbTipoCentral.SelectedItem == null)
            {
                WinForms.MessageBox.Show("Debe seleccionar el tipo de barra central.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return;
            }

            if (!TieneDisenoLongitudinalManualV5() &&
                string.IsNullOrWhiteSpace(txtCantidadSuperior.Text))
            {
                WinForms.MessageBox.Show("Debe ingresar la cantidad de barras superiores.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return;
            }

            if (!TieneDisenoLongitudinalManualV5() &&
                string.IsNullOrWhiteSpace(txtCantidadInferior.Text))
            {
                WinForms.MessageBox.Show("Debe ingresar la cantidad de barras inferiores.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return;
            }

            if (!TieneDisenoLongitudinalManualV5() &&
                !ValidarCapasLongitudinalesEnVentana())
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(txtRecubrimiento.Text))
            {
                WinForms.MessageBox.Show("Debe ingresar el recubrimiento.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return;
            }

            if (CrearEmpalmes)
            {
                if (UsarRNE)
                {
                    CalcularYAplicarEmpalmeRNE();

                    if (empalmeRNESuperiorCm <= 0.0 || empalmeRNEInferiorCm <= 0.0)
                    {
                        WinForms.MessageBox.Show("No se pudo calcular la longitud de empalme RNE. Verifique los tipos de barra superior e inferior.", "MYG",
                            WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                        return;
                    }
                }
                else
                {
                    if (!TextoNumeroMayorCero(txtLongitudEmpalme.Text))
                    {
                        WinForms.MessageBox.Show("Debe ingresar una longitud de empalme válida mayor que cero.", "MYG",
                            WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                        return;
                    }
                }

                if (!TextoNumeroMayorCero(txtLongitudBarra.Text))
                {
                    WinForms.MessageBox.Show("Debe ingresar una longitud de barra válida mayor que cero.", "MYG",
                        WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                    return;
                }
            }

            if (GanchoInicio && string.IsNullOrWhiteSpace(txtLongitudGanchoInicio.Text))
            {
                WinForms.MessageBox.Show("Debe ingresar la longitud de gancho del extremo inicial.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return;
            }

            if (GanchoFin && string.IsNullOrWhiteSpace(txtLongitudGanchoFin.Text))
            {
                WinForms.MessageBox.Show("Debe ingresar la longitud de gancho del extremo final.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return;
            }

            if (LongitudDesarrolloInicioHabilitada &&
                string.IsNullOrWhiteSpace(txtLongitudDesarrolloInicio.Text))
            {
                WinForms.MessageBox.Show("Debe ingresar la longitud de desarrollo del extremo inicial.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return;
            }

            if (LongitudDesarrolloFinHabilitada &&
                string.IsNullOrWhiteSpace(txtLongitudDesarrolloFin.Text))
            {
                WinForms.MessageBox.Show("Debe ingresar la longitud de desarrollo del extremo final.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return;
            }

            ModeloPreviewActual = ObtenerModeloPreviewActual();

            EjecutarEvent?.Raise();
        };

        grpExtremosLongitudinalesPrincipal = new WinForms.GroupBox()
        {
            Text = "Extremos de acero longitudinal",
            Left = 20,
            Top = 218,
            Width = 720,
            Height = 105,
            Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.FromArgb(50, 50, 50)
        };

        WinForms.GroupBox grpExtremosLongitudinales =
            grpExtremosLongitudinalesPrincipal;

        grpExtremoInicioPrincipal = CrearGrupoExtremoInicio();
        grpExtremoFinPrincipal = CrearGrupoExtremoFin();

        WinForms.GroupBox grpExtremoInicio = grpExtremoInicioPrincipal;
        WinForms.GroupBox grpExtremoFin = grpExtremoFinPrincipal;

        grpExtremoInicio.Left = 15;
        grpExtremoInicio.Top = 18;
        grpExtremoInicio.Width = 335;
        grpExtremoInicio.Height = 78;

        grpExtremoFin.Left = 370;
        grpExtremoFin.Top = 18;
        grpExtremoFin.Width = 335;
        grpExtremoFin.Height = 78;

        grpExtremosLongitudinales.Controls.Add(grpExtremoInicio);
        grpExtremosLongitudinales.Controls.Add(grpExtremoFin);

        grpPreviewLocal = new WinForms.GroupBox()
        {
            Text = "Vista preliminar",
            Left = 20,
            Top = 502,
            Width = 720,
            Height = 310,
            Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.FromArgb(50, 50, 50)
        };

        WinForms.GroupBox grpPreview = grpPreviewLocal;

        lblVistaInfo = new WinForms.Label()
        {
            Text = "La vista preliminar se actualizará al seleccionar las vigas.",
            Left = 15,
            Top = 22,
            Width = 500,
            Height = 20,
            ForeColor = Drawing.Color.Gray,
            Font = new Drawing.Font("Segoe UI", 8F)
        };

        chkGraficarEstribosCreados = new WinForms.CheckBox()
        {
            Text = "Graficar estribos",
            Left = 535,
            Top = 20,
            Width = 155,
            Height = 22,
            Checked = false,
            Enabled = true,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold)
        };

        chkGraficarEstribosCreados.CheckedChanged += (s, e) =>
        {
            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        panelPreview = new VistaPreviaPanel()
        {
            Left = 15,
            Top = 50,
            Width = 690,
            Height = 210,
            BackColor = Drawing.Color.White,
            BorderStyle = WinForms.BorderStyle.FixedSingle
        };

        panelPreview.Paint += DibujarVistaPrevia;

        InicializarNavegacionVistaPrevia2D();

        grpPreview.Controls.Add(lblVistaInfo);
        grpPreview.Controls.Add(chkGraficarEstribosCreados);
        grpPreview.Controls.Add(panelPreview);

        Controls.Add(lblTituloPrincipal);
        Controls.Add(lblDescripcionPrincipal);
        Controls.Add(grpParametros);
        Controls.Add(lblCantidad);
        Controls.Add(grpExtremosLongitudinales);
        // La vista preliminar longitudinal vive en el MAIN. El grupo local se
        // conserva para compatibilidad, pero no se muestra en esta pestaña.
        grpPreview.Visible = false;
        Controls.Add(grpPreview);
        Controls.Add(btnEjecutar);

        CrearPanelEditorSeccionIntegrado();
        CrearPanelConfiguracionUnificadaLongitudinal();
        this.Resize += (s, e) => AjustarLayoutEditorSeccionIntegrado();
        this.FormClosed += (s, e) =>
        {
            LimpiarPanelesEditorUnificadoLongitudinal();
            if (editorSeccionIntegrado != null &&
                !editorSeccionIntegrado.IsDisposed)
            {
                editorSeccionIntegrado.Dispose();
            }
        };

        this.AcceptButton = btnEjecutar;
        this.AutoScroll = false;
        AjustarLayoutEditorSeccionIntegrado();

        ActualizarEstadoAceroCentral();
        ActualizarEstadoEmpalmes();
        ActualizarEstadoRNE();
        ActualizarEstadoGanchoExtremos();
        ActualizarEstadoDesarrolloPorVoladizo();
        ActualizarVisibilidadCapasLongitudinales();
    }

    private bool ValidarCapasLongitudinalesEnVentana()
    {
        if (CapasSuperiores >= 2)
        {
            if (cmbTipoSuperiorCapa2 == null || cmbTipoSuperiorCapa2.SelectedItem == null)
            {
                WinForms.MessageBox.Show("Debe seleccionar el tipo de barra superior de la capa 2.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return false;
            }

            if (!TextoNumeroMayorCero(CantidadSuperiorCapa2Texto))
            {
                WinForms.MessageBox.Show("Debe ingresar una cantidad válida para la capa superior 2.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return false;
            }
        }

        if (CapasSuperiores >= 3)
        {
            if (cmbTipoSuperiorCapa3 == null || cmbTipoSuperiorCapa3.SelectedItem == null)
            {
                WinForms.MessageBox.Show("Debe seleccionar el tipo de barra superior de la capa 3.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return false;
            }

            if (!TextoNumeroMayorCero(CantidadSuperiorCapa3Texto))
            {
                WinForms.MessageBox.Show("Debe ingresar una cantidad válida para la capa superior 3.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return false;
            }
        }

        if (CapasSuperiores >= 4)
        {
            if (cmbTipoSuperiorCapa4 == null || cmbTipoSuperiorCapa4.SelectedItem == null)
            {
                WinForms.MessageBox.Show("Debe seleccionar el tipo de barra superior de la capa 4.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return false;
            }

            if (!TextoNumeroMayorCero(CantidadSuperiorCapa4Texto))
            {
                WinForms.MessageBox.Show("Debe ingresar una cantidad válida para la capa superior 4.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return false;
            }
        }

        if (CapasInferiores >= 2)
        {
            if (cmbTipoInferiorCapa2 == null || cmbTipoInferiorCapa2.SelectedItem == null)
            {
                WinForms.MessageBox.Show("Debe seleccionar el tipo de barra inferior de la capa 2.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return false;
            }

            if (!TextoNumeroMayorCero(CantidadInferiorCapa2Texto))
            {
                WinForms.MessageBox.Show("Debe ingresar una cantidad válida para la capa inferior 2.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return false;
            }
        }

        if (CapasInferiores >= 3)
        {
            if (cmbTipoInferiorCapa3 == null || cmbTipoInferiorCapa3.SelectedItem == null)
            {
                WinForms.MessageBox.Show("Debe seleccionar el tipo de barra inferior de la capa 3.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return false;
            }

            if (!TextoNumeroMayorCero(CantidadInferiorCapa3Texto))
            {
                WinForms.MessageBox.Show("Debe ingresar una cantidad válida para la capa inferior 3.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return false;
            }
        }

        if (CapasInferiores >= 4)
        {
            if (cmbTipoInferiorCapa4 == null || cmbTipoInferiorCapa4.SelectedItem == null)
            {
                WinForms.MessageBox.Show("Debe seleccionar el tipo de barra inferior de la capa 4.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return false;
            }

            if (!TextoNumeroMayorCero(CantidadInferiorCapa4Texto))
            {
                WinForms.MessageBox.Show("Debe ingresar una cantidad válida para la capa inferior 4.", "MYG",
                    WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning);
                return false;
            }
        }

        if (CapasSuperiores >= 2 || CapasInferiores >= 2)
        {
            double separacionMm;

            if (!TryConvertirLongitudTextoAMmMYG(
                SeparacionCapasTexto,
                out separacionMm) ||
                separacionMm <= 0.0)
            {
                WinForms.MessageBox.Show(
                    "Debe ingresar una separación entre capas válida.\n\n" +
                    "Ejemplos: 2in, 2\", 5cm, 50mm o 0.05m.",
                    "MYG",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Warning);

                return false;
            }
        }

        return true;
    }

    private void ActualizarVisibilidadCapasLongitudinales()
    {
        if (usarEditorManualUnificadoV5)
        {
            AplicarVisibilidadControl(lblTipoSuperiorCapa2, false);
            AplicarVisibilidadControl(cmbTipoSuperiorCapa2, false);
            AplicarVisibilidadControl(lblCantidadSuperiorCapa2, false);
            AplicarVisibilidadControl(txtCantidadSuperiorCapa2, false);
            AplicarVisibilidadControl(lblTipoSuperiorCapa3, false);
            AplicarVisibilidadControl(cmbTipoSuperiorCapa3, false);
            AplicarVisibilidadControl(lblCantidadSuperiorCapa3, false);
            AplicarVisibilidadControl(txtCantidadSuperiorCapa3, false);
            AplicarVisibilidadControl(lblTipoSuperiorCapa4, false);
            AplicarVisibilidadControl(cmbTipoSuperiorCapa4, false);
            AplicarVisibilidadControl(lblCantidadSuperiorCapa4, false);
            AplicarVisibilidadControl(txtCantidadSuperiorCapa4, false);
            AplicarVisibilidadControl(lblTipoInferiorCapa2, false);
            AplicarVisibilidadControl(cmbTipoInferiorCapa2, false);
            AplicarVisibilidadControl(lblCantidadInferiorCapa2, false);
            AplicarVisibilidadControl(txtCantidadInferiorCapa2, false);
            AplicarVisibilidadControl(lblTipoInferiorCapa3, false);
            AplicarVisibilidadControl(cmbTipoInferiorCapa3, false);
            AplicarVisibilidadControl(lblCantidadInferiorCapa3, false);
            AplicarVisibilidadControl(txtCantidadInferiorCapa3, false);
            AplicarVisibilidadControl(lblTipoInferiorCapa4, false);
            AplicarVisibilidadControl(cmbTipoInferiorCapa4, false);
            AplicarVisibilidadControl(lblCantidadInferiorCapa4, false);
            AplicarVisibilidadControl(txtCantidadInferiorCapa4, false);
            AplicarVisibilidadControl(lblSeparacionCapas, false);
            AplicarVisibilidadControl(txtSeparacionCapas, false);
            AplicarVisibilidadControl(lblAyudaSeparacionCapas, false);
            return;
        }

        int capasSup = CapasSuperiores;
        int capasInf = CapasInferiores;

        AplicarVisibilidadControl(lblTipoSuperiorCapa2, capasSup >= 2);
        AplicarVisibilidadControl(cmbTipoSuperiorCapa2, capasSup >= 2);
        AplicarVisibilidadControl(lblCantidadSuperiorCapa2, capasSup >= 2);
        AplicarVisibilidadControl(txtCantidadSuperiorCapa2, capasSup >= 2);

        AplicarVisibilidadControl(lblTipoSuperiorCapa3, capasSup >= 3);
        AplicarVisibilidadControl(cmbTipoSuperiorCapa3, capasSup >= 3);
        AplicarVisibilidadControl(lblCantidadSuperiorCapa3, capasSup >= 3);
        AplicarVisibilidadControl(txtCantidadSuperiorCapa3, capasSup >= 3);

        AplicarVisibilidadControl(lblTipoSuperiorCapa4, capasSup >= 4);
        AplicarVisibilidadControl(cmbTipoSuperiorCapa4, capasSup >= 4);
        AplicarVisibilidadControl(lblCantidadSuperiorCapa4, capasSup >= 4);
        AplicarVisibilidadControl(txtCantidadSuperiorCapa4, capasSup >= 4);

        AplicarVisibilidadControl(lblTipoInferiorCapa2, capasInf >= 2);
        AplicarVisibilidadControl(cmbTipoInferiorCapa2, capasInf >= 2);
        AplicarVisibilidadControl(lblCantidadInferiorCapa2, capasInf >= 2);
        AplicarVisibilidadControl(txtCantidadInferiorCapa2, capasInf >= 2);

        AplicarVisibilidadControl(lblTipoInferiorCapa3, capasInf >= 3);
        AplicarVisibilidadControl(cmbTipoInferiorCapa3, capasInf >= 3);
        AplicarVisibilidadControl(lblCantidadInferiorCapa3, capasInf >= 3);
        AplicarVisibilidadControl(txtCantidadInferiorCapa3, capasInf >= 3);

        AplicarVisibilidadControl(lblTipoInferiorCapa4, capasInf >= 4);
        AplicarVisibilidadControl(cmbTipoInferiorCapa4, capasInf >= 4);
        AplicarVisibilidadControl(lblCantidadInferiorCapa4, capasInf >= 4);
        AplicarVisibilidadControl(txtCantidadInferiorCapa4, capasInf >= 4);

        bool mostrarSeparacionCapas = capasSup >= 2 || capasInf >= 2;
        AplicarVisibilidadControl(lblSeparacionCapas, mostrarSeparacionCapas);
        AplicarVisibilidadControl(txtSeparacionCapas, mostrarSeparacionCapas);
        AplicarVisibilidadControl(lblAyudaSeparacionCapas, mostrarSeparacionCapas);

        AsegurarSeleccionComboCapa(cmbTipoSuperiorCapa2, cmbTipoSuperior);
        AsegurarSeleccionComboCapa(cmbTipoSuperiorCapa3, cmbTipoSuperior);
        AsegurarSeleccionComboCapa(cmbTipoSuperiorCapa4, cmbTipoSuperior);
        AsegurarSeleccionComboCapa(cmbTipoInferiorCapa2, cmbTipoInferior);
        AsegurarSeleccionComboCapa(cmbTipoInferiorCapa3, cmbTipoInferior);
        AsegurarSeleccionComboCapa(cmbTipoInferiorCapa4, cmbTipoInferior);
    }

    private double ObtenerSeparacionCapasMmMYG()
    {
        double separacionMm;

        if (TryConvertirLongitudTextoAMmMYG(
            SeparacionCapasTexto,
            out separacionMm) &&
            separacionMm > 0.0)
        {
            return separacionMm;
        }

        return 25.4;
    }

    private bool TryConvertirLongitudTextoAMmMYG(
        string texto,
        out double valorMm)
    {
        valorMm = 0.0;

        if (string.IsNullOrWhiteSpace(texto))
            return false;

        string t = texto
            .Trim()
            .ToLowerInvariant()
            .Replace(",", ".")
            .Replace("pulgadas", "in")
            .Replace("pulgada", "in")
            .Replace("pulg", "in")
            .Replace("inches", "in")
            .Replace("inch", "in");

        double factorMm = 1000.0;
        string numero = t;

        if (t.EndsWith("mm"))
        {
            factorMm = 1.0;
            numero = t.Substring(0, t.Length - 2);
        }
        else if (t.EndsWith("cm"))
        {
            factorMm = 10.0;
            numero = t.Substring(0, t.Length - 2);
        }
        else if (t.EndsWith("in"))
        {
            factorMm = 25.4;
            numero = t.Substring(0, t.Length - 2);
        }
        else if (t.EndsWith("\""))
        {
            factorMm = 25.4;
            numero = t.Substring(0, t.Length - 1);
        }
        else if (t.EndsWith("ft"))
        {
            factorMm = 304.8;
            numero = t.Substring(0, t.Length - 2);
        }
        else if (t.EndsWith("'"))
        {
            factorMm = 304.8;
            numero = t.Substring(0, t.Length - 1);
        }
        else if (t.EndsWith("m"))
        {
            factorMm = 1000.0;
            numero = t.Substring(0, t.Length - 1);
        }

        double valor;

        if (!double.TryParse(
            numero.Trim(),
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture,
            out valor))
        {
            return false;
        }

        if (valor <= 0.0)
            return false;

        valorMm = valor * factorMm;

        return valorMm > 0.0;
    }

    private void AplicarVisibilidadControl(WinForms.Control control, bool visible)
    {
        if (control == null)
            return;

        control.Visible = visible;
        control.Enabled = visible;
    }

    private void AsegurarSeleccionComboCapa(WinForms.ComboBox comboCapa, WinForms.ComboBox comboBase)
    {
        if (comboCapa == null || comboCapa.Items.Count == 0)
            return;

        if (comboCapa.SelectedItem != null)
            return;

        if (comboBase != null && comboBase.SelectedItem != null && comboCapa.Items.Contains(comboBase.SelectedItem))
        {
            comboCapa.SelectedItem = comboBase.SelectedItem;
            return;
        }

        comboCapa.SelectedIndex = 0;
    }

    private void ActualizarEstadoAceroCentral()
    {
        bool activo = chkAceroCentral != null && chkAceroCentral.Checked;

        if (cmbTipoCentral != null)
        {
            cmbTipoCentral.Enabled = activo;
            cmbTipoCentral.BackColor = activo
                ? Drawing.SystemColors.Window
                : Drawing.Color.FromArgb(235, 235, 235);
        }

        if (lblTipoCentral != null)
            lblTipoCentral.Enabled = activo;

        if (lblCantidadCentralFija != null)
            lblCantidadCentralFija.Enabled = activo;

        if (lblColorCentral != null)
        {
            lblColorCentral.ForeColor = activo
                ? ColorAceroCentral
                : Drawing.Color.Gray;
        }
    }

    private void ActualizarEstadoEmpalmes()
    {
        bool activo = chkCrearEmpalmes != null && chkCrearEmpalmes.Checked;
        bool usarRNE = chkUsarRNE != null && chkUsarRNE.Checked;

        if (lblLongitudEmpalme != null)
            lblLongitudEmpalme.Enabled = activo;

        if (txtLongitudEmpalme != null)
        {
            txtLongitudEmpalme.Enabled = activo && !usarRNE;
            txtLongitudEmpalme.ReadOnly = false;

            if (!activo || usarRNE)
                txtLongitudEmpalme.BackColor = Drawing.Color.FromArgb(235, 235, 235);
            else
                txtLongitudEmpalme.BackColor = Drawing.SystemColors.Window;
        }

        if (lblCmEmpalme != null)
            lblCmEmpalme.Enabled = activo && !usarRNE;

        if (lblLongitudBarra != null)
            lblLongitudBarra.Enabled = activo;

        if (txtLongitudBarra != null)
        {
            txtLongitudBarra.Enabled = activo;
            txtLongitudBarra.BackColor = activo
                ? Drawing.SystemColors.Window
                : Drawing.Color.FromArgb(235, 235, 235);
        }

        if (lblMBarra != null)
            lblMBarra.Enabled = activo;
    }

    // =====================================
    // RNE: EMPALME DIFERENCIADO
    // Superior = barra superior con Ψt = 1.30
    // Inferior/Central = barra inferior/central con Ψt = 1.00
    // =====================================
    private void ActualizarEstadoRNE()
    {
        bool usarRNE = chkUsarRNE != null && chkUsarRNE.Checked;
        bool crearEmpalmes = chkCrearEmpalmes != null && chkCrearEmpalmes.Checked;

        if (btnConfigRNE != null)
        {
            btnConfigRNE.Enabled = crearEmpalmes || usarRNE;
            btnConfigRNE.BackColor = usarRNE
                ? Drawing.Color.FromArgb(255, 255, 230)
                : Drawing.Color.FromArgb(245, 247, 250);
            btnConfigRNE.Text = usarRNE ? "RNE datos..." : "Usar RNE...";
        }

        if (cmbResistenciaRNE != null)
        {
            cmbResistenciaRNE.Enabled = usarRNE && crearEmpalmes;
            cmbResistenciaRNE.BackColor = (usarRNE && crearEmpalmes)
                ? Drawing.SystemColors.Window
                : Drawing.Color.FromArgb(235, 235, 235);
        }

        if (lblInfoRNE != null)
            lblInfoRNE.Visible = usarRNE && crearEmpalmes;

        if (usarRNE && crearEmpalmes)
        {
            if (txtLongitudEmpalme != null)
                txtLongitudEmpalme.Text = "";

            CalcularYAplicarEmpalmeRNE();
        }
        else
        {
            empalmeRNESuperiorCm = 0.0;
            empalmeRNEInferiorCm = 0.0;
            empalmeRNECentralCm = 0.0;

            if (lblInfoRNE != null)
                lblInfoRNE.Text = "";

            if (txtLongitudEmpalme != null && string.IsNullOrWhiteSpace(txtLongitudEmpalme.Text))
                txtLongitudEmpalme.Text = "60";
        }
    }

    private void CalcularYAplicarEmpalmeRNE()
    {
        if (!UsarRNE)
            return;

        if (rneFcKgCm2 <= 0.0)
            rneFcKgCm2 = 210.0;

        empalmeRNESuperiorCm = CalcularEmpalmeRNECm(TipoSuperiorSeleccionado, rneFcKgCm2, rnePsiSuperior);
        empalmeRNEInferiorCm = CalcularEmpalmeRNECm(TipoInferiorSeleccionado, rneFcKgCm2, rnePsiInferior);

        if (AceroCentral && TipoCentralSeleccionado != null)
            empalmeRNECentralCm = CalcularEmpalmeRNECm(TipoCentralSeleccionado, rneFcKgCm2, rnePsiCentral);
        else
            empalmeRNECentralCm = empalmeRNEInferiorCm;

        if (txtLongitudEmpalme != null)
            txtLongitudEmpalme.Text = "";

        SincronizarComboResistenciaRNE();
        ActualizarTextoInfoRNE();
    }

    private double CalcularEmpalmeRNECm(
        RebarBarType tipoBarra,
        double fcKgCm2,
        double psiT)
    {
        double dbMm = ObtenerDiametroBarraMm(tipoBarra);

        if (dbMm <= 0.0)
            return 0.0;

        double ldMm = CalcularLdRNEMm(dbMm, fcKgCm2, psiT);

        if (ldMm <= 0.0)
            return 0.0;

        double leMm = rneFactorEmpalme * ldMm;

        if (leMm < rneMinEmpalmeMm)
            leMm = rneMinEmpalmeMm;

        // Redondeo superior a centímetros para ir por lado seguro.
        return Math.Ceiling(leMm / 10.0);
    }

    private double CalcularLdRNEMm(
        double dbMm,
        double fcKgCm2,
        double psiT)
    {
        if (dbMm <= 0.0 || fcKgCm2 <= 0.0)
            return 0.0;

        // Conversión práctica usada en este flujo:
        // 210 kg/cm2 ≈ 21 MPa, 280 kg/cm2 ≈ 28 MPa.
        double fcMpa = fcKgCm2 / 10.0;

        if (fcMpa <= 0.0)
            return 0.0;

        double fyMpa = rneFyMpa <= 0.0 ? 420.0 : rneFyMpa;
        double psiE = rnePsiE <= 0.0 ? 1.0 : rnePsiE;
        double lambda = rneLambda <= 0.0 ? 1.0 : rneLambda;

        // Tabla 12.1 E.060:
        // Barras de 3/4" y menores: denominador 2.6
        // Barras mayores de 3/4": denominador 2.1
        double limiteTresCuartosMm = 19.05;
        double denominador = dbMm <= limiteTresCuartosMm ? 2.6 : 2.1;

        return (fyMpa * psiT * psiE * dbMm) /
            (denominador * lambda * Math.Sqrt(fcMpa));
    }

    private void ActualizarTextoInfoRNE()
    {
        if (lblInfoRNE == null)
            return;

        if (!UsarRNE || !CrearEmpalmes)
        {
            lblInfoRNE.Text = "";
            return;
        }

        string sup = empalmeRNESuperiorCm > 0.0
            ? FormatearCentimetrosEnteros(empalmeRNESuperiorCm) + " cm"
            : "--";

        string inf = empalmeRNEInferiorCm > 0.0
            ? FormatearCentimetrosEnteros(empalmeRNEInferiorCm) + " cm"
            : "--";

        string cen = empalmeRNECentralCm > 0.0
            ? FormatearCentimetrosEnteros(empalmeRNECentralCm) + " cm"
            : "--";

        if (AceroCentral)
            lblInfoRNE.Text = "RNE f'c " + FormatearCentimetrosEnteros(rneFcKgCm2) + " kg/cm2: Sup. " + sup + " | Inf. " + inf + " | Central " + cen;
        else
            lblInfoRNE.Text = "RNE f'c " + FormatearCentimetrosEnteros(rneFcKgCm2) + " kg/cm2: Sup. " + sup + " | Inf./Central " + inf;
    }

    private string FormatearCentimetrosEnteros(double valorCm)
    {
        if (valorCm <= 0.0)
            return "";

        return Math.Ceiling(valorCm).ToString(
            "0",
            System.Globalization.CultureInfo.InvariantCulture);
    }

    private double ObtenerResistenciaRNEKgCm2()
    {
        return rneFcKgCm2 <= 0.0 ? 210.0 : rneFcKgCm2;
    }

    private void SincronizarComboResistenciaRNE()
    {
        if (cmbResistenciaRNE == null)
            return;

        string valor = rneFcKgCm2.ToString("0", System.Globalization.CultureInfo.InvariantCulture) + " kg/cm2";

        int index = cmbResistenciaRNE.Items.IndexOf(valor);

        if (index >= 0 && cmbResistenciaRNE.SelectedIndex != index)
            cmbResistenciaRNE.SelectedIndex = index;
    }

    private void AbrirConfiguracionRNE()
    {
        // Al abrir desde Revit, si la ventana principal está TopMost,
        // el diálogo modal puede quedar visualmente detrás. Por eso se fuerza
        // el diálogo como TopMost y se activa al mostrarse.
        bool topMostAnterior = this.TopMost;

        try
        {
            if (chkCrearEmpalmes != null && !chkCrearEmpalmes.Checked)
                chkCrearEmpalmes.Checked = true;

            if (chkUsarRNE != null && !chkUsarRNE.Checked)
                chkUsarRNE.Checked = true;

            using (RNEEmpalmesConfigForm dlg = new RNEEmpalmesConfigForm())
            {
                dlg.FcKgCm2 = rneFcKgCm2;
                dlg.FyMpa = rneFyMpa;
                dlg.PsiE = rnePsiE;
                dlg.Lambda = rneLambda;
                dlg.FactorEmpalme = rneFactorEmpalme;
                dlg.MinEmpalmeMm = rneMinEmpalmeMm;
                dlg.PsiSuperior = rnePsiSuperior;
                dlg.PsiInferior = rnePsiInferior;
                dlg.PsiCentral = rnePsiCentral;

                dlg.NombreSuperior = ObtenerNombreTipoBarra(TipoSuperiorSeleccionado);
                dlg.NombreInferior = ObtenerNombreTipoBarra(TipoInferiorSeleccionado);
                dlg.NombreCentral = AceroCentral ? ObtenerNombreTipoBarra(TipoCentralSeleccionado) : "No activo";

                dlg.DbSuperiorMm = ObtenerDiametroBarraMm(TipoSuperiorSeleccionado);
                dlg.DbInferiorMm = ObtenerDiametroBarraMm(TipoInferiorSeleccionado);
                dlg.DbCentralMm = AceroCentral ? ObtenerDiametroBarraMm(TipoCentralSeleccionado) : 0.0;
                dlg.MostrarCentral = AceroCentral;

                dlg.StartPosition = WinForms.FormStartPosition.CenterParent;
                dlg.ShowInTaskbar = false;
                dlg.TopMost = true;

                dlg.Shown += (s, e) =>
                {
                    try
                    {
                        dlg.WindowState = WinForms.FormWindowState.Normal;
                        dlg.TopMost = true;
                        dlg.BringToFront();
                        dlg.Activate();
                        dlg.Focus();
                    }
                    catch
                    {
                        // No interrumpir si Windows no permite forzar foco.
                    }
                };

                // Baja temporalmente el TopMost del form principal para que el diálogo no quede detrás.
                this.TopMost = false;

                WinForms.DialogResult result = dlg.ShowDialog(this);

                if (result != WinForms.DialogResult.OK)
                    return;

                rneFcKgCm2 = dlg.FcKgCm2;
                rneFyMpa = dlg.FyMpa;
                rnePsiE = dlg.PsiE;
                rneLambda = dlg.Lambda;
                rneFactorEmpalme = dlg.FactorEmpalme;
                rneMinEmpalmeMm = dlg.MinEmpalmeMm;
                rnePsiSuperior = dlg.PsiSuperior;
                rnePsiInferior = dlg.PsiInferior;
                rnePsiCentral = dlg.PsiCentral;
            }

            SincronizarComboResistenciaRNE();
            ActualizarEstadoEmpalmes();
            ActualizarEstadoRNE();

            RefrescarPreviewLongitudinalEnTiempoReal();
        }
        finally
        {
            this.TopMost = topMostAnterior;

            try
            {
                this.BringToFront();
                this.Activate();
            }
            catch
            {
                // No interrumpir si Revit controla el foco.
            }
        }
    }

    private string ObtenerNombreTipoBarra(RebarBarType tipo)
    {
        if (tipo == null)
            return "--";

        try
        {
            return tipo.Name;
        }
        catch
        {
            return "--";
        }
    }

    private double ObtenerDiametroBarraMm(RebarBarType tipo)
    {
        if (tipo == null)
            return 0.0;

        // 1) Intenta leer por parámetros del tipo de barra.
        string[] nombresParametros =
        {
            "Diámetro de barra",
            "Diámetro de barra de modelo",
            "Bar Diameter",
            "Model Bar Diameter",
            "Nominal Diameter",
            "Diámetro nominal"
        };

        foreach (string nombre in nombresParametros)
        {
            try
            {
                Parameter p = tipo.LookupParameter(nombre);

                if (p != null && p.StorageType == StorageType.Double)
                {
                    double valorInterno = p.AsDouble();

                    if (valorInterno > 0.0)
                    {
                        double mm = UnitUtils.ConvertFromInternalUnits(
                            valorInterno,
                            UnitTypeId.Millimeters);

                        if (mm > 0.0)
                            return mm;
                    }
                }
            }
            catch
            {
                // Si no existe el parámetro, continúa con el siguiente.
            }
        }

        // 2) Intenta obtener por reflexión si la API expone alguna propiedad.
        string[] propiedades =
        {
            "BarDiameter",
            "BarModelDiameter",
            "BarNominalDiameter",
            "NominalDiameter"
        };

        foreach (string propName in propiedades)
        {
            try
            {
                System.Reflection.PropertyInfo prop =
                    tipo.GetType().GetProperty(propName);

                if (prop == null)
                    continue;

                object valorObj = prop.GetValue(tipo, null);

                if (valorObj == null)
                    continue;

                double valor = 0.0;

                if (valorObj is double)
                    valor = (double)valorObj;
                else
                {
                    double.TryParse(
                        valorObj.ToString().Replace(",", "."),
                        System.Globalization.NumberStyles.Any,
                        System.Globalization.CultureInfo.InvariantCulture,
                        out valor);
                }

                if (valor > 0.0)
                {
                    double mm = UnitUtils.ConvertFromInternalUnits(
                        valor,
                        UnitTypeId.Millimeters);

                    if (mm > 0.0)
                        return mm;
                }
            }
            catch
            {
                // Continúa con la siguiente alternativa.
            }
        }

        // 3) Fallback: intenta leer el diámetro desde el nombre del tipo.
        return ObtenerDiametroDesdeNombreTipo(tipo.Name);
    }

    private double ObtenerDiametroDesdeNombreTipo(string nombre)
    {
        if (string.IsNullOrWhiteSpace(nombre))
            return 0.0;

        string t = nombre.Trim().ToUpperInvariant();

        // Casos típicos en pulgadas.
        if (t.Contains("3/8"))
            return 9.525;

        if (t.Contains("1/2"))
            return 12.700;

        if (t.Contains("5/8"))
            return 15.875;

        if (t.Contains("3/4"))
            return 19.050;

        if (t.Contains("7/8"))
            return 22.225;

        if (t.Contains("1\"") || t.Contains("1''") || t.Contains(" 1 "))
            return 25.400;

        // Casos típicos por nombre métrico: "10 B 400 S", "12 B 420", etc.
        System.Text.RegularExpressions.Match m =
            System.Text.RegularExpressions.Regex.Match(
                t.Replace(",", "."),
                @"\d+(\.\d+)?");

        if (m.Success)
        {
            double valor = 0.0;

            if (double.TryParse(
                m.Value,
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out valor))
            {
                if (valor > 0.0 && valor <= 60.0)
                    return valor;
            }
        }

        return 0.0;
    }

    private WinForms.GroupBox CrearGrupoExtremoInicio()
    {
        WinForms.GroupBox grp = new WinForms.GroupBox()
        {
            Text = "Extremo inicial",
            Left = 15,
            Top = 45,
            Width = 335,
            Height = 82,
            Font = new Drawing.Font("Segoe UI", 8.2F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.FromArgb(50, 50, 50)
        };

        chkGanchoInicio = new WinForms.CheckBox()
        {
            Text = "Gancho",
            Left = 10,
            Top = 22,
            Width = 75,
            Height = 20,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Font = new Drawing.Font("Segoe UI", 8F)
        };

        lblLongitudGanchoInicio = new WinForms.Label()
        {
            Text = "L. gancho:",
            Left = 85,
            Top = 23,
            Width = 78,
            Height = 20,
            Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold)
        };

        txtLongitudGanchoInicio = new WinForms.TextBox()
        {
            Left = 165,
            Top = 20,
            Width = 45,
            Height = 22,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "15"
        };

        lblCmGanchoInicio = new WinForms.Label()
        {
            Text = "cm",
            Left = 215,
            Top = 23,
            Width = 25,
            Height = 20,
            ForeColor = Drawing.Color.Gray,
            Font = new Drawing.Font("Segoe UI", 8F)
        };

        lblLongitudDesarrolloInicio = new WinForms.Label()
        {
            Text = "L. desarrollo:",
            Left = 10,
            Top = 52,
            Width = 98,
            Height = 20,
            Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold)
        };

        txtLongitudDesarrolloInicio = new WinForms.TextBox()
        {
            Left = 110,
            Top = 49,
            Width = 45,
            Height = 22,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "60"
        };

        lblCmDesarrolloInicio = new WinForms.Label()
        {
            Text = "cm",
            Left = 160,
            Top = 52,
            Width = 25,
            Height = 20,
            ForeColor = Drawing.Color.Gray,
            Font = new Drawing.Font("Segoe UI", 8F)
        };

        chkDesarrolloAutomaticoInicio = new WinForms.CheckBox()
        {
            Text = "Auto",
            Left = 190,
            Top = 50,
            Width = 58,
            Height = 20,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Checked = false,
            Font = new Drawing.Font("Segoe UI", 8F),
            Cursor = WinForms.Cursors.Hand
        };

        lblEstadoInicio = new WinForms.Label()
        {
            Text = "",
            Left = 252,
            Top = 52,
            Width = 75,
            Height = 20,
            ForeColor = Drawing.Color.Gray,
            Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold)
        };

        chkGanchoInicio.CheckedChanged += (s, e) =>
        {
            ActualizarEstadoGanchoExtremos();

            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        chkDesarrolloAutomaticoInicio.CheckedChanged += (s, e) =>
        {
            ActualizarEstadoDesarrolloPorVoladizo();
            ActualizarTextoDesarrolloAutomaticoInicio();
            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        txtLongitudGanchoInicio.TextChanged += (s, e) =>
        {
            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        txtLongitudDesarrolloInicio.TextChanged += (s, e) =>
        {
            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        grp.Controls.Add(chkGanchoInicio);
        grp.Controls.Add(lblLongitudGanchoInicio);
        grp.Controls.Add(txtLongitudGanchoInicio);
        grp.Controls.Add(lblCmGanchoInicio);
        grp.Controls.Add(lblLongitudDesarrolloInicio);
        grp.Controls.Add(txtLongitudDesarrolloInicio);
        grp.Controls.Add(lblCmDesarrolloInicio);
        grp.Controls.Add(chkDesarrolloAutomaticoInicio);
        grp.Controls.Add(lblEstadoInicio);

        return grp;
    }

    private WinForms.GroupBox CrearGrupoExtremoFin()
    {
        WinForms.GroupBox grp = new WinForms.GroupBox()
        {
            Text = "Extremo final",
            Left = 370,
            Top = 45,
            Width = 335,
            Height = 82,
            Font = new Drawing.Font("Segoe UI", 8.2F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.FromArgb(50, 50, 50)
        };

        chkGanchoFin = new WinForms.CheckBox()
        {
            Text = "Gancho",
            Left = 10,
            Top = 22,
            Width = 75,
            Height = 20,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Font = new Drawing.Font("Segoe UI", 8F)
        };

        lblLongitudGanchoFin = new WinForms.Label()
        {
            Text = "L. gancho:",
            Left = 85,
            Top = 23,
            Width = 78,
            Height = 20,
            Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold)
        };

        txtLongitudGanchoFin = new WinForms.TextBox()
        {
            Left = 165,
            Top = 20,
            Width = 45,
            Height = 22,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "15"
        };

        lblCmGanchoFin = new WinForms.Label()
        {
            Text = "cm",
            Left = 215,
            Top = 23,
            Width = 25,
            Height = 20,
            ForeColor = Drawing.Color.Gray,
            Font = new Drawing.Font("Segoe UI", 8F)
        };

        lblLongitudDesarrolloFin = new WinForms.Label()
        {
            Text = "L. desarrollo:",
            Left = 10,
            Top = 52,
            Width = 98,
            Height = 20,
            Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold)
        };

        txtLongitudDesarrolloFin = new WinForms.TextBox()
        {
            Left = 110,
            Top = 49,
            Width = 45,
            Height = 22,
            BorderStyle = WinForms.BorderStyle.FixedSingle,
            Text = "60"
        };

        lblCmDesarrolloFin = new WinForms.Label()
        {
            Text = "cm",
            Left = 160,
            Top = 52,
            Width = 25,
            Height = 20,
            ForeColor = Drawing.Color.Gray,
            Font = new Drawing.Font("Segoe UI", 8F)
        };

        chkDesarrolloAutomaticoFin = new WinForms.CheckBox()
        {
            Text = "Auto",
            Left = 190,
            Top = 50,
            Width = 58,
            Height = 20,
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            Checked = false,
            Font = new Drawing.Font("Segoe UI", 8F),
            Cursor = WinForms.Cursors.Hand
        };

        lblEstadoFin = new WinForms.Label()
        {
            Text = "",
            Left = 252,
            Top = 52,
            Width = 75,
            Height = 20,
            ForeColor = Drawing.Color.Gray,
            Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold)
        };

        chkGanchoFin.CheckedChanged += (s, e) =>
        {
            ActualizarEstadoGanchoExtremos();

            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        chkDesarrolloAutomaticoFin.CheckedChanged += (s, e) =>
        {
            ActualizarEstadoDesarrolloPorVoladizo();
            ActualizarTextoDesarrolloAutomaticoFin();
            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        txtLongitudGanchoFin.TextChanged += (s, e) =>
        {
            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        txtLongitudDesarrolloFin.TextChanged += (s, e) =>
        {
            RefrescarPreviewLongitudinalEnTiempoReal();
        };

        grp.Controls.Add(chkGanchoFin);
        grp.Controls.Add(lblLongitudGanchoFin);
        grp.Controls.Add(txtLongitudGanchoFin);
        grp.Controls.Add(lblCmGanchoFin);
        grp.Controls.Add(lblLongitudDesarrolloFin);
        grp.Controls.Add(txtLongitudDesarrolloFin);
        grp.Controls.Add(lblCmDesarrolloFin);
        grp.Controls.Add(chkDesarrolloAutomaticoFin);
        grp.Controls.Add(lblEstadoFin);

        return grp;
    }

    private void ActualizarEstadoGanchoExtremos()
    {
        bool inicio = chkGanchoInicio != null && chkGanchoInicio.Checked;
        bool fin = chkGanchoFin != null && chkGanchoFin.Checked;

        if (txtLongitudGanchoInicio != null)
            txtLongitudGanchoInicio.Enabled = inicio;

        if (lblLongitudGanchoInicio != null)
            lblLongitudGanchoInicio.Enabled = inicio;

        if (lblCmGanchoInicio != null)
            lblCmGanchoInicio.Enabled = inicio;

        if (txtLongitudGanchoFin != null)
            txtLongitudGanchoFin.Enabled = fin;

        if (lblLongitudGanchoFin != null)
            lblLongitudGanchoFin.Enabled = fin;

        if (lblCmGanchoFin != null)
            lblCmGanchoFin.Enabled = fin;
    }

    private void ActualizarEstadoDesarrolloPorVoladizo()
    {
        if (txtLongitudDesarrolloInicio == null ||
            txtLongitudDesarrolloFin == null)
        {
            return;
        }

        AplicarEstadoDesarrolloInicio(desarrolloInicioDisponible);
        AplicarEstadoDesarrolloFin(desarrolloFinDisponible);
    }

    private void AplicarEstadoDesarrolloInicio(bool tieneColumna)
    {
        desarrolloInicioDisponible = tieneColumna;

        if (chkDesarrolloAutomaticoInicio != null)
        {
            chkDesarrolloAutomaticoInicio.Enabled = tieneColumna;

            if (!tieneColumna && chkDesarrolloAutomaticoInicio.Checked)
                chkDesarrolloAutomaticoInicio.Checked = false;
        }

        bool automatico = tieneColumna && DesarrolloAutomaticoInicio;

        // Regla solicitada:
        // - Auto activado y con columna: el campo muestra el cálculo y no se edita.
        // - Auto desactivado: el campo manual siempre se puede editar.
        bool editable = !automatico;

        txtLongitudDesarrolloInicio.Enabled = editable;
        lblLongitudDesarrolloInicio.Enabled = true;
        lblCmDesarrolloInicio.Enabled = true;

        txtLongitudDesarrolloInicio.BackColor = editable
            ? Drawing.SystemColors.Window
            : Drawing.Color.FromArgb(235, 235, 235);

        if (automatico)
            lblEstadoInicio.Text = "Auto";
        else if (!tieneColumna)
            lblEstadoInicio.Text = "Manual";
        else
            lblEstadoInicio.Text = "";

        lblEstadoInicio.ForeColor = Drawing.Color.Gray;

        if (automatico)
            ActualizarTextoDesarrolloAutomaticoInicio();
    }

    private void AplicarEstadoDesarrolloFin(bool tieneColumna)
    {
        desarrolloFinDisponible = tieneColumna;

        if (chkDesarrolloAutomaticoFin != null)
        {
            chkDesarrolloAutomaticoFin.Enabled = tieneColumna;

            if (!tieneColumna && chkDesarrolloAutomaticoFin.Checked)
                chkDesarrolloAutomaticoFin.Checked = false;
        }

        bool automatico = tieneColumna && DesarrolloAutomaticoFin;
        bool editable = !automatico;

        txtLongitudDesarrolloFin.Enabled = editable;
        lblLongitudDesarrolloFin.Enabled = true;
        lblCmDesarrolloFin.Enabled = true;

        txtLongitudDesarrolloFin.BackColor = editable
            ? Drawing.SystemColors.Window
            : Drawing.Color.FromArgb(235, 235, 235);

        if (automatico)
            lblEstadoFin.Text = "Auto";
        else if (!tieneColumna)
            lblEstadoFin.Text = "Manual";
        else
            lblEstadoFin.Text = "";

        lblEstadoFin.ForeColor = Drawing.Color.Gray;

        if (automatico)
            ActualizarTextoDesarrolloAutomaticoFin();
    }

    private void ActualizarTextosDesarrolloAutomatico()
    {
        if (DesarrolloAutomaticoInicio && desarrolloInicioDisponible)
            ActualizarTextoDesarrolloAutomaticoInicio();

        if (DesarrolloAutomaticoFin && desarrolloFinDisponible)
            ActualizarTextoDesarrolloAutomaticoFin();
    }

    private void ActualizarTextoDesarrolloAutomaticoInicio()
    {
        if (txtLongitudDesarrolloInicio == null)
            return;

        if (!desarrolloInicioDisponible || !DesarrolloAutomaticoInicio)
            return;

        txtLongitudDesarrolloInicio.Text =
            FormatearCmParaTexto(CalcularDesarrolloAutomaticoInicioCm());
    }

    private void ActualizarTextoDesarrolloAutomaticoFin()
    {
        if (txtLongitudDesarrolloFin == null)
            return;

        if (!desarrolloFinDisponible || !DesarrolloAutomaticoFin)
            return;

        txtLongitudDesarrolloFin.Text =
            FormatearCmParaTexto(CalcularDesarrolloAutomaticoFinCm());
    }

    private double CalcularDesarrolloAutomaticoInicioCm()
    {
        if (!desarrolloInicioDisponible || anchoColumnaAutoInicioMm <= 0.0)
            return 0.0;

        double recubrimientoMm = ObtenerRecubrimientoMm();
        double desarrolloMm = anchoColumnaAutoInicioMm - recubrimientoMm;

        return Math.Max(0.0, desarrolloMm / 10.0);
    }

    private double CalcularDesarrolloAutomaticoFinCm()
    {
        if (!desarrolloFinDisponible || anchoColumnaAutoFinMm <= 0.0)
            return 0.0;

        double recubrimientoMm = ObtenerRecubrimientoMm();
        double desarrolloMm = anchoColumnaAutoFinMm - recubrimientoMm;

        return Math.Max(0.0, desarrolloMm / 10.0);
    }

    private string FormatearCmParaTexto(double valorCm)
    {
        if (double.IsNaN(valorCm) || double.IsInfinity(valorCm))
            valorCm = 0.0;

        if (valorCm < 0.0)
            valorCm = 0.0;

        return Math.Round(valorCm, 2).ToString(
            "0.##",
            System.Globalization.CultureInfo.InvariantCulture);
    }

    private void ConfigurarFormatoNombreTipo(WinForms.ComboBox combo)
    {
        if (combo == null)
            return;

        combo.FormattingEnabled = true;
        combo.Format -= ComboTipoArmadura_Format;
        combo.Format += ComboTipoArmadura_Format;
    }

    private void ComboTipoArmadura_Format(
        object sender,
        WinForms.ListControlConvertEventArgs e)
    {
        RebarBarType tipo = e != null
            ? e.ListItem as RebarBarType
            : null;

        if (tipo != null)
            e.Value = tipo.Name;
    }

    private double ObtenerRecubrimientoEditorIntegradoCm()
    {
        if (txtRecubrimiento == null ||
            string.IsNullOrWhiteSpace(txtRecubrimiento.Text))
        {
            return 4.0;
        }

        double valor;
        string texto = txtRecubrimiento.Text.Trim().Replace(',', '.');

        if (!double.TryParse(
                texto,
                System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture,
                out valor) ||
            valor <= 0.0 ||
            double.IsNaN(valor) ||
            double.IsInfinity(valor))
        {
            return 4.0;
        }

        return valor;
    }

    private void CrearPanelConfiguracionUnificadaLongitudinal()
    {
        if (panelConfiguracionUnificada != null &&
            !panelConfiguracionUnificada.IsDisposed)
        {
            return;
        }

        panelConfiguracionUnificada = new WinForms.Panel
        {
            BackColor = Drawing.Color.White,
            BorderStyle = WinForms.BorderStyle.None,
            AutoScroll = true
        };

        Controls.Add(panelConfiguracionUnificada);

        WinForms.Control[] controles = new WinForms.Control[]
        {
            lblTituloPrincipal,
            lblDescripcionPrincipal,
            grpParametrosPrincipal,
            lblCantidad,
            grpExtremosLongitudinalesPrincipal,
            btnEjecutar
        };

        foreach (WinForms.Control control in controles)
        {
            if (control == null || control.IsDisposed)
                continue;

            if (control.Parent != null)
                control.Parent.Controls.Remove(control);

            panelConfiguracionUnificada.Controls.Add(control);
        }

        panelConfiguracionUnificada.BringToFront();
        if (panelEditorSeccionIntegrado != null)
            panelEditorSeccionIntegrado.BringToFront();

        ConstruirFormatoExactoColumnasV8Longitudinal();
    }

    private void LimpiarPanelesEditorUnificadoLongitudinal()
    {
        if (panelHerramientasEditorUnificado != null)
        {
            try
            {
                if (panelConfiguracionUnificada != null)
                {
                    panelConfiguracionUnificada.Controls.Remove(
                        panelHerramientasEditorUnificado);
                }
                panelHerramientasEditorUnificado.Dispose();
            }
            catch
            {
            }
            panelHerramientasEditorUnificado = null;
        }

        if (barraEdicionEditorUnificada != null)
        {
            try
            {
                if (panelEditorSeccionIntegrado != null)
                {
                    panelEditorSeccionIntegrado.Controls.Remove(
                        barraEdicionEditorUnificada);
                }
                barraEdicionEditorUnificada.Dispose();
            }
            catch
            {
            }
            barraEdicionEditorUnificada = null;
        }
    }

    private void CrearPanelEditorSeccionIntegrado()
    {
        panelEditorSeccionIntegrado = new WinForms.Panel
        {
            BackColor = Drawing.Color.FromArgb(245, 247, 250),
            BorderStyle = WinForms.BorderStyle.None,
            AutoScroll = false
        };

        Controls.Add(panelEditorSeccionIntegrado);
        panelEditorSeccionIntegrado.BringToFront();
    }

    public void ConfigurarEditorSeccionIntegrado(
        List<AceroVigaPuntoMm> contorno,
        List<RebarBarType> tipos,
        RebarBarType tipoEstriboReferencia,
        AceroVigaDisenoSeccion diseno,
        string nombreSeccion)
    {
        tipoEstriboEditorReferencia = tipoEstriboReferencia;
        EstablecerTipoEstriboReferencia(tipoEstriboReferencia);

        if (panelEditorSeccionIntegrado == null ||
            panelEditorSeccionIntegrado.IsDisposed)
        {
            CrearPanelEditorSeccionIntegrado();
        }

        LimpiarPanelesEditorUnificadoLongitudinal();

        if (editorSeccionIntegrado != null &&
            !editorSeccionIntegrado.IsDisposed)
        {
            try
            {
                AceroVigaDisenoSeccion trabajo =
                    editorSeccionIntegrado.ObtenerDisenoTrabajo();
                AceroVigaDisenoSeccionCompartido.Establecer(trabajo);
            }
            catch
            {
            }

            editorSeccionIntegrado.DisenoAplicado -=
                EditorSeccionIntegrado_DisenoAplicado;
            panelEditorSeccionIntegrado.Controls.Remove(
                editorSeccionIntegrado);
            editorSeccionIntegrado.Dispose();
            editorSeccionIntegrado = null;
        }

        panelEditorSeccionIntegrado.Controls.Clear();

        if (contorno == null || contorno.Count < 3)
        {
            lblEditorSinGeometriaIntegrado = new WinForms.Label
            {
                Dock = WinForms.DockStyle.Fill,
                Text = "DISEÑO LONGITUDINAL\n\n" +
                       "Seleccione una o más vigas para leer la sección real.",
                TextAlign = Drawing.ContentAlignment.MiddleCenter,
                Font = new Drawing.Font(
                    "Segoe UI",
                    10F,
                    Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(90, 90, 90),
                BackColor = Drawing.Color.White
            };
            panelEditorSeccionIntegrado.Controls.Add(
                lblEditorSinGeometriaIntegrado);
            AjustarLayoutEditorSeccionIntegrado();
            return;
        }

        List<RebarBarType> listaTipos = tipos != null
            ? tipos.Where(x => x != null).ToList()
            : new List<RebarBarType>();

        RebarBarType tipoLongitudinal = TipoSuperiorSeleccionado ??
            listaTipos.FirstOrDefault();
        RebarBarType tipoEstribo = tipoEstriboReferencia ??
            listaTipos.FirstOrDefault();

        AceroVigaDisenoSeccion trabajoDiseno = diseno != null
            ? diseno.Copiar()
            : AceroVigaDisenoSeccionCompartido.ObtenerCopia();

        editorSeccionIntegrado = new AceroVigaEditorSeccionForm(
            contorno,
            listaTipos,
            tipoLongitudinal,
            tipoEstribo,
            ObtenerRecubrimientoEditorIntegradoCm(),
            trabajoDiseno,
            AceroVigaModoEditorInicial.Longitudinales,
            nombreSeccion ?? string.Empty);

        editorSeccionIntegrado.ConfigurarComoLienzoUnificadoEnPestana(
            delegate { return TipoSuperiorSeleccionado; },
            delegate { return tipoEstriboEditorReferencia; },
            ObtenerRecubrimientoEditorIntegradoCm);

        editorSeccionIntegrado.DisenoAplicado +=
            EditorSeccionIntegrado_DisenoAplicado;

        // Si CARGAR DATA se ejecutó antes de disponer de una sección real,
        // restaura ahora el diseño completo sobre el nuevo editor.
        if (!string.IsNullOrWhiteSpace(
                disenoSeccionPersistentePendienteXmlMYG))
        {
            string errorCargaMYG;
            if (editorSeccionIntegrado.ImportarDisenoXmlMYG(
                    disenoSeccionPersistentePendienteXmlMYG,
                    out errorCargaMYG))
            {
                disenoSeccionPersistentePendienteXmlMYG = string.Empty;
            }
        }

        panelEditorSeccionIntegrado.Controls.Add(
            editorSeccionIntegrado);

        barraEdicionEditorUnificada =
            editorSeccionIntegrado
                .CrearBarraEdicionSuperiorPestanaUnificada();
        panelEditorSeccionIntegrado.Controls.Add(
            barraEdicionEditorUnificada);
        barraEdicionEditorUnificada.BringToFront();

        panelHerramientasEditorUnificado =
            editorSeccionIntegrado
                .CrearPanelHerramientasPestanaUnificada(
                    panelConfiguracionUnificada != null
                        ? Math.Max(390,
                            panelConfiguracionUnificada.ClientSize.Width - 18)
                        : 414);

        if (panelConfiguracionUnificada != null)
        {
            panelConfiguracionUnificada.Controls.Add(
                panelHerramientasEditorUnificado);
            panelHerramientasEditorUnificado.BringToFront();
        }

        editorSeccionIntegrado.Show();
        editorSeccionIntegrado.BringToFront();
        barraEdicionEditorUnificada.BringToFront();
        ConstruirFormatoExactoColumnasV8Longitudinal();
        AjustarLayoutEditorSeccionIntegrado();
    }

    private void EditorSeccionIntegrado_DisenoAplicado(
        AceroVigaDisenoSeccion diseno)
    {
        if (diseno != null)
            AceroVigaDisenoSeccionCompartido.Establecer(diseno);

        RefrescarPreviewLongitudinalEnTiempoReal();
    }

    // =========================================================
    // V11.2 - PERSISTENCIA COMPLETA DEL DISEÑO DIBUJADO
    // =========================================================
    public string ExportarDisenoSeccionPersistenteMYG()
    {
        try
        {
            if (editorSeccionIntegrado != null &&
                !editorSeccionIntegrado.IsDisposed)
            {
                AceroVigaDisenoSeccion trabajo =
                    editorSeccionIntegrado.ObtenerDisenoTrabajo();
                if (trabajo != null)
                    AceroVigaDisenoSeccionCompartido.Establecer(trabajo);

                return editorSeccionIntegrado.ExportarDisenoXmlMYG();
            }

            return disenoSeccionPersistentePendienteXmlMYG ??
                string.Empty;
        }
        catch
        {
            return disenoSeccionPersistentePendienteXmlMYG ??
                string.Empty;
        }
    }

    public bool ImportarDisenoSeccionPersistenteMYG(
        string contenidoXml,
        out string mensajeError)
    {
        mensajeError = string.Empty;

        if (string.IsNullOrWhiteSpace(contenidoXml))
            return true;

        try
        {
            if (editorSeccionIntegrado != null &&
                !editorSeccionIntegrado.IsDisposed)
            {
                bool ok = editorSeccionIntegrado.ImportarDisenoXmlMYG(
                    contenidoXml,
                    out mensajeError);

                if (ok)
                {
                    disenoSeccionPersistentePendienteXmlMYG =
                        string.Empty;
                    AceroVigaDisenoSeccion trabajo =
                        editorSeccionIntegrado.ObtenerDisenoTrabajo();
                    if (trabajo != null)
                        AceroVigaDisenoSeccionCompartido.Establecer(trabajo);
                    RefrescarPreviewLongitudinalEnTiempoReal();
                }

                return ok;
            }

            // Todavía no existe geometría de sección. Se conserva el XML y se
            // aplicará automáticamente al crear el editor tras seleccionar vigas.
            disenoSeccionPersistentePendienteXmlMYG = contenidoXml;
            return true;
        }
        catch (Exception ex)
        {
            mensajeError = ex.Message;
            return false;
        }
    }

    public void RefrescarEditorSeccionIntegrado()
    {
        if (editorSeccionIntegrado != null &&
            !editorSeccionIntegrado.IsDisposed)
        {
            editorSeccionIntegrado.RefrescarEntradasExternas();
        }
    }

    private WinForms.Label CrearEtiquetaFormatoV8Longitudinal(
        string texto,
        int left,
        int top,
        int width)
    {
        return new WinForms.Label
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.FromArgb(55, 55, 55)
        };
    }

    private void ReubicarControlFormatoV8Longitudinal(
        WinForms.Control control,
        WinForms.Control nuevoPadre,
        int left,
        int top,
        int width)
    {
        if (control == null || control.IsDisposed || nuevoPadre == null)
            return;

        if (control.Parent != null)
            control.Parent.Controls.Remove(control);

        control.Left = left;
        control.Top = top;
        control.Width = width;
        control.Visible = true;
        nuevoPadre.Controls.Add(control);
        control.BringToFront();
    }

    private void ConstruirFormatoExactoColumnasV8Longitudinal()
    {
        if (panelConfiguracionUnificada == null ||
            panelConfiguracionUnificada.IsDisposed)
        {
            return;
        }

        if (panelFormatoColumnasV8Longitudinal == null ||
            panelFormatoColumnasV8Longitudinal.IsDisposed)
        {
            panelFormatoColumnasV8Longitudinal = new WinForms.Panel
            {
                BackColor = Drawing.Color.White,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                AutoScroll = false
            };
            panelConfiguracionUnificada.Controls.Add(
                panelFormatoColumnasV8Longitudinal);

            chkCrearLongitudinalesV8 = new WinForms.CheckBox
            {
                Text = "Crear acero longitudinal",
                Left = 18,
                Top = 14,
                Width = 270,
                Height = 25,
                Checked = true,
                Font = new Drawing.Font(
                    "Segoe UI",
                    9F,
                    Drawing.FontStyle.Bold)
            };
            chkCrearLongitudinalesV8.CheckedChanged += (s, e) =>
            {
                bool activo = chkCrearLongitudinalesV8.Checked;
                if (panelHerramientasEditorUnificado != null)
                    panelHerramientasEditorUnificado.Enabled = activo;
                if (panelEditorSeccionIntegrado != null)
                    panelEditorSeccionIntegrado.Enabled = activo;
                if (btnEjecutar != null)
                    btnEjecutar.Enabled = activo;
            };
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                chkCrearLongitudinalesV8);

            lblModoDistribucionEstacionesMYG = new WinForms.Label
            {
                Text = "Modo:",
                Left = 18,
                Top = 315,
                Width = 48,
                Height = 24,
                Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(55, 55, 55)
            };
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                lblModoDistribucionEstacionesMYG);

            cmbModoDistribucionEstacionesMYG = new WinForms.ComboBox
            {
                Left = 66,
                Top = 312,
                Width = 170,
                Height = 26,
                DropDownStyle = WinForms.ComboBoxStyle.DropDownList
            };
            cmbModoDistribucionEstacionesMYG.Items.Add("CONTINUO (ACTUAL)");
            cmbModoDistribucionEstacionesMYG.Items.Add("ESTACIONES - INTERMEDIO");
            cmbModoDistribucionEstacionesMYG.Items.Add("ESTACIONES - AVANZADO");
            cmbModoDistribucionEstacionesMYG.SelectedIndex = 0;
            cmbModoDistribucionEstacionesMYG.SelectedIndexChanged += (s, e) =>
            {
                bool porEstaciones =
                    ModoDistribucionLongitudinalActualMYG !=
                    ModoDistribucionLongitudinalMYG.Continuo;

                if (btnConfigurarEstacionesMYG != null)
                    btnConfigurarEstacionesMYG.Enabled = porEstaciones;

                if (porEstaciones)
                    SincronizarConfiguracionEstacionesConModeloMYG();

                RefrescarPreviewLongitudinalEnTiempoReal();
            };
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                cmbModoDistribucionEstacionesMYG);

            btnConfigurarEstacionesMYG = new WinForms.Button
            {
                Text = "CONFIGURAR",
                Left = 242,
                Top = 311,
                Width = 92,
                Height = 28,
                Enabled = false,
                FlatStyle = WinForms.FlatStyle.Flat,
                Cursor = WinForms.Cursors.Hand,
                Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold)
            };
            btnConfigurarEstacionesMYG.FlatAppearance.BorderColor =
                Drawing.Color.FromArgb(155, 165, 175);
            btnConfigurarEstacionesMYG.Click += (s, e) =>
                MostrarConfiguracionEstacionesMYG();
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                btnConfigurarEstacionesMYG);

            // =========================================================
            // V11.28 - MIRROR DEL PREVIEW EN EL ENCABEZADO DE VISTA PRELIMINAR
            // =========================================================
            // Se agrega directamente al formulario (no a la columna izquierda)
            // para ubicarlo sobre la franja superior derecha de la vista
            // preliminar. MIRROR es exclusivamente visual: no altera T1/T2/T3,
            // desarrollos, AUTO/GANCHO ni el orden lógico usado en ejecución.
            btnInvertirVistaPreviaMYG = new WinForms.Button
            {
                Text = "MIRROR",
                Width = 82,
                Height = 28,
                Enabled = true,
                FlatStyle = WinForms.FlatStyle.Flat,
                Cursor = WinForms.Cursors.Hand,
                Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold),
                BackColor = Drawing.Color.White,
                Anchor = WinForms.AnchorStyles.Right | WinForms.AnchorStyles.Bottom,
                TabStop = false
            };
            btnInvertirVistaPreviaMYG.FlatAppearance.BorderColor =
                Drawing.Color.FromArgb(155, 165, 175);
            btnInvertirVistaPreviaMYG.Click += (s, e) =>
            {
                previewInvertirHorizontalMYG = !previewInvertirHorizontalMYG;

                // El texto permanece siempre como MIRROR. El estado activo se
                // identifica por el fondo azul claro, como un botón conmutado.
                btnInvertirVistaPreviaMYG.Text = "MIRROR";
                btnInvertirVistaPreviaMYG.BackColor = previewInvertirHorizontalMYG
                    ? Drawing.Color.FromArgb(225, 238, 250)
                    : Drawing.Color.White;

                RefrescarPreviewLongitudinalEnTiempoReal();
            };
            Controls.Add(btnInvertirVistaPreviaMYG);
            btnInvertirVistaPreviaMYG.BringToFront();

            panelFormatoColumnasV8Longitudinal.Controls.Add(
                CrearEtiquetaFormatoV8Longitudinal(
                    "Recubrimiento:", 18, 51, 145));
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                CrearEtiquetaFormatoV8Longitudinal(
                    "Tipo de barra:", 18, 84, 145));
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                CrearEtiquetaFormatoV8Longitudinal(
                    "Separación máxima:", 18, 117, 145));
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                CrearEtiquetaFormatoV8Longitudinal(
                    "Desarrollo inicial:", 18, 150, 145));
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                CrearEtiquetaFormatoV8Longitudinal(
                    "Desarrollo final:", 18, 183, 145));
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                CrearEtiquetaFormatoV8Longitudinal(
                    "Longitud comercial:", 18, 249, 145));
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                CrearEtiquetaFormatoV8Longitudinal(
                    "Longitud de empalme:", 18, 282, 145));

            panelFormatoColumnasV8Longitudinal.Controls.Add(
                new WinForms.Label
                {
                    Text = "cm",
                    Left = 238,
                    Top = 51,
                    Width = 35,
                    Height = 22,
                    ForeColor = Drawing.Color.Gray
                });
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                new WinForms.Label
                {
                    Text = "cm",
                    Left = 238,
                    Top = 117,
                    Width = 35,
                    Height = 22,
                    ForeColor = Drawing.Color.Gray
                });
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                new WinForms.Label
                {
                    Text = "cm",
                    Left = 238,
                    Top = 150,
                    Width = 35,
                    Height = 22,
                    ForeColor = Drawing.Color.Gray
                });
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                new WinForms.Label
                {
                    Text = "cm",
                    Left = 238,
                    Top = 183,
                    Width = 35,
                    Height = 22,
                    ForeColor = Drawing.Color.Gray
                });
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                new WinForms.Label
                {
                    Text = "m",
                    Left = 238,
                    Top = 249,
                    Width = 35,
                    Height = 22,
                    ForeColor = Drawing.Color.Gray
                });
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                new WinForms.Label
                {
                    Text = "cm",
                    Left = 238,
                    Top = 282,
                    Width = 35,
                    Height = 22,
                    ForeColor = Drawing.Color.Gray
                });

            btnAplicarTipoV8 = new WinForms.Button
            {
                Text = "APLICAR",
                Left = 332,
                Top = 81,
                Width = 82,
                Height = 27,
                FlatStyle = WinForms.FlatStyle.Flat,
                Cursor = WinForms.Cursors.Hand,
                Font = new Drawing.Font(
                    "Segoe UI",
                    8F,
                    Drawing.FontStyle.Bold)
            };
            btnAplicarTipoV8.FlatAppearance.BorderColor =
                Drawing.Color.FromArgb(155, 165, 175);
            btnAplicarTipoV8.Click += (s, e) =>
            {
                if (editorSeccionIntegrado != null &&
                    !editorSeccionIntegrado.IsDisposed)
                {
                    editorSeccionIntegrado
                        .AplicarTipoActualASeleccionDesdePestana();
                }
            };
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                btnAplicarTipoV8);

            lblAyudaFormatoV8Longitudinal = new WinForms.Label
            {
                Text = "SECCIÓN LIMPIA: agregue barras individuales o use " +
                       "DISTRIBUIR 2 PUNTOS. El OSNAP se aplica según la " +
                       "herramienta activa.",
                Left = 18,
                Top = 493,
                Width = 396,
                Height = 42,
                Font = new Drawing.Font("Segoe UI", 8.1F),
                ForeColor = Drawing.Color.FromArgb(75, 75, 75)
            };
            panelFormatoColumnasV8Longitudinal.Controls.Add(
                lblAyudaFormatoV8Longitudinal);
        }

        ReubicarControlFormatoV8Longitudinal(
            txtRecubrimiento,
            panelFormatoColumnasV8Longitudinal,
            168,
            48,
            62);
        ReubicarControlFormatoV8Longitudinal(
            cmbTipoSuperior,
            panelFormatoColumnasV8Longitudinal,
            168,
            81,
            158);
        ReubicarControlFormatoV8Longitudinal(
            txtSeparacionCapas,
            panelFormatoColumnasV8Longitudinal,
            168,
            114,
            62);
        ReubicarControlFormatoV8Longitudinal(
            txtLongitudDesarrolloInicio,
            panelFormatoColumnasV8Longitudinal,
            168,
            147,
            62);

        // V11.6 MYG - Controles independientes para el extremo inicial.
        // AUTO conserva la lógica existente: atraviesa el apoyo extremo y
        // termina a recubrimiento de su cara opuesta. GANCHO se puede combinar
        // tanto con AUTO como con una longitud manual.
        ReubicarControlFormatoV8Longitudinal(
            chkDesarrolloAutomaticoInicio,
            panelFormatoColumnasV8Longitudinal,
            270,
            146,
            60);
        if (chkDesarrolloAutomaticoInicio != null)
        {
            chkDesarrolloAutomaticoInicio.Text = "AUTO";
            chkDesarrolloAutomaticoInicio.BackColor = Drawing.Color.White;
            chkDesarrolloAutomaticoInicio.Font =
                new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold);
        }

        ReubicarControlFormatoV8Longitudinal(
            chkGanchoInicio,
            panelFormatoColumnasV8Longitudinal,
            332,
            146,
            82);
        if (chkGanchoInicio != null)
        {
            chkGanchoInicio.Text = "GANCHO";
            chkGanchoInicio.BackColor = Drawing.Color.White;
            chkGanchoInicio.Font =
                new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold);
        }

        ReubicarControlFormatoV8Longitudinal(
            txtLongitudDesarrolloFin,
            panelFormatoColumnasV8Longitudinal,
            168,
            180,
            62);

        // V11.6 MYG - Controles independientes para el extremo final.
        ReubicarControlFormatoV8Longitudinal(
            chkDesarrolloAutomaticoFin,
            panelFormatoColumnasV8Longitudinal,
            270,
            179,
            60);
        if (chkDesarrolloAutomaticoFin != null)
        {
            chkDesarrolloAutomaticoFin.Text = "AUTO";
            chkDesarrolloAutomaticoFin.BackColor = Drawing.Color.White;
            chkDesarrolloAutomaticoFin.Font =
                new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold);
        }

        ReubicarControlFormatoV8Longitudinal(
            chkGanchoFin,
            panelFormatoColumnasV8Longitudinal,
            332,
            179,
            82);
        if (chkGanchoFin != null)
        {
            chkGanchoFin.Text = "GANCHO";
            chkGanchoFin.BackColor = Drawing.Color.White;
            chkGanchoFin.Font =
                new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold);
        }
        ReubicarControlFormatoV8Longitudinal(
            chkCrearEmpalmes,
            panelFormatoColumnasV8Longitudinal,
            18,
            213,
            250);
        if (chkCrearEmpalmes != null)
            chkCrearEmpalmes.Text = "Considerar empalmes con quiebre";
        ReubicarControlFormatoV8Longitudinal(
            chkUsarRNE,
            panelFormatoColumnasV8Longitudinal,
            270,
            213,
            145);
        if (chkUsarRNE != null)
            chkUsarRNE.Text = "Usar RNE E.060";
        ReubicarControlFormatoV8Longitudinal(
            txtLongitudBarra,
            panelFormatoColumnasV8Longitudinal,
            168,
            246,
            62);
        ReubicarControlFormatoV8Longitudinal(
            txtLongitudEmpalme,
            panelFormatoColumnasV8Longitudinal,
            168,
            279,
            62);
        ReubicarControlFormatoV8Longitudinal(
            btnConfigRNE,
            panelFormatoColumnasV8Longitudinal,
            292,
            276,
            122);
        if (btnConfigRNE != null)
            btnConfigRNE.Text = "RNE E.060...";

        if (panelHerramientasEditorUnificado != null &&
            !panelHerramientasEditorUnificado.IsDisposed)
        {
            if (panelHerramientasEditorUnificado.Parent !=
                panelFormatoColumnasV8Longitudinal)
            {
                if (panelHerramientasEditorUnificado.Parent != null)
                {
                    panelHerramientasEditorUnificado.Parent.Controls.Remove(
                        panelHerramientasEditorUnificado);
                }
                panelFormatoColumnasV8Longitudinal.Controls.Add(
                    panelHerramientasEditorUnificado);
            }

            panelHerramientasEditorUnificado.Left = 10;
            panelHerramientasEditorUnificado.Top = 348;
            panelHerramientasEditorUnificado.Width = Math.Max(396, panelConfiguracionUnificada.ClientSize.Width - 20);
            panelHerramientasEditorUnificado.Height = 208;
            panelHerramientasEditorUnificado.BringToFront();
        }
    }

    private void AjustarLayoutEditorSeccionIntegrado()
    {
        int anchoTotal = Math.Max(1045, ClientSize.Width);
        int altoTotal = Math.Max(555, ClientSize.Height);
        const int margen = 8;
        const int anchoIzquierdo = 440;
        const int separacion = 8;

        if (panelConfiguracionUnificada != null)
        {
            panelConfiguracionUnificada.SetBounds(
                margen,
                margen,
                anchoIzquierdo,
                Math.Max(630, altoTotal - margen * 2));
            panelConfiguracionUnificada.AutoScroll = false;
        }

        int leftVista = margen + anchoIzquierdo + separacion;
        if (panelEditorSeccionIntegrado != null)
        {
            panelEditorSeccionIntegrado.SetBounds(
                leftVista,
                margen,
                Math.Max(570, anchoTotal - leftVista - margen),
                Math.Max(535, altoTotal - margen * 2));
            panelEditorSeccionIntegrado.BringToFront();
        }

        // Los controles antiguos permanecen como respaldo de datos, pero no
        // participan de la composición visual V8.
        if (lblTituloPrincipal != null) lblTituloPrincipal.Visible = false;
        if (lblDescripcionPrincipal != null) lblDescripcionPrincipal.Visible = false;
        if (grpParametrosPrincipal != null) grpParametrosPrincipal.Visible = false;
        if (lblCantidad != null) lblCantidad.Visible = false;
        if (grpExtremosLongitudinalesPrincipal != null)
            grpExtremosLongitudinalesPrincipal.Visible = false;
        if (grpPreviewLocal != null) grpPreviewLocal.Visible = false;

        ConstruirFormatoExactoColumnasV8Longitudinal();

        if (panelFormatoColumnasV8Longitudinal != null)
        {
            panelFormatoColumnasV8Longitudinal.SetBounds(
                0,
                0,
                anchoIzquierdo,
                Math.Max(630, panelConfiguracionUnificada.ClientSize.Height));
            panelFormatoColumnasV8Longitudinal.BringToFront();
        }

        if (btnEjecutar != null)
        {
            // La ejecución continúa disponible para compatibilidad; se ubica en
            // la franja inferior del panel izquierdo, como acción principal.
            if (btnEjecutar.Parent != panelFormatoColumnasV8Longitudinal &&
                panelFormatoColumnasV8Longitudinal != null)
            {
                if (btnEjecutar.Parent != null)
                    btnEjecutar.Parent.Controls.Remove(btnEjecutar);
                panelFormatoColumnasV8Longitudinal.Controls.Add(btnEjecutar);
            }
            btnEjecutar.Left = 225;
            btnEjecutar.Top = 598;
            btnEjecutar.Width = 190;
            btnEjecutar.Height = 32;
            btnEjecutar.Visible = true;
            btnEjecutar.BringToFront();

            if (lblAyudaFormatoV8Longitudinal != null)
            {
                lblAyudaFormatoV8Longitudinal.Top = 566;
                lblAyudaFormatoV8Longitudinal.Width = 195;
            }
        }

        // V11.28 - Botón MIRROR sobre el encabezado derecho de la vista
        // preliminar inferior, en la zona indicada por el usuario.
        if (btnInvertirVistaPreviaMYG != null &&
            !btnInvertirVistaPreviaMYG.IsDisposed)
        {
            if (btnInvertirVistaPreviaMYG.Parent != this)
            {
                if (btnInvertirVistaPreviaMYG.Parent != null)
                    btnInvertirVistaPreviaMYG.Parent.Controls.Remove(
                        btnInvertirVistaPreviaMYG);
                Controls.Add(btnInvertirVistaPreviaMYG);
            }

            const int anchoMirror = 82;
            const int altoMirror = 28;
            const int margenDerechoMirror = 48;
            const int distanciaDesdeAbajoMirror = 252;

            btnInvertirVistaPreviaMYG.SetBounds(
                Math.Max(8,
                    ClientSize.Width - margenDerechoMirror - anchoMirror),
                Math.Max(8,
                    ClientSize.Height - distanciaDesdeAbajoMirror),
                anchoMirror,
                altoMirror);

            btnInvertirVistaPreviaMYG.Visible = true;
            btnInvertirVistaPreviaMYG.BringToFront();
        }
    }


    // =========================================================
    // V11.20 - CONFIGURACIÓN ALTERNA POR ESTACIONES
    // =========================================================
    private AceroVigaDisenoSeccion ObtenerDisenoActualEstacionesMYG()
    {
        try
        {
            if (editorSeccionIntegrado != null &&
                !editorSeccionIntegrado.IsDisposed)
            {
                AceroVigaDisenoSeccion actual =
                    editorSeccionIntegrado.ObtenerDisenoTrabajo();
                if (actual != null)
                    return actual.Copiar();
            }
        }
        catch
        {
        }

        try
        {
            return AceroVigaDisenoSeccionCompartido.ObtenerCopia();
        }
        catch
        {
            return null;
        }
    }

    private string ObtenerEtiquetaGrupoEstacionesMYG(
        AceroVigaGrupoLongitudinal2D grupo,
        AceroVigaDisenoSeccion diseno)
    {
        if (grupo == null)
            return "Longitudinal";

        AceroVigaTipoCapaLongitudinal tipo = grupo.TipoCapa;
        int numero = grupo.NumeroCapa;

        if (tipo == AceroVigaTipoCapaLongitudinal.SinDefinir &&
            diseno != null && diseno.Longitudinales != null)
        {
            AceroVigaBarraLongitudinal2D primera =
                diseno.Longitudinales.FirstOrDefault(x =>
                    x != null &&
                    string.Equals(
                        x.GrupoDistribucionId,
                        grupo.Id,
                        StringComparison.Ordinal));

            if (primera != null)
            {
                tipo = primera.TipoCapa;
                numero = primera.NumeroCapa;

                if (tipo == AceroVigaTipoCapaLongitudinal.SinDefinir &&
                    primera.Punto != null)
                {
                    double v = Math.Max(0.0, Math.Min(1.0, primera.Punto.V));
                    tipo = v >= 0.66
                        ? AceroVigaTipoCapaLongitudinal.Superior
                        : (v <= 0.34
                            ? AceroVigaTipoCapaLongitudinal.Inferior
                            : AceroVigaTipoCapaLongitudinal.Central);
                }
            }
        }

        if (tipo == AceroVigaTipoCapaLongitudinal.Superior)
            return "Superior " + Math.Max(1, numero).ToString();

        if (tipo == AceroVigaTipoCapaLongitudinal.Inferior)
            return "Inferior " + Math.Max(1, numero).ToString();

        if (tipo == AceroVigaTipoCapaLongitudinal.Central)
            return "Central";

        return "Longitudinal";
    }

    private string ObtenerClaveBarraIndividualEstacionesMYG(
        AceroVigaBarraLongitudinal2D barra)
    {
        if (barra == null || string.IsNullOrWhiteSpace(barra.Id))
            return string.Empty;

        return "__IND__|" + barra.Id;
    }

    private string ObtenerEtiquetaBarraIndividualEstacionesMYG(
        AceroVigaBarraLongitudinal2D barra)
    {
        if (barra == null)
            return "Longitudinal individual";

        AceroVigaTipoCapaLongitudinal tipo = barra.TipoCapa;
        int numero = barra.NumeroCapa;

        if (tipo == AceroVigaTipoCapaLongitudinal.SinDefinir &&
            barra.Punto != null)
        {
            double v = Math.Max(0.0, Math.Min(1.0, barra.Punto.V));
            tipo = v >= 0.66
                ? AceroVigaTipoCapaLongitudinal.Superior
                : (v <= 0.34
                    ? AceroVigaTipoCapaLongitudinal.Inferior
                    : AceroVigaTipoCapaLongitudinal.Central);
        }

        if (tipo == AceroVigaTipoCapaLongitudinal.Superior)
            return "Superior " + Math.Max(1, numero).ToString() +
                   " • individual";

        if (tipo == AceroVigaTipoCapaLongitudinal.Inferior)
            return "Inferior " + Math.Max(1, numero).ToString() +
                   " • individual";

        if (tipo == AceroVigaTipoCapaLongitudinal.Central)
            return "Central • individual";

        return "Longitudinal • individual";
    }

    private int ObtenerCantidadMaximaGrupoEstacionesMYG(
        AceroVigaGrupoLongitudinal2D grupo,
        AceroVigaDisenoSeccion diseno)
    {
        if (grupo == null)
            return 0;

        int cantidadDefiniciones = 0;
        if (diseno != null && diseno.Longitudinales != null)
        {
            cantidadDefiniciones = diseno.Longitudinales.Count(x =>
                x != null &&
                !x.OcultaPorSuperposicion &&
                string.Equals(
                    x.GrupoDistribucionId,
                    grupo.Id,
                    StringComparison.Ordinal));
        }

        return Math.Max(
            1,
            Math.Max(
                cantidadDefiniciones,
                Math.Max(1, grupo.Cantidad)));
    }

    private void SincronizarConfiguracionEstacionesConModeloMYG()
    {
        AceroVigaDisenoSeccion diseno = ObtenerDisenoActualEstacionesMYG();
        if (diseno == null ||
            diseno.Longitudinales == null ||
            diseno.Longitudinales.Count == 0 ||
            previewVigas == null ||
            previewVigas.Count == 0)
        {
            return;
        }

        SerieContinuaPreview serie = ConstruirSerieContinua(previewVigas);
        int cantidadTramos = serie != null && serie.TramosViga != null
            ? serie.TramosViga.Count
            : 0;

        if (cantidadTramos <= 0)
            return;

        Dictionary<string, FilaConfiguracionEstacionMYG> anteriores =
            configuracionEstacionesLongitudinalMYG
                .Where(x => x != null)
                .GroupBy(x =>
                    x.TramoIndice.ToString() + "|" +
                    (x.GrupoId ?? string.Empty))
                .ToDictionary(
                    g => g.Key,
                    g => g.First());

        List<FilaConfiguracionEstacionMYG> nuevas =
            new List<FilaConfiguracionEstacionMYG>();

        for (int i = 0; i < cantidadTramos; i++)
        {
            if (diseno.GruposLongitudinales != null)
            {
                foreach (AceroVigaGrupoLongitudinal2D grupo in
                    diseno.GruposLongitudinales.Where(x => x != null))
                {
                    if (string.IsNullOrWhiteSpace(grupo.Id))
                        continue;

                    int maximo = ObtenerCantidadMaximaGrupoEstacionesMYG(
                        grupo,
                        diseno);

                    string clave = i.ToString() + "|" + grupo.Id;
                    FilaConfiguracionEstacionMYG filaAnterior = null;
                    anteriores.TryGetValue(clave, out filaAnterior);

                    FilaConfiguracionEstacionMYG fila =
                        filaAnterior != null
                            ? filaAnterior.Copiar()
                            : new FilaConfiguracionEstacionMYG
                            {
                                TramoIndice = i,
                                GrupoId = grupo.Id,
                                CapaEtiqueta =
                                    ObtenerEtiquetaGrupoEstacionesMYG(
                                        grupo,
                                        diseno),
                                CantidadMaxima = maximo,
                                CantidadIzquierda = maximo,
                                CantidadCentro = maximo,
                                CantidadDerecha = maximo
                            };

                    fila.TramoIndice = i;
                    fila.GrupoId = grupo.Id;
                    fila.CapaEtiqueta = ObtenerEtiquetaGrupoEstacionesMYG(
                        grupo,
                        diseno);
                    fila.CantidadMaxima = maximo;
                    fila.CantidadIzquierda = Math.Max(
                        0,
                        Math.Min(maximo, fila.CantidadIzquierda));
                    fila.CantidadCentro = Math.Max(
                        0,
                        Math.Min(maximo, fila.CantidadCentro));
                    fila.CantidadDerecha = Math.Max(
                        0,
                        Math.Min(maximo, fila.CantidadDerecha));

                    // V11.23: garantiza que cada cantidad tenga también su mapa
                    // exacto de posiciones activas. Las configuraciones antiguas
                    // se reconstruyen de forma simétrica una sola vez.
                    NormalizarSeleccionFilaEstacionVisualMYG(fila);

                    nuevas.Add(fila);
                }
            }

            // V11.23: las barras creadas con AGREGAR BARRA también forman parte
            // del configurador. Así la sección principal puede contener TODO el
            // acero posible y el usuario decide por tramo cuáles quedan activos.
            foreach (AceroVigaBarraLongitudinal2D barraIndividual in
                diseno.Longitudinales.Where(x =>
                    x != null &&
                    x.Punto != null &&
                    !x.OcultaPorSuperposicion &&
                    string.IsNullOrWhiteSpace(x.GrupoDistribucionId)))
            {
                string claveIndividual =
                    ObtenerClaveBarraIndividualEstacionesMYG(
                        barraIndividual);
                if (string.IsNullOrWhiteSpace(claveIndividual))
                    continue;

                string claveFila =
                    i.ToString() + "|" + claveIndividual;

                FilaConfiguracionEstacionMYG filaAnteriorIndividual = null;
                anteriores.TryGetValue(
                    claveFila,
                    out filaAnteriorIndividual);

                FilaConfiguracionEstacionMYG filaIndividual =
                    filaAnteriorIndividual != null
                        ? filaAnteriorIndividual.Copiar()
                        : new FilaConfiguracionEstacionMYG
                        {
                            TramoIndice = i,
                            GrupoId = claveIndividual,
                            BarraIndividualId =
                                barraIndividual.Id ?? string.Empty,
                            CapaEtiqueta =
                                ObtenerEtiquetaBarraIndividualEstacionesMYG(
                                    barraIndividual),
                            CantidadMaxima = 1,
                            CantidadIzquierda = 1,
                            CantidadCentro = 1,
                            CantidadDerecha = 1
                        };

                filaIndividual.TramoIndice = i;
                filaIndividual.GrupoId = claveIndividual;
                filaIndividual.BarraIndividualId =
                    barraIndividual.Id ?? string.Empty;
                filaIndividual.CapaEtiqueta =
                    ObtenerEtiquetaBarraIndividualEstacionesMYG(
                        barraIndividual);
                filaIndividual.CantidadMaxima = 1;

                filaIndividual.CantidadIzquierda =
                    Math.Max(
                        0,
                        Math.Min(
                            1,
                            filaIndividual.CantidadIzquierda));
                filaIndividual.CantidadCentro =
                    Math.Max(
                        0,
                        Math.Min(
                            1,
                            filaIndividual.CantidadCentro));
                filaIndividual.CantidadDerecha =
                    Math.Max(
                        0,
                        Math.Min(
                            1,
                            filaIndividual.CantidadDerecha));

                NormalizarSeleccionFilaEstacionVisualMYG(
                    filaIndividual);

                nuevas.Add(filaIndividual);
            }
        }

        configuracionEstacionesLongitudinalMYG.Clear();
        configuracionEstacionesLongitudinalMYG.AddRange(nuevas);
    }

    private int LeerEnteroCeldaEstacionesMYG(
        WinForms.DataGridViewRow row,
        string columna,
        int respaldo,
        int maximo)
    {
        try
        {
            object valor = row.Cells[columna].Value;
            int n;
            if (valor != null &&
                int.TryParse(valor.ToString(), out n))
            {
                return Math.Max(0, Math.Min(maximo, n));
            }
        }
        catch
        {
        }

        return Math.Max(0, Math.Min(maximo, respaldo));
    }

    // =========================================================
    // V11.22 - CONFIGURADOR VISUAL POR TRAMO
    // =========================================================
    // INTERMEDIO: una sección por tramo.
    // AVANZADO: tres secciones por tramo (IZQUIERDA / CENTRO / DERECHA).
    // V11.23 añade selección exacta por índice para que el clic determine
    // exactamente qué barra existe en cada tramo/zona. El handler consume ese
    // mismo mapa y ya no deduce las posiciones únicamente desde una cantidad.
    private int ObtenerOrdenCapaEstacionVisualMYG(string etiqueta)
    {
        string t = (etiqueta ?? string.Empty).Trim().ToLowerInvariant();

        if (t.StartsWith("superior"))
        {
            int n = 1;
            foreach (string token in t.Split(' '))
            {
                int candidato;
                if (int.TryParse(token, out candidato))
                {
                    n = candidato;
                    break;
                }
            }
            return 10 + Math.Max(1, n);
        }

        if (t == "central")
            return 50;

        if (t.StartsWith("inferior"))
        {
            int n = 1;
            foreach (string token in t.Split(' '))
            {
                int candidato;
                if (int.TryParse(token, out candidato))
                {
                    n = candidato;
                    break;
                }
            }
            // Visualmente queremos Inferior 4,3,2,1 de arriba hacia abajo.
            return 90 - Math.Max(1, n);
        }

        return 60;
    }

    private Drawing.Color ObtenerColorCapaEstacionVisualMYG(string etiqueta)
    {
        string t = (etiqueta ?? string.Empty).Trim().ToLowerInvariant();
        if (t.StartsWith("superior"))
            return ColorAceroSuperior;
        if (t.StartsWith("inferior"))
            return ColorAceroInferior;
        if (t == "central")
            return ColorAceroCentral;
        return Drawing.Color.FromArgb(90, 90, 90);
    }

    private List<int> ConstruirOrdenPrioridadSimetricaVisualMYG(int cantidad)
    {
        List<int> resultado = new List<int>();
        int izquierda = 0;
        int derecha = cantidad - 1;

        while (izquierda <= derecha)
        {
            if (!resultado.Contains(izquierda))
                resultado.Add(izquierda);

            if (derecha != izquierda && !resultado.Contains(derecha))
                resultado.Add(derecha);

            izquierda++;
            derecha--;
        }

        return resultado;
    }

    private List<int> ConstruirIndicesSimetricosEstacionVisualMYG(
        int cantidadMaxima,
        int cantidad)
    {
        cantidadMaxima = Math.Max(0, cantidadMaxima);
        cantidad = Math.Max(0, Math.Min(cantidadMaxima, cantidad));

        return ConstruirOrdenPrioridadSimetricaVisualMYG(cantidadMaxima)
            .Take(cantidad)
            .Distinct()
            .OrderBy(x => x)
            .ToList();
    }

    private List<int> SanitizarIndicesEstacionVisualMYG(
        IEnumerable<int> indices,
        int cantidadMaxima)
    {
        cantidadMaxima = Math.Max(0, cantidadMaxima);

        return (indices ?? Enumerable.Empty<int>())
            .Where(x => x >= 0 && x < cantidadMaxima)
            .Distinct()
            .OrderBy(x => x)
            .ToList();
    }

    private void NormalizarSeleccionFilaEstacionVisualMYG(
        FilaConfiguracionEstacionMYG fila)
    {
        if (fila == null)
            return;

        int maximo = Math.Max(0, fila.CantidadMaxima);

        if (!fila.SeleccionExplicitaIzquierda)
        {
            fila.IndicesActivosIzquierda =
                ConstruirIndicesSimetricosEstacionVisualMYG(
                    maximo,
                    fila.CantidadIzquierda);
        }
        else
        {
            fila.IndicesActivosIzquierda =
                SanitizarIndicesEstacionVisualMYG(
                    fila.IndicesActivosIzquierda,
                    maximo);
            fila.CantidadIzquierda = fila.IndicesActivosIzquierda.Count;
        }

        if (!fila.SeleccionExplicitaCentro)
        {
            fila.IndicesActivosCentro =
                ConstruirIndicesSimetricosEstacionVisualMYG(
                    maximo,
                    fila.CantidadCentro);
        }
        else
        {
            fila.IndicesActivosCentro =
                SanitizarIndicesEstacionVisualMYG(
                    fila.IndicesActivosCentro,
                    maximo);
            fila.CantidadCentro = fila.IndicesActivosCentro.Count;
        }

        if (!fila.SeleccionExplicitaDerecha)
        {
            fila.IndicesActivosDerecha =
                ConstruirIndicesSimetricosEstacionVisualMYG(
                    maximo,
                    fila.CantidadDerecha);
        }
        else
        {
            fila.IndicesActivosDerecha =
                SanitizarIndicesEstacionVisualMYG(
                    fila.IndicesActivosDerecha,
                    maximo);
            fila.CantidadDerecha = fila.IndicesActivosDerecha.Count;
        }
    }

    private List<int> ObtenerIndicesActivosZonaEstacionVisualMYG(
        FilaConfiguracionEstacionMYG fila,
        int zona,
        bool avanzado)
    {
        if (fila == null)
            return new List<int>();

        NormalizarSeleccionFilaEstacionVisualMYG(fila);

        if (!avanzado)
            return new List<int>(fila.IndicesActivosCentro);

        if (zona <= 0)
            return new List<int>(fila.IndicesActivosIzquierda);
        if (zona >= 2)
            return new List<int>(fila.IndicesActivosDerecha);
        return new List<int>(fila.IndicesActivosCentro);
    }

    private void AsignarIndicesZonaEstacionVisualMYG(
        FilaConfiguracionEstacionMYG fila,
        int zona,
        bool avanzado,
        IEnumerable<int> indices)
    {
        if (fila == null)
            return;

        List<int> limpios = SanitizarIndicesEstacionVisualMYG(
            indices,
            fila.CantidadMaxima);

        if (!avanzado)
        {
            fila.IndicesActivosIzquierda = new List<int>(limpios);
            fila.IndicesActivosCentro = new List<int>(limpios);
            fila.IndicesActivosDerecha = new List<int>(limpios);
            fila.CantidadIzquierda = limpios.Count;
            fila.CantidadCentro = limpios.Count;
            fila.CantidadDerecha = limpios.Count;
            fila.SeleccionExplicitaIzquierda = true;
            fila.SeleccionExplicitaCentro = true;
            fila.SeleccionExplicitaDerecha = true;
            return;
        }

        if (zona <= 0)
        {
            fila.IndicesActivosIzquierda = new List<int>(limpios);
            fila.CantidadIzquierda = limpios.Count;
            fila.SeleccionExplicitaIzquierda = true;
        }
        else if (zona >= 2)
        {
            fila.IndicesActivosDerecha = new List<int>(limpios);
            fila.CantidadDerecha = limpios.Count;
            fila.SeleccionExplicitaDerecha = true;
        }
        else
        {
            fila.IndicesActivosCentro = new List<int>(limpios);
            fila.CantidadCentro = limpios.Count;
            fila.SeleccionExplicitaCentro = true;
        }
    }

    private void AsignarCantidadSimetricaZonaEstacionVisualMYG(
        FilaConfiguracionEstacionMYG fila,
        int zona,
        bool avanzado,
        int cantidad)
    {
        if (fila == null)
            return;

        List<int> indices =
            ConstruirIndicesSimetricosEstacionVisualMYG(
                fila.CantidadMaxima,
                cantidad);

        AsignarIndicesZonaEstacionVisualMYG(
            fila,
            zona,
            avanzado,
            indices);
    }

    // =========================================================
    // V11.31 - COTAS VISUALES DE CANTIDAD POR FILA DE ACERO
    // =========================================================
    // Se reserva una franja a la izquierda del croquis para mostrar, de forma
    // dinámica, la cantidad REAL de barras activas por cada fila horizontal.
    // El texto usa el tipo real de barra del diseño (ej.: 6Ø1").
    private sealed class PuntoAnotacionAceroEstacionMYG
    {
        public float X { get; set; }
        public float Y { get; set; }
        public string TipoTexto { get; set; }
        public Drawing.Color Color { get; set; }
    }

    private sealed class FilaAnotacionAceroEstacionMYG
    {
        public float YObjetivo { get; set; }
        public float XObjetivo { get; set; }
        public string Texto { get; set; }
        public Drawing.Color Color { get; set; }
    }

    private Drawing.Rectangle ObtenerRectanguloConcretoEstacionVisualMYG(
        Drawing.Rectangle area)
    {
        // INTERMEDIO usa un lienzo más ancho; AVANZADO usa tres lienzos más
        // angostos. La reserva izquierda se adapta para no comprimir en exceso
        // la sección y mantener espacio suficiente para las cotas.
        int margenIzquierdo = area.Width <= 200 ? 48 : 62;
        int margenDerecho = 14;
        int margenY = 25;

        return new Drawing.Rectangle(
            area.Left + margenIzquierdo,
            area.Top + margenY,
            Math.Max(40, area.Width - margenIzquierdo - margenDerecho),
            Math.Max(70, area.Height - 2 * margenY));
    }

    private string ObtenerTextoTipoBarraAnotacionEstacionMYG(
        RebarBarType tipo,
        double diametroMm)
    {
        string nombre = ObtenerNombreTipoBarra(tipo);
        if (!string.IsNullOrWhiteSpace(nombre) && nombre != "--")
        {
            nombre = nombre.Trim();

            // Si el nombre del tipo ya contiene el símbolo Ø, no lo repetimos.
            if (nombre.StartsWith("Ø", StringComparison.Ordinal))
                return nombre;

            return "Ø" + nombre;
        }

        if (diametroMm > 0.01)
        {
            return "Ø" + diametroMm.ToString(
                "0.#",
                System.Globalization.CultureInfo.InvariantCulture) + " mm";
        }

        return string.Empty;
    }

    private void AgregarPuntoAnotacionEstacionMYG(
        List<PuntoAnotacionAceroEstacionMYG> puntos,
        float x,
        float y,
        RebarBarType tipo,
        double diametroMm,
        Drawing.Color color)
    {
        if (puntos == null)
            return;

        puntos.Add(new PuntoAnotacionAceroEstacionMYG
        {
            X = x,
            Y = y,
            TipoTexto = ObtenerTextoTipoBarraAnotacionEstacionMYG(
                tipo,
                diametroMm),
            Color = color
        });
    }

    private void DibujarAnotacionesCantidadEstacionMYG(
        Drawing.Graphics g,
        Drawing.Rectangle area,
        Drawing.Rectangle concreto,
        List<PuntoAnotacionAceroEstacionMYG> puntos)
    {
        if (g == null || puntos == null || puntos.Count == 0)
            return;

        // Agrupar por FILA HORIZONTAL real. Las barras laterales izquierda y
        // derecha que están a la misma altura cuentan como una sola fila, igual
        // que en un detalle estructural convencional.
        const float toleranciaFilaPx = 6.5f;

        List<List<PuntoAnotacionAceroEstacionMYG>> filas =
            new List<List<PuntoAnotacionAceroEstacionMYG>>();

        foreach (PuntoAnotacionAceroEstacionMYG punto in
            puntos.OrderBy(p => p.Y))
        {
            List<PuntoAnotacionAceroEstacionMYG> fila =
                filas.LastOrDefault();

            if (fila == null ||
                Math.Abs(fila.Average(p => p.Y) - punto.Y) > toleranciaFilaPx)
            {
                fila = new List<PuntoAnotacionAceroEstacionMYG>();
                filas.Add(fila);
            }

            fila.Add(punto);
        }

        List<FilaAnotacionAceroEstacionMYG> anotaciones =
            new List<FilaAnotacionAceroEstacionMYG>();

        foreach (List<PuntoAnotacionAceroEstacionMYG> fila in filas)
        {
            if (fila == null || fila.Count == 0)
                continue;

            List<string> partes = new List<string>();

            foreach (IGrouping<string, PuntoAnotacionAceroEstacionMYG> tipoGrupo in
                fila.GroupBy(p => p.TipoTexto ?? string.Empty))
            {
                int cantidad = tipoGrupo.Count();
                string tipoTexto = tipoGrupo.Key ?? string.Empty;

                partes.Add(
                    string.IsNullOrWhiteSpace(tipoTexto)
                        ? cantidad.ToString()
                        : cantidad.ToString() + tipoTexto);
            }

            anotaciones.Add(new FilaAnotacionAceroEstacionMYG
            {
                YObjetivo = (float)fila.Average(p => p.Y),
                XObjetivo = fila.Min(p => p.X),
                Texto = string.Join(" + ", partes),
                Color = fila[0].Color
            });
        }

        if (anotaciones.Count == 0)
            return;

        // Evitar que los textos de capas cercanas se monten unos sobre otros.
        anotaciones = anotaciones
            .OrderBy(a => a.YObjetivo)
            .ToList();

        float minY = area.Top + 9f;
        float maxY = area.Bottom - 9f;
        const float separacionMinima = 14f;
        List<float> posicionesTexto = new List<float>();

        for (int i = 0; i < anotaciones.Count; i++)
        {
            float y = Math.Max(minY, Math.Min(maxY, anotaciones[i].YObjetivo));

            if (i > 0 && y < posicionesTexto[i - 1] + separacionMinima)
                y = posicionesTexto[i - 1] + separacionMinima;

            posicionesTexto.Add(y);
        }

        // Si la última etiqueta sobrepasa el lienzo, se desplaza el conjunto
        // completo hacia arriba conservando su separación.
        if (posicionesTexto.Count > 0 &&
            posicionesTexto[posicionesTexto.Count - 1] > maxY)
        {
            float exceso = posicionesTexto[posicionesTexto.Count - 1] - maxY;
            for (int i = 0; i < posicionesTexto.Count; i++)
                posicionesTexto[i] -= exceso;
        }

        float anchoEtiqueta = Math.Max(30f, concreto.Left - area.Left - 8f);

        using (Drawing.Font fuente = new Drawing.Font(
            "Segoe UI",
            area.Width <= 200 ? 6.6F : 7.4F,
            Drawing.FontStyle.Bold))
        using (Drawing.Pen penLeader = new Drawing.Pen(
            Drawing.Color.FromArgb(95, 105, 115),
            0.8f))
        using (Drawing.StringFormat formato = new Drawing.StringFormat())
        {
            formato.Alignment = Drawing.StringAlignment.Far;
            formato.LineAlignment = Drawing.StringAlignment.Center;

            for (int i = 0; i < anotaciones.Count; i++)
            {
                FilaAnotacionAceroEstacionMYG a = anotaciones[i];
                float yTexto = posicionesTexto[i];

                Drawing.RectangleF rectTexto = new Drawing.RectangleF(
                    area.Left + 2f,
                    yTexto - 7f,
                    Math.Max(20f, anchoEtiqueta - 4f),
                    14f);

                using (Drawing.SolidBrush brochaTexto =
                    new Drawing.SolidBrush(a.Color))
                {
                    g.DrawString(
                        a.Texto ?? string.Empty,
                        fuente,
                        brochaTexto,
                        rectTexto,
                        formato);
                }

                float xInicio = area.Left + anchoEtiqueta - 1f;
                float xQuiebre = concreto.Left - 5f;
                float xDestino = Math.Max(
                    concreto.Left + 1f,
                    a.XObjetivo - 6f);

                g.DrawLine(penLeader, xInicio, yTexto, xQuiebre, yTexto);
                g.DrawLine(penLeader, xQuiebre, yTexto, xDestino, a.YObjetivo);

                Drawing.PointF[] flecha =
                {
                    new Drawing.PointF(xDestino, a.YObjetivo),
                    new Drawing.PointF(xDestino - 4f, a.YObjetivo - 2.3f),
                    new Drawing.PointF(xDestino - 4f, a.YObjetivo + 2.3f)
                };

                using (Drawing.SolidBrush brochaFlecha =
                    new Drawing.SolidBrush(
                        Drawing.Color.FromArgb(95, 105, 115)))
                {
                    g.FillPolygon(brochaFlecha, flecha);
                }
            }
        }
    }


    private BarraHitEstacionEspecialMYG ObtenerHitBarraSeccionEstacionEspecialMYG(
        Drawing.Point click,
        Drawing.Rectangle area,
        AceroVigaDisenoSeccion diseno,
        List<FilaConfiguracionEstacionMYG> filasTramo)
    {
        if (diseno == null || filasTramo == null)
            return null;

        Drawing.Rectangle concreto =
            ObtenerRectanguloConcretoEstacionVisualMYG(area);

        const float radioHit = 10.5f;
        double mejorDistancia2 = double.MaxValue;
        BarraHitEstacionEspecialMYG mejor = null;

        if (diseno.GruposLongitudinales != null)
        {
            foreach (AceroVigaGrupoLongitudinal2D grupo in
                diseno.GruposLongitudinales.Where(g => g != null))
            {
                if (string.IsNullOrWhiteSpace(grupo.Id))
                    continue;

                FilaConfiguracionEstacionMYG fila =
                    filasTramo.FirstOrDefault(f =>
                        f != null &&
                        string.Equals(
                            f.GrupoId,
                            grupo.Id,
                            StringComparison.Ordinal));

                if (fila == null)
                    continue;

                List<AceroVigaBarraLongitudinal2D> defs =
                    ObtenerDefinicionesGrupoEstacionVisualMYG(
                        diseno,
                        grupo);

                for (int i = 0; i < defs.Count; i++)
                {
                    AceroVigaBarraLongitudinal2D def = defs[i];
                    if (def == null || def.Punto == null)
                        continue;

                    double u = Math.Max(0.0, Math.Min(1.0, def.Punto.U));
                    double v = Math.Max(0.0, Math.Min(1.0, def.Punto.V));

                    double xHit = concreto.Left + 10 +
                        u * Math.Max(1, concreto.Width - 20);
                    double yHit = concreto.Bottom - 10 -
                        v * Math.Max(1, concreto.Height - 20);

                    double dx = click.X - xHit;
                    double dy = click.Y - yHit;
                    double d2 = dx * dx + dy * dy;

                    if (d2 <= radioHit * radioHit &&
                        d2 < mejorDistancia2)
                    {
                        mejorDistancia2 = d2;
                        mejor = new BarraHitEstacionEspecialMYG
                        {
                            Fila = fila,
                            Indice = i,
                            GrupoId = grupo.Id
                        };
                    }
                }
            }
        }

        if (diseno.Longitudinales != null)
        {
            foreach (AceroVigaBarraLongitudinal2D def in
                diseno.Longitudinales.Where(b =>
                    b != null &&
                    b.Punto != null &&
                    !b.OcultaPorSuperposicion &&
                    string.IsNullOrWhiteSpace(b.GrupoDistribucionId)))
            {
                FilaConfiguracionEstacionMYG fila =
                    filasTramo.FirstOrDefault(f =>
                        f != null &&
                        !string.IsNullOrWhiteSpace(f.BarraIndividualId) &&
                        string.Equals(
                            f.BarraIndividualId,
                            def.Id,
                            StringComparison.Ordinal));

                if (fila == null || string.IsNullOrWhiteSpace(fila.GrupoId))
                    continue;

                double u = Math.Max(0.0, Math.Min(1.0, def.Punto.U));
                double v = Math.Max(0.0, Math.Min(1.0, def.Punto.V));

                double xHit = concreto.Left + 10 +
                    u * Math.Max(1, concreto.Width - 20);
                double yHit = concreto.Bottom - 10 -
                    v * Math.Max(1, concreto.Height - 20);

                double dx = click.X - xHit;
                double dy = click.Y - yHit;
                double d2 = dx * dx + dy * dy;

                if (d2 <= radioHit * radioHit &&
                    d2 < mejorDistancia2)
                {
                    mejorDistancia2 = d2;
                    mejor = new BarraHitEstacionEspecialMYG
                    {
                        Fila = fila,
                        Indice = 0,
                        GrupoId = fila.GrupoId
                    };
                }
            }
        }

        return mejor;
    }

    private bool EsCapaSuperiorEspecialMYG(
        FilaConfiguracionEstacionMYG fila)
    {
        if (fila == null)
            return false;

        string etiqueta =
            (fila.CapaEtiqueta ?? string.Empty).Trim();

        return etiqueta.StartsWith(
            "Superior",
            StringComparison.OrdinalIgnoreCase);
    }

    private ClasificacionEspecialBarraMYG ObtenerOCrearClasificacionEspecialMYG(
        List<ClasificacionEspecialBarraMYG> lista,
        string grupoId,
        int tramoIndice)
    {
        if (lista == null || string.IsNullOrWhiteSpace(grupoId) || tramoIndice < 0)
            return null;

        ClasificacionEspecialBarraMYG c =
            lista.FirstOrDefault(x =>
                x != null &&
                x.TramoIndice == tramoIndice &&
                string.Equals(
                    x.GrupoId,
                    grupoId,
                    StringComparison.Ordinal));

        if (c == null)
        {
            c = new ClasificacionEspecialBarraMYG
            {
                TramoIndice = tramoIndice,
                GrupoId = grupoId
            };
            lista.Add(c);
        }

        if (c.IndicesBaston == null)
            c.IndicesBaston = new List<int>();
        if (c.IndicesBalancin == null)
            c.IndicesBalancin = new List<int>();

        return c;
    }

    private void LimpiarClasificacionesEspecialesVaciasMYG(
        List<ClasificacionEspecialBarraMYG> lista)
    {
        if (lista == null)
            return;

        lista.RemoveAll(c =>
            c == null ||
            c.TramoIndice < 0 ||
            string.IsNullOrWhiteSpace(c.GrupoId) ||
            ((c.IndicesBaston == null || c.IndicesBaston.Count == 0) &&
             (c.IndicesBalancin == null || c.IndicesBalancin.Count == 0)));
    }

    private void DibujarMarcaClasificacionEspecialMYG(
        Drawing.Graphics g,
        float x,
        float y,
        float radioBase,
        string grupoId,
        int tramoIndice,
        int indice,
        List<ClasificacionEspecialBarraMYG> clasificaciones)
    {
        if (g == null ||
            clasificaciones == null ||
            string.IsNullOrWhiteSpace(grupoId) ||
            tramoIndice < 0 ||
            indice < 0)
        {
            return;
        }

        ClasificacionEspecialBarraMYG c =
            clasificaciones.FirstOrDefault(item =>
                item != null &&
                item.TramoIndice == tramoIndice &&
                string.Equals(
                    item.GrupoId,
                    grupoId,
                    StringComparison.Ordinal));

        if (c == null)
            return;

        bool baston =
            c.IndicesBaston != null &&
            c.IndicesBaston.Contains(indice);
        bool balancin =
            c.IndicesBalancin != null &&
            c.IndicesBalancin.Contains(indice);

        if (!baston && !balancin)
            return;

        if (baston)
        {
            float r = radioBase + 3.0f;
            using (Drawing.Pen pen =
                new Drawing.Pen(
                    Drawing.Color.FromArgb(210, 45, 45),
                    2.0f))
            {
                g.DrawEllipse(
                    pen,
                    x - r,
                    y - r,
                    r * 2f,
                    r * 2f);
            }
        }

        if (balancin)
        {
            float r = radioBase + (baston ? 5.6f : 3.0f);
            using (Drawing.Pen pen =
                new Drawing.Pen(
                    Drawing.Color.FromArgb(125, 55, 180),
                    2.0f))
            {
                g.DrawRectangle(
                    pen,
                    x - r,
                    y - r,
                    r * 2f,
                    r * 2f);
            }
        }
    }

    // V11.24 - FIX CS0136: coordenadas de hit-test no reutilizan el nombre x de lambdas.
    private string AlternarBarraSeccionEstacionVisualMYG(
        Drawing.Point click,
        Drawing.Rectangle area,
        AceroVigaDisenoSeccion diseno,
        List<FilaConfiguracionEstacionMYG> filasTramo,
        int zona,
        bool avanzado)
    {
        if (diseno == null ||
            filasTramo == null)
        {
            return string.Empty;
        }

        Drawing.Rectangle concreto =
            ObtenerRectanguloConcretoEstacionVisualMYG(area);

        const float radioHit = 9.5f;
        double mejorDistancia2 = double.MaxValue;
        FilaConfiguracionEstacionMYG mejorFila = null;
        int mejorIndice = -1;

        if (diseno.GruposLongitudinales != null)
        {
            foreach (AceroVigaGrupoLongitudinal2D grupo in
                diseno.GruposLongitudinales.Where(x => x != null))
            {
                if (string.IsNullOrWhiteSpace(grupo.Id))
                    continue;

                FilaConfiguracionEstacionMYG fila =
                    filasTramo.FirstOrDefault(x =>
                        x != null &&
                        string.Equals(
                            x.GrupoId,
                            grupo.Id,
                            StringComparison.Ordinal));

                if (fila == null)
                    continue;

                List<AceroVigaBarraLongitudinal2D> defs =
                    ObtenerDefinicionesGrupoEstacionVisualMYG(
                        diseno,
                        grupo);

                for (int i = 0; i < defs.Count; i++)
                {
                    AceroVigaBarraLongitudinal2D def = defs[i];
                    if (def == null || def.Punto == null)
                        continue;

                    double u = Math.Max(0.0, Math.Min(1.0, def.Punto.U));
                    double v = Math.Max(0.0, Math.Min(1.0, def.Punto.V));

                    double xBarraHit = concreto.Left + 10 +
                        u * Math.Max(1, concreto.Width - 20);
                    double yBarraHit = concreto.Bottom - 10 -
                        v * Math.Max(1, concreto.Height - 20);

                    double dx = click.X - xBarraHit;
                    double dy = click.Y - yBarraHit;
                    double d2 = dx * dx + dy * dy;

                    if (d2 <= radioHit * radioHit &&
                        d2 < mejorDistancia2)
                    {
                        mejorDistancia2 = d2;
                        mejorFila = fila;
                        mejorIndice = i;
                    }
                }
            }
        }

        // También se pueden alternar las barras creadas individualmente
        // desde la sección principal.
        if (diseno.Longitudinales != null)
        {
            foreach (AceroVigaBarraLongitudinal2D def in
                diseno.Longitudinales.Where(x =>
                    x != null &&
                    x.Punto != null &&
                    !x.OcultaPorSuperposicion &&
                    string.IsNullOrWhiteSpace(x.GrupoDistribucionId)))
            {
                FilaConfiguracionEstacionMYG fila =
                    filasTramo.FirstOrDefault(x =>
                        x != null &&
                        !string.IsNullOrWhiteSpace(
                            x.BarraIndividualId) &&
                        string.Equals(
                            x.BarraIndividualId,
                            def.Id,
                            StringComparison.Ordinal));

                if (fila == null)
                    continue;

                double u = Math.Max(0.0, Math.Min(1.0, def.Punto.U));
                double v = Math.Max(0.0, Math.Min(1.0, def.Punto.V));

                double xBarraHit = concreto.Left + 10 +
                    u * Math.Max(1, concreto.Width - 20);
                double yBarraHit = concreto.Bottom - 10 -
                    v * Math.Max(1, concreto.Height - 20);

                double dx = click.X - xBarraHit;
                double dy = click.Y - yBarraHit;
                double d2 = dx * dx + dy * dy;

                if (d2 <= radioHit * radioHit &&
                    d2 < mejorDistancia2)
                {
                    mejorDistancia2 = d2;
                    mejorFila = fila;
                    mejorIndice = 0;
                }
            }
        }

        if (mejorFila == null || mejorIndice < 0)
            return string.Empty;

        List<int> activos =
            ObtenerIndicesActivosZonaEstacionVisualMYG(
                mejorFila,
                zona,
                avanzado);

        if (activos.Contains(mejorIndice))
            activos.Remove(mejorIndice);
        else
            activos.Add(mejorIndice);

        AsignarIndicesZonaEstacionVisualMYG(
            mejorFila,
            zona,
            avanzado,
            activos);

        return mejorFila.GrupoId ?? string.Empty;
    }

    private List<AceroVigaBarraLongitudinal2D>
        ObtenerDefinicionesGrupoEstacionVisualMYG(
            AceroVigaDisenoSeccion diseno,
            AceroVigaGrupoLongitudinal2D grupo)
    {
        if (diseno == null || grupo == null ||
            diseno.Longitudinales == null)
        {
            return new List<AceroVigaBarraLongitudinal2D>();
        }

        List<AceroVigaBarraLongitudinal2D> lista =
            diseno.Longitudinales
                .Where(x =>
                    x != null &&
                    x.Punto != null &&
                    !x.OcultaPorSuperposicion &&
                    string.Equals(
                        x.GrupoDistribucionId,
                        grupo.Id,
                        StringComparison.Ordinal))
                .ToList();

        if (lista.Count <= 1)
            return lista;

        try
        {
            if (lista.All(x => x.ParametroSobreGuia >= 0.0))
            {
                bool ascendente =
                    grupo.ParametroFinGuia >= grupo.ParametroInicioGuia;

                return ascendente
                    ? lista.OrderBy(x => x.ParametroSobreGuia).ToList()
                    : lista.OrderByDescending(x => x.ParametroSobreGuia).ToList();
            }
        }
        catch
        {
        }

        return lista
            .OrderBy(x => x.Punto.U)
            .ThenByDescending(x => x.Punto.V)
            .ToList();
    }

    private int ObtenerCantidadZonaEstacionVisualMYG(
        FilaConfiguracionEstacionMYG fila,
        int zona,
        bool avanzado)
    {
        if (fila == null)
            return 0;

        if (!avanzado)
            return Math.Max(0, fila.CantidadCentro);

        if (zona <= 0)
            return Math.Max(0, fila.CantidadIzquierda);
        if (zona >= 2)
            return Math.Max(0, fila.CantidadDerecha);
        return Math.Max(0, fila.CantidadCentro);
    }

    private void DibujarSeccionEstacionVisualMYG(
        Drawing.Graphics g,
        Drawing.Rectangle area,
        AceroVigaDisenoSeccion diseno,
        List<FilaConfiguracionEstacionMYG> filasTramo,
        int zona,
        bool avanzado,
        List<ClasificacionEspecialBarraMYG> clasificacionesEspeciales)
    {
        if (g == null || diseno == null)
        {
            return;
        }

        int tramoIndiceVisual =
            filasTramo != null
                ? filasTramo
                    .Where(f => f != null)
                    .Select(f => f.TramoIndice)
                    .DefaultIfEmpty(-1)
                    .First()
                : -1;

        g.SmoothingMode =
            System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

        List<PuntoAnotacionAceroEstacionMYG> puntosAnotacion =
            new List<PuntoAnotacionAceroEstacionMYG>();

        Drawing.Rectangle concreto =
            ObtenerRectanguloConcretoEstacionVisualMYG(area);

        using (Drawing.SolidBrush brochaConcreto =
            new Drawing.SolidBrush(Drawing.Color.FromArgb(242, 244, 247)))
        using (Drawing.Pen penConcreto =
            new Drawing.Pen(Drawing.Color.FromArgb(55, 65, 75), 1.4f))
        using (Drawing.Pen penEstribo =
            new Drawing.Pen(Drawing.Color.FromArgb(215, 115, 55), 2.0f))
        {
            g.FillRectangle(brochaConcreto, concreto);
            g.DrawRectangle(penConcreto, concreto);

            Drawing.Rectangle estribo = Drawing.Rectangle.Inflate(
                concreto,
                -10,
                -10);
            g.DrawRectangle(penEstribo, estribo);
        }

        if (diseno.GruposLongitudinales != null)
        {
            foreach (AceroVigaGrupoLongitudinal2D grupo in
                diseno.GruposLongitudinales.Where(grupoItem => grupoItem != null))
            {
                if (string.IsNullOrWhiteSpace(grupo.Id))
                    continue;

                FilaConfiguracionEstacionMYG fila =
                    filasTramo != null
                        ? filasTramo.FirstOrDefault(filaGrupo =>
                            filaGrupo != null &&
                            string.Equals(
                                filaGrupo.GrupoId,
                                grupo.Id,
                                StringComparison.Ordinal))
                        : null;

                List<AceroVigaBarraLongitudinal2D> defs =
                    ObtenerDefinicionesGrupoEstacionVisualMYG(
                        diseno,
                        grupo);

                if (defs.Count == 0)
                    continue;

                HashSet<int> activos = new HashSet<int>(
                    ObtenerIndicesActivosZonaEstacionVisualMYG(
                        fila,
                        zona,
                        avanzado)
                    .Where(indiceActivo => indiceActivo >= 0 && indiceActivo < defs.Count));

                Drawing.Color color = ObtenerColorCapaEstacionVisualMYG(
                    fila != null
                        ? fila.CapaEtiqueta
                        : ObtenerEtiquetaGrupoEstacionesMYG(grupo, diseno));

                for (int i = 0; i < defs.Count; i++)
                {
                    AceroVigaBarraLongitudinal2D def = defs[i];
                    if (def == null || def.Punto == null)
                        continue;

                    double u = Math.Max(0.0, Math.Min(1.0, def.Punto.U));
                    double v = Math.Max(0.0, Math.Min(1.0, def.Punto.V));

                    float xGrupo = (float)(
                        concreto.Left + 10 +
                        u * Math.Max(1, concreto.Width - 20));
                    float yGrupo = (float)(
                        concreto.Bottom - 10 -
                        v * Math.Max(1, concreto.Height - 20));

                    float radio = 4.7f;
                    Drawing.RectangleF circulo = new Drawing.RectangleF(
                        xGrupo - radio,
                        yGrupo - radio,
                        radio * 2f,
                        radio * 2f);

                    if (activos.Contains(i))
                    {
                        using (Drawing.SolidBrush b =
                            new Drawing.SolidBrush(color))
                        using (Drawing.Pen p =
                            new Drawing.Pen(Drawing.Color.White, 0.8f))
                        {
                            g.FillEllipse(b, circulo);
                            g.DrawEllipse(p, circulo);
                        }

                        AgregarPuntoAnotacionEstacionMYG(
                            puntosAnotacion,
                            xGrupo,
                            yGrupo,
                            def.TipoBarra ?? grupo.TipoBarra,
                            def.DiametroMm > 0.01
                                ? def.DiametroMm
                                : grupo.DiametroMm,
                            color);
                    }
                    else
                    {
                        using (Drawing.SolidBrush b =
                            new Drawing.SolidBrush(
                                Drawing.Color.FromArgb(225, 228, 232)))
                        using (Drawing.Pen p =
                            new Drawing.Pen(
                                Drawing.Color.FromArgb(160, 165, 170),
                                0.8f))
                        {
                            g.FillEllipse(b, circulo);
                            g.DrawEllipse(p, circulo);
                        }
                    }

                    // V11.38: la marca especial solo se muestra donde la barra
                    // está activa en esta sección/zona.
                    if (activos.Contains(i))
                    {
                        DibujarMarcaClasificacionEspecialMYG(
                            g,
                            xGrupo,
                            yGrupo,
                            radio,
                            grupo.Id,
                            tramoIndiceVisual,
                            i,
                            clasificacionesEspeciales);
                    }
                }
            }
        }

        // Barras individuales dibujadas con AGREGAR BARRA.
        if (diseno.Longitudinales != null)
        {
            foreach (AceroVigaBarraLongitudinal2D def in
                diseno.Longitudinales.Where(barraItem =>
                    barraItem != null &&
                    barraItem.Punto != null &&
                    !barraItem.OcultaPorSuperposicion &&
                    string.IsNullOrWhiteSpace(barraItem.GrupoDistribucionId)))
            {
                FilaConfiguracionEstacionMYG fila =
                    filasTramo != null
                        ? filasTramo.FirstOrDefault(filaIndividual =>
                            filaIndividual != null &&
                            !string.IsNullOrWhiteSpace(
                                filaIndividual.BarraIndividualId) &&
                            string.Equals(
                                filaIndividual.BarraIndividualId,
                                def.Id,
                                StringComparison.Ordinal))
                        : null;

                if (fila == null)
                    continue;

                HashSet<int> activos = new HashSet<int>(
                    ObtenerIndicesActivosZonaEstacionVisualMYG(
                        fila,
                        zona,
                        avanzado));

                double u = Math.Max(0.0, Math.Min(1.0, def.Punto.U));
                double v = Math.Max(0.0, Math.Min(1.0, def.Punto.V));

                float xBarraIndividual = (float)(
                    concreto.Left + 10 +
                    u * Math.Max(1, concreto.Width - 20));
                float yBarraIndividual = (float)(
                    concreto.Bottom - 10 -
                    v * Math.Max(1, concreto.Height - 20));

                float radio = 4.7f;
                Drawing.RectangleF circulo = new Drawing.RectangleF(
                    xBarraIndividual - radio,
                    yBarraIndividual - radio,
                    radio * 2f,
                    radio * 2f);

                Drawing.Color color =
                    ObtenerColorCapaEstacionVisualMYG(
                        fila.CapaEtiqueta);

                if (activos.Contains(0))
                {
                    using (Drawing.SolidBrush b =
                        new Drawing.SolidBrush(color))
                    using (Drawing.Pen p =
                        new Drawing.Pen(Drawing.Color.White, 0.8f))
                    {
                        g.FillEllipse(b, circulo);
                        g.DrawEllipse(p, circulo);
                    }

                    AgregarPuntoAnotacionEstacionMYG(
                        puntosAnotacion,
                        xBarraIndividual,
                        yBarraIndividual,
                        def.TipoBarra,
                        def.DiametroMm,
                        color);
                }
                else
                {
                    using (Drawing.SolidBrush b =
                        new Drawing.SolidBrush(
                            Drawing.Color.FromArgb(225, 228, 232)))
                    using (Drawing.Pen p =
                        new Drawing.Pen(
                            Drawing.Color.FromArgb(160, 165, 170),
                            0.8f))
                    {
                        g.FillEllipse(b, circulo);
                        g.DrawEllipse(p, circulo);
                    }
                }

                if (activos.Contains(0))
                {
                    DibujarMarcaClasificacionEspecialMYG(
                        g,
                        xBarraIndividual,
                        yBarraIndividual,
                        radio,
                        fila.GrupoId,
                        tramoIndiceVisual,
                        0,
                        clasificacionesEspeciales);
                }
            }
        }

        DibujarAnotacionesCantidadEstacionMYG(
            g,
            area,
            concreto,
            puntosAnotacion);
    }

    private string ConstruirTextoContinuidadTramoVisualMYG(
        List<FilaConfiguracionEstacionMYG> trabajo,
        int tramoIndice,
        bool avanzado)
    {
        if (trabajo == null || tramoIndice <= 0)
            return "INICIO DE SERIE";

        List<string> comunes = new List<string>();

        List<FilaConfiguracionEstacionMYG> actuales = trabajo
            .Where(x => x != null && x.TramoIndice == tramoIndice)
            .OrderBy(x => ObtenerOrdenCapaEstacionVisualMYG(x.CapaEtiqueta))
            .ToList();

        foreach (FilaConfiguracionEstacionMYG actual in actuales)
        {
            FilaConfiguracionEstacionMYG anterior = trabajo.FirstOrDefault(x =>
                x != null &&
                x.TramoIndice == tramoIndice - 1 &&
                string.Equals(
                    x.GrupoId,
                    actual.GrupoId,
                    StringComparison.Ordinal));

            if (anterior == null)
                continue;

            List<int> indicesAnterior =
                ObtenerIndicesActivosZonaEstacionVisualMYG(
                    anterior,
                    avanzado ? 2 : 1,
                    avanzado);
            List<int> indicesActual =
                ObtenerIndicesActivosZonaEstacionVisualMYG(
                    actual,
                    avanzado ? 0 : 1,
                    avanzado);

            int comun = indicesAnterior
                .Intersect(indicesActual)
                .Distinct()
                .Count();

            if (comun > 0)
            {
                comunes.Add(
                    (actual.CapaEtiqueta ?? "Longitudinal") +
                    ": " + comun.ToString());
            }
        }

        if (comunes.Count == 0)
            return "SIN BARRAS COMUNES CON T" + tramoIndice.ToString();

        return "CONTINÚAN DESDE T" + tramoIndice.ToString() +
               "  |  " + string.Join("   •   ", comunes);
    }

    private void MostrarConfiguracionDesarrollosDiametroMYG(
        AceroVigaDisenoSeccion diseno,
        Dictionary<int, double> desarrollosTrabajo,
        WinForms.Form propietario)
    {
        if (desarrollosTrabajo == null)
            return;

        AsegurarDesarrollosPorDiametroDesdeDisenoMYG(diseno, desarrollosTrabajo);

        Dictionary<int, RebarBarType> tiposPorClave =
            new Dictionary<int, RebarBarType>();

        if (diseno != null && diseno.Longitudinales != null)
        {
            foreach (AceroVigaBarraLongitudinal2D barra in diseno.Longitudinales
                .Where(b => b != null && b.TipoBarra != null))
            {
                double dbMm = ObtenerDiametroBarraMm(barra.TipoBarra);
                int clave = ObtenerClaveDiametroDesarrolloMYG(dbMm);
                if (clave > 0 && !tiposPorClave.ContainsKey(clave))
                    tiposPorClave[clave] = barra.TipoBarra;
            }
        }

        WinForms.Form sub = new WinForms.Form
        {
            Text = "MYG - Desarrollo de corte por diámetro",
            Width = 530,
            Height = 430,
            MinimumSize = new Drawing.Size(470, 330),
            StartPosition = WinForms.FormStartPosition.CenterParent,
            BackColor = Drawing.Color.White,
            Font = new Drawing.Font("Segoe UI", 9F),
            MinimizeBox = false,
            MaximizeBox = false,
            TopMost = true
        };

        WinForms.Label titulo = new WinForms.Label
        {
            Left = 16,
            Top = 14,
            Width = 475,
            Height = 42,
            Font = new Drawing.Font("Segoe UI", 9.5F, Drawing.FontStyle.Bold),
            Text = "DESARROLLO CUANDO UNA BARRA DESAPARECE EN LA ZONA / TRAMO SIGUIENTE"
        };
        sub.Controls.Add(titulo);

        WinForms.Label ayuda = new WinForms.Label
        {
            Left = 16,
            Top = 55,
            Width = 475,
            Height = 42,
            ForeColor = Drawing.Color.FromArgb(85, 90, 95),
            Text = "Sin unidad se interpreta en cm. También acepta mm, cm, m, in o \". " +
                   "El valor se aplica después del punto donde esa barra deja de continuar."
        };
        sub.Controls.Add(ayuda);

        WinForms.Panel cab = new WinForms.Panel
        {
            Left = 16,
            Top = 103,
            Width = 485,
            Height = 28,
            BackColor = Drawing.Color.FromArgb(242, 244, 247)
        };
        cab.Controls.Add(new WinForms.Label
        {
            Left = 10,
            Top = 6,
            Width = 285,
            Height = 20,
            Text = "DIÁMETRO / TIPO",
            Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold)
        });
        cab.Controls.Add(new WinForms.Label
        {
            Left = 315,
            Top = 6,
            Width = 140,
            Height = 20,
            Text = "DESARROLLO",
            TextAlign = Drawing.ContentAlignment.MiddleCenter,
            Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold)
        });
        sub.Controls.Add(cab);

        WinForms.FlowLayoutPanel flujoDes = new WinForms.FlowLayoutPanel
        {
            Left = 16,
            Top = 133,
            Width = 485,
            Height = 205,
            FlowDirection = WinForms.FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = true,
            BackColor = Drawing.Color.White
        };
        sub.Controls.Add(flujoDes);

        Dictionary<int, WinForms.TextBox> cajas =
            new Dictionary<int, WinForms.TextBox>();

        List<int> claves = desarrollosTrabajo.Keys
            .Where(k => k > 0)
            .Distinct()
            .OrderBy(k => k)
            .ToList();

        if (claves.Count == 0)
        {
            flujoDes.Controls.Add(new WinForms.Label
            {
                Width = 450,
                Height = 35,
                Text = "No se encontraron diámetros en la sección actual.",
                ForeColor = Drawing.Color.Gray,
                TextAlign = Drawing.ContentAlignment.MiddleLeft
            });
        }

        foreach (int clave in claves)
        {
            int claveLocal = clave;
            double dbMm = clave / 100.0;
            RebarBarType tipo = null;
            tiposPorClave.TryGetValue(clave, out tipo);

            WinForms.Panel fila = new WinForms.Panel
            {
                Width = 460,
                Height = 38,
                BackColor = Drawing.Color.White
            };

            fila.Controls.Add(new WinForms.Label
            {
                Left = 8,
                Top = 9,
                Width = 285,
                Height = 22,
                Text = ObtenerEtiquetaDiametroDesarrolloMYG(tipo, dbMm)
            });

            WinForms.TextBox txt = new WinForms.TextBox
            {
                Left = 315,
                Top = 6,
                Width = 85,
                Text = desarrollosTrabajo[clave].ToString(
                    "0.##",
                    System.Globalization.CultureInfo.InvariantCulture)
            };
            cajas[claveLocal] = txt;
            fila.Controls.Add(txt);

            fila.Controls.Add(new WinForms.Label
            {
                Left = 405,
                Top = 9,
                Width = 35,
                Height = 22,
                Text = "cm",
                ForeColor = Drawing.Color.Gray
            });

            flujoDes.Controls.Add(fila);
        }

        WinForms.Button btnAplicarDes = new WinForms.Button
        {
            Text = "APLICAR",
            Width = 120,
            Height = 32,
            Left = 381,
            Top = 350,
            Anchor = WinForms.AnchorStyles.Right | WinForms.AnchorStyles.Bottom
        };
        sub.Controls.Add(btnAplicarDes);

        WinForms.Button btnCerrarDes = new WinForms.Button
        {
            Text = "CERRAR",
            Width = 120,
            Height = 32,
            Left = 251,
            Top = 350,
            Anchor = WinForms.AnchorStyles.Right | WinForms.AnchorStyles.Bottom
        };
        sub.Controls.Add(btnCerrarDes);

        btnAplicarDes.Click += (s, e) =>
        {
            foreach (KeyValuePair<int, WinForms.TextBox> par in cajas)
            {
                double cm;
                if (!TryConvertirDesarrolloTextoACmMYG(par.Value.Text, out cm))
                {
                    WinForms.MessageBox.Show(
                        "Revise el desarrollo del diámetro " +
                        (par.Key / 100.0).ToString("0.##", System.Globalization.CultureInfo.InvariantCulture) +
                        " mm.\n\nEjemplos válidos: 120, 120.5, 1.20m, 48in.",
                        "MYG - Desarrollo por diámetro",
                        WinForms.MessageBoxButtons.OK,
                        WinForms.MessageBoxIcon.Warning);
                    par.Value.Focus();
                    return;
                }

                desarrollosTrabajo[par.Key] = Math.Max(0.0, cm);
                par.Value.Text = FormatearCmParaTexto(cm);
            }

            sub.Close();
        };

        btnCerrarDes.Click += (s, e) => sub.Close();

        // MODELESS: no bloquea Revit ni la ventana principal.
        try
        {
            if (propietario != null && !propietario.IsDisposed)
                sub.Show(propietario);
            else
                sub.Show();
            sub.BringToFront();
            sub.Activate();
        }
        catch
        {
            sub.Show();
        }
    }

    private void MostrarConfiguracionEstacionesMYG()
    {
        // V11.29: la configuración por tramos es MODELESS.
        // Si ya está abierta, no se crea otra instancia; simplemente se trae al frente.
        if (ventanaConfiguracionEstacionesMYG != null &&
            !ventanaConfiguracionEstacionesMYG.IsDisposed)
        {
            try
            {
                if (!ventanaConfiguracionEstacionesMYG.Visible)
                    ventanaConfiguracionEstacionesMYG.Show();

                ventanaConfiguracionEstacionesMYG.WindowState =
                    WinForms.FormWindowState.Normal;
                ventanaConfiguracionEstacionesMYG.BringToFront();
                ventanaConfiguracionEstacionesMYG.Activate();
            }
            catch
            {
            }
            return;
        }

        if (ModoDistribucionLongitudinalActualMYG ==
            ModoDistribucionLongitudinalMYG.Continuo)
        {
            return;
        }

        SincronizarConfiguracionEstacionesConModeloMYG();

        if (configuracionEstacionesLongitudinalMYG.Count == 0)
        {
            WinForms.MessageBox.Show(
                "Primero seleccione la serie de vigas y cree en la sección " +
                "principal los aceros que desea usar como catálogo base.",
                "MYG - Estaciones",
                WinForms.MessageBoxButtons.OK,
                WinForms.MessageBoxIcon.Information);
            return;
        }

        AceroVigaDisenoSeccion diseno = ObtenerDisenoActualEstacionesMYG();
        SerieContinuaPreview serie =
            previewVigas != null && previewVigas.Count > 0
                ? ConstruirSerieContinua(previewVigas)
                : null;

        if (diseno == null || serie == null ||
            serie.TramosViga == null || serie.TramosViga.Count == 0)
        {
            WinForms.MessageBox.Show(
                "No se pudo construir la geometría visual por tramos. " +
                "Vuelva a seleccionar la serie de vigas.",
                "MYG - Estaciones",
                WinForms.MessageBoxButtons.OK,
                WinForms.MessageBoxIcon.Warning);
            return;
        }

        bool avanzado =
            ModoDistribucionLongitudinalActualMYG ==
            ModoDistribucionLongitudinalMYG.EstacionesAvanzado;

        // Se trabaja sobre una copia. CANCELAR no modifica la configuración real.
        List<FilaConfiguracionEstacionMYG> trabajo =
            configuracionEstacionesLongitudinalMYG
                .Where(x => x != null)
                .Select(x => x.Copiar())
                .ToList();

        // V11.32: copia de trabajo para desarrollos por diámetro. CANCELAR en la
        // ventana principal por tramos también descarta los cambios de desarrollo.
        Dictionary<int, double> desarrollosTrabajo =
            desarrollosCortePorDiametroCmMYG.ToDictionary(
                x => x.Key,
                x => x.Value);
        AsegurarDesarrollosPorDiametroDesdeDisenoMYG(
            diseno,
            desarrollosTrabajo);

        // V11.39: copia de trabajo de la clasificación especial POR TRAMO.
        // CANCELAR/X no modifica la clasificación real.
        List<ClasificacionEspecialBarraMYG> clasificacionesTrabajo =
            clasificacionesEspecialesLongitudinalMYG
                .Where(c => c != null)
                .Select(c => c.Copiar())
                .ToList();

        // No usar ShowDialog/using aquí: esta ventana debe permanecer MODELESS
        // para permitir seguir haciendo zoom, pan, seleccionar y trabajar en Revit.
        WinForms.Form dlg = new WinForms.Form();
        ventanaConfiguracionEstacionesMYG = dlg;
        {
            dlg.Text = avanzado
                ? "MYG - Acero por tramos | AVANZADO"
                : "MYG - Acero por tramos | INTERMEDIO";
            dlg.Width = 1320;
            dlg.Height = 820;
            dlg.MinimumSize = new Drawing.Size(1050, 650);
            dlg.StartPosition = WinForms.FormStartPosition.CenterParent;
            dlg.MinimizeBox = false;
            dlg.MaximizeBox = true;
            dlg.BackColor = Drawing.Color.FromArgb(245, 247, 250);
            dlg.Font = new Drawing.Font("Segoe UI", 9F);

            WinForms.Panel cabecera = new WinForms.Panel
            {
                Dock = WinForms.DockStyle.Top,
                Height = 122,
                BackColor = Drawing.Color.White,
                Padding = new WinForms.Padding(14, 10, 14, 8)
            };
            dlg.Controls.Add(cabecera);

            WinForms.Label titulo = new WinForms.Label
            {
                Left = 14,
                Top = 10,
                Width = 805,
                Height = 24,
                Font = new Drawing.Font(
                    "Segoe UI",
                    10F,
                    Drawing.FontStyle.Bold),
                Text = avanzado
                    ? "AVANZADO — cada tramo muestra IZQUIERDA / CENTRO / DERECHA"
                    : "INTERMEDIO — una sección de armado independiente por tramo"
            };
            cabecera.Controls.Add(titulo);

            WinForms.Label ayuda = new WinForms.Label
            {
                Left = 14,
                Top = 38,
                Width = 980,
                Height = 40,
                ForeColor = Drawing.Color.FromArgb(85, 90, 95),
                Text = avanzado
                    ? "CLIC directamente sobre cualquier círculo para ACTIVAR / DESACTIVAR esa barra en IZQUIERDA, CENTRO o DERECHA. " +
                      "Los valores numéricos siguen disponibles para cambios rápidos y reconstruyen una selección simétrica."
                    : "CLIC directamente sobre cualquier círculo para ACTIVAR / DESACTIVAR esa barra en todo el tramo. " +
                      "El control numérico sigue disponible para cambios rápidos; la continuidad se calcula por la posición exacta."
            };
            cabecera.Controls.Add(ayuda);

            WinForms.Label lblExt = new WinForms.Label
            {
                Text = "Extensión al aparecer:",
                Left = 845,
                Top = 14,
                Width = 150,
                Height = 24
            };
            cabecera.Controls.Add(lblExt);

            WinForms.TextBox txtExt = new WinForms.TextBox
            {
                Left = 995,
                Top = 11,
                Width = 62,
                Text = extensionCambiosEstacionesCmMYG.ToString(
                    "0.##",
                    System.Globalization.CultureInfo.InvariantCulture)
            };
            cabecera.Controls.Add(txtExt);

            cabecera.Controls.Add(new WinForms.Label
            {
                Text = "cm",
                Left = 1061,
                Top = 14,
                Width = 32,
                Height = 24,
                ForeColor = Drawing.Color.Gray
            });

            WinForms.Button btnDesarrollosDiametro = new WinForms.Button
            {
                Text = "DESARROLLOS Ø...",
                Left = 1098,
                Top = 9,
                Width = 145,
                Height = 30,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };
            btnDesarrollosDiametro.FlatAppearance.BorderColor =
                Drawing.Color.FromArgb(145, 155, 165);
            btnDesarrollosDiametro.Click += (s, e) =>
                MostrarConfiguracionDesarrollosDiametroMYG(
                    diseno,
                    desarrollosTrabajo,
                    dlg);
            cabecera.Controls.Add(btnDesarrollosDiametro);

            // V11.38 - modos de selección de barras especiales.
            // 0 = edición normal de presencia, 1 = bastón, 2 = balancín.
            int modoSeleccionEspecialMYG = 0;

            WinForms.Button btnEsBaston = new WinForms.Button
            {
                Text = "ES BASTÓN",
                Left = 845,
                Top = 70,
                Width = 125,
                Height = 30,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            WinForms.Button btnEsBalancin = new WinForms.Button
            {
                Text = "ES BALANCÍN",
                Left = 978,
                Top = 70,
                Width = 135,
                Height = 30,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            WinForms.Label lblModoEspecial = new WinForms.Label
            {
                Left = 1120,
                Top = 72,
                Width = 165,
                Height = 28,
                TextAlign = Drawing.ContentAlignment.MiddleLeft,
                ForeColor = Drawing.Color.FromArgb(85, 90, 95),
                Text = "Modo: ACTIVAR/QUITAR"
            };

            Action refrescarEstadoBotonesEspeciales = () =>
            {
                btnEsBaston.BackColor =
                    modoSeleccionEspecialMYG == 1
                        ? Drawing.Color.FromArgb(255, 225, 225)
                        : Drawing.Color.White;
                btnEsBaston.FlatAppearance.BorderColor =
                    modoSeleccionEspecialMYG == 1
                        ? Drawing.Color.FromArgb(200, 45, 45)
                        : Drawing.Color.FromArgb(145, 155, 165);

                btnEsBalancin.BackColor =
                    modoSeleccionEspecialMYG == 2
                        ? Drawing.Color.FromArgb(238, 226, 250)
                        : Drawing.Color.White;
                btnEsBalancin.FlatAppearance.BorderColor =
                    modoSeleccionEspecialMYG == 2
                        ? Drawing.Color.FromArgb(125, 55, 180)
                        : Drawing.Color.FromArgb(145, 155, 165);

                lblModoEspecial.Text =
                    modoSeleccionEspecialMYG == 1
                        ? "Modo: BASTÓN"
                        : (modoSeleccionEspecialMYG == 2
                            ? "Modo: BALANCÍN"
                            : "Modo: ACTIVAR/QUITAR");
            };

            btnEsBaston.Click += (s, e) =>
            {
                modoSeleccionEspecialMYG =
                    modoSeleccionEspecialMYG == 1 ? 0 : 1;
                refrescarEstadoBotonesEspeciales();
            };

            btnEsBalancin.Click += (s, e) =>
            {
                modoSeleccionEspecialMYG =
                    modoSeleccionEspecialMYG == 2 ? 0 : 2;
                refrescarEstadoBotonesEspeciales();
            };

            cabecera.Controls.Add(btnEsBaston);
            cabecera.Controls.Add(btnEsBalancin);
            cabecera.Controls.Add(lblModoEspecial);
            refrescarEstadoBotonesEspeciales();

            WinForms.FlowLayoutPanel flujo = new WinForms.FlowLayoutPanel
            {
                Dock = WinForms.DockStyle.Fill,
                FlowDirection = WinForms.FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true,
                Padding = new WinForms.Padding(12, 10, 12, 10),
                BackColor = Drawing.Color.FromArgb(245, 247, 250)
            };
            dlg.Controls.Add(flujo);
            flujo.BringToFront();

            WinForms.Panel pie = new WinForms.Panel
            {
                Dock = WinForms.DockStyle.Bottom,
                Height = 58,
                BackColor = Drawing.Color.White
            };
            dlg.Controls.Add(pie);
            pie.BringToFront();

            // Controles por clave tramo|grupo. Permite copiar tramo y refrescar
            // la sección sin depender de una DataGrid abstracta.
            Dictionary<string, List<WinForms.NumericUpDown>> controles =
                new Dictionary<string, List<WinForms.NumericUpDown>>();
            Dictionary<int, List<WinForms.Panel>> lienzosPorTramo =
                new Dictionary<int, List<WinForms.Panel>>();
            Dictionary<int, WinForms.Label> labelsContinuidad =
                new Dictionary<int, WinForms.Label>();

            // Evita que una actualización visual del NumericUpDown borre una
            // selección manual exacta realizada con clic sobre una barra.
            bool sincronizandoControlesEstacionesMYG = false;

            Action<int> refrescarTramo = (indice) =>
            {
                List<WinForms.Panel> lienzos;
                if (lienzosPorTramo.TryGetValue(indice, out lienzos) &&
                    lienzos != null)
                {
                    foreach (WinForms.Panel p in lienzos)
                        if (p != null) p.Invalidate();
                }

                WinForms.Label lbl;
                if (labelsContinuidad.TryGetValue(indice, out lbl) && lbl != null)
                {
                    lbl.Text = ConstruirTextoContinuidadTramoVisualMYG(
                        trabajo,
                        indice,
                        avanzado);
                }

                // El tramo siguiente depende del borde derecho del actual.
                if (labelsContinuidad.TryGetValue(indice + 1, out lbl) && lbl != null)
                {
                    lbl.Text = ConstruirTextoContinuidadTramoVisualMYG(
                        trabajo,
                        indice + 1,
                        avanzado);
                }
            };

            Action refrescarTodasSeccionesEspeciales = () =>
            {
                foreach (List<WinForms.Panel> listaLienzos in
                    lienzosPorTramo.Values)
                {
                    if (listaLienzos == null)
                        continue;

                    foreach (WinForms.Panel p in listaLienzos)
                        if (p != null) p.Invalidate();
                }
            };

            Action<int, int> copiarTramo = (origenIndice, destinoIndice) =>
            {
                List<FilaConfiguracionEstacionMYG> origen = trabajo
                    .Where(x => x != null && x.TramoIndice == origenIndice)
                    .ToList();

                foreach (FilaConfiguracionEstacionMYG fOrigen in origen)
                {
                    FilaConfiguracionEstacionMYG fDestino = trabajo.FirstOrDefault(x =>
                        x != null &&
                        x.TramoIndice == destinoIndice &&
                        string.Equals(x.GrupoId, fOrigen.GrupoId, StringComparison.Ordinal));
                    if (fDestino == null)
                        continue;

                    // V11.23: copiar también las posiciones exactas activas,
                    // no solamente la cantidad.
                    fDestino.IndicesActivosIzquierda =
                        SanitizarIndicesEstacionVisualMYG(
                            fOrigen.IndicesActivosIzquierda,
                            fDestino.CantidadMaxima);
                    fDestino.IndicesActivosCentro =
                        SanitizarIndicesEstacionVisualMYG(
                            fOrigen.IndicesActivosCentro,
                            fDestino.CantidadMaxima);
                    fDestino.IndicesActivosDerecha =
                        SanitizarIndicesEstacionVisualMYG(
                            fOrigen.IndicesActivosDerecha,
                            fDestino.CantidadMaxima);

                    fDestino.SeleccionExplicitaIzquierda = true;
                    fDestino.SeleccionExplicitaCentro = true;
                    fDestino.SeleccionExplicitaDerecha = true;

                    fDestino.CantidadIzquierda =
                        fDestino.IndicesActivosIzquierda.Count;
                    fDestino.CantidadCentro =
                        fDestino.IndicesActivosCentro.Count;
                    fDestino.CantidadDerecha =
                        fDestino.IndicesActivosDerecha.Count;

                    string clave = destinoIndice.ToString() + "|" + fDestino.GrupoId;
                    List<WinForms.NumericUpDown> nums;
                    if (controles.TryGetValue(clave, out nums) && nums != null)
                    {
                        sincronizandoControlesEstacionesMYG = true;
                        try
                        {
                            if (nums.Count == 1)
                            {
                                nums[0].Value = Math.Min(nums[0].Maximum, fDestino.CantidadCentro);
                            }
                            else if (nums.Count >= 3)
                            {
                                nums[0].Value = Math.Min(nums[0].Maximum, fDestino.CantidadIzquierda);
                                nums[1].Value = Math.Min(nums[1].Maximum, fDestino.CantidadCentro);
                                nums[2].Value = Math.Min(nums[2].Maximum, fDestino.CantidadDerecha);
                            }
                        }
                        finally
                        {
                            sincronizandoControlesEstacionesMYG = false;
                        }
                    }
                }

                refrescarTramo(destinoIndice);
            };

            int cantidadTramos = serie.TramosViga.Count;

            for (int tramoIndice = 0; tramoIndice < cantidadTramos; tramoIndice++)
            {
                int indiceLocal = tramoIndice;
                TramoVigaSeriePreview tramo = serie.TramosViga[tramoIndice];
                double longitudM = tramo != null
                    ? Math.Max(0.0, tramo.LengthMm) / 1000.0
                    : 0.0;

                List<FilaConfiguracionEstacionMYG> filasTramo = trabajo
                    .Where(x => x != null && x.TramoIndice == tramoIndice)
                    .OrderBy(x => ObtenerOrdenCapaEstacionVisualMYG(x.CapaEtiqueta))
                    .ThenBy(x => x.CapaEtiqueta)
                    .ToList();

                int altoCard = Math.Max(
                    avanzado ? 410 : 350,
                    126 + filasTramo.Count * 34);

                WinForms.Panel card = new WinForms.Panel
                {
                    Width = 1240,
                    Height = altoCard,
                    Margin = new WinForms.Padding(0, 0, 0, 12),
                    BackColor = Drawing.Color.White,
                    BorderStyle = WinForms.BorderStyle.FixedSingle
                };
                flujo.Controls.Add(card);

                WinForms.Label lblTramo = new WinForms.Label
                {
                    Left = 14,
                    Top = 10,
                    Width = 195,
                    Height = 24,
                    Font = new Drawing.Font(
                        "Segoe UI",
                        10F,
                        Drawing.FontStyle.Bold),
                    Text = "TRAMO T" + (tramoIndice + 1).ToString() +
                           "   |   L = " + longitudM.ToString(
                               "0.00",
                               System.Globalization.CultureInfo.InvariantCulture) +
                           " m"
                };
                card.Controls.Add(lblTramo);

                string marcaTipoTramo = tramo != null &&
                    !string.IsNullOrWhiteSpace(tramo.MarcaTipo)
                        ? tramo.MarcaTipo.Trim()
                        : "--";

                WinForms.Label lblMarcaTipo = new WinForms.Label
                {
                    Left = 215,
                    Top = 10,
                    Width = 270,
                    Height = 24,
                    AutoEllipsis = true,
                    Font = new Drawing.Font(
                        "Segoe UI",
                        9F,
                        Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(55, 82, 110),
                    TextAlign = Drawing.ContentAlignment.MiddleLeft,
                    Text = "MARCA DE TIPO: " + marcaTipoTramo
                };
                card.Controls.Add(lblMarcaTipo);

                WinForms.Label lblContinuidad = new WinForms.Label
                {
                    Left = 500,
                    Top = 11,
                    Width = 710,
                    Height = 22,
                    ForeColor = Drawing.Color.FromArgb(55, 105, 150),
                    TextAlign = Drawing.ContentAlignment.MiddleRight,
                    Text = ConstruirTextoContinuidadTramoVisualMYG(
                        trabajo,
                        tramoIndice,
                        avanzado)
                };
                labelsContinuidad[tramoIndice] = lblContinuidad;
                card.Controls.Add(lblContinuidad);

                int topSeccion = 48;
                int anchoSeccion = avanzado ? 185 : 245;
                int altoSeccion = avanzado ? 245 : 235;
                int separacion = 12;
                int cantidadZonas = avanzado ? 3 : 1;
                string[] nombresZona = avanzado
                    ? new string[] { "IZQUIERDA", "CENTRO", "DERECHA" }
                    : new string[] { "SECCIÓN DEL TRAMO" };

                List<WinForms.Panel> lienzos = new List<WinForms.Panel>();
                lienzosPorTramo[tramoIndice] = lienzos;

                for (int zona = 0; zona < cantidadZonas; zona++)
                {
                    int zonaLocal = avanzado ? zona : 1;
                    int xZona = 14 + zona * (anchoSeccion + separacion);

                    WinForms.Label lblZona = new WinForms.Label
                    {
                        Left = xZona,
                        Top = topSeccion,
                        Width = anchoSeccion,
                        Height = 22,
                        TextAlign = Drawing.ContentAlignment.MiddleCenter,
                        Font = new Drawing.Font(
                            "Segoe UI",
                            8.5F,
                            Drawing.FontStyle.Bold),
                        Text = nombresZona[zona]
                    };
                    card.Controls.Add(lblZona);

                    WinForms.Panel lienzo = new WinForms.Panel
                    {
                        Left = xZona,
                        Top = topSeccion + 23,
                        Width = anchoSeccion,
                        Height = altoSeccion,
                        BackColor = Drawing.Color.White,
                        BorderStyle = WinForms.BorderStyle.FixedSingle
                    };

                    lienzo.Paint += (s, e) =>
                    {
                        WinForms.Panel p = s as WinForms.Panel;
                        if (p == null)
                            return;

                        DibujarSeccionEstacionVisualMYG(
                            e.Graphics,
                            p.ClientRectangle,
                            diseno,
                            filasTramo,
                            zonaLocal,
                            avanzado,
                            clasificacionesTrabajo);
                    };

                    lienzo.Cursor = WinForms.Cursors.Hand;
                    WinForms.ToolTip tooltipBarra = new WinForms.ToolTip();
                    tooltipBarra.SetToolTip(
                        lienzo,
                        "CLIC normal: activar/quitar. Con ES BASTÓN o ES BALANCÍN: clasificar esa posición.");

                    lienzo.MouseClick += (s, e) =>
                    {
                        if (e.Button != WinForms.MouseButtons.Left)
                            return;

                        WinForms.Panel p = s as WinForms.Panel;
                        if (p == null)
                            return;

                        // MODO NORMAL: conserva exactamente el comportamiento
                        // V11.23 de activar/quitar una posición.
                        if (modoSeleccionEspecialMYG == 0)
                        {
                            string grupoCambiado =
                                AlternarBarraSeccionEstacionVisualMYG(
                                    e.Location,
                                    p.ClientRectangle,
                                    diseno,
                                    filasTramo,
                                    zonaLocal,
                                    avanzado);

                            if (string.IsNullOrWhiteSpace(grupoCambiado))
                                return;

                            FilaConfiguracionEstacionMYG filaCambiada =
                                filasTramo.FirstOrDefault(f =>
                                    f != null &&
                                    string.Equals(
                                        f.GrupoId,
                                        grupoCambiado,
                                        StringComparison.Ordinal));

                            if (filaCambiada != null)
                            {
                                string claveCambio =
                                    indiceLocal.ToString() + "|" + grupoCambiado;
                                List<WinForms.NumericUpDown> numsCambio;

                                if (controles.TryGetValue(
                                        claveCambio,
                                        out numsCambio) &&
                                    numsCambio != null)
                                {
                                    sincronizandoControlesEstacionesMYG = true;
                                    try
                                    {
                                        if (!avanzado && numsCambio.Count >= 1)
                                        {
                                            numsCambio[0].Value = Math.Min(
                                                numsCambio[0].Maximum,
                                                filaCambiada.CantidadCentro);
                                        }
                                        else if (avanzado && numsCambio.Count >= 3)
                                        {
                                            int idxNum = Math.Max(
                                                0,
                                                Math.Min(2, zonaLocal));

                                            int q = idxNum == 0
                                                ? filaCambiada.CantidadIzquierda
                                                : (idxNum == 1
                                                    ? filaCambiada.CantidadCentro
                                                    : filaCambiada.CantidadDerecha);

                                            numsCambio[idxNum].Value = Math.Min(
                                                numsCambio[idxNum].Maximum,
                                                q);
                                        }
                                    }
                                    finally
                                    {
                                        sincronizandoControlesEstacionesMYG = false;
                                    }
                                }
                            }

                            refrescarTramo(indiceLocal);
                            return;
                        }

                        // MODO BASTÓN / BALANCÍN:
                        // clasifica la posición exacta sin modificar su presencia.
                        BarraHitEstacionEspecialMYG hit =
                            ObtenerHitBarraSeccionEstacionEspecialMYG(
                                e.Location,
                                p.ClientRectangle,
                                diseno,
                                filasTramo);

                        if (hit == null ||
                            hit.Fila == null ||
                            string.IsNullOrWhiteSpace(hit.GrupoId) ||
                            hit.Indice < 0)
                        {
                            return;
                        }

                        // Por definición de este módulo, bastones y balancines
                        // son acero negativo SUPERIOR.
                        if (!EsCapaSuperiorEspecialMYG(hit.Fila))
                        {
                            lblModoEspecial.Text =
                                "Solo aplica a acero SUPERIOR";
                            return;
                        }

                        List<int> activosZonaEspecial =
                            ObtenerIndicesActivosZonaEstacionVisualMYG(
                                hit.Fila,
                                zonaLocal,
                                avanzado);

                        if (!activosZonaEspecial.Contains(hit.Indice))
                        {
                            lblModoEspecial.Text =
                                "Primero ACTIVE esa barra";
                            return;
                        }

                        ClasificacionEspecialBarraMYG clasificacion =
                            ObtenerOCrearClasificacionEspecialMYG(
                                clasificacionesTrabajo,
                                hit.GrupoId,
                                indiceLocal);

                        if (clasificacion == null)
                            return;

                        List<int> destino =
                            modoSeleccionEspecialMYG == 1
                                ? clasificacion.IndicesBaston
                                : clasificacion.IndicesBalancin;

                        if (destino.Contains(hit.Indice))
                        {
                            destino.Remove(hit.Indice);
                        }
                        else
                        {
                            destino.Add(hit.Indice);

                            // V11.41 - dentro de un mismo tramo/posición la
                            // clasificación es exclusiva: o es BASTÓN o es
                            // BALANCÍN. Esto evita dos recorridos especiales
                            // superpuestos para la misma barra.
                            List<int> otro =
                                modoSeleccionEspecialMYG == 1
                                    ? clasificacion.IndicesBalancin
                                    : clasificacion.IndicesBaston;

                            if (otro != null)
                                otro.Remove(hit.Indice);
                        }

                        destino.Sort();
                        if (clasificacion.IndicesBaston != null)
                            clasificacion.IndicesBaston.Sort();
                        if (clasificacion.IndicesBalancin != null)
                            clasificacion.IndicesBalancin.Sort();
                        LimpiarClasificacionesEspecialesVaciasMYG(
                            clasificacionesTrabajo);

                        lblModoEspecial.Text =
                            modoSeleccionEspecialMYG == 1
                                ? "T" + (indiceLocal + 1).ToString() + ": BASTÓN"
                                : "T" + (indiceLocal + 1).ToString() + ": BALANCÍN";

                        refrescarTodasSeccionesEspeciales();
                    };

                    lienzos.Add(lienzo);
                    card.Controls.Add(lienzo);
                }

                int xTabla = avanzado ? 615 : 305;
                int anchoTabla = 610;

                WinForms.Label hCapa = new WinForms.Label
                {
                    Left = xTabla,
                    Top = topSeccion + 4,
                    Width = 210,
                    Height = 22,
                    Text = "CAPA / GRUPO",
                    Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold)
                };
                card.Controls.Add(hCapa);

                WinForms.Label hMax = new WinForms.Label
                {
                    Left = xTabla + 215,
                    Top = topSeccion + 4,
                    Width = 55,
                    Height = 22,
                    TextAlign = Drawing.ContentAlignment.MiddleCenter,
                    Text = "MÁX.",
                    Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold)
                };
                card.Controls.Add(hMax);

                if (avanzado)
                {
                    string[] heads = { "IZQ.", "CENTRO", "DER." };
                    for (int h = 0; h < 3; h++)
                    {
                        card.Controls.Add(new WinForms.Label
                        {
                            Left = xTabla + 282 + h * 85,
                            Top = topSeccion + 4,
                            Width = 75,
                            Height = 22,
                            TextAlign = Drawing.ContentAlignment.MiddleCenter,
                            Text = heads[h],
                            Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold)
                        });
                    }
                }
                else
                {
                    card.Controls.Add(new WinForms.Label
                    {
                        Left = xTabla + 295,
                        Top = topSeccion + 4,
                        Width = 120,
                        Height = 22,
                        TextAlign = Drawing.ContentAlignment.MiddleCenter,
                        Text = "CANTIDAD TRAMO",
                        Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold)
                    });
                }

                int yFila = topSeccion + 34;
                foreach (FilaConfiguracionEstacionMYG fila in filasTramo)
                {
                    FilaConfiguracionEstacionMYG filaLocal = fila;
                    string clave = tramoIndice.ToString() + "|" + fila.GrupoId;
                    Drawing.Color colorCapa = ObtenerColorCapaEstacionVisualMYG(
                        fila.CapaEtiqueta);

                    WinForms.Panel muestraColor = new WinForms.Panel
                    {
                        Left = xTabla,
                        Top = yFila + 8,
                        Width = 10,
                        Height = 10,
                        BackColor = colorCapa
                    };
                    card.Controls.Add(muestraColor);

                    card.Controls.Add(new WinForms.Label
                    {
                        Left = xTabla + 17,
                        Top = yFila + 3,
                        Width = 190,
                        Height = 24,
                        Text = fila.CapaEtiqueta ?? "Longitudinal"
                    });

                    card.Controls.Add(new WinForms.Label
                    {
                        Left = xTabla + 215,
                        Top = yFila + 3,
                        Width = 55,
                        Height = 24,
                        TextAlign = Drawing.ContentAlignment.MiddleCenter,
                        Text = fila.CantidadMaxima.ToString(),
                        ForeColor = Drawing.Color.DimGray
                    });

                    List<WinForms.NumericUpDown> nums =
                        new List<WinForms.NumericUpDown>();
                    controles[clave] = nums;

                    if (avanzado)
                    {
                        int[] valores =
                        {
                            fila.CantidadIzquierda,
                            fila.CantidadCentro,
                            fila.CantidadDerecha
                        };

                        for (int z = 0; z < 3; z++)
                        {
                            int zLocal = z;
                            WinForms.NumericUpDown num = new WinForms.NumericUpDown
                            {
                                Left = xTabla + 290 + z * 85,
                                Top = yFila,
                                Width = 65,
                                Height = 26,
                                Minimum = 0,
                                Maximum = Math.Max(0, fila.CantidadMaxima),
                                Value = Math.Max(
                                    0,
                                    Math.Min(
                                        Math.Max(0, fila.CantidadMaxima),
                                        valores[z]))
                            };

                            num.ValueChanged += (s, e) =>
                            {
                                if (sincronizandoControlesEstacionesMYG)
                                    return;

                                int q = Convert.ToInt32(num.Value);

                                // El NumericUpDown se conserva como atajo rápido:
                                // al cambiarlo, reconstruye esa zona de forma simétrica.
                                // Si el usuario quiere una combinación arbitraria,
                                // la define directamente haciendo clic en los círculos.
                                AsignarCantidadSimetricaZonaEstacionVisualMYG(
                                    filaLocal,
                                    zLocal,
                                    true,
                                    q);

                                refrescarTramo(indiceLocal);
                            };

                            nums.Add(num);
                            card.Controls.Add(num);
                        }
                    }
                    else
                    {
                        WinForms.NumericUpDown num = new WinForms.NumericUpDown
                        {
                            Left = xTabla + 315,
                            Top = yFila,
                            Width = 80,
                            Height = 26,
                            Minimum = 0,
                            Maximum = Math.Max(0, fila.CantidadMaxima),
                            Value = Math.Max(
                                0,
                                Math.Min(
                                    Math.Max(0, fila.CantidadMaxima),
                                    fila.CantidadCentro))
                        };

                        num.ValueChanged += (s, e) =>
                        {
                            if (sincronizandoControlesEstacionesMYG)
                                return;

                            int q = Convert.ToInt32(num.Value);

                            AsignarCantidadSimetricaZonaEstacionVisualMYG(
                                filaLocal,
                                1,
                                false,
                                q);

                            refrescarTramo(indiceLocal);
                        };

                        nums.Add(num);
                        card.Controls.Add(num);
                    }

                    yFila += 34;
                }

                int yBotones = Math.Min(
                    card.Height - 42,
                    Math.Max(topSeccion + altoSeccion + 35, yFila + 5));

                WinForms.Button btnMaxTramo = new WinForms.Button
                {
                    Text = "MÁXIMO",
                    Left = xTabla,
                    Top = yBotones,
                    Width = 95,
                    Height = 28
                };
                btnMaxTramo.Click += (s, e) =>
                {
                    foreach (FilaConfiguracionEstacionMYG f in trabajo.Where(x =>
                        x != null && x.TramoIndice == indiceLocal))
                    {
                        int q = Math.Max(0, f.CantidadMaxima);
                        List<int> todos = Enumerable.Range(0, q).ToList();

                        f.IndicesActivosIzquierda = new List<int>(todos);
                        f.IndicesActivosCentro = new List<int>(todos);
                        f.IndicesActivosDerecha = new List<int>(todos);
                        f.SeleccionExplicitaIzquierda = true;
                        f.SeleccionExplicitaCentro = true;
                        f.SeleccionExplicitaDerecha = true;
                        f.CantidadIzquierda = q;
                        f.CantidadCentro = q;
                        f.CantidadDerecha = q;

                        string k = indiceLocal.ToString() + "|" + f.GrupoId;
                        List<WinForms.NumericUpDown> ns;
                        if (controles.TryGetValue(k, out ns) && ns != null)
                        {
                            sincronizandoControlesEstacionesMYG = true;
                            try
                            {
                                foreach (WinForms.NumericUpDown n in ns)
                                    n.Value = Math.Min(n.Maximum, q);
                            }
                            finally
                            {
                                sincronizandoControlesEstacionesMYG = false;
                            }
                        }
                    }
                    refrescarTramo(indiceLocal);
                };
                card.Controls.Add(btnMaxTramo);

                WinForms.Button btnAnterior = new WinForms.Button
                {
                    Text = "COPIAR ANTERIOR",
                    Left = xTabla + 102,
                    Top = yBotones,
                    Width = 125,
                    Height = 28,
                    Enabled = tramoIndice > 0
                };
                btnAnterior.Click += (s, e) =>
                {
                    if (indiceLocal > 0)
                        copiarTramo(indiceLocal - 1, indiceLocal);
                };
                card.Controls.Add(btnAnterior);

                WinForms.Button btnSiguiente = new WinForms.Button
                {
                    Text = "COPIAR A SIGUIENTE",
                    Left = xTabla + 234,
                    Top = yBotones,
                    Width = 140,
                    Height = 28,
                    Enabled = tramoIndice < cantidadTramos - 1
                };
                btnSiguiente.Click += (s, e) =>
                {
                    if (indiceLocal < cantidadTramos - 1)
                        copiarTramo(indiceLocal, indiceLocal + 1);
                };
                card.Controls.Add(btnSiguiente);

                if (avanzado)
                {
                    WinForms.Button btnSimetrizar = new WinForms.Button
                    {
                        Text = "IZQ. = DER.",
                        Left = xTabla + 381,
                        Top = yBotones,
                        Width = 110,
                        Height = 28
                    };
                    btnSimetrizar.Click += (s, e) =>
                    {
                        foreach (FilaConfiguracionEstacionMYG f in trabajo.Where(x =>
                            x != null && x.TramoIndice == indiceLocal))
                        {
                            NormalizarSeleccionFilaEstacionVisualMYG(f);

                            f.IndicesActivosDerecha =
                                new List<int>(f.IndicesActivosIzquierda);
                            f.SeleccionExplicitaDerecha = true;
                            f.CantidadDerecha =
                                f.IndicesActivosDerecha.Count;

                            string k = indiceLocal.ToString() + "|" + f.GrupoId;
                            List<WinForms.NumericUpDown> ns;
                            if (controles.TryGetValue(k, out ns) &&
                                ns != null &&
                                ns.Count >= 3)
                            {
                                sincronizandoControlesEstacionesMYG = true;
                                try
                                {
                                    ns[2].Value = Math.Min(
                                        ns[2].Maximum,
                                        f.CantidadDerecha);
                                }
                                finally
                                {
                                    sincronizandoControlesEstacionesMYG = false;
                                }
                            }
                        }
                        refrescarTramo(indiceLocal);
                    };
                    card.Controls.Add(btnSimetrizar);
                }
            }

            WinForms.Button btnMaxTodo = new WinForms.Button
            {
                Text = "MÁXIMO EN TODO",
                Left = 14,
                Top = 13,
                Width = 145,
                Height = 32
            };
            btnMaxTodo.Click += (s, e) =>
            {
                foreach (FilaConfiguracionEstacionMYG f in trabajo)
                {
                    if (f == null) continue;
                    int q = Math.Max(0, f.CantidadMaxima);
                    List<int> todos = Enumerable.Range(0, q).ToList();

                    f.IndicesActivosIzquierda = new List<int>(todos);
                    f.IndicesActivosCentro = new List<int>(todos);
                    f.IndicesActivosDerecha = new List<int>(todos);
                    f.SeleccionExplicitaIzquierda = true;
                    f.SeleccionExplicitaCentro = true;
                    f.SeleccionExplicitaDerecha = true;
                    f.CantidadIzquierda = q;
                    f.CantidadCentro = q;
                    f.CantidadDerecha = q;

                    string k = f.TramoIndice.ToString() + "|" + f.GrupoId;
                    List<WinForms.NumericUpDown> ns;
                    if (controles.TryGetValue(k, out ns) && ns != null)
                    {
                        sincronizandoControlesEstacionesMYG = true;
                        try
                        {
                            foreach (WinForms.NumericUpDown n in ns)
                                n.Value = Math.Min(n.Maximum, q);
                        }
                        finally
                        {
                            sincronizandoControlesEstacionesMYG = false;
                        }
                    }
                }

                for (int i = 0; i < cantidadTramos; i++)
                    refrescarTramo(i);
            };
            pie.Controls.Add(btnMaxTodo);

            WinForms.Button btnCopiarT1Todo = new WinForms.Button
            {
                Text = "COPIAR T1 A TODOS",
                Left = 166,
                Top = 13,
                Width = 155,
                Height = 32
            };
            btnCopiarT1Todo.Click += (s, e) =>
            {
                for (int i = 1; i < cantidadTramos; i++)
                    copiarTramo(0, i);
            };
            pie.Controls.Add(btnCopiarT1Todo);

            WinForms.Button btnAceptar = new WinForms.Button
            {
                Text = "ACEPTAR",
                Width = 155,
                Height = 32,
                Left = 1135,
                Top = 13,
                Anchor = WinForms.AnchorStyles.Top | WinForms.AnchorStyles.Right
            };
            pie.Controls.Add(btnAceptar);

            WinForms.Button btnCancelar = new WinForms.Button
            {
                Text = "CANCELAR",
                Width = 155,
                Height = 32,
                Left = 970,
                Top = 13,
                Anchor = WinForms.AnchorStyles.Top | WinForms.AnchorStyles.Right
            };
            pie.Controls.Add(btnCancelar);

            dlg.AcceptButton = btnAceptar;
            dlg.CancelButton = btnCancelar;

            bool topMostAnteriorEstacionesMYG = this.TopMost;

            // ACEPTAR: aplica la copia de trabajo y cierra.
            btnAceptar.Click += (s, e) =>
            {
                double extensionNueva;
                if (!double.TryParse(
                        (txtExt.Text ?? string.Empty).Replace(',', '.'),
                        System.Globalization.NumberStyles.Float,
                        System.Globalization.CultureInfo.InvariantCulture,
                        out extensionNueva) ||
                    extensionNueva < 0.0)
                {
                    extensionNueva = extensionCambiosEstacionesCmMYG;
                }

                extensionCambiosEstacionesCmMYG = extensionNueva;

                desarrollosCortePorDiametroCmMYG.Clear();
                foreach (KeyValuePair<int, double> par in desarrollosTrabajo)
                {
                    if (par.Key > 0)
                        desarrollosCortePorDiametroCmMYG[par.Key] = Math.Max(0.0, par.Value);
                }

                configuracionEstacionesLongitudinalMYG.Clear();
                configuracionEstacionesLongitudinalMYG.AddRange(
                    trabajo.Where(x => x != null).Select(x => x.Copiar()));

                clasificacionesEspecialesLongitudinalMYG.Clear();
                clasificacionesEspecialesLongitudinalMYG.AddRange(
                    clasificacionesTrabajo
                        .Where(c =>
                            c != null &&
                            !string.IsNullOrWhiteSpace(c.GrupoId))
                        .Select(c => c.Copiar()));

                RefrescarPreviewLongitudinalEnTiempoReal();
                dlg.Close();
            };

            // CANCELAR o X: descarta la copia de trabajo.
            btnCancelar.Click += (s, e) =>
            {
                dlg.Close();
            };

            dlg.FormClosed += (s, e) =>
            {
                if (ReferenceEquals(ventanaConfiguracionEstacionesMYG, dlg))
                    ventanaConfiguracionEstacionesMYG = null;

                try
                {
                    this.TopMost = topMostAnteriorEstacionesMYG;
                }
                catch
                {
                }

                // Si se cerró con la X, la copia de trabajo se descarta y
                // la configuración real no se toca.
            };

            dlg.StartPosition = WinForms.FormStartPosition.CenterParent;
            dlg.ShowInTaskbar = false;
            dlg.TopMost = true;

            dlg.Shown += (s, e) =>
            {
                try
                {
                    dlg.WindowState = WinForms.FormWindowState.Normal;
                    dlg.BringToFront();
                    dlg.Activate();
                    dlg.Focus();
                }
                catch
                {
                }
            };

            // Mientras la configuración está abierta, la ventana principal deja
            // de ser TopMost para que no tape al configurador. Revit NO se deshabilita.
            this.TopMost = false;

            // CLAVE V11.29: Show() en lugar de ShowDialog().
            // La ventana es modeless y permite seguir interactuando con Revit.
            dlg.Show(this);
        }
    }


    public void CargarTiposArmadura(List<RebarBarType> tipos)
    {
        cmbTipoSuperior.Items.Clear();
        cmbTipoInferior.Items.Clear();
        cmbTipoCentral.Items.Clear();

        if (cmbTipoSuperiorCapa2 != null) cmbTipoSuperiorCapa2.Items.Clear();
        if (cmbTipoSuperiorCapa3 != null) cmbTipoSuperiorCapa3.Items.Clear();
        if (cmbTipoSuperiorCapa4 != null) cmbTipoSuperiorCapa4.Items.Clear();
        if (cmbTipoInferiorCapa2 != null) cmbTipoInferiorCapa2.Items.Clear();
        if (cmbTipoInferiorCapa3 != null) cmbTipoInferiorCapa3.Items.Clear();
        if (cmbTipoInferiorCapa4 != null) cmbTipoInferiorCapa4.Items.Clear();

        foreach (RebarBarType tipo in tipos)
        {
            cmbTipoSuperior.Items.Add(tipo);
            cmbTipoInferior.Items.Add(tipo);
            cmbTipoCentral.Items.Add(tipo);

            if (cmbTipoSuperiorCapa2 != null) cmbTipoSuperiorCapa2.Items.Add(tipo);
            if (cmbTipoSuperiorCapa3 != null) cmbTipoSuperiorCapa3.Items.Add(tipo);
            if (cmbTipoSuperiorCapa4 != null) cmbTipoSuperiorCapa4.Items.Add(tipo);
            if (cmbTipoInferiorCapa2 != null) cmbTipoInferiorCapa2.Items.Add(tipo);
            if (cmbTipoInferiorCapa3 != null) cmbTipoInferiorCapa3.Items.Add(tipo);
            if (cmbTipoInferiorCapa4 != null) cmbTipoInferiorCapa4.Items.Add(tipo);
        }

        cmbTipoSuperior.DisplayMember = "Name";
        cmbTipoInferior.DisplayMember = "Name";
        cmbTipoCentral.DisplayMember = "Name";

        ConfigurarFormatoNombreTipo(cmbTipoSuperior);
        ConfigurarFormatoNombreTipo(cmbTipoInferior);
        ConfigurarFormatoNombreTipo(cmbTipoCentral);

        if (cmbTipoSuperiorCapa2 != null) cmbTipoSuperiorCapa2.DisplayMember = "Name";
        if (cmbTipoSuperiorCapa3 != null) cmbTipoSuperiorCapa3.DisplayMember = "Name";
        if (cmbTipoSuperiorCapa4 != null) cmbTipoSuperiorCapa4.DisplayMember = "Name";
        if (cmbTipoInferiorCapa2 != null) cmbTipoInferiorCapa2.DisplayMember = "Name";
        if (cmbTipoInferiorCapa3 != null) cmbTipoInferiorCapa3.DisplayMember = "Name";
        if (cmbTipoInferiorCapa4 != null) cmbTipoInferiorCapa4.DisplayMember = "Name";

        ConfigurarFormatoNombreTipo(cmbTipoSuperiorCapa2);
        ConfigurarFormatoNombreTipo(cmbTipoSuperiorCapa3);
        ConfigurarFormatoNombreTipo(cmbTipoSuperiorCapa4);
        ConfigurarFormatoNombreTipo(cmbTipoInferiorCapa2);
        ConfigurarFormatoNombreTipo(cmbTipoInferiorCapa3);
        ConfigurarFormatoNombreTipo(cmbTipoInferiorCapa4);

        if (cmbTipoSuperior.Items.Count > 0)
            cmbTipoSuperior.SelectedIndex = 0;

        if (cmbTipoInferior.Items.Count > 0)
            cmbTipoInferior.SelectedIndex = 0;

        if (cmbTipoCentral.Items.Count > 0)
            cmbTipoCentral.SelectedIndex = 0;

        if (cmbTipoSuperiorCapa2 != null && cmbTipoSuperiorCapa2.Items.Count > 0) cmbTipoSuperiorCapa2.SelectedIndex = 0;
        if (cmbTipoSuperiorCapa3 != null && cmbTipoSuperiorCapa3.Items.Count > 0) cmbTipoSuperiorCapa3.SelectedIndex = 0;
        if (cmbTipoSuperiorCapa4 != null && cmbTipoSuperiorCapa4.Items.Count > 0) cmbTipoSuperiorCapa4.SelectedIndex = 0;
        if (cmbTipoInferiorCapa2 != null && cmbTipoInferiorCapa2.Items.Count > 0) cmbTipoInferiorCapa2.SelectedIndex = 0;
        if (cmbTipoInferiorCapa3 != null && cmbTipoInferiorCapa3.Items.Count > 0) cmbTipoInferiorCapa3.SelectedIndex = 0;
        if (cmbTipoInferiorCapa4 != null && cmbTipoInferiorCapa4.Items.Count > 0) cmbTipoInferiorCapa4.SelectedIndex = 0;

        ActualizarEstadoAceroCentral();
        ActualizarVisibilidadCapasLongitudinales();

        if (UsarRNE)
            CalcularYAplicarEmpalmeRNE();

        RefrescarEditorSeccionIntegrado();
    }

    public void ActualizarCantidad(int cantidad)
    {
        lblCantidad.Text = $"Vigas seleccionadas: {cantidad}";
    }

    public void ActualizarVistaPrevia(
        double longitudTotalMm,
        List<ColumnaPreview> columnas,
        string nombreViga)
    {
        List<VigaLongitudinalPreview> lista =
            new List<VigaLongitudinalPreview>();

        lista.Add(new VigaLongitudinalPreview(
            longitudTotalMm,
            columnas,
            nombreViga));

        ActualizarVistaPreviaMultiple(lista);
    }

    public void ActualizarVistaPreviaMultiple(
        List<VigaLongitudinalPreview> vigas)
    {
        previewVigas = vigas ?? new List<VigaLongitudinalPreview>();

        if (previewVigas.Count == 0)
        {
            lblVistaInfo.Text = "No hay vigas seleccionadas.";

            if (panelPreview != null)
                panelPreview.Invalidate();

            NotificarPreviewVigasActualizadas();
            return;
        }

        SerieContinuaPreview serie = ConstruirSerieContinua(previewVigas);

        // Mantiene la tabla por estaciones sincronizada con la cantidad real de
        // tramos seleccionados, sin alterar los valores ya editados.
        SincronizarConfiguracionEstacionesConModeloMYG();

        double totalLibre = 0.0;
        int cantidadTramosReales = 0;

        if (serie != null && serie.TramosViga != null)
        {
            totalLibre = serie.TramosViga.Sum(x => x.LengthMm);
            cantidadTramosReales = serie.TramosViga.Count;
        }

        lblVistaInfo.Text =
            $"Serie continua: {cantidadTramosReales} tramo(s)  |  Longitud libre vigas: {FormatearMetros(totalLibre)}";

        ActualizarEstadoDesarrolloPorVoladizo();

        panelPreview.Invalidate();

        NotificarPreviewVigasActualizadas();
    }

    private void NotificarPreviewVigasActualizadas()
    {
        try
        {
            List<VigaLongitudinalPreview> copia = previewVigas != null
                ? new List<VigaLongitudinalPreview>(previewVigas)
                : new List<VigaLongitudinalPreview>();

            PreviewVigasActualizadas?.Invoke(copia);
        }
        catch
        {
            // No se interrumpe la selección si el MAIN aún no está listo.
        }
    }


    private void RefrescarPreviewLongitudinalEnTiempoReal()
    {
        try
        {
            if (panelPreview != null)
            {
                panelPreview.Invalidate();
                panelPreview.Update();
            }
        }
        catch
        {
            // No interrumpir por refresco visual.
        }

        try
        {
            Action handler = PreviewLongitudinalParametrosActualizados;
            if (handler != null)
                handler();
        }
        catch
        {
            // No interrumpir si el MAIN todavía no está listo.
        }
    }

    public List<VigaLongitudinalPreview> ObtenerVigasPreviewActuales()
    {
        return previewVigas ?? new List<VigaLongitudinalPreview>();
    }

    public void EstablecerEstribosCreadosPreview(
        Dictionary<int, List<Tuple<double, int>>> estribosPorTramo)
    {
        previewEstribosCreados = ClonarEstribosPreview(estribosPorTramo);

        bool hayEstribos =
            previewEstribosCreados != null &&
            previewEstribosCreados.Count > 0;

        if (chkGraficarEstribosCreados != null)
        {
            // El check debe poder activarse manualmente aunque aún no existan
            // estribos cargados desde la pestaña Estribos.
            chkGraficarEstribosCreados.Enabled = true;
            chkGraficarEstribosCreados.Checked = hayEstribos;
        }

        if (panelPreview != null)
            panelPreview.Invalidate();
    }

    public void LimpiarEstribosCreadosPreview()
    {
        previewEstribosCreados = null;

        if (chkGraficarEstribosCreados != null)
        {
            chkGraficarEstribosCreados.Checked = false;
            chkGraficarEstribosCreados.Enabled = true;
        }

        if (panelPreview != null)
            panelPreview.Invalidate();
    }

    private Dictionary<int, List<Tuple<double, int>>> ClonarEstribosPreview(
        Dictionary<int, List<Tuple<double, int>>> origen)
    {
        Dictionary<int, List<Tuple<double, int>>> copia =
            new Dictionary<int, List<Tuple<double, int>>>();

        if (origen == null)
            return copia;

        foreach (KeyValuePair<int, List<Tuple<double, int>>> kv in origen)
        {
            List<Tuple<double, int>> lista = new List<Tuple<double, int>>();

            if (kv.Value != null)
            {
                foreach (Tuple<double, int> item in kv.Value)
                {
                    if (item == null)
                        continue;

                    lista.Add(Tuple.Create(item.Item1, item.Item2));
                }
            }

            copia[kv.Key] = lista;
        }

        return copia;
    }

    public List<double> ObtenerLongitudesTramosSerieVistaPreviaMm()
    {
        List<double> resultado = new List<double>();

        SerieContinuaPreview serie = ConstruirSerieContinua(previewVigas);

        if (serie == null || serie.TramosViga == null)
            return resultado;

        foreach (TramoVigaSeriePreview tramo in serie.TramosViga)
        {
            if (tramo == null)
                continue;

            if (tramo.LengthMm > 0.0)
                resultado.Add(tramo.LengthMm);
        }

        return resultado;
    }

    public void EstablecerVistaSoloGeometria(bool soloGeometria)
    {
        MostrarAcerosEnVistaPreliminar = !soloGeometria;

        if (panelPreview != null)
            panelPreview.Invalidate();
    }

    public List<Drawing.RectangleF> ObtenerHitBoxesTramosVistaPreviaComun(
        Drawing.Rectangle area)
    {
        List<Drawing.RectangleF> rects = new List<Drawing.RectangleF>();

        SerieContinuaPreview serie = ConstruirSerieContinua(previewVigas);

        if (serie == null || serie.TramosViga == null || serie.TramosViga.Count == 0)
            return rects;

        int margenIzq = 40;
        int margenDer = 28;

        int yBeam = 50;
        int hBeam = 30;

        double startGlobal = serie.TramosViga.Min(x => x.StartMm);
        double endGlobal = serie.TramosViga.Max(x => x.EndMm);

        double desarrolloInicioMm = ObtenerLongitudDesarrolloInicioMm();
        double desarrolloFinMm = ObtenerLongitudDesarrolloFinMm();
        double recubrimientoMm = ObtenerRecubrimientoMm();

        double xBarraInicioMm;
        double xBarraFinMm;

        if (serie.TieneColumnaInicioSerie && LongitudDesarrolloInicioHabilitada)
            xBarraInicioMm = startGlobal - desarrolloInicioMm;
        else
            xBarraInicioMm = startGlobal + recubrimientoMm;

        if (serie.TieneColumnaFinSerie && LongitudDesarrolloFinHabilitada)
            xBarraFinMm = endGlobal + desarrolloFinMm;
        else
            xBarraFinMm = endGlobal - recubrimientoMm;

        double displayMinMm = Math.Min(serie.MinMm, xBarraInicioMm);
        double displayMaxMm = Math.Max(serie.MaxMm, xBarraFinMm);

        // V11.41 - el encuadre/hit-test usa el mismo desarrollo GENERAL que
        // la geometría de los bastones de esquina (Desarrollo + AUTO).
        if (ModoDistribucionLongitudinalActualMYG !=
                ModoDistribucionLongitudinalMYG.Continuo &&
            clasificacionesEspecialesLongitudinalMYG != null &&
            clasificacionesEspecialesLongitudinalMYG.Any(c =>
                c != null && c.IndicesBaston != null && c.IndicesBaston.Count > 0))
        {
            int ultimoTramoPreview = Math.Max(0, serie.TramosViga.Count - 1);

            bool hayBastonInicio = clasificacionesEspecialesLongitudinalMYG.Any(c =>
                c != null && c.TramoIndice == 0 &&
                c.IndicesBaston != null && c.IndicesBaston.Count > 0);

            bool hayBastonFin = clasificacionesEspecialesLongitudinalMYG.Any(c =>
                c != null && c.TramoIndice == ultimoTramoPreview &&
                c.IndicesBaston != null && c.IndicesBaston.Count > 0);

            if (hayBastonInicio && LongitudDesarrolloInicioHabilitada)
                displayMinMm = Math.Min(displayMinMm, startGlobal - desarrolloInicioMm);

            if (hayBastonFin && LongitudDesarrolloFinHabilitada)
                displayMaxMm = Math.Max(displayMaxMm, endGlobal + desarrolloFinMm);
        }

        if (Math.Abs(displayMaxMm - displayMinMm) < 1.0)
            displayMaxMm = displayMinMm + 1.0;

        int x0 = margenIzq;
        int x1 = area.Width - margenDer;

        if (x1 <= x0)
            return rects;

        int anchoDibujo = x1 - x0;
        double rangoMm = displayMaxMm - displayMinMm;

        if (rangoMm <= 0.0)
            return rects;

        Func<double, float> mapX = mm =>
        {
            double t = AjustarParametroHorizontalPreviewMYG(
                (mm - displayMinMm) / rangoMm);

            return x0 + (float)(t * anchoDibujo);
        };

        // Hitbox amplio verticalmente para mantener la selección por tramo
        // usando exactamente la misma escala X de DibujarVistaPreviaComun.
        float y = Math.Max(0, yBeam - 35);
        float h = Math.Max(80, area.Height - y - 20);

        foreach (TramoVigaSeriePreview t in serie.TramosViga)
        {
            if (t == null)
                continue;

            float xA = mapX(t.StartMm);
            float xB = mapX(t.EndMm);
            float xa = Math.Min(xA, xB);
            float xb = Math.Max(xA, xB);

            if (xb <= xa + 1.0f)
                xb = xa + 5.0f;

            rects.Add(new Drawing.RectangleF(xa, y, xb - xa, h));
        }

        return rects;
    }

    // =========================================================
    // AGREGAR DENTRO DE LA CLASE AceroLongitudinalVigasForm
    // Ubicación recomendada: debajo de ObtenerHitBoxesTramosVistaPreviaComun(...)
    // Este método devuelve los polígonos EXACTOS de cada tramo usando la misma lógica
    // de DibujarVistaPreviaComun: misma escala X, mismo eje inclinado y mismo perfil variable.
    // =========================================================
    public List<Drawing.PointF[]> ObtenerPoligonosTramosVistaPreviaComun(
        Drawing.Rectangle area)
    {
        List<Drawing.PointF[]> resultado = new List<Drawing.PointF[]>();

        SerieContinuaPreview serie = ConstruirSerieContinua(previewVigas);

        if (serie == null || serie.TramosViga == null || serie.TramosViga.Count == 0)
            return resultado;

        int margenIzq = 40;
        int margenDer = 28;

        int yBeam = 50;
        int hBeam = 30;
        float yCentroBase = yBeam + hBeam / 2.0f;

        double startGlobal = serie.TramosViga.Min(x => x.StartMm);
        double endGlobal = serie.TramosViga.Max(x => x.EndMm);

        double desarrolloInicioMm = ObtenerLongitudDesarrolloInicioMm();
        double desarrolloFinMm = ObtenerLongitudDesarrolloFinMm();
        double recubrimientoMm = ObtenerRecubrimientoMm();

        double xBarraInicioMm;
        double xBarraFinMm;

        if (serie.TieneColumnaInicioSerie && LongitudDesarrolloInicioHabilitada)
            xBarraInicioMm = startGlobal - desarrolloInicioMm;
        else
            xBarraInicioMm = startGlobal + recubrimientoMm;

        if (serie.TieneColumnaFinSerie && LongitudDesarrolloFinHabilitada)
            xBarraFinMm = endGlobal + desarrolloFinMm;
        else
            xBarraFinMm = endGlobal - recubrimientoMm;

        double displayMinMm = Math.Min(serie.MinMm, xBarraInicioMm);
        double displayMaxMm = Math.Max(serie.MaxMm, xBarraFinMm);

        if (Math.Abs(displayMaxMm - displayMinMm) < 1.0)
            displayMaxMm = displayMinMm + 1.0;

        int x0 = margenIzq;
        int x1 = area.Width - margenDer;

        if (x1 <= x0)
            return resultado;

        int anchoDibujo = x1 - x0;
        double rangoMm = displayMaxMm - displayMinMm;

        if (rangoMm <= 0.0)
            return resultado;

        Func<double, int> mapX = mm =>
        {
            double t = AjustarParametroHorizontalPreviewMYG(
                (mm - displayMinMm) / rangoMm);

            return x0 + (int)(t * anchoDibujo);
        };

        List<EjeDibujoPreview> ejeBase = ConstruirEjeDibujoPreview(
            serie,
            mapX,
            yCentroBase);

        if (ejeBase == null || ejeBase.Count == 0)
            return resultado;

        double minZ;
        double maxZ;
        bool tienePerfilVariable = ObtenerRangoPerfilVariablePreview(
            serie,
            out minZ,
            out maxZ);

        double centroZMm = 0.0;
        float escalaZPxPorMm = 0.0f;

        if (tienePerfilVariable && maxZ > minZ + 1.0)
        {
            centroZMm = (minZ + maxZ) / 2.0;
            escalaZPxPorMm = (float)(hBeam / Math.Max(1.0, maxZ - minZ));
        }

        foreach (TramoVigaSeriePreview tramo in serie.TramosViga.OrderBy(t => t.StartMm))
        {
            if (tramo == null)
                continue;

            Drawing.PointF pSupIni;
            Drawing.PointF pSupFin;
            Drawing.PointF pInfIni;
            Drawing.PointF pInfFin;

            if (tienePerfilVariable && tramo.TienePerfilSeccionVariable)
            {
                double zSupIni = ObtenerZTramoVariable(tramo, tramo.StartMm, 1);
                double zSupFin = ObtenerZTramoVariable(tramo, tramo.EndMm, 1);
                double zInfIni = ObtenerZTramoVariable(tramo, tramo.StartMm, -1);
                double zInfFin = ObtenerZTramoVariable(tramo, tramo.EndMm, -1);

                pSupIni = PuntoPerfilVariablePreview(
                    ejeBase,
                    tramo.StartMm,
                    zSupIni,
                    centroZMm,
                    escalaZPxPorMm);

                pSupFin = PuntoPerfilVariablePreview(
                    ejeBase,
                    tramo.EndMm,
                    zSupFin,
                    centroZMm,
                    escalaZPxPorMm);

                pInfIni = PuntoPerfilVariablePreview(
                    ejeBase,
                    tramo.StartMm,
                    zInfIni,
                    centroZMm,
                    escalaZPxPorMm);

                pInfFin = PuntoPerfilVariablePreview(
                    ejeBase,
                    tramo.EndMm,
                    zInfFin,
                    centroZMm,
                    escalaZPxPorMm);
            }
            else
            {
                pSupIni = PuntoEnEjePreview(ejeBase, tramo.StartMm, -hBeam / 2.0f);
                pSupFin = PuntoEnEjePreview(ejeBase, tramo.EndMm, -hBeam / 2.0f);
                pInfFin = PuntoEnEjePreview(ejeBase, tramo.EndMm, hBeam / 2.0f);
                pInfIni = PuntoEnEjePreview(ejeBase, tramo.StartMm, hBeam / 2.0f);
            }

            resultado.Add(
                new Drawing.PointF[]
                {
                        pSupIni,
                        pSupFin,
                        pInfFin,
                        pInfIni
                });
        }

        return resultado;
    }

    public List<Tuple<double, double, double>> ObtenerRangosTramosSerieVistaPreviaMm()
    {
        List<Tuple<double, double, double>> resultado =
            new List<Tuple<double, double, double>>();

        SerieContinuaPreview serie = ConstruirSerieContinua(previewVigas);

        if (serie == null || serie.TramosViga == null || serie.TramosViga.Count == 0)
            return resultado;

        double totalSerieMm = Math.Max(serie.MaxMm - serie.MinMm, 1.0);

        foreach (TramoVigaSeriePreview tramo in serie.TramosViga.OrderBy(t => t.StartMm))
        {
            if (tramo == null)
                continue;

            if (tramo.LengthMm <= 1.0)
                continue;

            // Item1 = inicio del tramo dentro de la serie completa.
            // Item2 = fin del tramo dentro de la serie completa.
            // Item3 = longitud total de la serie, incluyendo columnas/apoyos/gaps visibles.
            double inicioVistaMm = tramo.StartMm - serie.MinMm;
            double finVistaMm = tramo.EndMm - serie.MinMm;

            if (previewInvertirHorizontalMYG)
            {
                double inicioInvertidoMm = totalSerieMm - finVistaMm;
                double finInvertidoMm = totalSerieMm - inicioVistaMm;
                inicioVistaMm = inicioInvertidoMm;
                finVistaMm = finInvertidoMm;
            }

            resultado.Add(
                Tuple.Create(
                    inicioVistaMm,
                    finVistaMm,
                    totalSerieMm));
        }

        return resultado;
    }

    public void DibujarVistaPreviaComun(
        Drawing.Graphics g,
        Drawing.Rectangle area,
        bool mostrarLongitudinal,
        bool longitudinalEnGris,
        Dictionary<int, List<Tuple<double, int>>> estribosPorTramo,
        int tramoEstribosResaltado = -1)
    {
        if (g == null)
            return;

        bool oldMostrarAceros = MostrarAcerosEnVistaPreliminar;
        bool oldGris = previewForzarLongitudinalesGris;
        bool oldUsarArea = previewUsarAreaExterna;
        Drawing.Rectangle oldArea = previewAreaExterna;
        Dictionary<int, List<Tuple<double, int>>> oldEstribos = previewEstribosExterno;
        int oldTramoEstribosResaltado = previewTramoEstribosResaltado;

        try
        {
            MostrarAcerosEnVistaPreliminar = mostrarLongitudinal;
            previewForzarLongitudinalesGris = longitudinalEnGris;
            previewEstribosExterno = estribosPorTramo;
            previewTramoEstribosResaltado = tramoEstribosResaltado;
            previewUsarAreaExterna = true;
            previewAreaExterna = area;

            DibujarVistaPrevia(
                panelPreview,
                new WinForms.PaintEventArgs(g, area));
        }
        finally
        {
            MostrarAcerosEnVistaPreliminar = oldMostrarAceros;
            previewForzarLongitudinalesGris = oldGris;
            previewEstribosExterno = oldEstribos;
            previewTramoEstribosResaltado = oldTramoEstribosResaltado;
            previewUsarAreaExterna = oldUsarArea;
            previewAreaExterna = oldArea;
        }
    }

    // =========================================================
    // SEPARACIÓN FÍSICA ENTRE ELEMENTOS DISTINTOS EN EL PREVIEW 2D
    // =========================================================
    // Solidos3D conserva coordenadas globales del modelo en milímetros.
    // Para dos elementos consecutivos:
    // 1. Se obtiene el centro de la caja global de cada sólido.
    // 2. Se define la dirección anterior -> actual.
    // 3. Se proyectan todos los vértices sobre esa dirección.
    // 4. La diferencia positiva entre ambas envolventes es el vacío real.
    //
    // Ese vacío aumenta el eje de la serie, pero no agrega TramoVigaSeriePreview;
    // por tanto, visualmente queda un espacio blanco y no un sólido ficticio.
    private double CalcularSeparacionFisicaEntreElementosPreviewMYG(
        VigaLongitudinalPreview anterior,
        VigaLongitudinalPreview actual)
    {
        List<VigaLongitudinalPreview.Punto3DPreview> puntosAnterior =
            ObtenerPuntosGlobalesSolidosPreviewMYG(anterior);

        List<VigaLongitudinalPreview.Punto3DPreview> puntosActual =
            ObtenerPuntosGlobalesSolidosPreviewMYG(actual);

        if (puntosAnterior.Count == 0 || puntosActual.Count == 0)
            return 0.0;

        VigaLongitudinalPreview.Punto3DPreview centroAnterior =
            ObtenerCentroCajaPuntosPreviewMYG(puntosAnterior);

        VigaLongitudinalPreview.Punto3DPreview centroActual =
            ObtenerCentroCajaPuntosPreviewMYG(puntosActual);

        if (centroAnterior == null || centroActual == null)
            return 0.0;

        double dx = centroActual.XMm - centroAnterior.XMm;
        double dy = centroActual.YMm - centroAnterior.YMm;
        double dz = centroActual.ZMm - centroAnterior.ZMm;

        double modulo = Math.Sqrt(
            dx * dx +
            dy * dy +
            dz * dz);

        if (modulo <= 1e-6)
            return 0.0;

        dx /= modulo;
        dy /= modulo;
        dz /= modulo;

        double maxAnterior = double.MinValue;
        double minActual = double.MaxValue;

        foreach (VigaLongitudinalPreview.Punto3DPreview punto
            in puntosAnterior)
        {
            if (punto == null)
                continue;

            double proyeccion =
                punto.XMm * dx +
                punto.YMm * dy +
                punto.ZMm * dz;

            if (proyeccion > maxAnterior)
                maxAnterior = proyeccion;
        }

        foreach (VigaLongitudinalPreview.Punto3DPreview punto
            in puntosActual)
        {
            if (punto == null)
                continue;

            double proyeccion =
                punto.XMm * dx +
                punto.YMm * dy +
                punto.ZMm * dz;

            if (proyeccion < minActual)
                minActual = proyeccion;
        }

        if (maxAnterior == double.MinValue ||
            minActual == double.MaxValue)
        {
            return 0.0;
        }

        double separacion = minActual - maxAnterior;

        // Tolerancia para evitar microvacíos producidos por uniones,
        // redondeos de malla o pequeñas diferencias geométricas.
        const double toleranciaMm = 2.0;

        if (separacion <= toleranciaMm)
            return 0.0;

        return separacion;
    }

    private List<VigaLongitudinalPreview.Punto3DPreview>
        ObtenerPuntosGlobalesSolidosPreviewMYG(
            VigaLongitudinalPreview viga)
    {
        List<VigaLongitudinalPreview.Punto3DPreview> resultado =
            new List<VigaLongitudinalPreview.Punto3DPreview>();

        if (viga == null ||
            viga.Solidos3D == null ||
            viga.Solidos3D.Count == 0)
        {
            return resultado;
        }

        foreach (VigaLongitudinalPreview.Solido3DPreview solido
            in viga.Solidos3D)
        {
            if (solido == null || solido.Puntos == null)
                continue;

            foreach (VigaLongitudinalPreview.Punto3DPreview punto
                in solido.Puntos)
            {
                if (punto == null)
                    continue;

                if (double.IsNaN(punto.XMm) ||
                    double.IsInfinity(punto.XMm) ||
                    double.IsNaN(punto.YMm) ||
                    double.IsInfinity(punto.YMm) ||
                    double.IsNaN(punto.ZMm) ||
                    double.IsInfinity(punto.ZMm))
                {
                    continue;
                }

                resultado.Add(punto);
            }
        }

        return resultado;
    }

    private VigaLongitudinalPreview.Punto3DPreview
        ObtenerCentroCajaPuntosPreviewMYG(
            List<VigaLongitudinalPreview.Punto3DPreview> puntos)
    {
        if (puntos == null || puntos.Count == 0)
            return null;

        double minX = double.MaxValue;
        double minY = double.MaxValue;
        double minZ = double.MaxValue;

        double maxX = double.MinValue;
        double maxY = double.MinValue;
        double maxZ = double.MinValue;

        foreach (VigaLongitudinalPreview.Punto3DPreview punto
            in puntos)
        {
            if (punto == null)
                continue;

            minX = Math.Min(minX, punto.XMm);
            minY = Math.Min(minY, punto.YMm);
            minZ = Math.Min(minZ, punto.ZMm);

            maxX = Math.Max(maxX, punto.XMm);
            maxY = Math.Max(maxY, punto.YMm);
            maxZ = Math.Max(maxZ, punto.ZMm);
        }

        if (minX == double.MaxValue ||
            maxX == double.MinValue)
        {
            return null;
        }

        return new VigaLongitudinalPreview.Punto3DPreview(
            (minX + maxX) / 2.0,
            (minY + maxY) / 2.0,
            (minZ + maxZ) / 2.0);
    }

    private SerieContinuaPreview ConstruirSerieContinua(
        List<VigaLongitudinalPreview> vigas)
    {
        SerieContinuaPreview serie = new SerieContinuaPreview();

        if (vigas == null || vigas.Count == 0)
            return serie;

        double cursor = 0.0;
        bool ultimoTerminoConColumna = false;

        // Se conserva el último elemento procesado para respetar en la vista 2D
        // la separación física real existente entre dos ElementId diferentes.
        VigaLongitudinalPreview vigaAnteriorPreviewMYG = null;

        for (int i = 0; i < vigas.Count; i++)
        {
            VigaLongitudinalPreview v = vigas[i];

            if (v == null)
                continue;

            double longitudReferenciaMm = v.LongitudMm;

            if (longitudReferenciaMm <= 0.0)
                longitudReferenciaMm = ObtenerLongitudLibreSolidoMm(v);

            if (longitudReferenciaMm <= 0.0)
                continue;

            // =========================================================
            // SEPARACIÓN REAL ENTRE DOS ELEMENTOS SELECCIONADOS
            // =========================================================
            // Los puntos de Solidos3D están en coordenadas globales del modelo.
            // Se proyectan sobre la dirección que une ambos sólidos y se calcula
            // el vacío entre la cara final del elemento anterior y la cara inicial
            // del actual. El cursor avanza por ese vacío, pero no se dibuja concreto.
            if (vigaAnteriorPreviewMYG != null)
            {
                double separacionEntreElementosMm =
                    CalcularSeparacionFisicaEntreElementosPreviewMYG(
                        vigaAnteriorPreviewMYG,
                        v);

                if (separacionEntreElementosMm > 1.0)
                {
                    cursor += separacionEntreElementosMm;

                    // Una separación física rompe cualquier continuidad de columna
                    // o de sólido entre los dos ElementId.
                    ultimoTerminoConColumna = false;
                }
            }

            vigaAnteriorPreviewMYG = v;

            double longitudSolidoMm = ObtenerLongitudLibreSolidoMm(v);

            if (longitudSolidoMm <= 0.0)
                longitudSolidoMm = longitudReferenciaMm;

            double anguloVigaGrados = ObtenerAnguloVigaGrados(v);

            List<ColumnaPreview> columnasLocales = new List<ColumnaPreview>();

            if (v.Columnas != null)
            {
                columnasLocales = v.Columnas
                    .Where(c => c != null)
                    .OrderBy(c => c.CentroMm)
                    .ToList();
            }

            List<IntervaloColumnaLocal> intervalos =
                ConstruirIntervalosColumnasLocales(
                    columnasLocales,
                    longitudReferenciaMm,
                    longitudSolidoMm);

            // NUEVO:
            // Si el sólido real de un mismo ElementId está dividido en varios
            // cuerpos, se preservan sus vacíos longitudinales en la serie 2D.
            // Cada intervalo continuo se convierte en un tramo independiente.
            List<VigaLongitudinalPreview.IntervaloSolidoPreview> intervalosSolido =
                v.ObtenerIntervalosSolidoNormalizados(1.0);

            if (intervalosSolido != null && intervalosSolido.Count > 1)
            {
                ultimoTerminoConColumna =
                    AgregarVigaDivididaPorIntervalosSolidoMYG(
                        serie,
                        ref cursor,
                        ultimoTerminoConColumna,
                        v,
                        longitudReferenciaMm,
                        anguloVigaGrados,
                        intervalos,
                        intervalosSolido);

                continue;
            }

            if (intervalos.Count == 0)
            {
                double localInicio = 0.0;
                double localFin = longitudReferenciaMm;

                AgregarTramoVigaSerie(
                    serie,
                    cursor,
                    cursor + longitudSolidoMm,
                    anguloVigaGrados,
                    v,
                    localInicio,
                    localFin,
                    longitudReferenciaMm);

                cursor += longitudSolidoMm;
                ultimoTerminoConColumna = false;
                continue;
            }

            bool saltarPrimeraColumna =
                i > 0 &&
                ultimoTerminoConColumna &&
                intervalos.Count > 0 &&
                intervalos[0].LeftFaceMm <= 1.0;

            double caraDerechaAnterior = 0.0;
            int indiceInicio = 0;

            if (saltarPrimeraColumna)
            {
                caraDerechaAnterior = Math.Max(0.0, intervalos[0].RightFaceMm);
                indiceInicio = 1;
            }
            else
            {
                IntervaloColumnaLocal primera = intervalos[0];

                if (primera.LeftFaceMm <= 1.0)
                {
                    AgregarColumnaSerie(
                        serie,
                        cursor,
                        cursor + primera.AnchoMm);

                    cursor += primera.AnchoMm;
                    caraDerechaAnterior = Math.Max(0.0, primera.RightFaceMm);
                    indiceInicio = 1;
                }
                else
                {
                    caraDerechaAnterior = 0.0;
                    indiceInicio = 0;
                }
            }

            for (int j = indiceInicio; j < intervalos.Count; j++)
            {
                IntervaloColumnaLocal col = intervalos[j];

                if (col == null)
                    continue;

                double caraIzquierda = Clamp(
                    col.LeftFaceMm,
                    0.0,
                    longitudReferenciaMm);

                double luzLibre = caraIzquierda - caraDerechaAnterior;

                if (luzLibre > 1.0)
                {
                    AgregarTramoVigaSerie(
                        serie,
                        cursor,
                        cursor + luzLibre,
                        anguloVigaGrados,
                        v,
                        caraDerechaAnterior,
                        caraIzquierda,
                        longitudReferenciaMm);

                    cursor += luzLibre;
                }

                AgregarColumnaSerie(
                    serie,
                    cursor,
                    cursor + col.AnchoMm);

                cursor += col.AnchoMm;

                caraDerechaAnterior = Clamp(
                    col.RightFaceMm,
                    0.0,
                    longitudReferenciaMm);
            }

            double luzFinal = longitudReferenciaMm - caraDerechaAnterior;

            if (luzFinal > 1.0)
            {
                AgregarTramoVigaSerie(
                    serie,
                    cursor,
                    cursor + luzFinal,
                    anguloVigaGrados,
                    v,
                    caraDerechaAnterior,
                    longitudReferenciaMm,
                    longitudReferenciaMm);

                cursor += luzFinal;
                ultimoTerminoConColumna = false;
            }
            else
            {
                ultimoTerminoConColumna = true;
            }
        }

        serie.MinMm = 0.0;
        serie.MaxMm = Math.Max(cursor, 1.0);

        serie.Columnas = serie.Columnas
            .OrderBy(x => x.LeftMm)
            .ToList();

        serie.TramosViga = serie.TramosViga
            .OrderBy(x => x.StartMm)
            .ToList();

        serie.SegmentosCota = serie.SegmentosCota
            .Where(x => x != null && x.LengthMm > 1.0)
            .OrderBy(x => x.StartMm)
            .ToList();

        CalcularColumnasEnExtremos(serie);

        return serie;
    }

    // =========================================================
    // CONSTRUIR UNA VIGA CON VARIOS CUERPOS CONTINUOS DE CONCRETO
    // =========================================================
    // El cursor global avanza también por los vacíos del sólido, pero no dibuja
    // concreto ni estribos en ellos. Así se mantienen las posiciones relativas
    // y ObtenerRangosTramosSerieVistaPreviaMm() devuelve un rango por cada cuerpo.
    private bool AgregarVigaDivididaPorIntervalosSolidoMYG(
        SerieContinuaPreview serie,
        ref double cursor,
        bool ultimoTerminoConColumna,
        VigaLongitudinalPreview viga,
        double longitudReferenciaMm,
        double anguloVigaGrados,
        List<IntervaloColumnaLocal> columnasLocales,
        List<VigaLongitudinalPreview.IntervaloSolidoPreview> intervalosSolido)
    {
        if (serie == null || viga == null)
            return ultimoTerminoConColumna;

        if (longitudReferenciaMm <= 1.0 ||
            intervalosSolido == null ||
            intervalosSolido.Count == 0)
        {
            return ultimoTerminoConColumna;
        }

        List<IntervaloColumnaLocal> columnas = columnasLocales == null
            ? new List<IntervaloColumnaLocal>()
            : columnasLocales
                .Where(c => c != null)
                .OrderBy(c => c.LeftFaceMm)
                .ToList();

        IntervaloColumnaLocal columnaInicio = columnas
            .Where(c => c.LeftFaceMm <= 1.0 && c.RightFaceMm <= 1.0)
            .OrderByDescending(c => c.RightFaceMm)
            .FirstOrDefault();

        IntervaloColumnaLocal columnaFin = columnas
            .Where(c =>
                c.LeftFaceMm >= longitudReferenciaMm - 1.0 &&
                c.RightFaceMm >= longitudReferenciaMm - 1.0)
            .OrderBy(c => c.LeftFaceMm)
            .FirstOrDefault();

        bool saltarColumnaInicial =
            ultimoTerminoConColumna &&
            columnaInicio != null;

        if (columnaInicio != null && !saltarColumnaInicial)
        {
            double anchoInicio = Math.Max(
                1.0,
                columnaInicio.RightFaceMm - columnaInicio.LeftFaceMm);

            if (anchoInicio <= 1.0)
                anchoInicio = Math.Max(1.0, columnaInicio.AnchoMm);

            AgregarColumnaSerie(
                serie,
                cursor,
                cursor + anchoInicio);

            cursor += anchoInicio;
        }

        double origenLocalGlobal = cursor;

        List<IntervaloColumnaLocal> columnasInteriores = columnas
            .Where(c => !ReferenceEquals(c, columnaInicio))
            .Where(c => !ReferenceEquals(c, columnaFin))
            .Where(c =>
                c.RightFaceMm > 1.0 &&
                c.LeftFaceMm < longitudReferenciaMm - 1.0)
            .ToList();

        foreach (VigaLongitudinalPreview.IntervaloSolidoPreview intervalo
            in intervalosSolido.OrderBy(x => x.InicioMm))
        {
            if (intervalo == null)
                continue;

            double inicio = Clamp(
                Math.Min(intervalo.InicioMm, intervalo.FinMm),
                0.0,
                longitudReferenciaMm);

            double fin = Clamp(
                Math.Max(intervalo.InicioMm, intervalo.FinMm),
                0.0,
                longitudReferenciaMm);

            if (fin <= inicio + 1.0)
                continue;

            List<Tuple<double, double>> partes =
                new List<Tuple<double, double>>()
                {
                    Tuple.Create(inicio, fin)
                };

            foreach (IntervaloColumnaLocal columna in columnasInteriores)
            {
                if (columna == null)
                    continue;

                double corteInicio = Clamp(
                    columna.LeftFaceMm,
                    0.0,
                    longitudReferenciaMm);

                double corteFin = Clamp(
                    columna.RightFaceMm,
                    0.0,
                    longitudReferenciaMm);

                if (corteFin <= corteInicio + 1.0)
                    continue;

                List<Tuple<double, double>> siguientes =
                    new List<Tuple<double, double>>();

                foreach (Tuple<double, double> parte in partes)
                {
                    if (parte == null)
                        continue;

                    double a = parte.Item1;
                    double b = parte.Item2;

                    if (corteFin <= a + 1.0 || corteInicio >= b - 1.0)
                    {
                        siguientes.Add(parte);
                        continue;
                    }

                    if (corteInicio > a + 1.0)
                        siguientes.Add(Tuple.Create(a, Math.Min(b, corteInicio)));

                    if (corteFin < b - 1.0)
                        siguientes.Add(Tuple.Create(Math.Max(a, corteFin), b));
                }

                partes = siguientes;

                if (partes.Count == 0)
                    break;
            }

            foreach (Tuple<double, double> parte in partes)
            {
                if (parte == null || parte.Item2 <= parte.Item1 + 1.0)
                    continue;

                AgregarTramoVigaSerie(
                    serie,
                    origenLocalGlobal + parte.Item1,
                    origenLocalGlobal + parte.Item2,
                    anguloVigaGrados,
                    viga,
                    parte.Item1,
                    parte.Item2,
                    longitudReferenciaMm);
            }
        }

        foreach (IntervaloColumnaLocal columna in columnasInteriores)
        {
            if (columna == null)
                continue;

            double inicio = Clamp(
                columna.LeftFaceMm,
                0.0,
                longitudReferenciaMm);

            double fin = Clamp(
                columna.RightFaceMm,
                0.0,
                longitudReferenciaMm);

            if (fin <= inicio + 1.0)
                continue;

            AgregarColumnaSerie(
                serie,
                origenLocalGlobal + inicio,
                origenLocalGlobal + fin);
        }

        // Se avanza por toda la envolvente física, incluyendo los vacíos.
        cursor = origenLocalGlobal + longitudReferenciaMm;

        if (columnaFin != null)
        {
            double anchoFin = Math.Max(
                1.0,
                columnaFin.RightFaceMm - columnaFin.LeftFaceMm);

            if (anchoFin <= 1.0)
                anchoFin = Math.Max(1.0, columnaFin.AnchoMm);

            AgregarColumnaSerie(
                serie,
                cursor,
                cursor + anchoFin);

            cursor += anchoFin;
            return true;
        }

        return false;
    }

    private List<IntervaloColumnaLocal> ConstruirIntervalosColumnasLocales(
        List<ColumnaPreview> columnasLocales,
        double longitudReferenciaMm,
        double longitudSolidoMm)
    {
        List<IntervaloColumnaLocal> intervalos =
            new List<IntervaloColumnaLocal>();

        if (columnasLocales == null || columnasLocales.Count == 0)
            return intervalos;

        if (longitudReferenciaMm <= 0.0)
            return intervalos;

        double toleranciaExteriorMm = 1000.0;

        bool vigaACaraDeColumna =
            Math.Abs(longitudReferenciaMm - longitudSolidoMm) <= 30.0;

        foreach (ColumnaPreview c in columnasLocales)
        {
            if (c == null)
                continue;

            double ancho = c.AnchoMm <= 0.0 ? 300.0 : c.AnchoMm;

            double left = c.CentroMm - ancho / 2.0;
            double right = c.CentroMm + ancho / 2.0;

            if (right < -toleranciaExteriorMm)
                continue;

            if (left > longitudReferenciaMm + toleranciaExteriorMm)
                continue;

            if (vigaACaraDeColumna)
            {
                double toleranciaExtremoMm = Math.Max(80.0, ancho / 2.0 + 20.0);

                bool esColumnaInicio =
                    Math.Abs(c.CentroMm) <= toleranciaExtremoMm ||
                    (left <= 0.0 && right >= 0.0);

                bool esColumnaFinal =
                    Math.Abs(c.CentroMm - longitudReferenciaMm) <= toleranciaExtremoMm ||
                    (left <= longitudReferenciaMm && right >= longitudReferenciaMm);

                if (esColumnaInicio)
                {
                    left = -ancho;
                    right = 0.0;
                }
                else if (esColumnaFinal)
                {
                    left = longitudReferenciaMm;
                    right = longitudReferenciaMm + ancho;
                }
            }

            intervalos.Add(
                new IntervaloColumnaLocal(
                    left,
                    right,
                    ancho,
                    c.Nombre));
        }

        intervalos = intervalos
            .OrderBy(x => x.LeftFaceMm)
            .ToList();

        intervalos = FusionarIntervalosColumnasLocales(intervalos);

        return intervalos;
    }

    private List<IntervaloColumnaLocal> FusionarIntervalosColumnasLocales(
        List<IntervaloColumnaLocal> intervalos)
    {
        List<IntervaloColumnaLocal> resultado =
            new List<IntervaloColumnaLocal>();

        if (intervalos == null || intervalos.Count == 0)
            return resultado;

        double toleranciaUnionMm = 20.0;

        foreach (IntervaloColumnaLocal col in intervalos.OrderBy(x => x.LeftFaceMm))
        {
            if (col == null)
                continue;

            if (resultado.Count == 0)
            {
                resultado.Add(col);
                continue;
            }

            IntervaloColumnaLocal ultima =
                resultado[resultado.Count - 1];

            if (col.LeftFaceMm <= ultima.RightFaceMm + toleranciaUnionMm)
            {
                double left = Math.Min(ultima.LeftFaceMm, col.LeftFaceMm);
                double right = Math.Max(ultima.RightFaceMm, col.RightFaceMm);

                ultima.LeftFaceMm = left;
                ultima.RightFaceMm = right;
                ultima.AnchoMm = Math.Max(ultima.AnchoMm, right - left);

                if (string.IsNullOrWhiteSpace(ultima.Nombre))
                    ultima.Nombre = col.Nombre;
            }
            else
            {
                resultado.Add(col);
            }
        }

        return resultado;
    }

    private void AgregarTramoVigaSerie(
        SerieContinuaPreview serie,
        double startMm,
        double endMm,
        double anguloGrados)
    {
        AgregarTramoVigaSerie(
            serie,
            startMm,
            endMm,
            anguloGrados,
            null,
            0.0,
            0.0,
            0.0);
    }

    private void AgregarTramoVigaSerie(
        SerieContinuaPreview serie,
        double startMm,
        double endMm,
        double anguloGrados,
        VigaLongitudinalPreview viga,
        double localInicioMm,
        double localFinMm,
        double longitudReferenciaMm)
    {
        if (serie == null)
            return;

        if (endMm <= startMm + 1.0)
            return;

        TramoVigaSeriePreview tramo =
            new TramoVigaSeriePreview(startMm, endMm, anguloGrados);

        // El handler de selección entrega en VigaLongitudinalPreview.Nombre
        // la Marca de tipo del armazón. Si un mismo elemento genera más de
        // un intervalo físico, todos esos tramos conservan la misma marca.
        tramo.MarcaTipo = viga != null && !string.IsNullOrWhiteSpace(viga.Nombre)
            ? viga.Nombre.Trim()
            : string.Empty;

        AplicarPerfilSeccionVariablePreview(
            tramo,
            viga,
            localInicioMm,
            localFinMm,
            longitudReferenciaMm);

        serie.TramosViga.Add(tramo);

        serie.SegmentosCota.Add(
            new SegmentoCotaPreview(startMm, endMm));

        serie.LongitudVigasMm += endMm - startMm;
    }

    private void AplicarPerfilSeccionVariablePreview(
        TramoVigaSeriePreview tramo,
        VigaLongitudinalPreview viga,
        double localInicioMm,
        double localFinMm,
        double longitudReferenciaMm)
    {
        if (tramo == null || viga == null)
            return;

        if (!viga.TienePerfilSeccionVariable)
            return;

        if (longitudReferenciaMm <= 0.0001)
            longitudReferenciaMm = Math.Max(viga.LongitudMm, 1.0);

        double t0 = localInicioMm / longitudReferenciaMm;
        double t1 = localFinMm / longitudReferenciaMm;

        if (t0 < 0.0) t0 = 0.0;
        if (t0 > 1.0) t0 = 1.0;

        if (t1 < 0.0) t1 = 0.0;
        if (t1 > 1.0) t1 = 1.0;

        tramo.TienePerfilSeccionVariable = true;

        tramo.ZSuperiorInicioMm = Interpolar(
            viga.ZSuperiorInicioMm,
            viga.ZSuperiorFinMm,
            t0);

        tramo.ZSuperiorFinMm = Interpolar(
            viga.ZSuperiorInicioMm,
            viga.ZSuperiorFinMm,
            t1);

        tramo.ZInferiorInicioMm = Interpolar(
            viga.ZInferiorInicioMm,
            viga.ZInferiorFinMm,
            t0);

        tramo.ZInferiorFinMm = Interpolar(
            viga.ZInferiorInicioMm,
            viga.ZInferiorFinMm,
            t1);
    }

    private double Interpolar(
        double a,
        double b,
        double t)
    {
        return a + (b - a) * t;
    }

    private void AgregarColumnaSerie(
        SerieContinuaPreview serie,
        double startMm,
        double endMm)
    {
        if (serie == null)
            return;

        if (endMm <= startMm + 1.0)
            return;

        serie.Columnas.Add(
            new ColumnaCajaPreview(startMm, endMm));

        serie.SegmentosCota.Add(
            new SegmentoCotaPreview(startMm, endMm));
    }

    private double Clamp(double valor, double minimo, double maximo)
    {
        if (valor < minimo)
            return minimo;

        if (valor > maximo)
            return maximo;

        return valor;
    }

    private double ObtenerLongitudLibreSolidoMm(VigaLongitudinalPreview v)
    {
        if (v == null)
            return 0.0;

        double valor = ObtenerPropiedadDouble(v, "LongitudSolidoMm");

        if (valor > 0.0)
            return valor;

        valor = ObtenerPropiedadDouble(v, "LongitudLibreMm");

        if (valor > 0.0)
            return valor;

        valor = ObtenerPropiedadDouble(v, "LongitudRealSolidoMm");

        if (valor > 0.0)
            return valor;

        return v.LongitudMm;
    }

    private double ObtenerPropiedadDouble(object obj, string nombrePropiedad)
    {
        if (obj == null)
            return 0.0;

        try
        {
            System.Reflection.PropertyInfo prop =
                obj.GetType().GetProperty(nombrePropiedad);

            if (prop == null)
                return 0.0;

            object valor = prop.GetValue(obj, null);

            if (valor == null)
                return 0.0;

            if (valor is double)
                return (double)valor;

            double resultado = 0.0;

            if (double.TryParse(
                valor.ToString().Replace(",", "."),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out resultado))
            {
                return resultado;
            }
        }
        catch
        {
            return 0.0;
        }

        return 0.0;
    }



    private double ObtenerAnguloVigaGrados(VigaLongitudinalPreview v)
    {
        if (v == null)
            return 0.0;

        double valor = ObtenerPropiedadDouble(v, "AnguloGrados");

        if (Math.Abs(valor) > 0.0001)
            return valor;

        double dz = ObtenerPropiedadDouble(v, "DeltaZMm");
        double proy = ObtenerPropiedadDouble(v, "ProyeccionHorizontalMm");

        if (Math.Abs(dz) > 0.0001 && proy > 0.0001)
            return Math.Atan2(dz, proy) * 180.0 / Math.PI;

        return 0.0;
    }

    private float CalcularDeltaYPorAnguloPreview(double anguloGrados, float deltaX)
    {
        if (Math.Abs(anguloGrados) < 0.01)
            return 0f;

        double rad = anguloGrados * Math.PI / 180.0;
        float dy = (float)(-Math.Tan(rad) * deltaX);

        if (dy > 70f) dy = 70f;
        if (dy < -70f) dy = -70f;

        return dy;
    }

    private Drawing.PointF[] CrearPoligonoTramoPreview(Drawing.PointF p0, Drawing.PointF p1, float espesorPx)
    {
        float dx = p1.X - p0.X;
        float dy = p1.Y - p0.Y;
        float len = (float)Math.Sqrt(dx * dx + dy * dy);

        if (len < 0.001f)
            len = 1f;

        float nx = -dy / len;
        float ny = dx / len;
        float h = espesorPx / 2f;

        return new Drawing.PointF[]
        {
                    new Drawing.PointF(p0.X + nx * h, p0.Y + ny * h),
                    new Drawing.PointF(p1.X + nx * h, p1.Y + ny * h),
                    new Drawing.PointF(p1.X - nx * h, p1.Y - ny * h),
                    new Drawing.PointF(p0.X - nx * h, p0.Y - ny * h)
        };
    }

    private float InterpolarYTramosPreview(List<TramoDibujoPreview> tramos, double xMm, float yFallback)
    {
        if (tramos == null || tramos.Count == 0)
            return yFallback;

        foreach (TramoDibujoPreview td in tramos)
        {
            if (td == null || td.Tramo == null)
                continue;

            if (xMm + 0.001 < td.Tramo.StartMm || xMm - 0.001 > td.Tramo.EndMm)
                continue;

            double len = td.Tramo.EndMm - td.Tramo.StartMm;
            double t = len <= 0.0001 ? 0.0 : (xMm - td.Tramo.StartMm) / len;

            if (t < 0.0) t = 0.0;
            if (t > 1.0) t = 1.0;

            return (float)(td.P0.Y + (td.P1.Y - td.P0.Y) * t);
        }

        TramoDibujoPreview primero = tramos.OrderBy(x => x.Tramo.StartMm).FirstOrDefault();
        TramoDibujoPreview ultimo = tramos.OrderBy(x => x.Tramo.EndMm).LastOrDefault();

        if (primero != null && xMm <= primero.Tramo.StartMm)
            return primero.P0.Y;

        if (ultimo != null && xMm >= ultimo.Tramo.EndMm)
            return ultimo.P1.Y;

        return yFallback;
    }

    private Drawing.PointF InterpolarPuntoEnTramoPreview(TramoDibujoPreview td, double xMm, float offsetNormalPx)
    {
        if (td == null || td.Tramo == null)
            return new Drawing.PointF();

        double lenMm = td.Tramo.EndMm - td.Tramo.StartMm;
        double t = lenMm <= 0.0001 ? 0.0 : (xMm - td.Tramo.StartMm) / lenMm;

        if (t < 0.0) t = 0.0;
        if (t > 1.0) t = 1.0;

        float x = (float)(td.P0.X + (td.P1.X - td.P0.X) * t);
        float y = (float)(td.P0.Y + (td.P1.Y - td.P0.Y) * t);

        return new Drawing.PointF(
            x + td.Normal.X * offsetNormalPx,
            y + td.Normal.Y * offsetNormalPx);
    }

    private void DibujarIntervaloAceroSobreTramos(
        Drawing.Graphics g,
        Drawing.Pen pen,
        List<TramoDibujoPreview> tramos,
        double startMm,
        double endMm,
        float offsetNormalPx)
    {
        if (g == null || pen == null || tramos == null || tramos.Count == 0)
            return;

        foreach (TramoDibujoPreview td in tramos)
        {
            if (td == null || td.Tramo == null)
                continue;

            double a = Math.Max(startMm, td.Tramo.StartMm);
            double b = Math.Min(endMm, td.Tramo.EndMm);

            if (b <= a + 1.0)
                continue;

            Drawing.PointF p0 = InterpolarPuntoEnTramoPreview(td, a, offsetNormalPx);
            Drawing.PointF p1 = InterpolarPuntoEnTramoPreview(td, b, offsetNormalPx);
            g.DrawLine(pen, p0, p1);
        }
    }



    private double ObtenerAnguloSegmentoCotaPreview(
        SegmentoCotaPreview seg,
        List<TramoVigaSeriePreview> tramos)
    {
        if (seg == null || tramos == null || tramos.Count == 0)
            return 0.0;

        TramoVigaSeriePreview tramoExacto = tramos
            .Where(t => t != null)
            .FirstOrDefault(t =>
                Math.Abs(t.StartMm - seg.StartMm) <= 1.0 &&
                Math.Abs(t.EndMm - seg.EndMm) <= 1.0);

        if (tramoExacto != null)
            return tramoExacto.AnguloGrados;

        TramoVigaSeriePreview previo = tramos
            .Where(t => t != null && t.EndMm <= seg.StartMm + 1.0)
            .OrderByDescending(t => t.EndMm)
            .FirstOrDefault();

        TramoVigaSeriePreview siguiente = tramos
            .Where(t => t != null && t.StartMm >= seg.EndMm - 1.0)
            .OrderBy(t => t.StartMm)
            .FirstOrDefault();

        if (previo != null)
            return previo.AnguloGrados;

        if (siguiente != null)
            return siguiente.AnguloGrados;

        return 0.0;
    }

    private List<EjeDibujoPreview> ConstruirEjeDibujoPreview(
        SerieContinuaPreview serie,
        Func<double, int> mapX,
        float yCentroBase)
    {
        List<EjeDibujoPreview> eje = new List<EjeDibujoPreview>();

        if (serie == null || mapX == null)
            return eje;

        List<SegmentoCotaPreview> segmentos = serie.SegmentosCota != null
            ? serie.SegmentosCota.Where(s => s != null && s.EndMm > s.StartMm + 1.0).OrderBy(s => s.StartMm).ToList()
            : new List<SegmentoCotaPreview>();

        if (segmentos.Count == 0 && serie.MaxMm > serie.MinMm + 1.0)
            segmentos.Add(new SegmentoCotaPreview(serie.MinMm, serie.MaxMm));

        float yCursor = yCentroBase;

        foreach (SegmentoCotaPreview seg in segmentos)
        {
            int xa = mapX(seg.StartMm);
            int xb = mapX(seg.EndMm);

            if (Math.Abs(xb - xa) < 1)
                xb = xa + (previewInvertirHorizontalMYG ? -1 : 1);

            double angulo = ObtenerAnguloSegmentoCotaPreview(seg, serie.TramosViga);
            float dy = CalcularDeltaYPorAnguloPreview(
                angulo,
                Math.Abs(xb - xa));

            Drawing.PointF p0 = new Drawing.PointF(xa, yCursor);
            Drawing.PointF p1 = new Drawing.PointF(xb, yCursor + dy);

            float dx = p1.X - p0.X;
            float dyLine = p1.Y - p0.Y;
            float len = (float)Math.Sqrt(dx * dx + dyLine * dyLine);

            if (len < 0.001f)
                len = 1f;

            // La normal debe conservar qué lado gráfico representa SUPERIOR/INFERIOR.
            // Si solo recalculáramos la normal con dx negativo al invertir la vista,
            // se intercambiarían visualmente las capas superior e inferior.
            float normalX = -dyLine / len;
            float normalY = Math.Abs(dx) / len;

            if (previewInvertirHorizontalMYG)
                normalX = -normalX;

            eje.Add(new EjeDibujoPreview()
            {
                StartMm = seg.StartMm,
                EndMm = seg.EndMm,
                P0 = p0,
                P1 = p1,
                Normal = new Drawing.PointF(normalX, normalY)
            });

            yCursor = p1.Y;
        }

        return eje;
    }

    // =========================================================
    // EXTENSIÓN DEL EJE PARA QUE SE VEA LA LONGITUD DE DESARROLLO
    // =========================================================
    // La barra sí se calcula con xBarraInicioMm / xBarraFinMm, pero si el eje
    // gráfico solo existe entre los tramos libres, PuntoEnEjePreview recorta
    // visualmente la línea al primer/último tramo. Este método agrega un eje
    // auxiliar antes y después para poder dibujar el desarrollo en los apoyos.
    private void ExtenderEjeDibujoPreview(
        List<EjeDibujoPreview> eje,
        double xInicioMm,
        double xFinMm,
        Func<double, int> mapX)
    {
        if (eje == null || eje.Count == 0 || mapX == null)
            return;

        eje.Sort((a, b) => a.StartMm.CompareTo(b.StartMm));

        EjeDibujoPreview primero = eje[0];

        if (xInicioMm < primero.StartMm - 1.0)
        {
            double lenMm = primero.EndMm - primero.StartMm;
            double t = lenMm <= 0.0001
                ? 0.0
                : (xInicioMm - primero.StartMm) / lenMm;

            float yInicio = (float)(primero.P0.Y + (primero.P1.Y - primero.P0.Y) * t);

            Drawing.PointF p0 = new Drawing.PointF(
                mapX(xInicioMm),
                yInicio);

            Drawing.PointF p1 = primero.P0;

            eje.Insert(0, new EjeDibujoPreview()
            {
                StartMm = xInicioMm,
                EndMm = primero.StartMm,
                P0 = p0,
                P1 = p1,
                Normal = primero.Normal
            });
        }

        eje.Sort((a, b) => a.StartMm.CompareTo(b.StartMm));

        EjeDibujoPreview ultimo = eje[eje.Count - 1];

        if (xFinMm > ultimo.EndMm + 1.0)
        {
            double lenMm = ultimo.EndMm - ultimo.StartMm;
            double t = lenMm <= 0.0001
                ? 1.0
                : (xFinMm - ultimo.StartMm) / lenMm;

            float yFin = (float)(ultimo.P0.Y + (ultimo.P1.Y - ultimo.P0.Y) * t);

            Drawing.PointF p0 = ultimo.P1;

            Drawing.PointF p1 = new Drawing.PointF(
                mapX(xFinMm),
                yFin);

            eje.Add(new EjeDibujoPreview()
            {
                StartMm = ultimo.EndMm,
                EndMm = xFinMm,
                P0 = p0,
                P1 = p1,
                Normal = ultimo.Normal
            });
        }

        eje.Sort((a, b) => a.StartMm.CompareTo(b.StartMm));
    }


    private EjeDibujoPreview ObtenerSegmentoEjePreview(
        List<EjeDibujoPreview> eje,
        double xMm)
    {
        if (eje == null || eje.Count == 0)
            return null;

        foreach (EjeDibujoPreview s in eje)
        {
            if (s == null)
                continue;

            if (xMm + 0.001 >= s.StartMm && xMm - 0.001 <= s.EndMm)
                return s;
        }

        if (xMm < eje[0].StartMm)
            return eje[0];

        return eje[eje.Count - 1];
    }

    private Drawing.PointF PuntoEnEjePreview(
        List<EjeDibujoPreview> eje,
        double xMm,
        float offsetNormalPx)
    {
        EjeDibujoPreview s = ObtenerSegmentoEjePreview(eje, xMm);

        if (s == null)
            return new Drawing.PointF();

        double lenMm = s.EndMm - s.StartMm;
        double t = lenMm <= 0.0001 ? 0.0 : (xMm - s.StartMm) / lenMm;

        if (t < 0.0) t = 0.0;
        if (t > 1.0) t = 1.0;

        float x = (float)(s.P0.X + (s.P1.X - s.P0.X) * t);
        float y = (float)(s.P0.Y + (s.P1.Y - s.P0.Y) * t);

        return new Drawing.PointF(
            x + s.Normal.X * offsetNormalPx,
            y + s.Normal.Y * offsetNormalPx);
    }

    private float ObtenerYEnEjePreview(
        List<EjeDibujoPreview> eje,
        double xMm,
        float yFallback)
    {
        EjeDibujoPreview s = ObtenerSegmentoEjePreview(eje, xMm);

        if (s == null)
            return yFallback;

        double lenMm = s.EndMm - s.StartMm;
        double t = lenMm <= 0.0001 ? 0.0 : (xMm - s.StartMm) / lenMm;

        if (t < 0.0) t = 0.0;
        if (t > 1.0) t = 1.0;

        return (float)(s.P0.Y + (s.P1.Y - s.P0.Y) * t);
    }

    private void DibujarIntervaloAceroSobreEje(
        Drawing.Graphics g,
        Drawing.Pen pen,
        List<EjeDibujoPreview> eje,
        double startMm,
        double endMm,
        float offsetNormalPx)
    {
        if (g == null || pen == null || eje == null || eje.Count == 0)
            return;

        if (endMm <= startMm + 1.0)
            return;

        List<double> cortes = new List<double>();
        cortes.Add(startMm);
        cortes.Add(endMm);

        foreach (EjeDibujoPreview s in eje)
        {
            if (s == null)
                continue;

            if (s.StartMm > startMm + 1.0 && s.StartMm < endMm - 1.0)
                cortes.Add(s.StartMm);

            if (s.EndMm > startMm + 1.0 && s.EndMm < endMm - 1.0)
                cortes.Add(s.EndMm);
        }

        cortes = cortes.Distinct().OrderBy(x => x).ToList();

        for (int i = 0; i < cortes.Count - 1; i++)
        {
            double a = cortes[i];
            double b = cortes[i + 1];

            if (b <= a + 1.0)
                continue;

            Drawing.PointF p0 = PuntoEnEjePreview(eje, a, offsetNormalPx);
            Drawing.PointF p1 = PuntoEnEjePreview(eje, b, offsetNormalPx);
            g.DrawLine(pen, p0, p1);
        }
    }

    private void CalcularColumnasEnExtremos(SerieContinuaPreview serie)
    {
        if (serie == null ||
            serie.TramosViga == null ||
            serie.TramosViga.Count == 0)
        {
            return;
        }

        double toleranciaMm = 5.0;

        double inicioAcero = serie.TramosViga.Min(x => x.StartMm);
        double finAcero = serie.TramosViga.Max(x => x.EndMm);

        serie.TieneColumnaInicioSerie = serie.Columnas.Any(c =>
            Math.Abs(c.RightMm - inicioAcero) <= toleranciaMm ||
            (c.LeftMm <= inicioAcero && c.RightMm >= inicioAcero));

        serie.TieneColumnaFinSerie = serie.Columnas.Any(c =>
            Math.Abs(c.LeftMm - finAcero) <= toleranciaMm ||
            (c.LeftMm <= finAcero && c.RightMm >= finAcero));
    }


    private bool ObtenerRangoPerfilVariablePreview(
        SerieContinuaPreview serie,
        out double minZ,
        out double maxZ)
    {
        minZ = 0.0;
        maxZ = 0.0;

        if (serie == null || serie.TramosViga == null)
            return false;

        List<double> valores = new List<double>();

        foreach (TramoVigaSeriePreview t in serie.TramosViga)
        {
            if (t == null || !t.TienePerfilSeccionVariable)
                continue;

            valores.Add(t.ZSuperiorInicioMm);
            valores.Add(t.ZSuperiorFinMm);
            valores.Add(t.ZInferiorInicioMm);
            valores.Add(t.ZInferiorFinMm);
        }

        if (valores.Count < 2)
            return false;

        minZ = valores.Min();
        maxZ = valores.Max();

        return maxZ > minZ + 1.0;
    }

    private Drawing.PointF PuntoPerfilVariablePreview(
        List<EjeDibujoPreview> ejeBase,
        double xMm,
        double zMm,
        double centroZMm,
        float escalaZPxPorMm)
    {
        float offsetPx = (float)(-(zMm - centroZMm) * escalaZPxPorMm);
        return PuntoEnEjePreview(ejeBase, xMm, offsetPx);
    }

    private double ObtenerZTramoVariable(
        TramoVigaSeriePreview tramo,
        double xMm,
        int tipo)
    {
        if (tramo == null || !tramo.TienePerfilSeccionVariable)
            return 0.0;

        double len = tramo.EndMm - tramo.StartMm;
        double t = len <= 0.0001 ? 0.0 : (xMm - tramo.StartMm) / len;

        if (t < 0.0) t = 0.0;
        if (t > 1.0) t = 1.0;

        double sup = Interpolar(
            tramo.ZSuperiorInicioMm,
            tramo.ZSuperiorFinMm,
            t);

        double inf = Interpolar(
            tramo.ZInferiorInicioMm,
            tramo.ZInferiorFinMm,
            t);

        if (tipo > 0)
            return sup;

        if (tipo < 0)
            return inf;

        return (sup + inf) / 2.0;
    }

    private List<EjeDibujoPreview> ConstruirEjeAceroVariablePreview(
        SerieContinuaPreview serie,
        List<EjeDibujoPreview> ejeBase,
        double centroZMm,
        float escalaZPxPorMm,
        double recubrimientoMm,
        int tipo)
    {
        List<EjeDibujoPreview> eje = new List<EjeDibujoPreview>();

        if (serie == null || serie.TramosViga == null || ejeBase == null)
            return eje;

        foreach (TramoVigaSeriePreview tramo in serie.TramosViga)
        {
            if (tramo == null || !tramo.TienePerfilSeccionVariable)
                continue;

            double z0 = ObtenerZTramoVariable(tramo, tramo.StartMm, tipo);
            double z1 = ObtenerZTramoVariable(tramo, tramo.EndMm, tipo);

            if (tipo > 0)
            {
                z0 -= recubrimientoMm;
                z1 -= recubrimientoMm;
            }
            else if (tipo < 0)
            {
                z0 += recubrimientoMm;
                z1 += recubrimientoMm;
            }

            Drawing.PointF p0 = PuntoPerfilVariablePreview(
                ejeBase,
                tramo.StartMm,
                z0,
                centroZMm,
                escalaZPxPorMm);

            Drawing.PointF p1 = PuntoPerfilVariablePreview(
                ejeBase,
                tramo.EndMm,
                z1,
                centroZMm,
                escalaZPxPorMm);

            float dx = p1.X - p0.X;
            float dy = p1.Y - p0.Y;
            float len = (float)Math.Sqrt(dx * dx + dy * dy);

            if (len < 0.001f)
                len = 1f;

            eje.Add(new EjeDibujoPreview()
            {
                StartMm = tramo.StartMm,
                EndMm = tramo.EndMm,
                P0 = p0,
                P1 = p1,
                Normal = new Drawing.PointF(-dy / len, dx / len)
            });
        }

        return eje;
    }

    private void InicializarNavegacionVistaPrevia2D()
    {
        if (panelPreview == null)
            return;

        panelPreview.TabStop = true;
        panelPreview.Cursor = WinForms.Cursors.Hand;

        panelPreview.MouseEnter += (s, e) =>
        {
            try
            {
                panelPreview.Focus();
            }
            catch
            {
                // No interrumpir si Windows no permite foco.
            }
        };

        panelPreview.MouseWheel += PanelPreview2D_MouseWheel;
        panelPreview.MouseDown += PanelPreview2D_MouseDown;
        panelPreview.MouseMove += PanelPreview2D_MouseMove;
        panelPreview.MouseUp += PanelPreview2D_MouseUp;
        panelPreview.MouseLeave += PanelPreview2D_MouseLeave;
        panelPreview.MouseDoubleClick += (s, e) =>
        {
            ResetearNavegacionVistaPrevia2D();
        };
    }

    private void PanelPreview2D_MouseWheel(object sender, WinForms.MouseEventArgs e)
    {
        if (panelPreview == null)
            return;

        float zoomAnterior = previewZoom2D;
        float factor = e.Delta > 0 ? 1.22f : 1.0f / 1.22f;

        previewZoom2D *= factor;

        if (previewZoom2D < PREVIEW_ZOOM_2D_MIN)
            previewZoom2D = PREVIEW_ZOOM_2D_MIN;

        if (previewZoom2D > PREVIEW_ZOOM_2D_MAX)
            previewZoom2D = PREVIEW_ZOOM_2D_MAX;

        if (Math.Abs(zoomAnterior) > 0.0001f)
        {
            float ratio = previewZoom2D / zoomAnterior;

            // Zoom hacia la posición del mouse.
            previewPanX2D = e.X - (e.X - previewPanX2D) * ratio;
            previewPanY2D = e.Y - (e.Y - previewPanY2D) * ratio;
        }

        panelPreview.Invalidate();
    }

    private void PanelPreview2D_MouseDown(object sender, WinForms.MouseEventArgs e)
    {
        if (panelPreview == null)
            return;

        if (e.Button == WinForms.MouseButtons.Left ||
            e.Button == WinForms.MouseButtons.Middle ||
            e.Button == WinForms.MouseButtons.Right)
        {
            previewPanActivo2D = true;
            previewPanUltimoPunto2D = e.Location;
            panelPreview.Cursor = WinForms.Cursors.SizeAll;

            try
            {
                panelPreview.Focus();
            }
            catch
            {
                // No interrumpir.
            }
        }
    }

    private void PanelPreview2D_MouseMove(object sender, WinForms.MouseEventArgs e)
    {
        if (!previewPanActivo2D || panelPreview == null)
            return;

        int dx = e.X - previewPanUltimoPunto2D.X;
        int dy = e.Y - previewPanUltimoPunto2D.Y;

        previewPanX2D += dx;
        previewPanY2D += dy;
        previewPanUltimoPunto2D = e.Location;

        panelPreview.Invalidate();
    }

    private void PanelPreview2D_MouseUp(object sender, WinForms.MouseEventArgs e)
    {
        previewPanActivo2D = false;

        if (panelPreview != null)
            panelPreview.Cursor = WinForms.Cursors.Hand;
    }

    private void PanelPreview2D_MouseLeave(object sender, EventArgs e)
    {
        previewPanActivo2D = false;

        if (panelPreview != null)
            panelPreview.Cursor = WinForms.Cursors.Hand;
    }

    private void ResetearNavegacionVistaPrevia2D()
    {
        previewZoom2D = 1.0f;
        previewPanX2D = 0.0f;
        previewPanY2D = 0.0f;
        previewPanActivo2D = false;
        previewPanUltimoPunto2D = Drawing.Point.Empty;

        if (panelPreview != null)
            panelPreview.Invalidate();
    }

    private void DibujarMensajeVistaPrevia(
        Drawing.Graphics g,
        Drawing.Rectangle area,
        string titulo,
        string subtitulo)
    {
        if (g == null)
            return;

        Drawing.Rectangle rect = area;

        if (rect.Width <= 0 || rect.Height <= 0)
            rect = panelPreview != null
                ? panelPreview.ClientRectangle
                : new Drawing.Rectangle(0, 0, 300, 160);

        using (Drawing.Font fontTitulo = new Drawing.Font("Segoe UI", 11.0F, Drawing.FontStyle.Bold))
        using (Drawing.Font fontSub = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Regular))
        using (Drawing.Brush brTitulo = new Drawing.SolidBrush(Drawing.Color.FromArgb(80, 80, 80)))
        using (Drawing.Brush brSub = new Drawing.SolidBrush(Drawing.Color.Gray))
        {
            Drawing.SizeF sizeTitulo = g.MeasureString(titulo ?? "", fontTitulo);
            Drawing.SizeF sizeSub = g.MeasureString(subtitulo ?? "", fontSub);

            float totalH = sizeTitulo.Height + 6.0f + sizeSub.Height;
            float y = rect.Top + (rect.Height - totalH) / 2.0f;

            g.DrawString(
                titulo ?? "",
                fontTitulo,
                brTitulo,
                rect.Left + (rect.Width - sizeTitulo.Width) / 2.0f,
                y);

            g.DrawString(
                subtitulo ?? "",
                fontSub,
                brSub,
                rect.Left + (rect.Width - sizeSub.Width) / 2.0f,
                y + sizeTitulo.Height + 6.0f);
        }
    }

    // =========================================================
    // V11.40 - PREVIEW DE BASTONES / BALANCINES / CENTRALES
    // =========================================================
    private int ObtenerNumeroCapaSuperiorPreviewMYG(string etiqueta)
    {
        if (string.IsNullOrWhiteSpace(etiqueta))
            return 1;

        string t = etiqueta.Trim();
        if (!t.StartsWith("Superior", StringComparison.OrdinalIgnoreCase))
            return 1;

        string resto = t.Substring("Superior".Length).Trim();
        string numero = new string(resto.TakeWhile(char.IsDigit).ToArray());
        int valor;
        return int.TryParse(numero, out valor) && valor > 0 ? valor : 1;
    }

    private bool EsFilaCentralPreviewMYG(FilaConfiguracionEstacionMYG fila)
    {
        return fila != null &&
            !string.IsNullOrWhiteSpace(fila.CapaEtiqueta) &&
            fila.CapaEtiqueta.Trim().StartsWith(
                "Central",
                StringComparison.OrdinalIgnoreCase);
    }

    private FilaConfiguracionEstacionMYG ObtenerFilaEstacionPreviewMYG(
        int tramoIndice,
        string grupoId)
    {
        if (configuracionEstacionesLongitudinalMYG == null ||
            string.IsNullOrWhiteSpace(grupoId))
        {
            return null;
        }

        return configuracionEstacionesLongitudinalMYG.FirstOrDefault(f =>
            f != null &&
            f.TramoIndice == tramoIndice &&
            string.Equals(
                f.GrupoId ?? string.Empty,
                grupoId,
                StringComparison.Ordinal));
    }

    private bool IndiceActivoEnBordeTramoPreviewMYG(
        int tramoIndice,
        string grupoId,
        bool bordeDerecho,
        int indice)
    {
        FilaConfiguracionEstacionMYG fila =
            ObtenerFilaEstacionPreviewMYG(tramoIndice, grupoId);

        if (fila == null || indice < 0)
            return false;

        bool avanzado =
            ModoDistribucionLongitudinalActualMYG ==
                ModoDistribucionLongitudinalMYG.EstacionesAvanzado;

        int zona = avanzado
            ? (bordeDerecho ? 2 : 0)
            : 1;

        return ObtenerIndicesActivosZonaEstacionVisualMYG(
                fila,
                zona,
                avanzado)
            .Contains(indice);
    }

    private List<AceroVigaBarraLongitudinal2D>
        ObtenerDefinicionesGrupoOrdenadasPreviewMYG(
            AceroVigaDisenoSeccion diseno,
            string grupoId)
    {
        if (diseno == null ||
            diseno.Longitudinales == null ||
            string.IsNullOrWhiteSpace(grupoId))
        {
            return new List<AceroVigaBarraLongitudinal2D>();
        }

        FilaConfiguracionEstacionMYG filaRef =
            configuracionEstacionesLongitudinalMYG != null
                ? configuracionEstacionesLongitudinalMYG.FirstOrDefault(f =>
                    f != null &&
                    string.Equals(
                        f.GrupoId ?? string.Empty,
                        grupoId,
                        StringComparison.Ordinal))
                : null;

        // Barra individual: GrupoId es una clave sintética, por eso se busca
        // por BarraIndividualId y no por GrupoDistribucionId.
        if (filaRef != null &&
            !string.IsNullOrWhiteSpace(filaRef.BarraIndividualId))
        {
            AceroVigaBarraLongitudinal2D individual =
                diseno.Longitudinales.FirstOrDefault(b =>
                    b != null &&
                    string.Equals(
                        b.Id ?? string.Empty,
                        filaRef.BarraIndividualId,
                        StringComparison.Ordinal));

            return individual != null
                ? new List<AceroVigaBarraLongitudinal2D> { individual }
                : new List<AceroVigaBarraLongitudinal2D>();
        }

        List<AceroVigaBarraLongitudinal2D> lista =
            diseno.Longitudinales
                .Where(b =>
                    b != null &&
                    b.Punto != null &&
                    !b.OcultaPorSuperposicion &&
                    string.Equals(
                        b.GrupoDistribucionId ?? string.Empty,
                        grupoId,
                        StringComparison.Ordinal))
                .ToList();

        if (lista.Count <= 1)
            return lista;

        AceroVigaGrupoLongitudinal2D grupo =
            diseno.GruposLongitudinales != null
                ? diseno.GruposLongitudinales.FirstOrDefault(gr =>
                    gr != null &&
                    string.Equals(
                        gr.Id ?? string.Empty,
                        grupoId,
                        StringComparison.Ordinal))
                : null;

        if (lista.All(b => b.ParametroSobreGuia >= 0.0))
        {
            bool ascendente = grupo == null ||
                grupo.ParametroFinGuia >= grupo.ParametroInicioGuia;

            return ascendente
                ? lista.OrderBy(b => b.ParametroSobreGuia).ToList()
                : lista.OrderByDescending(b => b.ParametroSobreGuia).ToList();
        }

        return lista
            .OrderBy(b => b.Punto.U)
            .ThenByDescending(b => b.Punto.V)
            .ToList();
    }

    private double ObtenerDesarrolloEspecialPreviewMmMYG(
        AceroVigaDisenoSeccion diseno,
        string grupoId,
        int indice)
    {
        List<AceroVigaBarraLongitudinal2D> defs =
            ObtenerDefinicionesGrupoOrdenadasPreviewMYG(diseno, grupoId);

        double cm = ExtensionCambiosEstacionesCmMYG;
        if (indice >= 0 && indice < defs.Count && defs[indice] != null)
        {
            cm = ObtenerDesarrolloCortePorDiametroCmMYG(
                defs[indice].TipoBarra);
        }

        return Math.Max(0.0, cm) * 10.0;
    }

    private void DibujarIntervaloEspecialPreviewMYG(
        Drawing.Graphics g,
        Drawing.Pen pen,
        Drawing.Brush brush,
        Drawing.Font font,
        List<EjeDibujoPreview> eje,
        double inicioMm,
        double finMm,
        float offsetPx,
        string texto)
    {
        if (g == null || pen == null || eje == null || eje.Count == 0 ||
            finMm <= inicioMm + 0.5)
        {
            return;
        }

        DibujarIntervaloAceroSobreEje(
            g,
            pen,
            eje,
            inicioMm,
            finMm,
            offsetPx);

        Drawing.PointF p0 = PuntoEnEjePreview(eje, inicioMm, offsetPx);
        Drawing.PointF p1 = PuntoEnEjePreview(eje, finMm, offsetPx);

        float r = 2.4f;
        if (brush != null)
        {
            g.FillEllipse(brush, p0.X - r, p0.Y - r, r * 2f, r * 2f);
            g.FillEllipse(brush, p1.X - r, p1.Y - r, r * 2f, r * 2f);
        }

        // La etiqueta aparece cuando hay suficiente zoom para no ensuciar
        // la vista general. Permite identificar exactamente cada recorrido.
        if (!string.IsNullOrWhiteSpace(texto) &&
            font != null && brush != null && previewZoom2D >= 1.15f)
        {
            double medio = (inicioMm + finMm) / 2.0;
            Drawing.PointF pm = PuntoEnEjePreview(eje, medio, offsetPx - 9f);
            Drawing.SizeF sz = g.MeasureString(texto, font);
            g.DrawString(texto, font, brush, pm.X - sz.Width / 2f, pm.Y - sz.Height);
        }
    }

    private void DibujarAcerosCentralesEstacionesPreviewMYG(
        Drawing.Graphics g,
        SerieContinuaPreview serie,
        List<EjeDibujoPreview> ejeCentral,
        float offsetCentral)
    {
        if (g == null || serie == null || ejeCentral == null || ejeCentral.Count == 0 ||
            configuracionEstacionesLongitudinalMYG == null ||
            configuracionEstacionesLongitudinalMYG.Count == 0 ||
            serie.TramosViga == null || serie.TramosViga.Count == 0)
        {
            return;
        }

        bool avanzado =
            ModoDistribucionLongitudinalActualMYG ==
                ModoDistribucionLongitudinalMYG.EstacionesAvanzado;

        List<TramoVigaSeriePreview> tramos = serie.TramosViga
            .Where(t => t != null)
            .OrderBy(t => Math.Min(t.StartMm, t.EndMm))
            .ToList();

        using (Drawing.Pen penCentralEstacion = new Drawing.Pen(
            Drawing.Color.FromArgb(0, 150, 70),
            3.0f))
        using (Drawing.SolidBrush brushCentral = new Drawing.SolidBrush(
            Drawing.Color.FromArgb(0, 125, 60)))
        using (Drawing.Font fontCentral = new Drawing.Font(
            "Segoe UI",
            6.5f,
            Drawing.FontStyle.Bold))
        {
            for (int i = 0; i < tramos.Count; i++)
            {
                TramoVigaSeriePreview tramo = tramos[i];
                double a = Math.Min(tramo.StartMm, tramo.EndMm);
                double b = Math.Max(tramo.StartMm, tramo.EndMm);
                double L = b - a;
                if (L <= 0.5)
                    continue;

                List<FilaConfiguracionEstacionMYG> filas =
                    configuracionEstacionesLongitudinalMYG
                        .Where(f => f != null &&
                                    f.TramoIndice == i &&
                                    EsFilaCentralPreviewMYG(f))
                        .ToList();

                int filaOrden = 0;
                foreach (FilaConfiguracionEstacionMYG fila in filas)
                {
                    float desplazamientoFila = (filaOrden - (filas.Count - 1) / 2f) * 3.0f;
                    filaOrden++;

                    if (!avanzado)
                    {
                        List<int> activos = ObtenerIndicesActivosZonaEstacionVisualMYG(
                            fila, 1, false);

                        for (int k = 0; k < activos.Count; k++)
                        {
                            float off = offsetCentral + desplazamientoFila +
                                (k - (activos.Count - 1) / 2f) * 1.8f;
                            DibujarIntervaloEspecialPreviewMYG(
                                g,
                                penCentralEstacion,
                                brushCentral,
                                fontCentral,
                                ejeCentral,
                                a,
                                b,
                                off,
                                k == 0 ? "CENTRAL" : string.Empty);
                        }
                    }
                    else
                    {
                        double tercio = L / 3.0;
                        for (int zona = 0; zona < 3; zona++)
                        {
                            double za = a + zona * tercio;
                            double zb = zona == 2 ? b : a + (zona + 1) * tercio;
                            List<int> activos = ObtenerIndicesActivosZonaEstacionVisualMYG(
                                fila, zona, true);

                            for (int k = 0; k < activos.Count; k++)
                            {
                                float off = offsetCentral + desplazamientoFila +
                                    (k - (activos.Count - 1) / 2f) * 1.8f;
                                DibujarIntervaloEspecialPreviewMYG(
                                    g,
                                    penCentralEstacion,
                                    brushCentral,
                                    fontCentral,
                                    ejeCentral,
                                    za,
                                    zb,
                                    off,
                                    zona == 1 && k == 0 ? "CENTRAL" : string.Empty);
                            }
                        }
                    }
                }
            }
        }
    }

    private void DibujarAcerosEstacionesEspecialesPreviewMYG(
        Drawing.Graphics g,
        SerieContinuaPreview serie,
        List<EjeDibujoPreview> ejeSuperior,
        List<EjeDibujoPreview> ejeCentral,
        float offsetSuperiorBase,
        float separacionCapasPreviewPx,
        float offsetCentral,
        double rangoMm,
        int anchoDibujo)
    {
        if (g == null || serie == null ||
            serie.TramosViga == null || serie.TramosViga.Count == 0)
        {
            return;
        }

        // Primero dibuja los centrales exactos por tramo/zona.
        DibujarAcerosCentralesEstacionesPreviewMYG(
            g,
            serie,
            ejeCentral,
            offsetCentral);

        if (clasificacionesEspecialesLongitudinalMYG == null ||
            clasificacionesEspecialesLongitudinalMYG.Count == 0 ||
            ejeSuperior == null || ejeSuperior.Count == 0)
        {
            return;
        }

        AceroVigaDisenoSeccion diseno = ObtenerDisenoActualEstacionesMYG();
        if (diseno == null)
            return;

        List<TramoVigaSeriePreview> tramos = serie.TramosViga
            .Where(t => t != null)
            .OrderBy(t => Math.Min(t.StartMm, t.EndMm))
            .ToList();

        if (tramos.Count == 0)
            return;

        using (Drawing.Pen penBaston = new Drawing.Pen(
            Drawing.Color.FromArgb(210, 45, 45),
            3.4f))
        using (Drawing.Pen penBalancin = new Drawing.Pen(
            Drawing.Color.FromArgb(125, 55, 180),
            3.4f))
        using (Drawing.SolidBrush brushBaston = new Drawing.SolidBrush(
            Drawing.Color.FromArgb(190, 35, 35)))
        using (Drawing.SolidBrush brushBalancin = new Drawing.SolidBrush(
            Drawing.Color.FromArgb(105, 40, 165)))
        using (Drawing.Font fontEspecial = new Drawing.Font(
            "Segoe UI",
            6.5f,
            Drawing.FontStyle.Bold))
        {
            // ---------------------------------------------------------
            // V11.41 - BASTONES POR TRAMO: DOS TERCIOS EXTREMOS.
            // ---------------------------------------------------------
            // Una barra marcada como BASTÓN en Ti se representa como:
            //
            //   [ L/3 desde cara izquierda ]  VACÍO  [ L/3 hasta cara derecha ]
            //
            // El tercio central queda expresamente vacío. En los extremos
            // físicos de la serie, el bastón obedece Desarrollo inicial/final,
            // AUTO y GANCHO de la ventana principal.
            // ---------------------------------------------------------
            int ultimo = tramos.Count - 1;
            foreach (ClasificacionEspecialBarraMYG clasificacion in
                clasificacionesEspecialesLongitudinalMYG.Where(c =>
                    c != null &&
                    c.TramoIndice >= 0 &&
                    c.TramoIndice < tramos.Count &&
                    !string.IsNullOrWhiteSpace(c.GrupoId) &&
                    c.IndicesBaston != null &&
                    c.IndicesBaston.Count > 0))
            {
                int indiceTramo = clasificacion.TramoIndice;

                FilaConfiguracionEstacionMYG fila =
                    ObtenerFilaEstacionPreviewMYG(
                        indiceTramo,
                        clasificacion.GrupoId);

                if (fila == null || !EsCapaSuperiorEspecialMYG(fila))
                    continue;

                int capa = ObtenerNumeroCapaSuperiorPreviewMYG(fila.CapaEtiqueta);
                float offsetCapa = offsetSuperiorBase +
                    Math.Max(0, capa - 1) * separacionCapasPreviewPx;

                TramoVigaSeriePreview tramo = tramos[indiceTramo];
                double a = Math.Min(tramo.StartMm, tramo.EndMm);
                double b = Math.Max(tramo.StartMm, tramo.EndMm);
                double L = Math.Max(0.0, b - a);
                double tercio = L / 3.0;

                if (tercio <= 0.5)
                    continue;

                double desarrolloInicioGeneralMm =
                    indiceTramo == 0 && LongitudDesarrolloInicioHabilitada
                        ? ObtenerLongitudDesarrolloInicioMm()
                        : 0.0;

                double desarrolloFinGeneralMm =
                    indiceTramo == ultimo && LongitudDesarrolloFinHabilitada
                        ? ObtenerLongitudDesarrolloFinMm()
                        : 0.0;

                bool etiquetaVacioDibujada = false;

                foreach (int indice in clasificacion.IndicesBaston
                    .Where(ind => ind >= 0)
                    .Distinct()
                    .OrderBy(ind => ind))
                {
                    float offIndice = offsetCapa +
                        (indice - Math.Max(0, fila.CantidadMaxima - 1) / 2f) * 1.5f;

                    bool activoIzquierda =
                        IndiceActivoEnBordeTramoPreviewMYG(
                            indiceTramo,
                            clasificacion.GrupoId,
                            false,
                            indice);

                    bool activoDerecha =
                        IndiceActivoEnBordeTramoPreviewMYG(
                            indiceTramo,
                            clasificacion.GrupoId,
                            true,
                            indice);

                    if (activoIzquierda)
                    {
                        double ini = a - desarrolloInicioGeneralMm;
                        double fin = a + tercio;

                        DibujarIntervaloEspecialPreviewMYG(
                            g,
                            penBaston,
                            brushBaston,
                            fontEspecial,
                            ejeSuperior,
                            ini,
                            fin,
                            offIndice,
                            "BASTÓN L/3");

                        if (indiceTramo == 0 && GanchoInicio)
                        {
                            int hookPx = ObtenerGanchoPreviewPx(
                                ObtenerLongitudGanchoInicioMm(),
                                rangoMm,
                                anchoDibujo);

                            Drawing.PointF pHook =
                                PuntoEnEjePreview(
                                    ejeSuperior,
                                    ini,
                                    offIndice);

                            g.DrawLine(
                                penBaston,
                                pHook.X,
                                pHook.Y,
                                pHook.X,
                                pHook.Y + hookPx);
                        }
                    }

                    if (activoDerecha)
                    {
                        double ini = b - tercio;
                        double fin = b + desarrolloFinGeneralMm;

                        DibujarIntervaloEspecialPreviewMYG(
                            g,
                            penBaston,
                            brushBaston,
                            fontEspecial,
                            ejeSuperior,
                            ini,
                            fin,
                            offIndice,
                            "BASTÓN L/3");

                        if (indiceTramo == ultimo && GanchoFin)
                        {
                            int hookPx = ObtenerGanchoPreviewPx(
                                ObtenerLongitudGanchoFinMm(),
                                rangoMm,
                                anchoDibujo);

                            Drawing.PointF pHook =
                                PuntoEnEjePreview(
                                    ejeSuperior,
                                    fin,
                                    offIndice);

                            g.DrawLine(
                                penBaston,
                                pHook.X,
                                pHook.Y,
                                pHook.X,
                                pHook.Y + hookPx);
                        }
                    }

                    // Una sola indicación por grupo/tramo para que sea evidente
                    // que el centro NO forma parte del bastón.
                    if (!etiquetaVacioDibujada &&
                        activoIzquierda &&
                        activoDerecha &&
                        previewZoom2D >= 1.15f)
                    {
                        Drawing.PointF pVacio = PuntoEnEjePreview(
                            ejeSuperior,
                            a + L / 2.0,
                            offIndice - 11f);

                        string textoVacio = "TERCIO CENTRAL VACÍO";
                        Drawing.SizeF szVacio =
                            g.MeasureString(textoVacio, fontEspecial);

                        g.DrawString(
                            textoVacio,
                            fontEspecial,
                            brushBaston,
                            pVacio.X - szVacio.Width / 2f,
                            pVacio.Y - szVacio.Height);

                        etiquetaVacioDibujada = true;
                    }
                }
            }

            // ---------------------------------------------------------
            // BALANCINES EN CADA APOYO INTERIOR.
            // ---------------------------------------------------------
            if (tramos.Count >= 2)
            {
                for (int i = 0; i < tramos.Count - 1; i++)
                {
                    TramoVigaSeriePreview izq = tramos[i];
                    TramoVigaSeriePreview der = tramos[i + 1];

                    double iniIzq = Math.Min(izq.StartMm, izq.EndMm);
                    double finIzq = Math.Max(izq.StartMm, izq.EndMm);
                    double iniDer = Math.Min(der.StartMm, der.EndMm);
                    double finDer = Math.Max(der.StartMm, der.EndMm);
                    double tercioIzq = Math.Max(0.0, finIzq - iniIzq) / 3.0;
                    double tercioDer = Math.Max(0.0, finDer - iniDer) / 3.0;

                    List<string> grupos = clasificacionesEspecialesLongitudinalMYG
                        .Where(c => c != null &&
                            (c.TramoIndice == i || c.TramoIndice == i + 1) &&
                            c.IndicesBalancin != null && c.IndicesBalancin.Count > 0 &&
                            !string.IsNullOrWhiteSpace(c.GrupoId))
                        .Select(c => c.GrupoId)
                        .Distinct(StringComparer.Ordinal)
                        .ToList();

                    foreach (string grupoId in grupos)
                    {
                        HashSet<int> indices = new HashSet<int>();
                        foreach (ClasificacionEspecialBarraMYG c in
                            clasificacionesEspecialesLongitudinalMYG.Where(c =>
                                c != null &&
                                (c.TramoIndice == i || c.TramoIndice == i + 1) &&
                                string.Equals(c.GrupoId, grupoId, StringComparison.Ordinal) &&
                                c.IndicesBalancin != null))
                        {
                            indices.UnionWith(c.IndicesBalancin.Where(ind => ind >= 0));
                        }

                        FilaConfiguracionEstacionMYG fila =
                            ObtenerFilaEstacionPreviewMYG(i, grupoId) ??
                            ObtenerFilaEstacionPreviewMYG(i + 1, grupoId);
                        if (fila == null || !EsCapaSuperiorEspecialMYG(fila))
                            continue;

                        int capa = ObtenerNumeroCapaSuperiorPreviewMYG(fila.CapaEtiqueta);
                        float offsetCapa = offsetSuperiorBase +
                            Math.Max(0, capa - 1) * separacionCapasPreviewPx;

                        foreach (int indice in indices.OrderBy(ind => ind))
                        {
                            if (!IndiceActivoEnBordeTramoPreviewMYG(
                                    i,
                                    grupoId,
                                    true,
                                    indice) ||
                                !IndiceActivoEnBordeTramoPreviewMYG(
                                    i + 1,
                                    grupoId,
                                    false,
                                    indice))
                            {
                                continue;
                            }

                            float offIndice = offsetCapa +
                                (indice - Math.Max(0, fila.CantidadMaxima - 1) / 2f) * 1.5f;

                            DibujarIntervaloEspecialPreviewMYG(
                                g,
                                penBalancin,
                                brushBalancin,
                                fontEspecial,
                                ejeSuperior,
                                finIzq - tercioIzq,
                                iniDer + tercioDer,
                                offIndice,
                                "BALANCÍN");
                        }
                    }
                }
            }
        }
    }

    private void DibujarVistaPrevia(object sender, WinForms.PaintEventArgs e)
    {
        Drawing.Graphics g = e.Graphics;
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

        Drawing.Rectangle area = previewUsarAreaExterna
            ? previewAreaExterna
            : panelPreview.ClientRectangle;

        g.Clear(Drawing.Color.White);

        // Si no hay selección real, no se dibuja geometría de ejemplo.
        // Se muestra el mensaje dentro del mismo cuadro de vista preliminar.
        if (previewVigas == null || previewVigas.Count == 0)
        {
            DibujarMensajeVistaPrevia(
                g,
                area,
                "NO HAY VIGAS SELECCIONADAS",
                "Presione SELECCIONAR VIGAS / ARMAZONES para actualizar la vista preliminar.");
            return;
        }

        // Pan/zoom solo para la vista preliminar 2D de esta ventana.
        // Cuando el dibujo se reutiliza desde otra ventana con DibujarVistaPreviaComun,
        // no se aplica navegación para no deformar la escala externa.
        if (!previewUsarAreaExterna)
        {
            g.TranslateTransform(previewPanX2D, previewPanY2D);
            g.ScaleTransform(previewZoom2D, previewZoom2D);
        }

        SerieContinuaPreview serie = ConstruirSerieContinua(previewVigas);

        if (serie == null || serie.TramosViga == null || serie.TramosViga.Count == 0)
        {
            g.ResetTransform();
            DibujarMensajeVistaPrevia(
                g,
                area,
                "NO HAY VIGAS SELECCIONADAS",
                "Presione SELECCIONAR VIGAS / ARMAZONES para actualizar la vista preliminar.");
            return;
        }

        int margenIzq = 40;
        int margenDer = 28;

        int yBeam = 50;
        int hBeam = 30;

        int yDimSerie = yBeam + hBeam + 108;
        int yDimTotal = yDimSerie + 40;

        double startGlobal = serie.TramosViga.Min(x => x.StartMm);
        double endGlobal = serie.TramosViga.Max(x => x.EndMm);

        double desarrolloInicioMm = ObtenerLongitudDesarrolloInicioMm();
        double desarrolloFinMm = ObtenerLongitudDesarrolloFinMm();
        double recubrimientoMm = ObtenerRecubrimientoMm();

        double xBarraInicioMm;
        double xBarraFinMm;

        if (serie.TieneColumnaInicioSerie && LongitudDesarrolloInicioHabilitada)
            xBarraInicioMm = startGlobal - desarrolloInicioMm;
        else
            xBarraInicioMm = startGlobal + recubrimientoMm;

        if (serie.TieneColumnaFinSerie && LongitudDesarrolloFinHabilitada)
            xBarraFinMm = endGlobal + desarrolloFinMm;
        else
            xBarraFinMm = endGlobal - recubrimientoMm;

        double displayMinMm = Math.Min(serie.MinMm, xBarraInicioMm);
        double displayMaxMm = Math.Max(serie.MaxMm, xBarraFinMm);

        // V11.41 - reservar el desarrollo GENERAL real de los bastones de
        // esquina. Ya no se usa el desarrollo por diámetro para estos extremos:
        // deben obedecer Desarrollo inicial/final + AUTO de la ventana principal.
        if (ModoDistribucionLongitudinalActualMYG !=
                ModoDistribucionLongitudinalMYG.Continuo &&
            clasificacionesEspecialesLongitudinalMYG != null &&
            clasificacionesEspecialesLongitudinalMYG.Any(c =>
                c != null && c.IndicesBaston != null && c.IndicesBaston.Count > 0))
        {
            int ultimoTramoPreview = Math.Max(0, serie.TramosViga.Count - 1);
            bool hayBastonInicio = clasificacionesEspecialesLongitudinalMYG.Any(c =>
                c != null && c.TramoIndice == 0 &&
                c.IndicesBaston != null && c.IndicesBaston.Count > 0);
            bool hayBastonFin = clasificacionesEspecialesLongitudinalMYG.Any(c =>
                c != null && c.TramoIndice == ultimoTramoPreview &&
                c.IndicesBaston != null && c.IndicesBaston.Count > 0);

            if (hayBastonInicio && LongitudDesarrolloInicioHabilitada)
                displayMinMm = Math.Min(displayMinMm, startGlobal - desarrolloInicioMm);
            if (hayBastonFin && LongitudDesarrolloFinHabilitada)
                displayMaxMm = Math.Max(displayMaxMm, endGlobal + desarrolloFinMm);
        }

        if (Math.Abs(displayMaxMm - displayMinMm) < 1.0)
            displayMaxMm = displayMinMm + 1.0;

        int x0 = margenIzq;
        int x1 = area.Width - margenDer;

        if (x1 <= x0)
            return;

        int anchoDibujo = x1 - x0;
        double rangoMm = displayMaxMm - displayMinMm;

        if (rangoMm <= 0.0)
            return;

        Func<double, int> mapX = mm =>
        {
            double t = AjustarParametroHorizontalPreviewMYG(
                (mm - displayMinMm) / rangoMm);

            return x0 + (int)(t * anchoDibujo);
        };

        Drawing.Pen penBeam = new Drawing.Pen(Drawing.Color.FromArgb(90, 90, 90), 2);
        Drawing.Pen penSupport = new Drawing.Pen(Drawing.Color.FromArgb(95, 95, 95), 1);
        Drawing.Color colorLongitudinalGris = Drawing.Color.FromArgb(150, 150, 150);
        Drawing.Color colorSuperiorPreview = previewForzarLongitudinalesGris ? colorLongitudinalGris : ColorAceroSuperior;
        Drawing.Color colorInferiorPreview = previewForzarLongitudinalesGris ? colorLongitudinalGris : ColorAceroInferior;
        Drawing.Color colorCentralPreview = previewForzarLongitudinalesGris ? colorLongitudinalGris : ColorAceroCentral;
        Drawing.Color colorEmpalmePreview = previewForzarLongitudinalesGris ? colorLongitudinalGris : ColorEmpalmePreview;

        Drawing.Pen penSuperior = new Drawing.Pen(colorSuperiorPreview, 2);
        Drawing.Pen penInferior = new Drawing.Pen(colorInferiorPreview, 2);
        Drawing.Pen penCentral = new Drawing.Pen(colorCentralPreview, 2);
        Drawing.Pen penEmpalme = new Drawing.Pen(colorEmpalmePreview, 3);
        // Referencia visual de estribos ya configurados/creados.
        // Se dibuja en gris para no confundirse con el acero longitudinal superior/inferior.
        Drawing.Pen penEstriboPreview = new Drawing.Pen(Drawing.Color.FromArgb(120, 120, 120), 1.1f);
        Drawing.Pen penDim = new Drawing.Pen(Drawing.Color.FromArgb(95, 95, 95), 1);

        Drawing.Brush brushBeam = new Drawing.SolidBrush(Drawing.Color.FromArgb(236, 236, 236));
        Drawing.Brush brushSupport = new Drawing.SolidBrush(Drawing.Color.FromArgb(210, 210, 210));
        Drawing.Brush brushText = new Drawing.SolidBrush(Drawing.Color.FromArgb(45, 45, 45));

        Drawing.Font font = new Drawing.Font("Segoe UI", 7.5F);
        Drawing.Font fontBold = new Drawing.Font("Segoe UI", 7.5F, Drawing.FontStyle.Bold);

        float yCentroBase = yBeam + hBeam / 2f;
        List<EjeDibujoPreview> ejeDibujo = ConstruirEjeDibujoPreview(serie, mapX, yCentroBase);

        // V11.7 MYG - referencia visual inequívoca de los dos extremos.
        // Se ubica sobre el extremo REAL del acero para que el usuario pueda
        // relacionar directamente Desarrollo inicial / Desarrollo final con
        // la elevación de la vista preliminar.
        DibujarIndicadoresInicialFinalPreviewMYG(
            g,
            area,
            mapX,
            xBarraInicioMm,
            xBarraFinMm,
            yBeam,
            hBeam,
            fontBold,
            brushText);

        double minZPerfil = 0.0;
        double maxZPerfil = 0.0;
        bool hayPerfilVariable = ObtenerRangoPerfilVariablePreview(
            serie,
            out minZPerfil,
            out maxZPerfil);

        double centroZPerfil = (minZPerfil + maxZPerfil) / 2.0;
        float escalaZPerfil = hayPerfilVariable
            ? (float)(hBeam / Math.Max(1.0, maxZPerfil - minZPerfil))
            : 1.0f;

        // Columnas primero, con su ancho real proyectado sobre el eje.
        foreach (ColumnaCajaPreview col in serie.Columnas)
        {
            int xColA = mapX(col.LeftMm);
            int xColB = mapX(col.RightMm);
            int xl = Math.Min(xColA, xColB);
            int xr = Math.Max(xColA, xColB);

            if (xr <= xl)
                xr = xl + 1;

            float yCol = ObtenerYEnEjePreview(ejeDibujo, col.CenterMm, yCentroBase);
            int extensionArriba = 14;
            int extensionAbajo = 58;

            Drawing.Rectangle rectCol = new Drawing.Rectangle(
                xl,
                (int)Math.Round(yCol - hBeam / 2f - extensionArriba),
                xr - xl,
                hBeam + extensionArriba + extensionAbajo);

            g.FillRectangle(brushSupport, rectCol);
            g.DrawRectangle(penSupport, rectCol);
        }

        // Vigas inclinadas y de sección variable según perfil limpio inicio/fin.
        foreach (TramoVigaSeriePreview tramo in serie.TramosViga)
        {
            if (hayPerfilVariable && tramo.TienePerfilSeccionVariable)
            {
                Drawing.PointF pSupIni = PuntoPerfilVariablePreview(
                    ejeDibujo,
                    tramo.StartMm,
                    tramo.ZSuperiorInicioMm,
                    centroZPerfil,
                    escalaZPerfil);

                Drawing.PointF pSupFin = PuntoPerfilVariablePreview(
                    ejeDibujo,
                    tramo.EndMm,
                    tramo.ZSuperiorFinMm,
                    centroZPerfil,
                    escalaZPerfil);

                Drawing.PointF pInfFin = PuntoPerfilVariablePreview(
                    ejeDibujo,
                    tramo.EndMm,
                    tramo.ZInferiorFinMm,
                    centroZPerfil,
                    escalaZPerfil);

                Drawing.PointF pInfIni = PuntoPerfilVariablePreview(
                    ejeDibujo,
                    tramo.StartMm,
                    tramo.ZInferiorInicioMm,
                    centroZPerfil,
                    escalaZPerfil);

                Drawing.PointF[] poly = new Drawing.PointF[]
                {
                            pSupIni,
                            pSupFin,
                            pInfFin,
                            pInfIni
                };

                g.FillPolygon(brushBeam, poly);
                g.DrawPolygon(penBeam, poly);
            }
            else
            {
                Drawing.PointF pIni = PuntoEnEjePreview(ejeDibujo, tramo.StartMm, 0f);
                Drawing.PointF pFin = PuntoEnEjePreview(ejeDibujo, tramo.EndMm, 0f);
                Drawing.PointF[] poly = CrearPoligonoTramoPreview(pIni, pFin, hBeam);

                g.FillPolygon(brushBeam, poly);
                g.DrawPolygon(penBeam, poly);
            }
        }

        // Guías visuales de tercios para ubicar empalmes.
        // Solo se muestran cuando está activo "Crear empalmes".
        DibujarGuiasTerciosEmpalmePreview(
            g,
            serie,
            ejeDibujo,
            hBeam,
            xBarraInicioMm,
            xBarraFinMm);

        // Barras continuas: ahora se dibujan también en nodos/columnas y extremos.
        if (MostrarAcerosEnVistaPreliminar && xBarraFinMm > xBarraInicioMm)
        {
            double longitudBarraMm = ObtenerLongitudBarraMm();
            double longitudEmpalmeSuperiorMm = ObtenerLongitudEmpalmeSuperiorMm();
            double longitudEmpalmeInferiorMm = ObtenerLongitudEmpalmeInferiorMm();
            double longitudEmpalmeCentralMm = ObtenerLongitudEmpalmeCentralMm();
            double ganchoInicioMm = GanchoInicio ? ObtenerLongitudGanchoInicioMm() : 0.0;

            List<EjeDibujoPreview> ejeSuperior = new List<EjeDibujoPreview>(ejeDibujo);
            List<EjeDibujoPreview> ejeInferior = new List<EjeDibujoPreview>(ejeDibujo);
            List<EjeDibujoPreview> ejeCentral = new List<EjeDibujoPreview>(ejeDibujo);

            float offsetSuperior = -hBeam / 2f + 5f;
            float offsetInferior = hBeam / 2f - 5f;
            float offsetCentral = 0f;

            if (hayPerfilVariable)
            {
                ejeSuperior = ConstruirEjeAceroVariablePreview(
                    serie,
                    ejeDibujo,
                    centroZPerfil,
                    escalaZPerfil,
                    recubrimientoMm,
                    1);

                ejeInferior = ConstruirEjeAceroVariablePreview(
                    serie,
                    ejeDibujo,
                    centroZPerfil,
                    escalaZPerfil,
                    recubrimientoMm,
                    -1);

                ejeCentral = ConstruirEjeAceroVariablePreview(
                    serie,
                    ejeDibujo,
                    centroZPerfil,
                    escalaZPerfil,
                    0.0,
                    0);

                offsetSuperior = 0f;
                offsetInferior = 0f;
                offsetCentral = 0f;
            }

            // 🔥 CLAVE: extender el eje gráfico hasta xBarraInicioMm / xBarraFinMm.
            // Así la vista preliminar sí muestra la longitud de desarrollo antes
            // del primer tramo y después del último tramo cuando hay apoyo.
            double limiteEjeSuperiorInicio =
                ModoDistribucionLongitudinalActualMYG !=
                    ModoDistribucionLongitudinalMYG.Continuo
                        ? Math.Min(displayMinMm, xBarraInicioMm)
                        : xBarraInicioMm;
            double limiteEjeSuperiorFin =
                ModoDistribucionLongitudinalActualMYG !=
                    ModoDistribucionLongitudinalMYG.Continuo
                        ? Math.Max(displayMaxMm, xBarraFinMm)
                        : xBarraFinMm;

            ExtenderEjeDibujoPreview(
                ejeSuperior,
                limiteEjeSuperiorInicio,
                limiteEjeSuperiorFin,
                mapX);
            ExtenderEjeDibujoPreview(ejeInferior, xBarraInicioMm, xBarraFinMm, mapX);

            if (AceroCentral ||
                ModoDistribucionLongitudinalActualMYG !=
                    ModoDistribucionLongitudinalMYG.Continuo)
            {
                ExtenderEjeDibujoPreview(
                    ejeCentral,
                    Math.Min(displayMinMm, xBarraInicioMm),
                    Math.Max(displayMaxMm, xBarraFinMm),
                    mapX);
            }

            int capasSupPreview = CapasSuperiores;
            int capasInfPreview = CapasInferiores;

            // Escala gráfica controlada por la separación libre ingresada.
            // Se limita para que la vista siga siendo legible.
            float separacionCapasPreviewPx = (float)Math.Max(
                4.0,
                Math.Min(18.0, ObtenerSeparacionCapasMmMYG() / 5.0));

            for (int iCapaSup = 0; iCapaSup < capasSupPreview; iCapaSup++)
            {
                DibujarAceroPreviewConEmpalmes(
                    g,
                    penSuperior,
                    penEmpalme,
                    xBarraInicioMm,
                    xBarraFinMm,
                    ejeSuperior,
                    offsetSuperior + iCapaSup * separacionCapasPreviewPx,
                    longitudBarraMm,
                    longitudEmpalmeSuperiorMm,
                    ganchoInicioMm,
                    serie,
                    1);
            }

            for (int iCapaInf = 0; iCapaInf < capasInfPreview; iCapaInf++)
            {
                DibujarAceroPreviewConEmpalmes(
                    g,
                    penInferior,
                    penEmpalme,
                    xBarraInicioMm,
                    xBarraFinMm,
                    ejeInferior,
                    offsetInferior - iCapaInf * separacionCapasPreviewPx,
                    longitudBarraMm,
                    longitudEmpalmeInferiorMm,
                    ganchoInicioMm,
                    serie,
                    -1);
            }

            if (AceroCentral &&
                ModoDistribucionLongitudinalActualMYG ==
                    ModoDistribucionLongitudinalMYG.Continuo)
            {
                DibujarAceroPreviewConEmpalmes(
                    g,
                    penCentral,
                    penEmpalme,
                    xBarraInicioMm,
                    xBarraFinMm,
                    ejeCentral,
                    offsetCentral,
                    longitudBarraMm,
                    longitudEmpalmeCentralMm,
                    0.0,
                    serie,
                    0);
            }

            if (GanchoInicio)
            {
                int hookPx = ObtenerGanchoPreviewPx(ObtenerLongitudGanchoInicioMm(), rangoMm, anchoDibujo);
                Drawing.PointF pSup = PuntoEnEjePreview(ejeSuperior, xBarraInicioMm, offsetSuperior);
                Drawing.PointF pInf = PuntoEnEjePreview(ejeInferior, xBarraInicioMm, offsetInferior);
                g.DrawLine(penSuperior, pSup.X, pSup.Y, pSup.X, pSup.Y + hookPx);
                g.DrawLine(penInferior, pInf.X, pInf.Y, pInf.X, pInf.Y - hookPx);
            }

            if (GanchoFin)
            {
                int hookPx = ObtenerGanchoPreviewPx(ObtenerLongitudGanchoFinMm(), rangoMm, anchoDibujo);
                Drawing.PointF pSup = PuntoEnEjePreview(ejeSuperior, xBarraFinMm, offsetSuperior);
                Drawing.PointF pInf = PuntoEnEjePreview(ejeInferior, xBarraFinMm, offsetInferior);
                g.DrawLine(penSuperior, pSup.X, pSup.Y, pSup.X, pSup.Y + hookPx);
                g.DrawLine(penInferior, pInf.X, pInf.Y, pInf.X, pInf.Y - hookPx);
            }

            // V11.41 - En los modos por estaciones se dibujan sobre la
            // elevación los recorridos especiales exactos: BASTONES,
            // BALANCINES y las barras CENTRALES activas por tramo/zona.
            if (ModoDistribucionLongitudinalActualMYG !=
                ModoDistribucionLongitudinalMYG.Continuo)
            {
                DibujarAcerosEstacionesEspecialesPreviewMYG(
                    g,
                    serie,
                    ejeSuperior,
                    ejeCentral,
                    offsetSuperior,
                    separacionCapasPreviewPx,
                    offsetCentral,
                    rangoMm,
                    anchoDibujo);
            }
        }

        Dictionary<int, List<Tuple<double, int>>> estribosADibujar =
            previewEstribosExterno;

        // Cuando la vista se dibuja normalmente desde la pestaña Acero Longitudinal,
        // se usa el check "Graficar estribos".
        if ((estribosADibujar == null || estribosADibujar.Count == 0) &&
            chkGraficarEstribosCreados != null &&
            chkGraficarEstribosCreados.Checked)
        {
            estribosADibujar = previewEstribosCreados;
        }

        if (estribosADibujar != null && estribosADibujar.Count > 0)
        {
            DibujarEstribosPreviewExterno(
                g,
                penEstriboPreview,
                serie,
                ejeDibujo,
                estribosADibujar,
                hBeam,
                hayPerfilVariable,
                centroZPerfil,
                escalaZPerfil);
        }

        // =========================================================
        // V11.30 MYG - MARCA DE TIPO DEBAJO DE CADA TRAMO REAL
        // =========================================================
        // Se centra respecto del tramo y usa mapX, por lo que también se
        // espeja correctamente cuando el usuario activa MIRROR.
        using (Drawing.Font fontMarcaTipo = new Drawing.Font(
            "Segoe UI",
            7.5F,
            Drawing.FontStyle.Bold))
        using (Drawing.Brush brushMarcaTipo = new Drawing.SolidBrush(
            Drawing.Color.FromArgb(55, 82, 110)))
        {
            if (serie.TramosViga != null)
            {
                foreach (TramoVigaSeriePreview tramoMarca in
                    serie.TramosViga
                        .Where(t => t != null)
                        .OrderBy(t => t.StartMm))
                {
                    int xMarcaA = mapX(tramoMarca.StartMm);
                    int xMarcaB = mapX(tramoMarca.EndMm);
                    int xMarca0 = Math.Min(xMarcaA, xMarcaB);
                    int xMarca1 = Math.Max(xMarcaA, xMarcaB);

                    if (xMarca1 <= xMarca0)
                        continue;

                    string marca = string.IsNullOrWhiteSpace(tramoMarca.MarcaTipo)
                        ? "Marca: --"
                        : "Marca: " + tramoMarca.MarcaTipo.Trim();

                    Drawing.SizeF tamMarca = g.MeasureString(
                        marca,
                        fontMarcaTipo);

                    float xTextoMarca =
                        (xMarca0 + xMarca1) / 2.0f - tamMarca.Width / 2.0f;

                    float yTextoMarca = yBeam + hBeam + 38.0f;

                    g.DrawString(
                        marca,
                        fontMarcaTipo,
                        brushMarcaTipo,
                        xTextoMarca,
                        yTextoMarca);
                }
            }
        }

        foreach (SegmentoCotaPreview seg in serie.SegmentosCota)
        {
            int xSegA = mapX(seg.StartMm);
            int xSegB = mapX(seg.EndMm);
            int xa = Math.Min(xSegA, xSegB);
            int xb = Math.Max(xSegA, xSegB);

            if (xb <= xa)
                continue;

            g.DrawLine(penDim, xa, yDimSerie, xb, yDimSerie);
            g.DrawLine(penDim, xa, yDimSerie - 4, xa, yDimSerie + 4);
            g.DrawLine(penDim, xb, yDimSerie - 4, xb, yDimSerie + 4);

            string txt = FormatearMetros(seg.LengthMm);
            Drawing.SizeF sz = g.MeasureString(txt, font);

            g.DrawString(
                txt,
                font,
                brushText,
                (xa + xb) / 2 - sz.Width / 2,
                yDimSerie - 18);
        }

        int xTotA = mapX(serie.MinMm);
        int xTotB = mapX(serie.MaxMm);
        int xTot0 = Math.Min(xTotA, xTotB);
        int xTot1 = Math.Max(xTotA, xTotB);

        g.DrawLine(penDim, xTot0, yDimTotal, xTot1, yDimTotal);
        g.DrawLine(penDim, xTot0, yDimTotal - 4, xTot0, yDimTotal + 4);
        g.DrawLine(penDim, xTot1, yDimTotal - 4, xTot1, yDimTotal + 4);

        string txtTotal = FormatearMetros(serie.MaxMm - serie.MinMm);
        Drawing.SizeF szTotal = g.MeasureString(txtTotal, fontBold);

        g.DrawString(
            txtTotal,
            fontBold,
            brushText,
            (xTot0 + xTot1) / 2 - szTotal.Width / 2,
            yDimTotal + 3);

        penBeam.Dispose();
        penSupport.Dispose();
        penSuperior.Dispose();
        penInferior.Dispose();
        penCentral.Dispose();
        penEmpalme.Dispose();
        penEstriboPreview.Dispose();
        penDim.Dispose();
        brushBeam.Dispose();
        brushSupport.Dispose();
        brushText.Dispose();
        font.Dispose();
        fontBold.Dispose();
    }

    // =========================================================
    // V11.7 MYG - INDICADORES INICIAL / FINAL EN ELEVACIÓN
    // =========================================================
    private void DibujarIndicadoresInicialFinalPreviewMYG(
        Drawing.Graphics g,
        Drawing.Rectangle area,
        Func<double, int> mapX,
        double xBarraInicioMm,
        double xBarraFinMm,
        int yBeam,
        int hBeam,
        Drawing.Font fuente,
        Drawing.Brush brochaTexto)
    {
        if (g == null || mapX == null || fuente == null || brochaTexto == null)
            return;

        int xInicio = mapX(xBarraInicioMm);
        int xFin = mapX(xBarraFinMm);

        string textoInicio = "INICIAL";
        string textoFin = "FINAL";

        Drawing.SizeF tamInicio = g.MeasureString(textoInicio, fuente);
        Drawing.SizeF tamFin = g.MeasureString(textoFin, fuente);

        float yTexto = Math.Max(3F, yBeam - 36F);
        float yLineaInicio = yTexto + tamInicio.Height + 1F;
        float yPunta = yBeam - hBeam / 2F - 3F;

        float xTextoInicio = Math.Max(
            area.Left + 3F,
            Math.Min(
                area.Right - tamInicio.Width - 3F,
                xInicio - tamInicio.Width / 2F));

        float xTextoFin = Math.Max(
            area.Left + 3F,
            Math.Min(
                area.Right - tamFin.Width - 3F,
                xFin - tamFin.Width / 2F));

        using (Drawing.Pen penIndicador = new Drawing.Pen(
            Drawing.Color.FromArgb(55, 90, 125),
            1.15F))
        using (Drawing.SolidBrush brochaIndicador = new Drawing.SolidBrush(
            Drawing.Color.FromArgb(55, 90, 125)))
        {
            g.DrawString(
                textoInicio,
                fuente,
                brochaIndicador,
                xTextoInicio,
                yTexto);

            g.DrawString(
                textoFin,
                fuente,
                brochaIndicador,
                xTextoFin,
                yTexto);

            // Líneas guía verticales hacia los extremos del acero.
            g.DrawLine(
                penIndicador,
                xInicio,
                yLineaInicio,
                xInicio,
                yPunta);

            g.DrawLine(
                penIndicador,
                xFin,
                yLineaInicio,
                xFin,
                yPunta);

            // Pequeña punta triangular para que se lea como indicador y no
            // como otra cota de la vista preliminar.
            Drawing.PointF[] flechaInicio = new Drawing.PointF[]
            {
                new Drawing.PointF(xInicio, yPunta + 4F),
                new Drawing.PointF(xInicio - 3.5F, yPunta - 1F),
                new Drawing.PointF(xInicio + 3.5F, yPunta - 1F)
            };

            Drawing.PointF[] flechaFin = new Drawing.PointF[]
            {
                new Drawing.PointF(xFin, yPunta + 4F),
                new Drawing.PointF(xFin - 3.5F, yPunta - 1F),
                new Drawing.PointF(xFin + 3.5F, yPunta - 1F)
            };

            g.FillPolygon(brochaIndicador, flechaInicio);
            g.FillPolygon(brochaIndicador, flechaFin);
        }
    }

    private void DibujarGuiasTerciosEmpalmePreview(
        Drawing.Graphics g,
        SerieContinuaPreview serie,
        List<EjeDibujoPreview> ejeDibujo,
        int hBeam,
        double limiteInicioMm,
        double limiteFinMm)
    {
        if (g == null ||
            serie == null ||
            ejeDibujo == null ||
            ejeDibujo.Count == 0)
        {
            return;
        }

        if (!CrearEmpalmes)
            return;

        List<SegmentoCotaPreview> tramos =
            new List<SegmentoCotaPreview>();

        // =========================================================
        // V11.12 - DOS GUÍAS VERTICALES POR CADA TRAMO REAL
        // =========================================================
        // Se usa PRIMERO TramosViga para que cada tramo mostrado en la
        // cota inferior tenga exactamente sus líneas 1/3 y 2/3.
        // Antes se priorizaban columnas y una serie completa podía terminar
        // tratándose como una sola luz, ocultando la referencia por tramos.
        if (serie.TramosViga != null &&
            serie.TramosViga.Count > 0)
        {
            foreach (TramoVigaSeriePreview tramo in
                serie.TramosViga
                    .Where(t => t != null)
                    .OrderBy(t => t.StartMm))
            {
                double inicio =
                    Math.Min(
                        tramo.StartMm,
                        tramo.EndMm);

                double fin =
                    Math.Max(
                        tramo.StartMm,
                        tramo.EndMm);

                if (fin >
                    inicio + 3.0)
                {
                    tramos.Add(
                        new SegmentoCotaPreview(
                            inicio,
                            fin));
                }
            }
        }

        // Respaldo únicamente cuando no existen tramos de viga disponibles.
        if (tramos.Count == 0 &&
            serie.Columnas != null &&
            serie.Columnas.Count >= 2)
        {
            List<ColumnaCajaPreview> columnas =
                serie.Columnas
                    .Where(c => c != null)
                    .OrderBy(c => c.LeftMm)
                    .ToList();

            for (int i = 0;
                 i < columnas.Count - 1;
                 i++)
            {
                double inicio =
                    columnas[i].RightMm;

                double fin =
                    columnas[i + 1].LeftMm;

                if (fin >
                    inicio + 3.0)
                {
                    tramos.Add(
                        new SegmentoCotaPreview(
                            inicio,
                            fin));
                }
            }
        }

        if (tramos.Count == 0)
            return;

        Drawing.Pen penGuia =
            new Drawing.Pen(
                Drawing.Color.FromArgb(
                    170,
                    95,
                    95,
                    95),
                1.15f);

        penGuia.DashStyle =
            System.Drawing.Drawing2D.DashStyle.Dash;

        penGuia.DashPattern =
            new float[] { 4f, 4f };

        Drawing.Font fuenteTercio =
            new Drawing.Font(
                "Segoe UI",
                7F,
                Drawing.FontStyle.Regular);

        Drawing.Brush brochaTercio =
            new Drawing.SolidBrush(
                Drawing.Color.FromArgb(
                    185,
                    80,
                    80,
                    80));

        try
        {
            foreach (SegmentoCotaPreview tramo in tramos)
            {
                if (tramo == null)
                    continue;

                double inicio =
                    Math.Max(
                        tramo.StartMm,
                        limiteInicioMm);

                double fin =
                    Math.Min(
                        tramo.EndMm,
                        limiteFinMm);

                double longitud =
                    fin - inicio;

                if (longitud <= 3.0)
                    continue;

                double xTercio1 =
                    inicio +
                    longitud / 3.0;

                double xTercio2 =
                    inicio +
                    2.0 * longitud / 3.0;

                DibujarLineaTercioEmpalmePreview(
                    g,
                    penGuia,
                    ejeDibujo,
                    xTercio1,
                    hBeam);

                DibujarLineaTercioEmpalmePreview(
                    g,
                    penGuia,
                    ejeDibujo,
                    xTercio2,
                    hBeam);

                // Etiquetas pequeñas para que sea inequívoco qué representan.
                DibujarEtiquetaTercioEmpalmePreview(
                    g,
                    fuenteTercio,
                    brochaTercio,
                    ejeDibujo,
                    xTercio1,
                    hBeam,
                    "1/3");

                DibujarEtiquetaTercioEmpalmePreview(
                    g,
                    fuenteTercio,
                    brochaTercio,
                    ejeDibujo,
                    xTercio2,
                    hBeam,
                    "2/3");
            }
        }
        finally
        {
            penGuia.Dispose();
            fuenteTercio.Dispose();
            brochaTercio.Dispose();
        }
    }

    private void DibujarEtiquetaTercioEmpalmePreview(
        Drawing.Graphics g,
        Drawing.Font fuente,
        Drawing.Brush brocha,
        List<EjeDibujoPreview> ejeDibujo,
        double xMm,
        int hBeam,
        string texto)
    {
        if (g == null ||
            fuente == null ||
            brocha == null ||
            ejeDibujo == null ||
            ejeDibujo.Count == 0 ||
            string.IsNullOrWhiteSpace(texto))
        {
            return;
        }

        Drawing.PointF p =
            PuntoEnEjePreview(
                ejeDibujo,
                xMm,
                -hBeam / 2f - 18f);

        Drawing.SizeF tam =
            g.MeasureString(
                texto,
                fuente);

        g.DrawString(
            texto,
            fuente,
            brocha,
            p.X - tam.Width / 2f,
            p.Y - tam.Height);
    }

    private void DibujarLineaTercioEmpalmePreview(
        Drawing.Graphics g,
        Drawing.Pen pen,
        List<EjeDibujoPreview> ejeDibujo,
        double xMm,
        int hBeam)
    {
        if (g == null || pen == null || ejeDibujo == null || ejeDibujo.Count == 0)
            return;

        float extensionSuperior = 24f;
        float extensionInferior = 78f;

        Drawing.PointF pArriba = PuntoEnEjePreview(
            ejeDibujo,
            xMm,
            -hBeam / 2f - extensionSuperior);

        Drawing.PointF pAbajo = PuntoEnEjePreview(
            ejeDibujo,
            xMm,
            hBeam / 2f + extensionInferior);

        g.DrawLine(pen, pArriba, pAbajo);
    }

    private void DibujarEstribosPreviewExterno(
        Drawing.Graphics g,
        Drawing.Pen penEstribo,
        SerieContinuaPreview serie,
        List<EjeDibujoPreview> ejeDibujo,
        Dictionary<int, List<Tuple<double, int>>> estribosPorTramo,
        int hBeam,
        bool hayPerfilVariable,
        double centroZPerfil,
        float escalaZPerfil)
    {
        if (g == null || penEstribo == null || serie == null || ejeDibujo == null)
            return;

        if (serie.TramosViga == null || serie.TramosViga.Count == 0)
            return;

        if (estribosPorTramo == null || estribosPorTramo.Count == 0)
            return;

        Drawing.Pen penEstriboResaltado = null;

        try
        {
            penEstriboResaltado = new Drawing.Pen(Drawing.Color.FromArgb(235, 0, 0), 2.2f);

            for (int i = 0; i < serie.TramosViga.Count; i++)
            {
                if (!estribosPorTramo.ContainsKey(i))
                    continue;

                TramoVigaSeriePreview tramo = serie.TramosViga[i];
                List<Tuple<double, int>> posiciones = estribosPorTramo[i];

                if (tramo == null || posiciones == null)
                    continue;

                Drawing.Pen penUsar =
                    (i == previewTramoEstribosResaltado && penEstriboResaltado != null)
                    ? penEstriboResaltado
                    : penEstribo;

                foreach (Tuple<double, int> dato in posiciones)
                {
                    if (dato == null)
                        continue;

                    double xLocalMm = dato.Item1;
                    double xGlobalMm = tramo.StartMm + xLocalMm;

                    if (xGlobalMm < tramo.StartMm - 1.0 || xGlobalMm > tramo.EndMm + 1.0)
                        continue;

                    Drawing.PointF pTop;
                    Drawing.PointF pBot;

                    // CLAVE:
                    // Si el tramo tiene sección variable, el estribo ya no se dibuja
                    // con una altura rectangular fija. Se toma el Z superior/inferior
                    // real interpolado en su propia posición, usando la misma lógica
                    // con la que se dibuja la viga gris.
                    if (hayPerfilVariable && tramo.TienePerfilSeccionVariable)
                    {
                        double zSuperior = ObtenerZTramoVariable(tramo, xGlobalMm, 1);
                        double zInferior = ObtenerZTramoVariable(tramo, xGlobalMm, -1);

                        pTop = PuntoPerfilVariablePreview(
                            ejeDibujo,
                            xGlobalMm,
                            zSuperior,
                            centroZPerfil,
                            escalaZPerfil);

                        pBot = PuntoPerfilVariablePreview(
                            ejeDibujo,
                            xGlobalMm,
                            zInferior,
                            centroZPerfil,
                            escalaZPerfil);

                        // Pequeño retiro visual para que no pise el borde de la viga.
                        pTop = MoverPuntoHaciaOtro(pTop, pBot, 3.0f);
                        pBot = MoverPuntoHaciaOtro(pBot, pTop, 3.0f);
                    }
                    else
                    {
                        pTop = PuntoEnEjePreview(
                            ejeDibujo,
                            xGlobalMm,
                            -hBeam / 2f + 3f);

                        pBot = PuntoEnEjePreview(
                            ejeDibujo,
                            xGlobalMm,
                            hBeam / 2f - 3f);
                    }

                    g.DrawLine(penUsar, pTop, pBot);
                }
            }
        }
        finally
        {
            if (penEstriboResaltado != null)
                penEstriboResaltado.Dispose();
        }
    }

    private Drawing.PointF MoverPuntoHaciaOtro(
        Drawing.PointF desde,
        Drawing.PointF hacia,
        float distancia)
    {
        float dx = hacia.X - desde.X;
        float dy = hacia.Y - desde.Y;
        float len = (float)Math.Sqrt(dx * dx + dy * dy);

        if (len <= 0.0001f)
            return desde;

        return new Drawing.PointF(
            desde.X + dx / len * distancia,
            desde.Y + dy / len * distancia);
    }

    // =====================================
    // LÓGICA:
    // - SIN QUIEBRE
    // - TODAS LAS BARRAS EN LA MISMA LÍNEA
    // - SOLO LA LONGITUD DE EMPALME SE RESALTA EN OTRO COLOR
    // =====================================
    private void DibujarAceroPreviewConEmpalmes(
        Drawing.Graphics g,
        Drawing.Pen penBarra,
        Drawing.Pen penEmpalme,
        double xInicioMm,
        double xFinMm,
        List<EjeDibujoPreview> eje,
        float offsetNormalPx,
        double longitudBarraMm,
        double longitudEmpalmeMm,
        double longitudGanchoInicioMm,
        SerieContinuaPreview serie,
        int tipoRuta)
    {
        if (g == null || penBarra == null || eje == null || eje.Count == 0)
            return;

        if (xFinMm <= xInicioMm + 1.0)
            return;

        if (!CrearEmpalmes ||
            longitudBarraMm <= 0.0 ||
            longitudEmpalmeMm <= 0.0 ||
            longitudBarraMm <= longitudEmpalmeMm + 1.0)
        {
            DibujarIntervaloAceroSobreEje(g, penBarra, eje, xInicioMm, xFinMm, offsetNormalPx);
            return;
        }

        double longitudTotalMm = xFinMm - xInicioMm;
        double primeraLongitudRectaMm = longitudBarraMm - Math.Max(0.0, longitudGanchoInicioMm);

        if (primeraLongitudRectaMm <= longitudEmpalmeMm + 1.0)
            primeraLongitudRectaMm = longitudBarraMm;

        if (longitudTotalMm <= primeraLongitudRectaMm + 1.0)
        {
            DibujarIntervaloAceroSobreEje(g, penBarra, eje, xInicioMm, xFinMm, offsetNormalPx);
            return;
        }

        List<SegmentoCotaPreview> zonasPermitidas = ConstruirZonasPermitidasEmpalmePreview(
            serie,
            tipoRuta,
            xInicioMm,
            xFinMm,
            longitudEmpalmeMm);

        List<SegmentoCotaPreview> segmentosBarra = new List<SegmentoCotaPreview>();
        List<SegmentoCotaPreview> segmentosEmpalme = new List<SegmentoCotaPreview>();

        double xSegInicio = xInicioMm;
        double xSegFin = Math.Min(xInicioMm + primeraLongitudRectaMm, xFinMm);
        int seguridad = 0;
        while (xSegInicio < xFinMm - 1.0 && seguridad < 300)
        {
            seguridad++;

            if (xSegFin >= xFinMm - 1.0)
            {
                if (xFinMm > xSegInicio + 1.0)
                    segmentosBarra.Add(new SegmentoCotaPreview(xSegInicio, xFinMm));

                break;
            }

            SegmentoCotaPreview empalmePermitido = BuscarEmpalmePermitidoPreview(
                zonasPermitidas,
                xSegInicio,
                xSegFin,
                xFinMm,
                longitudEmpalmeMm,
                tipoRuta);

            if (empalmePermitido == null)
            {
                // Si no existe una zona permitida suficiente, no se dibuja el empalme
                // en tercios prohibidos. Se deja el tramo continuo como respaldo visual.
                if (xFinMm > xSegInicio + 1.0)
                    segmentosBarra.Add(new SegmentoCotaPreview(xSegInicio, xFinMm));

                break;
            }
            else
            {
                double empalmeInicio = empalmePermitido.StartMm;
                double empalmeFin = empalmePermitido.EndMm;

                if (empalmeFin > xSegInicio + 1.0)
                    segmentosBarra.Add(new SegmentoCotaPreview(xSegInicio, empalmeFin));

                if (empalmeFin > empalmeInicio + 1.0)
                    segmentosEmpalme.Add(new SegmentoCotaPreview(empalmeInicio, empalmeFin));

                xSegInicio = empalmeInicio;
                xSegFin = Math.Min(xSegInicio + longitudBarraMm, xFinMm);
            }

            if (xSegFin <= xSegInicio + 1.0)
                break;
        }

        foreach (SegmentoCotaPreview seg in segmentosBarra)
            DibujarIntervaloAceroSobreEje(g, penBarra, eje, seg.StartMm, seg.EndMm, offsetNormalPx);

        foreach (SegmentoCotaPreview segEmp in segmentosEmpalme)
            DibujarIntervaloAceroSobreEje(g, penEmpalme, eje, segEmp.StartMm, segEmp.EndMm, offsetNormalPx);
    }

    private List<SegmentoCotaPreview> ConstruirZonasPermitidasEmpalmePreview(
        SerieContinuaPreview serie,
        int tipoRuta,
        double xInicioMm,
        double xFinMm,
        double longitudEmpalmeMm)
    {
        List<SegmentoCotaPreview> zonas =
            new List<SegmentoCotaPreview>();

        if (xFinMm <=
            xInicioMm + 1.0)
        {
            return zonas;
        }

        // V11.12:
        // igual que en la ejecución, los tercios se calculan POR TRAMO,
        // no por la envolvente completa de la serie.
        if (serie != null &&
            serie.TramosViga != null &&
            serie.TramosViga.Count > 0)
        {
            foreach (TramoVigaSeriePreview tramo in
                serie.TramosViga
                    .Where(t => t != null)
                    .OrderBy(t => t.StartMm))
            {
                double tramoInicio =
                    Math.Min(
                        tramo.StartMm,
                        tramo.EndMm);

                double tramoFin =
                    Math.Max(
                        tramo.StartMm,
                        tramo.EndMm);

                AgregarZonasPermitidasPorTercioPreview(
                    zonas,
                    tramoInicio,
                    tramoFin,
                    tipoRuta,
                    xInicioMm,
                    xFinMm);
            }
        }

        // Respaldo por luces entre columnas.
        if (zonas.Count == 0 &&
            serie != null &&
            serie.Columnas != null &&
            serie.Columnas.Count >= 2)
        {
            List<ColumnaCajaPreview> columnas =
                serie.Columnas
                    .Where(c => c != null)
                    .OrderBy(c => c.LeftMm)
                    .ToList();

            for (int i = 0;
                 i < columnas.Count - 1;
                 i++)
            {
                double luzInicio =
                    columnas[i].RightMm;

                double luzFin =
                    columnas[i + 1].LeftMm;

                AgregarZonasPermitidasPorTercioPreview(
                    zonas,
                    luzInicio,
                    luzFin,
                    tipoRuta,
                    xInicioMm,
                    xFinMm);
            }
        }

        if (zonas.Count == 0)
        {
            AgregarZonasPermitidasPorTercioPreview(
                zonas,
                xInicioMm,
                xFinMm,
                tipoRuta,
                xInicioMm,
                xFinMm);
        }

        return zonas
            .Where(z =>
                z != null &&
                z.EndMm >
                z.StartMm + 1.0)
            .OrderBy(z => z.StartMm)
            .ToList();
    }

    private void AgregarZonasPermitidasPorTercioPreview(
        List<SegmentoCotaPreview> zonas,
        double luzInicio,
        double luzFin,
        int tipoRuta,
        double limiteInicio,
        double limiteFin)
    {
        if (zonas == null)
            return;

        double longitudLuz = luzFin - luzInicio;

        if (longitudLuz <= 3.0)
            return;

        double tercio1Fin = luzInicio + longitudLuz / 3.0;
        double tercio2Inicio = tercio1Fin;
        double tercio2Fin = luzInicio + 2.0 * longitudLuz / 3.0;
        double tercio3Inicio = tercio2Fin;

        if (tipoRuta >= 0)
        {
            // SUPERIOR (+1) y CENTRAL (0): empalme en el tercio central.
            AgregarZonaPermitidaPreview(zonas, tercio2Inicio, tercio2Fin, limiteInicio, limiteFin);
        }
        else
        {
            // INFERIOR (-1): empalme en los dos tercios extremos.
            AgregarZonaPermitidaPreview(zonas, luzInicio, tercio1Fin, limiteInicio, limiteFin);
            AgregarZonaPermitidaPreview(zonas, tercio3Inicio, luzFin, limiteInicio, limiteFin);
        }
    }

    private void AgregarZonaPermitidaPreview(
        List<SegmentoCotaPreview> zonas,
        double inicio,
        double fin,
        double limiteInicio,
        double limiteFin)
    {
        double a = Math.Max(inicio, limiteInicio);
        double b = Math.Min(fin, limiteFin);

        if (b > a + 1.0)
            zonas.Add(new SegmentoCotaPreview(a, b));
    }

    private SegmentoCotaPreview BuscarEmpalmePermitidoPreview(
        List<SegmentoCotaPreview> zonasPermitidas,
        double xSegInicio,
        double xSegFinDeseado,
        double xFinTotal,
        double longitudEmpalmeMm,
        int tipoRuta)
    {
        if (zonasPermitidas == null ||
            zonasPermitidas.Count == 0 ||
            longitudEmpalmeMm <= 1.0)
        {
            return null;
        }

        double inicioMinimo =
            xSegInicio + 1.0;

        double inicioDeseado =
            xSegFinDeseado -
            longitudEmpalmeMm;

        double inicioMaximoPorBarra =
            xSegFinDeseado -
            longitudEmpalmeMm;

        double inicioMaximoPorTotal =
            xFinTotal -
            longitudEmpalmeMm;

        SegmentoCotaPreview mejor = null;
        double mejorDistancia = double.MaxValue;

        foreach (SegmentoCotaPreview zona in zonasPermitidas)
        {
            if (zona == null)
                continue;

            // V11.12:
            // el INICIO del empalme debe estar dentro del tercio permitido.
            // El traslape puede continuar fuera de ese tercio, siempre que no
            // salga del recorrido total. Esto replica la lógica de ejecución.
            double zonaInicio =
                Math.Max(
                    zona.StartMm,
                    inicioMinimo);

            // V11.43 - MISMA REGLA RÍGIDA QUE LA EJECUCIÓN.
            // En acero inferior todo el traslape debe permanecer dentro del
            // tercio extremo. Si por longitud comercial el empalme caería en
            // el tercio central, el preview lo adelanta al tercio permitido
            // anterior en vez de dibujarlo en una zona prohibida.
            double limiteZonaPorRegla = zona.EndMm;

            if (tipoRuta < 0)
                limiteZonaPorRegla = zona.EndMm - longitudEmpalmeMm;

            double zonaFinParaInicio =
                Math.Min(
                    limiteZonaPorRegla,
                    Math.Min(
                        inicioMaximoPorBarra,
                        inicioMaximoPorTotal));

            if (zonaFinParaInicio <
                zonaInicio - 1.0)
            {
                continue;
            }

            double inicioCandidato =
                Math.Max(
                    zonaInicio,
                    Math.Min(
                        inicioDeseado,
                        zonaFinParaInicio));

            // En inferiores la zona central es una exclusión absoluta para
            // el empalme completo, no solamente para su punto inicial.
            if (tipoRuta < 0 &&
                inicioCandidato + longitudEmpalmeMm > zona.EndMm + 1.0)
            {
                continue;
            }

            double distancia =
                Math.Abs(
                    inicioCandidato -
                    inicioDeseado);

            if (distancia <
                mejorDistancia)
            {
                mejorDistancia =
                    distancia;

                mejor =
                    new SegmentoCotaPreview(
                        inicioCandidato,
                        inicioCandidato +
                        longitudEmpalmeMm);
            }
        }

        return mejor;
    }

    private double ObtenerRecubrimientoMm()
    {
        return LeerCmComoMm(txtRecubrimiento);
    }

    private double ObtenerLongitudEmpalmeMm()
    {
        return ObtenerLongitudEmpalmeInferiorMm();
    }

    private double ObtenerLongitudEmpalmeSuperiorMm()
    {
        if (!CrearEmpalmes)
            return 0.0;

        if (UsarRNE)
            return empalmeRNESuperiorCm * 10.0;

        return LeerCmComoMm(txtLongitudEmpalme);
    }

    private double ObtenerLongitudEmpalmeInferiorMm()
    {
        if (!CrearEmpalmes)
            return 0.0;

        if (UsarRNE)
            return empalmeRNEInferiorCm * 10.0;

        return LeerCmComoMm(txtLongitudEmpalme);
    }

    private double ObtenerLongitudEmpalmeCentralMm()
    {
        if (!CrearEmpalmes)
            return 0.0;

        if (UsarRNE)
            return empalmeRNECentralCm * 10.0;

        return LeerCmComoMm(txtLongitudEmpalme);
    }

    private double ObtenerLongitudBarraMm()
    {
        if (!CrearEmpalmes)
            return 0.0;

        return LeerMComoMm(txtLongitudBarra);
    }

    private double ObtenerLongitudDesarrolloInicioMm()
    {
        if (!LongitudDesarrolloInicioHabilitada)
            return 0.0;

        if (DesarrolloAutomaticoInicio)
            return CalcularDesarrolloAutomaticoInicioCm() * 10.0;

        return LeerCmComoMm(txtLongitudDesarrolloInicio);
    }

    private double ObtenerLongitudDesarrolloFinMm()
    {
        if (!LongitudDesarrolloFinHabilitada)
            return 0.0;

        if (DesarrolloAutomaticoFin)
            return CalcularDesarrolloAutomaticoFinCm() * 10.0;

        return LeerCmComoMm(txtLongitudDesarrolloFin);
    }

    private double ObtenerLongitudGanchoInicioMm()
    {
        if (!GanchoInicio)
            return 0.0;

        return LeerCmComoMm(txtLongitudGanchoInicio);
    }

    private double ObtenerLongitudGanchoFinMm()
    {
        if (!GanchoFin)
            return 0.0;

        return LeerCmComoMm(txtLongitudGanchoFin);
    }

    private double LeerCmComoMm(WinForms.TextBox txt)
    {
        if (txt == null)
            return 0.0;

        string texto = (txt.Text ?? "").Trim().Replace(",", ".");

        if (double.TryParse(
            texto,
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture,
            out double valorCm))
        {
            if (valorCm < 0)
                valorCm = 0.0;

            return valorCm * 10.0;
        }

        return 0.0;
    }

    private double LeerMComoMm(WinForms.TextBox txt)
    {
        if (txt == null)
            return 0.0;

        string texto = (txt.Text ?? "").Trim().Replace(",", ".");

        if (double.TryParse(
            texto,
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture,
            out double valorM))
        {
            if (valorM < 0)
                valorM = 0.0;

            return valorM * 1000.0;
        }

        return 0.0;
    }

    private bool TextoNumeroMayorCero(string texto)
    {
        if (string.IsNullOrWhiteSpace(texto))
            return false;

        string t = texto.Trim().Replace(",", ".");

        if (!double.TryParse(
            t,
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture,
            out double valor))
        {
            return false;
        }

        return valor > 0.0;
    }

    private int ObtenerGanchoPreviewPx(
        double longitudGanchoMm,
        double rangoMm,
        int anchoDibujo)
    {
        if (longitudGanchoMm <= 0.0 || rangoMm <= 0.0 || anchoDibujo <= 0)
            return 10;

        int px = (int)((longitudGanchoMm / rangoMm) * anchoDibujo);

        if (px < 10)
            px = 10;

        if (px > 22)
            px = 22;

        return px;
    }

    private string FormatearMetros(double mm)
    {
        double metros = mm / 1000.0;

        return metros.ToString(
            "0.00",
            System.Globalization.CultureInfo.InvariantCulture) + " m";
    }

    private int LeerEntero(string texto, int defecto)
    {
        if (int.TryParse(texto, out int valor))
            return Math.Max(1, valor);

        return defecto;
    }

    public ModeloAceroLongitudinalPreview ObtenerModeloPreviewActual()
    {
        ModeloPreviewActual = ConstruirModeloPreviewSeguro();
        return ModeloPreviewActual;
    }

    private ModeloAceroLongitudinalPreview ConstruirModeloPreviewSeguro()
    {
        ModeloAceroLongitudinalPreview modelo = new ModeloAceroLongitudinalPreview();

        SerieContinuaPreview serie = ConstruirSerieContinua(previewVigas);

        if (serie == null || serie.TramosViga == null || serie.TramosViga.Count == 0)
            return modelo;

        double startGlobal = serie.TramosViga.Min(x => x.StartMm);
        double endGlobal = serie.TramosViga.Max(x => x.EndMm);

        double desarrolloInicioMm = ObtenerLongitudDesarrolloInicioMm();
        double desarrolloFinMm = ObtenerLongitudDesarrolloFinMm();
        double recubrimientoMm = ObtenerRecubrimientoMm();

        double xBarraInicioMm;
        double xBarraFinMm;

        if (serie.TieneColumnaInicioSerie && LongitudDesarrolloInicioHabilitada)
            xBarraInicioMm = startGlobal - desarrolloInicioMm;
        else
            xBarraInicioMm = startGlobal + recubrimientoMm;

        if (serie.TieneColumnaFinSerie && LongitudDesarrolloFinHabilitada)
            xBarraFinMm = endGlobal + desarrolloFinMm;
        else
            xBarraFinMm = endGlobal - recubrimientoMm;

        if (xBarraFinMm <= xBarraInicioMm + 1.0)
            return modelo;

        modelo.Valido = true;
        modelo.StartGlobalMm = Math.Min(serie.MinMm, xBarraInicioMm);
        modelo.EndGlobalMm = Math.Max(serie.MaxMm, xBarraFinMm);
        modelo.XBarraInicioMm = xBarraInicioMm;
        modelo.XBarraFinMm = xBarraFinMm;
        modelo.RecubrimientoMm = recubrimientoMm;
        modelo.CrearEmpalmes = CrearEmpalmes;
        modelo.LongitudBarraMm = ObtenerLongitudBarraMm();
        modelo.LongitudEmpalmeSuperiorMm = ObtenerLongitudEmpalmeSuperiorMm();
        modelo.LongitudEmpalmeInferiorMm = ObtenerLongitudEmpalmeInferiorMm();
        modelo.LongitudEmpalmeCentralMm = ObtenerLongitudEmpalmeCentralMm();
        modelo.GanchoInicio = GanchoInicio;
        modelo.GanchoFin = GanchoFin;
        modelo.LongitudGanchoInicioMm = ObtenerLongitudGanchoInicioMm();
        modelo.LongitudGanchoFinMm = ObtenerLongitudGanchoFinMm();
        modelo.TienePerfilVariable = serie.TramosViga.Any(t => t != null && t.TienePerfilSeccionVariable);

        double separacionCapasPreviewMm =
            ObtenerSeparacionCapasMmMYG();

        for (int iCapaSup = 0; iCapaSup < CapasSuperiores; iCapaSup++)
        {
            modelo.Rutas.Add(ConstruirRutaPreviewSeguro(
                serie,
                "Superior Capa " + (iCapaSup + 1).ToString(),
                1,
                xBarraInicioMm,
                xBarraFinMm,
                modelo.LongitudBarraMm,
                modelo.LongitudEmpalmeSuperiorMm,
                GanchoInicio ? modelo.LongitudGanchoInicioMm : 0.0,
                recubrimientoMm + iCapaSup * separacionCapasPreviewMm,
                -1.0));
        }

        for (int iCapaInf = 0; iCapaInf < CapasInferiores; iCapaInf++)
        {
            modelo.Rutas.Add(ConstruirRutaPreviewSeguro(
                serie,
                "Inferior Capa " + (iCapaInf + 1).ToString(),
                -1,
                xBarraInicioMm,
                xBarraFinMm,
                modelo.LongitudBarraMm,
                modelo.LongitudEmpalmeInferiorMm,
                GanchoInicio ? modelo.LongitudGanchoInicioMm : 0.0,
                recubrimientoMm + iCapaInf * separacionCapasPreviewMm,
                1.0));
        }

        if (AceroCentral)
        {
            modelo.Rutas.Add(ConstruirRutaPreviewSeguro(
                serie,
                "Central",
                0,
                xBarraInicioMm,
                xBarraFinMm,
                modelo.LongitudBarraMm,
                modelo.LongitudEmpalmeCentralMm,
                0.0,
                0.0,
                0.0));
        }

        return modelo;
    }

    private RutaAceroLongitudinalPreview ConstruirRutaPreviewSeguro(
        SerieContinuaPreview serie,
        string grupo,
        int tipoRuta,
        double xInicioMm,
        double xFinMm,
        double longitudBarraMm,
        double longitudEmpalmeMm,
        double longitudGanchoInicioMm,
        double recubrimientoMm,
        double zSigno)
    {
        RutaAceroLongitudinalPreview ruta = new RutaAceroLongitudinalPreview();
        ruta.Grupo = grupo;
        ruta.TipoRuta = tipoRuta;
        ruta.Activa = true;
        ruta.RecubrimientoMm = recubrimientoMm;
        ruta.OffsetNormalPreviewPx = 0.0;

        if (xFinMm <= xInicioMm + 1.0)
            return ruta;

        if (!CrearEmpalmes || longitudBarraMm <= 0.0 || longitudEmpalmeMm <= 0.0 || longitudBarraMm <= longitudEmpalmeMm + 1.0)
        {
            ruta.Segmentos.Add(CrearSegmentoRutaPreviewSeguro(
                xInicioMm,
                xFinMm,
                false,
                zSigno * recubrimientoMm));

            return ruta;
        }

        double longitudTotalMm = xFinMm - xInicioMm;
        double primeraLongitudRectaMm = longitudBarraMm - Math.Max(0.0, longitudGanchoInicioMm);

        if (primeraLongitudRectaMm <= longitudEmpalmeMm + 1.0)
            primeraLongitudRectaMm = longitudBarraMm;

        if (longitudTotalMm <= primeraLongitudRectaMm + 1.0)
        {
            ruta.Segmentos.Add(CrearSegmentoRutaPreviewSeguro(
                xInicioMm,
                xFinMm,
                false,
                zSigno * recubrimientoMm));

            return ruta;
        }

        List<SegmentoCotaPreview> zonasPermitidas = ConstruirZonasPermitidasEmpalmePreview(
            serie,
            tipoRuta,
            xInicioMm,
            xFinMm,
            longitudEmpalmeMm);

        double xSegInicio = xInicioMm;
        double xSegFin = Math.Min(xInicioMm + primeraLongitudRectaMm, xFinMm);
        int seguridad = 0;

        while (xSegInicio < xFinMm - 1.0 && seguridad < 300)
        {
            seguridad++;

            if (xSegFin >= xFinMm - 1.0)
            {
                ruta.Segmentos.Add(CrearSegmentoRutaPreviewSeguro(
                    xSegInicio,
                    xFinMm,
                    false,
                    zSigno * recubrimientoMm));

                break;
            }

            SegmentoCotaPreview empalmePermitido = BuscarEmpalmePermitidoPreview(
                zonasPermitidas,
                xSegInicio,
                xSegFin,
                xFinMm,
                longitudEmpalmeMm,
                tipoRuta);

            if (empalmePermitido == null)
            {
                // Si no existe una zona permitida suficiente, no se agrega empalme
                // en los tercios prohibidos.
                ruta.Segmentos.Add(CrearSegmentoRutaPreviewSeguro(
                    xSegInicio,
                    xFinMm,
                    false,
                    zSigno * recubrimientoMm));

                break;
            }
            else
            {
                double empalmeInicio = empalmePermitido.StartMm;
                double empalmeFin = empalmePermitido.EndMm;

                if (empalmeFin > xSegInicio + 1.0)
                {
                    ruta.Segmentos.Add(CrearSegmentoRutaPreviewSeguro(
                        xSegInicio,
                        empalmeFin,
                        false,
                        zSigno * recubrimientoMm));
                }

                if (empalmeFin > empalmeInicio + 1.0)
                {
                    ruta.Segmentos.Add(CrearSegmentoRutaPreviewSeguro(
                        empalmeInicio,
                        empalmeFin,
                        true,
                        zSigno * recubrimientoMm));
                }

                xSegInicio = empalmeInicio;
                xSegFin = Math.Min(xSegInicio + longitudBarraMm, xFinMm);
            }

            if (xSegFin <= xSegInicio + 1.0)
                break;
        }

        return ruta;
    }

    private SegmentoRutaAceroPreview CrearSegmentoRutaPreviewSeguro(
        double xInicioMm,
        double xFinMm,
        bool esEmpalme,
        double zMm)
    {
        SegmentoRutaAceroPreview seg = new SegmentoRutaAceroPreview();
        seg.StartMm = xInicioMm;
        seg.EndMm = xFinMm;
        seg.EsEmpalme = esEmpalme;
        seg.UsaPerfilVariable = false;
        seg.Puntos.Add(new PuntoRutaAceroPreview(xInicioMm, zMm));
        seg.Puntos.Add(new PuntoRutaAceroPreview(xFinMm, zMm));
        return seg;
    }

    private class VistaPreviaPanel : WinForms.Panel
    {
        public VistaPreviaPanel()
        {
            this.DoubleBuffered = true;
            this.ResizeRedraw = true;
            this.TabStop = true;

            this.SetStyle(
                WinForms.ControlStyles.AllPaintingInWmPaint |
                WinForms.ControlStyles.OptimizedDoubleBuffer |
                WinForms.ControlStyles.ResizeRedraw |
                WinForms.ControlStyles.UserPaint,
                true);
        }
    }

    private void InitializeComponent()
    {
        this.SuspendLayout();
        // 
        // AceroLongitudinalVigasForm
        // 
        this.ClientSize = new System.Drawing.Size(282, 253);
        this.Name = "AceroLongitudinalVigasForm";
        this.Load += new System.EventHandler(this.AceroLongitudinalVigasForm_Load);
        this.ResumeLayout(false);

    }

    private void AceroLongitudinalVigasForm_Load(object sender, EventArgs e)
    {

    }
}

// =====================================
// VENTANA AUXILIAR - DATOS RNE PARA EMPALMES
// =====================================
public class RNEEmpalmesConfigForm : WinForms.Form
{
    public double FcKgCm2 { get; set; }
    public double FyMpa { get; set; }
    public double PsiE { get; set; }
    public double Lambda { get; set; }
    public double FactorEmpalme { get; set; }
    public double MinEmpalmeMm { get; set; }
    public double PsiSuperior { get; set; }
    public double PsiInferior { get; set; }
    public double PsiCentral { get; set; }

    public string NombreSuperior { get; set; }
    public string NombreInferior { get; set; }
    public string NombreCentral { get; set; }

    public double DbSuperiorMm { get; set; }
    public double DbInferiorMm { get; set; }
    public double DbCentralMm { get; set; }
    public bool MostrarCentral { get; set; }

    private WinForms.ComboBox cmbFc;
    private WinForms.TextBox txtFy;
    private WinForms.TextBox txtPsiE;
    private WinForms.TextBox txtLambda;
    private WinForms.TextBox txtFactorEmpalme;
    private WinForms.TextBox txtMinEmpalme;

    private WinForms.TextBox txtPsiSuperior;
    private WinForms.TextBox txtPsiInferior;
    private WinForms.TextBox txtPsiCentral;

    private WinForms.Label lblBarraSuperior;
    private WinForms.Label lblBarraInferior;
    private WinForms.Label lblBarraCentral;

    private WinForms.Label lblResultadoSuperior;
    private WinForms.Label lblResultadoInferior;
    private WinForms.Label lblResultadoCentral;

    private WinForms.Button btnAceptar;
    private WinForms.Button btnCancelar;

    public RNEEmpalmesConfigForm()
    {
        FcKgCm2 = 210.0;
        FyMpa = 420.0;
        PsiE = 1.0;
        Lambda = 1.0;
        FactorEmpalme = 1.30;
        MinEmpalmeMm = 300.0;
        PsiSuperior = 1.30;
        PsiInferior = 1.00;
        PsiCentral = 1.00;

        NombreSuperior = "--";
        NombreInferior = "--";
        NombreCentral = "--";

        this.Text = "MYG - Datos RNE para empalmes";
        this.Width = 610;
        this.Height = 490;
        this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.ShowInTaskbar = false;
        this.TopMost = true;
        this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
        this.Font = new Drawing.Font("Segoe UI", 9F);

        WinForms.Label lblTitulo = new WinForms.Label()
        {
            Text = "Cálculo de longitud de empalme por RNE E.060",
            Left = 18,
            Top = 14,
            Width = 540,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 10F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.FromArgb(40, 40, 40)
        };

        WinForms.GroupBox grpDatos = new WinForms.GroupBox()
        {
            Text = "Datos generales",
            Left = 18,
            Top = 45,
            Width = 560,
            Height = 135,
            Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold)
        };

        cmbFc = CrearComboFc(120, 28);
        txtFy = CrearTextBox("420", 360, 28, 60);
        txtPsiE = CrearTextBox("1.00", 120, 65, 60);
        txtLambda = CrearTextBox("1.00", 360, 65, 60);
        txtFactorEmpalme = CrearTextBox("1.30", 120, 100, 60);
        txtMinEmpalme = CrearTextBox("300", 360, 100, 60);

        grpDatos.Controls.Add(CrearLabel("f'c:", 18, 31, 95));
        grpDatos.Controls.Add(cmbFc);
        grpDatos.Controls.Add(CrearLabel("fy (MPa):", 270, 31, 85));
        grpDatos.Controls.Add(txtFy);
        grpDatos.Controls.Add(CrearLabel("ψe:", 18, 68, 95));
        grpDatos.Controls.Add(txtPsiE);
        grpDatos.Controls.Add(CrearLabel("λ:", 270, 68, 85));
        grpDatos.Controls.Add(txtLambda);
        grpDatos.Controls.Add(CrearLabel("Factor empalme:", 18, 103, 100));
        grpDatos.Controls.Add(txtFactorEmpalme);
        grpDatos.Controls.Add(CrearLabel("Mín. emp. (mm):", 270, 103, 100));
        grpDatos.Controls.Add(txtMinEmpalme);

        WinForms.GroupBox grpBarras = new WinForms.GroupBox()
        {
            Text = "Barras y factores",
            Left = 18,
            Top = 190,
            Width = 560,
            Height = 175,
            Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold)
        };

        grpBarras.Controls.Add(CrearLabel("Acero", 18, 28, 190));
        grpBarras.Controls.Add(CrearLabel("  ", 230, 28, 70));
        grpBarras.Controls.Add(CrearLabel("ψt", 315, 28, 50));
        grpBarras.Controls.Add(CrearLabel("ld", 385, 28, 70));
        grpBarras.Controls.Add(CrearLabel("Empalme", 465, 28, 80));

        lblBarraSuperior = CrearLabel("Superior", 18, 58, 200);
        lblBarraInferior = CrearLabel("Inferior", 18, 90, 200);
        lblBarraCentral = CrearLabel("Central", 18, 122, 200);

        txtPsiSuperior = CrearTextBox("1.30", 315, 55, 45);
        txtPsiInferior = CrearTextBox("1.00", 315, 87, 45);
        txtPsiCentral = CrearTextBox("1.00", 315, 119, 45);

        lblResultadoSuperior = CrearLabel("--", 385, 58, 155);
        lblResultadoInferior = CrearLabel("--", 385, 90, 155);
        lblResultadoCentral = CrearLabel("--", 385, 122, 155);

        grpBarras.Controls.Add(lblBarraSuperior);
        grpBarras.Controls.Add(lblBarraInferior);
        grpBarras.Controls.Add(lblBarraCentral);
        grpBarras.Controls.Add(txtPsiSuperior);
        grpBarras.Controls.Add(txtPsiInferior);
        grpBarras.Controls.Add(txtPsiCentral);
        grpBarras.Controls.Add(lblResultadoSuperior);
        grpBarras.Controls.Add(lblResultadoInferior);
        grpBarras.Controls.Add(lblResultadoCentral);

        WinForms.Label lblNota = new WinForms.Label()
        {
            Text = "Nota: Para condiciones normales se usa ψe = 1.00, λ = 1.00 y empalme Clase B = 1.30 ld. El resultado se redondea hacia arriba en cm.",
            Left = 18,
            Top = 372,
            Width = 560,
            Height = 34,
            ForeColor = Drawing.Color.FromArgb(90, 90, 90),
            Font = new Drawing.Font("Segoe UI", 8F)
        };

        btnAceptar = new WinForms.Button()
        {
            Text = "APLICAR",
            Left = 365,
            Top = 410,
            Width = 100,
            Height = 30,
            BackColor = Drawing.Color.FromArgb(0, 120, 215),
            ForeColor = Drawing.Color.White,
            FlatStyle = WinForms.FlatStyle.Flat,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold)
        };
        btnAceptar.FlatAppearance.BorderSize = 0;

        btnCancelar = new WinForms.Button()
        {
            Text = "CANCELAR",
            Left = 475,
            Top = 410,
            Width = 100,
            Height = 30,
            BackColor = Drawing.Color.FromArgb(100, 100, 100),
            ForeColor = Drawing.Color.White,
            FlatStyle = WinForms.FlatStyle.Flat,
            Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold)
        };
        btnCancelar.FlatAppearance.BorderSize = 0;

        btnAceptar.Click += (s, e) =>
        {
            if (!LeerDatos())
                return;

            this.DialogResult = WinForms.DialogResult.OK;
            this.Close();
        };

        btnCancelar.Click += (s, e) =>
        {
            this.DialogResult = WinForms.DialogResult.Cancel;
            this.Close();
        };

        cmbFc.SelectedIndexChanged += (s, e) => ActualizarResultados();
        txtFy.TextChanged += (s, e) => ActualizarResultados();
        txtPsiE.TextChanged += (s, e) => ActualizarResultados();
        txtLambda.TextChanged += (s, e) => ActualizarResultados();
        txtFactorEmpalme.TextChanged += (s, e) => ActualizarResultados();
        txtMinEmpalme.TextChanged += (s, e) => ActualizarResultados();
        txtPsiSuperior.TextChanged += (s, e) => ActualizarResultados();
        txtPsiInferior.TextChanged += (s, e) => ActualizarResultados();
        txtPsiCentral.TextChanged += (s, e) => ActualizarResultados();

        this.Controls.Add(lblTitulo);
        this.Controls.Add(grpDatos);
        this.Controls.Add(grpBarras);
        this.Controls.Add(lblNota);
        this.Controls.Add(btnAceptar);
        this.Controls.Add(btnCancelar);

        this.AcceptButton = btnAceptar;
        this.CancelButton = btnCancelar;

        this.Load += (s, e) => CargarValoresIniciales();
    }

    private void CargarValoresIniciales()
    {
        SeleccionarFc(FcKgCm2);

        txtFy.Text = FyMpa.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture);
        txtPsiE.Text = PsiE.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture);
        txtLambda.Text = Lambda.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture);
        txtFactorEmpalme.Text = FactorEmpalme.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture);
        txtMinEmpalme.Text = MinEmpalmeMm.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture);

        txtPsiSuperior.Text = PsiSuperior.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture);
        txtPsiInferior.Text = PsiInferior.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture);
        txtPsiCentral.Text = PsiCentral.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture);

        lblBarraSuperior.Text = "Superior: " + (string.IsNullOrWhiteSpace(NombreSuperior) ? "--" : NombreSuperior) + "   db " + FormatearMm(DbSuperiorMm);
        lblBarraInferior.Text = "Inferior: " + (string.IsNullOrWhiteSpace(NombreInferior) ? "--" : NombreInferior) + "   db " + FormatearMm(DbInferiorMm);
        lblBarraCentral.Text = "Central: " + (string.IsNullOrWhiteSpace(NombreCentral) ? "--" : NombreCentral) + "   db " + FormatearMm(DbCentralMm);

        lblBarraCentral.Enabled = MostrarCentral;
        txtPsiCentral.Enabled = MostrarCentral;
        lblResultadoCentral.Enabled = MostrarCentral;

        ActualizarResultados();
    }

    private WinForms.ComboBox CrearComboFc(int left, int top)
    {
        WinForms.ComboBox cmb = new WinForms.ComboBox()
        {
            Left = left,
            Top = top,
            Width = 120,
            Height = 24,
            DropDownStyle = WinForms.ComboBoxStyle.DropDownList
        };

        cmb.Items.Add("175 kg/cm2");
        cmb.Items.Add("210 kg/cm2");
        cmb.Items.Add("280 kg/cm2");
        cmb.Items.Add("350 kg/cm2");
        cmb.SelectedIndex = 1;

        return cmb;
    }

    private WinForms.Label CrearLabel(string texto, int left, int top, int width)
    {
        return new WinForms.Label()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 22,
            Font = new Drawing.Font("Segoe UI", 8.3F, Drawing.FontStyle.Bold),
            ForeColor = Drawing.Color.FromArgb(50, 50, 50)
        };
    }

    private WinForms.TextBox CrearTextBox(string texto, int left, int top, int width)
    {
        return new WinForms.TextBox()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 24,
            BorderStyle = WinForms.BorderStyle.FixedSingle
        };
    }

    private void SeleccionarFc(double fc)
    {
        if (cmbFc == null)
            return;

        string valor = fc.ToString("0", System.Globalization.CultureInfo.InvariantCulture) + " kg/cm2";
        int index = cmbFc.Items.IndexOf(valor);

        if (index >= 0)
            cmbFc.SelectedIndex = index;
    }

    private bool LeerDatos()
    {
        FcKgCm2 = LeerFcSeleccionado();

        if (!LeerDouble(txtFy, out double fy) || fy <= 0)
        {
            MostrarError("El valor de fy no es válido.");
            return false;
        }

        if (!LeerDouble(txtPsiE, out double psiE) || psiE <= 0)
        {
            MostrarError("El valor de ψe no es válido.");
            return false;
        }

        if (!LeerDouble(txtLambda, out double lambda) || lambda <= 0)
        {
            MostrarError("El valor de λ no es válido.");
            return false;
        }

        if (!LeerDouble(txtFactorEmpalme, out double factor) || factor <= 0)
        {
            MostrarError("El factor de empalme no es válido.");
            return false;
        }

        if (!LeerDouble(txtMinEmpalme, out double minimo) || minimo < 0)
        {
            MostrarError("El empalme mínimo no es válido.");
            return false;
        }

        if (!LeerDouble(txtPsiSuperior, out double psiSup) || psiSup <= 0)
        {
            MostrarError("El valor de ψt superior no es válido.");
            return false;
        }

        if (!LeerDouble(txtPsiInferior, out double psiInf) || psiInf <= 0)
        {
            MostrarError("El valor de ψt inferior no es válido.");
            return false;
        }

        if (!LeerDouble(txtPsiCentral, out double psiCen) || psiCen <= 0)
        {
            MostrarError("El valor de ψt central no es válido.");
            return false;
        }

        FyMpa = fy;
        PsiE = psiE;
        Lambda = lambda;
        FactorEmpalme = factor;
        MinEmpalmeMm = minimo;
        PsiSuperior = psiSup;
        PsiInferior = psiInf;
        PsiCentral = psiCen;

        return true;
    }

    private void ActualizarResultados()
    {
        double fc = LeerFcSeleccionado();
        double fy = LeerDoubleSeguro(txtFy, 420.0);
        double psiE = LeerDoubleSeguro(txtPsiE, 1.0);
        double lambda = LeerDoubleSeguro(txtLambda, 1.0);
        double factor = LeerDoubleSeguro(txtFactorEmpalme, 1.30);
        double minimo = LeerDoubleSeguro(txtMinEmpalme, 300.0);
        double psiSup = LeerDoubleSeguro(txtPsiSuperior, 1.30);
        double psiInf = LeerDoubleSeguro(txtPsiInferior, 1.00);
        double psiCen = LeerDoubleSeguro(txtPsiCentral, 1.00);

        ActualizarResultadoFila(lblResultadoSuperior, DbSuperiorMm, fc, fy, psiE, lambda, factor, minimo, psiSup);
        ActualizarResultadoFila(lblResultadoInferior, DbInferiorMm, fc, fy, psiE, lambda, factor, minimo, psiInf);

        if (MostrarCentral)
            ActualizarResultadoFila(lblResultadoCentral, DbCentralMm, fc, fy, psiE, lambda, factor, minimo, psiCen);
        else
            lblResultadoCentral.Text = "--";
    }

    private void ActualizarResultadoFila(
        WinForms.Label lbl,
        double dbMm,
        double fcKgCm2,
        double fyMpa,
        double psiE,
        double lambda,
        double factorEmpalme,
        double minimoEmpalmeMm,
        double psiT)
    {
        if (lbl == null)
            return;

        if (dbMm <= 0.0 || fcKgCm2 <= 0.0 || fyMpa <= 0.0 || psiE <= 0.0 || lambda <= 0.0 || factorEmpalme <= 0.0)
        {
            lbl.Text = "--";
            return;
        }

        double fcMpa = fcKgCm2 / 10.0;
        double denominador = dbMm <= 19.05 ? 2.6 : 2.1;

        double ldMm = (fyMpa * psiT * psiE * dbMm) /
            (denominador * lambda * Math.Sqrt(fcMpa));

        double leMm = factorEmpalme * ldMm;

        if (leMm < minimoEmpalmeMm)
            leMm = minimoEmpalmeMm;

        double ldCm = Math.Ceiling(ldMm / 10.0);
        double leCm = Math.Ceiling(leMm / 10.0);

        lbl.Text = "ld " + ldCm.ToString("0", System.Globalization.CultureInfo.InvariantCulture) +
            " cm | Le " + leCm.ToString("0", System.Globalization.CultureInfo.InvariantCulture) + " cm";
    }

    private double LeerFcSeleccionado()
    {
        if (cmbFc == null || cmbFc.SelectedItem == null)
            return 210.0;

        string texto = cmbFc.SelectedItem.ToString();

        System.Text.RegularExpressions.Match m =
            System.Text.RegularExpressions.Regex.Match(texto, @"\d+(\.\d+)?");

        if (m.Success)
        {
            if (double.TryParse(
                m.Value.Replace(",", "."),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out double valor))
            {
                return valor;
            }
        }

        return 210.0;
    }

    private bool LeerDouble(WinForms.TextBox txt, out double valor)
    {
        valor = 0.0;

        if (txt == null)
            return false;

        string texto = (txt.Text ?? "").Trim().Replace(",", ".");

        return double.TryParse(
            texto,
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture,
            out valor);
    }

    private double LeerDoubleSeguro(WinForms.TextBox txt, double defecto)
    {
        if (LeerDouble(txt, out double valor))
            return valor;

        return defecto;
    }

    private void MostrarError(string mensaje)
    {
        WinForms.MessageBox.Show(
            mensaje,
            "MYG - RNE",
            WinForms.MessageBoxButtons.OK,
            WinForms.MessageBoxIcon.Warning);
    }

    private string FormatearMm(double valor)
    {
        if (valor <= 0.0)
            return "--";

        return valor.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture) + " mm";
    }
}