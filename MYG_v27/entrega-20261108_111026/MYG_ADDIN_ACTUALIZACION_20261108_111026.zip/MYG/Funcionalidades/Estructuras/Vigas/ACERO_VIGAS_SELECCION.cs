﻿// =====================================
// HANDLERS - ACERO LONGITUDINAL EN VIGAS
// DETECTA LUZ LIBRE ENTRE CARAS DE COLUMNAS
// SELECCIÓN + EJECUCIÓN COMPLETA
// MODIFICADO: CREA ACERO CENTRAL SI EL CHECK ESTÁ ACTIVADO
// =====================================
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Linq;


// =====================================
// SELECCIÓN - VIGAS
// =====================================
public class SeleccionarVigasAceroLongitudinalHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public AceroLongitudinalVigasForm Form;

    // Referencia opcional a la ventana principal. No es obligatorio modificar
    // el comando: si queda nula, el handler la localiza entre los formularios
    // abiertos comparando la instancia de VentanaLongitudinal.
    public AceroVigasMainForm MainForm;

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern bool ShowWindow(System.IntPtr hWnd, int nCmdShow);

    private const int SwMinimize = 6;
    private const int SwRestore = 9;
    private const int SwShow = 5;

    public List<ElementId> VigasSeleccionadas = new List<ElementId>();

    // Controla que las columnas reales detectadas no se agreguen repetidas
    // a la vista 3D cuando dos vigas comparten el mismo apoyo.
    private HashSet<long> columnas3DAgregadas = new HashSet<long>();

    private const double Tol = 1e-6;


    // =====================================
    // APOYO DETECTADO POR VIGA TRANSVERSAL
    // =====================================
    private class VigaTransversalDetectada
    {
        public Element Elemento { get; set; }
        public AceroLongitudinalVigasForm.ColumnaPreview Preview { get; set; }
    }

    // =========================================================
    // DATOS MÍNIMOS DE UNA COLUMNA REAL EN UN EXTREMO
    // =========================================================
    // Solo se usa para:
    // - mostrar la columna inicial/final en el preview 2D;
    // - habilitar y calcular la opción Auto del desarrollo.
    // Nunca se agrega al preview 3D ni se leen otras categorías.
    private class ColumnaExtremoMYG
    {
        public Element Elemento;
        public double AnchoFt;
        public string Nombre;

        public bool Valida
        {
            get { return Elemento != null && AnchoFt > Tol; }
        }

        public double AnchoMm
        {
            get
            {
                return Valida
                    ? UnitUtils.ConvertFromInternalUnits(AnchoFt, UnitTypeId.Millimeters)
                    : 0.0;
            }
        }
    }

    public void Execute(UIApplication app)
    {
        UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

        if (uidoc == null || Form == null || Form.IsDisposed)
            return;

        Document doc = uidoc.Document;
        System.Windows.Forms.Form ventanaPrincipal = ObtenerVentanaPrincipalMYG();
        EstadoVentanaSeleccionMYG estadoVentana =
            PrepararVentanaParaSeleccionMYG(ventanaPrincipal);

        try
        {
            IList<Reference> referencias = null;

            try
            {
                referencias = uidoc.Selection.PickObjects(
                    ObjectType.Element,
                    new FiltroVigasEstructurales(),
                    "Seleccione vigas o armazones estructurales y luego presione FINALIZAR.");
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                referencias = null;
            }
            catch
            {
                referencias = null;
            }

            // Cancelar no borra la selección válida anterior.
            if (referencias == null || referencias.Count == 0)
                return;

            List<ElementId> nuevaSeleccion = new List<ElementId>();

            foreach (Reference referencia in referencias)
            {
                if (referencia == null)
                    continue;

                Element elemento = doc.GetElement(referencia.ElementId);

                if (elemento == null)
                    continue;

                if (!nuevaSeleccion.Contains(elemento.Id))
                    nuevaSeleccion.Add(elemento.Id);
            }

            if (nuevaSeleccion.Count == 0)
                return;

            VigasSeleccionadas.Clear();
            VigasSeleccionadas.AddRange(nuevaSeleccion);
            OrdenarSeleccionSegunSerie(doc);

            try
            {
                uidoc.Selection.SetElementIds(VigasSeleccionadas);
            }
            catch
            {
                // El preview no depende de que Revit conserve el resaltado.
            }

            Form.ActualizarCantidad(VigasSeleccionadas.Count);
            ActualizarVistaPreviaDesdeSeleccion(doc);

            // El evento PreviewVigasActualizadas del formulario longitudinal
            // sincroniza MAIN, Estribos y el editor longitudinal. Se procesa el
            // Layout antes de restaurar la ventana para evitar que aparezca por
            // un instante el mensaje "Seleccione una o más vigas".
            try
            {
                System.Windows.Forms.Application.DoEvents();
            }
            catch
            {
            }
        }
        finally
        {
            RestaurarVentanaDespuesSeleccionMYG(
                ventanaPrincipal,
                estadoVentana);
        }
    }

    // V11.51 - cambia la serie activa sin volver a pedir selección al usuario.
    public bool EstablecerSeleccionProgramaticaMYG(
        Document doc,
        IEnumerable<ElementId> ids,
        bool actualizarSeleccionRevit)
    {
        if (doc == null || Form == null || Form.IsDisposed || ids == null)
            return false;

        List<ElementId> lista = ids
            .Where(x => x != null && x != ElementId.InvalidElementId)
            .GroupBy(x => x.Value)
            .Select(g => g.First())
            .ToList();

        if (lista.Count == 0)
            return false;

        VigasSeleccionadas.Clear();
        VigasSeleccionadas.AddRange(lista);
        OrdenarSeleccionSegunSerie(doc);

        if (actualizarSeleccionRevit)
        {
            try
            {
                UIDocument uidoc = UiDoc;
                if (uidoc != null)
                    uidoc.Selection.SetElementIds(VigasSeleccionadas);
            }
            catch { }
        }

        try
        {
            Form.ActualizarCantidad(VigasSeleccionadas.Count);
            ActualizarVistaPreviaDesdeSeleccion(doc);
            System.Windows.Forms.Application.DoEvents();
        }
        catch { return false; }

        return VigasSeleccionadas.Count > 0;
    }

    private sealed class EstadoVentanaSeleccionMYG
    {
        public bool Valido;
        public bool Visible;
        public bool TopMost;
        public System.Windows.Forms.FormWindowState WindowState;
        public bool SeOcultoComoRespaldo;
    }

    private System.Windows.Forms.Form ObtenerVentanaPrincipalMYG()
    {
        if (MainForm != null && !MainForm.IsDisposed)
            return MainForm;

        try
        {
            System.Windows.Forms.Form encontrada = Form.FindForm();

            if (encontrada != null &&
                !encontrada.IsDisposed &&
                !object.ReferenceEquals(encontrada, Form) &&
                encontrada.TopLevel)
            {
                AceroVigasMainForm mainEncontrado =
                    encontrada as AceroVigasMainForm;

                if (mainEncontrado != null)
                {
                    MainForm = mainEncontrado;
                    return mainEncontrado;
                }
            }
        }
        catch
        {
        }

        // En la pestaña "Seleccionar vigas", VentanaLongitudinal está separada
        // temporalmente de panelContenido. Por eso FindForm puede no encontrar el
        // MAIN. Application.OpenForms sí conserva la ventana top-level abierta.
        try
        {
            foreach (System.Windows.Forms.Form abierta in
                System.Windows.Forms.Application.OpenForms)
            {
                AceroVigasMainForm candidata = abierta as AceroVigasMainForm;

                if (candidata == null || candidata.IsDisposed)
                    continue;

                if (object.ReferenceEquals(candidata.VentanaLongitudinal, Form))
                {
                    MainForm = candidata;
                    return candidata;
                }
            }
        }
        catch
        {
        }

        // Último respaldo por título. Solo se considera una ventana top-level.
        try
        {
            foreach (System.Windows.Forms.Form abierta in
                System.Windows.Forms.Application.OpenForms)
            {
                if (abierta == null || abierta.IsDisposed || !abierta.TopLevel)
                    continue;

                if (string.Equals(
                    abierta.Text,
                    "MYG - Acero en Vigas",
                    StringComparison.OrdinalIgnoreCase))
                {
                    return abierta;
                }
            }
        }
        catch
        {
        }

        return null;
    }

    private EstadoVentanaSeleccionMYG PrepararVentanaParaSeleccionMYG(
        System.Windows.Forms.Form ventana)
    {
        EstadoVentanaSeleccionMYG estado = new EstadoVentanaSeleccionMYG();

        if (ventana == null || ventana.IsDisposed)
        {
            try
            {
                Form.Hide();
                estado.SeOcultoComoRespaldo = true;
            }
            catch
            {
            }

            return estado;
        }

        estado.Valido = true;
        estado.Visible = ventana.Visible;
        estado.TopMost = ventana.TopMost;
        estado.WindowState = ventana.WindowState;

        try
        {
            ventana.TopMost = false;

            if (!ventana.IsHandleCreated)
                ventana.CreateControl();

            // ShowWindow fuerza la minimización incluso cuando WinForms todavía
            // está procesando el cambio de pestaña o la ventana estaba maximizada.
            ShowWindow(ventana.Handle, SwMinimize);
            ventana.WindowState =
                System.Windows.Forms.FormWindowState.Minimized;
            ventana.Update();
            System.Windows.Forms.Application.DoEvents();
        }
        catch
        {
            try
            {
                ventana.Hide();
                estado.SeOcultoComoRespaldo = true;
                System.Windows.Forms.Application.DoEvents();
            }
            catch
            {
            }
        }

        return estado;
    }

    private void RestaurarVentanaDespuesSeleccionMYG(
        System.Windows.Forms.Form ventana,
        EstadoVentanaSeleccionMYG estado)
    {
        if (ventana == null || ventana.IsDisposed || estado == null ||
            !estado.Valido)
        {
            try
            {
                Form.Show();
                Form.Activate();
            }
            catch
            {
            }
            return;
        }

        try
        {
            if (!ventana.Visible || estado.SeOcultoComoRespaldo)
                ventana.Show();

            if (!ventana.IsHandleCreated)
                ventana.CreateControl();

            ShowWindow(ventana.Handle, SwRestore);

            // Se recupera el estado real previo. Si por alguna razón era
            // Minimized, se restaura como Normal para no dejar al usuario sin UI.
            ventana.WindowState = estado.WindowState ==
                System.Windows.Forms.FormWindowState.Maximized
                    ? System.Windows.Forms.FormWindowState.Maximized
                    : System.Windows.Forms.FormWindowState.Normal;

            ventana.TopMost = estado.TopMost;
            ShowWindow(ventana.Handle, SwShow);
            ventana.BringToFront();
            ventana.Activate();
            ventana.Focus();
            ventana.Refresh();
            System.Windows.Forms.Application.DoEvents();

            // Segundo pase luego del Layout: reconstruye los editores integrados
            // con el contorno transversal que el handler acaba de registrar.
            try
            {
                ventana.BeginInvoke(new Action(() =>
                {
                    if (ventana == null || ventana.IsDisposed)
                        return;

                    ventana.TopMost = estado.TopMost;
                    ventana.BringToFront();
                    ventana.Activate();
                    ventana.Refresh();
                }));
            }
            catch
            {
            }
        }
        catch
        {
            try
            {
                Form.Show();
                Form.Activate();
            }
            catch
            {
            }
        }
    }

    public string GetName()
    {
        return "Seleccionar vigas para acero longitudinal";
    }

    // =====================================
    // ORDENAR SELECCIÓN SEGÚN LA DIRECCIÓN DE LA SERIE
    // =====================================
    private void OrdenarSeleccionSegunSerie(Document doc)
    {
        if (doc == null || VigasSeleccionadas == null || VigasSeleccionadas.Count <= 1)
            return;

        List<Element> elementos = VigasSeleccionadas
            .Select(id => doc.GetElement(id))
            .Where(e => e != null)
            .ToList();

        elementos = OrdenarElementosPorContinuidadMYG(elementos);

        if (elementos == null || elementos.Count == 0)
            return;

        VigasSeleccionadas = elementos
            .Select(e => e.Id)
            .ToList();
    }

    // =====================================
    // ACTUALIZAR VISTA PRELIMINAR
    // =====================================
    private void ActualizarVistaPreviaDesdeSeleccion(Document doc)
    {
        List<VigaLongitudinalPreview> vistas =
            new List<VigaLongitudinalPreview>();

        List<Element> vigasOrdenadas = ObtenerVigasOrdenadas(doc);

        foreach (Element viga in vigasOrdenadas)
        {
            if (viga == null)
                continue;

            VigaLongitudinalPreview vista =
                ConstruirVistaPreviaDesdeViga(doc, viga);

            if (vista != null)
                vistas.Add(vista);
        }

        // Se detectan exclusivamente columnas reales de los DOS extremos.
        // Se muestran solo en el preview 2D y no se incorporan al preview 3D.
        ActualizarColumnasExtremosAutoDesdeSeleccion(
            doc,
            vigasOrdenadas,
            vistas);

        EnviarVistaPreviaAlForm(vistas);
    }

    // =========================================================
    // COLUMNAS DE EXTREMO SOLO PARA DESARROLLO AUTOMÁTICO
    // =========================================================
    // No altera la vista 2D/3D. Solo comunica al formulario si existe una
    // columna en el inicio y/o final de la serie y cuál es su ancho real
    // proyectado sobre el eje de las vigas seleccionadas.
    private void ActualizarColumnasExtremosAutoDesdeSeleccion(
        Document doc,
        List<Element> vigasOrdenadas,
        List<VigaLongitudinalPreview> vistas)
    {
        ColumnaExtremoMYG columnaInicio = null;
        ColumnaExtremoMYG columnaFin = null;

        try
        {
            DetectarColumnasExtremosSerieMYG(
                doc,
                vigasOrdenadas,
                out columnaInicio,
                out columnaFin);
        }
        catch
        {
            columnaInicio = null;
            columnaFin = null;
        }

        AplicarColumnasExtremosAlPreviewMYG(
            vistas,
            columnaInicio,
            columnaFin);

        if (Form == null || Form.IsDisposed)
            return;

        try
        {
            Form.EstablecerColumnasExtremosAuto(
                columnaInicio != null && columnaInicio.Valida,
                columnaInicio != null ? columnaInicio.AnchoMm : 0.0,
                columnaFin != null && columnaFin.Valida,
                columnaFin != null ? columnaFin.AnchoMm : 0.0);
        }
        catch
        {
            // No interrumpir la selección si temporalmente se usa una ventana anterior.
        }
    }

    private void AplicarColumnasExtremosAlPreviewMYG(
        List<VigaLongitudinalPreview> vistas,
        ColumnaExtremoMYG columnaInicio,
        ColumnaExtremoMYG columnaFin)
    {
        if (vistas == null || vistas.Count == 0)
            return;

        // Garantiza que no aparezcan columnas interiores ni apoyos de otras categorías.
        foreach (VigaLongitudinalPreview vista in vistas)
        {
            if (vista == null)
                continue;

            if (vista.Columnas == null)
                vista.Columnas = new List<AceroLongitudinalVigasForm.ColumnaPreview>();
            else
                vista.Columnas.Clear();
        }

        VigaLongitudinalPreview primera = vistas.FirstOrDefault(v => v != null);
        VigaLongitudinalPreview ultima = vistas.LastOrDefault(v => v != null);

        if (primera == null || ultima == null)
            return;

        if (columnaInicio != null && columnaInicio.Valida)
        {
            primera.Columnas.Add(
                new AceroLongitudinalVigasForm.ColumnaPreview(
                    0.0,
                    Math.Max(50.0, columnaInicio.AnchoMm),
                    string.IsNullOrWhiteSpace(columnaInicio.Nombre)
                        ? "Columna inicial"
                        : columnaInicio.Nombre));
        }

        if (columnaFin != null && columnaFin.Valida)
        {
            double centroFinMm = Math.Max(0.0, ultima.LongitudMm);

            ultima.Columnas.Add(
                new AceroLongitudinalVigasForm.ColumnaPreview(
                    centroFinMm,
                    Math.Max(50.0, columnaFin.AnchoMm),
                    string.IsNullOrWhiteSpace(columnaFin.Nombre)
                        ? "Columna final"
                        : columnaFin.Nombre));
        }

        try
        {
            primera.NormalizarApoyos();

            if (!ReferenceEquals(primera, ultima))
                ultima.NormalizarApoyos();
        }
        catch
        {
        }
    }

    private void DetectarColumnasExtremosSerieMYG(
        Document doc,
        List<Element> vigas,
        out ColumnaExtremoMYG columnaInicio,
        out ColumnaExtremoMYG columnaFin)
    {
        columnaInicio = null;
        columnaFin = null;

        if (doc == null || vigas == null || vigas.Count == 0)
            return;

        List<Element> ordenadas = OrdenarElementosPorContinuidadMYG(
            vigas.Where(v => v != null).ToList());

        if (ordenadas == null || ordenadas.Count == 0)
            return;

        XYZ puntoInicio;
        XYZ direccionInteriorInicio;
        XYZ puntoFin;
        XYZ direccionInteriorFin;

        if (!ObtenerExtremosOrientadosSerieMYG(
            ordenadas,
            out puntoInicio,
            out direccionInteriorInicio,
            out puntoFin,
            out direccionInteriorFin))
        {
            return;
        }

        columnaInicio = DetectarColumnaRealEnExtremoMYG(
            doc,
            ordenadas.First(),
            puntoInicio,
            direccionInteriorInicio);

        columnaFin = DetectarColumnaRealEnExtremoMYG(
            doc,
            ordenadas.Last(),
            puntoFin,
            direccionInteriorFin);
    }

    private bool ObtenerExtremosOrientadosSerieMYG(
        List<Element> ordenadas,
        out XYZ puntoInicio,
        out XYZ direccionInteriorInicio,
        out XYZ puntoFin,
        out XYZ direccionInteriorFin)
    {
        puntoInicio = null;
        direccionInteriorInicio = null;
        puntoFin = null;
        direccionInteriorFin = null;

        if (ordenadas == null || ordenadas.Count == 0)
            return false;

        Curve curvaPrimera = ObtenerCurvaElemento(ordenadas.First());
        Curve curvaUltima = ObtenerCurvaElemento(ordenadas.Last());

        if (curvaPrimera == null || curvaUltima == null)
            return false;

        int extremoInicio = 0;
        int extremoFin = 1;

        if (ordenadas.Count > 1)
        {
            Curve curvaSegunda = ObtenerCurvaElemento(ordenadas[1]);
            Curve curvaPenultima = ObtenerCurvaElemento(ordenadas[ordenadas.Count - 2]);

            if (curvaSegunda != null)
            {
                double d0 = DistanciaMinimaPuntoAExtremosCurvaMYG(
                    curvaPrimera.GetEndPoint(0),
                    curvaSegunda);

                double d1 = DistanciaMinimaPuntoAExtremosCurvaMYG(
                    curvaPrimera.GetEndPoint(1),
                    curvaSegunda);

                extremoInicio = d0 >= d1 ? 0 : 1;
            }

            if (curvaPenultima != null)
            {
                double d0 = DistanciaMinimaPuntoAExtremosCurvaMYG(
                    curvaUltima.GetEndPoint(0),
                    curvaPenultima);

                double d1 = DistanciaMinimaPuntoAExtremosCurvaMYG(
                    curvaUltima.GetEndPoint(1),
                    curvaPenultima);

                extremoFin = d0 >= d1 ? 0 : 1;
            }
        }

        puntoInicio = curvaPrimera.GetEndPoint(extremoInicio);
        puntoFin = curvaUltima.GetEndPoint(extremoFin);

        XYZ tangenteInicio = ObtenerTangenteExtremoCurvaMYG(
            curvaPrimera,
            extremoInicio);

        XYZ tangenteFin = ObtenerTangenteExtremoCurvaMYG(
            curvaUltima,
            extremoFin);

        if (tangenteInicio == null || tangenteFin == null)
            return false;

        // En ambos extremos se usa una dirección que apunta HACIA EL INTERIOR
        // de la serie. La columna válida debe encontrarse al lado exterior.
        direccionInteriorInicio = extremoInicio == 0
            ? tangenteInicio
            : tangenteInicio.Multiply(-1.0);

        direccionInteriorFin = extremoFin == 0
            ? tangenteFin
            : tangenteFin.Multiply(-1.0);

        if (direccionInteriorInicio.GetLength() <= Tol ||
            direccionInteriorFin.GetLength() <= Tol)
        {
            return false;
        }

        direccionInteriorInicio = direccionInteriorInicio.Normalize();
        direccionInteriorFin = direccionInteriorFin.Normalize();

        return true;
    }

    private XYZ ObtenerTangenteExtremoCurvaMYG(
        Curve curva,
        int extremo)
    {
        if (curva == null)
            return null;

        double u = extremo == 0 ? 0.0 : 1.0;

        try
        {
            Transform derivadas = curva.ComputeDerivatives(u, true);

            if (derivadas != null &&
                derivadas.BasisX != null &&
                derivadas.BasisX.GetLength() > Tol)
            {
                return derivadas.BasisX.Normalize();
            }
        }
        catch
        {
        }

        try
        {
            XYZ a = curva.GetEndPoint(0);
            XYZ b = curva.GetEndPoint(1);
            XYZ dir = b - a;

            if (dir.GetLength() > Tol)
                return dir.Normalize();
        }
        catch
        {
        }

        return null;
    }

    private double DistanciaMinimaPuntoAExtremosCurvaMYG(
        XYZ punto,
        Curve curva)
    {
        if (punto == null || curva == null)
            return double.MaxValue;

        try
        {
            return Math.Min(
                punto.DistanceTo(curva.GetEndPoint(0)),
                punto.DistanceTo(curva.GetEndPoint(1)));
        }
        catch
        {
            return double.MaxValue;
        }
    }

    private ColumnaExtremoMYG DetectarColumnaRealEnExtremoMYG(
        Document doc,
        Element vigaExtremo,
        XYZ puntoExtremo,
        XYZ direccionInterior)
    {
        if (doc == null || vigaExtremo == null || puntoExtremo == null)
            return null;

        if (direccionInterior == null || direccionInterior.GetLength() <= Tol)
            return null;

        direccionInterior = direccionInterior.Normalize();

        XYZ ejeLateral = XYZ.BasisZ.CrossProduct(direccionInterior);

        if (ejeLateral.GetLength() <= Tol)
            ejeLateral = XYZ.BasisX.CrossProduct(direccionInterior);

        if (ejeLateral.GetLength() <= Tol)
            ejeLateral = XYZ.BasisY;

        ejeLateral = ejeLateral.Normalize();

        List<XYZ> puntosViga = ObtenerPuntosSolidoElementoPreview(vigaExtremo);

        if (puntosViga == null || puntosViga.Count == 0)
            puntosViga = ObtenerPuntosBoundingBoxElementoPreview(vigaExtremo);

        if (puntosViga == null || puntosViga.Count == 0)
            return null;

        double vMinY = double.MaxValue;
        double vMaxY = double.MinValue;
        double vMinZ = double.MaxValue;
        double vMaxZ = double.MinValue;

        foreach (XYZ p in puntosViga)
        {
            if (p == null)
                continue;

            double y = (p - puntoExtremo).DotProduct(ejeLateral);

            if (y < vMinY) vMinY = y;
            if (y > vMaxY) vMaxY = y;
            if (p.Z < vMinZ) vMinZ = p.Z;
            if (p.Z > vMaxZ) vMaxZ = p.Z;
        }

        double radioBusquedaXY = UnitUtils.ConvertToInternalUnits(
            120.0,
            UnitTypeId.Centimeters);

        double radioBusquedaZ = UnitUtils.ConvertToInternalUnits(
            120.0,
            UnitTypeId.Centimeters);

        Outline outline = new Outline(
            new XYZ(
                puntoExtremo.X - radioBusquedaXY,
                puntoExtremo.Y - radioBusquedaXY,
                puntoExtremo.Z - radioBusquedaZ),
            new XYZ(
                puntoExtremo.X + radioBusquedaXY,
                puntoExtremo.Y + radioBusquedaXY,
                puntoExtremo.Z + radioBusquedaZ));

        BoundingBoxIntersectsFilter filtro =
            new BoundingBoxIntersectsFilter(outline);

        List<Element> candidatas = new List<Element>();

        // ÚNICAS categorías permitidas para Auto y para el preview de extremos.
        AgregarColumnasPorCategoria(
            doc,
            candidatas,
            BuiltInCategory.OST_StructuralColumns,
            filtro);

        AgregarColumnasPorCategoria(
            doc,
            candidatas,
            BuiltInCategory.OST_Columns,
            filtro);

        candidatas = candidatas
            .Where(c => c != null)
            .Where(c => VigasSeleccionadas == null || !VigasSeleccionadas.Contains(c.Id))
            .GroupBy(c => c.Id.Value)
            .Select(g => g.First())
            .ToList();

        double toleranciaTransversal = UnitUtils.ConvertToInternalUnits(
            8.0,
            UnitTypeId.Centimeters);

        double toleranciaVertical = UnitUtils.ConvertToInternalUnits(
            20.0,
            UnitTypeId.Centimeters);

        double distanciaMaxima = UnitUtils.ConvertToInternalUnits(
            30.0,
            UnitTypeId.Centimeters);

        double toleranciaInterior = UnitUtils.ConvertToInternalUnits(
            15.0,
            UnitTypeId.Centimeters);

        ColumnaExtremoMYG mejor = null;
        double mejorDistancia = double.MaxValue;

        foreach (Element columna in candidatas)
        {
            List<XYZ> pts = ObtenerPuntosSolidoElementoPreview(columna);

            if (pts == null || pts.Count == 0)
                pts = ObtenerPuntosBoundingBoxElementoPreview(columna);

            if (pts == null || pts.Count == 0)
                continue;

            double minX = double.MaxValue;
            double maxX = double.MinValue;
            double minY = double.MaxValue;
            double maxY = double.MinValue;
            double minZ = double.MaxValue;
            double maxZ = double.MinValue;

            foreach (XYZ p in pts)
            {
                if (p == null)
                    continue;

                XYZ rel = p - puntoExtremo;
                double x = rel.DotProduct(direccionInterior);
                double y = rel.DotProduct(ejeLateral);

                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
                if (p.Z < minZ) minZ = p.Z;
                if (p.Z > maxZ) maxZ = p.Z;
            }

            double ancho = maxX - minX;

            if (ancho <= Tol)
                continue;

            // La columna debe tocar el ancho de la viga en planta.
            if (maxY < vMinY - toleranciaTransversal ||
                minY > vMaxY + toleranciaTransversal)
            {
                continue;
            }

            // Y también debe coincidir verticalmente con la viga.
            if (maxZ < vMinZ - toleranciaVertical ||
                minZ > vMaxZ + toleranciaVertical)
            {
                continue;
            }

            // direccionInterior apunta hacia la viga. Una columna de extremo
            // debe cubrir x=0 o quedar inmediatamente al lado EXTERIOR (x negativo).
            if (minX > toleranciaInterior)
                continue;

            double distancia = 0.0;

            if (0.0 < minX)
                distancia = minX;
            else if (0.0 > maxX)
                distancia = -maxX;

            if (distancia > distanciaMaxima)
                continue;

            if (distancia < mejorDistancia - Tol ||
                (Math.Abs(distancia - mejorDistancia) <= Tol &&
                 (mejor == null || ancho > mejor.AnchoFt)))
            {
                mejorDistancia = distancia;
                mejor = new ColumnaExtremoMYG()
                {
                    Elemento = columna,
                    AnchoFt = ancho,
                    Nombre = ObtenerNombreElemento(columna)
                };
            }
        }

        return mejor;
    }

    // =========================================================
    // V11.26 MYG - ORDEN FÍSICO REAL DE LOS TRAMOS DE LA SERIE
    // =========================================================
    // Problema corregido:
    // el algoritmo anterior podía iniciar en una viga intermedia cuando varios
    // extremos tenían la misma cantidad de vecinos. En ese caso una serie física
    // T1-T2-T3 podía terminar dibujándose T2-T1-T3 en la vista preliminar.
    //
    // Nueva lógica:
    // 1) obtiene el centro geométrico de cada LocationCurve;
    // 2) busca el par de vigas más alejadas entre sí: ese par representa los
    //    extremos más probables de una serie lineal/encadenada;
    // 3) elige de forma determinista el extremo "inicial" según coordenadas
    //    globales (X, luego Y, luego Z);
    // 4) desde ese extremo recorre siempre la viga físicamente más próxima al
    //    extremo de la última viga añadida.
    //
    // Esto hace que el orden NO dependa del orden en que el usuario seleccionó
    // las vigas y mantiene T1, T2, T3... en la misma secuencia física del modelo.
    private List<Element> OrdenarElementosPorContinuidadMYG(
        List<Element> entrada)
    {
        List<Element> elementos = entrada == null
            ? new List<Element>()
            : entrada
                .Where(e => e != null && ObtenerCurvaElemento(e) != null)
                .GroupBy(e => e.Id.Value)
                .Select(g => g.First())
                .ToList();

        if (elementos.Count <= 1)
            return elementos;

        // -----------------------------------------------------
        // 1. Localizar los dos extremos globales de la serie.
        // -----------------------------------------------------
        Element extremoA = null;
        Element extremoB = null;
        double mayorDistanciaCentros = double.MinValue;

        for (int i = 0; i < elementos.Count; i++)
        {
            XYZ centroI = ObtenerCentroCurvaSerieMYG(
                ObtenerCurvaElemento(elementos[i]));

            if (centroI == null)
                continue;

            for (int j = i + 1; j < elementos.Count; j++)
            {
                XYZ centroJ = ObtenerCentroCurvaSerieMYG(
                    ObtenerCurvaElemento(elementos[j]));

                if (centroJ == null)
                    continue;

                double distancia = centroI.DistanceTo(centroJ);

                if (distancia > mayorDistanciaCentros)
                {
                    mayorDistanciaCentros = distancia;
                    extremoA = elementos[i];
                    extremoB = elementos[j];
                }
            }
        }

        // Respaldo extremadamente conservador.
        if (extremoA == null || extremoB == null)
        {
            return elementos
                .OrderBy(e => e.Id.Value)
                .ToList();
        }

        // -----------------------------------------------------
        // 2. Elegir un inicio determinista para que la vista no
        //    se invierta según el orden de selección del usuario.
        // -----------------------------------------------------
        Element inicial = CompararExtremosFisicosSerieMYG(
            extremoA,
            extremoB) <= 0
                ? extremoA
                : extremoB;

        List<Element> pendientes = new List<Element>(elementos);
        List<Element> resultado = new List<Element>();

        pendientes.Remove(inicial);
        resultado.Add(inicial);

        // -----------------------------------------------------
        // 3. Caminar por continuidad física.
        // -----------------------------------------------------
        while (pendientes.Count > 0)
        {
            Element ultimo = resultado[resultado.Count - 1];
            Curve curvaUltimo = ObtenerCurvaElemento(ultimo);

            if (curvaUltimo == null)
                break;

            Element mejor = null;
            double mejorDistancia = double.MaxValue;

            foreach (Element candidato in pendientes)
            {
                Curve curvaCandidato = ObtenerCurvaElemento(candidato);

                if (curvaCandidato == null)
                    continue;

                double distancia = DistanciaMinimaEntreCurvasSerieMYG(
                    curvaUltimo,
                    curvaCandidato);

                if (distancia < mejorDistancia - Tol)
                {
                    mejorDistancia = distancia;
                    mejor = candidato;
                    continue;
                }

                // Empate: se usa la posición física para que el resultado sea
                // estable entre ejecuciones y no dependa del orden de selección.
                if (Math.Abs(distancia - mejorDistancia) <= Tol &&
                    mejor != null &&
                    CompararExtremosFisicosSerieMYG(candidato, mejor) < 0)
                {
                    mejor = candidato;
                }
            }

            if (mejor == null)
                break;

            pendientes.Remove(mejor);
            resultado.Add(mejor);
        }

        // Nunca se pierde una selección aunque exista algún elemento aislado.
        if (pendientes.Count > 0)
        {
            List<Element> aislados = pendientes
                .OrderBy(e => ObtenerCoordenadaOrdenSerieMYG(e, 0))
                .ThenBy(e => ObtenerCoordenadaOrdenSerieMYG(e, 1))
                .ThenBy(e => ObtenerCoordenadaOrdenSerieMYG(e, 2))
                .ThenBy(e => e.Id.Value)
                .ToList();

            resultado.AddRange(aislados);
        }

        return resultado;
    }

    private XYZ ObtenerCentroCurvaSerieMYG(Curve curva)
    {
        if (curva == null)
            return null;

        try
        {
            XYZ p0 = curva.GetEndPoint(0);
            XYZ p1 = curva.GetEndPoint(1);

            if (p0 == null || p1 == null)
                return null;

            return (p0 + p1) * 0.5;
        }
        catch
        {
            return null;
        }
    }

    private double DistanciaMinimaEntreCurvasSerieMYG(
        Curve curvaA,
        Curve curvaB)
    {
        if (curvaA == null || curvaB == null)
            return double.MaxValue;

        try
        {
            XYZ a0 = curvaA.GetEndPoint(0);
            XYZ a1 = curvaA.GetEndPoint(1);
            XYZ b0 = curvaB.GetEndPoint(0);
            XYZ b1 = curvaB.GetEndPoint(1);

            if (a0 == null || a1 == null || b0 == null || b1 == null)
                return double.MaxValue;

            double d00 = a0.DistanceTo(b0);
            double d01 = a0.DistanceTo(b1);
            double d10 = a1.DistanceTo(b0);
            double d11 = a1.DistanceTo(b1);

            return Math.Min(
                Math.Min(d00, d01),
                Math.Min(d10, d11));
        }
        catch
        {
            return double.MaxValue;
        }
    }

    private int CompararExtremosFisicosSerieMYG(
        Element elementoA,
        Element elementoB)
    {
        XYZ centroA = ObtenerCentroCurvaSerieMYG(
            ObtenerCurvaElemento(elementoA));
        XYZ centroB = ObtenerCentroCurvaSerieMYG(
            ObtenerCurvaElemento(elementoB));

        if (centroA == null && centroB == null)
        {
            long idA = elementoA != null ? elementoA.Id.Value : long.MaxValue;
            long idB = elementoB != null ? elementoB.Id.Value : long.MaxValue;
            return idA.CompareTo(idB);
        }

        if (centroA == null)
            return 1;
        if (centroB == null)
            return -1;

        const double toleranciaOrden = 1e-7;

        if (Math.Abs(centroA.X - centroB.X) > toleranciaOrden)
            return centroA.X.CompareTo(centroB.X);

        if (Math.Abs(centroA.Y - centroB.Y) > toleranciaOrden)
            return centroA.Y.CompareTo(centroB.Y);

        if (Math.Abs(centroA.Z - centroB.Z) > toleranciaOrden)
            return centroA.Z.CompareTo(centroB.Z);

        long elementoIdA = elementoA != null
            ? elementoA.Id.Value
            : long.MaxValue;
        long elementoIdB = elementoB != null
            ? elementoB.Id.Value
            : long.MaxValue;

        return elementoIdA.CompareTo(elementoIdB);
    }

    private double ObtenerCoordenadaOrdenSerieMYG(
        Element elemento,
        int eje)
    {
        XYZ centro = ObtenerCentroCurvaSerieMYG(
            ObtenerCurvaElemento(elemento));

        if (centro == null)
            return double.MaxValue;

        if (eje == 0)
            return centro.X;
        if (eje == 1)
            return centro.Y;

        return centro.Z;
    }

    private List<Element> ObtenerVigasOrdenadas(Document doc)
    {
        List<Element> vigas = new List<Element>();

        if (doc == null || VigasSeleccionadas == null || VigasSeleccionadas.Count == 0)
            return vigas;

        foreach (ElementId id in VigasSeleccionadas)
        {
            Element e = doc.GetElement(id);

            if (e != null)
                vigas.Add(e);
        }

        return OrdenarElementosPorContinuidadMYG(vigas);
    }

    private void EnviarVistaPreviaAlForm(
        List<VigaLongitudinalPreview> vistas)
    {
        if (Form == null)
            return;

        if (vistas == null || vistas.Count == 0)
            return;

        try
        {
            System.Reflection.MethodInfo metodo =
                Form.GetType().GetMethod(
                    "ActualizarVistaPreviaMultiple",
                    new Type[] { typeof(List<VigaLongitudinalPreview>) });

            if (metodo != null)
            {
                metodo.Invoke(Form, new object[] { vistas });
                return;
            }
        }
        catch
        {
            // Si aún no existe el método en la ventana, se usa el método anterior.
        }

        VigaLongitudinalPreview ultima = vistas.Last();

        Form.ActualizarVistaPrevia(
            ultima.LongitudMm,
            ultima.Columnas,
            ultima.Nombre);
    }

    // =====================================
    // CONSTRUIR DATOS DE UNA VIGA PARA VISTA PRELIMINAR
    // =====================================
    private VigaLongitudinalPreview ConstruirVistaPreviaDesdeViga(
        Document doc,
        Element viga)
    {
        if (doc == null || viga == null)
            return null;

        Curve curva = ObtenerCurvaElemento(viga);

        if (curva == null)
            return null;

        XYZ p0 = curva.GetEndPoint(0);
        XYZ p1 = curva.GetEndPoint(1);

        if (p0 == null || p1 == null)
            return null;

        XYZ ejeReal3D = p1 - p0;
        double longitudReal3D = ejeReal3D.GetLength();

        if (longitudReal3D <= Tol)
            return null;

        ejeReal3D = ejeReal3D.Normalize();

        // Para la longitud 2D se usa el eje horizontal cuando sea posible,
        // pero los límites se obtienen exclusivamente del sólido REAL de la
        // viga seleccionada. No se consulta ninguna otra categoría del modelo.
        XYZ p0Preview = new XYZ(p0.X, p0.Y, 0.0);
        XYZ p1Preview = new XYZ(p1.X, p1.Y, 0.0);
        XYZ ejePreview = p1Preview - p0Preview;
        double longitudEjePreview = ejePreview.GetLength();

        if (longitudEjePreview <= Tol)
        {
            p0Preview = p0;
            ejePreview = ejeReal3D;
            longitudEjePreview = longitudReal3D;
        }
        else
        {
            ejePreview = ejePreview.Normalize();
        }

        double solidoMin = 0.0;
        double solidoMax = longitudEjePreview;

        ObtenerIntervaloSolidoElementoEnDireccion(
            viga,
            p0Preview,
            ejePreview,
            out solidoMin,
            out solidoMax);

        if (solidoMax <= solidoMin + Tol)
        {
            solidoMin = 0.0;
            solidoMax = longitudEjePreview;
        }

        double longitudFisica = solidoMax - solidoMin;

        if (longitudFisica <= Tol)
            return null;

        double longitudFisicaMm = UnitUtils.ConvertFromInternalUnits(
            longitudFisica,
            UnitTypeId.Millimeters);

        // IMPORTANTE:
        // Columnas queda deliberadamente vacía. La vista preliminar ya no lee,
        // representa ni usa columnas, zapatas, vigas transversales, muros ni
        // ningún otro elemento del entorno. Cada viga seleccionada constituye
        // un tramo independiente con su longitud física real.
        List<AceroLongitudinalVigasForm.ColumnaPreview> apoyosVacios =
            new List<AceroLongitudinalVigasForm.ColumnaPreview>();

        VigaLongitudinalPreview preview = new VigaLongitudinalPreview(
            longitudFisicaMm,
            apoyosVacios,
            ObtenerNombreElemento(viga));

        preview.LongitudSolidoMm = longitudFisicaMm;

        double deltaZ = p1.Z - p0.Z;
        double deltaZMm = UnitUtils.ConvertFromInternalUnits(
            deltaZ,
            UnitTypeId.Millimeters);

        double anguloGrados = 0.0;

        if (longitudReal3D > Tol)
            anguloGrados = Math.Asin(Math.Max(-1.0, Math.Min(1.0, deltaZ / longitudReal3D))) * 180.0 / Math.PI;

        preview.DeltaZMm = deltaZMm;
        preview.ProyeccionHorizontalMm = longitudFisicaMm;
        preview.AnguloGrados = anguloGrados;
        preview.EsInclinada = Math.Abs(deltaZMm) > 1.0 && Math.Abs(anguloGrados) > 0.1;

        // Perfil y forma se calculan únicamente a partir de la propia viga.
        AsignarPerfilSeccionVariablePreview(
            viga,
            p0,
            ejeReal3D,
            preview);

        AsignarFormaSeccionDetectadaPreview(
            viga,
            p0,
            ejeReal3D,
            preview);

        // Contorno transversal real para el editor 2D de acero.
        AsignarContornoSeccionRealPreview(
            viga,
            p0,
            ejeReal3D,
            preview);

        // Vista 3D: exclusivamente los sólidos reales de la viga seleccionada.
        // Si la viga está recortada, unida, inclinada o tiene sección variable,
        // se muestra exactamente la geometría que devuelve Revit para ese elemento.
        preview.Solidos3D = ConstruirSolidos3DPreviewDesdeElemento(viga);

        // NUEVO:
        // Se detectan los cuerpos continuos del sólido REAL sobre el eje de la viga.
        // Si un corte atraviesa toda la sección y divide el mismo ElementId en dos,
        // se guardan dos intervalos independientes para la vista preliminar 2D.
        preview.IntervalosSolidoMm =
            ObtenerIntervalosContinuosSolidoElementoEnDireccionMYG(
                viga,
                p0Preview,
                ejePreview,
                solidoMin,
                solidoMax);

        if (preview.IntervalosSolidoMm == null ||
            preview.IntervalosSolidoMm.Count == 0)
        {
            preview.IntervalosSolidoMm =
                new List<VigaLongitudinalPreview.IntervaloSolidoPreview>()
                {
                    new VigaLongitudinalPreview.IntervaloSolidoPreview(
                        0.0,
                        longitudFisicaMm)
                };
        }

        return preview;
    }


    // =====================================
    // CONTORNO TRANSVERSAL REAL PARA EL EDITOR 2D
    // =====================================
    private void AsignarContornoSeccionRealPreview(
        Element elem,
        XYZ p0,
        XYZ xAxis,
        VigaLongitudinalPreview preview)
    {
        if (preview == null)
            return;

        List<AceroVigaPuntoMm> resultado =
            new List<AceroVigaPuntoMm>();

        List<PuntoYZPreview> puntos =
            ObtenerPuntosPerfilYZPreview(elem, p0, xAxis);

        if (puntos != null && puntos.Count >= 3)
        {
            List<PuntoYZPreview> contorno = ConstruirHullYZPreview(
                DepurarPuntosYZPreview(puntos));

            contorno = LimpiarColinealesYZPreview(
                contorno,
                UnitUtils.ConvertToInternalUnits(
                    1.0,
                    UnitTypeId.Millimeters));

            if (contorno != null && contorno.Count >= 3)
            {
                foreach (PuntoYZPreview puntoPerfil in contorno)
                {
                    if (puntoPerfil == null)
                        continue;

                    resultado.Add(
                        new AceroVigaPuntoMm(
                            UnitUtils.ConvertFromInternalUnits(
                                puntoPerfil.Y,
                                UnitTypeId.Millimeters),
                            UnitUtils.ConvertFromInternalUnits(
                                puntoPerfil.Z,
                                UnitTypeId.Millimeters)));
                }
            }
        }

        AceroVigaContornoPreviewCompartido.Establecer(
            preview,
            resultado);
    }

    // =====================================
    // DETECCIÓN DE FORMA DE SECCIÓN PARA EL SELECTOR GLOBAL
    // =====================================
    private void AsignarFormaSeccionDetectadaPreview(
        Element elem,
        XYZ p0,
        XYZ xAxis,
        VigaLongitudinalPreview preview)
    {
        if (elem == null || preview == null)
            return;

        // =========================================================
        // DETECCIÓN 100% GEOMÉTRICA
        // =========================================================
        // Regla solicitada:
        // - Si la sección transversal geométrica tiene 4 lados => Rectangular.
        // - Si tiene más de 4 lados, recién se evalúa si corresponde a cumbrera.
        // - No se usa nombre/tipo/familia como criterio de forma.
        int lados = ContarLadosSeccionTransversalPreview(elem, p0, xAxis);
        bool porGeometria = lados > 4 && DetectarCumbreraPorGeometriaPreview(elem, p0, xAxis);

        preview.LadosSeccionTransversalDetectados = lados;
        preview.EsCumbreraDetectada = porGeometria;

        if (porGeometria)
            preview.MotivoDeteccionForma = "Geometría real: " + lados.ToString() + " lados con quiebre tipo cumbrera";
        else if (lados == 4)
            preview.MotivoDeteccionForma = "Geometría real: 4 lados = rectangular/trapezoidal";
        else if (lados > 0)
            preview.MotivoDeteccionForma = "Geometría real: " + lados.ToString() + " lados";
        else
            preview.MotivoDeteccionForma = "Sin geometría transversal confiable";
    }

    private bool NombreElementoIndicaCumbrera(Element elem)
    {
        if (elem == null)
            return false;

        List<string> textos = new List<string>();

        try { textos.Add(elem.Name ?? ""); } catch { }

        try
        {
            ElementId tipoId = elem.GetTypeId();

            if (tipoId != null && tipoId != ElementId.InvalidElementId)
            {
                Element tipo = elem.Document.GetElement(tipoId);

                if (tipo != null)
                {
                    textos.Add(tipo.Name ?? "");

                    FamilySymbol fs = tipo as FamilySymbol;
                    if (fs != null && fs.Family != null)
                        textos.Add(fs.Family.Name ?? "");
                }
            }
        }
        catch
        {
        }

        foreach (string t in textos)
        {
            if (string.IsNullOrWhiteSpace(t))
                continue;

            string s = t.Trim().ToLowerInvariant();

            if (s.Contains("cumbrera") ||
                s.Contains("cumbr") ||
                s.Contains("cumbre") ||
                s.Contains("ridge"))
            {
                return true;
            }
        }

        return false;
    }

    private int ContarLadosSeccionTransversalPreview(
        Element elem,
        XYZ p0,
        XYZ xAxis)
    {
        List<PuntoYZPreview> puntos = ObtenerPuntosPerfilYZPreview(elem, p0, xAxis);

        return ContarLadosGeometricosDesdePuntosYZPreview(puntos);
    }

    private int ContarLadosGeometricosDesdePuntosYZPreview(
        List<PuntoYZPreview> puntos)
    {
        List<PuntoYZPreview> pts = DepurarPuntosYZPreview(puntos);

        if (pts == null || pts.Count < 3)
            return 0;

        if (pts.Count <= 4)
            return pts.Count;

        // Si existe quiebre real superior/inferior, la sección no debe reducirse
        // al hull de 4 lados, porque allí se pierde el vértice de cumbrera.
        if (TieneQuiebreInternoTipoCumbreraYZPreview(pts))
            return Math.Max(5, pts.Count);

        List<PuntoYZPreview> hull = ConstruirHullYZPreview(pts);
        hull = LimpiarColinealesYZPreview(
            hull,
            UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Millimeters));

        return hull == null ? 0 : hull.Count;
    }

    private List<PuntoYZPreview> DepurarPuntosYZPreview(
        List<PuntoYZPreview> puntos)
    {
        List<PuntoYZPreview> resultado = new List<PuntoYZPreview>();

        if (puntos == null)
            return resultado;

        double tolPunto = UnitUtils.ConvertToInternalUnits(
            2.0,
            UnitTypeId.Millimeters);

        foreach (PuntoYZPreview p in puntos)
        {
            if (p == null)
                continue;

            bool existe = resultado.Any(q =>
                Math.Abs(q.Y - p.Y) <= tolPunto &&
                Math.Abs(q.Z - p.Z) <= tolPunto);

            if (!existe)
                resultado.Add(new PuntoYZPreview(p.Y, p.Z));
        }

        return resultado;
    }

    private bool DetectarCumbreraPorGeometriaPreview(
        Element elem,
        XYZ p0,
        XYZ xAxis)
    {
        List<PuntoYZPreview> puntos = ObtenerPuntosPerfilYZPreview(elem, p0, xAxis);

        if (puntos == null || puntos.Count < 5)
            return false;

        int lados = ContarLadosGeometricosDesdePuntosYZPreview(puntos);

        // Regla base: 4 lados reales = rectangular/trapezoidal.
        if (lados <= 4)
            return false;

        if (TieneQuiebreInternoTipoCumbreraYZPreview(puntos))
            return true;

        List<PuntoYZPreview> hull = ConstruirHullYZPreview(puntos);
        hull = LimpiarColinealesYZPreview(
            hull,
            UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Millimeters));

        if (hull == null || hull.Count <= 4)
            return false;

        return TieneQuiebreInternoTipoCumbreraYZPreview(hull);
    }

    private class PuntoYZPreview
    {
        public double Y;
        public double Z;

        public PuntoYZPreview(double y, double z)
        {
            Y = y;
            Z = z;
        }
    }

    private List<PuntoYZPreview> ObtenerPuntosPerfilYZPreview(
        Element elem,
        XYZ p0,
        XYZ xAxis)
    {
        List<PuntoYZPreview> resultado = new List<PuntoYZPreview>();

        if (elem == null || p0 == null || xAxis == null)
            return resultado;

        bool esCurva = false;

        // Para arcos y otras curvas, la sección se toma en el punto medio y con
        // la tangente local. Proyectar toda la curva contra la cuerda extremo a
        // extremo produciría un contorno artificialmente ancho.
        try
        {
            LocationCurve lc = elem.Location as LocationCurve;
            Curve eje = lc != null ? lc.Curve : null;

            if (eje != null && !(eje is Line) && eje.IsBound)
            {
                XYZ puntoMedio = eje.Evaluate(0.5, true);
                Transform derivadas = eje.ComputeDerivatives(0.5, true);
                XYZ tangente = derivadas != null ? derivadas.BasisX : null;

                if (puntoMedio != null && tangente != null && tangente.GetLength() > Tol)
                {
                    p0 = puntoMedio;
                    xAxis = tangente.Normalize();
                    esCurva = true;
                }
            }
        }
        catch
        {
            esCurva = false;
        }

        if (xAxis.GetLength() <= Tol)
            return resultado;

        xAxis = xAxis.Normalize();

        XYZ yAxis = XYZ.BasisZ.CrossProduct(xAxis);

        if (yAxis.GetLength() <= Tol)
            yAxis = XYZ.BasisX.CrossProduct(xAxis);

        if (yAxis.GetLength() <= Tol)
            yAxis = XYZ.BasisY;

        yAxis = yAxis.Normalize();

        XYZ zAxis = xAxis.CrossProduct(yAxis);

        if (zAxis.GetLength() <= Tol)
            zAxis = XYZ.BasisZ;

        zAxis = zAxis.Normalize();

        if (zAxis.DotProduct(XYZ.BasisZ) < 0.0)
            zAxis = zAxis.Multiply(-1.0);

        List<XYZ> puntos = ObtenerPuntosSolidoElementoPreview(elem);

        if (puntos == null || puntos.Count == 0)
            puntos = ObtenerPuntosBoundingBoxElementoPreview(elem);

        if (puntos == null || puntos.Count == 0)
            return resultado;

        if (esCurva)
        {
            double ventana = Math.Max(
                UnitUtils.ConvertToInternalUnits(12.0, UnitTypeId.Centimeters),
                UnitUtils.ConvertToInternalUnits(35.0, UnitTypeId.Centimeters));

            List<XYZ> banda = puntos
                .Where(x => x != null)
                .Where(x => Math.Abs((x - p0).DotProduct(xAxis)) <= ventana)
                .ToList();

            if (banda.Count >= 4)
                puntos = banda;
            else
            {
                puntos = puntos
                    .Where(x => x != null)
                    .OrderBy(x => Math.Abs((x - p0).DotProduct(xAxis)))
                    .Take(Math.Min(80, puntos.Count))
                    .ToList();
            }
        }

        // Deduplicación en 5 mm para limpiar triangulación del sólido.
        double pasoFt = UnitUtils.ConvertToInternalUnits(5.0, UnitTypeId.Millimeters);
        HashSet<string> usados = new HashSet<string>();

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            double y = (p - p0).DotProduct(yAxis);
            double z = (p - p0).DotProduct(zAxis);

            double yg = Math.Round(y / pasoFt) * pasoFt;
            double zg = Math.Round(z / pasoFt) * pasoFt;

            string clave = yg.ToString("0.000000") + "|" + zg.ToString("0.000000");

            if (usados.Contains(clave))
                continue;

            usados.Add(clave);
            resultado.Add(new PuntoYZPreview(yg, zg));
        }

        return resultado;
    }

    private List<PuntoYZPreview> ConstruirHullYZPreview(List<PuntoYZPreview> puntos)
    {
        List<PuntoYZPreview> pts = puntos == null
            ? new List<PuntoYZPreview>()
            : puntos
                .Where(p => p != null)
                .OrderBy(p => p.Y)
                .ThenBy(p => p.Z)
                .ToList();

        if (pts.Count <= 3)
            return pts;

        List<PuntoYZPreview> lower = new List<PuntoYZPreview>();
        foreach (PuntoYZPreview p in pts)
        {
            while (lower.Count >= 2 && CruzYZPreview(lower[lower.Count - 2], lower[lower.Count - 1], p) <= 0.0)
                lower.RemoveAt(lower.Count - 1);

            lower.Add(p);
        }

        List<PuntoYZPreview> upper = new List<PuntoYZPreview>();
        for (int i = pts.Count - 1; i >= 0; i--)
        {
            PuntoYZPreview p = pts[i];

            while (upper.Count >= 2 && CruzYZPreview(upper[upper.Count - 2], upper[upper.Count - 1], p) <= 0.0)
                upper.RemoveAt(upper.Count - 1);

            upper.Add(p);
        }

        lower.RemoveAt(lower.Count - 1);
        upper.RemoveAt(upper.Count - 1);

        lower.AddRange(upper);
        return lower;
    }

    private double CruzYZPreview(PuntoYZPreview a, PuntoYZPreview b, PuntoYZPreview c)
    {
        return ((b.Y - a.Y) * (c.Z - a.Z)) -
               ((b.Z - a.Z) * (c.Y - a.Y));
    }

    private List<PuntoYZPreview> LimpiarColinealesYZPreview(
        List<PuntoYZPreview> puntos,
        double tolerancia)
    {
        List<PuntoYZPreview> resultado = new List<PuntoYZPreview>();

        if (puntos == null || puntos.Count <= 3)
            return puntos ?? resultado;

        for (int i = 0; i < puntos.Count; i++)
        {
            PuntoYZPreview prev = puntos[(i - 1 + puntos.Count) % puntos.Count];
            PuntoYZPreview act = puntos[i];
            PuntoYZPreview next = puntos[(i + 1) % puntos.Count];

            double area2 = Math.Abs(CruzYZPreview(prev, act, next));
            double baseLen = Math.Sqrt(
                ((next.Y - prev.Y) * (next.Y - prev.Y)) +
                ((next.Z - prev.Z) * (next.Z - prev.Z)));

            double altura = baseLen <= Tol ? 0.0 : area2 / baseLen;

            if (altura > tolerancia)
                resultado.Add(act);
        }

        return resultado;
    }

    private bool TieneQuiebreInternoTipoCumbreraYZPreview(List<PuntoYZPreview> puntos)
    {
        if (puntos == null || puntos.Count < 5)
            return false;

        double yMin = puntos.Min(p => p.Y);
        double yMax = puntos.Max(p => p.Y);
        double zMin = puntos.Min(p => p.Z);
        double zMax = puntos.Max(p => p.Z);

        double ancho = yMax - yMin;
        double peralte = zMax - zMin;

        if (ancho <= Tol || peralte <= Tol)
            return false;

        double yCentro = (yMin + yMax) / 2.0;
        double margenCentral = ancho * 0.30;
        double margenLateral = ancho * 0.18;
        double toleranciaQuiebre = Math.Max(
            UnitUtils.ConvertToInternalUnits(15.0, UnitTypeId.Millimeters),
            peralte * 0.035);

        PuntoYZPreview topCentro = puntos
            .Where(p => p != null && Math.Abs(p.Y - yCentro) <= margenCentral)
            .OrderByDescending(p => p.Z)
            .FirstOrDefault();

        PuntoYZPreview topIzq = puntos
            .Where(p => p != null && p.Y <= yCentro - margenLateral)
            .OrderByDescending(p => p.Z)
            .FirstOrDefault();

        PuntoYZPreview topDer = puntos
            .Where(p => p != null && p.Y >= yCentro + margenLateral)
            .OrderByDescending(p => p.Z)
            .FirstOrDefault();

        if (topCentro != null && topIzq != null && topDer != null)
        {
            double zLinea = InterpolarZEnYPreview(topIzq.Y, topIzq.Z, topDer.Y, topDer.Z, topCentro.Y);

            if (topCentro.Z - zLinea >= toleranciaQuiebre)
                return true;
        }

        PuntoYZPreview botCentro = puntos
            .Where(p => p != null && Math.Abs(p.Y - yCentro) <= margenCentral)
            .OrderBy(p => p.Z)
            .FirstOrDefault();

        PuntoYZPreview botIzq = puntos
            .Where(p => p != null && p.Y <= yCentro - margenLateral)
            .OrderBy(p => p.Z)
            .FirstOrDefault();

        PuntoYZPreview botDer = puntos
            .Where(p => p != null && p.Y >= yCentro + margenLateral)
            .OrderBy(p => p.Z)
            .FirstOrDefault();

        if (botCentro != null && botIzq != null && botDer != null)
        {
            double zLinea = InterpolarZEnYPreview(botIzq.Y, botIzq.Z, botDer.Y, botDer.Z, botCentro.Y);

            if (zLinea - botCentro.Z >= toleranciaQuiebre)
                return true;
        }

        return false;
    }

    private double InterpolarZEnYPreview(
        double y1,
        double z1,
        double y2,
        double z2,
        double y)
    {
        if (Math.Abs(y2 - y1) <= Tol)
            return (z1 + z2) / 2.0;

        double t = (y - y1) / (y2 - y1);
        return z1 + (z2 - z1) * t;
    }

    // =====================================
    // DETECTAR VIGAS TRANSVERSALES COMO APOYOS
    // =====================================
    private List<VigaTransversalDetectada> DetectarVigasTransversalesComoApoyos(
        Document doc,
        Element vigaPrincipal,
        XYZ p0,
        XYZ p1)
    {
        List<VigaTransversalDetectada> resultado =
            new List<VigaTransversalDetectada>();

        if (doc == null || vigaPrincipal == null)
            return resultado;

        Curve curvaPrincipalReal = ObtenerCurvaElemento(vigaPrincipal);

        if (curvaPrincipalReal == null)
            return resultado;

        XYZ p0Real = curvaPrincipalReal.GetEndPoint(0);
        XYZ p1Real = curvaPrincipalReal.GetEndPoint(1);

        XYZ ejeReal = p1Real - p0Real;
        double longitudReal = ejeReal.GetLength();

        if (longitudReal <= Tol)
            return resultado;

        ejeReal = ejeReal.Normalize();

        // Eje de trabajo para la vista 2D: se mantiene en planta para que
        // los tramos/cotas de la ventana sigan comportándose como antes.
        XYZ p0Plano = new XYZ(p0Real.X, p0Real.Y, 0.0);
        XYZ p1Plano = new XYZ(p1Real.X, p1Real.Y, 0.0);

        XYZ eje = p1Plano - p0Plano;
        double longitud = eje.GetLength();

        if (longitud <= Tol)
        {
            p0Plano = p0Real;
            p1Plano = p1Real;
            eje = ejeReal;
            longitud = longitudReal;
        }
        else
        {
            eje = eje.Normalize();
        }

        BoundingBoxXYZ bbViga = vigaPrincipal.get_BoundingBox(null);

        if (bbViga == null)
            return resultado;

        // Para vigas inclinadas de cubierta a dos aguas NO conviene usar un
        // margen Z pequeño ni una intersección 2D estricta, porque la otra agua
        // puede quedar separada/desfasada en planta o en altura aunque sí sea
        // parte del encuentro estructural. Se amplía el rango inicial y luego se
        // filtra con distancia real 3D entre ejes de viga.
        double margenBboxXY = UnitUtils.ConvertToInternalUnits(
            250.0,
            UnitTypeId.Centimeters);

        double margenBboxZ = UnitUtils.ConvertToInternalUnits(
            250.0,
            UnitTypeId.Centimeters);

        XYZ min = new XYZ(
            bbViga.Min.X - margenBboxXY,
            bbViga.Min.Y - margenBboxXY,
            bbViga.Min.Z - margenBboxZ);

        XYZ max = new XYZ(
            bbViga.Max.X + margenBboxXY,
            bbViga.Max.Y + margenBboxXY,
            bbViga.Max.Z + margenBboxZ);

        Outline outline = new Outline(min, max);

        BoundingBoxIntersectsFilter filtroBbox =
            new BoundingBoxIntersectsFilter(outline);

        List<Element> candidatos = new List<Element>();

        AgregarColumnasPorCategoria(
            doc,
            candidatos,
            BuiltInCategory.OST_StructuralFraming,
            filtroBbox);

        candidatos = candidatos
            .Where(x => x != null)
            .GroupBy(x => x.Id.Value)
            .Select(g => g.First())
            .ToList();

        // Filtros para vigas transversales/inclinadas.
        // Antes el rango y la distancia 3D eran muy permisivos; por eso se colaban
        // vigas cercanas que no tocaban realmente la viga seleccionada.
        double toleranciaContactoSolido3D = UnitUtils.ConvertToInternalUnits(
            20.0,
            UnitTypeId.Centimeters);

        // Si los ejes casi se tocan, se acepta aunque el encuentro ocurra en medio
        // de la viga transversal.
        double toleranciaEncuentroDirecto3D = UnitUtils.ConvertToInternalUnits(
            8.0,
            UnitTypeId.Centimeters);

        // Si la distancia es mayor, solo se acepta cuando la viga transversal llega
        // con uno de sus extremos al encuentro. Esto conserva las vigas de dos aguas
        // y descarta vigas vecinas que solo pasan cerca.
        double toleranciaEncuentroConExtremo3D = UnitUtils.ConvertToInternalUnits(
            25.0,
            UnitTypeId.Centimeters);

        // Respaldo 2D muy estricto, solo para casos horizontales donde los ejes
        // cruzan en planta y además las cajas están realmente pegadas.
        double toleranciaCruce2D = UnitUtils.ConvertToInternalUnits(
            10.0,
            UnitTypeId.Centimeters);

        double toleranciaExtremos = UnitUtils.ConvertToInternalUnits(
            60.0,
            UnitTypeId.Centimeters);

        foreach (Element candidato in candidatos)
        {
            if (candidato == null)
                continue;

            if (candidato.Id == vigaPrincipal.Id)
                continue;

            if (VigasSeleccionadas != null && VigasSeleccionadas.Contains(candidato.Id))
                continue;

            Curve curvaTransversal = ObtenerCurvaElemento(candidato);

            if (curvaTransversal == null)
                continue;

            XYZ q0Real = curvaTransversal.GetEndPoint(0);
            XYZ q1Real = curvaTransversal.GetEndPoint(1);

            XYZ ejeCandidatoReal = q1Real - q0Real;

            if (ejeCandidatoReal.GetLength() <= Tol)
                continue;

            BoundingBoxXYZ bbCandidato = candidato.get_BoundingBox(null);

            if (bbCandidato == null)
                continue;

            XYZ direccionCandidatoReal = ejeCandidatoReal.Normalize();
            double paralelismo3D = Math.Abs(direccionCandidatoReal.DotProduct(ejeReal));

            // Si es casi paralela a la viga seleccionada, no se considera apoyo
            // transversal. Esto elimina vigas de la misma dirección que entraban
            // por cercanía del BoundingBox.
            if (paralelismo3D > 0.93)
                continue;

            // Primero se exige cercanía real entre sólidos mediante BoundingBox 3D.
            // Si la separación entre cajas supera este valor, la viga no está
            // adyacente ni intersectando a la seleccionada.
            double separacionSolido3D = ObtenerSeparacionMinimaBoundingBox3D(
                bbViga,
                bbCandidato);

            if (separacionSolido3D > toleranciaContactoSolido3D)
                continue;

            // =========================================================
            // FILTRO PRINCIPAL PARA VIGAS INCLINADAS:
            // distancia mínima real 3D entre el eje de la viga seleccionada
            // y el eje de la viga candidata.
            // =========================================================
            double tPrincipal3D = 0.0;
            double tCandidato3D = 0.0;
            XYZ puntoPrincipal3D = null;
            XYZ puntoCandidato3D = null;

            double distancia3D = ObtenerDistanciaMinimaSegmentos3D(
                p0Real,
                p1Real,
                q0Real,
                q1Real,
                out tPrincipal3D,
                out tCandidato3D,
                out puntoPrincipal3D,
                out puntoCandidato3D);

            bool principalEnRango3D =
                tPrincipal3D >= -0.04 &&
                tPrincipal3D <= 1.04;

            bool candidatoEnRango3D =
                tCandidato3D >= -0.04 &&
                tCandidato3D <= 1.04;

            // En cubiertas a dos aguas, la viga transversal normalmente llega al
            // caballete con uno de sus extremos. Esta condición evita captar vigas
            // vecinas que pasan cerca pero no conectan con la seleccionada.
            bool candidatoConectaPorExtremo =
                tCandidato3D <= 0.12 ||
                tCandidato3D >= 0.88;

            bool aceptaPorDistancia3D = false;

            if (principalEnRango3D && candidatoEnRango3D)
            {
                if (distancia3D <= toleranciaEncuentroDirecto3D)
                {
                    aceptaPorDistancia3D = true;
                }
                else if (distancia3D <= toleranciaEncuentroConExtremo3D &&
                         candidatoConectaPorExtremo)
                {
                    aceptaPorDistancia3D = true;
                }
            }

            // =========================================================
            // RESPALDO 2D ESTRICTO:
            // Solo se usa si además existe solape vertical y contacto en planta.
            // No debe aceptar vigas que solo cruzan visualmente en planta.
            // =========================================================
            XYZ q0Plano = new XYZ(q0Real.X, q0Real.Y, 0.0);
            XYZ q1Plano = new XYZ(q1Real.X, q1Real.Y, 0.0);

            double posicionEnEje = 0.0;
            double distanciaCruce2D = double.MaxValue;
            bool aceptaPorCruce2D = false;

            if (!aceptaPorDistancia3D)
            {
                double toleranciaZRespaldo = UnitUtils.ConvertToInternalUnits(
                    10.0,
                    UnitTypeId.Centimeters);

                double toleranciaPlantaRespaldo = UnitUtils.ConvertToInternalUnits(
                    5.0,
                    UnitTypeId.Centimeters);

                bool tieneSolapeZ = TieneSolapeVerticalConViga(
                    bbViga,
                    bbCandidato,
                    toleranciaZRespaldo);

                bool estaPegadaEnPlanta = EstaPegadoALaVigaEnPlanta(
                    bbViga,
                    bbCandidato,
                    toleranciaPlantaRespaldo);

                if (tieneSolapeZ && estaPegadaEnPlanta)
                {
                    double tMain = 0.0;
                    double tTransversal = 0.0;

                    if (ObtenerInterseccionSegmentos2D(
                        p0Plano,
                        p1Plano,
                        q0Plano,
                        q1Plano,
                        out tMain,
                        out tTransversal))
                    {
                        posicionEnEje = tMain * longitud;
                        distanciaCruce2D = 0.0;
                        aceptaPorCruce2D = true;
                    }
                    else
                    {
                        aceptaPorCruce2D = ObtenerCruceAproximadoConEje(
                            p0Plano,
                            p1Plano,
                            q0Plano,
                            q1Plano,
                            eje,
                            longitud,
                            out posicionEnEje,
                            out distanciaCruce2D);
                    }

                    if (aceptaPorCruce2D)
                    {
                        aceptaPorCruce2D =
                            distanciaCruce2D <= toleranciaCruce2D &&
                            posicionEnEje >= -toleranciaExtremos &&
                            posicionEnEje <= longitud + toleranciaExtremos;
                    }
                }
            }

            if (!aceptaPorDistancia3D && !aceptaPorCruce2D)
                continue;

            // Si se aceptó por distancia 3D, se calcula la posición en el eje
            // usando el punto real más cercano sobre la viga principal.
            if (aceptaPorDistancia3D && puntoPrincipal3D != null)
            {
                XYZ puntoPlano = new XYZ(
                    puntoPrincipal3D.X,
                    puntoPrincipal3D.Y,
                    eje == ejeReal ? puntoPrincipal3D.Z : 0.0);

                posicionEnEje = (puntoPlano - p0Plano).DotProduct(eje);
            }

            if (posicionEnEje < -toleranciaExtremos)
                continue;

            if (posicionEnEje > longitud + toleranciaExtremos)
                continue;

            double posicionMm = UnitUtils.ConvertFromInternalUnits(
                posicionEnEje,
                UnitTypeId.Millimeters);

            double anchoMm = ObtenerAnchoApoyoVigaTransversalMm(
                candidato,
                p0Plano,
                eje);

            if (anchoMm <= 0.0)
                anchoMm = 250.0;

            string nombre = ObtenerNombreElemento(candidato);

            if (string.IsNullOrWhiteSpace(nombre))
                nombre = "Viga transversal";

            resultado.Add(
                new VigaTransversalDetectada()
                {
                    Elemento = candidato,
                    Preview = new AceroLongitudinalVigasForm.ColumnaPreview(
                        posicionMm,
                        anchoMm,
                        "Viga transversal - " + nombre)
                });
        }

        resultado = resultado
            .Where(x => x != null && x.Preview != null)
            .OrderBy(x => x.Preview.CentroMm)
            .ToList();

        // IMPORTANTE:
        // No se fusionan aquí las vigas transversales con el mismo CentroMm.
        // En cubiertas a dos aguas normalmente hay dos vigas iguales que llegan
        // al mismo punto de la viga seleccionada, una por cada lado. Si se fusionan
        // aquí, se conserva solo el primer ElementId y la otra viga desaparece
        // de la vista 3D de Revit y del preview 3D.
        //
        // La limpieza de apoyos repetidos para la vista 2D ya se hace después en:
        // FusionarColumnasPreviewDuplicadas(columnas)
        // Por eso aquí se devuelven todos los Elementos detectados.
        return resultado;
    }

    // =====================================
    // DISTANCIA REAL 3D ENTRE DOS SEGMENTOS
    // Evita perder vigas inclinadas de cubiertas a dos aguas.
    // =====================================
    private double ObtenerDistanciaMinimaSegmentos3D(
        XYZ p1,
        XYZ q1,
        XYZ p2,
        XYZ q2,
        out double s,
        out double t,
        out XYZ punto1,
        out XYZ punto2)
    {
        s = 0.0;
        t = 0.0;
        punto1 = p1;
        punto2 = p2;

        if (p1 == null || q1 == null || p2 == null || q2 == null)
            return double.MaxValue;

        XYZ d1 = q1 - p1;
        XYZ d2 = q2 - p2;
        XYZ r = p1 - p2;

        double a = d1.DotProduct(d1);
        double e = d2.DotProduct(d2);
        double f = d2.DotProduct(r);

        if (a <= Tol && e <= Tol)
        {
            punto1 = p1;
            punto2 = p2;
            return p1.DistanceTo(p2);
        }

        if (a <= Tol)
        {
            s = 0.0;
            t = Limitar01(f / e);
        }
        else
        {
            double c = d1.DotProduct(r);

            if (e <= Tol)
            {
                t = 0.0;
                s = Limitar01(-c / a);
            }
            else
            {
                double b = d1.DotProduct(d2);
                double denom = (a * e) - (b * b);

                if (Math.Abs(denom) > Tol)
                    s = Limitar01(((b * f) - (c * e)) / denom);
                else
                    s = 0.0;

                double tNom = (b * s) + f;

                if (tNom < 0.0)
                {
                    t = 0.0;
                    s = Limitar01(-c / a);
                }
                else if (tNom > e)
                {
                    t = 1.0;
                    s = Limitar01((b - c) / a);
                }
                else
                {
                    t = tNom / e;
                }
            }
        }

        punto1 = p1 + d1.Multiply(s);
        punto2 = p2 + d2.Multiply(t);

        return punto1.DistanceTo(punto2);
    }

    private double Limitar01(double valor)
    {
        if (double.IsNaN(valor) || double.IsInfinity(valor))
            return 0.0;

        if (valor < 0.0)
            return 0.0;

        if (valor > 1.0)
            return 1.0;

        return valor;
    }

    private bool ObtenerInterseccionSegmentos2D(
        XYZ p0,
        XYZ p1,
        XYZ q0,
        XYZ q1,
        out double tMain,
        out double tTransversal)
    {
        tMain = 0.0;
        tTransversal = 0.0;

        XYZ r = p1 - p0;
        XYZ s = q1 - q0;

        double den = Cruz2D(r, s);

        if (Math.Abs(den) <= Tol)
            return false;

        XYZ qp = q0 - p0;

        tMain = Cruz2D(qp, s) / den;
        tTransversal = Cruz2D(qp, r) / den;

        double margen = 0.03;

        return tMain >= -margen &&
               tMain <= 1.0 + margen &&
               tTransversal >= -margen &&
               tTransversal <= 1.0 + margen;
    }

    private bool ObtenerCruceAproximadoConEje(
        XYZ p0,
        XYZ p1,
        XYZ q0,
        XYZ q1,
        XYZ eje,
        double longitud,
        out double posicionEnEje,
        out double distancia)
    {
        posicionEnEje = 0.0;
        distancia = double.MaxValue;

        if (eje == null || eje.GetLength() <= Tol)
            return false;

        eje = eje.Normalize();

        double d0 = Cruz2D(eje, q0 - p0);
        double d1 = Cruz2D(eje, q1 - p0);

        if ((d0 <= 0.0 && d1 >= 0.0) ||
            (d0 >= 0.0 && d1 <= 0.0))
        {
            double den = d0 - d1;

            if (Math.Abs(den) > Tol)
            {
                double a = d0 / den;
                a = Math.Max(0.0, Math.Min(1.0, a));

                XYZ punto = q0 + (q1 - q0).Multiply(a);
                posicionEnEje = (punto - p0).DotProduct(eje);
                distancia = 0.0;
                return true;
            }
        }

        double posQ0 = 0.0;
        double distQ0 = DistanciaPuntoASegmento2D(
            q0,
            p0,
            p1,
            eje,
            longitud,
            out posQ0);

        double posQ1 = 0.0;
        double distQ1 = DistanciaPuntoASegmento2D(
            q1,
            p0,
            p1,
            eje,
            longitud,
            out posQ1);

        if (distQ0 <= distQ1)
        {
            posicionEnEje = posQ0;
            distancia = distQ0;
        }
        else
        {
            posicionEnEje = posQ1;
            distancia = distQ1;
        }

        return distancia < double.MaxValue;
    }

    private double DistanciaPuntoASegmento2D(
        XYZ punto,
        XYZ seg0,
        XYZ seg1,
        XYZ ejeSegmento,
        double longitudSegmento,
        out double posicionEnEje)
    {
        posicionEnEje = 0.0;

        if (punto == null || seg0 == null || seg1 == null)
            return double.MaxValue;

        if (ejeSegmento == null || ejeSegmento.GetLength() <= Tol)
            return double.MaxValue;

        ejeSegmento = ejeSegmento.Normalize();

        double t = (punto - seg0).DotProduct(ejeSegmento);
        t = Math.Max(0.0, Math.Min(longitudSegmento, t));

        XYZ proy = seg0 + ejeSegmento.Multiply(t);

        posicionEnEje = t;

        return DistanciaHorizontal(punto, proy);
    }

    private double Cruz2D(XYZ a, XYZ b)
    {
        if (a == null || b == null)
            return 0.0;

        return (a.X * b.Y) - (a.Y * b.X);
    }

    private double ObtenerAnchoApoyoVigaTransversalMm(
        Element vigaTransversal,
        XYZ origen,
        XYZ ejePrincipal)
    {
        if (vigaTransversal == null)
            return 250.0;

        double anchoParametro = LeerParametroDimensionMm(
            vigaTransversal,
            new string[]
            {
                "b",
                "B",
                "Ancho",
                "Width",
                "Base",
                "b ancho",
                "Ancho de viga"
            });

        if (anchoParametro >= 80.0 && anchoParametro <= 900.0)
            return anchoParametro;

        BoundingBoxXYZ bb = vigaTransversal.get_BoundingBox(null);

        if (bb != null && ejePrincipal != null && ejePrincipal.GetLength() > Tol)
        {
            double minEje = 0.0;
            double maxEje = 0.0;

            if (ObtenerIntervaloBoundingBoxEnEje(
                bb,
                origen,
                ejePrincipal,
                out minEje,
                out maxEje))
            {
                double ancho = maxEje - minEje;

                double anchoMm = UnitUtils.ConvertFromInternalUnits(
                    ancho,
                    UnitTypeId.Millimeters);

                // Si la viga transversal está ligeramente inclinada, su largo puede inflar
                // la proyección sobre el eje principal. Por eso se limita para la vista 2D.
                if (anchoMm >= 80.0 && anchoMm <= 600.0)
                    return anchoMm;
            }
        }

        return 250.0;
    }

    private double LeerParametroDimensionMm(
        Element elem,
        string[] nombres)
    {
        if (elem == null || nombres == null)
            return 0.0;

        foreach (string nombre in nombres)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                continue;

            Parameter p = null;

            try
            {
                p = elem.LookupParameter(nombre);
            }
            catch
            {
                p = null;
            }

            if (p == null)
                continue;

            if (p.StorageType != StorageType.Double)
                continue;

            double valor = 0.0;

            try
            {
                valor = p.AsDouble();
            }
            catch
            {
                valor = 0.0;
            }

            if (valor <= Tol)
                continue;

            double valorMm = UnitUtils.ConvertFromInternalUnits(
                valor,
                UnitTypeId.Millimeters);

            if (valorMm > 0.0)
                return valorMm;
        }

        return 0.0;
    }

    // =====================================
    // DETECTAR COLUMNAS ADYACENTES E INTERNAS
    // ENVÍA CENTRO REAL Y ANCHO REAL PROYECTADO SOBRE EL EJE
    // NO CLAMPEA EL CENTRO A 0 NI A LA LONGITUD DE LA VIGA
    // =====================================
    private List<AceroLongitudinalVigasForm.ColumnaPreview> DetectarColumnasAdyacentesEInternas(
        Document doc,
        Element viga,
        XYZ p0,
        XYZ p1)
    {
        List<AceroLongitudinalVigasForm.ColumnaPreview> resultado =
            new List<AceroLongitudinalVigasForm.ColumnaPreview>();

        if (doc == null || viga == null || p0 == null || p1 == null)
            return resultado;

        XYZ p0Plano = new XYZ(p0.X, p0.Y, 0.0);
        XYZ p1Plano = new XYZ(p1.X, p1.Y, 0.0);
        XYZ eje = p1Plano - p0Plano;
        double longitud = eje.GetLength();

        if (longitud <= Tol)
            return resultado;

        eje = eje.Normalize();
        p0 = p0Plano;

        BoundingBoxXYZ bbViga = viga.get_BoundingBox(null);

        if (bbViga == null)
            return resultado;

        List<Element> candidatos = ObtenerCandidatosApoyoPreviewMYG(
            doc,
            bbViga);

        foreach (Element candidato in candidatos)
        {
            if (candidato == null)
                continue;

            double minApoyo;
            double maxApoyo;

            if (!TryObtenerIntervaloApoyoPreviewMYG(
                viga,
                candidato,
                bbViga,
                p0,
                eje,
                longitud,
                out minApoyo,
                out maxApoyo))
            {
                continue;
            }

            double centro = (minApoyo + maxApoyo) / 2.0;
            double ancho = maxApoyo - minApoyo;

            if (ancho <= Tol)
                continue;

            double posicionMm = UnitUtils.ConvertFromInternalUnits(
                centro,
                UnitTypeId.Millimeters);

            double anchoMm = UnitUtils.ConvertFromInternalUnits(
                ancho,
                UnitTypeId.Millimeters);

            resultado.Add(
                new AceroLongitudinalVigasForm.ColumnaPreview(
                    posicionMm,
                    Math.Max(50.0, anchoMm),
                    ObtenerNombreElemento(candidato)));
        }

        resultado = FusionarColumnasPreviewDuplicadas(resultado)
            .OrderBy(c => c.CentroMm)
            .ToList();

        return resultado;
    }


    private List<Element> DetectarColumnasAdyacentesEInternasElementos(
        Document doc,
        Element viga,
        XYZ p0,
        XYZ p1)
    {
        List<Element> resultado = new List<Element>();

        if (doc == null || viga == null || p0 == null || p1 == null)
            return resultado;

        XYZ p0Plano = new XYZ(p0.X, p0.Y, 0.0);
        XYZ p1Plano = new XYZ(p1.X, p1.Y, 0.0);
        XYZ eje = p1Plano - p0Plano;
        double longitud = eje.GetLength();

        if (longitud <= Tol)
            return resultado;

        eje = eje.Normalize();
        p0 = p0Plano;

        BoundingBoxXYZ bbViga = viga.get_BoundingBox(null);

        if (bbViga == null)
            return resultado;

        List<Element> candidatos = ObtenerCandidatosApoyoPreviewMYG(
            doc,
            bbViga);

        foreach (Element candidato in candidatos)
        {
            if (candidato == null)
                continue;

            double minApoyo;
            double maxApoyo;

            if (!TryObtenerIntervaloApoyoPreviewMYG(
                viga,
                candidato,
                bbViga,
                p0,
                eje,
                longitud,
                out minApoyo,
                out maxApoyo))
            {
                continue;
            }

            resultado.Add(candidato);
        }

        return resultado
            .Where(x => x != null)
            .GroupBy(x => x.Id.Value)
            .Select(g => g.First())
            .ToList();
    }

    private List<Element> ObtenerCandidatosApoyoPreviewMYG(
        Document doc,
        BoundingBoxXYZ bbViga)
    {
        List<Element> resultado = new List<Element>();

        if (doc == null || bbViga == null)
            return resultado;

        // El filtro previo solo reduce la colección. La aceptación final se
        // hace con el sólido real, el eje real y tolerancias pequeñas.
        double margenXY = UnitUtils.ConvertToInternalUnits(
            80.0,
            UnitTypeId.Centimeters);

        double margenZ = UnitUtils.ConvertToInternalUnits(
            25.0,
            UnitTypeId.Centimeters);

        Outline outline = new Outline(
            new XYZ(
                bbViga.Min.X - margenXY,
                bbViga.Min.Y - margenXY,
                bbViga.Min.Z - margenZ),
            new XYZ(
                bbViga.Max.X + margenXY,
                bbViga.Max.Y + margenXY,
                bbViga.Max.Z + margenZ));

        BoundingBoxIntersectsFilter filtro =
            new BoundingBoxIntersectsFilter(outline);

        AgregarColumnasPorCategoria(
            doc,
            resultado,
            BuiltInCategory.OST_StructuralColumns,
            filtro);

        AgregarColumnasPorCategoria(
            doc,
            resultado,
            BuiltInCategory.OST_Columns,
            filtro);

        AgregarColumnasPorCategoria(
            doc,
            resultado,
            BuiltInCategory.OST_StructuralFoundation,
            filtro);

        return resultado
            .Where(x => x != null)
            .GroupBy(x => x.Id.Value)
            .Select(g => g.First())
            .ToList();
    }

    private bool TryObtenerIntervaloApoyoPreviewMYG(
        Element viga,
        Element candidato,
        BoundingBoxXYZ bbViga,
        XYZ origen,
        XYZ eje,
        double longitudViga,
        out double minApoyo,
        out double maxApoyo)
    {
        minApoyo = 0.0;
        maxApoyo = 0.0;

        if (viga == null || candidato == null || bbViga == null)
            return false;

        if (candidato.Id == viga.Id)
            return false;

        if (origen == null || eje == null || eje.GetLength() <= Tol)
            return false;

        eje = eje.Normalize();

        BoundingBoxXYZ bbApoyo = null;

        try
        {
            bbApoyo = candidato.get_BoundingBox(null);
        }
        catch
        {
            bbApoyo = null;
        }

        if (bbApoyo == null)
            return false;

        bool esCimentacion = EsCimentacionEstructuralPreviewMYG(candidato);

        double toleranciaPlanta = UnitUtils.ConvertToInternalUnits(
            esCimentacion ? 3.0 : 1.0,
            UnitTypeId.Centimeters);

        // Una zapata puede quedar inmediatamente debajo de la viga o separada
        // por una junta/modelado pequeño. No se permite una búsqueda vertical
        // abierta: 15 cm es solo tolerancia de contacto, no de proximidad general.
        double toleranciaVertical = UnitUtils.ConvertToInternalUnits(
            esCimentacion ? 15.0 : 1.0,
            UnitTypeId.Centimeters);

        if (!EstaPegadoALaVigaEnPlanta(
            bbViga,
            bbApoyo,
            toleranciaPlanta))
        {
            return false;
        }

        if (!EstaPegadoALaVigaEnVertical(
            bbViga,
            bbApoyo,
            toleranciaVertical))
        {
            return false;
        }

        // Para zapatas se mide el intervalo con la geometría real. El
        // BoundingBox global puede inflar mucho el ancho cuando la familia está
        // girada o contiene geometría auxiliar/nidada.
        bool intervaloValido = false;

        if (esCimentacion)
        {
            intervaloValido = ObtenerIntervaloSolidoElementoEnDireccion(
                candidato,
                origen,
                eje,
                out minApoyo,
                out maxApoyo);
        }

        if (!intervaloValido)
        {
            intervaloValido = ObtenerIntervaloBoundingBoxEnEje(
                bbApoyo,
                origen,
                eje,
                out minApoyo,
                out maxApoyo);
        }

        if (!intervaloValido || maxApoyo <= minApoyo + Tol)
            return false;

        double toleranciaExtremo = UnitUtils.ConvertToInternalUnits(
            10.0,
            UnitTypeId.Centimeters);

        // Solo se aceptan apoyos que intersectan el intervalo físico de la
        // viga. Esto elimina zapatas del tramo vecino aunque estén dentro del
        // colector preliminar.
        if (maxApoyo < -toleranciaExtremo)
            return false;

        if (minApoyo > longitudViga + toleranciaExtremo)
            return false;

        double distanciaLateral = ObtenerDistanciaHorizontalMinimaAlEje(
            bbApoyo,
            origen,
            eje,
            longitudViga);

        double toleranciaLateral = UnitUtils.ConvertToInternalUnits(
            esCimentacion ? 10.0 : 5.0,
            UnitTypeId.Centimeters);

        if (distanciaLateral > toleranciaLateral)
            return false;

        if (esCimentacion &&
            !EsCimentacionLocalizadaPreviewMYG(
                candidato,
                bbApoyo,
                eje,
                longitudViga,
                minApoyo,
                maxApoyo))
        {
            return false;
        }

        return true;
    }

    private bool EsCimentacionEstructuralPreviewMYG(Element elemento)
    {
        if (elemento == null || elemento.Category == null)
            return false;

        try
        {
            return elemento.Category.Id.Value ==
                   (long)BuiltInCategory.OST_StructuralFoundation;
        }
        catch
        {
            return false;
        }
    }

    private bool EsCimentacionLocalizadaPreviewMYG(
        Element elemento,
        BoundingBoxXYZ bb,
        XYZ eje,
        double longitudViga,
        double minApoyo,
        double maxApoyo)
    {
        if (elemento == null || bb == null || eje == null)
            return false;

        double longitudApoyo = maxApoyo - minApoyo;

        if (longitudApoyo <= Tol)
            return false;

        XYZ transversal = XYZ.BasisZ.CrossProduct(eje.Normalize());

        if (transversal.GetLength() <= Tol)
            transversal = XYZ.BasisY;

        transversal = transversal.Normalize();

        double anchoTransversal = ObtenerAnchoBoundingBoxEnDireccionPreviewMYG(
            bb,
            transversal);

        double limiteAbsoluto = UnitUtils.ConvertToInternalUnits(
            4.50,
            UnitTypeId.Meters);

        double limiteRelativo = Math.Max(
            UnitUtils.ConvertToInternalUnits(1.50, UnitTypeId.Meters),
            longitudViga * 0.65);

        double limiteLongitudinal = Math.Max(
            limiteAbsoluto,
            limiteRelativo);

        // Una cimentación corrida o una viga de cimentación modelada dentro de
        // OST_StructuralFoundation no debe convertirse en una zapata/apoyo.
        // Las zapatas aisladas o combinadas cortas sí pasan.
        if (longitudApoyo > limiteLongitudinal &&
            longitudApoyo > Math.Max(anchoTransversal * 2.50, limiteAbsoluto))
        {
            return false;
        }

        return true;
    }

    private double ObtenerAnchoBoundingBoxEnDireccionPreviewMYG(
        BoundingBoxXYZ bb,
        XYZ direccion)
    {
        if (bb == null || direccion == null || direccion.GetLength() <= Tol)
            return 0.0;

        direccion = direccion.Normalize();
        List<XYZ> puntos = ObtenerPuntosBoundingBox(bb);

        if (puntos == null || puntos.Count == 0)
            return 0.0;

        double min = double.MaxValue;
        double max = double.MinValue;

        foreach (XYZ p in puntos)
        {
            double d = p.DotProduct(direccion);

            if (d < min) min = d;
            if (d > max) max = d;
        }

        return max > min ? max - min : 0.0;
    }

    private void AgregarColumnasPorCategoria(
        Document doc,
        List<Element> destino,
        BuiltInCategory categoria,
        ElementFilter filtro)
    {
        if (doc == null || destino == null || filtro == null)
            return;

        try
        {
            destino.AddRange(
                new FilteredElementCollector(doc)
                .OfCategory(categoria)
                .WhereElementIsNotElementType()
                .WherePasses(filtro)
                .ToElements());
        }
        catch
        {
            // Ignorar categorías no disponibles.
        }
    }

    private List<AceroLongitudinalVigasForm.ColumnaPreview> FusionarColumnasPreviewDuplicadas(
        List<AceroLongitudinalVigasForm.ColumnaPreview> columnas)
    {
        List<AceroLongitudinalVigasForm.ColumnaPreview> resultado =
            new List<AceroLongitudinalVigasForm.ColumnaPreview>();

        if (columnas == null || columnas.Count == 0)
            return resultado;

        double toleranciaCentroMm = 50.0;

        foreach (AceroLongitudinalVigasForm.ColumnaPreview col in columnas.OrderBy(x => x.CentroMm))
        {
            if (col == null)
                continue;

            if (resultado.Count == 0)
            {
                resultado.Add(col);
                continue;
            }

            AceroLongitudinalVigasForm.ColumnaPreview ultima =
                resultado[resultado.Count - 1];

            if (Math.Abs(ultima.CentroMm - col.CentroMm) <= toleranciaCentroMm)
            {
                double centroPromedio = (ultima.CentroMm + col.CentroMm) / 2.0;
                double anchoMayor = Math.Max(ultima.AnchoMm, col.AnchoMm);

                ultima.CentroMm = centroPromedio;
                ultima.AnchoMm = anchoMayor;

                if (string.IsNullOrWhiteSpace(ultima.Nombre))
                    ultima.Nombre = col.Nombre;
            }
            else
            {
                resultado.Add(col);
            }
        }

        return resultado;
    }

    // =====================================
    // GEOMETRÍA DEL SÓLIDO DE LA VIGA
    // =====================================
    private bool ObtenerIntervaloSolidoElementoEnDireccion(
        Element elem,
        XYZ origen,
        XYZ eje,
        out double minSolido,
        out double maxSolido)
    {
        minSolido = 0.0;
        maxSolido = 0.0;

        if (elem == null)
            return false;

        if (eje == null || eje.GetLength() <= Tol)
            return false;

        eje = eje.Normalize();

        Options opt = new Options();
        opt.DetailLevel = ViewDetailLevel.Fine;
        opt.IncludeNonVisibleObjects = false;
        opt.ComputeReferences = false;

        GeometryElement geo = null;

        try
        {
            geo = elem.get_Geometry(opt);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return false;

        List<double> proyecciones = new List<double>();

        RecolectarProyeccionesGeometria(
            geo,
            Transform.Identity,
            origen,
            eje,
            proyecciones);

        if (proyecciones.Count < 2)
            return false;

        minSolido = proyecciones.Min();
        maxSolido = proyecciones.Max();

        if (maxSolido <= minSolido)
            return false;

        return true;
    }

    private void RecolectarProyeccionesGeometria(
        GeometryElement geo,
        Transform transform,
        XYZ origen,
        XYZ eje,
        List<double> proyecciones)
    {
        if (geo == null)
            return;

        foreach (GeometryObject obj in geo)
        {
            if (obj == null)
                continue;

            Solid solid = obj as Solid;

            if (solid != null)
            {
                RecolectarProyeccionesSolido(
                    solid,
                    transform,
                    origen,
                    eje,
                    proyecciones);

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi != null)
            {
                try
                {
                    GeometryElement geoInst = gi.GetInstanceGeometry();

                    if (geoInst != null)
                    {
                        RecolectarProyeccionesGeometria(
                            geoInst,
                            Transform.Identity,
                            origen,
                            eje,
                            proyecciones);
                    }
                }
                catch
                {
                    try
                    {
                        GeometryElement geoSym = gi.GetSymbolGeometry();

                        if (geoSym != null)
                        {
                            Transform t2 = transform.Multiply(gi.Transform);

                            RecolectarProyeccionesGeometria(
                                geoSym,
                                t2,
                                origen,
                                eje,
                                proyecciones);
                        }
                    }
                    catch
                    {
                        // Ignorar geometría que no pueda leerse.
                    }
                }
            }
        }
    }

    private void RecolectarProyeccionesSolido(
        Solid solid,
        Transform transform,
        XYZ origen,
        XYZ eje,
        List<double> proyecciones)
    {
        if (solid == null)
            return;

        if (solid.Edges == null || solid.Edges.Size == 0)
            return;

        try
        {
            if (solid.Volume <= Tol)
                return;
        }
        catch
        {
            // Si no se puede leer volumen, igual se intenta con aristas.
        }

        foreach (Edge edge in solid.Edges)
        {
            if (edge == null)
                continue;

            Curve c = null;

            try
            {
                c = edge.AsCurve();
            }
            catch
            {
                c = null;
            }

            if (c == null)
                continue;

            try
            {
                XYZ a = c.GetEndPoint(0);
                XYZ b = c.GetEndPoint(1);

                if (transform != null && !transform.IsIdentity)
                {
                    a = transform.OfPoint(a);
                    b = transform.OfPoint(b);
                }

                proyecciones.Add((a - origen).DotProduct(eje));
                proyecciones.Add((b - origen).DotProduct(eje));
            }
            catch
            {
                // Ignorar aristas inválidas.
            }
        }
    }


    // =========================================================
    // INTERVALOS CONTINUOS DEL SÓLIDO REAL SOBRE EL EJE DE LA VIGA
    // =========================================================
    // A diferencia de ObtenerIntervaloSolidoElementoEnDireccion(...), este método
    // no reduce toda la geometría a un único mínimo/máximo. Cada volumen separado
    // conserva su propio intervalo. Por ello, una viga cortada en dos cuerpos se
    // envía a la ventana 2D como dos tramos aunque siga siendo un solo ElementId.
    private List<VigaLongitudinalPreview.IntervaloSolidoPreview>
        ObtenerIntervalosContinuosSolidoElementoEnDireccionMYG(
            Element elem,
            XYZ origen,
            XYZ eje,
            double minGeneral,
            double maxGeneral)
    {
        List<VigaLongitudinalPreview.IntervaloSolidoPreview> resultado =
            new List<VigaLongitudinalPreview.IntervaloSolidoPreview>();

        if (elem == null || origen == null || eje == null)
            return resultado;

        if (eje.GetLength() <= Tol)
            return resultado;

        if (maxGeneral <= minGeneral + Tol)
            return resultado;

        eje = eje.Normalize();

        Options opt = new Options();
        opt.DetailLevel = ViewDetailLevel.Fine;
        opt.IncludeNonVisibleObjects = false;
        opt.ComputeReferences = false;

        GeometryElement geo = null;

        try
        {
            geo = elem.get_Geometry(opt);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return resultado;

        List<Tuple<double, double>> intervalosFt =
            new List<Tuple<double, double>>();

        RecolectarIntervalosGeometriaMYG(
            geo,
            Transform.Identity,
            origen,
            eje,
            intervalosFt);

        double toleranciaUnionFt = UnitUtils.ConvertToInternalUnits(
            1.0,
            UnitTypeId.Millimeters);

        List<Tuple<double, double>> fusionados =
            FusionarIntervalosProyectadosMYG(
                intervalosFt,
                toleranciaUnionFt,
                minGeneral,
                maxGeneral);

        foreach (Tuple<double, double> intervalo in fusionados)
        {
            if (intervalo == null)
                continue;

            double inicioLocalFt = intervalo.Item1 - minGeneral;
            double finLocalFt = intervalo.Item2 - minGeneral;

            double inicioMm = UnitUtils.ConvertFromInternalUnits(
                inicioLocalFt,
                UnitTypeId.Millimeters);

            double finMm = UnitUtils.ConvertFromInternalUnits(
                finLocalFt,
                UnitTypeId.Millimeters);

            if (finMm <= inicioMm + 1.0)
                continue;

            resultado.Add(
                new VigaLongitudinalPreview.IntervaloSolidoPreview(
                    inicioMm,
                    finMm));
        }

        return resultado
            .OrderBy(x => x.InicioMm)
            .ToList();
    }

    private void RecolectarIntervalosGeometriaMYG(
        GeometryElement geo,
        Transform transform,
        XYZ origen,
        XYZ eje,
        List<Tuple<double, double>> intervalos)
    {
        if (geo == null || intervalos == null)
            return;

        foreach (GeometryObject obj in geo)
        {
            if (obj == null)
                continue;

            Solid solid = obj as Solid;

            if (solid != null)
            {
                AgregarIntervalosSolidMYG(
                    solid,
                    transform,
                    origen,
                    eje,
                    intervalos);

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi == null)
                continue;

            bool procesado = false;

            try
            {
                GeometryElement geoInst = gi.GetInstanceGeometry();

                if (geoInst != null)
                {
                    // GetInstanceGeometry normalmente ya llega en coordenadas de modelo.
                    RecolectarIntervalosGeometriaMYG(
                        geoInst,
                        Transform.Identity,
                        origen,
                        eje,
                        intervalos);

                    procesado = true;
                }
            }
            catch
            {
                procesado = false;
            }

            if (procesado)
                continue;

            try
            {
                GeometryElement geoSimbolo = gi.GetSymbolGeometry();

                if (geoSimbolo != null)
                {
                    Transform t2 = transform;

                    try
                    {
                        t2 = transform == null
                            ? gi.Transform
                            : transform.Multiply(gi.Transform);
                    }
                    catch
                    {
                        t2 = gi.Transform;
                    }

                    RecolectarIntervalosGeometriaMYG(
                        geoSimbolo,
                        t2,
                        origen,
                        eje,
                        intervalos);
                }
            }
            catch
            {
                // Ignorar geometría que no pueda leerse.
            }
        }
    }

    private void AgregarIntervalosSolidMYG(
        Solid solid,
        Transform transform,
        XYZ origen,
        XYZ eje,
        List<Tuple<double, double>> intervalos)
    {
        if (solid == null || intervalos == null)
            return;

        try
        {
            if (solid.Volume <= Tol ||
                solid.Faces == null ||
                solid.Faces.Size == 0)
            {
                return;
            }
        }
        catch
        {
            return;
        }

        List<Solid> partes = new List<Solid>();

        try
        {
            IList<Solid> volumenes = SolidUtils.SplitVolumes(solid);

            if (volumenes != null)
            {
                foreach (Solid parte in volumenes)
                {
                    if (parte != null)
                        partes.Add(parte);
                }
            }
        }
        catch
        {
            partes.Clear();
        }

        if (partes.Count == 0)
            partes.Add(solid);

        foreach (Solid parte in partes)
        {
            if (parte == null)
                continue;

            List<double> proyecciones = new List<double>();

            RecolectarProyeccionesSolido(
                parte,
                transform,
                origen,
                eje,
                proyecciones);

            if (proyecciones.Count < 2)
                continue;

            double min = proyecciones.Min();
            double max = proyecciones.Max();

            if (max <= min + Tol)
                continue;

            intervalos.Add(Tuple.Create(min, max));
        }
    }

    private List<Tuple<double, double>> FusionarIntervalosProyectadosMYG(
        List<Tuple<double, double>> intervalos,
        double toleranciaUnion,
        double minGeneral,
        double maxGeneral)
    {
        List<Tuple<double, double>> resultado =
            new List<Tuple<double, double>>();

        if (intervalos == null || intervalos.Count == 0)
            return resultado;

        List<Tuple<double, double>> validos =
            new List<Tuple<double, double>>();

        foreach (Tuple<double, double> intervalo in intervalos)
        {
            if (intervalo == null)
                continue;

            double inicio = Math.Min(intervalo.Item1, intervalo.Item2);
            double fin = Math.Max(intervalo.Item1, intervalo.Item2);

            inicio = Math.Max(minGeneral, Math.Min(maxGeneral, inicio));
            fin = Math.Max(minGeneral, Math.Min(maxGeneral, fin));

            if (fin <= inicio + Tol)
                continue;

            validos.Add(Tuple.Create(inicio, fin));
        }

        foreach (Tuple<double, double> intervalo in validos
            .OrderBy(x => x.Item1)
            .ThenBy(x => x.Item2))
        {
            if (resultado.Count == 0)
            {
                resultado.Add(intervalo);
                continue;
            }

            Tuple<double, double> ultimo = resultado[resultado.Count - 1];

            if (intervalo.Item1 <= ultimo.Item2 + toleranciaUnion)
            {
                resultado[resultado.Count - 1] =
                    Tuple.Create(
                        Math.Min(ultimo.Item1, intervalo.Item1),
                        Math.Max(ultimo.Item2, intervalo.Item2));
            }
            else
            {
                resultado.Add(intervalo);
            }
        }

        return resultado;
    }


    // =====================================
    // PERFIL LIMPIO DE SECCIÓN VARIABLE PARA VISTA PRELIMINAR
    // SOLO USA INICIO / FIN DEL SÓLIDO, NO TODOS LOS VÉRTICES
    // =====================================
    private void AsignarPerfilSeccionVariablePreview(
        Element elem,
        XYZ p0,
        XYZ xAxis,
        VigaLongitudinalPreview preview)
    {
        if (elem == null || p0 == null || xAxis == null || preview == null)
            return;

        if (xAxis.GetLength() <= Tol)
            return;

        xAxis = xAxis.Normalize();

        XYZ yAxis = XYZ.BasisZ.CrossProduct(xAxis);

        if (yAxis.GetLength() <= Tol)
            yAxis = XYZ.BasisX.CrossProduct(xAxis);

        if (yAxis.GetLength() <= Tol)
            yAxis = XYZ.BasisY;

        yAxis = yAxis.Normalize();

        XYZ zAxis = xAxis.CrossProduct(yAxis);

        if (zAxis.GetLength() <= Tol)
            zAxis = XYZ.BasisZ;

        zAxis = zAxis.Normalize();

        if (zAxis.DotProduct(XYZ.BasisZ) < 0.0)
            zAxis = zAxis.Multiply(-1.0);

        List<XYZ> puntos = ObtenerPuntosSolidoElementoPreview(elem);

        if (puntos == null || puntos.Count == 0)
            puntos = ObtenerPuntosBoundingBoxElementoPreview(elem);

        if (puntos == null || puntos.Count == 0)
            return;

        double minX = double.MaxValue;
        double maxX = double.MinValue;

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            double x = (p - p0).DotProduct(xAxis);

            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
        }

        if (maxX <= minX + Tol)
            return;

        double zSupIni = 0.0;
        double zInfIni = 0.0;
        double zSupFin = 0.0;
        double zInfFin = 0.0;

        bool okIni = ObtenerPerfilZEnExtremoPreview(
            puntos,
            p0,
            xAxis,
            zAxis,
            minX,
            minX,
            maxX,
            out zSupIni,
            out zInfIni);

        bool okFin = ObtenerPerfilZEnExtremoPreview(
            puntos,
            p0,
            xAxis,
            zAxis,
            maxX,
            minX,
            maxX,
            out zSupFin,
            out zInfFin);

        if (!okIni || !okFin)
            return;

        preview.TienePerfilSeccionVariable = true;

        preview.ZSuperiorInicioMm = UnitUtils.ConvertFromInternalUnits(
            zSupIni,
            UnitTypeId.Millimeters);

        preview.ZSuperiorFinMm = UnitUtils.ConvertFromInternalUnits(
            zSupFin,
            UnitTypeId.Millimeters);

        preview.ZInferiorInicioMm = UnitUtils.ConvertFromInternalUnits(
            zInfIni,
            UnitTypeId.Millimeters);

        preview.ZInferiorFinMm = UnitUtils.ConvertFromInternalUnits(
            zInfFin,
            UnitTypeId.Millimeters);

        AsignarPerfilDetalladoPreviewDesdePuntos(
            puntos,
            p0,
            xAxis,
            zAxis,
            minX,
            maxX,
            preview);
    }

    private void AsignarPerfilDetalladoPreviewDesdePuntos(
        List<XYZ> puntos,
        XYZ origen,
        XYZ xAxis,
        XYZ zAxis,
        double minX,
        double maxX,
        VigaLongitudinalPreview preview)
    {
        if (puntos == null || puntos.Count < 2 || preview == null)
            return;

        double longitud = maxX - minX;

        if (longitud <= Tol)
            return;

        // Agrupa estaciones cada 5 mm para eliminar duplicados de vértices
        // provenientes de caras laterales, pero conservando los quiebres reales.
        double pasoGrupoMm = 5.0;
        Dictionary<double, List<double>> zPorX = new Dictionary<double, List<double>>();

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            double x = (p - origen).DotProduct(xAxis);

            if (x < minX - Tol || x > maxX + Tol)
                continue;

            double z = (p - origen).DotProduct(zAxis);

            double xMm = UnitUtils.ConvertFromInternalUnits(
                x,
                UnitTypeId.Millimeters);

            double zMm = UnitUtils.ConvertFromInternalUnits(
                z,
                UnitTypeId.Millimeters);

            double clave = Math.Round(xMm / pasoGrupoMm) * pasoGrupoMm;

            if (!zPorX.ContainsKey(clave))
                zPorX[clave] = new List<double>();

            zPorX[clave].Add(zMm);
        }

        if (zPorX.Count < 2)
            return;

        List<VigaLongitudinalPreview.PuntoPerfilMm> superior = new List<VigaLongitudinalPreview.PuntoPerfilMm>();
        List<VigaLongitudinalPreview.PuntoPerfilMm> inferior = new List<VigaLongitudinalPreview.PuntoPerfilMm>();

        foreach (KeyValuePair<double, List<double>> kv in zPorX.OrderBy(k => k.Key))
        {
            if (kv.Value == null || kv.Value.Count == 0)
                continue;

            double zMax = kv.Value.Max();
            double zMin = kv.Value.Min();

            superior.Add(new VigaLongitudinalPreview.PuntoPerfilMm(kv.Key, zMax));
            inferior.Add(new VigaLongitudinalPreview.PuntoPerfilMm(kv.Key, zMin));
        }

        superior = SimplificarPerfilPreview(superior);
        inferior = SimplificarPerfilPreview(inferior);

        if (superior.Count >= 2 && inferior.Count >= 2)
        {
            preview.PerfilSuperiorMm = superior;
            preview.PerfilInferiorMm = inferior;
            preview.TienePerfilSeccionVariable = true;
        }
    }

    private List<VigaLongitudinalPreview.PuntoPerfilMm> SimplificarPerfilPreview(
        List<VigaLongitudinalPreview.PuntoPerfilMm> puntos)
    {
        List<VigaLongitudinalPreview.PuntoPerfilMm> resultado = new List<VigaLongitudinalPreview.PuntoPerfilMm>();

        if (puntos == null || puntos.Count == 0)
            return resultado;

        List<VigaLongitudinalPreview.PuntoPerfilMm> ordenados = puntos
            .Where(p => p != null)
            .OrderBy(p => p.XMm)
            .ToList();

        if (ordenados.Count <= 2)
            return ordenados;

        resultado.Add(ordenados[0]);

        for (int i = 1; i < ordenados.Count - 1; i++)
        {
            VigaLongitudinalPreview.PuntoPerfilMm a = resultado[resultado.Count - 1];
            VigaLongitudinalPreview.PuntoPerfilMm b = ordenados[i];
            VigaLongitudinalPreview.PuntoPerfilMm c = ordenados[i + 1];

            if (!EsPuntoColinealPerfilPreview(a, b, c, 3.0))
                resultado.Add(b);
        }

        resultado.Add(ordenados[ordenados.Count - 1]);

        return resultado;
    }

    private bool EsPuntoColinealPerfilPreview(
        VigaLongitudinalPreview.PuntoPerfilMm a,
        VigaLongitudinalPreview.PuntoPerfilMm b,
        VigaLongitudinalPreview.PuntoPerfilMm c,
        double toleranciaMm)
    {
        if (a == null || b == null || c == null)
            return false;

        double dx = c.XMm - a.XMm;

        if (Math.Abs(dx) <= 0.001)
            return false;

        double t = (b.XMm - a.XMm) / dx;
        double zInterpolado = a.ZMm + (c.ZMm - a.ZMm) * t;

        return Math.Abs(zInterpolado - b.ZMm) <= toleranciaMm;
    }

    private bool ObtenerPerfilZEnExtremoPreview(
        List<XYZ> puntos,
        XYZ origen,
        XYZ xAxis,
        XYZ zAxis,
        double estacionObjetivo,
        double minX,
        double maxX,
        out double zSuperior,
        out double zInferior)
    {
        zSuperior = 0.0;
        zInferior = 0.0;

        if (puntos == null || puntos.Count == 0)
            return false;

        double longitud = maxX - minX;

        if (longitud <= Tol)
            return false;

        double anchoFranja = Math.Max(
            UnitUtils.ConvertToInternalUnits(5.0, UnitTypeId.Centimeters),
            longitud * 0.08);

        List<Tuple<double, double>> candidatos = new List<Tuple<double, double>>();

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            double x = (p - origen).DotProduct(xAxis);
            double z = (p - origen).DotProduct(zAxis);
            double dist = Math.Abs(x - estacionObjetivo);

            candidatos.Add(new Tuple<double, double>(dist, z));
        }

        if (candidatos.Count == 0)
            return false;

        double distanciaMinima = candidatos.Min(c => c.Item1);
        double limite = Math.Max(anchoFranja, distanciaMinima + UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Centimeters));

        List<double> valoresZ = candidatos
            .Where(c => c.Item1 <= limite)
            .Select(c => c.Item2)
            .ToList();

        if (valoresZ.Count < 2)
        {
            valoresZ = candidatos
                .OrderBy(c => c.Item1)
                .Take(12)
                .Select(c => c.Item2)
                .ToList();
        }

        if (valoresZ.Count < 2)
            return false;

        zSuperior = valoresZ.Max();
        zInferior = valoresZ.Min();

        return zSuperior > zInferior + Tol;
    }

    private List<XYZ> ObtenerPuntosSolidoElementoPreview(Element elem)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (elem == null)
            return puntos;

        Options opt = new Options();
        opt.DetailLevel = ViewDetailLevel.Fine;
        opt.IncludeNonVisibleObjects = false;
        opt.ComputeReferences = false;

        GeometryElement geo = null;

        try
        {
            geo = elem.get_Geometry(opt);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return puntos;

        RecolectarPuntosGeometriaPreview(
            geo,
            Transform.Identity,
            puntos);

        return puntos;
    }

    private void RecolectarPuntosGeometriaPreview(
        GeometryElement geo,
        Transform transform,
        List<XYZ> puntos)
    {
        if (geo == null || puntos == null)
            return;

        foreach (GeometryObject obj in geo)
        {
            if (obj == null)
                continue;

            Solid solid = obj as Solid;

            if (solid != null)
            {
                RecolectarPuntosSolidoPreview(
                    solid,
                    transform,
                    puntos);

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi != null)
            {
                try
                {
                    GeometryElement geoInst = gi.GetInstanceGeometry();

                    if (geoInst != null)
                    {
                        RecolectarPuntosGeometriaPreview(
                            geoInst,
                            Transform.Identity,
                            puntos);
                    }
                }
                catch
                {
                    try
                    {
                        GeometryElement geoSym = gi.GetSymbolGeometry();

                        if (geoSym != null)
                        {
                            Transform t2 = transform.Multiply(gi.Transform);

                            RecolectarPuntosGeometriaPreview(
                                geoSym,
                                t2,
                                puntos);
                        }
                    }
                    catch
                    {
                        // Ignorar geometría inválida.
                    }
                }
            }
        }
    }

    private void RecolectarPuntosSolidoPreview(
        Solid solid,
        Transform transform,
        List<XYZ> puntos)
    {
        if (solid == null || puntos == null)
            return;

        try
        {
            if (solid.Volume <= Tol)
                return;
        }
        catch
        {
            // Se intenta de todos modos.
        }

        if (solid.Edges == null || solid.Edges.Size == 0)
            return;

        foreach (Edge edge in solid.Edges)
        {
            if (edge == null)
                continue;

            Curve c = null;

            try
            {
                c = edge.AsCurve();
            }
            catch
            {
                c = null;
            }

            if (c == null)
                continue;

            try
            {
                XYZ a = c.GetEndPoint(0);
                XYZ b = c.GetEndPoint(1);

                if (transform != null && !transform.IsIdentity)
                {
                    a = transform.OfPoint(a);
                    b = transform.OfPoint(b);
                }

                puntos.Add(a);
                puntos.Add(b);
            }
            catch
            {
                // Ignorar aristas inválidas.
            }
        }
    }

    private List<XYZ> ObtenerPuntosBoundingBoxElementoPreview(Element elem)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (elem == null)
            return puntos;

        BoundingBoxXYZ bb = elem.get_BoundingBox(null);

        if (bb == null)
            return puntos;

        XYZ min = bb.Min;
        XYZ max = bb.Max;

        puntos.Add(new XYZ(min.X, min.Y, min.Z));
        puntos.Add(new XYZ(max.X, min.Y, min.Z));
        puntos.Add(new XYZ(min.X, max.Y, min.Z));
        puntos.Add(new XYZ(max.X, max.Y, min.Z));

        puntos.Add(new XYZ(min.X, min.Y, max.Z));
        puntos.Add(new XYZ(max.X, min.Y, max.Z));
        puntos.Add(new XYZ(min.X, max.Y, max.Z));
        puntos.Add(new XYZ(max.X, max.Y, max.Z));

        return puntos;
    }


    // =====================================
    // SÓLIDOS 3D REALES PARA VISTA PRELIMINAR 3D
    // Convierte la geometría real de Revit a triángulos en mm.
    // Esto permite que SeleccionarVigasForm muestre el sólido sombreado
    // en lugar de una vista esquemática o tipo alámbrica.
    // =====================================

    private void AgregarSolidos3DColumnasDetectadas(
        VigaLongitudinalPreview preview,
        List<Element> columnas)
    {
        if (preview == null || columnas == null || columnas.Count == 0)
            return;

        if (preview.Solidos3D == null)
            preview.Solidos3D = new List<VigaLongitudinalPreview.Solido3DPreview>();

        if (columnas3DAgregadas == null)
            columnas3DAgregadas = new HashSet<long>();

        foreach (Element col in columnas)
        {
            if (col == null)
                continue;

            long id = col.Id.Value;

            if (columnas3DAgregadas.Contains(id))
                continue;

            List<VigaLongitudinalPreview.Solido3DPreview> solidosColumna = null;

            // Para cimentaciones se usa una caja 3D real en coordenadas del
            // modelo. Algunas familias de zapata contienen geometría anidada
            // cuya transformación puede llegar duplicada o incompleta al
            // preview, haciendo que la zapata aparezca como una pieza vertical.
            if (EsCimentacionEstructuralPreviewMYG(col))
            {
                solidosColumna = ConstruirCaja3DPreviewDesdeElementoMYG(col);
            }
            else
            {
                solidosColumna = ConstruirSolidos3DPreviewDesdeElemento(col);
            }

            // Respaldo general: si la triangulación no devuelve caras, se dibuja
            // la caja envolvente del elemento para que el apoyo no desaparezca.
            if (solidosColumna == null || solidosColumna.Count == 0)
                solidosColumna = ConstruirCaja3DPreviewDesdeElementoMYG(col);

            if (solidosColumna == null || solidosColumna.Count == 0)
                continue;

            preview.Solidos3D.AddRange(solidosColumna);
            columnas3DAgregadas.Add(id);
        }
    }

    private List<VigaLongitudinalPreview.Solido3DPreview> ConstruirCaja3DPreviewDesdeElementoMYG(
        Element elemento)
    {
        List<VigaLongitudinalPreview.Solido3DPreview> resultado =
            new List<VigaLongitudinalPreview.Solido3DPreview>();

        if (elemento == null)
            return resultado;

        BoundingBoxXYZ bb = null;

        try
        {
            bb = elemento.get_BoundingBox(null);
        }
        catch
        {
            bb = null;
        }

        if (bb == null)
            return resultado;

        XYZ min = bb.Min;
        XYZ max = bb.Max;

        if (min == null || max == null)
            return resultado;

        if (max.X <= min.X + Tol ||
            max.Y <= min.Y + Tol ||
            max.Z <= min.Z + Tol)
        {
            return resultado;
        }

        VigaLongitudinalPreview.Solido3DPreview caja =
            new VigaLongitudinalPreview.Solido3DPreview();

        XYZ[] puntos = new XYZ[]
        {
            new XYZ(min.X, min.Y, min.Z), // 0
            new XYZ(max.X, min.Y, min.Z), // 1
            new XYZ(max.X, max.Y, min.Z), // 2
            new XYZ(min.X, max.Y, min.Z), // 3
            new XYZ(min.X, min.Y, max.Z), // 4
            new XYZ(max.X, min.Y, max.Z), // 5
            new XYZ(max.X, max.Y, max.Z), // 6
            new XYZ(min.X, max.Y, max.Z)  // 7
        };

        foreach (XYZ punto in puntos)
        {
            caja.Puntos.Add(
                new VigaLongitudinalPreview.Punto3DPreview(
                    UnitUtils.ConvertFromInternalUnits(punto.X, UnitTypeId.Millimeters),
                    UnitUtils.ConvertFromInternalUnits(punto.Y, UnitTypeId.Millimeters),
                    UnitUtils.ConvertFromInternalUnits(punto.Z, UnitTypeId.Millimeters)));
        }

        int[][] triangulos = new int[][]
        {
            new int[] { 0, 2, 1 }, new int[] { 0, 3, 2 }, // inferior
            new int[] { 4, 5, 6 }, new int[] { 4, 6, 7 }, // superior
            new int[] { 0, 1, 5 }, new int[] { 0, 5, 4 },
            new int[] { 1, 2, 6 }, new int[] { 1, 6, 5 },
            new int[] { 2, 3, 7 }, new int[] { 2, 7, 6 },
            new int[] { 3, 0, 4 }, new int[] { 3, 4, 7 }
        };

        foreach (int[] tri in triangulos)
        {
            caja.Caras.Add(
                new VigaLongitudinalPreview.Cara3DPreview(
                    tri[0],
                    tri[1],
                    tri[2]));
        }

        resultado.Add(caja);
        return resultado;
    }

    private List<VigaLongitudinalPreview.Solido3DPreview> ConstruirSolidos3DPreviewDesdeElemento(Element elem)
    {
        List<VigaLongitudinalPreview.Solido3DPreview> resultado =
            new List<VigaLongitudinalPreview.Solido3DPreview>();

        if (elem == null)
            return resultado;

        Options opt = new Options();
        opt.ComputeReferences = false;
        opt.IncludeNonVisibleObjects = false;
        opt.DetailLevel = ViewDetailLevel.Fine;

        GeometryElement geo = null;

        try
        {
            geo = elem.get_Geometry(opt);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return resultado;

        try
        {
            AgregarGeometria3DPreview(
                geo,
                Transform.Identity,
                resultado);
        }
        catch
        {
            // No interrumpir la selección por problemas de geometría 3D.
        }

        return resultado;
    }

    private void AgregarGeometria3DPreview(
        GeometryElement geo,
        Transform transform,
        List<VigaLongitudinalPreview.Solido3DPreview> resultado)
    {
        if (geo == null || resultado == null)
            return;

        foreach (GeometryObject obj in geo)
        {
            if (obj == null)
                continue;

            Solid solid = obj as Solid;

            if (solid != null)
            {
                AgregarSolido3DPreview(
                    solid,
                    transform,
                    resultado);

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi != null)
            {
                // Primero se intenta con GetInstanceGeometry, que suele devolver
                // la geometría ya ubicada en coordenadas del modelo.
                bool procesado = false;

                try
                {
                    GeometryElement geoInst = gi.GetInstanceGeometry();

                    if (geoInst != null)
                    {
                        AgregarGeometria3DPreview(
                            geoInst,
                            Transform.Identity,
                            resultado);

                        procesado = true;
                    }
                }
                catch
                {
                    procesado = false;
                }

                if (procesado)
                    continue;

                // Respaldo: leer geometría de símbolo y aplicar transform del instance.
                try
                {
                    GeometryElement geoSym = gi.GetSymbolGeometry();

                    if (geoSym != null)
                    {
                        Transform t2 = transform;

                        try
                        {
                            t2 = transform.Multiply(gi.Transform);
                        }
                        catch
                        {
                            t2 = gi.Transform;
                        }

                        AgregarGeometria3DPreview(
                            geoSym,
                            t2,
                            resultado);
                    }
                }
                catch
                {
                    // Ignorar geometría que no pueda leerse.
                }
            }
        }
    }

    private void AgregarSolido3DPreview(
        Solid solid,
        Transform transform,
        List<VigaLongitudinalPreview.Solido3DPreview> resultado)
    {
        if (solid == null || resultado == null)
            return;

        try
        {
            if (solid.Faces == null || solid.Faces.Size == 0)
                return;
        }
        catch
        {
            return;
        }

        try
        {
            if (solid.Volume <= Tol)
                return;
        }
        catch
        {
            // Si el volumen no puede leerse, se intenta triangular de todos modos.
        }

        VigaLongitudinalPreview.Solido3DPreview solidoPreview =
            ConvertirSolidA3DPreview(
                solid,
                transform);

        if (solidoPreview == null)
            return;

        if (solidoPreview.Puntos == null || solidoPreview.Puntos.Count == 0)
            return;

        if (solidoPreview.Caras == null || solidoPreview.Caras.Count == 0)
            return;

        resultado.Add(solidoPreview);
    }

    private VigaLongitudinalPreview.Solido3DPreview ConvertirSolidA3DPreview(
        Solid solid,
        Transform transform)
    {
        if (solid == null)
            return null;

        VigaLongitudinalPreview.Solido3DPreview solidoPreview =
            new VigaLongitudinalPreview.Solido3DPreview();

        foreach (Face face in solid.Faces)
        {
            if (face == null)
                continue;

            Mesh mesh = null;

            try
            {
                mesh = face.Triangulate();
            }
            catch
            {
                mesh = null;
            }

            if (mesh == null)
                continue;

            int nTri = 0;

            try
            {
                nTri = mesh.NumTriangles;
            }
            catch
            {
                nTri = 0;
            }

            for (int i = 0; i < nTri; i++)
            {
                MeshTriangle tri = null;

                try
                {
                    tri = mesh.get_Triangle(i);
                }
                catch
                {
                    tri = null;
                }

                if (tri == null)
                    continue;

                XYZ p0 = null;
                XYZ p1 = null;
                XYZ p2 = null;

                try
                {
                    p0 = tri.get_Vertex(0);
                    p1 = tri.get_Vertex(1);
                    p2 = tri.get_Vertex(2);
                }
                catch
                {
                    continue;
                }

                if (transform != null && !transform.IsIdentity)
                {
                    try
                    {
                        p0 = transform.OfPoint(p0);
                        p1 = transform.OfPoint(p1);
                        p2 = transform.OfPoint(p2);
                    }
                    catch
                    {
                        // Si falla el transform, se usan los puntos tal como llegaron.
                    }
                }

                int i0 = AgregarPunto3DPreview(solidoPreview, p0);
                int i1 = AgregarPunto3DPreview(solidoPreview, p1);
                int i2 = AgregarPunto3DPreview(solidoPreview, p2);

                if (i0 >= 0 && i1 >= 0 && i2 >= 0)
                {
                    VigaLongitudinalPreview.Cara3DPreview cara =
                        new VigaLongitudinalPreview.Cara3DPreview(i0, i1, i2);

                    solidoPreview.Caras.Add(cara);
                }
            }
        }

        return solidoPreview;
    }

    private int AgregarPunto3DPreview(
        VigaLongitudinalPreview.Solido3DPreview solidoPreview,
        XYZ p)
    {
        if (solidoPreview == null || p == null)
            return -1;

        double xMm = UnitUtils.ConvertFromInternalUnits(p.X, UnitTypeId.Millimeters);
        double yMm = UnitUtils.ConvertFromInternalUnits(p.Y, UnitTypeId.Millimeters);
        double zMm = UnitUtils.ConvertFromInternalUnits(p.Z, UnitTypeId.Millimeters);

        int index = solidoPreview.Puntos.Count;

        solidoPreview.Puntos.Add(
            new VigaLongitudinalPreview.Punto3DPreview(
                xMm,
                yMm,
                zMm));

        return index;
    }

    // =====================================
    // UTILIDADES
    // =====================================

    // =====================================
    // UTILIDADES DE FILTRO GEOMÉTRICO
    // =====================================

    private bool TieneSolapeVerticalConViga(
        BoundingBoxXYZ bbViga,
        BoundingBoxXYZ bbCandidato,
        double toleranciaZ)
    {
        if (bbViga == null || bbCandidato == null)
            return false;

        double minZViga = bbViga.Min.Z - Math.Abs(toleranciaZ);
        double maxZViga = bbViga.Max.Z + Math.Abs(toleranciaZ);

        // Si el candidato está completamente debajo de la franja Z de la viga, se descarta.
        if (bbCandidato.Max.Z < minZViga)
            return false;

        // Si el candidato está completamente encima de la franja Z de la viga, se descarta.
        if (bbCandidato.Min.Z > maxZViga)
            return false;

        return true;
    }

    private bool EstaPegadoALaVigaEnPlanta(
        BoundingBoxXYZ bbViga,
        BoundingBoxXYZ bbCandidato,
        double toleranciaContacto)
    {
        if (bbViga == null || bbCandidato == null)
            return false;

        double separacionXY = ObtenerSeparacionMinimaBoundingBoxXY(
            bbViga,
            bbCandidato);

        return separacionXY <= Math.Abs(toleranciaContacto);
    }

    private bool EstaPegadoALaVigaEnVertical(
        BoundingBoxXYZ bbViga,
        BoundingBoxXYZ bbCandidato,
        double toleranciaContactoZ)
    {
        if (bbViga == null || bbCandidato == null)
            return false;

        double separacionZ = ObtenerSeparacionMinimaBoundingBoxZ(
            bbViga,
            bbCandidato);

        return separacionZ <= Math.Abs(toleranciaContactoZ);
    }

    private double ObtenerSeparacionMinimaBoundingBoxZ(
        BoundingBoxXYZ a,
        BoundingBoxXYZ b)
    {
        if (a == null || b == null)
            return double.MaxValue;

        // Si hay traslape vertical, la separación es 0.
        if (a.Max.Z < b.Min.Z)
            return b.Min.Z - a.Max.Z;

        if (b.Max.Z < a.Min.Z)
            return a.Min.Z - b.Max.Z;

        return 0.0;
    }

    private double ObtenerSeparacionMinimaBoundingBox3D(
        BoundingBoxXYZ a,
        BoundingBoxXYZ b)
    {
        if (a == null || b == null)
            return double.MaxValue;

        double dx = 0.0;
        double dy = 0.0;
        double dz = 0.0;

        if (a.Max.X < b.Min.X)
            dx = b.Min.X - a.Max.X;
        else if (b.Max.X < a.Min.X)
            dx = a.Min.X - b.Max.X;

        if (a.Max.Y < b.Min.Y)
            dy = b.Min.Y - a.Max.Y;
        else if (b.Max.Y < a.Min.Y)
            dy = a.Min.Y - b.Max.Y;

        if (a.Max.Z < b.Min.Z)
            dz = b.Min.Z - a.Max.Z;
        else if (b.Max.Z < a.Min.Z)
            dz = a.Min.Z - b.Max.Z;

        return Math.Sqrt((dx * dx) + (dy * dy) + (dz * dz));
    }

    private double ObtenerSeparacionMinimaBoundingBoxXY(
        BoundingBoxXYZ a,
        BoundingBoxXYZ b)
    {
        if (a == null || b == null)
            return double.MaxValue;

        double dx = 0.0;
        double dy = 0.0;

        // Separación horizontal en X entre las cajas.
        // Si se traslapan, la separación es 0.
        if (a.Max.X < b.Min.X)
            dx = b.Min.X - a.Max.X;
        else if (b.Max.X < a.Min.X)
            dx = a.Min.X - b.Max.X;

        // Separación horizontal en Y entre las cajas.
        // Si se traslapan, la separación es 0.
        if (a.Max.Y < b.Min.Y)
            dy = b.Min.Y - a.Max.Y;
        else if (b.Max.Y < a.Min.Y)
            dy = a.Min.Y - b.Max.Y;

        return Math.Sqrt((dx * dx) + (dy * dy));
    }

    private bool ObtenerIntervaloBoundingBoxEnEje(
        BoundingBoxXYZ bb,
        XYZ origen,
        XYZ eje,
        out double minEje,
        out double maxEje)
    {
        minEje = 0.0;
        maxEje = 0.0;

        if (bb == null)
            return false;

        if (origen == null || eje == null || eje.GetLength() <= Tol)
            return false;

        eje = eje.Normalize();

        List<XYZ> puntos = ObtenerPuntosBoundingBox(bb);

        if (puntos == null || puntos.Count == 0)
            return false;

        minEje = double.MaxValue;
        maxEje = double.MinValue;

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            double d = (p - origen).DotProduct(eje);

            if (d < minEje)
                minEje = d;

            if (d > maxEje)
                maxEje = d;
        }

        if (minEje == double.MaxValue || maxEje == double.MinValue)
            return false;

        if (maxEje < minEje)
            return false;

        return true;
    }

    private double ObtenerDistanciaHorizontalMinimaAlEje(
        BoundingBoxXYZ bb,
        XYZ origen,
        XYZ eje,
        double longitudEje)
    {
        if (bb == null)
            return double.MaxValue;

        if (origen == null || eje == null || eje.GetLength() <= Tol)
            return double.MaxValue;

        eje = eje.Normalize();

        List<XYZ> puntos = ObtenerPuntosBoundingBox(bb);

        XYZ centro = new XYZ(
            (bb.Min.X + bb.Max.X) / 2.0,
            (bb.Min.Y + bb.Max.Y) / 2.0,
            (bb.Min.Z + bb.Max.Z) / 2.0);

        puntos.Add(centro);

        double minDist = double.MaxValue;

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            double t = (p - origen).DotProduct(eje);

            if (t < 0.0)
                t = 0.0;

            if (t > longitudEje)
                t = longitudEje;

            XYZ puntoEje = origen + eje.Multiply(t);

            double dist = DistanciaHorizontal(p, puntoEje);

            if (dist < minDist)
                minDist = dist;
        }

        return minDist;
    }

    private double DistanciaHorizontal(XYZ a, XYZ b)
    {
        double dx = a.X - b.X;
        double dy = a.Y - b.Y;

        return Math.Sqrt(dx * dx + dy * dy);
    }

    private double ObtenerAnchoElementoEnDireccion(
        Element elem,
        XYZ direccion)
    {
        BoundingBoxXYZ bb = elem.get_BoundingBox(null);

        if (bb == null)
            return 0.0;

        List<XYZ> pts = ObtenerPuntosBoundingBox(bb);

        double min = double.MaxValue;
        double max = double.MinValue;

        XYZ dir = direccion.Normalize();

        foreach (XYZ p in pts)
        {
            double d = p.DotProduct(dir);

            if (d < min)
                min = d;

            if (d > max)
                max = d;
        }

        if (max <= min)
            return 0.0;

        return max - min;
    }

    private List<XYZ> ObtenerPuntosBoundingBox(BoundingBoxXYZ bb)
    {
        List<XYZ> puntos = new List<XYZ>();

        XYZ min = bb.Min;
        XYZ max = bb.Max;

        puntos.Add(new XYZ(min.X, min.Y, min.Z));
        puntos.Add(new XYZ(max.X, min.Y, min.Z));
        puntos.Add(new XYZ(min.X, max.Y, min.Z));
        puntos.Add(new XYZ(max.X, max.Y, min.Z));

        puntos.Add(new XYZ(min.X, min.Y, max.Z));
        puntos.Add(new XYZ(max.X, min.Y, max.Z));
        puntos.Add(new XYZ(min.X, max.Y, max.Z));
        puntos.Add(new XYZ(max.X, max.Y, max.Z));

        return puntos;
    }

    private Curve ObtenerCurvaElemento(Element elem)
    {
        LocationCurve lc = elem.Location as LocationCurve;

        if (lc == null)
            return null;

        return lc.Curve;
    }

    private string ObtenerNombreElemento(Element elem)
    {
        if (elem == null)
            return "";

        string nombre = "";

        try
        {
            nombre = elem.Name;
        }
        catch
        {
            nombre = "";
        }

        if (string.IsNullOrWhiteSpace(nombre))
            nombre = elem.Id.Value.ToString();

        return nombre;
    }
}


// =====================================
// FILTRO DE SELECCIÓN - VIGAS
// =====================================
public class FiltroVigasEstructurales : ISelectionFilter
{
    public bool AllowElement(Element elem)
    {
        if (elem == null || elem.Category == null)
            return false;

        return elem.Category.Id.Value ==
               (long)BuiltInCategory.OST_StructuralFraming;
    }

    public bool AllowReference(Reference reference, XYZ position)
    {
        return true;
    }
}
