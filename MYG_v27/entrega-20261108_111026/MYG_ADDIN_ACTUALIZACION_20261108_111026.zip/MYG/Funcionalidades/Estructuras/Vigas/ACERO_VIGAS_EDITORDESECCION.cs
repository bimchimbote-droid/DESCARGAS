﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Xml.Linq;
using Drawing = System.Drawing;
using Drawing2D = System.Drawing.Drawing2D;
using WinForms = System.Windows.Forms;

namespace MYG_Addin
{
    public sealed class AceroVigaPuntoMm
    {
        public double Y { get; set; }
        public double Z { get; set; }

        public AceroVigaPuntoMm()
        {
        }

        public AceroVigaPuntoMm(double y, double z)
        {
            Y = y;
            Z = z;
        }

        public AceroVigaPuntoMm Copiar()
        {
            return new AceroVigaPuntoMm(Y, Z);
        }
    }

    // =========================================================
    // CONTORNO TRANSVERSAL ASOCIADO A CADA PREVIEW
    // =========================================================
    // Se conserva fuera de VigaLongitudinalPreview para mantener compatibilidad
    // con la clase original del proyecto. Así no es necesario agregar propiedades
    // ni tipos anidados a VigaLongitudinalPreview.
    public static class AceroVigaContornoPreviewCompartido
    {
        private sealed class DatosContorno
        {
            public List<AceroVigaPuntoMm> Puntos { get; set; } =
                new List<AceroVigaPuntoMm>();
        }

        private static readonly ConditionalWeakTable<
            global::VigaLongitudinalPreview,
            DatosContorno> datosPorPreview =
            new ConditionalWeakTable<
                global::VigaLongitudinalPreview,
                DatosContorno>();

        public static void Establecer(
            global::VigaLongitudinalPreview preview,
            IEnumerable<AceroVigaPuntoMm> puntos)
        {
            if (preview == null)
                return;

            List<AceroVigaPuntoMm> copia = new List<AceroVigaPuntoMm>();

            if (puntos != null)
            {
                foreach (AceroVigaPuntoMm punto in puntos)
                {
                    if (punto != null)
                        copia.Add(punto.Copiar());
                }
            }

            datosPorPreview.Remove(preview);
            datosPorPreview.Add(
                preview,
                new DatosContorno { Puntos = copia });
        }

        public static List<AceroVigaPuntoMm> ObtenerCopia(
            global::VigaLongitudinalPreview preview)
        {
            List<AceroVigaPuntoMm> resultado =
                new List<AceroVigaPuntoMm>();

            if (preview == null)
                return resultado;

            DatosContorno datos;

            if (!datosPorPreview.TryGetValue(preview, out datos) ||
                datos == null ||
                datos.Puntos == null)
            {
                return resultado;
            }

            foreach (AceroVigaPuntoMm punto in datos.Puntos)
            {
                if (punto != null)
                    resultado.Add(punto.Copiar());
            }

            return resultado;
        }
    }


    // =========================================================
    // BARRA OSNAP - MISMO FORMATO DEL MÓDULO DE COLUMNAS
    // =========================================================
    public sealed class AceroVigaBarraOsnap : WinForms.FlowLayoutPanel
    {
        private bool bloqueando;

        private readonly WinForms.CheckBox chkActivo;
        private readonly WinForms.CheckBox chkExtremo;
        private readonly WinForms.CheckBox chkPuntoMedio;
        private readonly WinForms.CheckBox chkCentro;
        private readonly WinForms.CheckBox chkInterseccion;
        private readonly WinForms.CheckBox chkPerpendicular;
        private readonly WinForms.CheckBox chkCercano;

        public event EventHandler ConfiguracionCambiada;

        public bool Activo { get { return chkActivo.Checked; } }
        public bool Extremo { get { return chkExtremo.Checked; } }
        public bool PuntoMedio { get { return chkPuntoMedio.Checked; } }
        public bool Centro { get { return chkCentro.Checked; } }
        public bool Interseccion { get { return chkInterseccion.Checked; } }
        public bool Perpendicular { get { return chkPerpendicular.Checked; } }
        public bool Cercano { get { return chkCercano.Checked; } }

        public AceroVigaBarraOsnap()
        {
            Height = 34;
            Width = 560;
            MinimumSize = new Drawing.Size(360, 34);
            AutoSize = false;
            AutoScroll = false;
            WrapContents = false;
            FlowDirection = WinForms.FlowDirection.LeftToRight;
            Padding = new WinForms.Padding(6, 5, 4, 3);
            Margin = new WinForms.Padding(0);
            BackColor = Drawing.Color.FromArgb(242, 245, 248);
            BorderStyle = WinForms.BorderStyle.FixedSingle;

            chkActivo = CrearCheck("OSNAP (F3)", 92, true);
            chkExtremo = CrearCheck("Extremo", 76, true);
            chkPuntoMedio = CrearCheck("Medio", 66, true);
            chkCentro = CrearCheck("Centro", 68, true);
            chkInterseccion = CrearCheck("Intersección", 96, true);
            chkPerpendicular = CrearCheck("Perp.", 60, true);
            chkPerpendicular.AccessibleName = "Referencia perpendicular";
            chkCercano = CrearCheck("Cercano", 74, true);

            Controls.Add(chkActivo);
            Controls.Add(chkExtremo);
            Controls.Add(chkPuntoMedio);
            Controls.Add(chkCentro);
            Controls.Add(chkInterseccion);
            Controls.Add(chkPerpendicular);
            Controls.Add(chkCercano);

            ActualizarHabilitacion();
        }

        private WinForms.CheckBox CrearCheck(
            string texto,
            int ancho,
            bool marcado)
        {
            WinForms.CheckBox check = new WinForms.CheckBox
            {
                Text = texto,
                Width = ancho,
                Height = 22,
                Checked = marcado,
                AutoSize = false,
                Margin = new WinForms.Padding(1, 0, 1, 0),
                Padding = new WinForms.Padding(0),
                TextAlign = Drawing.ContentAlignment.MiddleLeft,
                Font = new Drawing.Font("Segoe UI", 8.2F),
                ForeColor = Drawing.Color.FromArgb(45, 45, 45),
                BackColor = Drawing.Color.Transparent
            };

            check.CheckedChanged += (s, e) =>
            {
                if (check == chkActivo)
                    ActualizarHabilitacion();

                if (!bloqueando && ConfiguracionCambiada != null)
                    ConfiguracionCambiada(this, EventArgs.Empty);
            };

            return check;
        }

        private void ActualizarHabilitacion()
        {
            bool activo = chkActivo != null && chkActivo.Checked;

            chkExtremo.Enabled = activo;
            chkPuntoMedio.Enabled = activo;
            chkCentro.Enabled = activo;
            chkInterseccion.Enabled = activo;
            chkPerpendicular.Enabled = activo;
            chkCercano.Enabled = activo;
        }

        public void EstablecerEstado(
            bool activo,
            bool extremo,
            bool puntoMedio,
            bool centro,
            bool interseccion,
            bool perpendicular,
            bool cercano)
        {
            bloqueando = true;

            chkActivo.Checked = activo;
            chkExtremo.Checked = extremo;
            chkPuntoMedio.Checked = puntoMedio;
            chkCentro.Checked = centro;
            chkInterseccion.Checked = interseccion;
            chkPerpendicular.Checked = perpendicular;
            chkCercano.Checked = cercano;

            bloqueando = false;
            ActualizarHabilitacion();
        }
    }

    public sealed class AceroVigaPuntoNormalizado
    {
        public double U { get; set; }
        public double V { get; set; }

        public AceroVigaPuntoNormalizado()
        {
        }

        public AceroVigaPuntoNormalizado(double u, double v)
        {
            U = Limitar01(u);
            V = Limitar01(v);
        }

        public AceroVigaPuntoNormalizado Copiar()
        {
            return new AceroVigaPuntoNormalizado(U, V);
        }

        private static double Limitar01(double valor)
        {
            if (double.IsNaN(valor) || double.IsInfinity(valor))
                return 0.5;

            return Math.Max(0.0, Math.Min(1.0, valor));
        }
    }

    public enum AceroVigaTipoCapaLongitudinal
    {
        SinDefinir = 0,
        Superior = 1,
        Inferior = 2,
        Central = 3
    }


    public enum AceroVigaReglaGrupoLongitudinal
    {
        EspaciadoMaximo = 0,
        NumeroFijo = 1,

        // Alias de compatibilidad para leer diseños V9.4 y anteriores.
        // Toda data antigua "NumeroConEspaciado" se interpreta ahora
        // como NÚMERO FIJO.
        NumeroConEspaciado = NumeroFijo
    }

    public sealed class AceroVigaGrupoLongitudinal2D
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("N");
        public RebarBarType TipoBarra { get; set; }
        public double DiametroMm { get; set; }

        public string GuiaCapaId { get; set; } = string.Empty;
        public AceroVigaTipoCapaLongitudinal TipoCapa { get; set; } =
            AceroVigaTipoCapaLongitudinal.SinDefinir;
        public int NumeroCapa { get; set; }

        public AceroVigaReglaGrupoLongitudinal Regla { get; set; } =
            AceroVigaReglaGrupoLongitudinal.NumeroFijo;
        public double EspaciadoCm { get; set; } = 20.0;
        public int Cantidad { get; set; } = 4;

        // Cuando el extremo de este conjunto coincide con una barra individual
        // o con un conjunto creado anteriormente, la posición se conserva de
        // forma paramétrica pero no se muestra ni se materializa en Revit.
        public bool OmitirPrimeraBarra { get; set; } = false;
        public bool OmitirUltimaBarra { get; set; } = false;

        // Para guías adaptativas, estos valores representan el recorrido
        // normalizado sobre la polilínea. Se conserva el sentido del arrastre.
        public double ParametroInicioGuia { get; set; } = -1.0;
        public double ParametroFinGuia { get; set; } = -1.0;

        // Línea geométrica definida por el usuario con DISTRIBUIR 2 PUNTOS.
        // La guía clasifica la capa, pero nunca reemplaza ni deforma esta línea.
        public bool RespetarTrazoDosPuntos { get; set; } = false;

        // Respaldo normalizado respecto del contorno útil del tipo de barra.
        public AceroVigaPuntoNormalizado PuntoInicio { get; set; } =
            new AceroVigaPuntoNormalizado(0.0, 0.5);
        public AceroVigaPuntoNormalizado PuntoFin { get; set; } =
            new AceroVigaPuntoNormalizado(1.0, 0.5);

        // Referencia estable respecto del CONTORNO DE CONCRETO. No cambia al
        // modificar el diámetro, el recubrimiento útil o la geometría de la guía.
        public AceroVigaPuntoNormalizado PuntoInicioSeccionReal { get; set; }
        public AceroVigaPuntoNormalizado PuntoFinSeccionReal { get; set; }

        public AceroVigaGrupoLongitudinal2D Copiar()
        {
            return new AceroVigaGrupoLongitudinal2D
            {
                Id = Id,
                TipoBarra = TipoBarra,
                DiametroMm = DiametroMm,
                GuiaCapaId = GuiaCapaId,
                TipoCapa = TipoCapa,
                NumeroCapa = NumeroCapa,
                Regla = Regla,
                EspaciadoCm = EspaciadoCm,
                Cantidad = Cantidad,
                OmitirPrimeraBarra = OmitirPrimeraBarra,
                OmitirUltimaBarra = OmitirUltimaBarra,
                ParametroInicioGuia = ParametroInicioGuia,
                ParametroFinGuia = ParametroFinGuia,
                RespetarTrazoDosPuntos = RespetarTrazoDosPuntos,
                PuntoInicio = PuntoInicio != null ? PuntoInicio.Copiar() : null,
                PuntoFin = PuntoFin != null ? PuntoFin.Copiar() : null,
                PuntoInicioSeccionReal = PuntoInicioSeccionReal != null
                    ? PuntoInicioSeccionReal.Copiar()
                    : null,
                PuntoFinSeccionReal = PuntoFinSeccionReal != null
                    ? PuntoFinSeccionReal.Copiar()
                    : null
            };
        }
    }

    public sealed class AceroVigaGuiaCapaLongitudinal2D
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("N");
        public AceroVigaTipoCapaLongitudinal Tipo { get; set; } =
            AceroVigaTipoCapaLongitudinal.SinDefinir;
        public int NumeroCapa { get; set; }

        // V se conserva para compatibilidad con diseños V9.2 o anteriores.
        // Las versiones nuevas utilizan PuntosGuia, que permiten líneas
        // horizontales, inclinadas y polilíneas adaptadas al contorno real.
        public double V { get; set; } = 0.5;
        public double SeparacionLibreCm { get; set; } = 2.5;
        public double DiametroReferenciaMm { get; set; } = 12.7;
        public double OffsetAcumuladoMm { get; set; }
        public bool AdaptadaAlContorno { get; set; } = true;

        public List<AceroVigaPuntoNormalizado> PuntosGuia { get; set; } =
            new List<AceroVigaPuntoNormalizado>();

        // V10.6: referencia estable de la guía respecto de la caja del
        // CONTORNO DE CONCRETO. PuntosGuia se mantiene por compatibilidad con
        // archivos anteriores, pero podía desplazarse al cambiar el diámetro
        // porque estaba normalizada respecto de un contorno útil variable.
        public List<AceroVigaPuntoNormalizado> PuntosGuiaSeccionReal
        { get; set; } = new List<AceroVigaPuntoNormalizado>();

        public string Etiqueta
        {
            get
            {
                if (Tipo == AceroVigaTipoCapaLongitudinal.Central)
                    return "Central";
                if (Tipo == AceroVigaTipoCapaLongitudinal.Superior)
                    return "Superior " + Math.Max(1, NumeroCapa);
                if (Tipo == AceroVigaTipoCapaLongitudinal.Inferior)
                    return "Inferior " + Math.Max(1, NumeroCapa);
                return "Sin guía";
            }
        }

        public override string ToString()
        {
            return Etiqueta;
        }

        public AceroVigaGuiaCapaLongitudinal2D Copiar()
        {
            AceroVigaGuiaCapaLongitudinal2D copia =
                new AceroVigaGuiaCapaLongitudinal2D
                {
                    Id = Id,
                    Tipo = Tipo,
                    NumeroCapa = NumeroCapa,
                    V = V,
                    SeparacionLibreCm = SeparacionLibreCm,
                    DiametroReferenciaMm = DiametroReferenciaMm,
                    OffsetAcumuladoMm = OffsetAcumuladoMm,
                    AdaptadaAlContorno = AdaptadaAlContorno
                };

            if (PuntosGuia != null)
            {
                foreach (AceroVigaPuntoNormalizado punto in PuntosGuia)
                {
                    if (punto != null)
                        copia.PuntosGuia.Add(punto.Copiar());
                }
            }

            if (PuntosGuiaSeccionReal != null)
            {
                foreach (AceroVigaPuntoNormalizado punto in
                    PuntosGuiaSeccionReal)
                {
                    if (punto != null)
                        copia.PuntosGuiaSeccionReal.Add(punto.Copiar());
                }
            }

            return copia;
        }
    }

    public sealed class AceroVigaBarraLongitudinal2D
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("N");
        public AceroVigaPuntoNormalizado Punto { get; set; } =
            new AceroVigaPuntoNormalizado(0.5, 0.5);

        // Coordenada exacta del centro de la barra respecto de la caja del
        // CONTORNO DE CONCRETO, no respecto del polígono offset. Esta referencia
        // evita que una barra ubicada sobre una cara inclinada se desplace hacia
        // abajo cuando el handler vuelve a calcular el recubrimiento en Revit.
        // Para archivos antiguos permanece null y se usa Punto como respaldo.
        public AceroVigaPuntoNormalizado PuntoSeccionReal { get; set; }

        public RebarBarType TipoBarra { get; set; }
        public double DiametroMm { get; set; }

        // Identificación semántica de la capa. No se infiere únicamente por Z:
        // se asigna al crear la barra sobre una línea guía.
        public string GrupoDistribucionId { get; set; } = string.Empty;
        public string GuiaCapaId { get; set; } = string.Empty;
        public AceroVigaTipoCapaLongitudinal TipoCapa { get; set; } =
            AceroVigaTipoCapaLongitudinal.SinDefinir;
        public int NumeroCapa { get; set; }

        // Posición normalizada recorrida sobre la polilínea de la guía.
        // Permite que la barra acompañe a una capa inclinada o quebrada cuando
        // cambia el recubrimiento, el diámetro o la separación libre.
        public double ParametroSobreGuia { get; set; } = -1.0;

        // Distancia firmada, en milímetros, desde la línea guía hasta el centro
        // real de la barra. El signo positivo apunta hacia el interior del
        // polígono útil. Así una barra puede clasificarse por una capa sin quedar
        // obligatoriamente pegada a ella, y el handler puede reconstruirla sobre
        // caras inclinadas sin depender de una caja rectangular.
        public double DesfaseNormalGuiaMm { get; set; } = 0.0;

        // Cuando es true, la ejecución debe utilizar PuntoSeccionReal antes que
        // cualquier reconstrucción desde la guía. Esto garantiza que el acero
        // respete exactamente la línea indicada mediante dos puntos.
        public bool UsarPosicionExactaSeccion { get; set; } = false;

        // La definición permanece en el grupo para conservar su longitud, regla
        // y cantidad, pero no se dibuja ni se crea cuando coincide con otra barra.
        public bool OcultaPorSuperposicion { get; set; } = false;

        public AceroVigaBarraLongitudinal2D Copiar()
        {
            return new AceroVigaBarraLongitudinal2D
            {
                Id = Id,
                Punto = Punto != null ? Punto.Copiar() : null,
                PuntoSeccionReal = PuntoSeccionReal != null
                    ? PuntoSeccionReal.Copiar()
                    : null,
                TipoBarra = TipoBarra,
                DiametroMm = DiametroMm,
                GrupoDistribucionId = GrupoDistribucionId,
                GuiaCapaId = GuiaCapaId,
                TipoCapa = TipoCapa,
                NumeroCapa = NumeroCapa,
                ParametroSobreGuia = ParametroSobreGuia,
                DesfaseNormalGuiaMm = DesfaseNormalGuiaMm,
                UsarPosicionExactaSeccion = UsarPosicionExactaSeccion,
                OcultaPorSuperposicion = OcultaPorSuperposicion
            };
        }
    }

    public enum AceroVigaTipoEstribo2D
    {
        Rectangular,
        Rombo,
        AdaptadoContorno,
        Croquis,
        HorizontalAlma,
        GanchoC,
        GanchoS
    }

    public sealed class AceroVigaEstribo2D
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("N");
        public bool Cerrado { get; set; } = true;
        public AceroVigaTipoEstribo2D Tipo { get; set; } =
            AceroVigaTipoEstribo2D.Croquis;

        // TRUE: el handler reconstruye el contorno real de cada viga y genera
        // automáticamente el offset al eje del estribo:
        // recubrimiento nominal + diámetro del estribo / 2.
        public bool UsarContornoOffsetAutomatico { get; set; }

        public int IndiceEsquinaGancho { get; set; } = -1;
        public RebarBarType TipoBarra { get; set; }
        public double DiametroMm { get; set; }

        // En Gancho C/S los dos puntos representan centros de barras
        // longitudinales. Se conservan sus diámetros para que la vista y el
        // handler reconstruyan la tangencia y el doblado real alrededor de cada
        // barra, incluso cuando los dos longitudinales tengan tipos diferentes.
        public double DiametroLongitudinalInicioMm { get; set; }
        public double DiametroLongitudinalFinMm { get; set; }

        // Los puntos se guardan normalizados dentro de la caja del contorno útil
        // del estribo. Así el mismo diseño se adapta a vigas de distinto ancho o alto.
        public List<AceroVigaPuntoNormalizado> Puntos { get; set; } =
            new List<AceroVigaPuntoNormalizado>();

        public AceroVigaEstribo2D Copiar()
        {
            AceroVigaEstribo2D copia = new AceroVigaEstribo2D
            {
                Id = Id,
                Cerrado = Cerrado,
                Tipo = Tipo,
                UsarContornoOffsetAutomatico = UsarContornoOffsetAutomatico,
                IndiceEsquinaGancho = IndiceEsquinaGancho,
                TipoBarra = TipoBarra,
                DiametroMm = DiametroMm,
                DiametroLongitudinalInicioMm = DiametroLongitudinalInicioMm,
                DiametroLongitudinalFinMm = DiametroLongitudinalFinMm
            };

            if (Puntos != null)
            {
                foreach (AceroVigaPuntoNormalizado punto in Puntos)
                {
                    if (punto != null)
                        copia.Puntos.Add(punto.Copiar());
                }
            }

            return copia;
        }
    }

    public sealed class AceroVigaDisenoSeccion
    {
        public int Version { get; set; } = 17;

        // Compatibilidad con diseños V2. Conserva el último recubrimiento editado.
        public double RecubrimientoCm { get; set; } = 4.0;

        // Cada pestaña conserva su propia configuración de recubrimiento.
        public double RecubrimientoLongitudinalCm { get; set; } = 4.0;
        public double RecubrimientoEstribosCm { get; set; } = 4.0;

        public string NombreSeccionReferencia { get; set; } = string.Empty;
        public double AnchoReferenciaMm { get; set; }
        public double AltoReferenciaMm { get; set; }

        public List<AceroVigaBarraLongitudinal2D> Longitudinales { get; set; } =
            new List<AceroVigaBarraLongitudinal2D>();

        public List<AceroVigaGrupoLongitudinal2D> GruposLongitudinales
        { get; set; } = new List<AceroVigaGrupoLongitudinal2D>();

        public List<AceroVigaGuiaCapaLongitudinal2D> GuiasCapasLongitudinales
        { get; set; } = new List<AceroVigaGuiaCapaLongitudinal2D>();

        public List<AceroVigaEstribo2D> Estribos { get; set; } =
            new List<AceroVigaEstribo2D>();

        public bool TieneLongitudinales
        {
            get { return Longitudinales != null && Longitudinales.Count > 0; }
        }

        public bool TieneEstribos
        {
            get { return Estribos != null && Estribos.Count > 0; }
        }

        public AceroVigaDisenoSeccion Copiar()
        {
            AceroVigaDisenoSeccion copia = new AceroVigaDisenoSeccion
            {
                Version = Version,
                RecubrimientoCm = RecubrimientoCm,
                RecubrimientoLongitudinalCm = RecubrimientoLongitudinalCm,
                RecubrimientoEstribosCm = RecubrimientoEstribosCm,
                NombreSeccionReferencia = NombreSeccionReferencia,
                AnchoReferenciaMm = AnchoReferenciaMm,
                AltoReferenciaMm = AltoReferenciaMm
            };

            if (Longitudinales != null)
            {
                foreach (AceroVigaBarraLongitudinal2D barra in Longitudinales)
                {
                    if (barra != null)
                        copia.Longitudinales.Add(barra.Copiar());
                }
            }

            if (GruposLongitudinales != null)
            {
                foreach (AceroVigaGrupoLongitudinal2D grupo in GruposLongitudinales)
                {
                    if (grupo != null)
                        copia.GruposLongitudinales.Add(grupo.Copiar());
                }
            }

            if (GuiasCapasLongitudinales != null)
            {
                foreach (AceroVigaGuiaCapaLongitudinal2D guia in
                    GuiasCapasLongitudinales)
                {
                    if (guia != null)
                        copia.GuiasCapasLongitudinales.Add(guia.Copiar());
                }
            }

            if (Estribos != null)
            {
                foreach (AceroVigaEstribo2D estribo in Estribos)
                {
                    if (estribo != null)
                        copia.Estribos.Add(estribo.Copiar());
                }
            }

            return copia;
        }
    }

    public static class AceroVigaDisenoSeccionCompartido
    {
        private static readonly object Sincronizacion = new object();
        private static AceroVigaDisenoSeccion actual = new AceroVigaDisenoSeccion();

        public static AceroVigaDisenoSeccion ObtenerCopia()
        {
            lock (Sincronizacion)
            {
                return actual != null
                    ? actual.Copiar()
                    : new AceroVigaDisenoSeccion();
            }
        }

        public static void Establecer(AceroVigaDisenoSeccion diseno)
        {
            lock (Sincronizacion)
            {
                actual = diseno != null
                    ? diseno.Copiar()
                    : new AceroVigaDisenoSeccion();
            }
        }

        public static void Limpiar()
        {
            lock (Sincronizacion)
            {
                actual = new AceroVigaDisenoSeccion();
            }
        }
    }

    public enum AceroVigaModoEditorInicial
    {
        Longitudinales,
        Estribos
    }

    internal enum AceroVigaHerramientaEditor
    {
        SeleccionarMover,
        MoverDosPuntos,
        CopiarDosPuntos,
        AplicarTipoSeleccion,
        AgregarLongitudinal,
        DistribuirLongitudinales,
        EstriboPerimetral,
        EstriboRectangular,
        EstriboRombo,
        EstriboLibreCerrado,
        TrabaAbierta,
        HorizontalAlmaDosPuntos,
        GanchoC,
        GanchoS,
        CambiarGancho,
        Eliminar
    }


    internal sealed class AceroVigaReglaGrupoLongitudinalForm :
        WinForms.Form
    {
        private readonly WinForms.ComboBox cmbRegla;
        private readonly WinForms.NumericUpDown nudEspaciado;
        private readonly WinForms.NumericUpDown nudCantidad;
        private readonly WinForms.Label lblResultado;
        private readonly double longitudDisponibleCm;

        public AceroVigaReglaGrupoLongitudinal ReglaSeleccionada
        {
            get
            {
                return cmbRegla.SelectedIndex == 1
                    ? AceroVigaReglaGrupoLongitudinal.EspaciadoMaximo
                    : AceroVigaReglaGrupoLongitudinal.NumeroFijo;
            }
        }

        public double EspaciadoCm
        {
            get { return (double)nudEspaciado.Value; }
        }

        public int Cantidad
        {
            get { return (int)nudCantidad.Value; }
        }

        public AceroVigaReglaGrupoLongitudinalForm(
            double longitudCm,
            AceroVigaReglaGrupoLongitudinal reglaInicial,
            double espaciadoInicialCm,
            int cantidadInicial)
        {
            longitudDisponibleCm = Math.Max(0.0, longitudCm);

            Text = "MYG - Modificar distribución longitudinal";
            StartPosition = WinForms.FormStartPosition.CenterParent;
            FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            TopMost = true;
            ClientSize = new Drawing.Size(470, 285);
            Font = new Drawing.Font("Segoe UI", 9F);
            BackColor = Drawing.Color.FromArgb(247, 248, 250);

            Controls.Add(new WinForms.Label
            {
                Left = 18,
                Top = 16,
                Width = 430,
                Height = 25,
                Text = "MODIFICAR GRUPO LONGITUDINAL",
                Font = new Drawing.Font(
                    "Segoe UI",
                    10F,
                    Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(0, 90, 160),
                TextAlign = Drawing.ContentAlignment.MiddleCenter
            });

            Controls.Add(new WinForms.Label
            {
                Left = 22,
                Top = 50,
                Width = 420,
                Height = 22,
                Text = "Longitud disponible: " +
                    longitudDisponibleCm.ToString("0.##") + " cm"
            });

            Controls.Add(new WinForms.Label
            {
                Left = 22,
                Top = 87,
                Width = 145,
                Height = 22,
                Text = "Regla:"
            });

            cmbRegla = new WinForms.ComboBox
            {
                Left = 170,
                Top = 83,
                Width = 270,
                DropDownStyle = WinForms.ComboBoxStyle.DropDownList
            };
            cmbRegla.Items.Add("Número fijo");
            cmbRegla.Items.Add("Espaciado máximo");
            cmbRegla.SelectedIndex =
                reglaInicial == AceroVigaReglaGrupoLongitudinal.EspaciadoMaximo
                    ? 1
                    : 0;
            Controls.Add(cmbRegla);

            Controls.Add(new WinForms.Label
            {
                Left = 22,
                Top = 125,
                Width = 145,
                Height = 22,
                Text = "Espaciado máximo:"
            });

            nudEspaciado = new WinForms.NumericUpDown
            {
                Left = 170,
                Top = 121,
                Width = 105,
                DecimalPlaces = 2,
                Minimum = 0.10M,
                Maximum = 1000M,
                Increment = 0.50M,
                Value = (decimal)Math.Max(0.10, espaciadoInicialCm)
            };
            Controls.Add(nudEspaciado);
            Controls.Add(new WinForms.Label
            {
                Left = 282,
                Top = 125,
                Width = 35,
                Height = 22,
                Text = "cm"
            });

            Controls.Add(new WinForms.Label
            {
                Left = 22,
                Top = 161,
                Width = 145,
                Height = 22,
                Text = "Número de barras:"
            });

            nudCantidad = new WinForms.NumericUpDown
            {
                Left = 170,
                Top = 157,
                Width = 105,
                Minimum = 1,
                Maximum = 1002,
                Value = Math.Max(1, cantidadInicial)
            };
            Controls.Add(nudCantidad);

            lblResultado = new WinForms.Label
            {
                Left = 22,
                Top = 194,
                Width = 420,
                Height = 34,
                ForeColor = Drawing.Color.FromArgb(65, 65, 65)
            };
            Controls.Add(lblResultado);

            WinForms.Button aceptar = new WinForms.Button
            {
                Left = 278,
                Top = 238,
                Width = 82,
                Height = 30,
                Text = "APLICAR",
                DialogResult = WinForms.DialogResult.OK,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat
            };
            aceptar.FlatAppearance.BorderSize = 0;
            Controls.Add(aceptar);

            WinForms.Button cancelar = new WinForms.Button
            {
                Left = 367,
                Top = 238,
                Width = 82,
                Height = 30,
                Text = "CANCELAR",
                DialogResult = WinForms.DialogResult.Cancel
            };
            Controls.Add(cancelar);

            AcceptButton = aceptar;
            CancelButton = cancelar;

            cmbRegla.SelectedIndexChanged += (s, e) => ActualizarControles();
            nudEspaciado.ValueChanged += (s, e) => ActualizarResumen();
            nudCantidad.ValueChanged += (s, e) => ActualizarResumen();
            ActualizarControles();
        }

        private void ActualizarControles()
        {
            bool numeroFijo = cmbRegla.SelectedIndex == 0;
            nudCantidad.Enabled = numeroFijo;
            nudEspaciado.Enabled = !numeroFijo;
            ActualizarResumen();
        }

        private void ActualizarResumen()
        {
            if (cmbRegla.SelectedIndex == 0)
            {
                int cantidad = Math.Max(1, (int)nudCantidad.Value);
                double separacionReal = cantidad <= 1
                    ? 0.0
                    : longitudDisponibleCm / (cantidad - 1);
                lblResultado.Text =
                    "Se conservarán " + cantidad +
                    " barras ocupando todo el tramo. Separación real: " +
                    separacionReal.ToString("0.##") + " cm.";
                return;
            }

            double espaciado = Math.Max(0.10, (double)nudEspaciado.Value);
            int cantidadMaximo = longitudDisponibleCm <= 1e-9
                ? 1
                : Math.Max(
                    2,
                    (int)Math.Ceiling(
                        longitudDisponibleCm / espaciado) + 1);
            double real = cantidadMaximo <= 1
                ? 0.0
                : longitudDisponibleCm / (cantidadMaximo - 1);
            lblResultado.Text =
                "Se crearán " + cantidadMaximo +
                " barras ocupando todo el tramo. Espaciado real: " +
                real.ToString("0.##") +
                " cm, sin superar el máximo indicado.";
        }
    }

    public sealed class AceroVigaEditorSeccionForm : WinForms.Form
    {
        private const double Tol = 1e-7;

        private sealed class ReferenciaLongitudinalMm
        {
            public AceroVigaPuntoMm Centro { get; set; }
            public double DiametroMm { get; set; }
        }
        private readonly List<AceroVigaPuntoMm> contornoConcretoMm;
        private readonly List<RebarBarType> tiposDisponibles;
        private AceroVigaDisenoSeccion disenoTrabajo;

        private readonly AceroVigaModoEditorInicial modoEditorActual;

        private WinForms.Panel panelHerramientas;
        private WinForms.Panel panelDerecho;
        private LienzoSeccion panelLienzo;
        private WinForms.ComboBox cmbTipoLongitudinal;
        private WinForms.ComboBox cmbTipoEstribo;
        private WinForms.NumericUpDown nudRecubrimiento;
        private WinForms.NumericUpDown nudCantidadDistribucion;
        private WinForms.ComboBox cmbGuiaCapaActiva;
        private WinForms.TextBox txtSeparacionCapa;
        private WinForms.Button btnAplicarSeparacionCapa;
        private string guiaCapaActivaId = string.Empty;
        private WinForms.Label lblEstado;
        private WinForms.Label lblResumen;
        private WinForms.Label lblTituloEditor;
        private WinForms.Label lblAyudaEditor;
        private WinForms.GroupBox grpLongitudinales;
        private WinForms.GroupBox grpEstribos;
        private WinForms.Button btnSeleccionarMover;
        private WinForms.Button btnEliminarElemento;
        private WinForms.Button btnDeshacerEditor;
        private WinForms.Button btnLimpiarEditor;
        private WinForms.Button btnGuardarEditor;
        private WinForms.Button btnCargarEditor;
        private WinForms.Button btnCancelarCroquisEditor;
        private WinForms.Button btnAceptar;
        private WinForms.Button btnCancelar;
        private WinForms.Panel panelBotones;

        private bool modoIncrustado;
        private bool modoIntegradoSinDuplicados;

        private Func<RebarBarType> obtenerTipoLongitudinalExterno;
        private Func<RebarBarType> obtenerTipoEstriboExterno;
        private Func<double> obtenerRecubrimientoExterno;

        private AceroVigaPuntoMm primerPuntoHerramienta;
        private double diametroPrimerLongitudinalGanchoMm;
        private AceroVigaPuntoMm puntoBaseTransformacion;
        private AceroVigaPuntoMm puntoSnapActual;
        private string textoSnapActual = string.Empty;

        // El vértice más cercano se detecta siempre que el cursor pasa por el
        // lienzo. Tiene una tolerancia mayor y prioridad absoluta sobre medio,
        // cercano, perpendicular, intersección y proyecciones predictivas.
        private AceroVigaPuntoMm verticePrioritarioActual;
        private string textoVerticePrioritarioActual = string.Empty;
        private bool verticePrioritarioCapturado;
        private const float ToleranciaVerticePrioritarioPx = 24F;
        private const float ToleranciaSnapGeneralPx = 13F;

        private bool osnapActivo = true;
        private bool osnapExtremo = true;
        private bool osnapMedio = true;
        private bool osnapCentro = true;
        private bool osnapInterseccion = true;
        private bool osnapPerpendicular = true;
        private bool osnapCercano = true;

        private AceroVigaBarraOsnap barraOsnapIntegrada;
        private bool trazoPausado;
        private WinForms.Button btnPausarTrazoExterno;

        /// <summary>
        /// Se dispara al pulsar APLICAR CAMBIOS cuando el editor está incrustado
        /// dentro de AceroVigasMainForm. El editor no se cierra.
        /// </summary>
        public event Action<AceroVigaDisenoSeccion> DisenoAplicado;

        /// <summary>
        /// Se dispara cuando cambia la selección editable del lienzo. La pestaña
        /// principal lo usa para habilitar o deshabilitar el botón APLICAR situado
        /// junto al desplegable del tipo de barra.
        /// </summary>
        public event EventHandler EstadoSeleccionTipoCambiado;

        private AceroVigaHerramientaEditor herramienta =
            AceroVigaHerramientaEditor.SeleccionarMover;

        private readonly List<AceroVigaPuntoMm> puntosCroquisActual =
            new List<AceroVigaPuntoMm>();

        private AceroVigaPuntoMm primerPuntoDistribucion;

        // DISTRIBUIR 2 PUNTOS se define mediante clic izquierdo sostenido:
        // MouseDown fija el inicio, MouseMove muestra la previsualización y
        // MouseUp confirma el tramo y abre la regla paramétrica.
        private bool creandoDistribucionLongitudinalConArrastre;
        private AceroVigaPuntoMm puntoInicioDistribucionArrastre;
        private AceroVigaPuntoMm puntoFinDistribucionArrastre;
        private double parametroInicioDistribucionArrastre = -1.0;
        private double parametroFinDistribucionArrastre = -1.0;

        // V11.2 - BLOQUEO INTUITIVO DE CAPA PARA DISTRIBUIR 2 PUNTOS.
        // Si el primer punto se toma sobre una guía Superior/Inferior,
        // el segundo extremo se mantiene alineado con esa misma guía.
        private string idGuiaDistribucionArrastreMYG = string.Empty;

        private AceroVigaReglaGrupoLongitudinal ultimaReglaDistribucion =
            AceroVigaReglaGrupoLongitudinal.NumeroFijo;
        private double ultimoEspaciadoDistribucionCm = 20.0;

        private string idSeleccionado = string.Empty;
        private int indiceVerticeSeleccionado = -1;

        // Selección múltiple de estribos tipo AutoCAD/Revit. El ID primario se
        // conserva en idSeleccionado para operaciones que requieren un elemento
        // activo o un vértice específico.
        private readonly HashSet<string> idsEstribosSeleccionados =
            new HashSet<string>(StringComparer.Ordinal);

        // Selección múltiple longitudinal. Un conjunto se almacena por su ID de
        // grupo; las barras creadas individualmente se almacenan por su propio ID.
        // idSeleccionado se mantiene como representante primario para conservar
        // compatibilidad con las operaciones existentes y el doble clic.
        private readonly HashSet<string> idsGruposLongitudinalesSeleccionados =
            new HashSet<string>(StringComparer.Ordinal);
        private readonly HashSet<string> idsBarrasLongitudinalesSeleccionadas =
            new HashSet<string>(StringComparer.Ordinal);

        private bool seleccionandoRegionLongitudinal;
        private Drawing.Point inicioSeleccionRegionLongitudinal;
        private Drawing.Point finSeleccionRegionLongitudinal;
        private bool agregarSeleccionRegionLongitudinal;

        private bool seleccionandoRegionEstribos;
        private Drawing.Point inicioSeleccionRegionEstribos;
        private Drawing.Point finSeleccionRegionEstribos;
        private bool agregarSeleccionRegionEstribos;

        private bool arrastrando;

        // Edición directa de los extremos de un conjunto longitudinal creado
        // mediante DISTRIBUIR 2 PUNTOS. Los controles permanecen visibles aunque
        // la primera o última barra estén ocultas por superposición.
        private bool arrastrandoExtremoGrupoLongitudinal;
        private string idGrupoLongitudinalArrastreExtremo = string.Empty;
        private bool arrastrandoInicioGrupoLongitudinal;

        // RECTÁNGULO y ROMBO: clic izquierdo sostenido, arrastre con preview y
        // creación al soltar. CROQUIS LIBRE: cada clic confirma un vértice y
        // MouseMove previsualiza el siguiente tramo hasta el próximo clic.
        private bool creandoEstriboConArrastre;
        private AceroVigaHerramientaEditor herramientaArrastre;
        private AceroVigaPuntoMm puntoInicioArrastre;
        private AceroVigaPuntoMm puntoActualArrastre;
        private Drawing.Point puntoPantallaInicioArrastre;
        private readonly List<AceroVigaPuntoMm> puntosCroquisArrastre =
            new List<AceroVigaPuntoMm>();

        private readonly Stack<AceroVigaDisenoSeccion> historial =
            new Stack<AceroVigaDisenoSeccion>();

        private readonly List<WinForms.Button> botonesHerramienta =
            new List<WinForms.Button>();

        private Drawing.RectangleF rectModeloPantalla;
        private double minYModelo;
        private double maxYModelo;
        private double minZModelo;
        private double maxZModelo;

        // Navegación 2D equivalente al módulo de columnas.
        // Rueda del mouse: zoom centrado en la posición del cursor.
        // Botón central sostenido: paneo de la vista.
        // Doble clic con botón central: ajustar nuevamente toda la sección.
        private double zoomVista = 1.0;
        private double panVistaX = 0.0;
        private double panVistaY = 0.0;
        private bool paneandoVista;
        private Drawing.Point ultimoPuntoPaneo;

        public AceroVigaDisenoSeccion DisenoResultado { get; private set; }

        public AceroVigaEditorSeccionForm(
            IEnumerable<AceroVigaPuntoMm> contornoSeccionMm,
            IEnumerable<RebarBarType> tipos,
            RebarBarType tipoLongitudinalInicial,
            RebarBarType tipoEstriboInicial,
            double recubrimientoCm,
            AceroVigaDisenoSeccion disenoActual,
            AceroVigaModoEditorInicial modoInicial,
            string nombreSeccion)
        {
            modoEditorActual = modoInicial;

            contornoConcretoMm = NormalizarContorno(contornoSeccionMm);
            tiposDisponibles = tipos == null
                ? new List<RebarBarType>()
                : tipos.Where(x => x != null).OrderBy(x => x.Name).ToList();

            disenoTrabajo = disenoActual != null
                ? disenoActual.Copiar()
                : new AceroVigaDisenoSeccion();

            if (recubrimientoCm > 0.0)
                EstablecerRecubrimientoActivo(recubrimientoCm);

            disenoTrabajo.NombreSeccionReferencia = nombreSeccion ?? string.Empty;
            CalcularDimensionesReferencia();

            Text = "MYG - Editor 2D de acero en sección de viga";
            StartPosition = WinForms.FormStartPosition.CenterParent;
            FormBorderStyle = WinForms.FormBorderStyle.Sizable;
            MinimizeBox = false;
            MaximizeBox = true;
            ShowInTaskbar = false;
            TopMost = true;
            BackColor = Drawing.Color.FromArgb(244, 247, 250);
            Font = new Drawing.Font("Segoe UI", 9F);
            ClientSize = new Drawing.Size(1160, 760);
            MinimumSize = new Drawing.Size(980, 680);

            CrearInterfaz();
            CargarTipos(tipoLongitudinalInicial, tipoEstriboInicial);

            nudRecubrimiento.Value = (decimal)Math.Max(
                (double)nudRecubrimiento.Minimum,
                Math.Min(
                    (double)nudRecubrimiento.Maximum,
                    ObtenerRecubrimientoActivo()));

            herramienta = modoInicial == AceroVigaModoEditorInicial.Estribos
                ? AceroVigaHerramientaEditor.EstriboPerimetral
                : AceroVigaHerramientaEditor.AgregarLongitudinal;

            ActualizarEstadoHerramienta();
            ActualizarResumen();
        }

        private double ObtenerRecubrimientoActivo()
        {
            if (modoIntegradoSinDuplicados &&
                obtenerRecubrimientoExterno != null)
            {
                try
                {
                    double externo = obtenerRecubrimientoExterno();
                    if (externo > 0.0 &&
                        !double.IsNaN(externo) &&
                        !double.IsInfinity(externo))
                    {
                        return externo;
                    }
                }
                catch
                {
                }
            }

            double valor = modoEditorActual ==
                AceroVigaModoEditorInicial.Estribos
                    ? disenoTrabajo.RecubrimientoEstribosCm
                    : disenoTrabajo.RecubrimientoLongitudinalCm;

            if (valor > 0.0)
                return valor;

            return disenoTrabajo.RecubrimientoCm > 0.0
                ? disenoTrabajo.RecubrimientoCm
                : 4.0;
        }

        private void EstablecerRecubrimientoActivo(double valorCm)
        {
            double valor = valorCm > 0.0 ? valorCm : 4.0;

            disenoTrabajo.RecubrimientoCm = valor;

            if (modoEditorActual ==
                AceroVigaModoEditorInicial.Estribos)
            {
                disenoTrabajo.RecubrimientoEstribosCm = valor;
            }
            else
            {
                disenoTrabajo.RecubrimientoLongitudinalCm = valor;
            }
        }

        /// <summary>
        /// Convierte esta misma ventana en un formulario hijo incrustado.
        /// No se crea ninguna ventana emergente y APLICAR CAMBIOS conserva
        /// el editor visible dentro del MAIN.
        /// </summary>
        public void ConfigurarComoEditorIncrustado()
        {
            modoIncrustado = true;

            TopLevel = false;
            FormBorderStyle = WinForms.FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = false;
            ControlBox = false;
            MinimizeBox = false;
            MaximizeBox = false;
            Dock = WinForms.DockStyle.Fill;
            MinimumSize = Drawing.Size.Empty;
            MaximumSize = Drawing.Size.Empty;
            Text = string.Empty;

            if (panelHerramientas != null)
            {
                // En alturas reducidas toda la botonera queda disponible mediante
                // desplazamiento, sin recortar GUARDAR, CARGAR ni el resumen.
                panelHerramientas.AutoScroll = true;
            }

            if (btnCancelar != null)
                btnCancelar.Visible = false;

            // Evita que Enter o Escape cierren accidentalmente un formulario hijo.
            AcceptButton = null;
            CancelButton = null;

            if (btnAceptar != null)
            {
                btnAceptar.Text =
                    modoEditorActual == AceroVigaModoEditorInicial.Estribos
                        ? "APLICAR ESTRIBOS"
                        : "APLICAR LONGITUDINALES";
                btnAceptar.Width = 190;
            }

            AjustarBotonesInferiores();
        }

        /// <summary>
        /// Integra el editor directamente en la pestaña de vigas. Los tipos de
        /// barra y el recubrimiento se leen desde los controles de la propia
        /// pestaña, por lo que no se vuelven a mostrar entradas duplicadas.
        /// </summary>
        public void ConfigurarComoEditorIntegradoEnPestana(
            Func<RebarBarType> obtenerTipoLongitudinal,
            Func<RebarBarType> obtenerTipoEstribo,
            Func<double> obtenerRecubrimiento)
        {
            obtenerTipoLongitudinalExterno = obtenerTipoLongitudinal;
            obtenerTipoEstriboExterno = obtenerTipoEstribo;
            obtenerRecubrimientoExterno = obtenerRecubrimiento;
            modoIntegradoSinDuplicados = true;

            ConfigurarComoEditorIncrustado();

            BackColor = Drawing.Color.FromArgb(245, 247, 250);

            if (panelBotones != null)
                panelBotones.Visible = false;

            if (panelHerramientas != null)
            {
                panelHerramientas.Width =
                    modoEditorActual == AceroVigaModoEditorInicial.Estribos
                        ? 315
                        : 275;
                panelHerramientas.BackColor =
                    Drawing.Color.FromArgb(245, 247, 250);
                panelHerramientas.BorderStyle = WinForms.BorderStyle.None;
                panelHerramientas.Padding = new WinForms.Padding(8);
                panelHerramientas.AutoScroll = true;
            }

            ReconstruirHerramientasIntegradas();
            CrearBarraOsnapIntegrada();
            RefrescarEntradasExternas();
        }

        /// <summary>
        /// Convierte el editor en el lienzo de la pestaña, con el mismo criterio
        /// visual del módulo de columnas: configuración y herramientas a la
        /// izquierda, barra de edición sobre la vista y sección a la derecha.
        /// El editor no muestra una segunda columna de parámetros.
        /// </summary>
        public void ConfigurarComoLienzoUnificadoEnPestana(
            Func<RebarBarType> obtenerTipoLongitudinal,
            Func<RebarBarType> obtenerTipoEstribo,
            Func<double> obtenerRecubrimiento)
        {
            obtenerTipoLongitudinalExterno = obtenerTipoLongitudinal;
            obtenerTipoEstriboExterno = obtenerTipoEstribo;
            obtenerRecubrimientoExterno = obtenerRecubrimiento;
            modoIntegradoSinDuplicados = true;

            ConfigurarComoEditorIncrustado();

            BackColor = Drawing.Color.White;

            if (panelHerramientas != null)
                panelHerramientas.Visible = false;

            if (panelBotones != null)
                panelBotones.Visible = false;

            if (panelDerecho != null)
            {
                panelDerecho.Padding = new WinForms.Padding(0);
                panelDerecho.BackColor = Drawing.Color.White;
            }

            if (lblEstado != null)
            {
                lblEstado.Visible = true;
                lblEstado.Height = 34;
                lblEstado.Padding = new WinForms.Padding(8, 0, 4, 0);
                lblEstado.BackColor = Drawing.Color.FromArgb(250, 250, 250);
                lblEstado.BorderStyle = WinForms.BorderStyle.FixedSingle;
            }

            if (panelLienzo != null)
            {
                panelLienzo.Dock = WinForms.DockStyle.Fill;
                panelLienzo.Margin = new WinForms.Padding(0);
                panelLienzo.BorderStyle = WinForms.BorderStyle.FixedSingle;
            }

            CrearBarraOsnapIntegrada();
            RefrescarEntradasExternas();
            ActualizarEstadoHerramienta();
        }

        /// <summary>
        /// Crea únicamente la botonera de herramientas que se ubica en la
        /// columna izquierda de la pestaña. No duplica tipo de barra ni
        /// recubrimiento; ambos se leen de los controles principales de vigas.
        /// </summary>
        public WinForms.Panel CrearPanelHerramientasPestanaUnificada(int ancho)
        {
            // Formato V8: misma jerarquía visual del módulo de columnas.
            // Las acciones de selección/edición permanecen en la franja superior
            // de la vista; aquí solo aparecen las herramientas de creación.
            int anchoSeguro = Math.Max(360, ancho);
            int margen = 6;
            int separacion = 6;
            int anchoUtil = Math.Max(320, anchoSeguro - margen * 2);
            int mitad = Math.Max(120, (anchoUtil - separacion) / 2);
            int y = 4;

            WinForms.Panel panel = new WinForms.Panel
            {
                Width = anchoSeguro,
                Height = modoEditorActual == AceroVigaModoEditorInicial.Estribos
                    ? 184
                    : 164,
                BackColor = Drawing.Color.White,
                BorderStyle = WinForms.BorderStyle.None,
                AutoScroll = false
            };

            WinForms.Label titulo = new WinForms.Label
            {
                Text = "HERRAMIENTAS EN PLANTA",
                Left = margen,
                Top = y,
                Width = anchoUtil,
                Height = 22,
                Font = new Drawing.Font(
                    "Segoe UI",
                    8.7F,
                    Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(0, 90, 160)
            };
            panel.Controls.Add(titulo);
            y += 27;

            if (modoEditorActual == AceroVigaModoEditorInicial.Longitudinales)
            {
                panel.Height = 208;

                WinForms.Button agregar = CrearBotonHerramienta(
                    "AGREGAR BARRA", margen, y,
                    AceroVigaHerramientaEditor.AgregarLongitudinal, mitad);
                WinForms.Button distribuir = CrearBotonHerramienta(
                    "DISTRIBUIR 2 PUNTOS", margen + mitad + separacion, y,
                    AceroVigaHerramientaEditor.DistribuirLongitudinales, mitad);
                panel.Controls.Add(agregar);
                panel.Controls.Add(distribuir);
                y += 31;

                WinForms.Label cantidad = new WinForms.Label
                {
                    Text = "Cantidad:",
                    Left = margen,
                    Top = y + 4,
                    Width = 70,
                    Height = 22,
                    Font = new Drawing.Font("Segoe UI", 8.2F)
                };
                nudCantidadDistribucion.Left = margen + 72;
                nudCantidadDistribucion.Top = y;
                nudCantidadDistribucion.Width = 58;
                WinForms.Button limpiar = CrearBotonSimple(
                    "LIMPIAR LONGITUDINALES",
                    margen + 138, y, anchoUtil - 138);
                limpiar.Click += (s, e) => LimpiarDiseno();
                panel.Controls.Add(cantidad);
                panel.Controls.Add(nudCantidadDistribucion);
                panel.Controls.Add(limpiar);
                y += 31;

                WinForms.Label tituloCapas = new WinForms.Label
                {
                    Text = "CAPAS GUÍA LONGITUDINALES",
                    Left = margen,
                    Top = y + 1,
                    Width = anchoUtil,
                    Height = 20,
                    Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(0, 90, 160)
                };
                panel.Controls.Add(tituloCapas);
                y += 23;

                int w4 = Math.Max(64, (anchoUtil - 9) / 4);
                WinForms.Button masSup = CrearBotonSimple("+ SUP", margen, y, w4);
                WinForms.Button menosSup = CrearBotonSimple("- SUP", margen + w4 + 3, y, w4);
                WinForms.Button masInf = CrearBotonSimple("+ INF", margen + (w4 + 3) * 2, y, w4);
                WinForms.Button menosInf = CrearBotonSimple("- INF", margen + (w4 + 3) * 3, y, w4);
                masSup.Click += (s, e) => AgregarGuiaCapa(AceroVigaTipoCapaLongitudinal.Superior);
                menosSup.Click += (s, e) => EliminarGuiaCapa(AceroVigaTipoCapaLongitudinal.Superior);
                masInf.Click += (s, e) => AgregarGuiaCapa(AceroVigaTipoCapaLongitudinal.Inferior);
                menosInf.Click += (s, e) => EliminarGuiaCapa(AceroVigaTipoCapaLongitudinal.Inferior);
                panel.Controls.Add(masSup); panel.Controls.Add(menosSup);
                panel.Controls.Add(masInf); panel.Controls.Add(menosInf);
                y += 31;

                WinForms.Button central = CrearBotonSimple("+ CENTRAL", margen, y, mitad);
                WinForms.Button quitarCentral = CrearBotonSimple(
                    "- CENTRAL", margen + mitad + separacion, y, mitad);
                central.Click += (s, e) => AgregarGuiaCapa(AceroVigaTipoCapaLongitudinal.Central);
                quitarCentral.Click += (s, e) => EliminarGuiaCapa(AceroVigaTipoCapaLongitudinal.Central);
                panel.Controls.Add(central); panel.Controls.Add(quitarCentral);
                y += 31;

                WinForms.Label activa = new WinForms.Label
                {
                    Text = "Capa:",
                    Left = margen,
                    Top = y + 4,
                    Width = 42,
                    Height = 22,
                    Font = new Drawing.Font("Segoe UI", 8.2F)
                };
                cmbGuiaCapaActiva.Left = margen + 43;
                cmbGuiaCapaActiva.Top = y;
                cmbGuiaCapaActiva.Width = 128;
                WinForms.Label sep = new WinForms.Label
                {
                    Text = "Sep. libre:",
                    Left = margen + 177,
                    Top = y + 4,
                    Width = 68,
                    Height = 22,
                    Font = new Drawing.Font("Segoe UI", 8.0F)
                };
                txtSeparacionCapa.Left = margen + 244;
                txtSeparacionCapa.Top = y;
                txtSeparacionCapa.Width = 55;
                btnAplicarSeparacionCapa.Left = margen + 304;
                btnAplicarSeparacionCapa.Top = y;
                btnAplicarSeparacionCapa.Width = Math.Max(72, anchoUtil - 304);
                panel.Controls.Add(activa);
                panel.Controls.Add(cmbGuiaCapaActiva);
                panel.Controls.Add(sep);
                panel.Controls.Add(txtSeparacionCapa);
                panel.Controls.Add(btnAplicarSeparacionCapa);

                RefrescarComboGuiasCapas();
            }
            else
            {
                WinForms.Button rectangular = CrearBotonHerramienta(
                    "RECTÁNGULO",
                    margen,
                    y,
                    AceroVigaHerramientaEditor.EstriboRectangular,
                    mitad);
                WinForms.Button rombo = CrearBotonHerramienta(
                    "ROMBO",
                    margen + mitad + separacion,
                    y,
                    AceroVigaHerramientaEditor.EstriboRombo,
                    mitad);
                panel.Controls.Add(rectangular);
                panel.Controls.Add(rombo);
                y += 31;

                WinForms.Button adaptar = CrearBotonSimple(
                    "ADAPTAR CONTORNO",
                    margen,
                    y,
                    mitad);
                adaptar.Click += (s, e) =>
                {
                    AgregarEstriboPerimetral();
                    herramienta = AceroVigaHerramientaEditor.SeleccionarMover;
                    ActualizarEstadoHerramienta();
                };
                WinForms.Button croquis = CrearBotonHerramienta(
                    "CROQUIS LIBRE",
                    margen + mitad + separacion,
                    y,
                    AceroVigaHerramientaEditor.EstriboLibreCerrado,
                    mitad);
                panel.Controls.Add(adaptar);
                panel.Controls.Add(croquis);
                y += 31;

                WinForms.Button ganchoC = CrearBotonHerramienta(
                    "GANCHO TIPO C",
                    margen,
                    y,
                    AceroVigaHerramientaEditor.GanchoC,
                    mitad);
                WinForms.Button ganchoS = CrearBotonHerramienta(
                    "GANCHO TIPO S",
                    margen + mitad + separacion,
                    y,
                    AceroVigaHerramientaEditor.GanchoS,
                    mitad);
                panel.Controls.Add(ganchoC);
                panel.Controls.Add(ganchoS);
                y += 31;

                WinForms.Button cambiarGancho = CrearBotonHerramienta(
                    "CAMBIAR ESQUINA DE GANCHO",
                    margen,
                    y,
                    AceroVigaHerramientaEditor.CambiarGancho,
                    anchoUtil);
                panel.Controls.Add(cambiarGancho);
                y += 31;

                WinForms.Button limpiar = CrearBotonSimple(
                    "LIMPIAR TODO",
                    margen,
                    y,
                    anchoUtil);
                limpiar.Click += (s, e) => LimpiarDiseno();
                panel.Controls.Add(limpiar);
                y += 31;

            }

            return panel;
        }


        /// <summary>
        /// Barra superior de la vista de sección: seleccionar, eliminar,
        /// mover/copiar por dos puntos y pausar un croquis en curso.
        /// </summary>
        public WinForms.Panel CrearBarraEdicionSuperiorPestanaUnificada()
        {
            // Misma franja superior del módulo de columnas. OSNAP se dibuja
            // dentro del lienzo, debajo del título de la vista.
            WinForms.Panel panel = new WinForms.Panel
            {
                Dock = WinForms.DockStyle.Top,
                Height = 29,
                BackColor = Drawing.Color.FromArgb(246, 247, 249),
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };

            int x = 7;
            const int y = 2;

            WinForms.Button seleccionar = CrearBotonHerramienta(
                "SELECCIONAR",
                x,
                y,
                AceroVigaHerramientaEditor.SeleccionarMover,
                108);
            panel.Controls.Add(seleccionar);
            x += 112;

            WinForms.Button eliminar = CrearBotonHerramienta(
                "ELIMINAR",
                x,
                y,
                AceroVigaHerramientaEditor.Eliminar,
                92);
            panel.Controls.Add(eliminar);
            x += 96;

            WinForms.Button mover = CrearBotonHerramienta(
                "MOVER 2 PTOS",
                x,
                y,
                AceroVigaHerramientaEditor.MoverDosPuntos,
                112);
            panel.Controls.Add(mover);
            x += 116;

            WinForms.Button copiar = CrearBotonHerramienta(
                "COPIAR 2 PTOS",
                x,
                y,
                AceroVigaHerramientaEditor.CopiarDosPuntos,
                112);
            panel.Controls.Add(copiar);
            x += 116;

            btnPausarTrazoExterno = CrearBotonSimple(
                "PAUSAR TRAZO",
                x,
                y,
                112);
            btnPausarTrazoExterno.Click += (s, e) =>
            {
                trazoPausado = !trazoPausado;
                ActualizarBotonPausaTrazo();

                if (lblEstado != null)
                {
                    lblEstado.Text = trazoPausado
                        ? "TRAZO PAUSADO: pulse CONTINUAR TRAZO para seguir."
                        : "Trazo reanudado.";
                }

                if (panelLienzo != null)
                {
                    panelLienzo.Focus();
                    panelLienzo.Invalidate();
                }
            };
            panel.Controls.Add(btnPausarTrazoExterno);
            ActualizarBotonPausaTrazo();

            ActualizarMarcadoHerramientas();
            return panel;
        }


        private void ActualizarBotonPausaTrazo()
        {
            if (btnPausarTrazoExterno == null ||
                btnPausarTrazoExterno.IsDisposed)
            {
                return;
            }

            btnPausarTrazoExterno.Text = trazoPausado
                ? "CONTINUAR TRAZO"
                : "PAUSAR TRAZO";
            btnPausarTrazoExterno.BackColor = trazoPausado
                ? Drawing.Color.FromArgb(255, 238, 210)
                : Drawing.Color.White;
        }

        private bool EsHerramientaDeTrazoActiva()
        {
            return herramienta == AceroVigaHerramientaEditor.EstriboRectangular ||
                   herramienta == AceroVigaHerramientaEditor.EstriboRombo ||
                   herramienta == AceroVigaHerramientaEditor.EstriboLibreCerrado ||
                   herramienta == AceroVigaHerramientaEditor.TrabaAbierta ||
                   herramienta == AceroVigaHerramientaEditor.HorizontalAlmaDosPuntos ||
                   herramienta == AceroVigaHerramientaEditor.GanchoC ||
                   herramienta == AceroVigaHerramientaEditor.GanchoS ||
                   herramienta == AceroVigaHerramientaEditor.DistribuirLongitudinales;
        }

        public void RefrescarEntradasExternas()
        {
            double recubrimiento = ObtenerRecubrimientoActivo();
            EstablecerRecubrimientoActivo(recubrimiento);

            RebarBarType tipoLongitudinal = TipoLongitudinalActual;
            RebarBarType tipoEstribo = TipoEstriboActual;

            if (cmbTipoLongitudinal != null)
                SeleccionarTipo(cmbTipoLongitudinal, tipoLongitudinal);
            if (cmbTipoEstribo != null)
                SeleccionarTipo(cmbTipoEstribo, tipoEstribo);

            if (nudRecubrimiento != null)
            {
                decimal valor = (decimal)Math.Max(
                    (double)nudRecubrimiento.Minimum,
                    Math.Min(
                        (double)nudRecubrimiento.Maximum,
                        recubrimiento));

                if (nudRecubrimiento.Value != valor)
                    nudRecubrimiento.Value = valor;
            }

            RecalcularGuiasCapasLongitudinales();
            if (panelLienzo != null)
                panelLienzo.Invalidate();

            ActualizarResumen();
        }

        private void ReconstruirHerramientasIntegradas()
        {
            if (panelHerramientas == null)
                return;

            panelHerramientas.SuspendLayout();
            panelHerramientas.Controls.Clear();

            int ancho = panelHerramientas.Width - 18;
            int mitad = Math.Max(90, (ancho - 8) / 2);
            int y = 8;

            WinForms.Label titulo = new WinForms.Label
            {
                Text = modoEditorActual == AceroVigaModoEditorInicial.Estribos
                    ? "HERRAMIENTAS DE ESTRIBOS"
                    : "HERRAMIENTAS LONGITUDINALES",
                Left = 8,
                Top = y,
                Width = ancho,
                Height = 24,
                Font = new Drawing.Font(
                    "Segoe UI",
                    9.2F,
                    Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(0, 90, 160)
            };
            panelHerramientas.Controls.Add(titulo);
            y += 28;

            WinForms.Label ayuda = new WinForms.Label
            {
                Text = "El tipo de barra y el recubrimiento se toman de la configuración de esta pestaña.",
                Left = 8,
                Top = y,
                Width = ancho,
                Height = 38,
                Font = new Drawing.Font("Segoe UI", 7.8F),
                ForeColor = Drawing.Color.FromArgb(80, 80, 80)
            };
            panelHerramientas.Controls.Add(ayuda);
            y += 42;

            WinForms.Button seleccionar = CrearBotonHerramienta(
                modoEditorActual == AceroVigaModoEditorInicial.Estribos
                    ? "SELECCIONAR ESTR."
                    : "SELECCIONAR BARRA",
                8,
                y,
                AceroVigaHerramientaEditor.SeleccionarMover,
                mitad);

            WinForms.Button eliminar = CrearBotonHerramienta(
                "ELIMINAR",
                8 + mitad + 8,
                y,
                AceroVigaHerramientaEditor.Eliminar,
                mitad);

            panelHerramientas.Controls.Add(seleccionar);
            panelHerramientas.Controls.Add(eliminar);
            y += 34;

            WinForms.Button mover = CrearBotonHerramienta(
                "MOVER 2 PTOS",
                8,
                y,
                AceroVigaHerramientaEditor.MoverDosPuntos,
                mitad);

            WinForms.Button copiar = CrearBotonHerramienta(
                "COPIAR 2 PTOS",
                8 + mitad + 8,
                y,
                AceroVigaHerramientaEditor.CopiarDosPuntos,
                mitad);

            panelHerramientas.Controls.Add(mover);
            panelHerramientas.Controls.Add(copiar);
            y += 38;

            if (modoEditorActual == AceroVigaModoEditorInicial.Longitudinales)
            {
                WinForms.Button agregar = CrearBotonHerramienta(
                    "AGREGAR BARRA",
                    8,
                    y,
                    AceroVigaHerramientaEditor.AgregarLongitudinal,
                    ancho);
                panelHerramientas.Controls.Add(agregar);
                y += 34;

                WinForms.Button distribuir = CrearBotonHerramienta(
                    "DISTRIBUIR 2 PUNTOS",
                    8,
                    y,
                    AceroVigaHerramientaEditor.DistribuirLongitudinales,
                    ancho);
                panelHerramientas.Controls.Add(distribuir);
                y += 31;

                WinForms.Label lblCantidad = new WinForms.Label
                {
                    Text = "Cantidad:",
                    Left = 8,
                    Top = y + 4,
                    Width = 72,
                    Height = 22
                };
                nudCantidadDistribucion.Left = 82;
                nudCantidadDistribucion.Top = y;
                nudCantidadDistribucion.Width = 64;
                panelHerramientas.Controls.Add(lblCantidad);
                panelHerramientas.Controls.Add(nudCantidadDistribucion);
                y += 34;
            }
            else
            {
                WinForms.Button rectangular = CrearBotonHerramienta(
                    "RECTÁNGULO",
                    8,
                    y,
                    AceroVigaHerramientaEditor.EstriboRectangular,
                    mitad);

                WinForms.Button rombo = CrearBotonHerramienta(
                    "ROMBO",
                    8 + mitad + 8,
                    y,
                    AceroVigaHerramientaEditor.EstriboRombo,
                    mitad);

                panelHerramientas.Controls.Add(rectangular);
                panelHerramientas.Controls.Add(rombo);
                y += 34;

                WinForms.Button adaptar = CrearBotonSimple(
                    "ADAPTAR CONTORNO",
                    8,
                    y,
                    ancho);
                adaptar.Click += (s, e) =>
                {
                    AgregarEstriboPerimetral();
                    herramienta =
                        AceroVigaHerramientaEditor.SeleccionarMover;
                    ActualizarEstadoHerramienta();
                };
                panelHerramientas.Controls.Add(adaptar);
                y += 34;

                WinForms.Button croquis = CrearBotonHerramienta(
                    "CROQUIS LIBRE CERRADO",
                    8,
                    y,
                    AceroVigaHerramientaEditor.EstriboLibreCerrado,
                    ancho);
                panelHerramientas.Controls.Add(croquis);
                y += 34;

                WinForms.Button ganchoC = CrearBotonHerramienta(
                    "GANCHO TIPO C",
                    8,
                    y,
                    AceroVigaHerramientaEditor.GanchoC,
                    mitad);

                WinForms.Button ganchoS = CrearBotonHerramienta(
                    "GANCHO TIPO S",
                    8 + mitad + 8,
                    y,
                    AceroVigaHerramientaEditor.GanchoS,
                    mitad);

                panelHerramientas.Controls.Add(ganchoC);
                panelHerramientas.Controls.Add(ganchoS);
                y += 34;

                WinForms.Button cambiarGancho = CrearBotonHerramienta(
                    "CAMBIAR ESQUINA DE GANCHO",
                    8,
                    y,
                    AceroVigaHerramientaEditor.CambiarGancho,
                    ancho);
                panelHerramientas.Controls.Add(cambiarGancho);
                y += 31;
            }

            WinForms.Button aplicarTipo = CrearBotonSimple(
                "APLICAR TIPO A SELECCIÓN",
                8,
                y,
                ancho);
            aplicarTipo.Click += (s, e) =>
                AplicarTipoActualASeleccion();
            panelHerramientas.Controls.Add(aplicarTipo);
            y += 38;

            WinForms.Button deshacer = CrearBotonSimple(
                "DESHACER",
                8,
                y,
                mitad);
            deshacer.Click += (s, e) => Deshacer();

            WinForms.Button limpiar = CrearBotonSimple(
                modoEditorActual == AceroVigaModoEditorInicial.Estribos
                    ? "LIMPIAR ESTR."
                    : "LIMPIAR LONG.",
                8 + mitad + 8,
                y,
                mitad);
            limpiar.Click += (s, e) => LimpiarDiseno();

            panelHerramientas.Controls.Add(deshacer);
            panelHerramientas.Controls.Add(limpiar);
            y += 34;

            WinForms.Button guardar = CrearBotonSimple(
                "GUARDAR DISEÑO",
                8,
                y,
                mitad);
            guardar.Click += (s, e) => GuardarDiseno();

            WinForms.Button cargar = CrearBotonSimple(
                "CARGAR DISEÑO",
                8 + mitad + 8,
                y,
                mitad);
            cargar.Click += (s, e) => CargarDiseno();

            panelHerramientas.Controls.Add(guardar);
            panelHerramientas.Controls.Add(cargar);
            y += 38;

            if (modoEditorActual == AceroVigaModoEditorInicial.Estribos)
            {
                WinForms.Button cancelarTrazo = CrearBotonSimple(
                    "CANCELAR TRAZO",
                    8,
                    y,
                    ancho);
                cancelarTrazo.Click += (s, e) => CancelarCroquis();
                panelHerramientas.Controls.Add(cancelarTrazo);
                y += 31;
            }

            lblResumen = new WinForms.Label
            {
                Left = 8,
                Top = y,
                Width = ancho,
                Height = 60,
                Font = new Drawing.Font(
                    "Segoe UI",
                    8.2F,
                    Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(45, 45, 45)
            };
            panelHerramientas.Controls.Add(lblResumen);

            panelHerramientas.ResumeLayout(true);
            ActualizarResumen();
        }

        private AceroVigaBarraOsnap CrearBarraOsnapVisual()
        {
            AceroVigaBarraOsnap barra = new AceroVigaBarraOsnap();
            barra.EstablecerEstado(
                osnapActivo,
                osnapExtremo,
                osnapMedio,
                osnapCentro,
                osnapInterseccion,
                osnapPerpendicular,
                osnapCercano);

            barra.ConfiguracionCambiada += (s, e) =>
            {
                AceroVigaBarraOsnap actual = s as AceroVigaBarraOsnap;
                if (actual == null)
                    return;

                osnapActivo = actual.Activo;
                osnapExtremo = actual.Extremo;
                osnapMedio = actual.PuntoMedio;
                osnapCentro = actual.Centro;
                osnapInterseccion = actual.Interseccion;
                osnapPerpendicular = actual.Perpendicular;
                osnapCercano = actual.Cercano;

                puntoSnapActual = null;
                textoSnapActual = string.Empty;
                verticePrioritarioActual = null;
                textoVerticePrioritarioActual = string.Empty;
                verticePrioritarioCapturado = false;

                if (panelLienzo != null)
                    panelLienzo.Invalidate();
            };

            return barra;
        }

        private void CrearBarraOsnapIntegrada()
        {
            if (panelLienzo == null)
                return;

            if (barraOsnapIntegrada != null &&
                !barraOsnapIntegrada.IsDisposed)
            {
                if (barraOsnapIntegrada.Parent != null)
                    barraOsnapIntegrada.Parent.Controls.Remove(barraOsnapIntegrada);
                barraOsnapIntegrada.Dispose();
            }

            barraOsnapIntegrada = CrearBarraOsnapVisual();
            barraOsnapIntegrada.Left = 8;
            barraOsnapIntegrada.Top = 34;
            barraOsnapIntegrada.Height = 34;
            barraOsnapIntegrada.Width = Math.Max(
                360,
                Math.Min(620, panelLienzo.ClientSize.Width - 16));
            barraOsnapIntegrada.Anchor =
                WinForms.AnchorStyles.Left |
                WinForms.AnchorStyles.Top |
                WinForms.AnchorStyles.Right;

            panelLienzo.Controls.Add(barraOsnapIntegrada);
            barraOsnapIntegrada.BringToFront();
        }

        private WinForms.CheckBox CrearCheckOsnap(
            string texto,
            bool marcado,
            Action<bool> asignar,
            int ancho)
        {
            WinForms.CheckBox check = new WinForms.CheckBox
            {
                Text = texto,
                Width = ancho,
                Height = 21,
                Checked = marcado,
                AutoSize = false,
                Margin = new WinForms.Padding(1, 0, 1, 0),
                Font = new Drawing.Font("Segoe UI", 7.4F),
                BackColor = Drawing.Color.Transparent
            };

            check.CheckedChanged += (s, e) =>
            {
                asignar(check.Checked);
                if (panelLienzo != null)
                    panelLienzo.Invalidate();
            };

            return check;
        }

        /// <summary>
        /// Indica si existe un acero de la pestaña actual seleccionado y, por
        /// tanto, el botón APLICAR puede habilitarse.
        /// </summary>
        public bool TieneSeleccionParaCambiarTipo
        {
            get
            {
                if (modoEditorActual == AceroVigaModoEditorInicial.Estribos)
                {
                    if (disenoTrabajo == null ||
                        disenoTrabajo.Estribos == null)
                    {
                        return false;
                    }

                    return disenoTrabajo.Estribos.Any(elemento =>
                        elemento != null &&
                        !string.IsNullOrWhiteSpace(elemento.Id) &&
                        (idsEstribosSeleccionados.Contains(elemento.Id) ||
                         elemento.Id == idSeleccionado));
                }

                if (string.IsNullOrWhiteSpace(idSeleccionado))
                    return false;

                return disenoTrabajo != null &&
                       disenoTrabajo.Longitudinales != null &&
                       disenoTrabajo.Longitudinales.Any(elemento =>
                           elemento != null &&
                           elemento.Id == idSeleccionado);
            }
        }

        /// <summary>
        /// Tipo actual del acero seleccionado. Se usa únicamente para sincronizar
        /// el desplegable externo cuando el usuario selecciona un acero existente.
        /// </summary>
        public RebarBarType TipoBarraDeSeleccionActual
        {
            get
            {
                if (!TieneSeleccionParaCambiarTipo)
                    return null;

                if (modoEditorActual == AceroVigaModoEditorInicial.Estribos)
                {
                    AceroVigaEstribo2D estribo =
                        disenoTrabajo.Estribos.FirstOrDefault(elemento =>
                            elemento != null &&
                            elemento.Id == idSeleccionado);

                    return estribo != null ? estribo.TipoBarra : null;
                }

                AceroVigaBarraLongitudinal2D barra =
                    disenoTrabajo.Longitudinales.FirstOrDefault(elemento =>
                        elemento != null &&
                        elemento.Id == idSeleccionado);

                return barra != null ? barra.TipoBarra : null;
            }
        }

        public void AplicarTipoActualASeleccionDesdePestana()
        {
            AplicarTipoActualASeleccion();
            NotificarEstadoSeleccionTipoCambiado();
        }

        private void NotificarEstadoSeleccionTipoCambiado()
        {
            EventHandler manejador = EstadoSeleccionTipoCambiado;
            if (manejador != null)
                manejador(this, EventArgs.Empty);
        }

        private void ActualizarCoordenadasSeccionRealLongitudinales()
        {
            if (disenoTrabajo == null ||
                disenoTrabajo.Longitudinales == null ||
                contornoConcretoMm == null ||
                contornoConcretoMm.Count < 3)
            {
                return;
            }

            foreach (AceroVigaBarraLongitudinal2D barra in
                disenoTrabajo.Longitudinales)
            {
                if (barra == null || barra.Punto == null)
                    continue;

                RebarBarType tipo = barra.TipoBarra ?? TipoLongitudinalActual;
                List<AceroVigaPuntoMm> permitido =
                    ObtenerContornoCentrosLongitudinalMm(tipo);

                if (permitido == null || permitido.Count < 3)
                    continue;

                AceroVigaPuntoMm puntoExacto =
                    DesnormalizarEnCaja(barra.Punto, permitido);

                if (puntoExacto == null)
                    continue;

                // La posición se guarda en el sistema estable del concreto.
                // El diámetro y el recubrimiento ya están incorporados en la
                // ubicación exacta del centro que se ve en el editor.
                barra.PuntoSeccionReal =
                    NormalizarEnCaja(puntoExacto, contornoConcretoMm);

                // V10.4: además de la coordenada en la caja del concreto se
                // conserva una referencia geométrica respecto de la guía real.
                // Esta referencia es la que permite reconstruir correctamente
                // capas inclinadas, quebradas o pertenecientes a una cara 3D.
                barra.ParametroSobreGuia = -1.0;
                barra.DesfaseNormalGuiaMm = 0.0;

                if (!string.IsNullOrWhiteSpace(barra.GuiaCapaId) &&
                    disenoTrabajo.GuiasCapasLongitudinales != null)
                {
                    AceroVigaGuiaCapaLongitudinal2D guia =
                        disenoTrabajo.GuiasCapasLongitudinales.FirstOrDefault(x =>
                            x != null && string.Equals(
                                x.Id,
                                barra.GuiaCapaId,
                                StringComparison.Ordinal));

                    if (guia != null)
                    {
                        List<AceroVigaPuntoMm> puntosGuia =
                            ObtenerPuntosGuiaMm(guia, permitido);

                        double parametroGuia;
                        double desfaseNormalMm;
                        if (TryObtenerReferenciaNormalSobreGuia(
                                puntoExacto,
                                puntosGuia,
                                permitido,
                                out parametroGuia,
                                out desfaseNormalMm))
                        {
                            barra.ParametroSobreGuia = parametroGuia;
                            barra.DesfaseNormalGuiaMm = desfaseNormalMm;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Devuelve una copia del diseño que se está editando actualmente.
        /// </summary>
        public AceroVigaDisenoSeccion ObtenerDisenoTrabajo()
        {
            if (puntosCroquisActual.Count > 0)
                FinalizarCroquis();

            EstablecerRecubrimientoActivo(ObtenerRecubrimientoActivo());
            CalcularDimensionesReferencia();
            ActualizarCoordenadasSeccionRealLongitudinales();
            return disenoTrabajo.Copiar();
        }

        private void CrearInterfaz()
        {
            panelHerramientas = new WinForms.Panel
            {
                Dock = WinForms.DockStyle.Left,
                Width = 300,
                BackColor = Drawing.Color.FromArgb(235, 239, 244),
                Padding = new WinForms.Padding(12)
            };

            lblTituloEditor = new WinForms.Label
            {
                Text = modoEditorActual == AceroVigaModoEditorInicial.Estribos
                    ? "DISEÑO DE ESTRIBOS"
                    : "DISEÑO LONGITUDINAL",
                Left = 14,
                Top = 14,
                Width = 270,
                Height = 28,
                Font = new Drawing.Font("Segoe UI", 11F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(0, 90, 160)
            };

            lblAyudaEditor = new WinForms.Label
            {
                Text = modoEditorActual == AceroVigaModoEditorInicial.Estribos
                    ? "Configura únicamente los estribos de la sección. La línea discontinua representa el eje del estribo con el offset de recubrimiento."
                    : "Configura únicamente las barras longitudinales. Los estribos existentes se muestran solo como referencia y no se editan en esta pestaña.",
                Left = 14,
                Top = 45,
                Width = 270,
                Height = 55,
                ForeColor = Drawing.Color.FromArgb(80, 80, 80)
            };

            WinForms.Label lblRec = CrearEtiqueta("Recubrimiento nominal:", 14, 108, 170);
            nudRecubrimiento = new WinForms.NumericUpDown
            {
                Left = 185,
                Top = 104,
                Width = 70,
                DecimalPlaces = 1,
                Minimum = 0.5M,
                Maximum = 25M,
                Increment = 0.5M,
                Value = 4M,
                TextAlign = WinForms.HorizontalAlignment.Center
            };
            nudRecubrimiento.ValueChanged += (s, e) =>
            {
                if (!modoIntegradoSinDuplicados)
                    EstablecerRecubrimientoActivo((double)nudRecubrimiento.Value);

                RecalcularGuiasCapasLongitudinales();
                panelLienzo.Invalidate();
                ActualizarResumen();
            };
            WinForms.Label lblCm = CrearEtiqueta("cm", 260, 108, 30);

            grpLongitudinales = new WinForms.GroupBox
            {
                Text = "Configuración de longitudinales",
                Left = 12,
                Top = 140,
                Width = 276,
                Height = 185
            };

            cmbTipoLongitudinal = CrearComboTipo(14, 25, 245);
            WinForms.Button btnAgregar = CrearBotonHerramienta(
                "AGREGAR BARRA",
                14,
                58,
                AceroVigaHerramientaEditor.AgregarLongitudinal);

            WinForms.Button btnDistribuir = CrearBotonHerramienta(
                "DISTRIBUIR 2 PUNTOS",
                14,
                92,
                AceroVigaHerramientaEditor.DistribuirLongitudinales);

            WinForms.Label lblCantidad = CrearEtiqueta("Cantidad:", 14, 132, 70);
            nudCantidadDistribucion = new WinForms.NumericUpDown
            {
                Left = 84,
                Top = 128,
                Width = 65,
                Minimum = 2,
                Maximum = 100,
                Value = 4,
                TextAlign = WinForms.HorizontalAlignment.Center
            };

            InicializarControlesCapasLongitudinales();

            grpLongitudinales.Controls.Add(cmbTipoLongitudinal);
            grpLongitudinales.Controls.Add(btnAgregar);
            grpLongitudinales.Controls.Add(btnDistribuir);
            grpLongitudinales.Controls.Add(lblCantidad);
            grpLongitudinales.Controls.Add(nudCantidadDistribucion);

            grpEstribos = new WinForms.GroupBox
            {
                Text = "Stirrups / estribos",
                Left = 12,
                Top = 332,
                Width = 276,
                Height = 205
            };

            cmbTipoEstribo = CrearComboTipo(14, 25, 245);
            WinForms.Button btnPerimetral = CrearBotonHerramienta(
                "ESTRIBO PERIMETRAL OFFSET",
                14,
                58,
                AceroVigaHerramientaEditor.EstriboPerimetral);

            WinForms.Button btnCerrado = CrearBotonHerramienta(
                "CROQUIS CERRADO",
                14,
                92,
                AceroVigaHerramientaEditor.EstriboLibreCerrado);

            WinForms.Button btnAbierto = CrearBotonHerramienta(
                "TRABA / CROQUIS ABIERTO",
                14,
                126,
                AceroVigaHerramientaEditor.TrabaAbierta);

            WinForms.Label ayudaCroquis = new WinForms.Label
            {
                Text = "Clic para puntos. Enter o doble clic para terminar.",
                Left = 14,
                Top = 164,
                Width = 245,
                Height = 30,
                ForeColor = Drawing.Color.Gray,
                Font = new Drawing.Font("Segoe UI", 8F)
            };

            grpEstribos.Controls.Add(cmbTipoEstribo);
            grpEstribos.Controls.Add(btnPerimetral);
            grpEstribos.Controls.Add(btnCerrado);
            grpEstribos.Controls.Add(btnAbierto);
            grpEstribos.Controls.Add(ayudaCroquis);

            btnSeleccionarMover = CrearBotonHerramienta(
                "SELECCIONAR / MOVER",
                12,
                548,
                AceroVigaHerramientaEditor.SeleccionarMover,
                134);

            btnEliminarElemento = CrearBotonHerramienta(
                "ELIMINAR",
                154,
                548,
                AceroVigaHerramientaEditor.Eliminar,
                134);

            btnDeshacerEditor = CrearBotonSimple("DESHACER", 12, 584, 86);
            btnDeshacerEditor.Click += (s, e) => Deshacer();

            btnLimpiarEditor = CrearBotonSimple(
                modoEditorActual == AceroVigaModoEditorInicial.Estribos
                    ? "LIMPIAR ESTR."
                    : "LIMPIAR LONG.",
                103,
                584,
                86);
            btnLimpiarEditor.Click += (s, e) => LimpiarDiseno();

            btnGuardarEditor = CrearBotonSimple("GUARDAR", 194, 584, 94);
            btnGuardarEditor.Click += (s, e) => GuardarDiseno();

            btnCargarEditor = CrearBotonSimple("CARGAR DISEÑO", 12, 620, 134);
            btnCargarEditor.Click += (s, e) => CargarDiseno();

            btnCancelarCroquisEditor = CrearBotonSimple("CANCELAR CROQUIS", 154, 620, 134);
            btnCancelarCroquisEditor.Click += (s, e) => CancelarCroquis();

            lblResumen = new WinForms.Label
            {
                Left = 14,
                Top = 660,
                Width = 270,
                Height = 45,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(45, 45, 45)
            };

            panelHerramientas.Controls.Add(lblTituloEditor);
            panelHerramientas.Controls.Add(lblAyudaEditor);
            panelHerramientas.Controls.Add(lblRec);
            panelHerramientas.Controls.Add(nudRecubrimiento);
            panelHerramientas.Controls.Add(lblCm);
            panelHerramientas.Controls.Add(grpLongitudinales);
            panelHerramientas.Controls.Add(grpEstribos);
            panelHerramientas.Controls.Add(btnSeleccionarMover);
            panelHerramientas.Controls.Add(btnEliminarElemento);
            panelHerramientas.Controls.Add(btnDeshacerEditor);
            panelHerramientas.Controls.Add(btnLimpiarEditor);
            panelHerramientas.Controls.Add(btnGuardarEditor);
            panelHerramientas.Controls.Add(btnCargarEditor);
            panelHerramientas.Controls.Add(btnCancelarCroquisEditor);
            panelHerramientas.Controls.Add(lblResumen);

            AplicarModoPorPestana();

            panelDerecho = new WinForms.Panel
            {
                Dock = WinForms.DockStyle.Fill,
                BackColor = Drawing.Color.White,
                Padding = new WinForms.Padding(12)
            };

            lblEstado = new WinForms.Label
            {
                Dock = WinForms.DockStyle.Top,
                Height = 42,
                TextAlign = Drawing.ContentAlignment.MiddleLeft,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(0, 90, 160)
            };

            panelBotones = new WinForms.Panel
            {
                Dock = WinForms.DockStyle.Bottom,
                Height = 58,
                BackColor = Drawing.Color.FromArgb(246, 248, 251)
            };

            btnAceptar = new WinForms.Button
            {
                Text = "APLICAR DISEÑO",
                Width = 150,
                Height = 34,
                Top = 12,
                Anchor = WinForms.AnchorStyles.Top | WinForms.AnchorStyles.Right,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat
            };
            btnAceptar.FlatAppearance.BorderSize = 0;
            btnAceptar.Click += (s, e) => AceptarDiseno();

            btnCancelar = new WinForms.Button
            {
                Text = "CANCELAR",
                Width = 110,
                Height = 34,
                Top = 12,
                Anchor = WinForms.AnchorStyles.Top | WinForms.AnchorStyles.Right,
                DialogResult = WinForms.DialogResult.Cancel
            };

            panelBotones.Resize += (s, e) => AjustarBotonesInferiores();
            panelBotones.Controls.Add(btnAceptar);
            panelBotones.Controls.Add(btnCancelar);

            panelLienzo = new LienzoSeccion(this)
            {
                Dock = WinForms.DockStyle.Fill,
                BackColor = Drawing.Color.White,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                Cursor = WinForms.Cursors.Cross
            };

            panelDerecho.Controls.Add(panelLienzo);
            panelDerecho.Controls.Add(lblEstado);
            panelDerecho.Controls.Add(panelBotones);

            Controls.Add(panelDerecho);
            Controls.Add(panelHerramientas);

            AcceptButton = btnAceptar;
            CancelButton = btnCancelar;
            AjustarBotonesInferiores();
        }


        private void AplicarModoPorPestana()
        {
            bool modoEstribos =
                modoEditorActual == AceroVigaModoEditorInicial.Estribos;

            if (grpLongitudinales != null)
            {
                grpLongitudinales.Visible = !modoEstribos;
                grpLongitudinales.Top = 140;
            }

            if (grpEstribos != null)
            {
                grpEstribos.Visible = modoEstribos;
                grpEstribos.Top = 140;
            }

            int topAcciones = modoEstribos
                ? 356
                : 336;

            if (btnSeleccionarMover != null)
            {
                btnSeleccionarMover.Top = topAcciones;
                btnSeleccionarMover.Text = modoEstribos
                    ? "SELECCIONAR ESTRIBO"
                    : "SELECCIONAR BARRA";
            }

            if (btnEliminarElemento != null)
            {
                btnEliminarElemento.Top = topAcciones;
                btnEliminarElemento.Text = modoEstribos
                    ? "ELIMINAR ESTRIBO"
                    : "ELIMINAR BARRA";
            }

            int topFila2 = topAcciones + 36;
            int topFila3 = topAcciones + 72;

            if (btnDeshacerEditor != null)
                btnDeshacerEditor.Top = topFila2;

            if (btnLimpiarEditor != null)
                btnLimpiarEditor.Top = topFila2;

            if (btnGuardarEditor != null)
                btnGuardarEditor.Top = topFila2;

            if (btnCargarEditor != null)
            {
                btnCargarEditor.Top = topFila3;
                btnCargarEditor.Left = 12;
                btnCargarEditor.Width = modoEstribos ? 134 : 276;
            }

            if (btnCancelarCroquisEditor != null)
            {
                btnCancelarCroquisEditor.Visible = modoEstribos;
                btnCancelarCroquisEditor.Top = topFila3;
            }

            if (lblResumen != null)
            {
                lblResumen.Top = topFila3 + 42;
                lblResumen.Height = 54;
            }
        }

        private void AjustarBotonesInferiores()
        {
            if (panelBotones == null || btnAceptar == null)
                return;

            if (modoIncrustado || btnCancelar == null || !btnCancelar.Visible)
            {
                btnAceptar.Left = Math.Max(12,
                    panelBotones.ClientSize.Width - btnAceptar.Width - 12);
                return;
            }

            btnCancelar.Left = Math.Max(12,
                panelBotones.ClientSize.Width - btnCancelar.Width - 12);
            btnAceptar.Left = Math.Max(12,
                btnCancelar.Left - btnAceptar.Width - 10);
        }

        private WinForms.Label CrearEtiqueta(string texto, int left, int top, int width)
        {
            return new WinForms.Label
            {
                Text = texto,
                Left = left,
                Top = top,
                Width = width,
                Height = 22
            };
        }

        private WinForms.ComboBox CrearComboTipo(int left, int top, int width)
        {
            WinForms.ComboBox combo = new WinForms.ComboBox
            {
                Left = left,
                Top = top,
                Width = width,
                Height = 24,
                DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
                IntegralHeight = false,
                MaxDropDownItems = 12,
                DropDownWidth = Math.Max(width, 340),
                DisplayMember = "Name",
                FormattingEnabled = true
            };

            // RebarBarType no muestra su nombre en ToString(). Sin este formato,
            // WinForms presenta Autodesk.Revit.DB.Structure.RebarBarType.
            // Se conserva el objeto RebarBarType como SelectedItem para no romper
            // el resto del código ni los handlers.
            combo.Format += (s, e) =>
            {
                RebarBarType tipo = e.ListItem as RebarBarType;
                if (tipo != null)
                    e.Value = tipo.Name;
            };

            return combo;
        }

        private WinForms.Button CrearBotonHerramienta(
            string texto,
            int left,
            int top,
            AceroVigaHerramientaEditor valor,
            int width = 245)
        {
            WinForms.Button boton = CrearBotonSimple(texto, left, top, width);
            boton.Tag = valor;
            botonesHerramienta.Add(boton);
            boton.Click += (s, e) =>
            {
                herramienta = valor;
                CancelarCroquis(false);
                ActualizarEstadoHerramienta();
                if (panelLienzo != null)
                {
                    panelLienzo.Focus();
                    panelLienzo.Invalidate();
                }
            };
            return boton;
        }

        private WinForms.Button CrearBotonSimple(string texto, int left, int top, int width)
        {
            WinForms.Button boton = new WinForms.Button
            {
                Text = texto,
                Left = left,
                Top = top,
                Width = width,
                Height = 28,
                FlatStyle = WinForms.FlatStyle.Flat,
                BackColor = Drawing.Color.White,
                ForeColor = Drawing.Color.FromArgb(45, 45, 45),
                Font = new Drawing.Font("Segoe UI", 8.4F),
                TextAlign = Drawing.ContentAlignment.MiddleCenter,
                UseVisualStyleBackColor = false
            };
            boton.FlatAppearance.BorderColor = Drawing.Color.FromArgb(170, 180, 190);
            boton.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(242, 247, 252);
            boton.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(225, 237, 248);
            return boton;
        }

        private void ActualizarMarcadoHerramientas()
        {
            for (int i = botonesHerramienta.Count - 1; i >= 0; i--)
            {
                WinForms.Button boton = botonesHerramienta[i];

                if (boton == null || boton.IsDisposed)
                {
                    botonesHerramienta.RemoveAt(i);
                    continue;
                }

                bool activo = boton.Tag is AceroVigaHerramientaEditor &&
                    (AceroVigaHerramientaEditor)boton.Tag == herramienta;

                boton.BackColor = activo
                    ? Drawing.Color.FromArgb(0, 120, 190)
                    : Drawing.Color.FromArgb(225, 229, 234);

                boton.ForeColor = activo
                    ? Drawing.Color.White
                    : Drawing.Color.FromArgb(35, 35, 35);

                boton.FlatAppearance.BorderColor = activo
                    ? Drawing.Color.FromArgb(0, 95, 155)
                    : Drawing.Color.FromArgb(170, 180, 190);
            }
        }

        private void CargarTipos(
            RebarBarType tipoLongitudinalInicial,
            RebarBarType tipoEstriboInicial)
        {
            cmbTipoLongitudinal.Items.Clear();
            cmbTipoEstribo.Items.Clear();

            foreach (RebarBarType tipo in tiposDisponibles)
            {
                cmbTipoLongitudinal.Items.Add(tipo);
                cmbTipoEstribo.Items.Add(tipo);
            }

            SeleccionarTipo(cmbTipoLongitudinal, tipoLongitudinalInicial);
            SeleccionarTipo(cmbTipoEstribo, tipoEstriboInicial);
        }

        private void SeleccionarTipo(WinForms.ComboBox combo, RebarBarType tipo)
        {
            if (combo == null || combo.Items.Count == 0)
                return;

            if (tipo != null)
            {
                for (int i = 0; i < combo.Items.Count; i++)
                {
                    RebarBarType candidato = combo.Items[i] as RebarBarType;
                    if (candidato != null && candidato.Id == tipo.Id)
                    {
                        combo.SelectedIndex = i;
                        return;
                    }
                }
            }

            combo.SelectedIndex = 0;
        }

        private static List<AceroVigaPuntoMm> NormalizarContorno(
            IEnumerable<AceroVigaPuntoMm> puntos)
        {
            List<AceroVigaPuntoMm> resultado = new List<AceroVigaPuntoMm>();

            if (puntos != null)
            {
                foreach (AceroVigaPuntoMm punto in puntos)
                {
                    if (punto == null ||
                        double.IsNaN(punto.Y) || double.IsInfinity(punto.Y) ||
                        double.IsNaN(punto.Z) || double.IsInfinity(punto.Z))
                    {
                        continue;
                    }

                    if (!resultado.Any(x =>
                        Math.Abs(x.Y - punto.Y) < 0.1 &&
                        Math.Abs(x.Z - punto.Z) < 0.1))
                    {
                        resultado.Add(punto.Copiar());
                    }
                }
            }

            if (resultado.Count < 3)
            {
                resultado.Clear();
                resultado.Add(new AceroVigaPuntoMm(-150.0, -300.0));
                resultado.Add(new AceroVigaPuntoMm(150.0, -300.0));
                resultado.Add(new AceroVigaPuntoMm(150.0, 300.0));
                resultado.Add(new AceroVigaPuntoMm(-150.0, 300.0));
            }

            if (AreaFirmada(resultado) < 0.0)
                resultado.Reverse();

            return resultado;
        }

        private void CalcularDimensionesReferencia()
        {
            if (contornoConcretoMm.Count == 0)
                return;

            disenoTrabajo.AnchoReferenciaMm =
                contornoConcretoMm.Max(x => x.Y) - contornoConcretoMm.Min(x => x.Y);
            disenoTrabajo.AltoReferenciaMm =
                contornoConcretoMm.Max(x => x.Z) - contornoConcretoMm.Min(x => x.Z);
        }

        private void ActualizarEstadoHerramienta()
        {
            string texto;

            switch (herramienta)
            {
                case AceroVigaHerramientaEditor.MoverDosPuntos:
                    texto = puntoBaseTransformacion == null
                        ? "MOVER 2 PUNTOS: seleccione el elemento y marque el punto base."
                        : "MOVER 2 PUNTOS: marque el punto destino.";
                    break;

                case AceroVigaHerramientaEditor.CopiarDosPuntos:
                    texto = puntoBaseTransformacion == null
                        ? "COPIAR 2 PUNTOS: seleccione el elemento y marque el punto base."
                        : "COPIAR 2 PUNTOS: marque el punto destino.";
                    break;

                case AceroVigaHerramientaEditor.AgregarLongitudinal:
                    texto = "AGREGAR BARRA: clic dentro del límite permitido.";
                    break;

                case AceroVigaHerramientaEditor.DistribuirLongitudinales:
                    texto = creandoDistribucionLongitudinalConArrastre
                        ? "DISTRIBUIR: mantenga el clic y arrastre hasta el extremo final."
                        : "DISTRIBUIR 2 PUNTOS: mantenga presionado el clic izquierdo, arrastre sobre la guía y suelte.";
                    break;

                case AceroVigaHerramientaEditor.EstriboPerimetral:
                    texto = "ADAPTAR CONTORNO: clic para crear el estribo con offset automático.";
                    break;

                case AceroVigaHerramientaEditor.EstriboRectangular:
                    texto = "RECTÁNGULO: mantenga presionado el clic izquierdo, arrastre y suelte para crear.";
                    break;

                case AceroVigaHerramientaEditor.EstriboRombo:
                    texto = "ROMBO: mantenga presionado el clic izquierdo desde el centro, arrastre y suelte para crear.";
                    break;

                case AceroVigaHerramientaEditor.EstriboLibreCerrado:
                    texto = puntosCroquisActual.Count == 0
                        ? "CROQUIS LIBRE: primer clic para iniciar; mueva el cursor y dé clic para fijar cada vértice."
                        : "CROQUIS LIBRE: mueva el cursor y dé clic para fijar el siguiente vértice. Enter o doble clic cierra.";
                    break;

                case AceroVigaHerramientaEditor.TrabaAbierta:
                    texto = "CROQUIS ABIERTO: marque puntos; Enter o doble clic para terminar.";
                    break;

                case AceroVigaHerramientaEditor.HorizontalAlmaDosPuntos:
                    texto = primerPuntoHerramienta == null
                        ? "ALMA 2 PUNTOS: marque el primer extremo."
                        : "ALMA 2 PUNTOS: marque el segundo extremo.";
                    break;

                case AceroVigaHerramientaEditor.GanchoC:
                    texto = primerPuntoHerramienta == null
                        ? "GANCHO C: seleccione el centro de la primera barra longitudinal."
                        : "GANCHO C: seleccione una segunda barra. El cuerpo será recto y ambos ganchos quedarán al mismo lado.";
                    break;

                case AceroVigaHerramientaEditor.GanchoS:
                    texto = primerPuntoHerramienta == null
                        ? "GANCHO S: seleccione el centro de la primera barra longitudinal."
                        : "GANCHO S: seleccione una segunda barra. El cuerpo inclinado y los ganchos opuestos se previsualizan antes del clic.";
                    break;

                case AceroVigaHerramientaEditor.CambiarGancho:
                    texto = "CAMBIAR GANCHO: clic en una esquina de un estribo cerrado.";
                    break;

                case AceroVigaHerramientaEditor.Eliminar:
                    texto = modoEditorActual == AceroVigaModoEditorInicial.Estribos
                        ? "ELIMINAR: clic sobre un recorrido de estribo."
                        : "ELIMINAR: clic sobre una barra longitudinal.";
                    break;

                default:
                    texto = modoEditorActual == AceroVigaModoEditorInicial.Estribos
                        ? "SELECCIONAR: arrastre vértices. Supr elimina el recorrido."
                        : "SELECCIONAR: arrastre la barra. Supr la elimina.";
                    break;
            }

            if (lblEstado != null)
                lblEstado.Text = texto;

            ActualizarMarcadoHerramientas();
        }


        private void ActualizarResumen()
        {
            int nLong = disenoTrabajo.Longitudinales != null
                ? disenoTrabajo.Longitudinales.Count
                : 0;
            int nEstr = disenoTrabajo.Estribos != null
                ? disenoTrabajo.Estribos.Count
                : 0;

            if (modoEditorActual == AceroVigaModoEditorInicial.Estribos)
            {
                lblResumen.Text =
                    "Estribos configurados: " +
                    nEstr.ToString(CultureInfo.InvariantCulture) +
                    "\nLongitudinales visibles: " +
                    nLong.ToString(CultureInfo.InvariantCulture) +
                    " (solo referencia)";
            }
            else
            {
                lblResumen.Text =
                    "Longitudinales configurados: " +
                    nLong.ToString(CultureInfo.InvariantCulture) +
                    "\nEstribos visibles: " +
                    nEstr.ToString(CultureInfo.InvariantCulture) +
                    " (solo referencia)";
            }

            PublicarCambiosIncrustados();
        }

        private void PublicarCambiosIncrustados()
        {
            if (!modoIncrustado || disenoTrabajo == null)
                return;

            EstablecerRecubrimientoActivo(ObtenerRecubrimientoActivo());
            CalcularDimensionesReferencia();
            ActualizarCoordenadasSeccionRealLongitudinales();
            DisenoResultado = disenoTrabajo.Copiar();
            AceroVigaDisenoSeccionCompartido.Establecer(DisenoResultado);

            Action<AceroVigaDisenoSeccion> handler = DisenoAplicado;
            if (handler != null)
                handler(DisenoResultado.Copiar());
        }

        private void RegistrarHistorial()
        {
            historial.Push(disenoTrabajo.Copiar());

            while (historial.Count > 50)
            {
                AceroVigaDisenoSeccion[] datos = historial.Reverse().Take(50).ToArray();
                historial.Clear();
                foreach (AceroVigaDisenoSeccion dato in datos.Reverse())
                    historial.Push(dato);
            }
        }

        private void Deshacer()
        {
            if (historial.Count == 0)
                return;

            disenoTrabajo = historial.Pop();
            idSeleccionado = string.Empty;
            idsEstribosSeleccionados.Clear();
            idsGruposLongitudinalesSeleccionados.Clear();
            idsBarrasLongitudinalesSeleccionadas.Clear();
            indiceVerticeSeleccionado = -1;
            CancelarCroquis(false);
            RefrescarComboGuiasCapas();
            ActualizarResumen();
            NotificarEstadoSeleccionTipoCambiado();
            panelLienzo.Invalidate();
        }

        private void LimpiarDiseno()
        {
            RegistrarHistorial();

            if (modoEditorActual == AceroVigaModoEditorInicial.Estribos)
                disenoTrabajo.Estribos.Clear();
            else
            {
                disenoTrabajo.Longitudinales.Clear();
                if (disenoTrabajo.GruposLongitudinales != null)
                    disenoTrabajo.GruposLongitudinales.Clear();
                disenoTrabajo.GuiasCapasLongitudinales.Clear();
                guiaCapaActivaId = string.Empty;
                RefrescarComboGuiasCapas();
            }

            idSeleccionado = string.Empty;
            idsEstribosSeleccionados.Clear();
            idsGruposLongitudinalesSeleccionados.Clear();
            idsBarrasLongitudinalesSeleccionadas.Clear();
            indiceVerticeSeleccionado = -1;
            CancelarCroquis(false);
            ActualizarResumen();
            NotificarEstadoSeleccionTipoCambiado();
            panelLienzo.Invalidate();
        }

        private void CancelarCroquis(bool refrescar = true)
        {
            puntosCroquisActual.Clear();
            puntosCroquisArrastre.Clear();
            seleccionandoRegionEstribos = false;
            seleccionandoRegionLongitudinal = false;
            creandoEstriboConArrastre = false;
            puntoInicioArrastre = null;
            puntoActualArrastre = null;
            if (panelLienzo != null)
                panelLienzo.Capture = false;
            primerPuntoDistribucion = null;
            creandoDistribucionLongitudinalConArrastre = false;
            puntoInicioDistribucionArrastre = null;
            puntoFinDistribucionArrastre = null;
            parametroInicioDistribucionArrastre = -1.0;
            parametroFinDistribucionArrastre = -1.0;
            primerPuntoHerramienta = null;
            puntoBaseTransformacion = null;
            puntoSnapActual = null;
            textoSnapActual = string.Empty;
            trazoPausado = false;
            ActualizarBotonPausaTrazo();

            if (refrescar)
            {
                ActualizarEstadoHerramienta();
                panelLienzo.Invalidate();
            }
        }

        protected override bool ProcessCmdKey(
            ref WinForms.Message msg,
            WinForms.Keys keyData)
        {
            if (keyData == WinForms.Keys.F3)
            {
                osnapActivo = !osnapActivo;

                if (barraOsnapIntegrada != null &&
                    !barraOsnapIntegrada.IsDisposed)
                {
                    barraOsnapIntegrada.EstablecerEstado(
                        osnapActivo,
                        osnapExtremo,
                        osnapMedio,
                        osnapCentro,
                        osnapInterseccion,
                        osnapPerpendicular,
                        osnapCercano);
                }

                if (panelLienzo != null)
                    panelLienzo.Invalidate();

                return true;
            }

            if (keyData == WinForms.Keys.Enter)
            {
                if (herramienta ==
                        AceroVigaHerramientaEditor.EstriboLibreCerrado ||
                    herramienta ==
                        AceroVigaHerramientaEditor.TrabaAbierta)
                {
                    FinalizarCroquis();
                    return true;
                }
            }

            if (keyData == WinForms.Keys.Escape)
            {
                CancelarCroquis();
                return true;
            }

            if (keyData == WinForms.Keys.Delete)
            {
                EliminarSeleccionado();
                return true;
            }

            if (keyData ==
                (WinForms.Keys.Control | WinForms.Keys.Z))
            {
                Deshacer();
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void AceptarDiseno()
        {
            if (puntosCroquisActual.Count > 0)
                FinalizarCroquis();

            EstablecerRecubrimientoActivo(ObtenerRecubrimientoActivo());
            CalcularDimensionesReferencia();
            DisenoResultado = disenoTrabajo.Copiar();

            if (modoIncrustado)
            {
                if (lblEstado != null)
                    lblEstado.Text = "Diseño aplicado. Puede continuar editándolo en esta misma ventana.";

                // ActualizarResumen publica el diseño compartido y avisa al MAIN.
                ActualizarResumen();
                if (panelLienzo != null)
                    panelLienzo.Invalidate();
                return;
            }

            DialogResult = WinForms.DialogResult.OK;
            Close();
        }

        private RebarBarType TipoLongitudinalActual
        {
            get
            {
                if (modoIntegradoSinDuplicados &&
                    obtenerTipoLongitudinalExterno != null)
                {
                    try
                    {
                        RebarBarType tipo = obtenerTipoLongitudinalExterno();
                        if (tipo != null)
                            return tipo;
                    }
                    catch
                    {
                    }
                }

                return cmbTipoLongitudinal != null
                    ? cmbTipoLongitudinal.SelectedItem as RebarBarType
                    : null;
            }
        }

        private RebarBarType TipoEstriboActual
        {
            get
            {
                if (modoIntegradoSinDuplicados &&
                    obtenerTipoEstriboExterno != null)
                {
                    try
                    {
                        RebarBarType tipo = obtenerTipoEstriboExterno();
                        if (tipo != null)
                            return tipo;
                    }
                    catch
                    {
                    }
                }

                return cmbTipoEstribo != null
                    ? cmbTipoEstribo.SelectedItem as RebarBarType
                    : null;
            }
        }

        private double ObtenerDiametroMm(RebarBarType tipo)
        {
            if (tipo == null)
                return 0.0;

            double valorInterno = 0.0;

            // Revit 2027 usa los parámetros de diámetro del tipo de barra.
            // Para el dibujo y el offset se prioriza el diámetro de modelo.
            try
            {
                valorInterno = tipo.BarModelDiameter;
            }
            catch
            {
                valorInterno = 0.0;
            }

            if (valorInterno <= 0.0)
            {
                try
                {
                    valorInterno = tipo.BarNominalDiameter;
                }
                catch
                {
                    valorInterno = 0.0;
                }
            }

            // Respaldo por parámetros para tipos importados o plantillas antiguas.
            if (valorInterno <= 0.0)
            {
                string[] nombres = new string[]
                {
                    "Diámetro de barra de modelo",
                    "Diametro de barra de modelo",
                    "Model Bar Diameter",
                    "Diámetro de barra",
                    "Diametro de barra",
                    "Bar Diameter",
                    "Nominal Diameter",
                    "Diámetro nominal"
                };

                foreach (string nombre in nombres)
                {
                    try
                    {
                        Parameter parametro = tipo.LookupParameter(nombre);

                        if (parametro != null &&
                            parametro.StorageType == StorageType.Double &&
                            parametro.AsDouble() > 0.0)
                        {
                            valorInterno = parametro.AsDouble();
                            break;
                        }
                    }
                    catch
                    {
                    }
                }
            }

            if (valorInterno <= 0.0)
                return 0.0;

            try
            {
                return UnitUtils.ConvertFromInternalUnits(
                    valorInterno,
                    UnitTypeId.Millimeters);
            }
            catch
            {
                return valorInterno * 304.8;
            }
        }

        private List<AceroVigaPuntoMm> ObtenerContornoEjeEstriboMm(RebarBarType tipo)
        {
            double coverMm = ObtenerRecubrimientoActivo() * 10.0;
            double diametro = ObtenerDiametroMm(tipo);
            double offset = coverMm + diametro * 0.5;
            return DesfasarPoligonoInterior(contornoConcretoMm, offset);
        }

        private List<AceroVigaPuntoMm> ObtenerContornoCentrosLongitudinalMm(RebarBarType tipo)
        {
            double coverMm = ObtenerRecubrimientoActivo() * 10.0;
            double diametroEstribo = ObtenerDiametroMm(TipoEstriboActual);
            double diametroLong = ObtenerDiametroMm(tipo);
            double offset = coverMm + diametroEstribo + diametroLong * 0.5;
            return DesfasarPoligonoInterior(contornoConcretoMm, offset);
        }

        private bool EsHerramientaRectanguloRomboConArrastre()
        {
            return herramienta == AceroVigaHerramientaEditor.EstriboRectangular ||
                   herramienta == AceroVigaHerramientaEditor.EstriboRombo;
        }

        private bool EsHerramientaCroquisLibrePorClics()
        {
            return herramienta ==
                AceroVigaHerramientaEditor.EstriboLibreCerrado;
        }

        private void IniciarCreacionEstriboConArrastre(
            AceroVigaPuntoMm punto,
            Drawing.Point posicionPantalla)
        {
            if (punto == null || TipoEstriboActual == null)
                return;

            creandoEstriboConArrastre = true;
            herramientaArrastre = herramienta;
            puntoPantallaInicioArrastre = posicionPantalla;
            puntosCroquisArrastre.Clear();

            if (herramientaArrastre ==
                AceroVigaHerramientaEditor.EstriboLibreCerrado)
            {
                if (puntosCroquisActual.Count == 0)
                    puntosCroquisActual.Add(punto.Copiar());

                puntoInicioArrastre =
                    puntosCroquisActual[puntosCroquisActual.Count - 1].Copiar();
                puntoActualArrastre = puntoInicioArrastre.Copiar();
            }
            else
            {
                puntoInicioArrastre = punto.Copiar();
                puntoActualArrastre = punto.Copiar();
            }

            puntosCroquisArrastre.Add(puntoInicioArrastre.Copiar());

            if (lblEstado != null)
            {
                if (herramientaArrastre ==
                    AceroVigaHerramientaEditor.EstriboRectangular)
                {
                    lblEstado.Text =
                        "RECTÁNGULO: mantenga el clic, arrastre para ver el preview y suelte para crear.";
                }
                else if (herramientaArrastre ==
                    AceroVigaHerramientaEditor.EstriboRombo)
                {
                    lblEstado.Text =
                        "ROMBO: mantenga el clic, arrastre para ver el preview y suelte para crear.";
                }
                else
                {
                    lblEstado.Text =
                        "CROQUIS LIBRE: mueva el cursor y dé clic para fijar el siguiente vértice.";
                }
            }

            if (panelLienzo != null)
            {
                panelLienzo.Capture =
                    herramientaArrastre !=
                    AceroVigaHerramientaEditor.EstriboLibreCerrado;
                panelLienzo.Invalidate();
            }
        }

        private void ActualizarCreacionEstriboConArrastre(
            AceroVigaPuntoMm punto,
            Drawing.Point posicionPantalla)
        {
            if (!creandoEstriboConArrastre || punto == null)
                return;

            // El cursor actualiza únicamente el preview. En rectángulo/rombo la
            // geometría se confirma al soltar; en croquis libre, con otro clic.
            puntoActualArrastre = punto.Copiar();

            if (panelLienzo != null)
                panelLienzo.Invalidate();
        }

        private void LimpiarEstadoArrastreEstribo()
        {
            creandoEstriboConArrastre = false;
            herramientaArrastre = AceroVigaHerramientaEditor.SeleccionarMover;
            puntoInicioArrastre = null;
            puntoActualArrastre = null;
            puntosCroquisArrastre.Clear();

            if (panelLienzo != null)
                panelLienzo.Capture = false;
        }

        private void ProcesarCreacionEstriboPorDosClics(
            AceroVigaPuntoMm punto,
            Drawing.Point posicionPantalla)
        {
            if (punto == null || TipoEstriboActual == null)
                return;

            if (!creandoEstriboConArrastre || herramientaArrastre != herramienta)
            {
                LimpiarEstadoArrastreEstribo();
                IniciarCreacionEstriboConArrastre(punto, posicionPantalla);
                return;
            }

            FinalizarCreacionEstriboConArrastre(punto);
        }

        private void FinalizarCreacionEstriboConArrastre(
            AceroVigaPuntoMm puntoFinal)
        {
            if (!creandoEstriboConArrastre)
                return;

            if (puntoFinal != null)
                puntoActualArrastre = puntoFinal.Copiar();

            AceroVigaHerramientaEditor tipoHerramienta = herramientaArrastre;

            if (tipoHerramienta ==
                AceroVigaHerramientaEditor.EstriboLibreCerrado)
            {
                AceroVigaPuntoMm fin = puntoActualArrastre != null
                    ? puntoActualArrastre.Copiar()
                    : null;

                if (fin == null || puntosCroquisActual.Count == 0)
                    return;

                AceroVigaPuntoMm primero = puntosCroquisActual[0];
                AceroVigaPuntoMm ultimo =
                    puntosCroquisActual[puntosCroquisActual.Count - 1];

                double toleranciaTramo = ObtenerToleranciaModelo(4.0F);
                bool cerrarSobrePrimero =
                    puntosCroquisActual.Count >= 3 &&
                    Distancia(fin, primero) <=
                        ObtenerToleranciaModelo(ToleranciaVerticePrioritarioPx);

                if (cerrarSobrePrimero)
                {
                    LimpiarEstadoArrastreEstribo();
                    FinalizarCroquis();
                    return;
                }

                if (Distancia(fin, ultimo) <= toleranciaTramo)
                {
                    if (lblEstado != null)
                        lblEstado.Text =
                            "CROQUIS LIBRE: el punto es demasiado cercano al vértice anterior.";
                    if (panelLienzo != null)
                        panelLienzo.Invalidate();
                    return;
                }

                puntosCroquisActual.Add(fin.Copiar());

                // El vértice confirmado se convierte inmediatamente en el origen
                // del siguiente tramo. No se requiere mantener presionado el mouse
                // ni hacer un clic adicional para iniciar el preview siguiente.
                puntoInicioArrastre = fin.Copiar();
                puntoActualArrastre = fin.Copiar();
                puntosCroquisArrastre.Clear();
                puntosCroquisArrastre.Add(fin.Copiar());

                if (lblEstado != null)
                {
                    lblEstado.Text =
                        "CROQUIS LIBRE: vértice fijado. Mueva el cursor y dé clic para el siguiente; " +
                        "clic sobre el primero, ENTER o doble clic para cerrar.";
                }

                if (panelLienzo != null)
                    panelLienzo.Invalidate();
                return;
            }

            List<AceroVigaPuntoMm> puntos = ConstruirPreviewEstriboArrastre();
            LimpiarEstadoArrastreEstribo();

            if (puntos == null || puntos.Count < 3)
            {
                if (lblEstado != null)
                    lblEstado.Text =
                        "La geometría es demasiado pequeña. Marque nuevamente el primer punto.";
                if (panelLienzo != null)
                    panelLienzo.Invalidate();
                return;
            }

            AceroVigaTipoEstribo2D tipoDiseno =
                tipoHerramienta == AceroVigaHerramientaEditor.EstriboRectangular
                    ? AceroVigaTipoEstribo2D.Rectangular
                    : AceroVigaTipoEstribo2D.Rombo;

            CrearEstriboDesdePuntos(puntos, true, tipoDiseno);
            ActualizarEstadoHerramienta();
        }

        private List<AceroVigaPuntoMm> ConstruirPreviewEstriboArrastre()
        {
            List<AceroVigaPuntoMm> puntos = new List<AceroVigaPuntoMm>();

            if (!creandoEstriboConArrastre ||
                puntoInicioArrastre == null ||
                puntoActualArrastre == null)
            {
                return puntos;
            }

            if (herramientaArrastre ==
                AceroVigaHerramientaEditor.EstriboLibreCerrado)
            {
                foreach (AceroVigaPuntoMm p in puntosCroquisActual)
                {
                    if (p != null)
                        puntos.Add(p.Copiar());
                }

                if (puntos.Count == 0)
                    puntos.Add(puntoInicioArrastre.Copiar());

                if (Distancia(
                    puntos[puntos.Count - 1],
                    puntoActualArrastre) > Tol)
                {
                    puntos.Add(puntoActualArrastre.Copiar());
                }

                return puntos;
            }

            AceroVigaPuntoMm primero = puntoInicioArrastre;
            AceroVigaPuntoMm segundo = puntoActualArrastre;
            double minY = Math.Min(primero.Y, segundo.Y);
            double maxY = Math.Max(primero.Y, segundo.Y);
            double minZ = Math.Min(primero.Z, segundo.Z);
            double maxZ = Math.Max(primero.Z, segundo.Z);

            if (maxY - minY <= Tol || maxZ - minZ <= Tol)
                return puntos;

            if (herramientaArrastre ==
                AceroVigaHerramientaEditor.EstriboRectangular)
            {
                puntos.Add(new AceroVigaPuntoMm(minY, minZ));
                puntos.Add(new AceroVigaPuntoMm(maxY, minZ));
                puntos.Add(new AceroVigaPuntoMm(maxY, maxZ));
                puntos.Add(new AceroVigaPuntoMm(minY, maxZ));
                return AjustarRectanguloRomboALongitudinalesYRecubrimiento(
                    puntos,
                    AceroVigaTipoEstribo2D.Rectangular);
            }

            double radioY = Math.Abs(segundo.Y - primero.Y);
            double radioZ = Math.Abs(segundo.Z - primero.Z);
            if (radioY <= Tol || radioZ <= Tol)
                return puntos;

            puntos.Add(new AceroVigaPuntoMm(primero.Y, primero.Z + radioZ));
            puntos.Add(new AceroVigaPuntoMm(primero.Y + radioY, primero.Z));
            puntos.Add(new AceroVigaPuntoMm(primero.Y, primero.Z - radioZ));
            puntos.Add(new AceroVigaPuntoMm(primero.Y - radioY, primero.Z));
            return AjustarRectanguloRomboALongitudinalesYRecubrimiento(
                puntos,
                AceroVigaTipoEstribo2D.Rombo);
        }

        private List<ReferenciaLongitudinalMm>
            ObtenerReferenciasLongitudinalesRealesMm()
        {
            List<ReferenciaLongitudinalMm> resultado =
                new List<ReferenciaLongitudinalMm>();

            if (disenoTrabajo == null ||
                disenoTrabajo.Longitudinales == null)
            {
                return resultado;
            }

            double recubrimientoLongitudinalCm =
                disenoTrabajo.RecubrimientoLongitudinalCm > 0.0
                    ? disenoTrabajo.RecubrimientoLongitudinalCm
                    : disenoTrabajo.RecubrimientoCm;
            double recubrimientoLongitudinalMm =
                Math.Max(0.0, recubrimientoLongitudinalCm) * 10.0;
            double diametroEstriboMm = Math.Max(
                ObtenerDiametroMm(TipoEstriboActual),
                1.0);

            foreach (AceroVigaBarraLongitudinal2D barra in
                disenoTrabajo.Longitudinales)
            {
                if (barra == null || barra.Punto == null ||
                    barra.OcultaPorSuperposicion)
                    continue;

                RebarBarType tipoLongitudinal =
                    barra.TipoBarra ?? TipoLongitudinalActual;
                double diametroLongitudinalMm = barra.DiametroMm > Tol
                    ? barra.DiametroMm
                    : ObtenerDiametroMm(tipoLongitudinal);
                double offsetCentroLongitudinalMm =
                    recubrimientoLongitudinalMm +
                    diametroEstriboMm +
                    Math.Max(diametroLongitudinalMm, 1.0) * 0.5;
                List<AceroVigaPuntoMm> contornoLongitudinal =
                    DesfasarPoligonoInterior(
                        contornoConcretoMm,
                        offsetCentroLongitudinalMm);

                if (contornoLongitudinal == null ||
                    contornoLongitudinal.Count < 3)
                {
                    continue;
                }

                resultado.Add(new ReferenciaLongitudinalMm
                {
                    Centro = DesnormalizarEnCaja(
                        barra.Punto,
                        contornoLongitudinal),
                    DiametroMm = Math.Max(diametroLongitudinalMm, 1.0)
                });
            }

            return resultado;
        }

        private List<AceroVigaPuntoMm>
            AjustarRectanguloRomboALongitudinalesYRecubrimiento(
                List<AceroVigaPuntoMm> puntos,
                AceroVigaTipoEstribo2D tipoDiseno)
        {
            if (puntos == null || puntos.Count < 4 ||
                (tipoDiseno != AceroVigaTipoEstribo2D.Rectangular &&
                 tipoDiseno != AceroVigaTipoEstribo2D.Rombo))
            {
                return puntos;
            }

            RebarBarType tipoEstribo = TipoEstriboActual;
            List<AceroVigaPuntoMm> limiteRecubrimiento =
                ObtenerContornoEjeEstriboMm(tipoEstribo);
            List<ReferenciaLongitudinalMm> longitudinales =
                ObtenerReferenciasLongitudinalesRealesMm();

            if (tipoEstribo == null ||
                limiteRecubrimiento == null ||
                limiteRecubrimiento.Count < 3 ||
                longitudinales.Count == 0)
            {
                return puntos;
            }

            double diametroEstribo = Math.Max(
                ObtenerDiametroMm(tipoEstribo),
                1.0);
            double proximidad = Math.Max(
                30.0,
                ObtenerToleranciaModelo(22.0F));

            List<ReferenciaLongitudinalMm> cercanas =
                new List<ReferenciaLongitudinalMm>();

            foreach (ReferenciaLongitudinalMm referencia in longitudinales)
            {
                if (referencia == null || referencia.Centro == null)
                    continue;

                double holgura =
                    (Math.Max(referencia.DiametroMm, 1.0) +
                     diametroEstribo) * 0.5 + 1.0;
                double distancia = DistanciaPuntoAPoligonoEditor(
                    referencia.Centro,
                    puntos);

                if (PuntoDentroPoligono(referencia.Centro, puntos) ||
                    distancia <= holgura + proximidad)
                {
                    cercanas.Add(referencia);
                }
            }

            if (cercanas.Count == 0)
                return puntos;

            if (tipoDiseno == AceroVigaTipoEstribo2D.Rectangular)
            {
                return AjustarRectanguloALongitudinales(
                    puntos,
                    cercanas,
                    limiteRecubrimiento,
                    diametroEstribo);
            }

            return AjustarRomboALongitudinales(
                puntos,
                cercanas,
                limiteRecubrimiento,
                diametroEstribo);
        }

        private List<AceroVigaPuntoMm> AjustarRectanguloALongitudinales(
            List<AceroVigaPuntoMm> puntos,
            List<ReferenciaLongitudinalMm> longitudinales,
            List<AceroVigaPuntoMm> limiteRecubrimiento,
            double diametroEstribo)
        {
            double minY = puntos.Min(x => x.Y);
            double maxY = puntos.Max(x => x.Y);
            double minZ = puntos.Min(x => x.Z);
            double maxZ = puntos.Max(x => x.Z);

            foreach (ReferenciaLongitudinalMm referencia in longitudinales)
            {
                double holgura =
                    (Math.Max(referencia.DiametroMm, 1.0) +
                     diametroEstribo) * 0.5 + 1.0;

                minY = Math.Min(minY, referencia.Centro.Y - holgura);
                maxY = Math.Max(maxY, referencia.Centro.Y + holgura);
                minZ = Math.Min(minZ, referencia.Centro.Z - holgura);
                maxZ = Math.Max(maxZ, referencia.Centro.Z + holgura);
            }

            double limiteMinY = limiteRecubrimiento.Min(x => x.Y);
            double limiteMaxY = limiteRecubrimiento.Max(x => x.Y);
            double limiteMinZ = limiteRecubrimiento.Min(x => x.Z);
            double limiteMaxZ = limiteRecubrimiento.Max(x => x.Z);
            double toleranciaPegado = Math.Max(
                12.0,
                longitudinales.Max(x =>
                    (Math.Max(x.DiametroMm, 1.0) + diametroEstribo) * 0.5) +
                2.0);

            minY = AjustarLadoAlLimite(
                minY, limiteMinY, limiteMaxY, toleranciaPegado, true);
            maxY = AjustarLadoAlLimite(
                maxY, limiteMinY, limiteMaxY, toleranciaPegado, false);
            minZ = AjustarLadoAlLimite(
                minZ, limiteMinZ, limiteMaxZ, toleranciaPegado, true);
            maxZ = AjustarLadoAlLimite(
                maxZ, limiteMinZ, limiteMaxZ, toleranciaPegado, false);

            if (maxY - minY <= Tol || maxZ - minZ <= Tol)
                return puntos;

            return new List<AceroVigaPuntoMm>
            {
                new AceroVigaPuntoMm(minY, minZ),
                new AceroVigaPuntoMm(maxY, minZ),
                new AceroVigaPuntoMm(maxY, maxZ),
                new AceroVigaPuntoMm(minY, maxZ)
            };
        }

        private List<AceroVigaPuntoMm> AjustarRomboALongitudinales(
            List<AceroVigaPuntoMm> puntos,
            List<ReferenciaLongitudinalMm> longitudinales,
            List<AceroVigaPuntoMm> limiteRecubrimiento,
            double diametroEstribo)
        {
            double centroY = (puntos.Min(x => x.Y) + puntos.Max(x => x.Y)) * 0.5;
            double centroZ = (puntos.Min(x => x.Z) + puntos.Max(x => x.Z)) * 0.5;
            double radioY = (puntos.Max(x => x.Y) - puntos.Min(x => x.Y)) * 0.5;
            double radioZ = (puntos.Max(x => x.Z) - puntos.Min(x => x.Z)) * 0.5;

            double limiteMinY = limiteRecubrimiento.Min(x => x.Y);
            double limiteMaxY = limiteRecubrimiento.Max(x => x.Y);
            double limiteMinZ = limiteRecubrimiento.Min(x => x.Z);
            double limiteMaxZ = limiteRecubrimiento.Max(x => x.Z);

            centroY = Math.Max(limiteMinY, Math.Min(limiteMaxY, centroY));
            centroZ = Math.Max(limiteMinZ, Math.Min(limiteMaxZ, centroZ));

            double radioMaxY = Math.Max(
                Tol,
                Math.Min(centroY - limiteMinY, limiteMaxY - centroY));
            double radioMaxZ = Math.Max(
                Tol,
                Math.Min(centroZ - limiteMinZ, limiteMaxZ - centroZ));

            radioY = Math.Min(Math.Max(radioY, 1.0), radioMaxY);
            radioZ = Math.Min(Math.Max(radioZ, 1.0), radioMaxZ);

            ExpandirRomboHastaLiberarLongitudinales(
                centroY, centroZ,
                ref radioY, ref radioZ,
                radioMaxY, radioMaxZ,
                longitudinales, diametroEstribo);

            double toleranciaPegado = Math.Max(
                12.0,
                longitudinales.Max(x =>
                    (Math.Max(x.DiametroMm, 1.0) + diametroEstribo) * 0.5) +
                2.0);

            if (radioMaxY - radioY <= toleranciaPegado)
                radioY = radioMaxY;
            if (radioMaxZ - radioZ <= toleranciaPegado)
                radioZ = radioMaxZ;

            return new List<AceroVigaPuntoMm>
            {
                new AceroVigaPuntoMm(centroY, centroZ + radioZ),
                new AceroVigaPuntoMm(centroY + radioY, centroZ),
                new AceroVigaPuntoMm(centroY, centroZ - radioZ),
                new AceroVigaPuntoMm(centroY - radioY, centroZ)
            };
        }

        private void ExpandirRomboHastaLiberarLongitudinales(
            double centroY,
            double centroZ,
            ref double radioY,
            ref double radioZ,
            double radioMaxY,
            double radioMaxZ,
            List<ReferenciaLongitudinalMm> longitudinales,
            double diametroEstribo)
        {
            for (int iteracion = 0; iteracion < 80; iteracion++)
            {
                double factorNecesario = 1.0;

                foreach (ReferenciaLongitudinalMm referencia in longitudinales)
                {
                    double holgura =
                        (Math.Max(referencia.DiametroMm, 1.0) +
                         diametroEstribo) * 0.5 + 1.0;
                    double dy = Math.Abs(referencia.Centro.Y - centroY);
                    double dz = Math.Abs(referencia.Centro.Z - centroZ);
                    double valor = dy / Math.Max(radioY, Tol) +
                                   dz / Math.Max(radioZ, Tol);
                    double normal = Math.Sqrt(
                        1.0 / Math.Max(radioY * radioY, Tol) +
                        1.0 / Math.Max(radioZ * radioZ, Tol));
                    double requerido = valor + holgura * normal;

                    factorNecesario = Math.Max(
                        factorNecesario,
                        requerido * 1.005);
                }

                if (factorNecesario <= 1.0001)
                    break;

                double nuevoRadioY = Math.Min(
                    radioMaxY,
                    radioY * factorNecesario);
                double nuevoRadioZ = Math.Min(
                    radioMaxZ,
                    radioZ * factorNecesario);

                if (nuevoRadioY <= radioY + Tol &&
                    nuevoRadioZ <= radioZ + Tol)
                {
                    break;
                }

                radioY = nuevoRadioY;
                radioZ = nuevoRadioZ;
            }
        }

        private static double AjustarLadoAlLimite(
            double valor,
            double minimo,
            double maximo,
            double toleranciaPegado,
            bool esMinimo)
        {
            valor = Math.Max(minimo, Math.Min(maximo, valor));

            if (esMinimo && valor - minimo <= toleranciaPegado)
                return minimo;
            if (!esMinimo && maximo - valor <= toleranciaPegado)
                return maximo;

            return valor;
        }

        private static double DistanciaPuntoAPoligonoEditor(
            AceroVigaPuntoMm punto,
            List<AceroVigaPuntoMm> poligono)
        {
            if (punto == null || poligono == null || poligono.Count < 2)
                return double.MaxValue;

            double menor = double.MaxValue;
            for (int i = 0; i < poligono.Count; i++)
            {
                AceroVigaPuntoMm a = poligono[i];
                AceroVigaPuntoMm b = poligono[(i + 1) % poligono.Count];
                menor = Math.Min(
                    menor,
                    DistanciaPuntoSegmento(punto, a, b));
            }
            return menor;
        }

        private void OnLienzoMouseWheel(WinForms.MouseEventArgs e)
        {
            if (e == null || panelLienzo == null || e.Delta == 0)
                return;

            // El punto de modelo situado bajo el cursor debe permanecer en la
            // misma posición de pantalla después de modificar el zoom.
            AceroVigaPuntoMm puntoBajoCursor =
                ConvertirPantallaAModelo(e.Location);

            double factor = e.Delta > 0
                ? 1.18
                : 1.0 / 1.18;

            double nuevoZoom = Math.Max(
                0.25,
                Math.Min(20.0, zoomVista * factor));

            if (Math.Abs(nuevoZoom - zoomVista) <= Tol)
                return;

            zoomVista = nuevoZoom;
            CalcularTransformacion(panelLienzo.ClientRectangle);

            if (puntoBajoCursor != null)
            {
                Drawing.PointF nuevaPosicion =
                    ConvertirModeloAPantalla(puntoBajoCursor);

                panVistaX += e.Location.X - nuevaPosicion.X;
                panVistaY += e.Location.Y - nuevaPosicion.Y;

                CalcularTransformacion(panelLienzo.ClientRectangle);
            }

            if (lblEstado != null)
            {
                lblEstado.Text =
                    "Zoom: " +
                    Math.Round(zoomVista * 100.0).ToString("0") +
                    "%  |  Rueda: acercar/alejar  |  Botón central: desplazar";
            }

            panelLienzo.Invalidate();
        }

        private void IniciarPaneoVista(Drawing.Point ubicacion)
        {
            if (panelLienzo == null)
                return;

            paneandoVista = true;
            ultimoPuntoPaneo = ubicacion;
            panelLienzo.Capture = true;
            panelLienzo.Cursor = WinForms.Cursors.Hand;
        }

        private void ActualizarPaneoVista(Drawing.Point ubicacion)
        {
            if (!paneandoVista || panelLienzo == null)
                return;

            panVistaX += ubicacion.X - ultimoPuntoPaneo.X;
            panVistaY += ubicacion.Y - ultimoPuntoPaneo.Y;
            ultimoPuntoPaneo = ubicacion;

            CalcularTransformacion(panelLienzo.ClientRectangle);
            panelLienzo.Invalidate();
        }

        private void FinalizarPaneoVista()
        {
            paneandoVista = false;

            if (panelLienzo == null)
                return;

            panelLienzo.Capture = false;
            panelLienzo.Cursor = WinForms.Cursors.Cross;
        }

        private void RestablecerNavegacionVista()
        {
            zoomVista = 1.0;
            panVistaX = 0.0;
            panVistaY = 0.0;
            paneandoVista = false;

            if (panelLienzo != null)
            {
                panelLienzo.Capture = false;
                panelLienzo.Cursor = WinForms.Cursors.Cross;
                CalcularTransformacion(panelLienzo.ClientRectangle);
                panelLienzo.Invalidate();
            }

            if (lblEstado != null)
            {
                lblEstado.Text =
                    "Vista ajustada. Rueda: zoom | botón central: desplazar.";
            }
        }

        private void OnLienzoMouseDown(WinForms.MouseEventArgs e)
        {
            if (panelLienzo != null)
                panelLienzo.Focus();

            if (e.Button == WinForms.MouseButtons.Middle)
            {
                IniciarPaneoVista(e.Location);
                return;
            }

            AceroVigaPuntoMm punto =
                AplicarSnap(ConvertirPantallaAModelo(e.Location));

            if (punto == null)
                return;

            if (e.Button == WinForms.MouseButtons.Right)
            {
                CancelarCroquis();
                herramienta =
                    AceroVigaHerramientaEditor.SeleccionarMover;
                ActualizarEstadoHerramienta();
                return;
            }

            if (trazoPausado && EsHerramientaDeTrazoActiva())
            {
                if (lblEstado != null)
                    lblEstado.Text =
                        "TRAZO PAUSADO: pulse CONTINUAR TRAZO para seguir.";
                return;
            }

            if (herramienta ==
                    AceroVigaHerramientaEditor.MoverDosPuntos ||
                herramienta ==
                    AceroVigaHerramientaEditor.CopiarDosPuntos)
            {
                ProcesarTransformacionDosPuntos(punto);
                return;
            }

            if (herramienta ==
                AceroVigaHerramientaEditor.AgregarLongitudinal)
            {
                AgregarBarra(punto);
                return;
            }

            if (herramienta ==
                AceroVigaHerramientaEditor.DistribuirLongitudinales)
            {
                if (e.Button == WinForms.MouseButtons.Left)
                    IniciarDistribucionLongitudinalConArrastre(punto);
                return;
            }

            if (herramienta ==
                AceroVigaHerramientaEditor.EstriboPerimetral)
            {
                AgregarEstriboPerimetral();
                return;
            }

            if (e.Button == WinForms.MouseButtons.Left &&
                EsHerramientaRectanguloRomboConArrastre())
            {
                LimpiarEstadoArrastreEstribo();
                IniciarCreacionEstriboConArrastre(punto, e.Location);
                return;
            }

            if (e.Button == WinForms.MouseButtons.Left &&
                EsHerramientaCroquisLibrePorClics())
            {
                ProcesarCreacionEstriboPorDosClics(punto, e.Location);
                return;
            }

            if (herramienta == AceroVigaHerramientaEditor.GanchoC ||
                herramienta == AceroVigaHerramientaEditor.GanchoS)
            {
                ProcesarGanchoEntreLongitudinales(e.Location);
                return;
            }

            if (herramienta ==
                AceroVigaHerramientaEditor.HorizontalAlmaDosPuntos)
            {
                ProcesarHerramientaEstriboDosPuntos(punto);
                return;
            }

            if (herramienta ==
                    AceroVigaHerramientaEditor.TrabaAbierta)
            {
                puntosCroquisActual.Add(punto.Copiar());

                if (panelLienzo != null)
                    panelLienzo.Invalidate();

                return;
            }

            if (modoEditorActual == AceroVigaModoEditorInicial.Estribos &&
                herramienta == AceroVigaHerramientaEditor.SeleccionarMover &&
                e.Button == WinForms.MouseButtons.Left)
            {
                bool controlPresionado = EstaControlSeleccionPresionado();

                // Con Ctrl el gesto se resuelve al soltar: un clic alterna el
                // recorrido bajo el cursor y un arrastre agrega otra ventana o
                // cruce a la selección existente.
                if (controlPresionado)
                {
                    IniciarSeleccionRegionEstribos(e.Location, true);
                    return;
                }

                string idDetectado;
                int verticeDetectado;
                if (TryDetectarEstriboEnPunto(
                        punto,
                        out idDetectado,
                        out verticeDetectado))
                {
                    SeleccionarSoloEstribo(idDetectado, verticeDetectado);
                    arrastrando = true;
                    RegistrarHistorial();

                    if (panelLienzo != null)
                        panelLienzo.Invalidate();
                    return;
                }

                // Clic o arrastre sobre vacío: inicia selección rectangular.
                IniciarSeleccionRegionEstribos(e.Location, false);
                return;
            }

            if (modoEditorActual ==
                    AceroVigaModoEditorInicial.Longitudinales &&
                herramienta ==
                    AceroVigaHerramientaEditor.SeleccionarMover &&
                e.Button == WinForms.MouseButtons.Left)
            {
                bool controlPresionado = EstaControlSeleccionPresionado();

                // Ctrl+Clic alterna un conjunto completo. Ctrl+arrastre agrega una
                // VENTANA o CRUCE sin perder la selección existente.
                if (controlPresionado)
                {
                    IniciarSeleccionRegionLongitudinal(e.Location, true);
                    return;
                }

                // Los controles de extremos solo se habilitan cuando existe un
                // único conjunto seleccionado, para evitar ediciones ambiguas.
                string grupoExtremoId;
                bool esExtremoInicial;
                if (idsGruposLongitudinalesSeleccionados.Count <= 1 &&
                    idsBarrasLongitudinalesSeleccionadas.Count == 0 &&
                    TryDetectarExtremoGrupoLongitudinal(
                        e.Location,
                        out grupoExtremoId,
                        out esExtremoInicial))
                {
                    SeleccionarGrupoLongitudinalCompleto(grupoExtremoId);
                    arrastrandoExtremoGrupoLongitudinal = true;
                    idGrupoLongitudinalArrastreExtremo = grupoExtremoId;
                    arrastrandoInicioGrupoLongitudinal = esExtremoInicial;
                    arrastrando = false;
                    RegistrarHistorial();

                    if (panelLienzo != null)
                    {
                        panelLienzo.Capture = true;
                        panelLienzo.Cursor = WinForms.Cursors.SizeAll;
                        panelLienzo.Invalidate();
                    }

                    if (lblEstado != null)
                    {
                        lblEstado.Text = esExtremoInicial
                            ? "Arrastre el extremo INICIAL del conjunto. OSNAP, proyecciones y referencias permanecen activos."
                            : "Arrastre el extremo FINAL del conjunto. OSNAP, proyecciones y referencias permanecen activos.";
                    }
                    return;
                }

                AceroVigaBarraLongitudinal2D barraDetectada;
                if (TryDetectarBarraLongitudinalEnPunto(
                        punto,
                        out barraDetectada))
                {
                    SeleccionarSoloLongitudinal(barraDetectada);

                    // Las barras individuales conservan el arrastre directo. Los
                    // grupos se editan mediante sus controles INICIO/FINAL.
                    arrastrando = string.IsNullOrWhiteSpace(
                        barraDetectada.GrupoDistribucionId);
                    if (arrastrando)
                        RegistrarHistorial();

                    if (lblEstado != null)
                    {
                        lblEstado.Text = !string.IsNullOrWhiteSpace(
                            barraDetectada.GrupoDistribucionId)
                                ? "Conjunto longitudinal seleccionado completo. Ctrl+Clic o Ctrl+región permite acumular otros conjuntos."
                                : "Barra longitudinal individual seleccionada. Ctrl+Clic o Ctrl+región permite acumular otras barras.";
                    }

                    if (panelLienzo != null)
                        panelLienzo.Invalidate();
                    return;
                }

                // Sobre vacío inicia la selección tipo AutoCAD/Revit.
                IniciarSeleccionRegionLongitudinal(e.Location, false);
                return;
            }

            DetectarSeleccion(punto);

            if (herramienta ==
                AceroVigaHerramientaEditor.CambiarGancho)
            {
                CambiarGanchoEnSeleccion(punto);
                return;
            }

            if (herramienta ==
                AceroVigaHerramientaEditor.Eliminar)
            {
                EliminarSeleccionado();
                return;
            }

            arrastrando =
                !string.IsNullOrWhiteSpace(idSeleccionado);

            if (arrastrando)
                RegistrarHistorial();

            if (panelLienzo != null)
                panelLienzo.Invalidate();
        }

        private void OnLienzoMouseMove(WinForms.MouseEventArgs e)
        {
            if (paneandoVista)
            {
                if (e.Button == WinForms.MouseButtons.Middle)
                    ActualizarPaneoVista(e.Location);
                else
                    FinalizarPaneoVista();

                return;
            }

            if (seleccionandoRegionLongitudinal)
            {
                finSeleccionRegionLongitudinal = e.Location;
                puntoSnapActual = null;
                textoSnapActual = string.Empty;

                if (panelLienzo != null)
                    panelLienzo.Invalidate();
                return;
            }

            if (seleccionandoRegionEstribos)
            {
                finSeleccionRegionEstribos = e.Location;
                puntoSnapActual = null;
                textoSnapActual = string.Empty;

                if (panelLienzo != null)
                    panelLienzo.Invalidate();
                return;
            }

            AceroVigaPuntoMm puntoCrudo =
                ConvertirPantallaAModelo(e.Location);

            puntoSnapActual = AplicarSnap(puntoCrudo);

            if (creandoEstriboConArrastre)
            {
                bool esCroquisLibre =
                    herramientaArrastre ==
                    AceroVigaHerramientaEditor.EstriboLibreCerrado;

                if (esCroquisLibre ||
                    e.Button == WinForms.MouseButtons.Left)
                {
                    ActualizarCreacionEstriboConArrastre(
                        puntoSnapActual ?? puntoCrudo,
                        e.Location);
                }

                if (panelLienzo != null)
                    panelLienzo.Invalidate();
                return;
            }

            if (creandoDistribucionLongitudinalConArrastre)
            {
                if (e.Button == WinForms.MouseButtons.Left)
                {
                    ActualizarDistribucionLongitudinalConArrastre(
                        puntoSnapActual ?? puntoCrudo);
                }
                else
                {
                    CancelarDistribucionLongitudinalConArrastre(false);
                }

                if (panelLienzo != null)
                    panelLienzo.Invalidate();
                return;
            }

            if (arrastrandoExtremoGrupoLongitudinal)
            {
                if (e.Button == WinForms.MouseButtons.Left)
                {
                    ActualizarArrastreExtremoGrupoLongitudinal(
                        puntoSnapActual ?? puntoCrudo);
                }
                else
                {
                    FinalizarArrastreExtremoGrupoLongitudinal(false);
                }

                if (panelLienzo != null)
                    panelLienzo.Invalidate();
                return;
            }

            if (!arrastrando ||
                e.Button != WinForms.MouseButtons.Left)
            {
                if (panelLienzo != null &&
                    modoEditorActual ==
                        AceroVigaModoEditorInicial.Longitudinales &&
                    herramienta ==
                        AceroVigaHerramientaEditor.SeleccionarMover)
                {
                    string grupoSobreCursor;
                    bool extremoInicialSobreCursor;
                    panelLienzo.Cursor =
                        idsGruposLongitudinalesSeleccionados.Count <= 1 &&
                        idsBarrasLongitudinalesSeleccionadas.Count == 0 &&
                        TryDetectarExtremoGrupoLongitudinal(
                            e.Location,
                            out grupoSobreCursor,
                            out extremoInicialSobreCursor)
                                ? WinForms.Cursors.Hand
                                : WinForms.Cursors.Cross;
                }

                if (panelLienzo != null)
                    panelLienzo.Invalidate();

                return;
            }

            AceroVigaPuntoMm punto =
                puntoSnapActual ?? puntoCrudo;

            if (punto == null)
                return;

            AceroVigaBarraLongitudinal2D barra =
                disenoTrabajo.Longitudinales.FirstOrDefault(
                    elemento =>
                        elemento != null &&
                        elemento.Id == idSeleccionado);

            if (barra != null)
            {
                if (!string.IsNullOrWhiteSpace(
                        barra.GrupoDistribucionId))
                {
                    // Una barra perteneciente a un grupo nunca se desacopla por
                    // arrastre individual. El grupo completo permanece seleccionado.
                    arrastrando = false;
                    if (lblEstado != null)
                    {
                        lblEstado.Text =
                            "Conjunto seleccionado. Use MOVER 2 PTOS para desplazarlo o doble clic para modificar su regla.";
                    }
                    return;
                }

                List<AceroVigaPuntoMm> permitido =
                    ObtenerContornoCentrosLongitudinalMm(
                        barra.TipoBarra ?? TipoLongitudinalActual);

                AceroVigaPuntoMm puntoGuiado = punto;
                if (!string.IsNullOrWhiteSpace(barra.GuiaCapaId))
                {
                    AceroVigaGuiaCapaLongitudinal2D guiaBarra =
                        disenoTrabajo.GuiasCapasLongitudinales.FirstOrDefault(x =>
                            x != null && x.Id == barra.GuiaCapaId);
                    if (guiaBarra != null)
                    {
                        double minZ = permitido.Min(x => x.Z);
                        double maxZ = permitido.Max(x => x.Z);
                        puntoGuiado = new AceroVigaPuntoMm(
                            punto.Y,
                            minZ + (maxZ - minZ) * guiaBarra.V);
                    }
                }

                AceroVigaPuntoMm ajustado =
                    AjustarPuntoAlContornoPermitido(
                        puntoGuiado,
                        permitido);

                barra.Punto =
                    NormalizarEnCaja(ajustado, permitido);

                if (panelLienzo != null)
                    panelLienzo.Invalidate();

                return;
            }

            AceroVigaEstribo2D estribo =
                disenoTrabajo.Estribos.FirstOrDefault(
                    elemento =>
                        elemento != null &&
                        elemento.Id == idSeleccionado);

            if (estribo == null ||
                estribo.UsarContornoOffsetAutomatico ||
                estribo.Puntos == null ||
                indiceVerticeSeleccionado < 0 ||
                indiceVerticeSeleccionado >= estribo.Puntos.Count)
            {
                return;
            }

            List<AceroVigaPuntoMm> contorno =
                ObtenerContornoEjeEstriboMm(
                    estribo.TipoBarra ?? TipoEstriboActual);

            // En vigas se permite editar el recorrido fuera del concreto y del
            // límite de recubrimiento. El handler decidirá después si la geometría
            // final es válida para Revit.
            estribo.Puntos[indiceVerticeSeleccionado] =
                NormalizarEnCaja(
                    punto,
                    contorno);

            if (panelLienzo != null)
                panelLienzo.Invalidate();
        }

        private void OnLienzoMouseLeave()
        {
            if (panelLienzo != null && panelLienzo.Capture)
                return;

            puntoSnapActual = null;
            textoSnapActual = string.Empty;
            verticePrioritarioActual = null;
            textoVerticePrioritarioActual = string.Empty;
            verticePrioritarioCapturado = false;

            if (panelLienzo != null)
                panelLienzo.Invalidate();
        }

        private void OnLienzoMouseUp(WinForms.MouseEventArgs e)
        {
            if (e.Button == WinForms.MouseButtons.Middle || paneandoVista)
            {
                FinalizarPaneoVista();
                return;
            }

            if (e.Button == WinForms.MouseButtons.Left &&
                creandoDistribucionLongitudinalConArrastre)
            {
                FinalizarDistribucionLongitudinalConArrastre(e.Location);
                return;
            }

            if (e.Button == WinForms.MouseButtons.Left &&
                seleccionandoRegionLongitudinal)
            {
                FinalizarSeleccionRegionLongitudinal(e.Location);
                return;
            }

            if (e.Button == WinForms.MouseButtons.Left &&
                seleccionandoRegionEstribos)
            {
                FinalizarSeleccionRegionEstribos(e.Location);
                return;
            }

            if (e.Button == WinForms.MouseButtons.Left &&
                creandoEstriboConArrastre &&
                (herramientaArrastre ==
                    AceroVigaHerramientaEditor.EstriboRectangular ||
                 herramientaArrastre ==
                    AceroVigaHerramientaEditor.EstriboRombo))
            {
                AceroVigaPuntoMm puntoCrudo =
                    ConvertirPantallaAModelo(e.Location);
                AceroVigaPuntoMm puntoFinal =
                    AplicarSnap(puntoCrudo) ?? puntoCrudo;

                FinalizarCreacionEstriboConArrastre(puntoFinal);
                return;
            }

            if (e.Button == WinForms.MouseButtons.Left &&
                arrastrandoExtremoGrupoLongitudinal)
            {
                FinalizarArrastreExtremoGrupoLongitudinal(true);
                return;
            }

            bool huboArrastre = arrastrando;
            arrastrando = false;

            if (huboArrastre)
            {
                if (modoEditorActual ==
                    AceroVigaModoEditorInicial.Longitudinales)
                {
                    RecalcularOmisionesExtremosGruposLongitudinales();
                }

                PublicarCambiosIncrustados();
            }
        }

        private void OnLienzoDoubleClick(WinForms.MouseEventArgs e)
        {
            if (e.Button == WinForms.MouseButtons.Middle)
            {
                RestablecerNavegacionVista();
                return;
            }

            if (e.Button == WinForms.MouseButtons.Left &&
                modoEditorActual ==
                    AceroVigaModoEditorInicial.Longitudinales &&
                EditarGrupoLongitudinalDesdeDobleClic(e.Location))
            {
                return;
            }

            if (herramienta ==
                    AceroVigaHerramientaEditor.TrabaAbierta ||
                herramienta ==
                    AceroVigaHerramientaEditor.EstriboLibreCerrado)
            {
                FinalizarCroquis();
            }
        }

        private bool EditarGrupoLongitudinalDesdeDobleClic(
            Drawing.Point ubicacionPantalla)
        {
            if (disenoTrabajo == null ||
                disenoTrabajo.Longitudinales == null ||
                disenoTrabajo.GruposLongitudinales == null)
            {
                return false;
            }

            AceroVigaPuntoMm punto =
                ConvertirPantallaAModelo(ubicacionPantalla);
            double tolerancia = ObtenerToleranciaModelo(16F);
            AceroVigaBarraLongitudinal2D mejorBarra = null;
            double mejorDistancia = double.MaxValue;

            foreach (AceroVigaBarraLongitudinal2D barra in
                disenoTrabajo.Longitudinales)
            {
                if (barra == null || barra.Punto == null ||
                    string.IsNullOrWhiteSpace(
                        barra.GrupoDistribucionId))
                {
                    continue;
                }

                RebarBarType tipoBarra =
                    barra.TipoBarra ?? TipoLongitudinalActual;
                List<AceroVigaPuntoMm> contorno =
                    ObtenerContornoCentrosLongitudinalMm(tipoBarra);
                if (contorno == null || contorno.Count < 3)
                    continue;

                AceroVigaPuntoMm posicion =
                    DesnormalizarEnCaja(barra.Punto, contorno);
                double distancia = Distancia(punto, posicion);
                if (distancia <= tolerancia &&
                    distancia < mejorDistancia)
                {
                    mejorDistancia = distancia;
                    mejorBarra = barra;
                }
            }

            if (mejorBarra == null)
                return false;

            return EditarReglaGrupoLongitudinal(
                mejorBarra.GrupoDistribucionId);
        }

        private double ObtenerLongitudGrupoLongitudinalMm(
            AceroVigaGrupoLongitudinal2D grupo,
            out AceroVigaGuiaCapaLongitudinal2D guia,
            out List<AceroVigaPuntoMm> puntosGuia,
            out List<AceroVigaPuntoMm> permitido)
        {
            guia = null;
            puntosGuia = new List<AceroVigaPuntoMm>();
            permitido = new List<AceroVigaPuntoMm>();

            if (grupo == null)
                return 0.0;

            RebarBarType tipo =
                grupo.TipoBarra ?? TipoLongitudinalActual;
            permitido =
                ObtenerContornoCentrosLongitudinalMm(tipo);
            if (permitido == null || permitido.Count < 3)
                return 0.0;

            guia = disenoTrabajo.GuiasCapasLongitudinales != null
                ? disenoTrabajo.GuiasCapasLongitudinales.FirstOrDefault(x =>
                    x != null &&
                    string.Equals(
                        x.Id,
                        grupo.GuiaCapaId,
                        StringComparison.Ordinal))
                : null;

            if (guia != null)
                puntosGuia = ObtenerPuntosGuiaMm(guia, permitido);

            if (puntosGuia != null &&
                puntosGuia.Count >= 2 &&
                grupo.ParametroInicioGuia >= 0.0 &&
                grupo.ParametroFinGuia >= 0.0)
            {
                return Math.Abs(
                    grupo.ParametroFinGuia -
                    grupo.ParametroInicioGuia) *
                    LongitudCadenaGuia(puntosGuia);
            }

            if (grupo.PuntoInicio == null ||
                grupo.PuntoFin == null)
            {
                return 0.0;
            }

            AceroVigaPuntoMm inicio =
                DesnormalizarEnCaja(
                    grupo.PuntoInicio,
                    permitido);
            AceroVigaPuntoMm fin =
                DesnormalizarEnCaja(
                    grupo.PuntoFin,
                    permitido);
            return Distancia(inicio, fin);
        }

        private bool EditarReglaGrupoLongitudinal(
            string grupoId)
        {
            if (string.IsNullOrWhiteSpace(grupoId) ||
                disenoTrabajo.GruposLongitudinales == null)
            {
                return false;
            }

            AceroVigaGrupoLongitudinal2D grupo =
                disenoTrabajo.GruposLongitudinales.FirstOrDefault(x =>
                    x != null &&
                    string.Equals(
                        x.Id,
                        grupoId,
                        StringComparison.Ordinal));
            if (grupo == null)
                return false;

            AceroVigaGuiaCapaLongitudinal2D guia;
            List<AceroVigaPuntoMm> puntosGuia;
            List<AceroVigaPuntoMm> permitido;
            double longitudMm = ObtenerLongitudGrupoLongitudinalMm(
                grupo,
                out guia,
                out puntosGuia,
                out permitido);
            if (longitudMm <= 1.0)
                return false;

            using (AceroVigaReglaGrupoLongitudinalForm dialogo =
                new AceroVigaReglaGrupoLongitudinalForm(
                    longitudMm / 10.0,
                    grupo.Regla,
                    Math.Max(0.10, grupo.EspaciadoCm),
                    Math.Max(1, grupo.Cantidad)))
            {
                WinForms.Form propietario = FindForm();
                WinForms.DialogResult resultado =
                    propietario != null
                        ? dialogo.ShowDialog(propietario)
                        : dialogo.ShowDialog();

                if (resultado != WinForms.DialogResult.OK)
                    return true;

                RegistrarHistorial();

                grupo.Regla = dialogo.ReglaSeleccionada;
                if (grupo.Regla ==
                    AceroVigaReglaGrupoLongitudinal.EspaciadoMaximo)
                {
                    grupo.EspaciadoCm =
                        Math.Max(0.10, dialogo.EspaciadoCm);
                    grupo.Cantidad = Math.Max(
                        2,
                        (int)Math.Ceiling(
                            (longitudMm / 10.0) /
                            grupo.EspaciadoCm) + 1);
                }
                else
                {
                    grupo.Regla =
                        AceroVigaReglaGrupoLongitudinal.NumeroFijo;
                    grupo.Cantidad =
                        Math.Max(1, dialogo.Cantidad);
                    grupo.EspaciadoCm =
                        grupo.Cantidad <= 1
                            ? 0.0
                            : (longitudMm / 10.0) /
                                (grupo.Cantidad - 1);
                }

                ReconstruirBarrasGrupoLongitudinal(
                    grupo,
                    guia,
                    puntosGuia,
                    permitido);

                if (nudCantidadDistribucion != null)
                {
                    decimal valor = Math.Max(
                        nudCantidadDistribucion.Minimum,
                        Math.Min(
                            nudCantidadDistribucion.Maximum,
                            grupo.Cantidad));
                    nudCantidadDistribucion.Value = valor;
                }

                ultimaReglaDistribucion = grupo.Regla;
                ultimoEspaciadoDistribucionCm =
                    Math.Max(0.10, grupo.EspaciadoCm);

                ActualizarResumen();
                PublicarCambiosIncrustados();
                NotificarEstadoSeleccionTipoCambiado();
                if (panelLienzo != null)
                    panelLienzo.Invalidate();

                if (lblEstado != null)
                {
                    lblEstado.Text = grupo.Regla ==
                        AceroVigaReglaGrupoLongitudinal.EspaciadoMaximo
                            ? "Grupo actualizado: ESPACIADO MÁXIMO " +
                                grupo.EspaciadoCm.ToString("0.##") +
                                " cm; " + grupo.Cantidad +
                                " barras resultantes."
                            : "Grupo actualizado: NÚMERO FIJO " +
                                grupo.Cantidad + " barras.";
                }

                return true;
            }
        }

        private sealed class SegmentoReferenciaEditor
        {
            public AceroVigaPuntoMm A;
            public AceroVigaPuntoMm B;
        }

        private sealed class VerticeReferenciaEditor
        {
            public AceroVigaPuntoMm Punto;
            public string Texto;
            public int Prioridad;
        }

        private AceroVigaPuntoMm AplicarSnap(
            AceroVigaPuntoMm punto)
        {
            textoSnapActual = string.Empty;
            verticePrioritarioActual = null;
            textoVerticePrioritarioActual = string.Empty;
            verticePrioritarioCapturado = false;

            if (punto == null)
                return punto;

            AceroVigaPuntoMm verticePrioritario;
            string textoVertice;
            double distanciaVertice;
            bool existeVerticePrioritario =
                TryObtenerVerticePrioritario(
                    punto,
                    out verticePrioritario,
                    out textoVertice,
                    out distanciaVertice);

            if (existeVerticePrioritario)
            {
                verticePrioritarioActual = verticePrioritario.Copiar();
                textoVerticePrioritarioActual = textoVertice;
            }

            if (!osnapActivo)
                return punto;

            // 1) Los vértices/extremos conservan prioridad absoluta.
            if (osnapExtremo && existeVerticePrioritario)
            {
                textoSnapActual = textoVertice;
                verticePrioritarioCapturado = true;
                return verticePrioritario.Copiar();
            }

            AceroVigaPuntoMm mejor = null;
            double mejorDistancia = double.MaxValue;
            string mejorTexto = string.Empty;
            int mejorPrioridad = int.MaxValue;

            // En CAD, "Cercano" no debe robar el punto medio. Por eso cada
            // referencia tiene prioridad propia además de su distancia.
            Action<AceroVigaPuntoMm, string, int, float> considerar =
                (candidato, textoCandidato, prioridad, toleranciaPx) =>
                {
                    if (candidato == null)
                        return;

                    double tolerancia =
                        ObtenerToleranciaModelo(toleranciaPx);
                    double distancia = Distancia(punto, candidato);

                    if (distancia > tolerancia)
                        return;

                    bool mejorTipo = prioridad < mejorPrioridad;
                    bool mismoTipoMasCercano =
                        prioridad == mejorPrioridad &&
                        distancia < mejorDistancia - Tol;

                    if (!mejorTipo && !mismoTipoMasCercano)
                        return;

                    mejor = candidato.Copiar();
                    mejorDistancia = distancia;
                    mejorTexto = textoCandidato;
                    mejorPrioridad = prioridad;
                };

            List<SegmentoReferenciaEditor> segmentos =
                ObtenerSegmentosReferenciaEditor();

            // 2) Extremos geométricos que no hayan sido capturados por la
            // búsqueda prioritaria de vértices.
            if (osnapExtremo)
            {
                foreach (SegmentoReferenciaEditor segmento in segmentos)
                {
                    considerar(segmento.A, "Extremo", 0, 22F);
                    considerar(segmento.B, "Extremo", 0, 22F);
                }

                foreach (AceroVigaBarraLongitudinal2D barra
                    in disenoTrabajo.Longitudinales)
                {
                    if (barra == null || barra.Punto == null ||
                        barra.OcultaPorSuperposicion ||
                        EsBarraDelGrupoEnArrastreExtremo(barra))
                        continue;

                    List<AceroVigaPuntoMm> permitido =
                        ObtenerContornoCentrosLongitudinalMm(
                            barra.TipoBarra ?? TipoLongitudinalActual);

                    considerar(
                        DesnormalizarEnCaja(barra.Punto, permitido),
                        "Centro barra",
                        0,
                        22F);
                }
            }

            // 3) El punto medio usa una apertura mayor y tiene prioridad sobre
            // cercano/perpendicular aunque el cursor esté exactamente sobre la línea.
            if (osnapMedio)
            {
                foreach (SegmentoReferenciaEditor segmento in segmentos)
                {
                    considerar(
                        new AceroVigaPuntoMm(
                            (segmento.A.Y + segmento.B.Y) * 0.5,
                            (segmento.A.Z + segmento.B.Z) * 0.5),
                        "Punto medio",
                        1,
                        26F);
                }
            }

            if (osnapInterseccion)
            {
                for (int i = 0; i < segmentos.Count; i++)
                {
                    for (int j = i + 1; j < segmentos.Count; j++)
                    {
                        AceroVigaPuntoMm interseccion;

                        if (TryInterseccionSegmentos(
                            segmentos[i].A,
                            segmentos[i].B,
                            segmentos[j].A,
                            segmentos[j].B,
                            out interseccion))
                        {
                            considerar(
                                interseccion,
                                "Intersección",
                                2,
                                20F);
                        }
                    }
                }
            }

            if (osnapCentro && contornoConcretoMm.Count > 0)
            {
                considerar(
                    new AceroVigaPuntoMm(
                        (contornoConcretoMm.Min(x => x.Y) +
                         contornoConcretoMm.Max(x => x.Y)) * 0.5,
                        (contornoConcretoMm.Min(x => x.Z) +
                         contornoConcretoMm.Max(x => x.Z)) * 0.5),
                    "Centro",
                    3,
                    20F);
            }

            if (osnapPerpendicular)
            {
                foreach (SegmentoReferenciaEditor segmento in segmentos)
                {
                    considerar(
                        ProyectarPuntoEnSegmento(
                            punto,
                            segmento.A,
                            segmento.B),
                        "Perpendicular",
                        5,
                        18F);
                }
            }

            // Cercano se evalúa al final y con la prioridad más baja. Así está
            // disponible en cualquier tramo sin ocultar Medio, Extremo o Intersección.
            if (osnapCercano)
            {
                foreach (SegmentoReferenciaEditor segmento in segmentos)
                {
                    considerar(
                        ProyectarPuntoEnSegmento(
                            punto,
                            segmento.A,
                            segmento.B),
                        "Cercano",
                        9,
                        20F);
                }
            }

            AceroVigaPuntoMm inferido;
            string textoInferencia;
            double distanciaInferencia;
            double toleranciaInferencia =
                ObtenerToleranciaModelo(18F);

            if (TryObtenerInferenciaPredictiva(
                punto,
                segmentos,
                toleranciaInferencia,
                out inferido,
                out textoInferencia,
                out distanciaInferencia))
            {
                // Las inferencias tienen prioridad inferior a Medio/Intersección,
                // pero superior a Cercano.
                considerar(inferido, textoInferencia, 6, 18F);
            }

            if (mejor != null)
            {
                textoSnapActual = mejorTexto;
                return mejor;
            }

            return punto;
        }

        private bool TryObtenerVerticePrioritario(
            AceroVigaPuntoMm cursor,
            out AceroVigaPuntoMm resultado,
            out string texto,
            out double distancia)
        {
            resultado = null;
            texto = string.Empty;
            distancia = double.MaxValue;

            if (cursor == null)
                return false;

            double tolerancia = ObtenerToleranciaModelo(
                ToleranciaVerticePrioritarioPx);
            int mejorPrioridad = int.MaxValue;

            List<VerticeReferenciaEditor> vertices =
                ObtenerVerticesReferenciaEditor();

            foreach (VerticeReferenciaEditor vertice in vertices)
            {
                if (vertice == null || vertice.Punto == null)
                    continue;

                double d = Distancia(cursor, vertice.Punto);
                if (d > tolerancia)
                    continue;

                bool masCercano = d < distancia - Tol;
                bool mismaDistanciaMejorPrioridad =
                    Math.Abs(d - distancia) <= Tol &&
                    vertice.Prioridad < mejorPrioridad;

                if (!masCercano && !mismaDistanciaMejorPrioridad)
                    continue;

                resultado = vertice.Punto.Copiar();
                texto = vertice.Texto;
                distancia = d;
                mejorPrioridad = vertice.Prioridad;
            }

            return resultado != null;
        }

        private List<VerticeReferenciaEditor>
            ObtenerVerticesReferenciaEditor()
        {
            List<VerticeReferenciaEditor> resultado =
                new List<VerticeReferenciaEditor>();

            // Prioridad menor = captura preferente cuando dos referencias
            // coinciden en la misma ubicación.
            AgregarVerticesReferencia(
                resultado,
                puntosCroquisActual,
                "Vértice croquis",
                0);

            if (creandoEstriboConArrastre)
            {
                List<AceroVigaPuntoMm> puntosPrevios =
                    new List<AceroVigaPuntoMm>();

                if (puntoInicioArrastre != null)
                    puntosPrevios.Add(puntoInicioArrastre.Copiar());

                // No se agrega el último punto porque normalmente coincide con
                // el cursor y provocaría una captura artificial sobre sí mismo.
                for (int i = 0; i < puntosCroquisArrastre.Count - 1; i++)
                {
                    AceroVigaPuntoMm p = puntosCroquisArrastre[i];
                    if (p != null)
                        puntosPrevios.Add(p.Copiar());
                }

                AgregarVerticesReferencia(
                    resultado,
                    puntosPrevios,
                    "Vértice preview",
                    1);
            }

            foreach (AceroVigaEstribo2D estribo in disenoTrabajo.Estribos)
            {
                if (estribo == null)
                    continue;

                AgregarVerticesReferencia(
                    resultado,
                    ObtenerPuntosEstriboMm(estribo),
                    "Vértice estribo",
                    2);
            }

            List<AceroVigaPuntoMm> limiteActivo =
                modoEditorActual == AceroVigaModoEditorInicial.Estribos
                    ? ObtenerContornoEjeEstriboMm(TipoEstriboActual)
                    : ObtenerContornoCentrosLongitudinalMm(
                        TipoLongitudinalActual);

            AgregarVerticesReferencia(
                resultado,
                limiteActivo,
                "Vértice recubrimiento",
                3);

            AgregarVerticesReferencia(
                resultado,
                contornoConcretoMm,
                "Vértice concreto",
                4);

            foreach (AceroVigaBarraLongitudinal2D barra
                in disenoTrabajo.Longitudinales)
            {
                if (barra == null || barra.Punto == null ||
                    barra.OcultaPorSuperposicion ||
                    EsBarraDelGrupoEnArrastreExtremo(barra))
                    continue;

                List<AceroVigaPuntoMm> permitido =
                    ObtenerContornoCentrosLongitudinalMm(
                        barra.TipoBarra ?? TipoLongitudinalActual);

                AceroVigaPuntoMm centro =
                    DesnormalizarEnCaja(barra.Punto, permitido);

                AgregarVerticeReferencia(
                    resultado,
                    centro,
                    "Centro barra",
                    5);
            }

            AgregarVerticeReferencia(
                resultado,
                primerPuntoHerramienta,
                "Punto base",
                0);
            AgregarVerticeReferencia(
                resultado,
                primerPuntoDistribucion,
                "Punto base",
                0);
            AgregarVerticeReferencia(
                resultado,
                puntoBaseTransformacion,
                "Punto base",
                0);

            return resultado;
        }

        private void AgregarVerticesReferencia(
            List<VerticeReferenciaEditor> destino,
            IEnumerable<AceroVigaPuntoMm> puntos,
            string texto,
            int prioridad)
        {
            if (destino == null || puntos == null)
                return;

            foreach (AceroVigaPuntoMm punto in puntos)
            {
                AgregarVerticeReferencia(
                    destino,
                    punto,
                    texto,
                    prioridad);
            }
        }

        private void AgregarVerticeReferencia(
            List<VerticeReferenciaEditor> destino,
            AceroVigaPuntoMm punto,
            string texto,
            int prioridad)
        {
            if (destino == null || punto == null)
                return;

            const double toleranciaDuplicadoMm = 0.01;
            VerticeReferenciaEditor existente = destino.FirstOrDefault(
                x => x != null &&
                     x.Punto != null &&
                     Distancia(x.Punto, punto) <= toleranciaDuplicadoMm);

            if (existente != null)
            {
                if (prioridad < existente.Prioridad)
                {
                    existente.Prioridad = prioridad;
                    existente.Texto = texto ?? "Vértice";
                }
                return;
            }

            destino.Add(new VerticeReferenciaEditor
            {
                Punto = punto.Copiar(),
                Texto = texto ?? "Vértice",
                Prioridad = prioridad
            });
        }

        private AceroVigaPuntoMm ObtenerBaseInferenciaActual()
        {
            if (arrastrandoExtremoGrupoLongitudinal)
            {
                AceroVigaPuntoMm inicioGrupo;
                AceroVigaPuntoMm finGrupo;
                AceroVigaGuiaCapaLongitudinal2D guiaGrupo;
                List<AceroVigaPuntoMm> puntosGuiaGrupo;
                List<AceroVigaPuntoMm> permitidoGrupo;
                if (TryObtenerExtremosGrupoLongitudinal(
                        idGrupoLongitudinalArrastreExtremo,
                        out inicioGrupo,
                        out finGrupo,
                        out guiaGrupo,
                        out puntosGuiaGrupo,
                        out permitidoGrupo))
                {
                    return arrastrandoInicioGrupoLongitudinal
                        ? finGrupo
                        : inicioGrupo;
                }
            }

            if (creandoEstriboConArrastre && puntoInicioArrastre != null)
                return puntoInicioArrastre;
            if (primerPuntoHerramienta != null)
                return primerPuntoHerramienta;
            if (primerPuntoDistribucion != null)
                return primerPuntoDistribucion;
            if (puntoBaseTransformacion != null)
                return puntoBaseTransformacion;
            if (puntosCroquisActual.Count > 0)
                return puntosCroquisActual[puntosCroquisActual.Count - 1];
            return null;
        }

        private bool TryObtenerInferenciaPredictiva(
            AceroVigaPuntoMm cursor,
            List<SegmentoReferenciaEditor> segmentos,
            double tolerancia,
            out AceroVigaPuntoMm resultado,
            out string texto,
            out double distancia)
        {
            resultado = null;
            texto = string.Empty;
            distancia = double.MaxValue;
            if (cursor == null)
                return false;

            AceroVigaPuntoMm baseActual = ObtenerBaseInferenciaActual();
            AceroVigaPuntoMm mejorLocal = null;
            string textoLocal = string.Empty;
            double distanciaLocal = double.MaxValue;

            Action<AceroVigaPuntoMm, string> evaluar = (candidato, etiqueta) =>
            {
                if (candidato == null)
                    return;
                double d = Distancia(cursor, candidato);
                if (d <= tolerancia && d < distanciaLocal)
                {
                    mejorLocal = candidato.Copiar();
                    textoLocal = etiqueta;
                    distanciaLocal = d;
                }
            };

            // Proyecciones ortogonales intuitivas respecto de todos los extremos,
            // incluyendo concreto, offset de recubrimiento y estribos ya dibujados.
            if (osnapCercano && segmentos != null)
            {
                foreach (SegmentoReferenciaEditor s in segmentos)
                {
                    if (s == null)
                        continue;
                    evaluar(new AceroVigaPuntoMm(s.A.Y, cursor.Z), "Proyección vertical");
                    evaluar(new AceroVigaPuntoMm(cursor.Y, s.A.Z), "Proyección horizontal");
                    evaluar(new AceroVigaPuntoMm(s.B.Y, cursor.Z), "Proyección vertical");
                    evaluar(new AceroVigaPuntoMm(cursor.Y, s.B.Z), "Proyección horizontal");
                }
            }

            if (baseActual == null || !osnapPerpendicular)
            {
                resultado = mejorLocal;
                texto = textoLocal;
                distancia = distanciaLocal;
                return resultado != null;
            }

            // Ejes ortogonales básicos desde el punto de partida.
            evaluar(new AceroVigaPuntoMm(cursor.Y, baseActual.Z), "Paralelo horizontal");
            evaluar(new AceroVigaPuntoMm(baseActual.Y, cursor.Z), "Paralelo vertical");

            if (segmentos != null)
            {
                foreach (SegmentoReferenciaEditor s in segmentos)
                {
                    if (s == null || s.A == null || s.B == null)
                        continue;

                    double dy = s.B.Y - s.A.Y;
                    double dz = s.B.Z - s.A.Z;
                    double longitud = Math.Sqrt(dy * dy + dz * dz);
                    if (longitud <= Tol)
                        continue;
                    dy /= longitud;
                    dz /= longitud;

                    AceroVigaPuntoMm paralelo = ProyectarPuntoEnLineaInfinita(
                        cursor,
                        baseActual,
                        new AceroVigaPuntoMm(baseActual.Y + dy, baseActual.Z + dz));
                    evaluar(paralelo, "Paralelo");

                    AceroVigaPuntoMm perpendicular = ProyectarPuntoEnLineaInfinita(
                        cursor,
                        baseActual,
                        new AceroVigaPuntoMm(baseActual.Y - dz, baseActual.Z + dy));
                    evaluar(perpendicular, "Perpendicular");
                }
            }

            resultado = mejorLocal;
            texto = textoLocal;
            distancia = distanciaLocal;
            return resultado != null;
        }

        private AceroVigaPuntoMm ProyectarPuntoEnLineaInfinita(
            AceroVigaPuntoMm punto,
            AceroVigaPuntoMm a,
            AceroVigaPuntoMm b)
        {
            if (punto == null || a == null || b == null)
                return null;

            double dy = b.Y - a.Y;
            double dz = b.Z - a.Z;
            double longitud2 = dy * dy + dz * dz;
            if (longitud2 <= Tol)
                return a.Copiar();

            double t = ((punto.Y - a.Y) * dy +
                        (punto.Z - a.Z) * dz) / longitud2;
            return new AceroVigaPuntoMm(a.Y + dy * t, a.Z + dz * t);
        }

        private List<SegmentoReferenciaEditor>
            ObtenerSegmentosReferenciaEditor()
        {
            List<SegmentoReferenciaEditor> resultado =
                new List<SegmentoReferenciaEditor>();

            AgregarSegmentosPoligono(
                resultado,
                contornoConcretoMm,
                true);

            // El OSNAP incluye explícitamente el límite de referencia generado
            // por el recubrimiento. Así se puede capturar extremo, medio, cercano,
            // perpendicular e intersección sobre la línea discontinua.
            List<AceroVigaPuntoMm> limiteActivo =
                modoEditorActual == AceroVigaModoEditorInicial.Estribos
                    ? ObtenerContornoEjeEstriboMm(TipoEstriboActual)
                    : ObtenerContornoCentrosLongitudinalMm(
                        TipoLongitudinalActual);
            AgregarSegmentosPoligono(resultado, limiteActivo, true);

            if (modoEditorActual == AceroVigaModoEditorInicial.Longitudinales &&
                disenoTrabajo.GuiasCapasLongitudinales != null &&
                limiteActivo != null && limiteActivo.Count >= 3)
            {
                foreach (AceroVigaGuiaCapaLongitudinal2D guia in
                    disenoTrabajo.GuiasCapasLongitudinales.Where(x => x != null))
                {
                    List<AceroVigaPuntoMm> puntosGuia =
                        ObtenerPuntosGuiaMm(guia, limiteActivo);
                    for (int i = 1; i < puntosGuia.Count; i++)
                    {
                        resultado.Add(new SegmentoReferenciaEditor
                        {
                            A = puntosGuia[i - 1].Copiar(),
                            B = puntosGuia[i].Copiar()
                        });
                    }
                }
            }

            foreach (AceroVigaEstribo2D estribo
                in disenoTrabajo.Estribos)
            {
                if (estribo == null)
                    continue;

                List<AceroVigaPuntoMm> puntos =
                    ObtenerPuntosEstriboMm(estribo);

                AgregarSegmentosPoligono(
                    resultado,
                    puntos,
                    estribo.Cerrado);
            }

            return resultado;
        }

        private void AgregarSegmentosPoligono(
            List<SegmentoReferenciaEditor> destino,
            List<AceroVigaPuntoMm> puntos,
            bool cerrado)
        {
            if (destino == null || puntos == null ||
                puntos.Count < 2)
            {
                return;
            }

            int cantidad =
                cerrado ? puntos.Count : puntos.Count - 1;

            for (int i = 0; i < cantidad; i++)
            {
                AceroVigaPuntoMm a = puntos[i];
                AceroVigaPuntoMm b =
                    puntos[(i + 1) % puntos.Count];

                if (a == null || b == null ||
                    Distancia(a, b) <= Tol)
                {
                    continue;
                }

                destino.Add(
                    new SegmentoReferenciaEditor
                    {
                        A = a.Copiar(),
                        B = b.Copiar()
                    });
            }
        }

        private AceroVigaPuntoMm ProyectarPuntoEnSegmento(
            AceroVigaPuntoMm punto,
            AceroVigaPuntoMm a,
            AceroVigaPuntoMm b)
        {
            if (punto == null || a == null || b == null)
                return null;

            double dy = b.Y - a.Y;
            double dz = b.Z - a.Z;
            double longitud2 = dy * dy + dz * dz;

            if (longitud2 <= Tol)
                return a.Copiar();

            double t =
                ((punto.Y - a.Y) * dy +
                 (punto.Z - a.Z) * dz) /
                longitud2;

            t = Math.Max(0.0, Math.Min(1.0, t));

            return new AceroVigaPuntoMm(
                a.Y + dy * t,
                a.Z + dz * t);
        }

        private bool TryInterseccionSegmentos(
            AceroVigaPuntoMm a,
            AceroVigaPuntoMm b,
            AceroVigaPuntoMm c,
            AceroVigaPuntoMm d,
            out AceroVigaPuntoMm interseccion)
        {
            interseccion = null;

            if (a == null || b == null ||
                c == null || d == null)
            {
                return false;
            }

            double rY = b.Y - a.Y;
            double rZ = b.Z - a.Z;
            double sY = d.Y - c.Y;
            double sZ = d.Z - c.Z;
            double denominador =
                rY * sZ - rZ * sY;

            if (Math.Abs(denominador) <= Tol)
                return false;

            double qY = c.Y - a.Y;
            double qZ = c.Z - a.Z;
            double t =
                (qY * sZ - qZ * sY) /
                denominador;
            double u =
                (qY * rZ - qZ * rY) /
                denominador;

            if (t < -Tol || t > 1.0 + Tol ||
                u < -Tol || u > 1.0 + Tol)
            {
                return false;
            }

            interseccion = new AceroVigaPuntoMm(
                a.Y + t * rY,
                a.Z + t * rZ);

            return true;
        }

        private void ProcesarTransformacionDosPuntos(
            AceroVigaPuntoMm punto)
        {
            if (punto == null)
                return;

            if (puntoBaseTransformacion == null)
            {
                bool conservarSeleccionMultiple =
                    (modoEditorActual == AceroVigaModoEditorInicial.Estribos &&
                     idsEstribosSeleccionados.Count > 0) ||
                    (modoEditorActual ==
                        AceroVigaModoEditorInicial.Longitudinales &&
                     ObtenerCantidadUnidadesSeleccionLongitudinal() > 0);

                if (!conservarSeleccionMultiple)
                    DetectarSeleccion(punto);

                if (string.IsNullOrWhiteSpace(idSeleccionado) &&
                    idsEstribosSeleccionados.Count == 0 &&
                    ObtenerCantidadUnidadesSeleccionLongitudinal() == 0)
                {
                    if (lblEstado != null)
                    {
                        lblEstado.Text =
                            "Seleccione primero una barra o un estribo.";
                    }

                    return;
                }

                puntoBaseTransformacion = punto.Copiar();
                ActualizarEstadoHerramienta();

                if (panelLienzo != null)
                    panelLienzo.Invalidate();

                return;
            }

            double desplazamientoY =
                punto.Y - puntoBaseTransformacion.Y;
            double desplazamientoZ =
                punto.Z - puntoBaseTransformacion.Z;

            bool copiar =
                herramienta ==
                AceroVigaHerramientaEditor.CopiarDosPuntos;

            RegistrarHistorial();

            bool modificado = TransformarSeleccion(
                desplazamientoY,
                desplazamientoZ,
                copiar);

            puntoBaseTransformacion = null;

            if (modificado)
                ActualizarResumen();

            ActualizarEstadoHerramienta();

            if (panelLienzo != null)
                panelLienzo.Invalidate();
        }

        private bool TransformarSeleccion(
            double desplazamientoY,
            double desplazamientoZ,
            bool copiar)
        {
            AceroVigaBarraLongitudinal2D barra =
                disenoTrabajo.Longitudinales.FirstOrDefault(
                    elemento =>
                        elemento != null &&
                        elemento.Id == idSeleccionado);

            if (barra != null &&
                !string.IsNullOrWhiteSpace(
                    barra.GrupoDistribucionId))
            {
                string grupoId = barra.GrupoDistribucionId;
                List<AceroVigaBarraLongitudinal2D> origenes =
                    disenoTrabajo.Longitudinales.Where(x =>
                        x != null &&
                        string.Equals(
                            x.GrupoDistribucionId,
                            grupoId,
                            StringComparison.Ordinal)).ToList();

                AceroVigaGrupoLongitudinal2D grupoOrigen =
                    disenoTrabajo.GruposLongitudinales != null
                        ? disenoTrabajo.GruposLongitudinales.FirstOrDefault(x =>
                            x != null &&
                            string.Equals(
                                x.Id,
                                grupoId,
                                StringComparison.Ordinal))
                        : null;

                if (origenes.Count == 0 || grupoOrigen == null)
                    return false;

                AceroVigaGrupoLongitudinal2D grupoDestino =
                    copiar ? grupoOrigen.Copiar() : grupoOrigen;
                if (copiar)
                {
                    grupoDestino.Id = Guid.NewGuid().ToString("N");
                    grupoDestino.OmitirPrimeraBarra = false;
                    grupoDestino.OmitirUltimaBarra = false;
                    disenoTrabajo.GruposLongitudinales.Add(grupoDestino);
                }

                List<AceroVigaBarraLongitudinal2D> destinos =
                    new List<AceroVigaBarraLongitudinal2D>();

                foreach (AceroVigaBarraLongitudinal2D origen in origenes)
                {
                    AceroVigaBarraLongitudinal2D destino =
                        copiar ? origen.Copiar() : origen;

                    if (copiar)
                    {
                        destino.Id = Guid.NewGuid().ToString("N");
                        destino.GrupoDistribucionId = grupoDestino.Id;
                        disenoTrabajo.Longitudinales.Add(destino);
                    }

                    RebarBarType tipo =
                        destino.TipoBarra ?? TipoLongitudinalActual;
                    List<AceroVigaPuntoMm> permitido =
                        ObtenerContornoCentrosLongitudinalMm(tipo);
                    if (permitido == null || permitido.Count < 3)
                        continue;

                    AceroVigaPuntoMm actual =
                        DesnormalizarEnCaja(
                            destino.Punto,
                            permitido);
                    AceroVigaPuntoMm movido =
                        AjustarPuntoAlContornoPermitido(
                            new AceroVigaPuntoMm(
                                actual.Y + desplazamientoY,
                                actual.Z + desplazamientoZ),
                            permitido);

                    destino.Punto =
                        NormalizarEnCaja(movido, permitido);
                    destino.ParametroSobreGuia = -1.0;
                    destino.OcultaPorSuperposicion = false;
                    destinos.Add(destino);
                }

                if (destinos.Count == 0)
                    return false;

                grupoDestino.RespetarTrazoDosPuntos = true;
                grupoDestino.ParametroInicioGuia = 0.0;
                grupoDestino.ParametroFinGuia = 1.0;

                AceroVigaBarraLongitudinal2D primera = destinos[0];
                AceroVigaBarraLongitudinal2D ultima =
                    destinos[destinos.Count - 1];
                List<AceroVigaPuntoMm> permitidoGrupo =
                    ObtenerContornoCentrosLongitudinalMm(
                        grupoDestino.TipoBarra ??
                        TipoLongitudinalActual);
                if (permitidoGrupo != null &&
                    permitidoGrupo.Count >= 3)
                {
                    AceroVigaPuntoMm pInicio =
                        ObtenerPuntoModeloLongitudinal(primera);
                    AceroVigaPuntoMm pFin =
                        ObtenerPuntoModeloLongitudinal(ultima);
                    if (pInicio != null)
                    {
                        grupoDestino.PuntoInicio =
                            NormalizarEnCaja(
                                pInicio,
                                permitidoGrupo);
                        grupoDestino.PuntoInicioSeccionReal =
                            contornoConcretoMm != null && contornoConcretoMm.Count >= 3
                                ? NormalizarEnCaja(pInicio, contornoConcretoMm)
                                : null;
                    }
                    if (pFin != null)
                    {
                        grupoDestino.PuntoFin =
                            NormalizarEnCaja(
                                pFin,
                                permitidoGrupo);
                        grupoDestino.PuntoFinSeccionReal =
                            contornoConcretoMm != null && contornoConcretoMm.Count >= 3
                                ? NormalizarEnCaja(pFin, contornoConcretoMm)
                                : null;
                    }

                    double porcentajeCoincidencia;
                    AceroVigaGuiaCapaLongitudinal2D guiaDetectada =
                        DetectarGuiaCapaParaSegmento(
                            pInicio,
                            pFin,
                            grupoDestino.TipoBarra ??
                                TipoLongitudinalActual,
                            out porcentajeCoincidencia);
                    AplicarClasificacionCapaAGrupo(
                        grupoDestino,
                        guiaDetectada);
                    grupoDestino.ParametroInicioGuia = 0.0;
                    grupoDestino.ParametroFinGuia = 1.0;

                    foreach (AceroVigaBarraLongitudinal2D destino in destinos)
                    {
                        AsignarCapaABarra(
                            destino,
                            guiaDetectada,
                            grupoDestino.Id);
                    }
                }

                RecalcularOmisionesExtremosGruposLongitudinales();
                AceroVigaBarraLongitudinal2D primeraVisible =
                    destinos.FirstOrDefault(x =>
                        x != null &&
                        !x.OcultaPorSuperposicion) ?? destinos[0];
                idSeleccionado = primeraVisible.Id;
                indiceVerticeSeleccionado = -1;

                if (lblEstado != null)
                {
                    lblEstado.Text = copiar
                        ? "Conjunto longitudinal copiado como una nueva distribución."
                        : "Conjunto longitudinal movido completo.";
                }

                return true;
            }

            if (barra != null)
            {
                AceroVigaBarraLongitudinal2D destino =
                    copiar ? barra.Copiar() : barra;

                if (copiar)
                {
                    destino.Id = Guid.NewGuid().ToString("N");
                    disenoTrabajo.Longitudinales.Add(destino);
                }

                RebarBarType tipo = destino.TipoBarra ?? TipoLongitudinalActual;
                List<AceroVigaPuntoMm> permitido =
                    ObtenerContornoCentrosLongitudinalMm(tipo);
                AceroVigaPuntoMm actual =
                    DesnormalizarEnCaja(destino.Punto, permitido);
                AceroVigaPuntoMm movido = AjustarPuntoAlContornoPermitido(
                    new AceroVigaPuntoMm(
                        actual.Y + desplazamientoY,
                        actual.Z + desplazamientoZ),
                    permitido);

                destino.Punto = NormalizarEnCaja(movido, permitido);
                AceroVigaGuiaCapaLongitudinal2D guiaDetectada =
                    DetectarGuiaCapaParaPunto(
                        movido,
                        tipo);
                AsignarCapaABarra(
                    destino,
                    guiaDetectada,
                    string.Empty);
                RecalcularOmisionesExtremosGruposLongitudinales();
                idSeleccionado = destino.Id;
                indiceVerticeSeleccionado = -1;
                return true;
            }

            HashSet<string> ids = new HashSet<string>(
                idsEstribosSeleccionados,
                StringComparer.Ordinal);
            if (!string.IsNullOrWhiteSpace(idSeleccionado))
                ids.Add(idSeleccionado);

            List<AceroVigaEstribo2D> seleccionados =
                disenoTrabajo.Estribos
                    .Where(elemento =>
                        elemento != null &&
                        !string.IsNullOrWhiteSpace(elemento.Id) &&
                        ids.Contains(elemento.Id))
                    .ToList();

            if (seleccionados.Count == 0)
                return false;

            List<string> idsDestino = new List<string>();
            int omitidosAutomaticos = 0;

            foreach (AceroVigaEstribo2D origen in seleccionados)
            {
                if (origen.UsarContornoOffsetAutomatico)
                {
                    omitidosAutomaticos++;
                    continue;
                }

                AceroVigaEstribo2D destino = copiar ? origen.Copiar() : origen;
                if (copiar)
                {
                    destino.Id = Guid.NewGuid().ToString("N");
                    disenoTrabajo.Estribos.Add(destino);
                }

                List<AceroVigaPuntoMm> contorno =
                    ObtenerContornoEjeEstriboMm(
                        destino.TipoBarra ?? TipoEstriboActual);
                List<AceroVigaPuntoMm> puntos = ObtenerPuntosEstriboMm(destino);
                destino.Puntos.Clear();

                foreach (AceroVigaPuntoMm p in puntos)
                {
                    AceroVigaPuntoMm movido = new AceroVigaPuntoMm(
                        p.Y + desplazamientoY,
                        p.Z + desplazamientoZ);
                    destino.Puntos.Add(NormalizarEnCaja(movido, contorno));
                }

                idsDestino.Add(destino.Id);
            }

            if (idsDestino.Count == 0)
            {
                if (lblEstado != null)
                {
                    lblEstado.Text =
                        "Los estribos adaptados automáticamente no se desplazan. " +
                        "Use CROQUIS LIBRE para recorridos movibles.";
                }
                return false;
            }

            idsEstribosSeleccionados.Clear();
            foreach (string id in idsDestino)
                idsEstribosSeleccionados.Add(id);

            idSeleccionado = idsDestino[0];
            indiceVerticeSeleccionado = -1;
            NotificarEstadoSeleccionTipoCambiado();

            if (lblEstado != null)
            {
                lblEstado.Text =
                    (copiar ? "Copiados " : "Movidos ") +
                    idsDestino.Count + " recorrido(s)." +
                    (omitidosAutomaticos > 0
                        ? " Se omitieron " + omitidosAutomaticos +
                          " adaptado(s) automáticamente."
                        : string.Empty);
            }

            return true;
        }

        private bool TryObtenerBarraLongitudinalCercana(
            Drawing.Point ubicacionPantalla,
            float toleranciaPixeles,
            out AceroVigaBarraLongitudinal2D barra,
            out AceroVigaPuntoMm centro)
        {
            barra = null;
            centro = null;

            if (disenoTrabajo == null ||
                disenoTrabajo.Longitudinales == null ||
                disenoTrabajo.Longitudinales.Count == 0)
            {
                return false;
            }

            double mejor = double.MaxValue;

            foreach (AceroVigaBarraLongitudinal2D candidata in
                disenoTrabajo.Longitudinales)
            {
                if (candidata == null || candidata.Punto == null ||
                    candidata.OcultaPorSuperposicion)
                    continue;

                List<AceroVigaPuntoMm> contorno =
                    ObtenerContornoCentrosLongitudinalMm(
                        candidata.TipoBarra ?? TipoLongitudinalActual);

                if (contorno == null || contorno.Count < 3)
                    continue;

                AceroVigaPuntoMm puntoModelo =
                    DesnormalizarEnCaja(candidata.Punto, contorno);
                Drawing.PointF puntoPantalla =
                    ConvertirModeloAPantalla(puntoModelo);

                double dx = puntoPantalla.X - ubicacionPantalla.X;
                double dy = puntoPantalla.Y - ubicacionPantalla.Y;
                double distancia = Math.Sqrt(dx * dx + dy * dy);

                if (distancia <= toleranciaPixeles && distancia < mejor)
                {
                    mejor = distancia;
                    barra = candidata;
                    centro = puntoModelo;
                }
            }

            return barra != null && centro != null;
        }

        private bool TryObtenerBarraLongitudinalCercanaModelo(
            AceroVigaPuntoMm punto,
            float toleranciaPixeles,
            out AceroVigaBarraLongitudinal2D barra,
            out AceroVigaPuntoMm centro)
        {
            barra = null;
            centro = null;

            if (punto == null || panelLienzo == null)
                return false;

            Drawing.PointF pantalla = ConvertirModeloAPantalla(punto);
            return TryObtenerBarraLongitudinalCercana(
                Drawing.Point.Round(pantalla),
                toleranciaPixeles,
                out barra,
                out centro);
        }

        private void ProcesarGanchoEntreLongitudinales(
            Drawing.Point ubicacionPantalla)
        {
            RebarBarType tipoEstribo = TipoEstriboActual;

            if (tipoEstribo == null)
                return;

            AceroVigaBarraLongitudinal2D barra;
            AceroVigaPuntoMm centro;

            if (!TryObtenerBarraLongitudinalCercana(
                ubicacionPantalla,
                28F,
                out barra,
                out centro))
            {
                if (lblEstado != null)
                {
                    lblEstado.Text =
                        "GANCHO C/S: haga clic directamente sobre el centro de una barra longitudinal.";
                }

                if (panelLienzo != null)
                    panelLienzo.Invalidate();

                return;
            }

            puntoSnapActual = centro.Copiar();
            textoSnapActual = "Centro barra";

            double diametroLongitudinal = barra.DiametroMm > Tol
                ? barra.DiametroMm
                : ObtenerDiametroMm(
                    barra.TipoBarra ?? TipoLongitudinalActual);

            if (primerPuntoHerramienta == null)
            {
                primerPuntoHerramienta = centro.Copiar();
                diametroPrimerLongitudinalGanchoMm =
                    Math.Max(diametroLongitudinal, Tol);
                ActualizarEstadoHerramienta();

                if (panelLienzo != null)
                    panelLienzo.Invalidate();

                return;
            }

            if (Distancia(primerPuntoHerramienta, centro) <=
                ObtenerToleranciaModelo(4F))
            {
                if (lblEstado != null)
                    lblEstado.Text =
                        "La segunda barra longitudinal debe ser distinta de la primera.";
                return;
            }

            List<AceroVigaPuntoMm> contorno =
                ObtenerContornoEjeEstriboMm(tipoEstribo);

            if (contorno == null || contorno.Count < 3)
                return;

            RegistrarHistorial();

            AceroVigaEstribo2D gancho = new AceroVigaEstribo2D
            {
                Tipo = herramienta == AceroVigaHerramientaEditor.GanchoS
                    ? AceroVigaTipoEstribo2D.GanchoS
                    : AceroVigaTipoEstribo2D.GanchoC,
                TipoBarra = tipoEstribo,
                DiametroMm = ObtenerDiametroMm(tipoEstribo),
                DiametroLongitudinalInicioMm =
                    Math.Max(diametroPrimerLongitudinalGanchoMm, Tol),
                DiametroLongitudinalFinMm =
                    Math.Max(diametroLongitudinal, Tol),
                Cerrado = false,
                UsarContornoOffsetAutomatico = false,
                IndiceEsquinaGancho = -1
            };

            gancho.Puntos.Add(
                NormalizarEnCaja(primerPuntoHerramienta, contorno));
            gancho.Puntos.Add(
                NormalizarEnCaja(centro, contorno));

            disenoTrabajo.Estribos.Add(gancho);
            SeleccionarSoloEstribo(gancho.Id, -1);
            primerPuntoHerramienta = null;
            diametroPrimerLongitudinalGanchoMm = 0.0;

            ActualizarResumen();
            PublicarCambiosIncrustados();
            ActualizarEstadoHerramienta();

            if (panelLienzo != null)
                panelLienzo.Invalidate();
        }

        private void ProcesarHerramientaEstriboDosPuntos(
            AceroVigaPuntoMm punto)
        {
            RebarBarType tipo = TipoEstriboActual;

            if (tipo == null || punto == null)
                return;

            List<AceroVigaPuntoMm> permitido =
                ObtenerContornoEjeEstriboMm(tipo);

            if (permitido == null || permitido.Count < 3)
                return;

            // Los recorridos manuales de estribos pueden trazarse fuera del
            // concreto y del offset para facilitar croquis, copia y correcciones.
            AceroVigaPuntoMm ajustado = punto.Copiar();

            if (primerPuntoHerramienta == null)
            {
                primerPuntoHerramienta =
                    ajustado.Copiar();

                ActualizarEstadoHerramienta();

                if (panelLienzo != null)
                    panelLienzo.Invalidate();

                return;
            }

            AceroVigaPuntoMm primero =
                primerPuntoHerramienta;
            primerPuntoHerramienta = null;

            List<AceroVigaPuntoMm> puntos =
                new List<AceroVigaPuntoMm>();

            bool cerrado = false;
            AceroVigaTipoEstribo2D tipoDiseno =
                AceroVigaTipoEstribo2D.Croquis;

            double minY = Math.Min(
                primero.Y,
                ajustado.Y);
            double maxY = Math.Max(
                primero.Y,
                ajustado.Y);
            double minZ = Math.Min(
                primero.Z,
                ajustado.Z);
            double maxZ = Math.Max(
                primero.Z,
                ajustado.Z);

            if (herramienta ==
                AceroVigaHerramientaEditor.EstriboRectangular)
            {
                if (maxY - minY <= Tol ||
                    maxZ - minZ <= Tol)
                {
                    ActualizarEstadoHerramienta();
                    return;
                }

                puntos.Add(
                    new AceroVigaPuntoMm(minY, minZ));
                puntos.Add(
                    new AceroVigaPuntoMm(maxY, minZ));
                puntos.Add(
                    new AceroVigaPuntoMm(maxY, maxZ));
                puntos.Add(
                    new AceroVigaPuntoMm(minY, maxZ));

                cerrado = true;
                tipoDiseno =
                    AceroVigaTipoEstribo2D.Rectangular;
            }
            else if (herramienta ==
                AceroVigaHerramientaEditor.EstriboRombo)
            {
                double radioY =
                    Math.Abs(ajustado.Y - primero.Y);
                double radioZ =
                    Math.Abs(ajustado.Z - primero.Z);

                if (radioY <= Tol || radioZ <= Tol)
                {
                    ActualizarEstadoHerramienta();
                    return;
                }

                puntos.Add(
                    new AceroVigaPuntoMm(
                        primero.Y,
                        primero.Z + radioZ));
                puntos.Add(
                    new AceroVigaPuntoMm(
                        primero.Y + radioY,
                        primero.Z));
                puntos.Add(
                    new AceroVigaPuntoMm(
                        primero.Y,
                        primero.Z - radioZ));
                puntos.Add(
                    new AceroVigaPuntoMm(
                        primero.Y - radioY,
                        primero.Z));

                cerrado = true;
                tipoDiseno =
                    AceroVigaTipoEstribo2D.Rombo;
            }
            else if (herramienta ==
                AceroVigaHerramientaEditor.HorizontalAlmaDosPuntos)
            {
                double zMedio =
                    (primero.Z + ajustado.Z) * 0.5;

                puntos.Add(
                    new AceroVigaPuntoMm(
                        primero.Y,
                        zMedio));
                puntos.Add(
                    new AceroVigaPuntoMm(
                        ajustado.Y,
                        zMedio));

                cerrado = false;
                tipoDiseno =
                    AceroVigaTipoEstribo2D.HorizontalAlma;
            }
            else if (herramienta ==
                AceroVigaHerramientaEditor.GanchoC)
            {
                if (maxY - minY <= Tol ||
                    maxZ - minZ <= Tol)
                {
                    ActualizarEstadoHerramienta();
                    return;
                }

                puntos.Add(
                    new AceroVigaPuntoMm(maxY, maxZ));
                puntos.Add(
                    new AceroVigaPuntoMm(minY, maxZ));
                puntos.Add(
                    new AceroVigaPuntoMm(minY, minZ));
                puntos.Add(
                    new AceroVigaPuntoMm(maxY, minZ));

                cerrado = false;
                tipoDiseno =
                    AceroVigaTipoEstribo2D.GanchoC;
            }
            else if (herramienta ==
                AceroVigaHerramientaEditor.GanchoS)
            {
                if (maxY - minY <= Tol ||
                    maxZ - minZ <= Tol)
                {
                    ActualizarEstadoHerramienta();
                    return;
                }

                double medioY =
                    (minY + maxY) * 0.5;

                puntos.Add(
                    new AceroVigaPuntoMm(minY, maxZ));
                puntos.Add(
                    new AceroVigaPuntoMm(medioY, maxZ));
                puntos.Add(
                    new AceroVigaPuntoMm(medioY, minZ));
                puntos.Add(
                    new AceroVigaPuntoMm(maxY, minZ));

                cerrado = false;
                tipoDiseno =
                    AceroVigaTipoEstribo2D.GanchoS;
            }

            CrearEstriboDesdePuntos(
                puntos,
                cerrado,
                tipoDiseno);

            ActualizarEstadoHerramienta();
        }

        private void CrearEstriboDesdePuntos(
            List<AceroVigaPuntoMm> puntos,
            bool cerrado,
            AceroVigaTipoEstribo2D tipoDiseno)
        {
            RebarBarType tipo = TipoEstriboActual;
            int minimo = cerrado ? 3 : 2;

            if (cerrado &&
                (tipoDiseno == AceroVigaTipoEstribo2D.Rectangular ||
                 tipoDiseno == AceroVigaTipoEstribo2D.Rombo))
            {
                puntos = AjustarRectanguloRomboALongitudinalesYRecubrimiento(
                    puntos,
                    tipoDiseno);
            }

            if (tipo == null ||
                puntos == null ||
                puntos.Count < minimo)
            {
                return;
            }

            List<AceroVigaPuntoMm> permitido =
                ObtenerContornoEjeEstriboMm(tipo);

            if (permitido == null ||
                permitido.Count < 3)
            {
                return;
            }

            RegistrarHistorial();

            AceroVigaEstribo2D estribo =
                new AceroVigaEstribo2D
                {
                    Tipo = tipoDiseno,
                    TipoBarra = tipo,
                    DiametroMm =
                        ObtenerDiametroMm(tipo),
                    Cerrado = cerrado,
                    UsarContornoOffsetAutomatico =
                        false,
                    IndiceEsquinaGancho =
                        cerrado
                            ? ObtenerIndiceEsquinaSuperiorDerecha(
                                puntos)
                            : -1
                };

            foreach (AceroVigaPuntoMm punto in puntos)
            {
                estribo.Puntos.Add(
                    NormalizarEnCaja(
                        punto,
                        permitido));
            }

            disenoTrabajo.Estribos.Add(estribo);
            SeleccionarSoloEstribo(estribo.Id, -1);
            ActualizarResumen();

            if (panelLienzo != null)
                panelLienzo.Invalidate();
        }

        private void CambiarGanchoEnSeleccion(
            AceroVigaPuntoMm punto)
        {
            AceroVigaEstribo2D estribo =
                disenoTrabajo.Estribos.FirstOrDefault(
                    elemento =>
                        elemento != null &&
                        elemento.Id == idSeleccionado);

            if (estribo == null ||
                !estribo.Cerrado)
            {
                if (lblEstado != null)
                {
                    lblEstado.Text =
                        "Seleccione una esquina de un estribo cerrado.";
                }

                return;
            }

            List<AceroVigaPuntoMm> puntos =
                ObtenerPuntosEstriboMm(estribo);

            if (puntos == null || puntos.Count < 3)
                return;

            int mejorIndice = -1;
            double mejorDistancia =
                double.MaxValue;

            for (int i = 0; i < puntos.Count; i++)
            {
                double distancia =
                    Distancia(punto, puntos[i]);

                if (distancia < mejorDistancia)
                {
                    mejorDistancia = distancia;
                    mejorIndice = i;
                }
            }

            if (mejorIndice < 0)
                return;

            RegistrarHistorial();
            estribo.IndiceEsquinaGancho =
                mejorIndice;
            indiceVerticeSeleccionado =
                mejorIndice;

            ActualizarResumen();

            if (panelLienzo != null)
                panelLienzo.Invalidate();

            if (lblEstado != null)
            {
                lblEstado.Text =
                    "Esquina del gancho actualizada. " +
                    "El handler probará las orientaciones hacia el interior.";
            }
        }

        private void AplicarTipoActualASeleccion()
        {
            if (string.IsNullOrWhiteSpace(idSeleccionado))
            {
                if (lblEstado != null)
                    lblEstado.Text =
                        "Seleccione primero el elemento al que aplicará el tipo.";

                return;
            }

            AceroVigaBarraLongitudinal2D barra =
                disenoTrabajo.Longitudinales.FirstOrDefault(
                    elemento => elemento != null &&
                        elemento.Id == idSeleccionado);

            HashSet<string> gruposSeleccionados = new HashSet<string>(
                idsGruposLongitudinalesSeleccionados,
                StringComparer.Ordinal);
            HashSet<string> barrasSeleccionadas = new HashSet<string>(
                idsBarrasLongitudinalesSeleccionadas,
                StringComparer.Ordinal);

            if (barra != null)
            {
                if (!string.IsNullOrWhiteSpace(barra.GrupoDistribucionId))
                    gruposSeleccionados.Add(barra.GrupoDistribucionId);
                else
                    barrasSeleccionadas.Add(barra.Id);
            }

            if (gruposSeleccionados.Count > 0 ||
                barrasSeleccionadas.Count > 0)
            {
                RebarBarType tipo = TipoLongitudinalActual;
                if (tipo == null)
                    return;

                RegistrarHistorial();
                double diametroNuevo = ObtenerDiametroMm(tipo);

                foreach (AceroVigaBarraLongitudinal2D barraLongitudinal in
                    disenoTrabajo.Longitudinales)
                {
                    if (barraLongitudinal == null)
                        continue;

                    bool coincideGrupo =
                        !string.IsNullOrWhiteSpace(
                            barraLongitudinal.GrupoDistribucionId) &&
                        gruposSeleccionados.Contains(
                            barraLongitudinal.GrupoDistribucionId);
                    bool coincideIndividual =
                        string.IsNullOrWhiteSpace(
                            barraLongitudinal.GrupoDistribucionId) &&
                        barrasSeleccionadas.Contains(barraLongitudinal.Id);

                    if (!coincideGrupo && !coincideIndividual)
                        continue;

                    barraLongitudinal.TipoBarra = tipo;
                    barraLongitudinal.DiametroMm = diametroNuevo;
                }

                if (disenoTrabajo.GruposLongitudinales != null)
                {
                    foreach (AceroVigaGrupoLongitudinal2D grupo in
                        disenoTrabajo.GruposLongitudinales)
                    {
                        if (grupo != null &&
                            gruposSeleccionados.Contains(grupo.Id))
                        {
                            grupo.TipoBarra = tipo;
                            grupo.DiametroMm = diametroNuevo;
                        }
                    }
                }

                // V11.0: no se regeneran las líneas guía, pero los conjuntos
                // vinculados se vuelven a ordenar sobre ellas. Así un cambio masivo
                // de diámetro no deja barras antiguas fuera de la línea de su capa.
                // Las barras individuales permanecen exactamente donde estaban.
                SincronizarGruposVinculadosAGuias();
                RecalcularOmisionesExtremosGruposLongitudinales();
                SincronizarRepresentanteSeleccionLongitudinal();
                ActualizarResumen();

                if (panelLienzo != null)
                    panelLienzo.Invalidate();

                if (lblEstado != null)
                {
                    lblEstado.Text =
                        "Tipo aplicado a " +
                        (gruposSeleccionados.Count +
                         barrasSeleccionadas.Count) +
                        " conjunto(s) o barra(s). Se conservaron los ejes y las guías de capas.";
                }
                return;
            }

            RebarBarType tipoEstribo = TipoEstriboActual;
            if (tipoEstribo == null)
                return;

            HashSet<string> ids = new HashSet<string>(
                idsEstribosSeleccionados,
                StringComparer.Ordinal);
            if (!string.IsNullOrWhiteSpace(idSeleccionado))
                ids.Add(idSeleccionado);

            List<AceroVigaEstribo2D> seleccionados =
                disenoTrabajo.Estribos
                    .Where(elemento =>
                        elemento != null &&
                        !string.IsNullOrWhiteSpace(elemento.Id) &&
                        ids.Contains(elemento.Id))
                    .ToList();

            if (seleccionados.Count == 0)
                return;

            RegistrarHistorial();
            double diametro = ObtenerDiametroMm(tipoEstribo);
            foreach (AceroVigaEstribo2D estribo in seleccionados)
            {
                estribo.TipoBarra = tipoEstribo;
                estribo.DiametroMm = diametro;
            }

            ActualizarResumen();

            if (lblEstado != null)
            {
                lblEstado.Text = seleccionados.Count +
                    " recorrido(s) actualizado(s) al tipo " +
                    tipoEstribo.Name + ".";
            }

            if (panelLienzo != null)
                panelLienzo.Invalidate();
        }

        private void InicializarControlesCapasLongitudinales()
        {
            cmbGuiaCapaActiva = new WinForms.ComboBox
            {
                DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
                IntegralHeight = false,
                Height = 24
            };
            cmbGuiaCapaActiva.SelectedIndexChanged += (s, e) =>
            {
                AceroVigaGuiaCapaLongitudinal2D guia =
                    cmbGuiaCapaActiva.SelectedItem as
                        AceroVigaGuiaCapaLongitudinal2D;
                guiaCapaActivaId = guia != null ? guia.Id : string.Empty;
                if (guia != null && txtSeparacionCapa != null)
                {
                    txtSeparacionCapa.Text =
                        FormatearSeparacionCapaCmMYG(guia.SeparacionLibreCm);
                }
                if (panelLienzo != null)
                    panelLienzo.Invalidate();
            };

            // V11.6 MYG: TextBox tipo Revit para permitir unidades y decimales con punto.
            // Sin sufijo se interpreta en centímetros. Máximo permitido: 50 cm.
            txtSeparacionCapa = new WinForms.TextBox
            {
                Text = "2.5",
                TextAlign = WinForms.HorizontalAlignment.Center,
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };
            txtSeparacionCapa.Leave += (s, e) =>
            {
                double valorCm;
                if (TryConvertirSeparacionCapaACmMYG(
                        txtSeparacionCapa.Text,
                        out valorCm))
                {
                    txtSeparacionCapa.Text =
                        FormatearSeparacionCapaCmMYG(valorCm);
                }
            };

            btnAplicarSeparacionCapa = CrearBotonSimple(
                "APLICAR", 0, 0, 76);
            btnAplicarSeparacionCapa.Click += (s, e) =>
                AplicarSeparacionGuiaActiva();
        }

        private AceroVigaGuiaCapaLongitudinal2D ObtenerGuiaCapaActiva()
        {
            if (disenoTrabajo == null ||
                disenoTrabajo.GuiasCapasLongitudinales == null ||
                string.IsNullOrWhiteSpace(guiaCapaActivaId))
            {
                return null;
            }

            return disenoTrabajo.GuiasCapasLongitudinales.FirstOrDefault(x =>
                x != null && string.Equals(
                    x.Id,
                    guiaCapaActivaId,
                    StringComparison.Ordinal));
        }

        private void RefrescarComboGuiasCapas()
        {
            if (cmbGuiaCapaActiva == null)
                return;

            string idAnterior = guiaCapaActivaId;
            cmbGuiaCapaActiva.BeginUpdate();
            cmbGuiaCapaActiva.Items.Clear();

            if (disenoTrabajo != null &&
                disenoTrabajo.GuiasCapasLongitudinales != null)
            {
                foreach (AceroVigaGuiaCapaLongitudinal2D guia in
                    disenoTrabajo.GuiasCapasLongitudinales
                        .Where(x => x != null)
                        .OrderBy(x => x.Tipo == AceroVigaTipoCapaLongitudinal.Superior ? 0 :
                                      x.Tipo == AceroVigaTipoCapaLongitudinal.Central ? 1 : 2)
                        .ThenBy(x => x.NumeroCapa))
                {
                    cmbGuiaCapaActiva.Items.Add(guia);
                }
            }

            cmbGuiaCapaActiva.EndUpdate();
            int indice = -1;
            for (int i = 0; i < cmbGuiaCapaActiva.Items.Count; i++)
            {
                AceroVigaGuiaCapaLongitudinal2D guia =
                    cmbGuiaCapaActiva.Items[i] as AceroVigaGuiaCapaLongitudinal2D;
                if (guia != null && guia.Id == idAnterior)
                {
                    indice = i;
                    break;
                }
            }

            if (indice < 0 && cmbGuiaCapaActiva.Items.Count > 0)
                indice = 0;
            cmbGuiaCapaActiva.SelectedIndex = indice;
            if (indice < 0)
                guiaCapaActivaId = string.Empty;
        }

        private void AgregarGuiaCapa(AceroVigaTipoCapaLongitudinal tipoCapa)
        {
            if (modoEditorActual != AceroVigaModoEditorInicial.Longitudinales)
                return;

            if (disenoTrabajo.GuiasCapasLongitudinales == null)
                disenoTrabajo.GuiasCapasLongitudinales =
                    new List<AceroVigaGuiaCapaLongitudinal2D>();

            List<AceroVigaGuiaCapaLongitudinal2D> existentes =
                disenoTrabajo.GuiasCapasLongitudinales
                    .Where(x => x != null && x.Tipo == tipoCapa)
                    .OrderBy(x => x.NumeroCapa)
                    .ToList();

            if (tipoCapa == AceroVigaTipoCapaLongitudinal.Central &&
                existentes.Count > 0)
            {
                SeleccionarGuiaCapa(existentes[0]);
                return;
            }

            if ((tipoCapa == AceroVigaTipoCapaLongitudinal.Superior ||
                 tipoCapa == AceroVigaTipoCapaLongitudinal.Inferior) &&
                existentes.Count >= 4)
            {
                WinForms.MessageBox.Show(
                    this,
                    "El máximo permitido es de 4 capas superiores y 4 inferiores.",
                    "MYG",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Information);
                return;
            }

            RegistrarHistorial();
            AceroVigaGuiaCapaLongitudinal2D nueva =
                new AceroVigaGuiaCapaLongitudinal2D
                {
                    Tipo = tipoCapa,
                    NumeroCapa = tipoCapa == AceroVigaTipoCapaLongitudinal.Central
                        ? 1
                        : existentes.Count + 1,
                    SeparacionLibreCm = ObtenerSeparacionCapaActualCmMYG(),
                    DiametroReferenciaMm = Math.Max(
                        ObtenerDiametroMm(TipoLongitudinalActual),
                        6.0)
                };

            disenoTrabajo.GuiasCapasLongitudinales.Add(nueva);
            RecalcularGuiasCapasLongitudinales();
            SeleccionarGuiaCapa(nueva);
            PublicarCambiosIncrustados();
        }

        private void EliminarGuiaCapa(AceroVigaTipoCapaLongitudinal tipoCapa)
        {
            if (disenoTrabajo == null ||
                disenoTrabajo.GuiasCapasLongitudinales == null)
                return;

            AceroVigaGuiaCapaLongitudinal2D guia =
                disenoTrabajo.GuiasCapasLongitudinales
                    .Where(x => x != null && x.Tipo == tipoCapa)
                    .OrderByDescending(x => x.NumeroCapa)
                    .FirstOrDefault();
            if (guia == null)
                return;

            int barrasAsociadas = disenoTrabajo.Longitudinales.Count(x =>
                x != null && x.GuiaCapaId == guia.Id);
            if (barrasAsociadas > 0)
            {
                WinForms.DialogResult respuesta = WinForms.MessageBox.Show(
                    this,
                    "La guía " + guia.Etiqueta + " contiene " + barrasAsociadas +
                    " barra(s).\n\nSí: eliminar también las barras.\nNo: conservarlas sin capa.\nCancelar: no realizar cambios.",
                    "MYG - Eliminar capa",
                    WinForms.MessageBoxButtons.YesNoCancel,
                    WinForms.MessageBoxIcon.Warning);
                if (respuesta == WinForms.DialogResult.Cancel)
                    return;

                RegistrarHistorial();
                if (respuesta == WinForms.DialogResult.Yes)
                {
                    HashSet<string> gruposEliminar = new HashSet<string>(
                        disenoTrabajo.Longitudinales
                            .Where(x => x != null && x.GuiaCapaId == guia.Id)
                            .Select(x => x.GrupoDistribucionId)
                            .Where(x => !string.IsNullOrWhiteSpace(x)),
                        StringComparer.Ordinal);

                    disenoTrabajo.Longitudinales.RemoveAll(x =>
                        x != null && x.GuiaCapaId == guia.Id);

                    if (disenoTrabajo.GruposLongitudinales != null)
                    {
                        disenoTrabajo.GruposLongitudinales.RemoveAll(x =>
                            x != null &&
                            (x.GuiaCapaId == guia.Id ||
                             gruposEliminar.Contains(x.Id)));
                    }
                }
                else
                {
                    foreach (AceroVigaBarraLongitudinal2D barra in
                        disenoTrabajo.Longitudinales.Where(x =>
                            x != null && x.GuiaCapaId == guia.Id))
                    {
                        barra.GuiaCapaId = string.Empty;
                        barra.TipoCapa = AceroVigaTipoCapaLongitudinal.SinDefinir;
                        barra.NumeroCapa = 0;
                        barra.ParametroSobreGuia = -1.0;
                    }

                    if (disenoTrabajo.GruposLongitudinales != null)
                    {
                        foreach (AceroVigaGrupoLongitudinal2D grupo in
                            disenoTrabajo.GruposLongitudinales.Where(x =>
                                x != null && x.GuiaCapaId == guia.Id))
                        {
                            grupo.GuiaCapaId = string.Empty;
                            grupo.TipoCapa =
                                AceroVigaTipoCapaLongitudinal.SinDefinir;
                            grupo.NumeroCapa = 0;
                            grupo.ParametroInicioGuia = -1.0;
                            grupo.ParametroFinGuia = -1.0;
                        }
                    }
                }
            }
            else
            {
                RegistrarHistorial();
            }

            disenoTrabajo.GuiasCapasLongitudinales.Remove(guia);
            RenumerarGuias(tipoCapa);
            RecalcularGuiasCapasLongitudinales();
            guiaCapaActivaId = string.Empty;
            RefrescarComboGuiasCapas();
            ActualizarResumen();
            PublicarCambiosIncrustados();
            if (panelLienzo != null) panelLienzo.Invalidate();
        }

        private void RenumerarGuias(AceroVigaTipoCapaLongitudinal tipoCapa)
        {
            int numero = 1;
            foreach (AceroVigaGuiaCapaLongitudinal2D guia in
                disenoTrabajo.GuiasCapasLongitudinales
                    .Where(x => x != null && x.Tipo == tipoCapa)
                    .OrderBy(x => x.NumeroCapa))
            {
                guia.NumeroCapa = numero++;
                foreach (AceroVigaBarraLongitudinal2D barra in
                    disenoTrabajo.Longitudinales.Where(x =>
                        x != null && x.GuiaCapaId == guia.Id))
                {
                    barra.NumeroCapa = guia.NumeroCapa;
                }

                if (disenoTrabajo.GruposLongitudinales != null)
                {
                    foreach (AceroVigaGrupoLongitudinal2D grupo in
                        disenoTrabajo.GruposLongitudinales.Where(x =>
                            x != null && x.GuiaCapaId == guia.Id))
                    {
                        grupo.NumeroCapa = guia.NumeroCapa;
                    }
                }
            }
        }

        private void AplicarSeparacionGuiaActiva()
        {
            AceroVigaGuiaCapaLongitudinal2D guia = ObtenerGuiaCapaActiva();
            if (guia == null || guia.Tipo == AceroVigaTipoCapaLongitudinal.Central)
                return;

            double separacionCm;
            if (!TryConvertirSeparacionCapaACmMYG(
                    txtSeparacionCapa != null ? txtSeparacionCapa.Text : string.Empty,
                    out separacionCm))
            {
                WinForms.MessageBox.Show(
                    this,
                    "La separación libre no es válida.\n\n" +
                    "Puede ingresar, por ejemplo: 20.5, 20.5cm, 2in, 2\", 50mm o 0.20m.\n" +
                    "El rango permitido es de 0.1 cm a 50 cm.",
                    "MYG - Separación libre",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Warning);

                if (txtSeparacionCapa != null)
                {
                    txtSeparacionCapa.Focus();
                    txtSeparacionCapa.SelectAll();
                }
                return;
            }

            RegistrarHistorial();
            guia.SeparacionLibreCm = separacionCm;

            if (txtSeparacionCapa != null)
                txtSeparacionCapa.Text = FormatearSeparacionCapaCmMYG(separacionCm);

            RecalcularGuiasCapasLongitudinales();
            PublicarCambiosIncrustados();
            if (panelLienzo != null) panelLienzo.Invalidate();
        }

        // =========================================================
        // V11.6 MYG - ENTRADA DE SEPARACIÓN CON UNIDADES TIPO REVIT
        // =========================================================
        // Reglas:
        //   20.5      -> 20.5 cm
        //   20.5 cm   -> 20.5 cm
        //   2 in / 2" -> 5.08 cm
        //   50 mm     -> 5 cm
        //   0.20 m    -> 20 cm
        // Se admite punto decimal; también se tolera coma y se normaliza a punto.
        private bool TryConvertirSeparacionCapaACmMYG(
            string textoEntrada,
            out double valorCm)
        {
            valorCm = 0.0;

            if (string.IsNullOrWhiteSpace(textoEntrada))
                return false;

            string texto = textoEntrada
                .Trim()
                .ToLowerInvariant()
                .Replace(',', '.');

            // Compacta espacios para aceptar "2 in", "20 cm", etc.
            texto = new string(texto.Where(c => !char.IsWhiteSpace(c)).ToArray());

            double factorACm = 1.0; // Sin sufijo = centímetros.
            string numero = texto;

            if (texto.EndsWith("mm", StringComparison.Ordinal))
            {
                factorACm = 0.1;
                numero = texto.Substring(0, texto.Length - 2);
            }
            else if (texto.EndsWith("cm", StringComparison.Ordinal))
            {
                factorACm = 1.0;
                numero = texto.Substring(0, texto.Length - 2);
            }
            else if (texto.EndsWith("in", StringComparison.Ordinal))
            {
                factorACm = 2.54;
                numero = texto.Substring(0, texto.Length - 2);
            }
            else if (texto.EndsWith("\"", StringComparison.Ordinal))
            {
                factorACm = 2.54;
                numero = texto.Substring(0, texto.Length - 1);
            }
            else if (texto.EndsWith("m", StringComparison.Ordinal))
            {
                // Debe evaluarse después de mm y cm.
                factorACm = 100.0;
                numero = texto.Substring(0, texto.Length - 1);
            }

            double valorNumerico;
            if (!double.TryParse(
                    numero,
                    System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out valorNumerico))
            {
                return false;
            }

            if (double.IsNaN(valorNumerico) ||
                double.IsInfinity(valorNumerico))
            {
                return false;
            }

            valorCm = valorNumerico * factorACm;

            // Rango solicitado: hasta 50 cm. Se mantiene un mínimo práctico de 0.1 cm.
            if (valorCm < 0.1 - 1e-9 || valorCm > 50.0 + 1e-9)
            {
                valorCm = 0.0;
                return false;
            }

            valorCm = Math.Round(valorCm, 4);
            return true;
        }

        private double ObtenerSeparacionCapaActualCmMYG()
        {
            double valorCm;
            if (txtSeparacionCapa != null &&
                TryConvertirSeparacionCapaACmMYG(
                    txtSeparacionCapa.Text,
                    out valorCm))
            {
                return valorCm;
            }

            return 2.5;
        }

        private string FormatearSeparacionCapaCmMYG(double valorCm)
        {
            if (double.IsNaN(valorCm) || double.IsInfinity(valorCm))
                valorCm = 2.5;

            valorCm = Math.Max(0.1, Math.Min(50.0, valorCm));

            return valorCm.ToString(
                "0.####",
                System.Globalization.CultureInfo.InvariantCulture);
        }

        private List<AceroVigaPuntoMm> LimpiarCadenaGuia(
            IEnumerable<AceroVigaPuntoMm> puntos)
        {
            List<AceroVigaPuntoMm> limpia = new List<AceroVigaPuntoMm>();
            if (puntos == null)
                return limpia;

            foreach (AceroVigaPuntoMm punto in puntos)
            {
                if (punto == null)
                    continue;
                if (limpia.Count == 0 || Distancia(limpia[limpia.Count - 1], punto) > 0.01)
                    limpia.Add(punto.Copiar());
            }

            bool cambio = true;
            while (cambio && limpia.Count > 2)
            {
                cambio = false;
                for (int i = 1; i < limpia.Count - 1; i++)
                {
                    AceroVigaPuntoMm a = limpia[i - 1];
                    AceroVigaPuntoMm b = limpia[i];
                    AceroVigaPuntoMm c = limpia[i + 1];
                    double cruz = Math.Abs(
                        (b.Y - a.Y) * (c.Z - b.Z) -
                        (b.Z - a.Z) * (c.Y - b.Y));
                    double escala = Math.Max(Distancia(a, b) + Distancia(b, c), 1.0);
                    if (cruz <= escala * 1e-5)
                    {
                        limpia.RemoveAt(i);
                        cambio = true;
                        break;
                    }
                }
            }
            return limpia;
        }

        private List<AceroVigaPuntoMm> ObtenerCaminoPoligono(
            List<AceroVigaPuntoMm> poligono,
            int inicio,
            int fin,
            int paso)
        {
            List<AceroVigaPuntoMm> camino = new List<AceroVigaPuntoMm>();
            if (poligono == null || poligono.Count < 2)
                return camino;

            int n = poligono.Count;
            int indice = inicio;
            for (int guardia = 0; guardia <= n; guardia++)
            {
                camino.Add(poligono[indice].Copiar());
                if (indice == fin)
                    break;
                indice = (indice + paso + n) % n;
            }
            return LimpiarCadenaGuia(camino);
        }

        private List<AceroVigaPuntoMm> ExtraerCadenaSuperiorInferior(
            List<AceroVigaPuntoMm> poligono,
            AceroVigaTipoCapaLongitudinal tipo)
        {
            List<AceroVigaPuntoMm> limpia = LimpiarCadenaGuia(poligono);
            if (limpia.Count < 3)
                return limpia;

            double minY = limpia.Min(x => x.Y);
            double maxY = limpia.Max(x => x.Y);
            double toleranciaY = Math.Max((maxY - minY) * 1e-6, 0.01);

            IEnumerable<int> izquierdos = Enumerable.Range(0, limpia.Count)
                .Where(i => Math.Abs(limpia[i].Y - minY) <= toleranciaY);
            IEnumerable<int> derechos = Enumerable.Range(0, limpia.Count)
                .Where(i => Math.Abs(limpia[i].Y - maxY) <= toleranciaY);

            bool superior = tipo == AceroVigaTipoCapaLongitudinal.Superior;
            int indiceIzquierdo = superior
                ? izquierdos.OrderByDescending(i => limpia[i].Z).First()
                : izquierdos.OrderBy(i => limpia[i].Z).First();
            int indiceDerecho = superior
                ? derechos.OrderByDescending(i => limpia[i].Z).First()
                : derechos.OrderBy(i => limpia[i].Z).First();

            List<AceroVigaPuntoMm> caminoA = ObtenerCaminoPoligono(
                limpia, indiceIzquierdo, indiceDerecho, 1);
            List<AceroVigaPuntoMm> caminoB = ObtenerCaminoPoligono(
                limpia, indiceIzquierdo, indiceDerecho, -1);

            double promedioA = caminoA.Count > 0 ? caminoA.Average(x => x.Z) : 0.0;
            double promedioB = caminoB.Count > 0 ? caminoB.Average(x => x.Z) : 0.0;
            List<AceroVigaPuntoMm> elegida = superior
                ? (promedioA >= promedioB ? caminoA : caminoB)
                : (promedioA <= promedioB ? caminoA : caminoB);

            if (elegida.Count >= 2 && elegida[0].Y > elegida[elegida.Count - 1].Y)
                elegida.Reverse();

            return LimpiarCadenaGuia(elegida);
        }

        private List<double> ObtenerInterseccionesVerticalesPoligono(
            List<AceroVigaPuntoMm> poligono,
            double y)
        {
            List<double> intersecciones = new List<double>();
            if (poligono == null || poligono.Count < 3)
                return intersecciones;

            for (int i = 0; i < poligono.Count; i++)
            {
                AceroVigaPuntoMm a = poligono[i];
                AceroVigaPuntoMm b = poligono[(i + 1) % poligono.Count];
                if (a == null || b == null)
                    continue;

                double minY = Math.Min(a.Y, b.Y);
                double maxY = Math.Max(a.Y, b.Y);
                if (y < minY - 0.001 || y > maxY + 0.001)
                    continue;

                double dy = b.Y - a.Y;
                if (Math.Abs(dy) <= Tol)
                    continue;

                double t = (y - a.Y) / dy;
                if (t < -1e-8 || t > 1.0 + 1e-8)
                    continue;
                intersecciones.Add(a.Z + (b.Z - a.Z) * t);
            }

            return intersecciones
                .OrderBy(x => x)
                .Aggregate(new List<double>(), (lista, valor) =>
                {
                    if (lista.Count == 0 || Math.Abs(lista[lista.Count - 1] - valor) > 0.01)
                        lista.Add(valor);
                    return lista;
                });
        }

        private List<AceroVigaPuntoMm> ConstruirGuiaCentralAdaptativa(
            List<AceroVigaPuntoMm> poligono)
        {
            List<AceroVigaPuntoMm> resultado = new List<AceroVigaPuntoMm>();
            if (poligono == null || poligono.Count < 3)
                return resultado;

            double minY = poligono.Min(x => x.Y);
            double maxY = poligono.Max(x => x.Y);
            const int muestras = 40;
            for (int i = 0; i <= muestras; i++)
            {
                double t = (double)i / muestras;
                double y = minY + (maxY - minY) * t;
                List<double> zs = ObtenerInterseccionesVerticalesPoligono(poligono, y);
                if (zs.Count < 2)
                    continue;

                double zInferior = zs.First();
                double zSuperior = zs.Last();
                AceroVigaPuntoMm punto = new AceroVigaPuntoMm(
                    y,
                    (zInferior + zSuperior) * 0.5);
                if (PuntoDentroPoligono(punto, poligono))
                    resultado.Add(punto);
            }
            return LimpiarCadenaGuia(resultado);
        }

        private List<AceroVigaPuntoNormalizado> NormalizarCadenaGuia(
            List<AceroVigaPuntoMm> cadena,
            List<AceroVigaPuntoMm> contornoReferencia)
        {
            List<AceroVigaPuntoNormalizado> resultado =
                new List<AceroVigaPuntoNormalizado>();
            if (cadena == null || contornoReferencia == null ||
                contornoReferencia.Count < 3)
                return resultado;

            foreach (AceroVigaPuntoMm punto in cadena)
                resultado.Add(NormalizarEnCaja(punto, contornoReferencia));
            return resultado;
        }

        private List<AceroVigaPuntoMm> ObtenerPuntosGuiaMm(
            AceroVigaGuiaCapaLongitudinal2D guia,
            List<AceroVigaPuntoMm> contornoReferencia)
        {
            List<AceroVigaPuntoMm> resultado = new List<AceroVigaPuntoMm>();
            if (guia == null || contornoReferencia == null ||
                contornoReferencia.Count < 3)
                return resultado;

            // V10.6: primero se usa la referencia invariable respecto del
            // concreto. Así cambiar el tipo longitudinal no reescala la guía
            // dentro de una caja útil diferente.
            if (guia.PuntosGuiaSeccionReal != null &&
                guia.PuntosGuiaSeccionReal.Count >= 2 &&
                contornoConcretoMm != null &&
                contornoConcretoMm.Count >= 3)
            {
                foreach (AceroVigaPuntoNormalizado punto in
                    guia.PuntosGuiaSeccionReal)
                {
                    if (punto != null)
                    {
                        resultado.Add(DesnormalizarEnCaja(
                            punto,
                            contornoConcretoMm));
                    }
                }
                return LimpiarCadenaGuia(resultado);
            }

            if (guia.PuntosGuia != null && guia.PuntosGuia.Count >= 2)
            {
                foreach (AceroVigaPuntoNormalizado punto in guia.PuntosGuia)
                {
                    if (punto != null)
                        resultado.Add(DesnormalizarEnCaja(punto, contornoReferencia));
                }
                return LimpiarCadenaGuia(resultado);
            }

            double minY = contornoReferencia.Min(x => x.Y);
            double maxY = contornoReferencia.Max(x => x.Y);
            double minZ = contornoReferencia.Min(x => x.Z);
            double maxZ = contornoReferencia.Max(x => x.Z);
            double z = minZ + (maxZ - minZ) *
                Math.Max(0.0, Math.Min(1.0, guia.V));
            resultado.Add(new AceroVigaPuntoMm(minY, z));
            resultado.Add(new AceroVigaPuntoMm(maxY, z));
            return resultado;
        }

        private double LongitudCadenaGuia(List<AceroVigaPuntoMm> puntos)
        {
            double longitud = 0.0;
            if (puntos == null)
                return longitud;
            for (int i = 1; i < puntos.Count; i++)
                longitud += Distancia(puntos[i - 1], puntos[i]);
            return longitud;
        }

        private AceroVigaPuntoMm PuntoEnCadenaGuia(
            List<AceroVigaPuntoMm> puntos,
            double parametro)
        {
            if (puntos == null || puntos.Count == 0)
                return null;
            if (puntos.Count == 1)
                return puntos[0].Copiar();

            parametro = Math.Max(0.0, Math.Min(1.0, parametro));
            double total = LongitudCadenaGuia(puntos);
            if (total <= Tol)
                return puntos[0].Copiar();

            double objetivo = total * parametro;
            double acumulado = 0.0;
            for (int i = 1; i < puntos.Count; i++)
            {
                double tramo = Distancia(puntos[i - 1], puntos[i]);
                if (acumulado + tramo >= objetivo || i == puntos.Count - 1)
                {
                    double local = tramo <= Tol ? 0.0 : (objetivo - acumulado) / tramo;
                    local = Math.Max(0.0, Math.Min(1.0, local));
                    return new AceroVigaPuntoMm(
                        puntos[i - 1].Y + (puntos[i].Y - puntos[i - 1].Y) * local,
                        puntos[i - 1].Z + (puntos[i].Z - puntos[i - 1].Z) * local);
                }
                acumulado += tramo;
            }
            return puntos[puntos.Count - 1].Copiar();
        }

        // V11.0: las guías generadas desde una cara plana pueden conservar
        // vértices auxiliares muy pequeños en sus extremos. Si se distribuye por
        // longitud acumulada sobre esos segmentos, las barras intermedias parecen
        // desordenadas aunque la capa visualmente sea recta. Para conjuntos
        // paramétricos se reconoce la rectitud de la guía y se interpola siempre
        // entre sus dos extremos útiles.
        private bool EsCadenaGuiaPracticamenteRecta(
            List<AceroVigaPuntoMm> puntos)
        {
            if (puntos == null || puntos.Count < 2)
                return false;
            if (puntos.Count == 2)
                return true;

            AceroVigaPuntoMm inicio = puntos[0];
            AceroVigaPuntoMm fin = puntos[puntos.Count - 1];
            if (inicio == null || fin == null)
                return false;

            double dy = fin.Y - inicio.Y;
            double dz = fin.Z - inicio.Z;
            double longitud = Math.Sqrt(dy * dy + dz * dz);
            if (longitud <= Tol)
                return false;

            // Se admite únicamente ruido geométrico o pequeños remates de
            // intersección. Una guía realmente quebrada mantiene su polilínea.
            double toleranciaMm = Math.Max(1.25, longitud * 0.004);

            foreach (AceroVigaPuntoMm punto in puntos)
            {
                if (punto == null)
                    continue;

                double distancia = Math.Abs(
                    dy * (inicio.Z - punto.Z) -
                    (inicio.Y - punto.Y) * dz) / longitud;

                if (distancia > toleranciaMm)
                    return false;
            }

            return true;
        }

        // =========================================================
        // V11.2 - DISTRIBUCIÓN EQUIDISTANTE SOBRE LA CARA PRINCIPAL
        // =========================================================
        // Una guía adaptada al contorno puede contener pequeños remates
        // diagonales en sus extremos. Si se distribuye por la longitud
        // acumulada de toda esa polilínea, visualmente las barras pueden
        // aparentar separaciones distintas.
        //
        // Cuando existe una cara claramente dominante, se considera esa
        // cara como el tramo útil principal. Las guías realmente quebradas
        // siguen utilizando su recorrido completo.
        private bool TryObtenerTramoPrincipalCadenaGuiaMYG(
            List<AceroVigaPuntoMm> puntos,
            out AceroVigaPuntoMm inicio,
            out AceroVigaPuntoMm fin)
        {
            inicio = null;
            fin = null;

            if (puntos == null || puntos.Count < 2)
                return false;

            double longitudTotal = LongitudCadenaGuia(puntos);
            if (longitudTotal <= Tol)
                return false;

            int indiceMayor = -1;
            double mayor = 0.0;

            for (int i = 1; i < puntos.Count; i++)
            {
                if (puntos[i - 1] == null || puntos[i] == null)
                    continue;

                double longitud =
                    Distancia(puntos[i - 1], puntos[i]);

                if (longitud > mayor)
                {
                    mayor = longitud;
                    indiceMayor = i - 1;
                }
            }

            if (indiceMayor < 0 || mayor <= Tol)
                return false;

            // La cara debe dominar claramente la cadena.
            // Así no alteramos una sección genuinamente quebrada.
            if (mayor / longitudTotal < 0.52)
                return false;

            AceroVigaPuntoMm a = puntos[indiceMayor];
            AceroVigaPuntoMm b = puntos[indiceMayor + 1];

            double dy = b.Y - a.Y;
            double dz = b.Z - a.Z;
            double longitudBase =
                Math.Sqrt(dy * dy + dz * dz);

            if (longitudBase <= Tol)
                return false;

            double uy = dy / longitudBase;
            double uz = dz / longitudBase;

            int indiceInicio = indiceMayor;
            int indiceFin = indiceMayor + 1;

            // Absorbe segmentos contiguos prácticamente colineales.
            double cosenoMinimo =
                Math.Cos(6.0 * Math.PI / 180.0);

            while (indiceInicio > 0)
            {
                AceroVigaPuntoMm p0 = puntos[indiceInicio - 1];
                AceroVigaPuntoMm p1 = puntos[indiceInicio];

                double sy = p1.Y - p0.Y;
                double sz = p1.Z - p0.Z;
                double ls = Math.Sqrt(sy * sy + sz * sz);

                if (ls <= Tol)
                {
                    indiceInicio--;
                    continue;
                }

                double dot = Math.Abs(
                    (sy / ls) * uy +
                    (sz / ls) * uz);

                if (dot < cosenoMinimo)
                    break;

                indiceInicio--;
            }

            while (indiceFin < puntos.Count - 1)
            {
                AceroVigaPuntoMm p0 = puntos[indiceFin];
                AceroVigaPuntoMm p1 = puntos[indiceFin + 1];

                double sy = p1.Y - p0.Y;
                double sz = p1.Z - p0.Z;
                double ls = Math.Sqrt(sy * sy + sz * sz);

                if (ls <= Tol)
                {
                    indiceFin++;
                    continue;
                }

                double dot = Math.Abs(
                    (sy / ls) * uy +
                    (sz / ls) * uz);

                if (dot < cosenoMinimo)
                    break;

                indiceFin++;
            }

            inicio = puntos[indiceInicio].Copiar();
            fin = puntos[indiceFin].Copiar();

            return inicio != null &&
                   fin != null &&
                   Distancia(inicio, fin) > 1.0;
        }


        private bool EsGuiaSuperiorOInferiorMYG(
            AceroVigaGuiaCapaLongitudinal2D guia)
        {
            return guia != null &&
                   (guia.Tipo ==
                        AceroVigaTipoCapaLongitudinal.Superior ||
                    guia.Tipo ==
                        AceroVigaTipoCapaLongitudinal.Inferior);
        }


        // Proyecta un punto sobre la cara principal de la guía.
        // Si la guía no tiene una cara dominante, utiliza la cadena completa.
        private AceroVigaPuntoMm ProyectarPuntoSobreGuiaAlineadaMYG(
            AceroVigaPuntoMm punto,
            AceroVigaGuiaCapaLongitudinal2D guia,
            List<AceroVigaPuntoMm> permitido,
            out double distancia)
        {
            distancia = double.MaxValue;

            if (punto == null ||
                guia == null ||
                permitido == null ||
                permitido.Count < 3)
            {
                return null;
            }

            List<AceroVigaPuntoMm> puntosGuia =
                ObtenerPuntosGuiaMm(
                    guia,
                    permitido);

            if (puntosGuia == null ||
                puntosGuia.Count < 2)
            {
                return null;
            }

            AceroVigaPuntoMm aPrincipal;
            AceroVigaPuntoMm bPrincipal;

            if (TryObtenerTramoPrincipalCadenaGuiaMYG(
                    puntosGuia,
                    out aPrincipal,
                    out bPrincipal))
            {
                AceroVigaPuntoMm proyectado =
                    ProyectarPuntoEnSegmento(
                        punto,
                        aPrincipal,
                        bPrincipal);

                if (proyectado != null)
                {
                    distancia =
                        Distancia(punto, proyectado);
                    return proyectado;
                }
            }

            double parametro;

            return ProyectarPuntoSobreCadenaGuia(
                punto,
                puntosGuia,
                out parametro,
                out distancia);
        }


        // Alineación tipo CAD:
        // - si hay una guía preferida, mantiene esa misma capa;
        // - si no la hay, captura la Superior/Inferior más cercana.
        private bool TryAlinearPuntoAGuiaLongitudinalMYG(
            AceroVigaPuntoMm punto,
            RebarBarType tipoBarra,
            AceroVigaGuiaCapaLongitudinal2D guiaPreferida,
            bool exigirCercania,
            out AceroVigaPuntoMm alineado,
            out AceroVigaGuiaCapaLongitudinal2D guiaAlineada)
        {
            alineado = null;
            guiaAlineada = null;

            if (punto == null ||
                disenoTrabajo == null ||
                disenoTrabajo.GuiasCapasLongitudinales == null)
            {
                return false;
            }

            List<AceroVigaPuntoMm> permitido =
                ObtenerContornoCentrosLongitudinalMm(
                    tipoBarra ?? TipoLongitudinalActual);

            if (permitido == null ||
                permitido.Count < 3)
            {
                return false;
            }

            IEnumerable<AceroVigaGuiaCapaLongitudinal2D>
                candidatas;

            if (EsGuiaSuperiorOInferiorMYG(
                    guiaPreferida))
            {
                candidatas =
                    new[] { guiaPreferida };
            }
            else
            {
                candidatas =
                    disenoTrabajo.GuiasCapasLongitudinales
                        .Where(x =>
                            EsGuiaSuperiorOInferiorMYG(x));
            }

            double mejorDistancia =
                double.MaxValue;
            AceroVigaPuntoMm mejorPunto = null;
            AceroVigaGuiaCapaLongitudinal2D
                mejorGuia = null;

            foreach (AceroVigaGuiaCapaLongitudinal2D guia
                in candidatas)
            {
                double distancia;

                AceroVigaPuntoMm proyectado =
                    ProyectarPuntoSobreGuiaAlineadaMYG(
                        punto,
                        guia,
                        permitido,
                        out distancia);

                if (proyectado == null)
                    continue;

                if (distancia < mejorDistancia)
                {
                    mejorDistancia = distancia;
                    mejorPunto = proyectado;
                    mejorGuia = guia;
                }
            }

            if (mejorPunto == null ||
                mejorGuia == null)
            {
                return false;
            }

            if (exigirCercania)
            {
                // Un poco más permisivo que el OSNAP normal para que
                // el jalado del extremo se sienta intuitivo.
                double tolerancia =
                    ObtenerToleranciaModelo(22F);

                if (mejorDistancia > tolerancia)
                    return false;
            }

            alineado = mejorPunto.Copiar();
            guiaAlineada = mejorGuia;
            return true;
        }


        private AceroVigaPuntoMm PuntoDistribucionEnGuia(
            List<AceroVigaPuntoMm> puntos,
            double parametro)
        {
            if (puntos == null || puntos.Count == 0)
                return null;
            if (puntos.Count == 1)
                return puntos[0].Copiar();

            parametro = Math.Max(0.0, Math.Min(1.0, parametro));

            AceroVigaPuntoMm inicioPrincipal;
            AceroVigaPuntoMm finPrincipal;

            // NÚMERO FIJO debe verse y ser geométricamente equidistante.
            // Los pequeños remates laterales de una guía no participan
            // en la distribución cuando existe una cara principal clara.
            if (TryObtenerTramoPrincipalCadenaGuiaMYG(
                    puntos,
                    out inicioPrincipal,
                    out finPrincipal))
            {
                return new AceroVigaPuntoMm(
                    inicioPrincipal.Y +
                        (finPrincipal.Y -
                         inicioPrincipal.Y) * parametro,
                    inicioPrincipal.Z +
                        (finPrincipal.Z -
                         inicioPrincipal.Z) * parametro);
            }

            if (EsCadenaGuiaPracticamenteRecta(puntos))
            {
                AceroVigaPuntoMm inicio = puntos[0];
                AceroVigaPuntoMm fin =
                    puntos[puntos.Count - 1];

                return new AceroVigaPuntoMm(
                    inicio.Y +
                        (fin.Y - inicio.Y) * parametro,
                    inicio.Z +
                        (fin.Z - inicio.Z) * parametro);
            }

            return PuntoEnCadenaGuia(
                puntos,
                parametro);
        }

        private AceroVigaPuntoMm PuntoEnCadenaGuiaConDesfaseNormal(
            List<AceroVigaPuntoMm> puntos,
            List<AceroVigaPuntoMm> poligonoReferencia,
            double parametro,
            double desfaseNormalMm)
        {
            if (puntos == null || puntos.Count < 2)
                return null;

            parametro = Math.Max(0.0, Math.Min(1.0, parametro));
            double total = LongitudCadenaGuia(puntos);
            if (total <= Tol)
                return puntos[0].Copiar();

            AceroVigaPuntoMm centro = poligonoReferencia != null &&
                poligonoReferencia.Count >= 3
                    ? new AceroVigaPuntoMm(
                        poligonoReferencia.Average(x => x.Y),
                        poligonoReferencia.Average(x => x.Z))
                    : new AceroVigaPuntoMm(
                        puntos.Average(x => x.Y),
                        puntos.Average(x => x.Z));

            double objetivo = total * parametro;
            double acumulado = 0.0;

            for (int i = 1; i < puntos.Count; i++)
            {
                AceroVigaPuntoMm a = puntos[i - 1];
                AceroVigaPuntoMm b = puntos[i];
                double dy = b.Y - a.Y;
                double dz = b.Z - a.Z;
                double longitud = Math.Sqrt(dy * dy + dz * dz);
                if (longitud <= Tol)
                    continue;

                if (acumulado + longitud >= objetivo ||
                    i == puntos.Count - 1)
                {
                    double local = (objetivo - acumulado) / longitud;
                    local = Math.Max(0.0, Math.Min(1.0, local));
                    double yBase = a.Y + dy * local;
                    double zBase = a.Z + dz * local;

                    double normalY = -dz / longitud;
                    double normalZ = dy / longitud;
                    double medioY = (a.Y + b.Y) * 0.5;
                    double medioZ = (a.Z + b.Z) * 0.5;
                    double haciaCentro =
                        (centro.Y - medioY) * normalY +
                        (centro.Z - medioZ) * normalZ;
                    if (haciaCentro < 0.0)
                    {
                        normalY = -normalY;
                        normalZ = -normalZ;
                    }

                    return new AceroVigaPuntoMm(
                        yBase + normalY * desfaseNormalMm,
                        zBase + normalZ * desfaseNormalMm);
                }

                acumulado += longitud;
            }

            return puntos[puntos.Count - 1].Copiar();
        }

        private AceroVigaPuntoMm ProyectarPuntoSobreCadenaGuia(
            AceroVigaPuntoMm punto,
            List<AceroVigaPuntoMm> puntos,
            out double parametro,
            out double distancia)
        {
            parametro = 0.0;
            distancia = double.MaxValue;
            if (punto == null || puntos == null || puntos.Count < 2)
                return punto;

            double total = LongitudCadenaGuia(puntos);
            double acumulado = 0.0;
            AceroVigaPuntoMm mejor = null;
            for (int i = 1; i < puntos.Count; i++)
            {
                AceroVigaPuntoMm a = puntos[i - 1];
                AceroVigaPuntoMm b = puntos[i];
                double tramo = Distancia(a, b);
                AceroVigaPuntoMm proyectado = ProyectarPuntoEnSegmento(punto, a, b);
                double d = Distancia(punto, proyectado);
                if (d < distancia)
                {
                    distancia = d;
                    mejor = proyectado;
                    double local = tramo <= Tol ? 0.0 : Distancia(a, proyectado) / tramo;
                    parametro = total <= Tol
                        ? 0.0
                        : Math.Max(0.0, Math.Min(1.0,
                            (acumulado + tramo * local) / total));
                }
                acumulado += tramo;
            }
            return mejor ?? punto;
        }

        // Obtiene el parámetro acumulado sobre una guía y el desfase firmado
        // respecto de su normal interior. No modifica la posición dibujada.
        private bool TryObtenerReferenciaNormalSobreGuia(
            AceroVigaPuntoMm punto,
            List<AceroVigaPuntoMm> puntosGuia,
            List<AceroVigaPuntoMm> poligonoReferencia,
            out double parametro,
            out double desfaseNormalMm)
        {
            parametro = -1.0;
            desfaseNormalMm = 0.0;

            if (punto == null || puntosGuia == null || puntosGuia.Count < 2 ||
                poligonoReferencia == null || poligonoReferencia.Count < 3)
            {
                return false;
            }

            double longitudTotal = LongitudCadenaGuia(puntosGuia);
            if (longitudTotal <= Tol)
                return false;

            AceroVigaPuntoMm centro = new AceroVigaPuntoMm(
                poligonoReferencia.Average(x => x.Y),
                poligonoReferencia.Average(x => x.Z));

            double acumulado = 0.0;
            double mejorDistancia = double.MaxValue;
            double mejorParametro = -1.0;
            double mejorDesfase = 0.0;

            for (int i = 1; i < puntosGuia.Count; i++)
            {
                AceroVigaPuntoMm a = puntosGuia[i - 1];
                AceroVigaPuntoMm b = puntosGuia[i];
                if (a == null || b == null)
                    continue;

                double dy = b.Y - a.Y;
                double dz = b.Z - a.Z;
                double longitud = Math.Sqrt(dy * dy + dz * dz);
                if (longitud <= Tol)
                    continue;

                AceroVigaPuntoMm proyectado =
                    ProyectarPuntoEnSegmento(punto, a, b);
                double distancia = Distancia(punto, proyectado);

                if (distancia < mejorDistancia)
                {
                    double normalY = -dz / longitud;
                    double normalZ = dy / longitud;
                    double medioY = (a.Y + b.Y) * 0.5;
                    double medioZ = (a.Z + b.Z) * 0.5;

                    double haciaCentro =
                        (centro.Y - medioY) * normalY +
                        (centro.Z - medioZ) * normalZ;
                    if (haciaCentro < 0.0)
                    {
                        normalY = -normalY;
                        normalZ = -normalZ;
                    }

                    double local = Distancia(a, proyectado) / longitud;
                    local = Math.Max(0.0, Math.Min(1.0, local));

                    mejorParametro = Math.Max(0.0, Math.Min(1.0,
                        (acumulado + longitud * local) / longitudTotal));
                    mejorDesfase =
                        (punto.Y - proyectado.Y) * normalY +
                        (punto.Z - proyectado.Z) * normalZ;
                    mejorDistancia = distancia;
                }

                acumulado += longitud;
            }

            if (mejorParametro < 0.0)
                return false;

            parametro = mejorParametro;
            desfaseNormalMm = mejorDesfase;
            return true;
        }

        private List<AceroVigaPuntoMm> DesfasarCadenaAbiertaHaciaInterior(
            List<AceroVigaPuntoMm> cadenaBase,
            double distanciaMm,
            List<AceroVigaPuntoMm> poligonoLimite)
        {
            List<AceroVigaPuntoMm> baseLimpia =
                LimpiarCadenaGuia(cadenaBase);

            if (baseLimpia.Count < 2 ||
                poligonoLimite == null ||
                poligonoLimite.Count < 3)
            {
                return baseLimpia;
            }

            if (distanciaMm <= 0.01)
                return baseLimpia.Select(x => x.Copiar()).ToList();

            AceroVigaPuntoMm centro = new AceroVigaPuntoMm(
                poligonoLimite.Average(x => x.Y),
                poligonoLimite.Average(x => x.Z));

            List<Linea2D> lineas = new List<Linea2D>();
            for (int i = 1; i < baseLimpia.Count; i++)
            {
                AceroVigaPuntoMm a = baseLimpia[i - 1];
                AceroVigaPuntoMm b = baseLimpia[i];
                double dy = b.Y - a.Y;
                double dz = b.Z - a.Z;
                double longitud = Math.Sqrt(dy * dy + dz * dz);
                if (longitud <= Tol)
                    continue;

                double normalY = -dz / longitud;
                double normalZ = dy / longitud;
                AceroVigaPuntoMm medio = new AceroVigaPuntoMm(
                    (a.Y + b.Y) * 0.5,
                    (a.Z + b.Z) * 0.5);

                double haciaCentro =
                    (centro.Y - medio.Y) * normalY +
                    (centro.Z - medio.Z) * normalZ;
                if (haciaCentro < 0.0)
                {
                    normalY = -normalY;
                    normalZ = -normalZ;
                }

                lineas.Add(new Linea2D(
                    new AceroVigaPuntoMm(
                        a.Y + normalY * distanciaMm,
                        a.Z + normalZ * distanciaMm),
                    new AceroVigaPuntoMm(
                        b.Y + normalY * distanciaMm,
                        b.Z + normalZ * distanciaMm)));
            }

            if (lineas.Count == 0)
                return new List<AceroVigaPuntoMm>();

            List<AceroVigaPuntoMm> desplazada =
                new List<AceroVigaPuntoMm>();
            desplazada.Add(lineas[0].A.Copiar());

            for (int i = 1; i < lineas.Count; i++)
            {
                AceroVigaPuntoMm interseccion;
                if (TryIntersecarLineas(
                        lineas[i - 1],
                        lineas[i],
                        out interseccion))
                {
                    desplazada.Add(interseccion);
                }
                else
                {
                    desplazada.Add(lineas[i - 1].B.Copiar());
                }
            }

            desplazada.Add(lineas[lineas.Count - 1].B.Copiar());
            desplazada = LimpiarCadenaGuia(desplazada);

            if (desplazada.Count >= 2)
            {
                desplazada[0] = ExtenderExtremoCadenaHastaPoligono(
                    desplazada[0],
                    desplazada[1],
                    poligonoLimite,
                    true);

                int ultimo = desplazada.Count - 1;
                desplazada[ultimo] = ExtenderExtremoCadenaHastaPoligono(
                    desplazada[ultimo],
                    desplazada[ultimo - 1],
                    poligonoLimite,
                    false);
            }

            return LimpiarCadenaGuia(desplazada);
        }

        private AceroVigaPuntoMm ExtenderExtremoCadenaHastaPoligono(
            AceroVigaPuntoMm extremo,
            AceroVigaPuntoMm vecino,
            List<AceroVigaPuntoMm> poligono,
            bool esInicio)
        {
            if (extremo == null || vecino == null ||
                poligono == null || poligono.Count < 3)
            {
                return extremo;
            }

            double direccionY = esInicio
                ? extremo.Y - vecino.Y
                : extremo.Y - vecino.Y;
            double direccionZ = esInicio
                ? extremo.Z - vecino.Z
                : extremo.Z - vecino.Z;
            double longitud = Math.Sqrt(
                direccionY * direccionY +
                direccionZ * direccionZ);
            if (longitud <= Tol)
                return extremo;

            direccionY /= longitud;
            direccionZ /= longitud;

            double mejorT = double.MaxValue;
            AceroVigaPuntoMm mejorPunto = null;

            for (int i = 0; i < poligono.Count; i++)
            {
                AceroVigaPuntoMm a = poligono[i];
                AceroVigaPuntoMm b =
                    poligono[(i + 1) % poligono.Count];
                double t;
                AceroVigaPuntoMm interseccion;
                if (!TryIntersecarRayoConSegmento(
                        extremo,
                        direccionY,
                        direccionZ,
                        a,
                        b,
                        out t,
                        out interseccion))
                {
                    continue;
                }

                if (t >= -0.01 && t < mejorT)
                {
                    mejorT = t;
                    mejorPunto = interseccion;
                }
            }

            return mejorPunto ?? extremo;
        }

        private bool TryIntersecarRayoConSegmento(
            AceroVigaPuntoMm origen,
            double direccionY,
            double direccionZ,
            AceroVigaPuntoMm a,
            AceroVigaPuntoMm b,
            out double tRayo,
            out AceroVigaPuntoMm punto)
        {
            tRayo = 0.0;
            punto = null;
            if (origen == null || a == null || b == null)
                return false;

            double segmentoY = b.Y - a.Y;
            double segmentoZ = b.Z - a.Z;
            double denominador =
                direccionY * segmentoZ -
                direccionZ * segmentoY;
            if (Math.Abs(denominador) <= Tol)
                return false;

            double deltaY = a.Y - origen.Y;
            double deltaZ = a.Z - origen.Z;
            double t =
                (deltaY * segmentoZ -
                 deltaZ * segmentoY) / denominador;
            double u =
                (deltaY * direccionZ -
                 deltaZ * direccionY) / denominador;

            if (t < -0.01 || u < -1e-8 || u > 1.0 + 1e-8)
                return false;

            tRayo = Math.Max(0.0, t);
            punto = new AceroVigaPuntoMm(
                origen.Y + direccionY * tRayo,
                origen.Z + direccionZ * tRayo);
            return true;
        }

        private void RecalcularGuiasCapasLongitudinales()
        {
            if (disenoTrabajo == null ||
                disenoTrabajo.GuiasCapasLongitudinales == null ||
                contornoConcretoMm == null || contornoConcretoMm.Count < 3)
                return;

            List<AceroVigaPuntoMm> contornoReferencia =
                ObtenerContornoCentrosLongitudinalMm(TipoLongitudinalActual);
            if (contornoReferencia == null || contornoReferencia.Count < 3)
                return;

            double coverMm = ObtenerRecubrimientoActivo() * 10.0;
            double diametroEstriboMm = ObtenerDiametroMm(TipoEstriboActual);

            foreach (AceroVigaTipoCapaLongitudinal tipo in new[]
            {
                AceroVigaTipoCapaLongitudinal.Superior,
                AceroVigaTipoCapaLongitudinal.Inferior
            })
            {
                List<AceroVigaGuiaCapaLongitudinal2D> lista =
                    disenoTrabajo.GuiasCapasLongitudinales
                        .Where(x => x != null && x.Tipo == tipo)
                        .OrderBy(x => x.NumeroCapa)
                        .ToList();

                if (lista.Count == 0)
                    continue;

                double diametroPrimera =
                    Math.Max(lista[0].DiametroReferenciaMm, 1.0);
                double offsetPrimera =
                    coverMm + diametroEstriboMm +
                    diametroPrimera * 0.5;

                // Este polígono representa el límite real del recubrimiento para
                // los centros longitudinales de la primera capa. TODAS las capas
                // se extienden hasta sus bordes laterales; solo cambia su offset
                // respecto de la cara superior o inferior.
                List<AceroVigaPuntoMm> poligonoLimiteLateral =
                    DesfasarPoligonoInterior(
                        contornoConcretoMm,
                        offsetPrimera);
                List<AceroVigaPuntoMm> cadenaBase =
                    ExtraerCadenaSuperiorInferior(
                        poligonoLimiteLateral,
                        tipo);

                if (poligonoLimiteLateral.Count < 3 ||
                    cadenaBase.Count < 2)
                {
                    continue;
                }

                double offsetAbsoluto = 0.0;
                AceroVigaGuiaCapaLongitudinal2D anterior = null;

                foreach (AceroVigaGuiaCapaLongitudinal2D guia in lista)
                {
                    double diametroActual =
                        Math.Max(guia.DiametroReferenciaMm, 1.0);

                    if (anterior == null)
                    {
                        offsetAbsoluto = offsetPrimera;
                    }
                    else
                    {
                        offsetAbsoluto +=
                            Math.Max(
                                anterior.DiametroReferenciaMm,
                                1.0) * 0.5 +
                            Math.Max(
                                0.0,
                                guia.SeparacionLibreCm) * 10.0 +
                            diametroActual * 0.5;
                    }

                    guia.OffsetAcumuladoMm = offsetAbsoluto;
                    guia.AdaptadaAlContorno = true;

                    double desplazamientoAdicional =
                        Math.Max(0.0, offsetAbsoluto - offsetPrimera);
                    List<AceroVigaPuntoMm> cadena =
                        DesfasarCadenaAbiertaHaciaInterior(
                            cadenaBase,
                            desplazamientoAdicional,
                            poligonoLimiteLateral);

                    // Respaldo para secciones extremadamente cóncavas donde una
                    // cadena paralela no pueda resolverse de forma estable.
                    if (cadena == null || cadena.Count < 2)
                    {
                        List<AceroVigaPuntoMm> poligonoCapa =
                            DesfasarPoligonoInterior(
                                contornoConcretoMm,
                                offsetAbsoluto);
                        cadena = ExtraerCadenaSuperiorInferior(
                            poligonoCapa,
                            tipo);
                    }

                    guia.PuntosGuia = NormalizarCadenaGuia(
                        cadena,
                        contornoReferencia);
                    guia.PuntosGuiaSeccionReal = NormalizarCadenaGuia(
                        cadena,
                        contornoConcretoMm);
                    guia.V = guia.PuntosGuia.Count > 0
                        ? guia.PuntosGuia.Average(x => x.V)
                        : (tipo ==
                            AceroVigaTipoCapaLongitudinal.Superior
                                ? 1.0
                                : 0.0);

                    ActualizarBarrasAsociadasAGuia(guia);
                    anterior = guia;
                }
            }

            AceroVigaGuiaCapaLongitudinal2D central =
                disenoTrabajo.GuiasCapasLongitudinales.FirstOrDefault(x =>
                    x != null &&
                    x.Tipo == AceroVigaTipoCapaLongitudinal.Central);
            if (central != null)
            {
                double diametroCentral =
                    Math.Max(central.DiametroReferenciaMm, 1.0);
                central.OffsetAcumuladoMm =
                    coverMm + diametroEstriboMm +
                    diametroCentral * 0.5;
                List<AceroVigaPuntoMm> poligonoCentral =
                    DesfasarPoligonoInterior(
                        contornoConcretoMm,
                        central.OffsetAcumuladoMm);
                List<AceroVigaPuntoMm> cadenaCentral =
                    ConstruirGuiaCentralAdaptativa(poligonoCentral);
                central.PuntosGuia = NormalizarCadenaGuia(
                    cadenaCentral,
                    contornoReferencia);
                central.PuntosGuiaSeccionReal = NormalizarCadenaGuia(
                    cadenaCentral,
                    contornoConcretoMm);
                central.V = central.PuntosGuia.Count > 0
                    ? central.PuntosGuia.Average(x => x.V)
                    : 0.5;
                central.NumeroCapa = 1;
                central.AdaptadaAlContorno = true;
                ActualizarBarrasAsociadasAGuia(central);
            }

            // Después de regenerar todas las guías, los grupos vinculados se
            // reconstruyen con los extremos que ya acompañaron a su nueva capa.
            // Las barras individuales vinculadas ya fueron desplazadas arriba.
            SincronizarGruposVinculadosAGuias();
            RecalcularOmisionesExtremosGruposLongitudinales();
            RefrescarComboGuiasCapas();
        }

        // =========================================================
        // V11.7 MYG - ACEROS VINCULADOS A LAS LÍNEAS GUÍA
        // =========================================================
        // Regla de edición:
        // - Si una barra individual fue colocada/capturada sobre una guía,
        //   debe acompañar a esa guía cuando cambia la separación de capas.
        // - Si un conjunto de DISTRIBUIR 2 PUNTOS quedó asociado a una guía,
        //   sus dos extremos acompañan a la nueva posición de la guía y luego
        //   se reconstruye el conjunto manteniendo su cantidad/regla.
        // - Las barras realmente libres (GuiaCapaId vacío) no se modifican.
        private void ActualizarBarrasAsociadasAGuia(
            AceroVigaGuiaCapaLongitudinal2D guia)
        {
            if (guia == null || disenoTrabajo == null)
                return;

            // ---------------------------------------------------------
            // 1. BARRAS INDIVIDUALES VINCULADAS A LA GUÍA
            // ---------------------------------------------------------
            if (disenoTrabajo.Longitudinales != null)
            {
                foreach (AceroVigaBarraLongitudinal2D barra in
                    disenoTrabajo.Longitudinales.Where(x =>
                        x != null && x.GuiaCapaId == guia.Id))
                {
                    barra.TipoCapa = guia.Tipo;
                    barra.NumeroCapa = guia.NumeroCapa;

                    // Las barras de un grupo se reconstruyen desde el grupo.
                    // No se desplazan dos veces aquí.
                    if (!string.IsNullOrWhiteSpace(
                            barra.GrupoDistribucionId))
                    {
                        continue;
                    }

                    MoverBarraIndividualConGuiaMYG(
                        barra,
                        guia);
                }
            }

            // ---------------------------------------------------------
            // 2. GRUPOS DISTRIBUIDOS VINCULADOS A LA GUÍA
            // ---------------------------------------------------------
            if (disenoTrabajo.GruposLongitudinales != null)
            {
                foreach (AceroVigaGrupoLongitudinal2D grupo in
                    disenoTrabajo.GruposLongitudinales.Where(x =>
                        x != null && x.GuiaCapaId == guia.Id))
                {
                    grupo.TipoCapa = guia.Tipo;
                    grupo.NumeroCapa = guia.NumeroCapa;

                    // Los grupos creados mediante 2 puntos conservan su trazo
                    // exacto, pero ese trazo se traslada hasta la NUEVA posición
                    // de la línea guía. De esta forma el acero acompaña a la capa
                    // sin volver a usar los puntos antiguos.
                    if (grupo.RespetarTrazoDosPuntos)
                    {
                        MoverGrupoDosPuntosConGuiaMYG(
                            grupo,
                            guia);
                    }
                    else if (grupo.ParametroInicioGuia < 0.0 ||
                             grupo.ParametroFinGuia < 0.0)
                    {
                        // Respaldo para diseños antiguos vinculados a guía.
                        grupo.ParametroInicioGuia = 0.0;
                        grupo.ParametroFinGuia = 1.0;
                    }
                }
            }
        }

        private void MoverBarraIndividualConGuiaMYG(
            AceroVigaBarraLongitudinal2D barra,
            AceroVigaGuiaCapaLongitudinal2D guia)
        {
            if (barra == null || guia == null)
                return;

            RebarBarType tipo =
                barra.TipoBarra ?? TipoLongitudinalActual;

            List<AceroVigaPuntoMm> permitido =
                ObtenerContornoCentrosLongitudinalMm(tipo);

            if (permitido == null || permitido.Count < 3)
                return;

            AceroVigaPuntoMm puntoActual = null;

            // PuntoSeccionReal es la referencia más estable cuando existe.
            if (barra.PuntoSeccionReal != null &&
                contornoConcretoMm != null &&
                contornoConcretoMm.Count >= 3)
            {
                puntoActual = DesnormalizarEnCaja(
                    barra.PuntoSeccionReal,
                    contornoConcretoMm);
            }

            if (puntoActual == null && barra.Punto != null)
            {
                puntoActual = DesnormalizarEnCaja(
                    barra.Punto,
                    permitido);
            }

            if (puntoActual == null)
                return;

            double distancia;
            AceroVigaPuntoMm puntoNuevaGuia =
                ProyectarPuntoSobreGuiaAlineadaMYG(
                    puntoActual,
                    guia,
                    permitido,
                    out distancia);

            if (puntoNuevaGuia == null)
                return;

            AceroVigaPuntoMm ajustado =
                AjustarPuntoAlContornoPermitido(
                    puntoNuevaGuia,
                    permitido);

            if (ajustado == null)
                return;

            barra.Punto =
                NormalizarEnCaja(
                    ajustado,
                    permitido);

            if (contornoConcretoMm != null &&
                contornoConcretoMm.Count >= 3)
            {
                barra.PuntoSeccionReal =
                    NormalizarEnCaja(
                        ajustado,
                        contornoConcretoMm);
            }

            // La barra deja de ser una coordenada "congelada" y pasa a
            // reconstruirse paramétricamente desde la guía también en Revit.
            barra.UsarPosicionExactaSeccion = false;

            List<AceroVigaPuntoMm> puntosGuia =
                ObtenerPuntosGuiaMm(
                    guia,
                    permitido);

            double parametro;
            double desfaseNormalMm;

            if (TryObtenerReferenciaNormalSobreGuia(
                    ajustado,
                    puntosGuia,
                    permitido,
                    out parametro,
                    out desfaseNormalMm))
            {
                barra.ParametroSobreGuia = parametro;
                barra.DesfaseNormalGuiaMm = desfaseNormalMm;
            }
            else
            {
                barra.ParametroSobreGuia = -1.0;
                barra.DesfaseNormalGuiaMm = 0.0;
            }
        }

        private void MoverGrupoDosPuntosConGuiaMYG(
            AceroVigaGrupoLongitudinal2D grupo,
            AceroVigaGuiaCapaLongitudinal2D guia)
        {
            if (grupo == null || guia == null)
                return;

            RebarBarType tipo =
                grupo.TipoBarra ?? TipoLongitudinalActual;

            List<AceroVigaPuntoMm> permitido =
                ObtenerContornoCentrosLongitudinalMm(tipo);

            if (permitido == null || permitido.Count < 3)
                return;

            AceroVigaPuntoMm inicioActual = null;
            AceroVigaPuntoMm finActual = null;

            if (grupo.PuntoInicioSeccionReal != null &&
                grupo.PuntoFinSeccionReal != null &&
                contornoConcretoMm != null &&
                contornoConcretoMm.Count >= 3)
            {
                inicioActual = DesnormalizarEnCaja(
                    grupo.PuntoInicioSeccionReal,
                    contornoConcretoMm);

                finActual = DesnormalizarEnCaja(
                    grupo.PuntoFinSeccionReal,
                    contornoConcretoMm);
            }

            if (inicioActual == null && grupo.PuntoInicio != null)
            {
                inicioActual = DesnormalizarEnCaja(
                    grupo.PuntoInicio,
                    permitido);
            }

            if (finActual == null && grupo.PuntoFin != null)
            {
                finActual = DesnormalizarEnCaja(
                    grupo.PuntoFin,
                    permitido);
            }

            if (inicioActual == null || finActual == null ||
                Distancia(inicioActual, finActual) <= 1.0)
            {
                return;
            }

            // =========================================================
            // V11.8 MYG - MOVER EL SET COMO CUERPO RÍGIDO
            // =========================================================
            // IMPORTANTE:
            // Antes se proyectaba INICIO y FIN por separado sobre la nueva guía.
            // En los remates laterales de una guía eso podía cambiar ligeramente
            // el ángulo o la longitud de la recta de distribución. Aunque en el
            // editor se siguiera viendo como un conjunto, al ejecutar Revit podía
            // rechazar el ShapeDrivenAccessor y el handler terminaba usando el
            // respaldo Free Form, que aparece en Propiedades como "Individual".
            //
            // Ahora se proyecta SOLO el centro del grupo y se obtiene UN ÚNICO
            // vector de traslación. Ese mismo vector se aplica a los dos extremos,
            // preservando exactamente:
            //   - dirección de distribución;
            //   - longitud del set;
            //   - cantidad;
            //   - regla Número fijo / Espaciado máximo.
            AceroVigaPuntoMm centroActual = new AceroVigaPuntoMm(
                (inicioActual.Y + finActual.Y) * 0.5,
                (inicioActual.Z + finActual.Z) * 0.5);

            double distanciaCentro;
            AceroVigaPuntoMm centroNuevaGuia =
                ProyectarPuntoSobreGuiaAlineadaMYG(
                    centroActual,
                    guia,
                    permitido,
                    out distanciaCentro);

            if (centroNuevaGuia == null)
                return;

            double desplazamientoY =
                centroNuevaGuia.Y - centroActual.Y;
            double desplazamientoZ =
                centroNuevaGuia.Z - centroActual.Z;

            AceroVigaPuntoMm inicioNuevo = new AceroVigaPuntoMm(
                inicioActual.Y + desplazamientoY,
                inicioActual.Z + desplazamientoZ);

            AceroVigaPuntoMm finNuevo = new AceroVigaPuntoMm(
                finActual.Y + desplazamientoY,
                finActual.Z + desplazamientoZ);

            // Si por una sección inclinada uno de los extremos queda apenas fuera
            // del contorno permitido, se corrige mediante OTRO desplazamiento
            // común. Nunca se corrige cada extremo de forma independiente porque
            // eso volvería a deformar el set.
            for (int intento = 0; intento < 4; intento++)
            {
                bool inicioDentro =
                    PuntoDentroPoligono(inicioNuevo, permitido) ||
                    DistanciaPuntoAPoligonoEditor(
                        inicioNuevo,
                        permitido) <= 0.50;

                bool finDentro =
                    PuntoDentroPoligono(finNuevo, permitido) ||
                    DistanciaPuntoAPoligonoEditor(
                        finNuevo,
                        permitido) <= 0.50;

                if (inicioDentro && finDentro)
                    break;

                AceroVigaPuntoMm fuera = !inicioDentro
                    ? inicioNuevo
                    : finNuevo;

                AceroVigaPuntoMm ajustado =
                    AjustarPuntoAlContornoPermitido(
                        fuera,
                        permitido);

                if (ajustado == null)
                    return;

                double correccionY = ajustado.Y - fuera.Y;
                double correccionZ = ajustado.Z - fuera.Z;

                if (Math.Abs(correccionY) <= 1e-9 &&
                    Math.Abs(correccionZ) <= 1e-9)
                {
                    break;
                }

                inicioNuevo = new AceroVigaPuntoMm(
                    inicioNuevo.Y + correccionY,
                    inicioNuevo.Z + correccionZ);

                finNuevo = new AceroVigaPuntoMm(
                    finNuevo.Y + correccionY,
                    finNuevo.Z + correccionZ);
            }

            // Último control: si no puede conservarse la recta completa dentro de
            // la sección, se mantiene la posición anterior antes que deformar el
            // conjunto y convertirlo en barras Individuales al ejecutar.
            bool inicioFinalDentro =
                PuntoDentroPoligono(inicioNuevo, permitido) ||
                DistanciaPuntoAPoligonoEditor(
                    inicioNuevo,
                    permitido) <= 0.50;

            bool finFinalDentro =
                PuntoDentroPoligono(finNuevo, permitido) ||
                DistanciaPuntoAPoligonoEditor(
                    finNuevo,
                    permitido) <= 0.50;

            if (!inicioFinalDentro ||
                !finFinalDentro ||
                Distancia(inicioNuevo, finNuevo) <= 1.0)
            {
                return;
            }

            grupo.PuntoInicio =
                NormalizarEnCaja(
                    inicioNuevo,
                    permitido);

            grupo.PuntoFin =
                NormalizarEnCaja(
                    finNuevo,
                    permitido);

            if (contornoConcretoMm != null &&
                contornoConcretoMm.Count >= 3)
            {
                grupo.PuntoInicioSeccionReal =
                    NormalizarEnCaja(
                        inicioNuevo,
                        contornoConcretoMm);

                grupo.PuntoFinSeccionReal =
                    NormalizarEnCaja(
                        finNuevo,
                        contornoConcretoMm);
            }

            // Sigue siendo un conjunto de dos puntos. No se toca Regla, Cantidad
            // ni EspaciadoCm; únicamente se traslada su línea completa.
            grupo.RespetarTrazoDosPuntos = true;
            grupo.ParametroInicioGuia = 0.0;
            grupo.ParametroFinGuia = 1.0;
        }

        private void SeleccionarGuiaCapa(AceroVigaGuiaCapaLongitudinal2D guia)
        {
            guiaCapaActivaId = guia != null ? guia.Id : string.Empty;
            RefrescarComboGuiasCapas();
            if (guia != null && lblEstado != null)
                lblEstado.Text = "Capa seleccionada: " + guia.Etiqueta +
                    ". Sirve para editar su separación; los aceros colocados/vinculados sobre esta guía acompañarán su nueva posición.";
            if (panelLienzo != null) panelLienzo.Invalidate();
        }

        private AceroVigaPuntoMm AplicarGuiaActivaAPunto(
            AceroVigaPuntoMm punto,
            List<AceroVigaPuntoMm> permitido)
        {
            if (punto == null || permitido == null || permitido.Count < 3)
                return punto;

            AceroVigaGuiaCapaLongitudinal2D guia = ObtenerGuiaCapaActiva();
            if (guia == null)
                return punto;

            List<AceroVigaPuntoMm> puntosGuia =
                ObtenerPuntosGuiaMm(guia, permitido);
            if (puntosGuia.Count < 2)
                return punto;

            double parametro;
            double distancia;
            return ProyectarPuntoSobreCadenaGuia(
                punto,
                puntosGuia,
                out parametro,
                out distancia);
        }

        private void AsignarCapaABarra(
            AceroVigaBarraLongitudinal2D barra,
            AceroVigaGuiaCapaLongitudinal2D guia,
            string grupoId)
        {
            if (barra == null)
                return;

            barra.GrupoDistribucionId = grupoId ?? string.Empty;
            barra.GuiaCapaId = guia != null
                ? guia.Id
                : string.Empty;
            barra.TipoCapa = guia != null
                ? guia.Tipo
                : AceroVigaTipoCapaLongitudinal.SinDefinir;
            barra.NumeroCapa = guia != null
                ? guia.NumeroCapa
                : 0;

            // La guía clasifica el acero, pero no modifica su coordenada.
            barra.ParametroSobreGuia = -1.0;
        }

        private bool TrySeleccionarGuiaCapaCercana(AceroVigaPuntoMm punto)
        {
            if (punto == null || disenoTrabajo.GuiasCapasLongitudinales == null ||
                disenoTrabajo.GuiasCapasLongitudinales.Count == 0)
                return false;

            List<AceroVigaPuntoMm> permitido =
                ObtenerContornoCentrosLongitudinalMm(TipoLongitudinalActual);
            if (permitido == null || permitido.Count < 3)
                return false;

            double tolerancia = ObtenerToleranciaModelo(12F);
            AceroVigaGuiaCapaLongitudinal2D mejor = null;
            double mejorDistancia = double.MaxValue;

            foreach (AceroVigaGuiaCapaLongitudinal2D guia in
                disenoTrabajo.GuiasCapasLongitudinales.Where(x => x != null))
            {
                List<AceroVigaPuntoMm> puntosGuia =
                    ObtenerPuntosGuiaMm(guia, permitido);
                if (puntosGuia.Count < 2)
                    continue;

                double parametro;
                double distancia;
                ProyectarPuntoSobreCadenaGuia(
                    punto,
                    puntosGuia,
                    out parametro,
                    out distancia);
                if (distancia <= tolerancia && distancia < mejorDistancia)
                {
                    mejor = guia;
                    mejorDistancia = distancia;
                }
            }

            if (mejor == null)
                return false;
            SeleccionarGuiaCapa(mejor);
            return true;
        }

        private void DibujarGuiasCapasLongitudinales(Drawing.Graphics g)
        {
            if (g == null || modoEditorActual != AceroVigaModoEditorInicial.Longitudinales ||
                disenoTrabajo.GuiasCapasLongitudinales == null ||
                disenoTrabajo.GuiasCapasLongitudinales.Count == 0)
                return;

            List<AceroVigaPuntoMm> permitido =
                ObtenerContornoCentrosLongitudinalMm(TipoLongitudinalActual);
            if (permitido == null || permitido.Count < 3)
                return;

            using (Drawing.Font fuente = new Drawing.Font(
                "Segoe UI", 7.7F, Drawing.FontStyle.Bold))
            using (Drawing.Font fuenteCota = new Drawing.Font("Segoe UI", 7.2F))
            {
                foreach (AceroVigaGuiaCapaLongitudinal2D guia in
                    disenoTrabajo.GuiasCapasLongitudinales
                        .Where(x => x != null)
                        .OrderBy(x => x.Tipo)
                        .ThenBy(x => x.NumeroCapa))
                {
                    List<AceroVigaPuntoMm> puntosGuia =
                        ObtenerPuntosGuiaMm(guia, permitido);
                    if (puntosGuia.Count < 2)
                        continue;

                    bool activa = guia.Id == guiaCapaActivaId;
                    Drawing.Color color = activa
                        ? Drawing.Color.FromArgb(0, 130, 220)
                        : guia.Tipo == AceroVigaTipoCapaLongitudinal.Superior
                            ? Drawing.Color.FromArgb(55, 125, 205)
                            : guia.Tipo == AceroVigaTipoCapaLongitudinal.Inferior
                                ? Drawing.Color.FromArgb(225, 125, 25)
                                : Drawing.Color.FromArgb(70, 155, 105);

                    using (Drawing.Pen pen = new Drawing.Pen(
                        color,
                        activa ? 2.2F : 1.35F))
                    using (Drawing.SolidBrush brocha = new Drawing.SolidBrush(color))
                    {
                        pen.DashStyle = activa
                            ? Drawing2D.DashStyle.Solid
                            : Drawing2D.DashStyle.Dash;
                        pen.LineJoin = Drawing2D.LineJoin.Round;
                        Drawing.PointF[] pantalla = puntosGuia
                            .Select(ConvertirModeloAPantalla)
                            .ToArray();
                        if (pantalla.Length >= 2)
                            g.DrawLines(pen, pantalla);

                        Drawing.PointF etiqueta = pantalla[0];
                        g.DrawString(
                            guia.Etiqueta,
                            fuente,
                            brocha,
                            etiqueta.X + 4F,
                            etiqueta.Y - 17F);
                    }
                }

                foreach (AceroVigaTipoCapaLongitudinal tipo in new[]
                {
                    AceroVigaTipoCapaLongitudinal.Superior,
                    AceroVigaTipoCapaLongitudinal.Inferior
                })
                {
                    List<AceroVigaGuiaCapaLongitudinal2D> lista =
                        disenoTrabajo.GuiasCapasLongitudinales
                            .Where(x => x != null && x.Tipo == tipo)
                            .OrderBy(x => x.NumeroCapa)
                            .ToList();
                    for (int i = 1; i < lista.Count; i++)
                    {
                        List<AceroVigaPuntoMm> anterior =
                            ObtenerPuntosGuiaMm(lista[i - 1], permitido);
                        List<AceroVigaPuntoMm> actual =
                            ObtenerPuntosGuiaMm(lista[i], permitido);
                        if (anterior.Count < 2 || actual.Count < 2)
                            continue;

                        AceroVigaPuntoMm pModelo1 = PuntoEnCadenaGuia(anterior, 0.88);
                        AceroVigaPuntoMm pModelo2 = PuntoEnCadenaGuia(actual, 0.88);
                        if (pModelo1 == null || pModelo2 == null)
                            continue;

                        Drawing.PointF p1 = ConvertirModeloAPantalla(pModelo1);
                        Drawing.PointF p2 = ConvertirModeloAPantalla(pModelo2);
                        using (Drawing.Pen pen = new Drawing.Pen(
                            Drawing.Color.FromArgb(95, 95, 95), 1F))
                        using (Drawing.SolidBrush brocha = new Drawing.SolidBrush(
                            Drawing.Color.FromArgb(70, 70, 70)))
                        {
                            g.DrawLine(pen, p1, p2);
                            string texto = lista[i].SeparacionLibreCm.ToString("0.#") + " cm";
                            g.DrawString(
                                texto,
                                fuenteCota,
                                brocha,
                                (p1.X + p2.X) * 0.5F + 5F,
                                (p1.Y + p2.Y) * 0.5F - 7F);
                        }
                    }
                }
            }
        }

        private double ObtenerToleranciaClasificacionCapaMm(
            RebarBarType tipoBarra)
        {
            double diametro = ObtenerDiametroMm(tipoBarra);

            // La tolerancia funciona como una franja de reconocimiento alrededor
            // de cada guía. Se limita para no confundir capas cercanas entre sí.
            return Math.Max(
                7.0,
                Math.Min(18.0, diametro * 0.50 + 5.0));
        }

        private double ObtenerDistanciaYTangenteCadenaGuia(
            AceroVigaPuntoMm punto,
            List<AceroVigaPuntoMm> puntosGuia,
            out double tangenteY,
            out double tangenteZ)
        {
            tangenteY = 1.0;
            tangenteZ = 0.0;

            if (punto == null || puntosGuia == null || puntosGuia.Count < 2)
                return double.MaxValue;

            double mejorDistancia = double.MaxValue;

            for (int i = 1; i < puntosGuia.Count; i++)
            {
                AceroVigaPuntoMm a = puntosGuia[i - 1];
                AceroVigaPuntoMm b = puntosGuia[i];
                if (a == null || b == null)
                    continue;

                double dy = b.Y - a.Y;
                double dz = b.Z - a.Z;
                double longitud = Math.Sqrt(dy * dy + dz * dz);
                if (longitud <= Tol)
                    continue;

                AceroVigaPuntoMm proyectado =
                    ProyectarPuntoEnSegmento(punto, a, b);
                double distancia = Distancia(punto, proyectado);

                if (distancia < mejorDistancia)
                {
                    mejorDistancia = distancia;
                    tangenteY = dy / longitud;
                    tangenteZ = dz / longitud;
                }
            }

            return mejorDistancia;
        }

        private AceroVigaGuiaCapaLongitudinal2D
            DetectarGuiaCapaParaPunto(
                AceroVigaPuntoMm punto,
                RebarBarType tipoBarra)
        {
            if (punto == null || disenoTrabajo == null ||
                disenoTrabajo.GuiasCapasLongitudinales == null ||
                disenoTrabajo.GuiasCapasLongitudinales.Count == 0)
            {
                return null;
            }

            List<AceroVigaPuntoMm> permitido =
                ObtenerContornoCentrosLongitudinalMm(tipoBarra);
            if (permitido == null || permitido.Count < 3)
                return null;

            double tolerancia =
                ObtenerToleranciaClasificacionCapaMm(tipoBarra);
            double mejorDistancia = double.MaxValue;
            AceroVigaGuiaCapaLongitudinal2D mejor = null;

            foreach (AceroVigaGuiaCapaLongitudinal2D guia in
                disenoTrabajo.GuiasCapasLongitudinales.Where(x => x != null))
            {
                List<AceroVigaPuntoMm> puntosGuia =
                    ObtenerPuntosGuiaMm(guia, permitido);
                if (puntosGuia == null || puntosGuia.Count < 2)
                    continue;

                double ty;
                double tz;
                double distancia = ObtenerDistanciaYTangenteCadenaGuia(
                    punto,
                    puntosGuia,
                    out ty,
                    out tz);

                if (distancia <= tolerancia && distancia < mejorDistancia)
                {
                    mejorDistancia = distancia;
                    mejor = guia;
                }
            }

            return mejor;
        }

        private AceroVigaGuiaCapaLongitudinal2D
            DetectarGuiaCapaParaSegmento(
                AceroVigaPuntoMm inicio,
                AceroVigaPuntoMm fin,
                RebarBarType tipoBarra,
                out double porcentajeCoincidencia)
        {
            porcentajeCoincidencia = 0.0;

            if (inicio == null || fin == null ||
                disenoTrabajo == null ||
                disenoTrabajo.GuiasCapasLongitudinales == null ||
                disenoTrabajo.GuiasCapasLongitudinales.Count == 0)
            {
                return null;
            }

            double longitud = Distancia(inicio, fin);
            if (longitud <= 1.0)
                return null;

            List<AceroVigaPuntoMm> permitido =
                ObtenerContornoCentrosLongitudinalMm(tipoBarra);
            if (permitido == null || permitido.Count < 3)
                return null;

            double dirY = (fin.Y - inicio.Y) / longitud;
            double dirZ = (fin.Z - inicio.Z) / longitud;
            double tolerancia =
                ObtenerToleranciaClasificacionCapaMm(tipoBarra);

            // Aproximadamente una muestra cada 8 mm. La coincidencia se analiza
            // por longitud, no solo porque el trazo cruce puntualmente una guía.
            int intervalos = Math.Max(
                12,
                Math.Min(160, (int)Math.Ceiling(longitud / 8.0)));

            AceroVigaGuiaCapaLongitudinal2D mejor = null;
            double mejorPuntaje = double.MinValue;
            double mejorPorcentaje = 0.0;
            double cosenoMinimo = Math.Cos(35.0 * Math.PI / 180.0);

            foreach (AceroVigaGuiaCapaLongitudinal2D guia in
                disenoTrabajo.GuiasCapasLongitudinales.Where(x => x != null))
            {
                List<AceroVigaPuntoMm> puntosGuia =
                    ObtenerPuntosGuiaMm(guia, permitido);
                if (puntosGuia == null || puntosGuia.Count < 2)
                    continue;

                int compatibles = 0;
                int consecutivos = 0;
                int maxConsecutivos = 0;
                double sumaDistancias = 0.0;

                for (int i = 0; i <= intervalos; i++)
                {
                    double t = (double)i / intervalos;
                    AceroVigaPuntoMm muestra = new AceroVigaPuntoMm(
                        inicio.Y + (fin.Y - inicio.Y) * t,
                        inicio.Z + (fin.Z - inicio.Z) * t);

                    double tangenteY;
                    double tangenteZ;
                    double distancia = ObtenerDistanciaYTangenteCadenaGuia(
                        muestra,
                        puntosGuia,
                        out tangenteY,
                        out tangenteZ);

                    double paralelismo = Math.Abs(
                        dirY * tangenteY + dirZ * tangenteZ);
                    bool coincide =
                        distancia <= tolerancia &&
                        paralelismo >= cosenoMinimo;

                    if (coincide)
                    {
                        compatibles++;
                        consecutivos++;
                        maxConsecutivos = Math.Max(
                            maxConsecutivos,
                            consecutivos);
                        sumaDistancias += distancia;
                    }
                    else
                    {
                        consecutivos = 0;
                    }
                }

                int totalMuestras = intervalos + 1;
                double porcentaje = totalMuestras <= 0
                    ? 0.0
                    : (double)compatibles / totalMuestras;
                double porcentajeConsecutivo = totalMuestras <= 0
                    ? 0.0
                    : (double)maxConsecutivos / totalMuestras;

                // Una coincidencia parcial válida debe acompañar la dirección de
                // la guía durante un tramo reconocible. Así un cruce perpendicular
                // aislado no clasifica accidentalmente el grupo.
                bool valida =
                    porcentajeConsecutivo >= 0.10 ||
                    (compatibles >= 3 && porcentaje >= 0.08);

                if (!valida)
                    continue;

                double promedioDistancia = compatibles > 0
                    ? sumaDistancias / compatibles
                    : tolerancia;
                double puntaje =
                    porcentaje * 100.0 +
                    porcentajeConsecutivo * 140.0 -
                    promedioDistancia / Math.Max(1.0, tolerancia);

                if (puntaje > mejorPuntaje)
                {
                    mejorPuntaje = puntaje;
                    mejor = guia;
                    mejorPorcentaje = porcentajeConsecutivo;
                }
            }

            porcentajeCoincidencia = mejorPorcentaje;
            return mejor;
        }

        private void AplicarClasificacionCapaAGrupo(
            AceroVigaGrupoLongitudinal2D grupo,
            AceroVigaGuiaCapaLongitudinal2D guia)
        {
            if (grupo == null)
                return;

            grupo.GuiaCapaId = guia != null
                ? guia.Id
                : string.Empty;
            grupo.TipoCapa = guia != null
                ? guia.Tipo
                : AceroVigaTipoCapaLongitudinal.SinDefinir;
            grupo.NumeroCapa = guia != null
                ? guia.NumeroCapa
                : 0;

            // La guía sirve únicamente para clasificar. En un grupo creado
            // con dos puntos, 0..1 representa el sentido de SU LÍNEA exacta, no
            // el recorrido completo ni los remates laterales de la polilínea guía.
            if (grupo.RespetarTrazoDosPuntos)
            {
                grupo.ParametroInicioGuia = 0.0;
                grupo.ParametroFinGuia = 1.0;
            }
            else
            {
                grupo.ParametroInicioGuia = -1.0;
                grupo.ParametroFinGuia = -1.0;
            }
        }

        private void AgregarBarra(AceroVigaPuntoMm punto)
        {
            RebarBarType tipo = TipoLongitudinalActual;
            if (tipo == null)
                return;

            List<AceroVigaPuntoMm> permitido =
                ObtenerContornoCentrosLongitudinalMm(tipo);
            if (permitido == null || permitido.Count < 3)
            {
                WinForms.MessageBox.Show(
                    this,
                    "El recubrimiento y los diámetros no dejan una región útil para longitudinales.",
                    "MYG",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Warning);
                return;
            }

            RegistrarHistorial();

            // La barra puede colocarse en cualquier punto válido. La guía activa
            // del desplegable ya no obliga ni proyecta la posición.
            AceroVigaPuntoMm ajustado =
                AjustarPuntoAlContornoPermitido(punto, permitido);
            AceroVigaGuiaCapaLongitudinal2D guiaDetectada =
                DetectarGuiaCapaParaPunto(ajustado, tipo);

            AceroVigaBarraLongitudinal2D barra =
                new AceroVigaBarraLongitudinal2D
                {
                    TipoBarra = tipo,
                    DiametroMm = ObtenerDiametroMm(tipo),
                    Punto = NormalizarEnCaja(ajustado, permitido)
                };

            AsignarCapaABarra(
                barra,
                guiaDetectada,
                string.Empty);
            disenoTrabajo.Longitudinales.Add(barra);
            RecalcularOmisionesExtremosGruposLongitudinales();
            idSeleccionado = barra.Id;
            indiceVerticeSeleccionado = -1;
            ActualizarResumen();
            panelLienzo.Invalidate();
        }


        private AceroVigaPuntoMm ResolverPuntoDistribucionLongitudinal(
            AceroVigaPuntoMm punto,
            out AceroVigaGuiaCapaLongitudinal2D guia,
            out List<AceroVigaPuntoMm> puntosGuia,
            out List<AceroVigaPuntoMm> contornoPermitido,
            out double parametro)
        {
            parametro = -1.0;
            guia = null;
            puntosGuia = new List<AceroVigaPuntoMm>();
            contornoPermitido =
                ObtenerContornoCentrosLongitudinalMm(TipoLongitudinalActual);

            if (punto == null ||
                contornoPermitido == null ||
                contornoPermitido.Count < 3)
            {
                return null;
            }

            // DISTRIBUIR 2 PUNTOS es completamente libre dentro de la región útil.
            // Las guías se analizan después para asignar únicamente la capa semántica.
            return AjustarPuntoAlContornoPermitido(
                punto,
                contornoPermitido);
        }

        private void IniciarDistribucionLongitudinalConArrastre(
            AceroVigaPuntoMm punto)
        {
            if (TipoLongitudinalActual == null || punto == null)
                return;

            AceroVigaGuiaCapaLongitudinal2D guia;
            List<AceroVigaPuntoMm> puntosGuia;
            List<AceroVigaPuntoMm> permitido;
            double parametro;
            AceroVigaPuntoMm ajustado =
                ResolverPuntoDistribucionLongitudinal(
                    punto,
                    out guia,
                    out puntosGuia,
                    out permitido,
                    out parametro);

            if (ajustado == null)
                return;

            // Captura intuitiva de la capa Superior/Inferior.
            AceroVigaPuntoMm alineadoInicio;
            AceroVigaGuiaCapaLongitudinal2D guiaInicio;

            if (TryAlinearPuntoAGuiaLongitudinalMYG(
                    ajustado,
                    TipoLongitudinalActual,
                    null,
                    true,
                    out alineadoInicio,
                    out guiaInicio))
            {
                ajustado = alineadoInicio;
                idGuiaDistribucionArrastreMYG =
                    guiaInicio != null
                        ? guiaInicio.Id
                        : string.Empty;
            }
            else
            {
                idGuiaDistribucionArrastreMYG =
                    string.Empty;
            }

            creandoDistribucionLongitudinalConArrastre = true;
            puntoInicioDistribucionArrastre = ajustado.Copiar();
            puntoFinDistribucionArrastre = ajustado.Copiar();
            parametroInicioDistribucionArrastre = parametro;
            parametroFinDistribucionArrastre = parametro;
            primerPuntoDistribucion = ajustado.Copiar();

            if (panelLienzo != null)
            {
                panelLienzo.Capture = true;
                panelLienzo.Cursor = WinForms.Cursors.Cross;
                panelLienzo.Invalidate();
            }

            if (lblEstado != null)
            {
                lblEstado.Text =
                    "Mantenga el clic y arrastre. Si inicia cerca de una capa " +
                    "Superior/Inferior, el segundo extremo permanecerá alineado con ella.";
            }

            ActualizarEstadoHerramienta();
        }

        private void ActualizarDistribucionLongitudinalConArrastre(
            AceroVigaPuntoMm punto)
        {
            if (!creandoDistribucionLongitudinalConArrastre ||
                puntoInicioDistribucionArrastre == null ||
                punto == null)
            {
                return;
            }

            AceroVigaGuiaCapaLongitudinal2D guia;
            List<AceroVigaPuntoMm> puntosGuia;
            List<AceroVigaPuntoMm> permitido;
            double parametro;
            AceroVigaPuntoMm ajustado =
                ResolverPuntoDistribucionLongitudinal(
                    punto,
                    out guia,
                    out puntosGuia,
                    out permitido,
                    out parametro);

            if (ajustado == null)
                return;

            AceroVigaGuiaCapaLongitudinal2D
                guiaBloqueada = null;

            if (!string.IsNullOrWhiteSpace(
                    idGuiaDistribucionArrastreMYG) &&
                disenoTrabajo.GuiasCapasLongitudinales != null)
            {
                guiaBloqueada =
                    disenoTrabajo.GuiasCapasLongitudinales
                        .FirstOrDefault(x =>
                            x != null &&
                            string.Equals(
                                x.Id,
                                idGuiaDistribucionArrastreMYG,
                                StringComparison.Ordinal));
            }

            AceroVigaPuntoMm alineadoFin;
            AceroVigaGuiaCapaLongitudinal2D guiaFin;

            if (TryAlinearPuntoAGuiaLongitudinalMYG(
                    ajustado,
                    TipoLongitudinalActual,
                    guiaBloqueada,
                    guiaBloqueada == null,
                    out alineadoFin,
                    out guiaFin))
            {
                ajustado = alineadoFin;

                if (guiaFin != null)
                {
                    idGuiaDistribucionArrastreMYG =
                        guiaFin.Id;
                }
            }

            puntoFinDistribucionArrastre =
                ajustado.Copiar();
            parametroFinDistribucionArrastre =
                parametro;
        }

        private void CancelarDistribucionLongitudinalConArrastre(
            bool refrescar)
        {
            creandoDistribucionLongitudinalConArrastre = false;
            puntoInicioDistribucionArrastre = null;
            puntoFinDistribucionArrastre = null;
            parametroInicioDistribucionArrastre = -1.0;
            parametroFinDistribucionArrastre = -1.0;
            idGuiaDistribucionArrastreMYG = string.Empty;
            primerPuntoDistribucion = null;

            if (panelLienzo != null)
            {
                panelLienzo.Capture = false;
                panelLienzo.Cursor = WinForms.Cursors.Cross;
                if (refrescar)
                    panelLienzo.Invalidate();
            }

            if (refrescar)
                ActualizarEstadoHerramienta();
        }

        private double ObtenerLongitudSeleccionDistribucionMm(
            AceroVigaGuiaCapaLongitudinal2D guia,
            List<AceroVigaPuntoMm> puntosGuia)
        {
            if (guia != null &&
                puntosGuia != null &&
                puntosGuia.Count >= 2 &&
                parametroInicioDistribucionArrastre >= 0.0 &&
                parametroFinDistribucionArrastre >= 0.0)
            {
                return Math.Abs(
                    parametroFinDistribucionArrastre -
                    parametroInicioDistribucionArrastre) *
                    LongitudCadenaGuia(puntosGuia);
            }

            return puntoInicioDistribucionArrastre != null &&
                puntoFinDistribucionArrastre != null
                    ? Distancia(
                        puntoInicioDistribucionArrastre,
                        puntoFinDistribucionArrastre)
                    : 0.0;
        }

        private void FinalizarDistribucionLongitudinalConArrastre(
            Drawing.Point ubicacionFinal)
        {
            if (!creandoDistribucionLongitudinalConArrastre)
                return;

            AceroVigaPuntoMm crudo =
                ConvertirPantallaAModelo(ubicacionFinal);
            AceroVigaPuntoMm final =
                AplicarSnap(crudo) ?? crudo;
            ActualizarDistribucionLongitudinalConArrastre(final);

            List<AceroVigaPuntoMm> permitido =
                ObtenerContornoCentrosLongitudinalMm(
                    TipoLongitudinalActual);

            double porcentajeCoincidenciaCapa = 0.0;
            AceroVigaGuiaCapaLongitudinal2D guia = null;

            if (!string.IsNullOrWhiteSpace(
                    idGuiaDistribucionArrastreMYG) &&
                disenoTrabajo.GuiasCapasLongitudinales != null)
            {
                guia =
                    disenoTrabajo.GuiasCapasLongitudinales
                        .FirstOrDefault(x =>
                            x != null &&
                            string.Equals(
                                x.Id,
                                idGuiaDistribucionArrastreMYG,
                                StringComparison.Ordinal));
            }

            if (guia == null)
            {
                guia =
                    DetectarGuiaCapaParaSegmento(
                        puntoInicioDistribucionArrastre,
                        puntoFinDistribucionArrastre,
                        TipoLongitudinalActual,
                        out porcentajeCoincidenciaCapa);
            }

            List<AceroVigaPuntoMm> puntosGuia =
                guia != null && permitido != null
                    ? ObtenerPuntosGuiaMm(guia, permitido)
                    : new List<AceroVigaPuntoMm>();

            // V11.1: la guía solamente clasifica la capa. La geometría del grupo
            // respeta exactamente la línea recta definida por el primer y segundo punto.
            // Nunca se sustituye por la polilínea completa de la guía, porque sus remates
            // laterales pueden introducir quiebres y desordenar la última barra.
            AceroVigaPuntoMm inicioGrupo =
                puntoInicioDistribucionArrastre != null
                    ? puntoInicioDistribucionArrastre.Copiar()
                    : null;
            AceroVigaPuntoMm finGrupo =
                puntoFinDistribucionArrastre != null
                    ? puntoFinDistribucionArrastre.Copiar()
                    : null;

            // Se guardan parámetros únicamente como referencia de clasificación. La
            // reconstrucción gráfica y la ejecución usan siempre inicioGrupo-finGrupo.
            double parametroInicioGrupo = 0.0;
            double parametroFinGrupo = 1.0;

            double longitudMm =
                inicioGrupo != null && finGrupo != null
                    ? Distancia(inicioGrupo, finGrupo)
                    : 0.0;

            if (longitudMm <= 1.0)
            {
                CancelarDistribucionLongitudinalConArrastre(true);
                if (lblEstado != null)
                    lblEstado.Text =
                        "El tramo de distribución debe tener una longitud mayor que 1 mm.";
                return;
            }

            // La creación inicial SIEMPRE toma directamente el diámetro activo y el
            // número indicado en la ventana. No se abre ningún diálogo en esta etapa.
            int cantidad = nudCantidadDistribucion != null
                ? Math.Max(1, (int)nudCantidadDistribucion.Value)
                : 4;

            double longitudCm = longitudMm / 10.0;
            double espaciadoRealCm = cantidad <= 1
                ? 0.0
                : longitudCm / (cantidad - 1);

            ultimaReglaDistribucion =
                AceroVigaReglaGrupoLongitudinal.NumeroFijo;
            ultimoEspaciadoDistribucionCm =
                Math.Max(0.10, espaciadoRealCm);

            RegistrarHistorial();

            AceroVigaGrupoLongitudinal2D grupo =
                new AceroVigaGrupoLongitudinal2D
                {
                    TipoBarra = TipoLongitudinalActual,
                    DiametroMm = ObtenerDiametroMm(
                        TipoLongitudinalActual),
                    GuiaCapaId = guia != null
                        ? guia.Id
                        : string.Empty,
                    TipoCapa = guia != null
                        ? guia.Tipo
                        : AceroVigaTipoCapaLongitudinal.SinDefinir,
                    NumeroCapa = guia != null
                        ? guia.NumeroCapa
                        : 0,
                    Regla = AceroVigaReglaGrupoLongitudinal.NumeroFijo,
                    EspaciadoCm = espaciadoRealCm,
                    Cantidad = cantidad,
                    // La capa es semántica. El recorrido geométrico es siempre la línea
                    // exacta indicada por los dos clics/arrastre del usuario.
                    ParametroInicioGuia = parametroInicioGrupo,
                    ParametroFinGuia = parametroFinGrupo,
                    RespetarTrazoDosPuntos = true,
                    PuntoInicio = permitido != null && inicioGrupo != null
                        ? NormalizarEnCaja(
                            inicioGrupo,
                            permitido)
                        : new AceroVigaPuntoNormalizado(0.0, 0.5),
                    PuntoFin = permitido != null && finGrupo != null
                        ? NormalizarEnCaja(
                            finGrupo,
                            permitido)
                        : new AceroVigaPuntoNormalizado(1.0, 0.5),
                    PuntoInicioSeccionReal =
                        contornoConcretoMm != null &&
                        contornoConcretoMm.Count >= 3 &&
                        inicioGrupo != null
                            ? NormalizarEnCaja(inicioGrupo, contornoConcretoMm)
                            : null,
                    PuntoFinSeccionReal =
                        contornoConcretoMm != null &&
                        contornoConcretoMm.Count >= 3 &&
                        finGrupo != null
                            ? NormalizarEnCaja(finGrupo, contornoConcretoMm)
                            : null
                };

            if (disenoTrabajo.GruposLongitudinales == null)
            {
                disenoTrabajo.GruposLongitudinales =
                    new List<AceroVigaGrupoLongitudinal2D>();
            }

            disenoTrabajo.GruposLongitudinales.Add(grupo);
            ReconstruirBarrasGrupoLongitudinal(
                grupo,
                guia,
                puntosGuia,
                permitido);
            SeleccionarGrupoLongitudinalCompleto(grupo.Id);

            CancelarDistribucionLongitudinalConArrastre(false);
            ActualizarEstadoHerramienta();
            ActualizarResumen();
            PublicarCambiosIncrustados();

            if (panelLienzo != null)
                panelLienzo.Invalidate();

            if (lblEstado != null)
            {
                string textoCapa = guia != null
                    ? " Capa detectada: " + guia.Etiqueta +
                        "; se conserva exactamente el trazo de dos puntos."
                    : " Sin clasificación de capa.";

                lblEstado.Text =
                    "Grupo creado con NÚMERO FIJO: " +
                    cantidad + " barras de " +
                    (TipoLongitudinalActual != null
                        ? TipoLongitudinalActual.Name
                        : "tipo actual") + "." +
                    textoCapa +
                    " Doble clic sobre una barra del grupo para modificar la regla.";
            }
        }

        private List<double> ObtenerParametrosGrupoLongitudinal(
            AceroVigaGrupoLongitudinal2D grupo,
            List<AceroVigaPuntoMm> puntosGuia)
        {
            List<double> resultado = new List<double>();
            if (grupo == null)
                return resultado;

            int cantidad = Math.Max(1, grupo.Cantidad);
            double inicio = grupo.ParametroInicioGuia;
            double fin = grupo.ParametroFinGuia;

            // Tanto NÚMERO FIJO como ESPACIADO MÁXIMO ocupan el tramo completo.
            // La diferencia es cómo se determina la cantidad, no la posición final.
            for (int i = 0; i < cantidad; i++)
            {
                double t = cantidad <= 1
                    ? 0.0
                    : (double)i / (cantidad - 1);

                if (grupo.RespetarTrazoDosPuntos)
                {
                    resultado.Add(t);
                }
                else if (puntosGuia != null &&
                         puntosGuia.Count >= 2 &&
                         inicio >= 0.0 &&
                         fin >= 0.0)
                {
                    resultado.Add(
                        inicio + (fin - inicio) * t);
                }
                else
                {
                    resultado.Add(t);
                }
            }

            return resultado;
        }

        private bool TryObtenerLineaExactaGrupoLongitudinal(
            AceroVigaGrupoLongitudinal2D grupo,
            List<AceroVigaPuntoMm> permitido,
            out AceroVigaPuntoMm inicio,
            out AceroVigaPuntoMm fin)
        {
            inicio = null;
            fin = null;

            if (grupo == null || !grupo.RespetarTrazoDosPuntos)
                return false;

            if (grupo.PuntoInicioSeccionReal != null &&
                grupo.PuntoFinSeccionReal != null &&
                contornoConcretoMm != null &&
                contornoConcretoMm.Count >= 3)
            {
                inicio = DesnormalizarEnCaja(
                    grupo.PuntoInicioSeccionReal,
                    contornoConcretoMm);
                fin = DesnormalizarEnCaja(
                    grupo.PuntoFinSeccionReal,
                    contornoConcretoMm);
            }
            else if (grupo.PuntoInicio != null &&
                     grupo.PuntoFin != null &&
                     permitido != null &&
                     permitido.Count >= 3)
            {
                inicio = DesnormalizarEnCaja(grupo.PuntoInicio, permitido);
                fin = DesnormalizarEnCaja(grupo.PuntoFin, permitido);
            }

            return inicio != null && fin != null &&
                Distancia(inicio, fin) > 1.0;
        }

        private void ReconstruirBarrasGrupoLongitudinal(
            AceroVigaGrupoLongitudinal2D grupo,
            AceroVigaGuiaCapaLongitudinal2D guia,
            List<AceroVigaPuntoMm> puntosGuia,
            List<AceroVigaPuntoMm> permitido)
        {
            if (grupo == null ||
                disenoTrabajo == null ||
                disenoTrabajo.Longitudinales == null ||
                permitido == null ||
                permitido.Count < 3)
            {
                return;
            }

            disenoTrabajo.Longitudinales.RemoveAll(x =>
                x != null &&
                string.Equals(
                    x.GrupoDistribucionId,
                    grupo.Id,
                    StringComparison.Ordinal));

            List<double> parametros =
                ObtenerParametrosGrupoLongitudinal(
                    grupo,
                    puntosGuia);

            AceroVigaPuntoMm inicioRespaldo;
            AceroVigaPuntoMm finRespaldo;
            bool usarTrazoExacto = TryObtenerLineaExactaGrupoLongitudinal(
                grupo,
                permitido,
                out inicioRespaldo,
                out finRespaldo);

            if (!usarTrazoExacto)
            {
                inicioRespaldo = grupo.PuntoInicio != null
                    ? DesnormalizarEnCaja(grupo.PuntoInicio, permitido)
                    : puntoInicioDistribucionArrastre;
                finRespaldo = grupo.PuntoFin != null
                    ? DesnormalizarEnCaja(grupo.PuntoFin, permitido)
                    : puntoFinDistribucionArrastre;
            }

            AceroVigaBarraLongitudinal2D primera = null;

            List<AceroVigaPuntoMm> posicionesCreadasMYG =
                new List<AceroVigaPuntoMm>();

            for (int i = 0; i < parametros.Count; i++)
            {
                AceroVigaPuntoMm punto;
                double parametroGuia = -1.0;

                if (usarTrazoExacto)
                {
                    double t = parametros[i];
                    punto = new AceroVigaPuntoMm(
                        inicioRespaldo.Y +
                            (finRespaldo.Y - inicioRespaldo.Y) * t,
                        inicioRespaldo.Z +
                            (finRespaldo.Z - inicioRespaldo.Z) * t);

                    // La clasificación se conserva sin deformar la línea.
                    parametroGuia = t;
                }
                else if (guia != null &&
                         puntosGuia != null &&
                         puntosGuia.Count >= 2 &&
                         grupo.ParametroInicioGuia >= 0.0 &&
                         grupo.ParametroFinGuia >= 0.0)
                {
                    parametroGuia = parametros[i];
                    punto = PuntoDistribucionEnGuia(
                        puntosGuia,
                        parametroGuia);
                }
                else
                {
                    double t = parametros[i];
                    punto = new AceroVigaPuntoMm(
                        inicioRespaldo.Y +
                            (finRespaldo.Y - inicioRespaldo.Y) * t,
                        inicioRespaldo.Z +
                            (finRespaldo.Z - inicioRespaldo.Z) * t);
                    punto = AjustarPuntoAlContornoPermitido(
                        punto,
                        permitido);
                }

                if (punto == null)
                    continue;

                AceroVigaBarraLongitudinal2D barra =
                    new AceroVigaBarraLongitudinal2D
                    {
                        TipoBarra = grupo.TipoBarra ??
                            TipoLongitudinalActual,
                        DiametroMm = grupo.DiametroMm > 0.0
                            ? grupo.DiametroMm
                            : ObtenerDiametroMm(
                                grupo.TipoBarra ??
                                TipoLongitudinalActual),
                        Punto = NormalizarEnCaja(
                            punto,
                            permitido),
                        PuntoSeccionReal = contornoConcretoMm != null &&
                            contornoConcretoMm.Count >= 3
                                ? NormalizarEnCaja(
                                    punto,
                                    contornoConcretoMm)
                                : null,
                        GrupoDistribucionId = grupo.Id,
                        GuiaCapaId = grupo.GuiaCapaId ??
                            string.Empty,
                        TipoCapa = grupo.TipoCapa,
                        NumeroCapa = grupo.NumeroCapa,
                        ParametroSobreGuia = parametroGuia,
                        DesfaseNormalGuiaMm = 0.0,
                        UsarPosicionExactaSeccion = usarTrazoExacto,
                        OcultaPorSuperposicion = false
                    };

                disenoTrabajo.Longitudinales.Add(barra);
                posicionesCreadasMYG.Add(
                    punto.Copiar());

                if (primera == null)
                    primera = barra;
            }

            // NÚMERO FIJO:
            // la cantidad permanece fija y EspaciadoCm representa la
            // separación centro-centro realmente construida.
            if (grupo.Regla ==
                    AceroVigaReglaGrupoLongitudinal.NumeroFijo &&
                posicionesCreadasMYG.Count >= 2)
            {
                grupo.EspaciadoCm =
                    Distancia(
                        posicionesCreadasMYG[0],
                        posicionesCreadasMYG[1]) / 10.0;
            }

            RecalcularOmisionesExtremosGruposLongitudinales();

            if (primera != null &&
                (idsGruposLongitudinalesSeleccionados.Contains(grupo.Id) ||
                 (idsGruposLongitudinalesSeleccionados.Count == 0 &&
                  idsBarrasLongitudinalesSeleccionadas.Count == 0 &&
                  string.IsNullOrWhiteSpace(idSeleccionado))))
            {
                idSeleccionado = primera.Id;
                indiceVerticeSeleccionado = -1;
            }
        }

        private void SincronizarGruposVinculadosAGuias()
        {
            if (disenoTrabajo == null ||
                disenoTrabajo.GruposLongitudinales == null ||
                disenoTrabajo.GruposLongitudinales.Count == 0 ||
                disenoTrabajo.GuiasCapasLongitudinales == null)
            {
                return;
            }

            foreach (AceroVigaGrupoLongitudinal2D grupo in
                disenoTrabajo.GruposLongitudinales.Where(x => x != null))
            {
                if (string.IsNullOrWhiteSpace(grupo.GuiaCapaId) ||
                    grupo.ParametroInicioGuia < 0.0 ||
                    grupo.ParametroFinGuia < 0.0)
                {
                    continue;
                }

                AceroVigaGuiaCapaLongitudinal2D guia =
                    disenoTrabajo.GuiasCapasLongitudinales.FirstOrDefault(x =>
                        x != null && string.Equals(
                            x.Id,
                            grupo.GuiaCapaId,
                            StringComparison.Ordinal));
                if (guia == null)
                    continue;

                RebarBarType tipo = grupo.TipoBarra ?? TipoLongitudinalActual;
                List<AceroVigaPuntoMm> permitido =
                    ObtenerContornoCentrosLongitudinalMm(tipo);
                if (permitido == null || permitido.Count < 3)
                    continue;

                List<AceroVigaPuntoMm> puntosGuia =
                    ObtenerPuntosGuiaMm(guia, permitido);
                if (puntosGuia == null || puntosGuia.Count < 2)
                    continue;

                if (!grupo.RespetarTrazoDosPuntos)
                {
                    AceroVigaPuntoMm inicio = PuntoDistribucionEnGuia(
                        puntosGuia,
                        grupo.ParametroInicioGuia);
                    AceroVigaPuntoMm fin = PuntoDistribucionEnGuia(
                        puntosGuia,
                        grupo.ParametroFinGuia);

                    if (inicio != null && fin != null)
                    {
                        grupo.PuntoInicio = NormalizarEnCaja(inicio, permitido);
                        grupo.PuntoFin = NormalizarEnCaja(fin, permitido);
                    }
                }

                ReconstruirBarrasGrupoLongitudinal(
                    grupo,
                    guia,
                    puntosGuia,
                    permitido);
            }
        }

        private void ReconstruirTodosLosGruposLongitudinales()
        {
            if (disenoTrabajo == null ||
                disenoTrabajo.GruposLongitudinales == null ||
                disenoTrabajo.GruposLongitudinales.Count == 0)
            {
                return;
            }

            List<AceroVigaGrupoLongitudinal2D> grupos =
                disenoTrabajo.GruposLongitudinales
                    .Where(x => x != null)
                    .Select(x => x.Copiar())
                    .ToList();

            foreach (AceroVigaGrupoLongitudinal2D grupo in grupos)
            {
                RebarBarType tipo = grupo.TipoBarra ?? TipoLongitudinalActual;
                List<AceroVigaPuntoMm> permitido =
                    ObtenerContornoCentrosLongitudinalMm(tipo);
                if (permitido == null || permitido.Count < 3)
                    continue;

                AceroVigaGuiaCapaLongitudinal2D guia =
                    disenoTrabajo.GuiasCapasLongitudinales != null
                        ? disenoTrabajo.GuiasCapasLongitudinales.FirstOrDefault(x =>
                            x != null && string.Equals(
                                x.Id,
                                grupo.GuiaCapaId,
                                StringComparison.Ordinal))
                        : null;
                List<AceroVigaPuntoMm> puntosGuia = guia != null
                    ? ObtenerPuntosGuiaMm(guia, permitido)
                    : new List<AceroVigaPuntoMm>();

                ReconstruirBarrasGrupoLongitudinal(
                    grupo,
                    guia,
                    puntosGuia,
                    permitido);
            }

            RecalcularOmisionesExtremosGruposLongitudinales();
        }

        private void ProcesarDistribucion(AceroVigaPuntoMm punto)
        {
            // Compatibilidad con llamadas de versiones anteriores.
            // La interacción actual se realiza por MouseDown/MouseMove/MouseUp.
            if (!creandoDistribucionLongitudinalConArrastre)
                IniciarDistribucionLongitudinalConArrastre(punto);
            else
                ActualizarDistribucionLongitudinalConArrastre(punto);
        }


        private void AgregarEstriboPerimetral()
        {
            RebarBarType tipo = TipoEstriboActual;
            if (tipo == null)
                return;

            List<AceroVigaPuntoMm> contorno = ObtenerContornoEjeEstriboMm(tipo);
            if (contorno == null || contorno.Count < 3)
            {
                WinForms.MessageBox.Show(
                    this,
                    "El recubrimiento no deja una sección útil para el estribo.",
                    "MYG",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Warning);
                return;
            }

            RegistrarHistorial();
            AceroVigaEstribo2D estribo = new AceroVigaEstribo2D
            {
                Tipo = AceroVigaTipoEstribo2D.AdaptadoContorno,
                TipoBarra = tipo,
                DiametroMm = ObtenerDiametroMm(tipo),
                Cerrado = true,
                UsarContornoOffsetAutomatico = true,
                IndiceEsquinaGancho = ObtenerIndiceEsquinaSuperiorDerecha(contorno)
            };
            disenoTrabajo.Estribos.Add(estribo);
            SeleccionarSoloEstribo(estribo.Id, -1);
            ActualizarResumen();
            panelLienzo.Invalidate();
        }

        private void FinalizarCroquis()
        {
            LimpiarEstadoArrastreEstribo();

            bool cerrado = herramienta == AceroVigaHerramientaEditor.EstriboLibreCerrado;
            int minimo = cerrado ? 3 : 2;

            if (puntosCroquisActual.Count < minimo)
            {
                CancelarCroquis();
                return;
            }

            RebarBarType tipo = TipoEstriboActual;
            if (tipo == null)
            {
                CancelarCroquis();
                return;
            }

            List<AceroVigaPuntoMm> contorno = ObtenerContornoEjeEstriboMm(tipo);
            if (contorno == null || contorno.Count < 3)
            {
                CancelarCroquis();
                return;
            }

            RegistrarHistorial();
            AceroVigaEstribo2D estribo = new AceroVigaEstribo2D
            {
                Tipo = cerrado
                    ? AceroVigaTipoEstribo2D.Croquis
                    : AceroVigaTipoEstribo2D.HorizontalAlma,
                TipoBarra = tipo,
                DiametroMm = ObtenerDiametroMm(tipo),
                Cerrado = cerrado,
                UsarContornoOffsetAutomatico = false,
                IndiceEsquinaGancho = cerrado
                    ? ObtenerIndiceEsquinaSuperiorDerecha(puntosCroquisActual)
                    : -1
            };

            foreach (AceroVigaPuntoMm punto in puntosCroquisActual)
                estribo.Puntos.Add(NormalizarEnCaja(punto, contorno));

            disenoTrabajo.Estribos.Add(estribo);
            SeleccionarSoloEstribo(estribo.Id, -1);
            puntosCroquisActual.Clear();
            ActualizarResumen();
            ActualizarEstadoHerramienta();
            panelLienzo.Invalidate();
        }

        #region SELECCIÓN MÚLTIPLE Y POR REGIÓN DE ESTRIBOS

        private bool EstaControlSeleccionPresionado()
        {
            return (WinForms.Control.ModifierKeys & WinForms.Keys.Control) ==
                WinForms.Keys.Control;
        }

        private bool EsEstriboSeleccionado(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                return false;

            return idsEstribosSeleccionados.Contains(id) ||
                   id == idSeleccionado;
        }

        private void LimpiarSeleccionEstribos(bool notificar)
        {
            idsEstribosSeleccionados.Clear();
            idsGruposLongitudinalesSeleccionados.Clear();
            idsBarrasLongitudinalesSeleccionadas.Clear();
            idSeleccionado = string.Empty;
            indiceVerticeSeleccionado = -1;

            if (notificar)
                NotificarEstadoSeleccionTipoCambiado();
        }

        private void SeleccionarSoloEstribo(
            string id,
            int indiceVertice)
        {
            idsEstribosSeleccionados.Clear();
            idsGruposLongitudinalesSeleccionados.Clear();
            idsBarrasLongitudinalesSeleccionadas.Clear();

            if (string.IsNullOrWhiteSpace(id))
            {
                idSeleccionado = string.Empty;
                indiceVerticeSeleccionado = -1;
                NotificarEstadoSeleccionTipoCambiado();
                return;
            }

            idsEstribosSeleccionados.Add(id);
            idSeleccionado = id;
            indiceVerticeSeleccionado = indiceVertice;
            NotificarEstadoSeleccionTipoCambiado();
        }

        private void AlternarSeleccionEstribo(
            string id,
            int indiceVertice)
        {
            if (string.IsNullOrWhiteSpace(id))
                return;

            idsGruposLongitudinalesSeleccionados.Clear();
            idsBarrasLongitudinalesSeleccionadas.Clear();

            if (idsEstribosSeleccionados.Contains(id))
            {
                idsEstribosSeleccionados.Remove(id);

                if (idSeleccionado == id)
                {
                    idSeleccionado = idsEstribosSeleccionados.FirstOrDefault() ??
                        string.Empty;
                    indiceVerticeSeleccionado = -1;
                }
            }
            else
            {
                idsEstribosSeleccionados.Add(id);
                idSeleccionado = id;
                indiceVerticeSeleccionado = indiceVertice;
            }

            NotificarEstadoSeleccionTipoCambiado();
        }

        private bool TryDetectarEstriboEnPunto(
            AceroVigaPuntoMm punto,
            out string id,
            out int indiceVertice)
        {
            id = string.Empty;
            indiceVertice = -1;

            if (punto == null ||
                disenoTrabajo == null ||
                disenoTrabajo.Estribos == null)
            {
                return false;
            }

            double tolerancia = ObtenerToleranciaModelo(12.0F);
            double mejor = double.MaxValue;

            foreach (AceroVigaEstribo2D estribo in disenoTrabajo.Estribos)
            {
                if (estribo == null || string.IsNullOrWhiteSpace(estribo.Id))
                    continue;

                List<AceroVigaPuntoMm> puntos = ObtenerPuntosEstriboMm(estribo);
                if (puntos == null || puntos.Count == 0)
                    continue;

                for (int i = 0; i < puntos.Count; i++)
                {
                    double distancia = Distancia(punto, puntos[i]);
                    if (distancia <= tolerancia && distancia < mejor)
                    {
                        mejor = distancia;
                        id = estribo.Id;
                        indiceVertice = estribo.UsarContornoOffsetAutomatico
                            ? -1
                            : i;
                    }
                }

                int segmentos = estribo.Cerrado
                    ? puntos.Count
                    : Math.Max(0, puntos.Count - 1);

                for (int i = 0; i < segmentos; i++)
                {
                    AceroVigaPuntoMm a = puntos[i];
                    AceroVigaPuntoMm b = puntos[(i + 1) % puntos.Count];
                    double distancia = DistanciaPuntoSegmento(punto, a, b);

                    if (distancia <= tolerancia && distancia < mejor)
                    {
                        mejor = distancia;
                        id = estribo.Id;
                        indiceVertice = -1;
                    }
                }
            }

            return !string.IsNullOrWhiteSpace(id);
        }

        private void IniciarSeleccionRegionEstribos(
            Drawing.Point ubicacion,
            bool agregar)
        {
            seleccionandoRegionEstribos = true;
            inicioSeleccionRegionEstribos = ubicacion;
            finSeleccionRegionEstribos = ubicacion;
            agregarSeleccionRegionEstribos = agregar;

            puntoSnapActual = null;
            textoSnapActual = string.Empty;

            if (panelLienzo != null)
            {
                panelLienzo.Capture = true;
                panelLienzo.Cursor = WinForms.Cursors.Cross;
                panelLienzo.Invalidate();
            }

            if (lblEstado != null)
            {
                lblEstado.Text =
                    "Arrastre IZQ→DER: VENTANA, solo recorridos completamente " +
                    "dentro. DER→IZQ: CRUCE, recorridos tocados o cruzados. " +
                    "Ctrl agrega o retira con clic.";
            }
        }

        private Drawing.RectangleF ObtenerRectanguloSeleccionPantalla(
            Drawing.Point inicio,
            Drawing.Point fin)
        {
            float x = Math.Min(inicio.X, fin.X);
            float y = Math.Min(inicio.Y, fin.Y);
            float ancho = Math.Abs(fin.X - inicio.X);
            float alto = Math.Abs(fin.Y - inicio.Y);
            return new Drawing.RectangleF(x, y, ancho, alto);
        }

        private bool EsArrastreRealSeleccion(
            Drawing.Point inicio,
            Drawing.Point fin)
        {
            return Math.Abs(fin.X - inicio.X) >= 4 ||
                   Math.Abs(fin.Y - inicio.Y) >= 4;
        }

        private bool PuntoDentroRectanguloPantalla(
            Drawing.RectangleF rectangulo,
            Drawing.PointF punto,
            float margen)
        {
            return punto.X >= rectangulo.Left + margen &&
                   punto.X <= rectangulo.Right - margen &&
                   punto.Y >= rectangulo.Top + margen &&
                   punto.Y <= rectangulo.Bottom - margen;
        }

        private double OrientacionPantalla(
            Drawing.PointF a,
            Drawing.PointF b,
            Drawing.PointF c)
        {
            return (b.X - a.X) * (c.Y - a.Y) -
                   (b.Y - a.Y) * (c.X - a.X);
        }

        private bool PuntoSobreSegmentoPantalla(
            Drawing.PointF a,
            Drawing.PointF b,
            Drawing.PointF punto)
        {
            const double tolerancia = 0.001;
            return Math.Abs(OrientacionPantalla(a, b, punto)) <= tolerancia &&
                   punto.X >= Math.Min(a.X, b.X) - tolerancia &&
                   punto.X <= Math.Max(a.X, b.X) + tolerancia &&
                   punto.Y >= Math.Min(a.Y, b.Y) - tolerancia &&
                   punto.Y <= Math.Max(a.Y, b.Y) + tolerancia;
        }

        private bool SegmentosPantallaSeIntersectan(
            Drawing.PointF a1,
            Drawing.PointF a2,
            Drawing.PointF b1,
            Drawing.PointF b2)
        {
            double o1 = OrientacionPantalla(a1, a2, b1);
            double o2 = OrientacionPantalla(a1, a2, b2);
            double o3 = OrientacionPantalla(b1, b2, a1);
            double o4 = OrientacionPantalla(b1, b2, a2);
            const double tolerancia = 0.001;

            if (((o1 > tolerancia && o2 < -tolerancia) ||
                 (o1 < -tolerancia && o2 > tolerancia)) &&
                ((o3 > tolerancia && o4 < -tolerancia) ||
                 (o3 < -tolerancia && o4 > tolerancia)))
            {
                return true;
            }

            return (Math.Abs(o1) <= tolerancia &&
                    PuntoSobreSegmentoPantalla(a1, a2, b1)) ||
                   (Math.Abs(o2) <= tolerancia &&
                    PuntoSobreSegmentoPantalla(a1, a2, b2)) ||
                   (Math.Abs(o3) <= tolerancia &&
                    PuntoSobreSegmentoPantalla(b1, b2, a1)) ||
                   (Math.Abs(o4) <= tolerancia &&
                    PuntoSobreSegmentoPantalla(b1, b2, a2));
        }

        private bool SegmentoIntersecaRectanguloPantalla(
            Drawing.PointF a,
            Drawing.PointF b,
            Drawing.RectangleF rectangulo)
        {
            if (PuntoDentroRectanguloPantalla(rectangulo, a, 0F) ||
                PuntoDentroRectanguloPantalla(rectangulo, b, 0F))
            {
                return true;
            }

            Drawing.PointF si = new Drawing.PointF(
                rectangulo.Left,
                rectangulo.Top);
            Drawing.PointF sd = new Drawing.PointF(
                rectangulo.Right,
                rectangulo.Top);
            Drawing.PointF id = new Drawing.PointF(
                rectangulo.Right,
                rectangulo.Bottom);
            Drawing.PointF ii = new Drawing.PointF(
                rectangulo.Left,
                rectangulo.Bottom);

            return SegmentosPantallaSeIntersectan(a, b, si, sd) ||
                   SegmentosPantallaSeIntersectan(a, b, sd, id) ||
                   SegmentosPantallaSeIntersectan(a, b, id, ii) ||
                   SegmentosPantallaSeIntersectan(a, b, ii, si);
        }

        private bool EstriboCoincideSeleccionRegion(
            AceroVigaEstribo2D estribo,
            Drawing.RectangleF rectangulo,
            bool seleccionVentana)
        {
            if (estribo == null)
                return false;

            List<AceroVigaPuntoMm> puntosModelo = ObtenerPuntosEstriboMm(estribo);
            if (puntosModelo == null || puntosModelo.Count == 0)
                return false;

            List<Drawing.PointF> puntos = puntosModelo
                .Select(ConvertirModeloAPantalla)
                .ToList();

            float margen = ObtenerDiametroPantalla(
                estribo.TipoBarra ?? TipoEstriboActual,
                2.5F) * 0.5F + 1F;

            if (seleccionVentana)
            {
                return puntos.All(p =>
                    PuntoDentroRectanguloPantalla(rectangulo, p, margen));
            }

            if (puntos.Any(p =>
                PuntoDentroRectanguloPantalla(rectangulo, p, 0F)))
            {
                return true;
            }

            int segmentos = estribo.Cerrado
                ? puntos.Count
                : Math.Max(0, puntos.Count - 1);

            for (int i = 0; i < segmentos; i++)
            {
                Drawing.PointF a = puntos[i];
                Drawing.PointF b = puntos[(i + 1) % puntos.Count];
                if (SegmentoIntersecaRectanguloPantalla(a, b, rectangulo))
                    return true;
            }

            return false;
        }

        private void FinalizarSeleccionRegionEstribos(
            Drawing.Point ubicacionFinal)
        {
            if (!seleccionandoRegionEstribos)
                return;

            finSeleccionRegionEstribos = ubicacionFinal;
            bool arrastreReal = EsArrastreRealSeleccion(
                inicioSeleccionRegionEstribos,
                finSeleccionRegionEstribos);
            bool seleccionVentana =
                finSeleccionRegionEstribos.X >=
                inicioSeleccionRegionEstribos.X;
            Drawing.RectangleF rectangulo =
                ObtenerRectanguloSeleccionPantalla(
                    inicioSeleccionRegionEstribos,
                    finSeleccionRegionEstribos);

            seleccionandoRegionEstribos = false;
            if (panelLienzo != null)
            {
                panelLienzo.Capture = false;
                panelLienzo.Cursor = WinForms.Cursors.Cross;
            }

            if (!arrastreReal ||
                rectangulo.Width < 1F ||
                rectangulo.Height < 1F)
            {
                AceroVigaPuntoMm punto = ConvertirPantallaAModelo(
                    inicioSeleccionRegionEstribos);
                string id;
                int indiceVertice;
                bool detectado = TryDetectarEstriboEnPunto(
                    punto,
                    out id,
                    out indiceVertice);

                if (agregarSeleccionRegionEstribos)
                {
                    if (detectado)
                        AlternarSeleccionEstribo(id, indiceVertice);
                }
                else
                {
                    if (detectado)
                        SeleccionarSoloEstribo(id, indiceVertice);
                    else
                        LimpiarSeleccionEstribos(true);
                }

                if (lblEstado != null)
                {
                    lblEstado.Text = detectado
                        ? idsEstribosSeleccionados.Count +
                          " recorrido(s) seleccionado(s). Ctrl+Clic agrega o retira."
                        : "Selección de estribos vacía.";
                }

                if (panelLienzo != null)
                    panelLienzo.Invalidate();
                return;
            }

            if (!agregarSeleccionRegionEstribos)
            {
                idsEstribosSeleccionados.Clear();
                idSeleccionado = string.Empty;
                indiceVerticeSeleccionado = -1;
            }

            string primerIdAgregado = string.Empty;
            foreach (AceroVigaEstribo2D estribo in disenoTrabajo.Estribos)
            {
                if (estribo == null || string.IsNullOrWhiteSpace(estribo.Id))
                    continue;

                if (!EstriboCoincideSeleccionRegion(
                        estribo,
                        rectangulo,
                        seleccionVentana))
                {
                    continue;
                }

                idsEstribosSeleccionados.Add(estribo.Id);
                if (string.IsNullOrWhiteSpace(primerIdAgregado))
                    primerIdAgregado = estribo.Id;
            }

            if (!string.IsNullOrWhiteSpace(primerIdAgregado))
            {
                idSeleccionado = primerIdAgregado;
                indiceVerticeSeleccionado = -1;
            }
            else if (!agregarSeleccionRegionEstribos)
            {
                idSeleccionado = string.Empty;
                indiceVerticeSeleccionado = -1;
            }
            else if (string.IsNullOrWhiteSpace(idSeleccionado) ||
                     !idsEstribosSeleccionados.Contains(idSeleccionado))
            {
                idSeleccionado = idsEstribosSeleccionados.FirstOrDefault() ??
                    string.Empty;
                indiceVerticeSeleccionado = -1;
            }

            NotificarEstadoSeleccionTipoCambiado();

            if (lblEstado != null)
            {
                lblEstado.Text =
                    (seleccionVentana ? "VENTANA" : "CRUCE") + ": " +
                    idsEstribosSeleccionados.Count +
                    " recorrido(s) seleccionado(s). Ctrl permite agregar otra región.";
            }

            if (panelLienzo != null)
                panelLienzo.Invalidate();
        }

        private void DibujarSeleccionRegionEstribos(Drawing.Graphics g)
        {
            if (g == null || !seleccionandoRegionEstribos)
                return;

            Drawing.RectangleF rectangulo =
                ObtenerRectanguloSeleccionPantalla(
                    inicioSeleccionRegionEstribos,
                    finSeleccionRegionEstribos);
            bool ventana =
                finSeleccionRegionEstribos.X >=
                inicioSeleccionRegionEstribos.X;

            Drawing.Color color = ventana
                ? Drawing.Color.FromArgb(35, 105, 210)
                : Drawing.Color.FromArgb(35, 165, 95);
            Drawing.Color relleno = ventana
                ? Drawing.Color.FromArgb(45, 70, 135, 230)
                : Drawing.Color.FromArgb(45, 45, 190, 110);

            using (Drawing.SolidBrush brocha = new Drawing.SolidBrush(relleno))
            using (Drawing.Pen pen = new Drawing.Pen(color, 1.7F))
            using (Drawing.Font fuente = new Drawing.Font(
                "Segoe UI",
                7.5F,
                Drawing.FontStyle.Bold))
            using (Drawing.SolidBrush brochaTexto = new Drawing.SolidBrush(color))
            using (Drawing.SolidBrush fondoTexto = new Drawing.SolidBrush(
                Drawing.Color.FromArgb(235, 255, 255, 255)))
            {
                pen.DashStyle = ventana
                    ? Drawing2D.DashStyle.Solid
                    : Drawing2D.DashStyle.Dash;
                g.FillRectangle(brocha, rectangulo);
                g.DrawRectangle(
                    pen,
                    rectangulo.X,
                    rectangulo.Y,
                    rectangulo.Width,
                    rectangulo.Height);

                string texto = ventana
                    ? "VENTANA · COMPLETAMENTE DENTRO"
                    : "CRUCE · TOCA O CRUZA";
                Drawing.SizeF tamano = g.MeasureString(texto, fuente);
                float x = rectangulo.Left + 5F;
                float y = rectangulo.Top - tamano.Height - 4F;
                if (y < 70F)
                    y = rectangulo.Top + 5F;

                Drawing.RectangleF caja = new Drawing.RectangleF(
                    x - 3F,
                    y - 2F,
                    tamano.Width + 6F,
                    tamano.Height + 4F);
                g.FillRectangle(fondoTexto, caja);
                g.DrawRectangle(pen, caja.X, caja.Y, caja.Width, caja.Height);
                g.DrawString(texto, fuente, brochaTexto, x, y);
            }
        }



        // =========================================================
        // SELECCIÓN MÚLTIPLE Y POR REGIÓN DE LONGITUDINALES
        // =========================================================
        private void LimpiarSeleccionLongitudinal(bool notificar)
        {
            idsGruposLongitudinalesSeleccionados.Clear();
            idsBarrasLongitudinalesSeleccionadas.Clear();
            idSeleccionado = string.Empty;
            indiceVerticeSeleccionado = -1;

            if (notificar)
                NotificarEstadoSeleccionTipoCambiado();
        }

        private bool TryDetectarBarraLongitudinalEnPunto(
            AceroVigaPuntoMm punto,
            out AceroVigaBarraLongitudinal2D barraDetectada)
        {
            barraDetectada = null;
            if (punto == null || disenoTrabajo == null ||
                disenoTrabajo.Longitudinales == null)
            {
                return false;
            }

            double tolerancia = ObtenerToleranciaModelo(14.0F);
            double mejor = double.MaxValue;

            foreach (AceroVigaBarraLongitudinal2D barra in
                disenoTrabajo.Longitudinales)
            {
                if (barra == null || barra.Punto == null ||
                    barra.OcultaPorSuperposicion)
                {
                    continue;
                }

                AceroVigaPuntoMm modelo =
                    ObtenerPuntoModeloLongitudinal(barra);
                if (modelo == null)
                    continue;

                double distancia = Distancia(punto, modelo);
                if (distancia <= tolerancia && distancia < mejor)
                {
                    mejor = distancia;
                    barraDetectada = barra;
                }
            }

            return barraDetectada != null;
        }

        private void SeleccionarSoloLongitudinal(
            AceroVigaBarraLongitudinal2D barra)
        {
            idsGruposLongitudinalesSeleccionados.Clear();
            idsBarrasLongitudinalesSeleccionadas.Clear();
            idsEstribosSeleccionados.Clear();

            if (barra == null)
            {
                idSeleccionado = string.Empty;
                indiceVerticeSeleccionado = -1;
                NotificarEstadoSeleccionTipoCambiado();
                return;
            }

            if (!string.IsNullOrWhiteSpace(barra.GrupoDistribucionId))
                idsGruposLongitudinalesSeleccionados.Add(
                    barra.GrupoDistribucionId);
            else
                idsBarrasLongitudinalesSeleccionadas.Add(barra.Id);

            idSeleccionado = barra.Id;
            indiceVerticeSeleccionado = -1;
            NotificarEstadoSeleccionTipoCambiado();
        }

        private AceroVigaBarraLongitudinal2D
            ObtenerRepresentanteSeleccionLongitudinal()
        {
            if (disenoTrabajo == null ||
                disenoTrabajo.Longitudinales == null)
            {
                return null;
            }

            foreach (string grupoId in idsGruposLongitudinalesSeleccionados)
            {
                AceroVigaBarraLongitudinal2D barra =
                    disenoTrabajo.Longitudinales.FirstOrDefault(x =>
                        x != null && !x.OcultaPorSuperposicion &&
                        string.Equals(
                            x.GrupoDistribucionId,
                            grupoId,
                            StringComparison.Ordinal));
                if (barra != null)
                    return barra;

                barra = disenoTrabajo.Longitudinales.FirstOrDefault(x =>
                    x != null && string.Equals(
                        x.GrupoDistribucionId,
                        grupoId,
                        StringComparison.Ordinal));
                if (barra != null)
                    return barra;
            }

            foreach (string barraId in idsBarrasLongitudinalesSeleccionadas)
            {
                AceroVigaBarraLongitudinal2D barra =
                    disenoTrabajo.Longitudinales.FirstOrDefault(x =>
                        x != null && string.Equals(
                            x.Id,
                            barraId,
                            StringComparison.Ordinal));
                if (barra != null)
                    return barra;
            }

            return null;
        }

        private void SincronizarRepresentanteSeleccionLongitudinal()
        {
            AceroVigaBarraLongitudinal2D representante =
                ObtenerRepresentanteSeleccionLongitudinal();
            idSeleccionado = representante != null
                ? representante.Id
                : string.Empty;
            indiceVerticeSeleccionado = -1;
        }

        private void AlternarSeleccionLongitudinal(
            AceroVigaBarraLongitudinal2D barra)
        {
            if (barra == null)
                return;

            idsEstribosSeleccionados.Clear();

            if (!string.IsNullOrWhiteSpace(barra.GrupoDistribucionId))
            {
                if (!idsGruposLongitudinalesSeleccionados.Add(
                        barra.GrupoDistribucionId))
                {
                    idsGruposLongitudinalesSeleccionados.Remove(
                        barra.GrupoDistribucionId);
                }
            }
            else
            {
                if (!idsBarrasLongitudinalesSeleccionadas.Add(barra.Id))
                    idsBarrasLongitudinalesSeleccionadas.Remove(barra.Id);
            }

            SincronizarRepresentanteSeleccionLongitudinal();
            NotificarEstadoSeleccionTipoCambiado();
        }

        private int ObtenerCantidadUnidadesSeleccionLongitudinal()
        {
            return idsGruposLongitudinalesSeleccionados.Count +
                   idsBarrasLongitudinalesSeleccionadas.Count;
        }

        private void IniciarSeleccionRegionLongitudinal(
            Drawing.Point ubicacion,
            bool agregar)
        {
            seleccionandoRegionLongitudinal = true;
            inicioSeleccionRegionLongitudinal = ubicacion;
            finSeleccionRegionLongitudinal = ubicacion;
            agregarSeleccionRegionLongitudinal = agregar;
            puntoSnapActual = null;
            textoSnapActual = string.Empty;

            if (panelLienzo != null)
            {
                panelLienzo.Capture = true;
                panelLienzo.Cursor = WinForms.Cursors.Cross;
                panelLienzo.Invalidate();
            }

            if (lblEstado != null)
            {
                lblEstado.Text =
                    "Arrastre IZQ→DER: VENTANA, conjuntos completamente dentro. " +
                    "DER→IZQ: CRUCE, conjuntos tocados o cruzados. Ctrl acumula selección.";
            }
        }

        private bool CirculoCompletamenteDentroRectanguloPantalla(
            Drawing.RectangleF rectangulo,
            Drawing.PointF centro,
            float radio)
        {
            return centro.X - radio >= rectangulo.Left &&
                   centro.X + radio <= rectangulo.Right &&
                   centro.Y - radio >= rectangulo.Top &&
                   centro.Y + radio <= rectangulo.Bottom;
        }

        private bool CirculoIntersecaRectanguloPantalla(
            Drawing.RectangleF rectangulo,
            Drawing.PointF centro,
            float radio)
        {
            float xCercano = Math.Max(
                rectangulo.Left,
                Math.Min(centro.X, rectangulo.Right));
            float yCercano = Math.Max(
                rectangulo.Top,
                Math.Min(centro.Y, rectangulo.Bottom));
            float dx = centro.X - xCercano;
            float dy = centro.Y - yCercano;
            return dx * dx + dy * dy <= radio * radio;
        }

        private bool GrupoLongitudinalCoincideSeleccionRegion(
            AceroVigaGrupoLongitudinal2D grupo,
            Drawing.RectangleF rectangulo,
            bool seleccionVentana)
        {
            if (grupo == null || string.IsNullOrWhiteSpace(grupo.Id) ||
                disenoTrabajo == null ||
                disenoTrabajo.Longitudinales == null)
            {
                return false;
            }

            List<AceroVigaBarraLongitudinal2D> barras =
                disenoTrabajo.Longitudinales.Where(x =>
                    x != null && !x.OcultaPorSuperposicion &&
                    string.Equals(
                        x.GrupoDistribucionId,
                        grupo.Id,
                        StringComparison.Ordinal)).ToList();

            if (barras.Count == 0)
                return false;

            bool todasDentro = true;
            bool algunaTocada = false;
            foreach (AceroVigaBarraLongitudinal2D barra in barras)
            {
                AceroVigaPuntoMm modelo =
                    ObtenerPuntoModeloLongitudinal(barra);
                if (modelo == null)
                    continue;

                Drawing.PointF centro = ConvertirModeloAPantalla(modelo);
                float radio = ObtenerDiametroPantalla(
                    barra.TipoBarra ?? TipoLongitudinalActual,
                    6F) * 0.5F;

                todasDentro = todasDentro &&
                    CirculoCompletamenteDentroRectanguloPantalla(
                        rectangulo,
                        centro,
                        radio);
                algunaTocada = algunaTocada ||
                    CirculoIntersecaRectanguloPantalla(
                        rectangulo,
                        centro,
                        radio);
            }

            AceroVigaPuntoMm inicio;
            AceroVigaPuntoMm fin;
            AceroVigaGuiaCapaLongitudinal2D guia;
            List<AceroVigaPuntoMm> puntosGuia;
            List<AceroVigaPuntoMm> permitido;
            bool tieneExtremos = TryObtenerExtremosGrupoLongitudinal(
                grupo.Id,
                out inicio,
                out fin,
                out guia,
                out puntosGuia,
                out permitido);

            if (seleccionVentana)
            {
                if (!todasDentro)
                    return false;

                if (!tieneExtremos)
                    return true;

                Drawing.PointF a = ConvertirModeloAPantalla(inicio);
                Drawing.PointF b = ConvertirModeloAPantalla(fin);
                return PuntoDentroRectanguloPantalla(rectangulo, a, 0F) &&
                       PuntoDentroRectanguloPantalla(rectangulo, b, 0F);
            }

            if (algunaTocada)
                return true;

            if (tieneExtremos)
            {
                return SegmentoIntersecaRectanguloPantalla(
                    ConvertirModeloAPantalla(inicio),
                    ConvertirModeloAPantalla(fin),
                    rectangulo);
            }

            return false;
        }

        private bool BarraIndividualCoincideSeleccionRegion(
            AceroVigaBarraLongitudinal2D barra,
            Drawing.RectangleF rectangulo,
            bool seleccionVentana)
        {
            if (barra == null || barra.Punto == null ||
                barra.OcultaPorSuperposicion ||
                !string.IsNullOrWhiteSpace(barra.GrupoDistribucionId))
            {
                return false;
            }

            AceroVigaPuntoMm modelo = ObtenerPuntoModeloLongitudinal(barra);
            if (modelo == null)
                return false;

            Drawing.PointF centro = ConvertirModeloAPantalla(modelo);
            float radio = ObtenerDiametroPantalla(
                barra.TipoBarra ?? TipoLongitudinalActual,
                6F) * 0.5F;

            return seleccionVentana
                ? CirculoCompletamenteDentroRectanguloPantalla(
                    rectangulo,
                    centro,
                    radio)
                : CirculoIntersecaRectanguloPantalla(
                    rectangulo,
                    centro,
                    radio);
        }

        private void FinalizarSeleccionRegionLongitudinal(
            Drawing.Point ubicacionFinal)
        {
            if (!seleccionandoRegionLongitudinal)
                return;

            finSeleccionRegionLongitudinal = ubicacionFinal;
            bool arrastreReal = EsArrastreRealSeleccion(
                inicioSeleccionRegionLongitudinal,
                finSeleccionRegionLongitudinal);
            bool seleccionVentana =
                finSeleccionRegionLongitudinal.X >=
                inicioSeleccionRegionLongitudinal.X;
            Drawing.RectangleF rectangulo =
                ObtenerRectanguloSeleccionPantalla(
                    inicioSeleccionRegionLongitudinal,
                    finSeleccionRegionLongitudinal);

            seleccionandoRegionLongitudinal = false;
            if (panelLienzo != null)
            {
                panelLienzo.Capture = false;
                panelLienzo.Cursor = WinForms.Cursors.Cross;
            }

            if (!arrastreReal || rectangulo.Width < 1F ||
                rectangulo.Height < 1F)
            {
                AceroVigaPuntoMm punto = ConvertirPantallaAModelo(
                    inicioSeleccionRegionLongitudinal);
                AceroVigaBarraLongitudinal2D barra;
                bool detectado = TryDetectarBarraLongitudinalEnPunto(
                    punto,
                    out barra);

                if (agregarSeleccionRegionLongitudinal)
                {
                    if (detectado)
                        AlternarSeleccionLongitudinal(barra);
                }
                else
                {
                    if (detectado)
                        SeleccionarSoloLongitudinal(barra);
                    else
                    {
                        LimpiarSeleccionLongitudinal(false);
                        TrySeleccionarGuiaCapaCercana(punto);
                        NotificarEstadoSeleccionTipoCambiado();
                    }
                }

                if (lblEstado != null)
                {
                    lblEstado.Text = detectado
                        ? ObtenerCantidadUnidadesSeleccionLongitudinal() +
                          " conjunto(s) o barra(s) seleccionado(s). Ctrl+Clic agrega o retira."
                        : "Selección longitudinal vacía.";
                }

                if (panelLienzo != null)
                    panelLienzo.Invalidate();
                return;
            }

            if (!agregarSeleccionRegionLongitudinal)
            {
                idsGruposLongitudinalesSeleccionados.Clear();
                idsBarrasLongitudinalesSeleccionadas.Clear();
            }

            if (disenoTrabajo.GruposLongitudinales != null)
            {
                foreach (AceroVigaGrupoLongitudinal2D grupo in
                    disenoTrabajo.GruposLongitudinales)
                {
                    if (GrupoLongitudinalCoincideSeleccionRegion(
                            grupo,
                            rectangulo,
                            seleccionVentana))
                    {
                        idsGruposLongitudinalesSeleccionados.Add(grupo.Id);
                    }
                }
            }

            foreach (AceroVigaBarraLongitudinal2D barra in
                disenoTrabajo.Longitudinales)
            {
                if (BarraIndividualCoincideSeleccionRegion(
                        barra,
                        rectangulo,
                        seleccionVentana))
                {
                    idsBarrasLongitudinalesSeleccionadas.Add(barra.Id);
                }
            }

            SincronizarRepresentanteSeleccionLongitudinal();
            NotificarEstadoSeleccionTipoCambiado();

            if (lblEstado != null)
            {
                lblEstado.Text =
                    (seleccionVentana ? "VENTANA" : "CRUCE") + ": " +
                    ObtenerCantidadUnidadesSeleccionLongitudinal() +
                    " conjunto(s) o barra(s) seleccionado(s). Ctrl permite acumular regiones.";
            }

            if (panelLienzo != null)
                panelLienzo.Invalidate();
        }

        private void DibujarSeleccionRegionLongitudinal(Drawing.Graphics g)
        {
            if (g == null || !seleccionandoRegionLongitudinal)
                return;

            Drawing.RectangleF rectangulo =
                ObtenerRectanguloSeleccionPantalla(
                    inicioSeleccionRegionLongitudinal,
                    finSeleccionRegionLongitudinal);
            bool ventana =
                finSeleccionRegionLongitudinal.X >=
                inicioSeleccionRegionLongitudinal.X;

            Drawing.Color color = ventana
                ? Drawing.Color.FromArgb(35, 105, 210)
                : Drawing.Color.FromArgb(35, 165, 95);
            Drawing.Color relleno = ventana
                ? Drawing.Color.FromArgb(45, 70, 135, 230)
                : Drawing.Color.FromArgb(45, 45, 190, 110);

            using (Drawing.SolidBrush brocha = new Drawing.SolidBrush(relleno))
            using (Drawing.Pen pen = new Drawing.Pen(color, 1.7F))
            using (Drawing.Font fuente = new Drawing.Font(
                "Segoe UI",
                7.5F,
                Drawing.FontStyle.Bold))
            using (Drawing.SolidBrush brochaTexto =
                new Drawing.SolidBrush(color))
            using (Drawing.SolidBrush fondoTexto =
                new Drawing.SolidBrush(
                    Drawing.Color.FromArgb(235, 255, 255, 255)))
            {
                pen.DashStyle = ventana
                    ? Drawing2D.DashStyle.Solid
                    : Drawing2D.DashStyle.Dash;
                g.FillRectangle(brocha, rectangulo);
                g.DrawRectangle(
                    pen,
                    rectangulo.X,
                    rectangulo.Y,
                    rectangulo.Width,
                    rectangulo.Height);

                string texto = ventana
                    ? "VENTANA · CONJUNTOS COMPLETAMENTE DENTRO"
                    : "CRUCE · CONJUNTOS TOCADOS O CRUZADOS";
                Drawing.SizeF tamano = g.MeasureString(texto, fuente);
                float x = rectangulo.Left + 5F;
                float y = rectangulo.Top - tamano.Height - 4F;
                if (y < 70F)
                    y = rectangulo.Top + 5F;

                Drawing.RectangleF caja = new Drawing.RectangleF(
                    x - 3F,
                    y - 2F,
                    tamano.Width + 6F,
                    tamano.Height + 4F);
                g.FillRectangle(fondoTexto, caja);
                g.DrawRectangle(pen, caja.X, caja.Y, caja.Width, caja.Height);
                g.DrawString(texto, fuente, brochaTexto, x, y);
            }
        }


        #endregion

        private string ObtenerGrupoLongitudinalSeleccionadoId()
        {
            if (disenoTrabajo == null ||
                disenoTrabajo.Longitudinales == null)
            {
                return string.Empty;
            }

            if (!string.IsNullOrWhiteSpace(idSeleccionado))
            {
                AceroVigaBarraLongitudinal2D barra =
                    disenoTrabajo.Longitudinales.FirstOrDefault(x =>
                        x != null && string.Equals(
                            x.Id,
                            idSeleccionado,
                            StringComparison.Ordinal));

                if (barra != null &&
                    !string.IsNullOrWhiteSpace(barra.GrupoDistribucionId))
                {
                    return barra.GrupoDistribucionId;
                }
            }

            return idsGruposLongitudinalesSeleccionados.Count == 1
                ? idsGruposLongitudinalesSeleccionados.First()
                : string.Empty;
        }

        private bool EsLongitudinalSeleccionadoComoConjunto(
            AceroVigaBarraLongitudinal2D barra)
        {
            if (barra == null ||
                modoEditorActual !=
                    AceroVigaModoEditorInicial.Longitudinales)
            {
                return false;
            }

            if (!string.IsNullOrWhiteSpace(barra.GrupoDistribucionId))
            {
                return idsGruposLongitudinalesSeleccionados.Contains(
                           barra.GrupoDistribucionId) ||
                       string.Equals(
                           barra.GrupoDistribucionId,
                           ObtenerGrupoLongitudinalSeleccionadoId(),
                           StringComparison.Ordinal);
            }

            return idsBarrasLongitudinalesSeleccionadas.Contains(barra.Id) ||
                   string.Equals(
                       barra.Id,
                       idSeleccionado,
                       StringComparison.Ordinal);
        }

        private AceroVigaPuntoMm ObtenerPuntoModeloLongitudinal(
            AceroVigaBarraLongitudinal2D barra)
        {
            if (barra == null || barra.Punto == null)
                return null;

            RebarBarType tipo =
                barra.TipoBarra ?? TipoLongitudinalActual;
            List<AceroVigaPuntoMm> permitido =
                ObtenerContornoCentrosLongitudinalMm(tipo);

            if (permitido == null || permitido.Count < 3)
                return null;

            return DesnormalizarEnCaja(barra.Punto, permitido);
        }

        private bool ExistePosicionLongitudinalOcupada(
            AceroVigaPuntoMm punto,
            IEnumerable<AceroVigaPuntoMm> ocupados,
            double toleranciaMm)
        {
            if (punto == null || ocupados == null)
                return false;

            foreach (AceroVigaPuntoMm ocupado in ocupados)
            {
                if (ocupado != null &&
                    Distancia(punto, ocupado) <= toleranciaMm)
                {
                    return true;
                }
            }

            return false;
        }

        private void RecalcularOmisionesExtremosGruposLongitudinales()
        {
            if (disenoTrabajo == null ||
                disenoTrabajo.Longitudinales == null)
            {
                return;
            }

            foreach (AceroVigaBarraLongitudinal2D barra in
                disenoTrabajo.Longitudinales)
            {
                if (barra != null)
                    barra.OcultaPorSuperposicion = false;
            }

            if (disenoTrabajo.GruposLongitudinales == null ||
                disenoTrabajo.GruposLongitudinales.Count == 0)
            {
                return;
            }

            // V10.8: solo se oculta un extremo cuando los centros coinciden de
            // forma prácticamente exacta. Una tolerancia mayor podía ocultar una
            // barra válida después de cambiar tipo o reconstruir una guía inclinada.
            const double toleranciaMm = 0.25;
            List<AceroVigaPuntoMm> ocupados =
                new List<AceroVigaPuntoMm>();

            // Las barras individuales tienen prioridad sobre los grupos.
            foreach (AceroVigaBarraLongitudinal2D barra in
                disenoTrabajo.Longitudinales.Where(x =>
                    x != null &&
                    string.IsNullOrWhiteSpace(
                        x.GrupoDistribucionId)))
            {
                AceroVigaPuntoMm punto =
                    ObtenerPuntoModeloLongitudinal(barra);
                if (punto != null)
                    ocupados.Add(punto);
            }

            // Los grupos se procesan en el orden en que fueron creados. Cuando
            // un grupo posterior coincide en su inicio o final con una posición
            // ya ocupada, ese extremo queda oculto.
            foreach (AceroVigaGrupoLongitudinal2D grupo in
                disenoTrabajo.GruposLongitudinales.Where(x => x != null))
            {
                List<AceroVigaBarraLongitudinal2D> barrasGrupo =
                    disenoTrabajo.Longitudinales.Where(x =>
                        x != null &&
                        string.Equals(
                            x.GrupoDistribucionId,
                            grupo.Id,
                            StringComparison.Ordinal)).ToList();

                if (barrasGrupo.Count == 0)
                {
                    grupo.OmitirPrimeraBarra = false;
                    grupo.OmitirUltimaBarra = false;
                    continue;
                }

                if (barrasGrupo.All(x =>
                        x.ParametroSobreGuia >= 0.0))
                {
                    bool sentidoAscendente =
                        grupo.ParametroFinGuia >=
                        grupo.ParametroInicioGuia;
                    barrasGrupo = sentidoAscendente
                        ? barrasGrupo.OrderBy(x =>
                            x.ParametroSobreGuia).ToList()
                        : barrasGrupo.OrderByDescending(x =>
                            x.ParametroSobreGuia).ToList();
                }

                AceroVigaBarraLongitudinal2D primera =
                    barrasGrupo[0];
                AceroVigaBarraLongitudinal2D ultima =
                    barrasGrupo[barrasGrupo.Count - 1];

                AceroVigaPuntoMm puntoPrimero =
                    ObtenerPuntoModeloLongitudinal(primera);
                AceroVigaPuntoMm puntoUltimo =
                    ObtenerPuntoModeloLongitudinal(ultima);

                grupo.OmitirPrimeraBarra =
                    ExistePosicionLongitudinalOcupada(
                        puntoPrimero,
                        ocupados,
                        toleranciaMm);

                grupo.OmitirUltimaBarra =
                    barrasGrupo.Count > 1 &&
                    ExistePosicionLongitudinalOcupada(
                        puntoUltimo,
                        ocupados,
                        toleranciaMm);

                primera.OcultaPorSuperposicion =
                    grupo.OmitirPrimeraBarra;
                ultima.OcultaPorSuperposicion =
                    grupo.OmitirUltimaBarra;

                for (int i = 0; i < barrasGrupo.Count; i++)
                {
                    AceroVigaBarraLongitudinal2D barra =
                        barrasGrupo[i];
                    if (barra == null ||
                        barra.OcultaPorSuperposicion)
                    {
                        continue;
                    }

                    AceroVigaPuntoMm posicion =
                        ObtenerPuntoModeloLongitudinal(barra);
                    if (posicion != null)
                        ocupados.Add(posicion);
                }
            }
        }

        private AceroVigaGrupoLongitudinal2D ObtenerGrupoLongitudinalPorId(
            string grupoId)
        {
            if (string.IsNullOrWhiteSpace(grupoId) ||
                disenoTrabajo == null ||
                disenoTrabajo.GruposLongitudinales == null)
            {
                return null;
            }

            return disenoTrabajo.GruposLongitudinales.FirstOrDefault(x =>
                x != null && string.Equals(
                    x.Id,
                    grupoId,
                    StringComparison.Ordinal));
        }

        private bool EsBarraDelGrupoEnArrastreExtremo(
            AceroVigaBarraLongitudinal2D barra)
        {
            return arrastrandoExtremoGrupoLongitudinal &&
                   barra != null &&
                   !string.IsNullOrWhiteSpace(
                       idGrupoLongitudinalArrastreExtremo) &&
                   string.Equals(
                       barra.GrupoDistribucionId,
                       idGrupoLongitudinalArrastreExtremo,
                       StringComparison.Ordinal);
        }

        private void SeleccionarGrupoLongitudinalCompleto(
            string grupoId)
        {
            if (string.IsNullOrWhiteSpace(grupoId) ||
                disenoTrabajo == null ||
                disenoTrabajo.Longitudinales == null)
            {
                return;
            }

            AceroVigaBarraLongitudinal2D representante =
                disenoTrabajo.Longitudinales.FirstOrDefault(x =>
                    x != null &&
                    !x.OcultaPorSuperposicion &&
                    string.Equals(
                        x.GrupoDistribucionId,
                        grupoId,
                        StringComparison.Ordinal));

            if (representante == null)
            {
                representante = disenoTrabajo.Longitudinales.FirstOrDefault(x =>
                    x != null && string.Equals(
                        x.GrupoDistribucionId,
                        grupoId,
                        StringComparison.Ordinal));
            }

            idsGruposLongitudinalesSeleccionados.Clear();
            idsBarrasLongitudinalesSeleccionadas.Clear();
            idsGruposLongitudinalesSeleccionados.Add(grupoId);
            idSeleccionado = representante != null
                ? representante.Id
                : string.Empty;
            indiceVerticeSeleccionado = -1;
            idsEstribosSeleccionados.Clear();
            NotificarEstadoSeleccionTipoCambiado();
        }

        private bool TryObtenerExtremosGrupoLongitudinal(
            string grupoId,
            out AceroVigaPuntoMm inicio,
            out AceroVigaPuntoMm fin,
            out AceroVigaGuiaCapaLongitudinal2D guia,
            out List<AceroVigaPuntoMm> puntosGuia,
            out List<AceroVigaPuntoMm> permitido)
        {
            inicio = null;
            fin = null;
            guia = null;
            puntosGuia = new List<AceroVigaPuntoMm>();
            permitido = new List<AceroVigaPuntoMm>();

            AceroVigaGrupoLongitudinal2D grupo =
                ObtenerGrupoLongitudinalPorId(grupoId);
            if (grupo == null)
                return false;

            RebarBarType tipo =
                grupo.TipoBarra ?? TipoLongitudinalActual;
            permitido = ObtenerContornoCentrosLongitudinalMm(tipo);
            if (permitido == null || permitido.Count < 3)
                return false;

            if (disenoTrabajo.GuiasCapasLongitudinales != null &&
                !string.IsNullOrWhiteSpace(grupo.GuiaCapaId))
            {
                guia = disenoTrabajo.GuiasCapasLongitudinales.FirstOrDefault(x =>
                    x != null && string.Equals(
                        x.Id,
                        grupo.GuiaCapaId,
                        StringComparison.Ordinal));
            }

            if (guia != null)
                puntosGuia = ObtenerPuntosGuiaMm(guia, permitido);

            if (TryObtenerLineaExactaGrupoLongitudinal(
                    grupo,
                    permitido,
                    out inicio,
                    out fin))
            {
                return true;
            }

            if (puntosGuia != null &&
                puntosGuia.Count >= 2 &&
                grupo.ParametroInicioGuia >= 0.0 &&
                grupo.ParametroFinGuia >= 0.0)
            {
                inicio = PuntoDistribucionEnGuia(
                    puntosGuia,
                    grupo.ParametroInicioGuia);
                fin = PuntoDistribucionEnGuia(
                    puntosGuia,
                    grupo.ParametroFinGuia);
                return inicio != null && fin != null;
            }

            if (grupo.PuntoInicio == null || grupo.PuntoFin == null)
                return false;

            inicio = DesnormalizarEnCaja(
                grupo.PuntoInicio,
                permitido);
            fin = DesnormalizarEnCaja(
                grupo.PuntoFin,
                permitido);
            return inicio != null && fin != null;
        }

        private bool TryDetectarExtremoGrupoLongitudinal(
            Drawing.Point ubicacionPantalla,
            out string grupoId,
            out bool esInicio)
        {
            grupoId = string.Empty;
            esInicio = false;

            if (modoEditorActual !=
                    AceroVigaModoEditorInicial.Longitudinales ||
                herramienta !=
                    AceroVigaHerramientaEditor.SeleccionarMover ||
                disenoTrabajo == null ||
                disenoTrabajo.GruposLongitudinales == null)
            {
                return false;
            }

            const float toleranciaPx = 15F;
            double mejorDistanciaPx = double.MaxValue;
            string grupoSeleccionado =
                ObtenerGrupoLongitudinalSeleccionadoId();

            IEnumerable<AceroVigaGrupoLongitudinal2D> grupos =
                disenoTrabajo.GruposLongitudinales
                    .Where(x => x != null)
                    .OrderByDescending(x => string.Equals(
                        x.Id,
                        grupoSeleccionado,
                        StringComparison.Ordinal));

            foreach (AceroVigaGrupoLongitudinal2D grupo in grupos)
            {
                AceroVigaPuntoMm inicio;
                AceroVigaPuntoMm fin;
                AceroVigaGuiaCapaLongitudinal2D guia;
                List<AceroVigaPuntoMm> puntosGuia;
                List<AceroVigaPuntoMm> permitido;
                if (!TryObtenerExtremosGrupoLongitudinal(
                        grupo.Id,
                        out inicio,
                        out fin,
                        out guia,
                        out puntosGuia,
                        out permitido))
                {
                    continue;
                }

                Drawing.PointF inicioPx =
                    ConvertirModeloAPantalla(inicio);
                Drawing.PointF finPx =
                    ConvertirModeloAPantalla(fin);

                double di = Math.Sqrt(
                    Math.Pow(ubicacionPantalla.X - inicioPx.X, 2.0) +
                    Math.Pow(ubicacionPantalla.Y - inicioPx.Y, 2.0));
                double df = Math.Sqrt(
                    Math.Pow(ubicacionPantalla.X - finPx.X, 2.0) +
                    Math.Pow(ubicacionPantalla.Y - finPx.Y, 2.0));

                if (di <= toleranciaPx && di < mejorDistanciaPx)
                {
                    mejorDistanciaPx = di;
                    grupoId = grupo.Id;
                    esInicio = true;
                }

                if (df <= toleranciaPx && df < mejorDistanciaPx)
                {
                    mejorDistanciaPx = df;
                    grupoId = grupo.Id;
                    esInicio = false;
                }
            }

            return !string.IsNullOrWhiteSpace(grupoId);
        }

        private void ActualizarArrastreExtremoGrupoLongitudinal(
            AceroVigaPuntoMm puntoSolicitado)
        {
            if (!arrastrandoExtremoGrupoLongitudinal ||
                puntoSolicitado == null)
            {
                return;
            }

            AceroVigaGrupoLongitudinal2D grupo =
                ObtenerGrupoLongitudinalPorId(
                    idGrupoLongitudinalArrastreExtremo);
            if (grupo == null)
                return;

            RebarBarType tipo =
                grupo.TipoBarra ?? TipoLongitudinalActual;
            List<AceroVigaPuntoMm> permitido =
                ObtenerContornoCentrosLongitudinalMm(tipo);
            if (permitido == null || permitido.Count < 3)
                return;

            AceroVigaPuntoMm inicioActual =
                grupo.PuntoInicio != null
                    ? DesnormalizarEnCaja(
                        grupo.PuntoInicio,
                        permitido)
                    : null;
            AceroVigaPuntoMm finActual =
                grupo.PuntoFin != null
                    ? DesnormalizarEnCaja(
                        grupo.PuntoFin,
                        permitido)
                    : null;

            // -------------------------------------------------
            // V11.2 - ALINEACIÓN INTUITIVA AL JALAR UN EXTREMO
            // -------------------------------------------------
            AceroVigaGuiaCapaLongitudinal2D
                guiaPreferida = null;

            if (!string.IsNullOrWhiteSpace(
                    grupo.GuiaCapaId) &&
                disenoTrabajo.GuiasCapasLongitudinales != null)
            {
                guiaPreferida =
                    disenoTrabajo.GuiasCapasLongitudinales
                        .FirstOrDefault(x =>
                            x != null &&
                            string.Equals(
                                x.Id,
                                grupo.GuiaCapaId,
                                StringComparison.Ordinal));
            }

            AceroVigaPuntoMm puntoGuiado =
                puntoSolicitado.Copiar();

            AceroVigaPuntoMm alineadoArrastre;
            AceroVigaGuiaCapaLongitudinal2D
                guiaAlineadaArrastre;

            if (EsGuiaSuperiorOInferiorMYG(
                    guiaPreferida) &&
                TryAlinearPuntoAGuiaLongitudinalMYG(
                    puntoGuiado,
                    tipo,
                    guiaPreferida,
                    false,
                    out alineadoArrastre,
                    out guiaAlineadaArrastre))
            {
                // Si el grupo ya era Superior/Inferior, NO abandona
                // accidentalmente esa capa durante el arrastre.
                puntoGuiado = alineadoArrastre;
                guiaPreferida =
                    guiaAlineadaArrastre;
            }
            else if (TryAlinearPuntoAGuiaLongitudinalMYG(
                    puntoGuiado,
                    tipo,
                    null,
                    true,
                    out alineadoArrastre,
                    out guiaAlineadaArrastre))
            {
                // Un grupo libre puede capturar una capa al acercarse.
                puntoGuiado = alineadoArrastre;
                guiaPreferida =
                    guiaAlineadaArrastre;
            }

            AceroVigaPuntoMm puntoFinal =
                AjustarPuntoAlContornoPermitido(
                    puntoGuiado,
                    permitido);

            AceroVigaPuntoMm otro =
                arrastrandoInicioGrupoLongitudinal
                    ? finActual
                    : inicioActual;

            // Mantiene ambos extremos exactamente en la misma capa.
            if (otro != null &&
                EsGuiaSuperiorOInferiorMYG(
                    guiaPreferida))
            {
                AceroVigaPuntoMm otroAlineado;
                AceroVigaGuiaCapaLongitudinal2D guiaOtro;

                if (TryAlinearPuntoAGuiaLongitudinalMYG(
                        otro,
                        tipo,
                        guiaPreferida,
                        false,
                        out otroAlineado,
                        out guiaOtro))
                {
                    otro = otroAlineado;

                    if (arrastrandoInicioGrupoLongitudinal)
                    {
                        grupo.PuntoFin =
                            NormalizarEnCaja(
                                otro,
                                permitido);

                        grupo.PuntoFinSeccionReal =
                            contornoConcretoMm != null &&
                            contornoConcretoMm.Count >= 3
                                ? NormalizarEnCaja(
                                    otro,
                                    contornoConcretoMm)
                                : null;
                    }
                    else
                    {
                        grupo.PuntoInicio =
                            NormalizarEnCaja(
                                otro,
                                permitido);

                        grupo.PuntoInicioSeccionReal =
                            contornoConcretoMm != null &&
                            contornoConcretoMm.Count >= 3
                                ? NormalizarEnCaja(
                                    otro,
                                    contornoConcretoMm)
                                : null;
                    }
                }
            }

            if (puntoFinal == null ||
                (otro != null && Distancia(puntoFinal, otro) < 1.0))
            {
                return;
            }

            grupo.RespetarTrazoDosPuntos = true;
            if (arrastrandoInicioGrupoLongitudinal)
            {
                grupo.PuntoInicio = NormalizarEnCaja(
                    puntoFinal,
                    permitido);
                grupo.PuntoInicioSeccionReal =
                    contornoConcretoMm != null && contornoConcretoMm.Count >= 3
                        ? NormalizarEnCaja(puntoFinal, contornoConcretoMm)
                        : null;
            }
            else
            {
                grupo.PuntoFin = NormalizarEnCaja(
                    puntoFinal,
                    permitido);
                grupo.PuntoFinSeccionReal =
                    contornoConcretoMm != null && contornoConcretoMm.Count >= 3
                        ? NormalizarEnCaja(puntoFinal, contornoConcretoMm)
                        : null;
            }

            inicioActual = grupo.PuntoInicio != null
                ? DesnormalizarEnCaja(grupo.PuntoInicio, permitido)
                : null;
            finActual = grupo.PuntoFin != null
                ? DesnormalizarEnCaja(grupo.PuntoFin, permitido)
                : null;

            double porcentajeCoincidencia = 0.0;

            AceroVigaGuiaCapaLongitudinal2D
                guiaDetectada =
                    EsGuiaSuperiorOInferiorMYG(
                        guiaPreferida)
                        ? guiaPreferida
                        : DetectarGuiaCapaParaSegmento(
                            inicioActual,
                            finActual,
                            tipo,
                            out porcentajeCoincidencia);

            AplicarClasificacionCapaAGrupo(
                grupo,
                guiaDetectada);

            grupo.ParametroInicioGuia = 0.0;
            grupo.ParametroFinGuia = 1.0;

            double longitudMm =
                Distancia(
                    inicioActual,
                    finActual);

            if (grupo.Regla ==
                AceroVigaReglaGrupoLongitudinal.EspaciadoMaximo)
            {
                grupo.Cantidad =
                    longitudMm <= 1e-9
                        ? 1
                        : Math.Max(
                            2,
                            (int)Math.Ceiling(
                                (longitudMm / 10.0) /
                                Math.Max(
                                    0.10,
                                    grupo.EspaciadoCm)) + 1);
            }
            else
            {
                // NÚMERO FIJO:
                // NO cambia la cantidad al jalar el extremo.
                // Reparte nuevamente N barras en forma equidistante.
                grupo.Cantidad =
                    Math.Max(
                        1,
                        grupo.Cantidad);

                grupo.EspaciadoCm =
                    grupo.Cantidad <= 1
                        ? 0.0
                        : (longitudMm / 10.0) /
                            (grupo.Cantidad - 1);
            }

            List<AceroVigaPuntoMm> puntosGuia =
                guiaDetectada != null
                    ? ObtenerPuntosGuiaMm(
                        guiaDetectada,
                        permitido)
                    : new List<AceroVigaPuntoMm>();

            ReconstruirBarrasGrupoLongitudinal(
                grupo,
                guiaDetectada,
                puntosGuia,
                permitido);
            SeleccionarGrupoLongitudinalCompleto(grupo.Id);
            puntoSnapActual = puntoFinal.Copiar();

            if (lblEstado != null)
            {
                string capa = guiaDetectada != null
                    ? " Capa detectada: " +
                        guiaDetectada.Etiqueta + "."
                    : " Sin clasificación de capa.";

                lblEstado.Text =
                    (arrastrandoInicioGrupoLongitudinal
                        ? "Extremo INICIAL"
                        : "Extremo FINAL") +
                    " actualizado y alineado." + capa + " " +
                    (grupo.Regla ==
                        AceroVigaReglaGrupoLongitudinal.EspaciadoMaximo
                            ? grupo.Cantidad +
                                " barras resultantes con máximo " +
                                grupo.EspaciadoCm.ToString("0.##") + " cm."
                            : grupo.Cantidad +
                                " barras de número fijo.");
            }
        }

        private void FinalizarArrastreExtremoGrupoLongitudinal(
            bool publicar)
        {
            if (!arrastrandoExtremoGrupoLongitudinal)
                return;

            string grupoFinalizado =
                idGrupoLongitudinalArrastreExtremo;
            arrastrandoExtremoGrupoLongitudinal = false;
            idGrupoLongitudinalArrastreExtremo = string.Empty;
            arrastrandoInicioGrupoLongitudinal = false;
            arrastrando = false;

            if (panelLienzo != null)
            {
                panelLienzo.Capture = false;
                panelLienzo.Cursor = WinForms.Cursors.Cross;
                panelLienzo.Invalidate();
            }

            RecalcularOmisionesExtremosGruposLongitudinales();
            if (!string.IsNullOrWhiteSpace(grupoFinalizado))
                SeleccionarGrupoLongitudinalCompleto(grupoFinalizado);

            if (publicar)
            {
                ActualizarResumen();
                PublicarCambiosIncrustados();
                NotificarEstadoSeleccionTipoCambiado();
            }

            if (lblEstado != null)
            {
                lblEstado.Text =
                    "Extremo del conjunto actualizado. Puede jalar el otro extremo, usar doble clic para cambiar la regla o ejecutar el acero.";
            }
        }

        private void DibujarControlesExtremosGrupoLongitudinal(
            Drawing.Graphics g)
        {
            if (g == null ||
                modoEditorActual !=
                    AceroVigaModoEditorInicial.Longitudinales)
            {
                return;
            }

            if (idsGruposLongitudinalesSeleccionados.Count > 1 ||
                idsBarrasLongitudinalesSeleccionadas.Count > 0)
            {
                return;
            }

            string grupoId = ObtenerGrupoLongitudinalSeleccionadoId();
            if (string.IsNullOrWhiteSpace(grupoId))
                return;

            AceroVigaPuntoMm inicio;
            AceroVigaPuntoMm fin;
            AceroVigaGuiaCapaLongitudinal2D guia;
            List<AceroVigaPuntoMm> puntosGuia;
            List<AceroVigaPuntoMm> permitido;
            if (!TryObtenerExtremosGrupoLongitudinal(
                    grupoId,
                    out inicio,
                    out fin,
                    out guia,
                    out puntosGuia,
                    out permitido))
            {
                return;
            }

            Drawing.PointF a = ConvertirModeloAPantalla(inicio);
            Drawing.PointF b = ConvertirModeloAPantalla(fin);

            using (Drawing.Pen linea = new Drawing.Pen(
                Drawing.Color.FromArgb(255, 145, 0),
                1.6F))
            using (Drawing.SolidBrush rellenoInicio =
                new Drawing.SolidBrush(
                    Drawing.Color.FromArgb(0, 145, 220)))
            using (Drawing.SolidBrush rellenoFin =
                new Drawing.SolidBrush(
                    Drawing.Color.FromArgb(220, 45, 135)))
            using (Drawing.Pen borde = new Drawing.Pen(
                Drawing.Color.White,
                1.5F))
            using (Drawing.Font fuente = new Drawing.Font(
                "Segoe UI",
                7.2F,
                Drawing.FontStyle.Bold))
            using (Drawing.SolidBrush texto = new Drawing.SolidBrush(
                Drawing.Color.FromArgb(50, 50, 50)))
            using (Drawing.SolidBrush fondo = new Drawing.SolidBrush(
                Drawing.Color.FromArgb(225, 255, 255, 255)))
            {
                linea.DashStyle = Drawing2D.DashStyle.Dash;
                g.DrawLine(linea, a, b);

                const float r = 7F;
                g.FillRectangle(
                    rellenoInicio,
                    a.X - r,
                    a.Y - r,
                    2F * r,
                    2F * r);
                g.DrawRectangle(
                    borde,
                    a.X - r,
                    a.Y - r,
                    2F * r,
                    2F * r);

                Drawing.PointF[] rombo =
                {
                    new Drawing.PointF(b.X, b.Y - r - 1F),
                    new Drawing.PointF(b.X + r + 1F, b.Y),
                    new Drawing.PointF(b.X, b.Y + r + 1F),
                    new Drawing.PointF(b.X - r - 1F, b.Y)
                };
                g.FillPolygon(rellenoFin, rombo);
                g.DrawPolygon(borde, rombo);

                string textoInicio = "INICIO";
                string textoFin = "FINAL";
                Drawing.SizeF tamInicio =
                    g.MeasureString(textoInicio, fuente);
                Drawing.SizeF tamFin =
                    g.MeasureString(textoFin, fuente);

                Drawing.RectangleF cajaInicio = new Drawing.RectangleF(
                    a.X + 9F,
                    a.Y - tamInicio.Height - 7F,
                    tamInicio.Width + 6F,
                    tamInicio.Height + 3F);
                Drawing.RectangleF cajaFin = new Drawing.RectangleF(
                    b.X + 9F,
                    b.Y - tamFin.Height - 7F,
                    tamFin.Width + 6F,
                    tamFin.Height + 3F);
                g.FillRectangle(fondo, cajaInicio);
                g.FillRectangle(fondo, cajaFin);
                g.DrawString(
                    textoInicio,
                    fuente,
                    texto,
                    cajaInicio.X + 3F,
                    cajaInicio.Y + 1F);
                g.DrawString(
                    textoFin,
                    fuente,
                    texto,
                    cajaFin.X + 3F,
                    cajaFin.Y + 1F);
            }
        }

        private void DetectarSeleccion(AceroVigaPuntoMm punto)
        {
            idSeleccionado = string.Empty;
            idsEstribosSeleccionados.Clear();
            indiceVerticeSeleccionado = -1;
            double tolerancia = ObtenerToleranciaModelo(12.0F);
            double mejor = double.MaxValue;

            if (modoEditorActual == AceroVigaModoEditorInicial.Longitudinales)
            {
                AceroVigaBarraLongitudinal2D barraDetectada;
                if (TryDetectarBarraLongitudinalEnPunto(
                        punto,
                        out barraDetectada))
                {
                    SeleccionarSoloLongitudinal(barraDetectada);

                    if (lblEstado != null &&
                        !string.IsNullOrWhiteSpace(
                            barraDetectada.GrupoDistribucionId))
                    {
                        int cantidadVisible =
                            disenoTrabajo.Longitudinales.Count(x =>
                                x != null && !x.OcultaPorSuperposicion &&
                                string.Equals(
                                    x.GrupoDistribucionId,
                                    barraDetectada.GrupoDistribucionId,
                                    StringComparison.Ordinal));
                        lblEstado.Text =
                            "Conjunto longitudinal seleccionado: " +
                            cantidadVisible +
                            " barra(s) visibles. Ctrl permite agregar otros conjuntos.";
                    }
                }
                else
                {
                    LimpiarSeleccionLongitudinal(false);
                    TrySeleccionarGuiaCapaCercana(punto);
                    NotificarEstadoSeleccionTipoCambiado();
                }

                return;
            }

            string idEstribo;
            int indiceVertice;
            if (TryDetectarEstriboEnPunto(
                    punto,
                    out idEstribo,
                    out indiceVertice))
            {
                SeleccionarSoloEstribo(idEstribo, indiceVertice);
            }
            else
            {
                LimpiarSeleccionEstribos(false);
                NotificarEstadoSeleccionTipoCambiado();
            }
        }

        private void EliminarSeleccionado()
        {
            if (modoEditorActual == AceroVigaModoEditorInicial.Estribos)
            {
                HashSet<string> ids = new HashSet<string>(
                    idsEstribosSeleccionados,
                    StringComparer.Ordinal);

                if (!string.IsNullOrWhiteSpace(idSeleccionado))
                    ids.Add(idSeleccionado);

                if (ids.Count == 0)
                    return;

                RegistrarHistorial();
                disenoTrabajo.Estribos.RemoveAll(elemento =>
                    elemento != null &&
                    !string.IsNullOrWhiteSpace(elemento.Id) &&
                    ids.Contains(elemento.Id));

                LimpiarSeleccionEstribos(false);
                ActualizarResumen();
                NotificarEstadoSeleccionTipoCambiado();
                panelLienzo.Invalidate();
                return;
            }

            HashSet<string> gruposEliminar = new HashSet<string>(
                idsGruposLongitudinalesSeleccionados,
                StringComparer.Ordinal);
            HashSet<string> barrasEliminar = new HashSet<string>(
                idsBarrasLongitudinalesSeleccionadas,
                StringComparer.Ordinal);

            if (!string.IsNullOrWhiteSpace(idSeleccionado))
            {
                AceroVigaBarraLongitudinal2D primaria =
                    disenoTrabajo.Longitudinales.FirstOrDefault(elemento =>
                        elemento != null && elemento.Id == idSeleccionado);
                if (primaria != null)
                {
                    if (!string.IsNullOrWhiteSpace(
                            primaria.GrupoDistribucionId))
                        gruposEliminar.Add(primaria.GrupoDistribucionId);
                    else
                        barrasEliminar.Add(primaria.Id);
                }
            }

            if (gruposEliminar.Count == 0 && barrasEliminar.Count == 0)
                return;

            RegistrarHistorial();

            disenoTrabajo.Longitudinales.RemoveAll(elemento =>
                elemento != null &&
                ((!string.IsNullOrWhiteSpace(elemento.GrupoDistribucionId) &&
                  gruposEliminar.Contains(elemento.GrupoDistribucionId)) ||
                 (string.IsNullOrWhiteSpace(elemento.GrupoDistribucionId) &&
                  barrasEliminar.Contains(elemento.Id))));

            if (disenoTrabajo.GruposLongitudinales != null)
            {
                disenoTrabajo.GruposLongitudinales.RemoveAll(grupo =>
                    grupo != null && gruposEliminar.Contains(grupo.Id));
            }

            LimpiarSeleccionLongitudinal(false);
            RecalcularOmisionesExtremosGruposLongitudinales();
            ActualizarResumen();
            NotificarEstadoSeleccionTipoCambiado();
            panelLienzo.Invalidate();
        }

        private Drawing.Color ObtenerColorPorTipoBarra(RebarBarType tipo)
        {
            double diametroMm = ObtenerDiametroMm(tipo);
            int clave = (int)Math.Round(diametroMm);

            if (clave <= 6) return Drawing.Color.FromArgb(0, 135, 210);
            if (clave <= 8) return Drawing.Color.FromArgb(0, 150, 115);
            if (clave <= 10) return Drawing.Color.FromArgb(190, 145, 0);
            if (clave <= 13) return Drawing.Color.FromArgb(225, 95, 30);
            if (clave <= 16) return Drawing.Color.FromArgb(205, 45, 90);
            if (clave <= 20) return Drawing.Color.FromArgb(125, 70, 180);
            if (clave <= 26) return Drawing.Color.FromArgb(45, 70, 165);
            if (clave <= 32) return Drawing.Color.FromArgb(0, 105, 115);

            int r = 55 + (clave * 47) % 155;
            int g = 55 + (clave * 71) % 155;
            int b = 55 + (clave * 97) % 155;
            return Drawing.Color.FromArgb(r, g, b);
        }

        private float ObtenerDiametroPantalla(
            RebarBarType tipo,
            float minimo)
        {
            double diametroMm = ObtenerDiametroMm(tipo);
            if (diametroMm <= Tol)
                return minimo;

            float pixeles = (float)(diametroMm * EscalaActual());
            return Math.Max(minimo, Math.Min(18F, pixeles));
        }

        private string ObtenerTextoTipoDiametro(RebarBarType tipo)
        {
            if (tipo == null)
                return "Sin tipo";

            return tipo.Name + " · " +
                ObtenerDiametroMm(tipo).ToString(
                    "0.#",
                    CultureInfo.CurrentCulture) +
                " mm";
        }

        private bool ListaContieneTipoBarra(
            List<RebarBarType> tipos,
            RebarBarType tipo)
        {
            if (tipos == null || tipo == null)
                return false;

            foreach (RebarBarType existente in tipos)
            {
                if (existente == null)
                    continue;

                try
                {
                    if (existente.Id.Value == tipo.Id.Value)
                        return true;
                }
                catch
                {
                    if (ReferenceEquals(existente, tipo))
                        return true;
                }
            }

            return false;
        }

        private void AgregarTipoLeyenda(
            List<RebarBarType> tipos,
            RebarBarType tipo)
        {
            if (tipo != null && !ListaContieneTipoBarra(tipos, tipo))
                tipos.Add(tipo);
        }

        private void DibujarLeyendaDiametros(Drawing.Graphics g)
        {
            if (g == null || panelLienzo == null)
                return;

            List<RebarBarType> tipos = new List<RebarBarType>();

            foreach (AceroVigaBarraLongitudinal2D barra
                in disenoTrabajo.Longitudinales)
            {
                if (barra != null)
                    AgregarTipoLeyenda(
                        tipos,
                        barra.TipoBarra ?? TipoLongitudinalActual);
            }

            foreach (AceroVigaEstribo2D estribo
                in disenoTrabajo.Estribos)
            {
                if (estribo != null)
                    AgregarTipoLeyenda(
                        tipos,
                        estribo.TipoBarra ?? TipoEstriboActual);
            }

            // La leyenda se mantiene visible desde el inicio, igual que una
            // paleta de trabajo: muestra como mínimo el tipo activo de la pestaña.
            if (modoEditorActual == AceroVigaModoEditorInicial.Estribos)
                AgregarTipoLeyenda(tipos, TipoEstriboActual);
            else
                AgregarTipoLeyenda(tipos, TipoLongitudinalActual);

            if (tipos.Count == 0)
                return;

            tipos.Sort((a, b) =>
                ObtenerDiametroMm(a).CompareTo(ObtenerDiametroMm(b)));

            using (Drawing.Font fuente = new Drawing.Font(
                "Segoe UI",
                7.5F,
                Drawing.FontStyle.Regular))
            using (Drawing.Font fuenteTitulo = new Drawing.Font(
                "Segoe UI",
                7.5F,
                Drawing.FontStyle.Bold))
            {
                float anchoMaximo = g.MeasureString(
                    "LEYENDA DE ACEROS",
                    fuenteTitulo).Width;

                foreach (RebarBarType tipo in tipos)
                {
                    anchoMaximo = Math.Max(
                        anchoMaximo,
                        g.MeasureString(
                            ObtenerTextoTipoDiametro(tipo),
                            fuente).Width);
                }

                float anchoCaja = anchoMaximo + 40F;
                float altoCaja = 28F + tipos.Count * 20F;
                float x = panelLienzo.ClientSize.Width - anchoCaja - 12F;
                float y = panelLienzo.ClientSize.Height - altoCaja - 34F;

                x = Math.Max(8F, x);
                y = Math.Max(105F, y);

                using (Drawing.SolidBrush fondo = new Drawing.SolidBrush(
                    Drawing.Color.FromArgb(232, 255, 255, 255)))
                using (Drawing.Pen borde = new Drawing.Pen(
                    Drawing.Color.FromArgb(120, 120, 125),
                    1F))
                using (Drawing.SolidBrush textoTitulo = new Drawing.SolidBrush(
                    Drawing.Color.FromArgb(55, 55, 60)))
                {
                    g.FillRectangle(fondo, x, y, anchoCaja, altoCaja);
                    g.DrawRectangle(borde, x, y, anchoCaja, altoCaja);
                    g.DrawString(
                        "LEYENDA DE ACEROS",
                        fuenteTitulo,
                        textoTitulo,
                        x + 8F,
                        y + 5F);
                }

                for (int i = 0; i < tipos.Count; i++)
                {
                    RebarBarType tipo = tipos[i];
                    float filaY = y + 24F + i * 20F;
                    Drawing.Color color = ObtenerColorPorTipoBarra(tipo);
                    float d = Math.Max(
                        7F,
                        ObtenerDiametroPantalla(tipo, 5F));

                    using (Drawing.SolidBrush relleno =
                        new Drawing.SolidBrush(color))
                    using (Drawing.Pen borde =
                        new Drawing.Pen(Drawing.Color.White, 1F))
                    using (Drawing.SolidBrush texto =
                        new Drawing.SolidBrush(
                            Drawing.Color.FromArgb(55, 55, 60)))
                    {
                        g.FillEllipse(
                            relleno,
                            x + 8F,
                            filaY + 4F - d / 2F,
                            d,
                            d);
                        g.DrawEllipse(
                            borde,
                            x + 8F,
                            filaY + 4F - d / 2F,
                            d,
                            d);
                        g.DrawString(
                            ObtenerTextoTipoDiametro(tipo),
                            fuente,
                            texto,
                            x + 26F,
                            filaY - 3F);
                    }
                }
            }
        }

        private string ObtenerEtiquetaLimiteActual()
        {
            double recubrimientoCm = Math.Max(
                0.0,
                ObtenerRecubrimientoActivo());

            if (modoEditorActual == AceroVigaModoEditorInicial.Estribos)
            {
                double retiro = recubrimientoCm +
                    ObtenerDiametroMm(TipoEstriboActual) / 20.0;

                return "LÍMITE ESTRIBOS · OFFSET " +
                    retiro.ToString(
                        "0.##",
                        CultureInfo.CurrentCulture) +
                    " cm";
            }

            double retiroLongitudinal = recubrimientoCm +
                ObtenerDiametroMm(TipoEstriboActual) / 10.0 +
                ObtenerDiametroMm(TipoLongitudinalActual) / 20.0;

            return "LÍMITE LONGITUDINALES · OFFSET " +
                retiroLongitudinal.ToString(
                    "0.##",
                    CultureInfo.CurrentCulture) +
                " cm";
        }

        private void DibujarLimitePorRecubrimiento(
            Drawing.Graphics g,
            List<AceroVigaPuntoMm> contorno)
        {
            if (g == null || contorno == null || contorno.Count < 3)
                return;

            Drawing.PointF[] pantalla = contorno
                .Select(ConvertirModeloAPantalla)
                .ToArray();

            using (Drawing.Pen pen = new Drawing.Pen(
                Drawing.Color.FromArgb(100, 110, 120),
                1.6F))
            {
                pen.DashStyle = Drawing2D.DashStyle.Dash;
                pen.LineJoin = Drawing2D.LineJoin.Round;
                g.DrawPolygon(pen, pantalla);
            }

            AceroVigaPuntoMm anclaModelo = contorno
                .OrderBy(x => x.Y)
                .ThenByDescending(x => x.Z)
                .FirstOrDefault();

            if (anclaModelo == null)
                return;

            Drawing.PointF ancla = ConvertirModeloAPantalla(anclaModelo);
            string etiqueta = ObtenerEtiquetaLimiteActual();

            using (Drawing.Font fuente = new Drawing.Font(
                "Segoe UI",
                7.2F,
                Drawing.FontStyle.Bold))
            using (Drawing.SolidBrush fondo = new Drawing.SolidBrush(
                Drawing.Color.FromArgb(235, 250, 250, 250)))
            using (Drawing.SolidBrush texto = new Drawing.SolidBrush(
                Drawing.Color.FromArgb(95, 100, 110)))
            {
                Drawing.SizeF tam = g.MeasureString(etiqueta, fuente);
                float x = ancla.X + 8F;
                float y = ancla.Y - tam.Height - 6F;

                if (y < 30F)
                    y = ancla.Y + 6F;

                if (x + tam.Width + 8F > panelLienzo.ClientSize.Width)
                    x = Math.Max(8F, ancla.X - tam.Width - 8F);

                g.FillRectangle(
                    fondo,
                    x - 3F,
                    y - 1F,
                    tam.Width + 6F,
                    tam.Height + 2F);
                g.DrawString(etiqueta, fuente, texto, x, y);
            }
        }

        private void DibujarEncabezadoVista(Drawing.Graphics g)
        {
            string titulo = modoEditorActual == AceroVigaModoEditorInicial.Estribos
                ? "VISTA EN PLANTA - ESTRIBOS"
                : "VISTA EN PLANTA - LONGITUDINALES";

            using (Drawing.Font fuente = new Drawing.Font(
                "Segoe UI",
                9F,
                Drawing.FontStyle.Bold))
            using (Drawing.SolidBrush brocha = new Drawing.SolidBrush(
                Drawing.Color.FromArgb(80, 80, 80)))
            {
                g.DrawString(titulo, fuente, brocha, 14F, 12F);
            }

            string referencia = disenoTrabajo.NombreSeccionReferencia ??
                string.Empty;

            if (disenoTrabajo.AnchoReferenciaMm > Tol &&
                disenoTrabajo.AltoReferenciaMm > Tol)
            {
                string dimensiones =
                    disenoTrabajo.AnchoReferenciaMm.ToString(
                        "0.#",
                        CultureInfo.CurrentCulture) +
                    " × " +
                    disenoTrabajo.AltoReferenciaMm.ToString(
                        "0.#",
                        CultureInfo.CurrentCulture) +
                    " mm";

                referencia = string.IsNullOrWhiteSpace(referencia)
                    ? dimensiones
                    : referencia + "  |  " + dimensiones;
            }

            if (!string.IsNullOrWhiteSpace(referencia))
            {
                using (Drawing.Font fuente = new Drawing.Font(
                    "Segoe UI",
                    7.5F))
                using (Drawing.SolidBrush brocha = new Drawing.SolidBrush(
                    Drawing.Color.FromArgb(105, 105, 105)))
                {
                    Drawing.SizeF tam = g.MeasureString(referencia, fuente);
                    g.DrawString(
                        referencia,
                        fuente,
                        brocha,
                        Math.Max(14F,
                            panelLienzo.ClientSize.Width - tam.Width - 14F),
                        14F);
                }
            }
        }

        private AceroVigaPuntoMm NormalizarVectorMm(AceroVigaPuntoMm vector)
        {
            if (vector == null)
                return new AceroVigaPuntoMm();

            double longitud = Math.Sqrt(
                vector.Y * vector.Y +
                vector.Z * vector.Z);

            if (longitud <= Tol)
                return new AceroVigaPuntoMm();

            return new AceroVigaPuntoMm(
                vector.Y / longitud,
                vector.Z / longitud);
        }

        private AceroVigaPuntoMm CentroPromedio(
            List<AceroVigaPuntoMm> puntos)
        {
            if (puntos == null || puntos.Count == 0)
                return new AceroVigaPuntoMm();

            return new AceroVigaPuntoMm(
                puntos.Average(x => x.Y),
                puntos.Average(x => x.Z));
        }

        private double ObtenerRadioDobladoEjeEstriboMm(
            RebarBarType tipo)
        {
            if (tipo == null)
                return 1.0;

            double diametroModeloFt = 0.0;
            double diametroDobladoInteriorFt = 0.0;

            try
            {
                diametroModeloFt = tipo.BarModelDiameter;
            }
            catch
            {
            }

            if (diametroModeloFt <= Tol)
            {
                diametroModeloFt = UnitUtils.ConvertToInternalUnits(
                    Math.Max(ObtenerDiametroMm(tipo), 1.0),
                    UnitTypeId.Millimeters);
            }

            try
            {
                diametroDobladoInteriorFt = tipo.StirrupTieBendDiameter;
            }
            catch
            {
            }

            if (diametroDobladoInteriorFt <= Tol)
            {
                try
                {
                    Parameter parametro = tipo.get_Parameter(
                        BuiltInParameter.REBAR_BAR_STIRRUP_BEND_DIAMETER);

                    if (parametro != null &&
                        parametro.StorageType == StorageType.Double)
                    {
                        diametroDobladoInteriorFt = parametro.AsDouble();
                    }
                }
                catch
                {
                }
            }

            if (diametroDobladoInteriorFt <= Tol)
                diametroDobladoInteriorFt = diametroModeloFt * 4.0;

            double radioEjeFt =
                diametroDobladoInteriorFt * 0.5 +
                diametroModeloFt * 0.5;

            return Math.Max(radioEjeFt * 304.8, 1.0);
        }

        private double ObtenerDiametroLongitudinalCercanoMm(
            AceroVigaPuntoMm centro)
        {
            if (centro == null || disenoTrabajo == null ||
                disenoTrabajo.Longitudinales == null)
            {
                return ObtenerDiametroMm(TipoLongitudinalActual);
            }

            double mejor = double.MaxValue;
            double diametro = ObtenerDiametroMm(TipoLongitudinalActual);

            foreach (AceroVigaBarraLongitudinal2D barra in
                disenoTrabajo.Longitudinales)
            {
                if (barra == null || barra.Punto == null ||
                    barra.OcultaPorSuperposicion)
                    continue;

                List<AceroVigaPuntoMm> contorno =
                    ObtenerContornoCentrosLongitudinalMm(
                        barra.TipoBarra ?? TipoLongitudinalActual);
                if (contorno == null || contorno.Count < 3)
                    continue;

                AceroVigaPuntoMm puntoBarra =
                    DesnormalizarEnCaja(barra.Punto, contorno);
                double distancia = Distancia(centro, puntoBarra);

                if (distancia < mejor)
                {
                    mejor = distancia;
                    diametro = barra.DiametroMm > Tol
                        ? barra.DiametroMm
                        : ObtenerDiametroMm(
                            barra.TipoBarra ?? TipoLongitudinalActual);
                }
            }

            return Math.Max(diametro, 1.0);
        }

        private bool CalcularGeometriaGanchoLongitudinalesViga(
            AceroVigaEstribo2D gancho,
            AceroVigaPuntoMm centroInicio,
            AceroVigaPuntoMm centroFin,
            bool tipoS,
            out AceroVigaPuntoMm inicioCuerpo,
            out AceroVigaPuntoMm finCuerpo,
            out AceroVigaPuntoMm tangenciaInicio,
            out AceroVigaPuntoMm tangenciaFin)
        {
            inicioCuerpo = null;
            finCuerpo = null;
            tangenciaInicio = null;
            tangenciaFin = null;

            if (gancho == null || centroInicio == null || centroFin == null)
                return false;

            AceroVigaPuntoMm direccionCentros = NormalizarVectorMm(
                new AceroVigaPuntoMm(
                    centroFin.Y - centroInicio.Y,
                    centroFin.Z - centroInicio.Z));

            if (Math.Abs(direccionCentros.Y) +
                Math.Abs(direccionCentros.Z) <= Tol)
            {
                return false;
            }

            AceroVigaPuntoMm normalIzquierda = new AceroVigaPuntoMm(
                -direccionCentros.Z,
                direccionCentros.Y);
            AceroVigaPuntoMm centroSeccion =
                CentroPromedio(contornoConcretoMm);
            AceroVigaPuntoMm puntoMedio = new AceroVigaPuntoMm(
                (centroInicio.Y + centroFin.Y) * 0.5,
                (centroInicio.Z + centroFin.Z) * 0.5);

            double productoInterior =
                normalIzquierda.Y * (centroSeccion.Y - puntoMedio.Y) +
                normalIzquierda.Z * (centroSeccion.Z - puntoMedio.Z);
            double signoInterior = productoInterior >= 0.0 ? 1.0 : -1.0;
            AceroVigaPuntoMm normalInterior = new AceroVigaPuntoMm(
                normalIzquierda.Y * signoInterior,
                normalIzquierda.Z * signoInterior);

            double diametroEstribo = gancho.DiametroMm > Tol
                ? gancho.DiametroMm
                : ObtenerDiametroMm(gancho.TipoBarra ?? TipoEstriboActual);
            double diametroInicio = gancho.DiametroLongitudinalInicioMm > Tol
                ? gancho.DiametroLongitudinalInicioMm
                : ObtenerDiametroLongitudinalCercanoMm(centroInicio);
            double diametroFin = gancho.DiametroLongitudinalFinMm > Tol
                ? gancho.DiametroLongitudinalFinMm
                : ObtenerDiametroLongitudinalCercanoMm(centroFin);

            double radioContactoInicio = Math.Max(
                (diametroInicio + diametroEstribo) * 0.5,
                0.5);
            double radioContactoFin = Math.Max(
                (diametroFin + diametroEstribo) * 0.5,
                0.5);
            double radioDobladoEje = ObtenerRadioDobladoEjeEstriboMm(
                gancho.TipoBarra ?? TipoEstriboActual);
            double distanciaEntreCentros = Distancia(
                centroInicio,
                centroFin);

            AceroVigaPuntoMm baseInicio;
            AceroVigaPuntoMm baseFin;

            if (tipoS && TryCalcularCuerpoGanchoSLongitudinalesViga(
                centroInicio,
                centroFin,
                radioDobladoEje,
                normalInterior,
                out baseInicio,
                out baseFin))
            {
                tangenciaInicio = baseInicio.Copiar();
                tangenciaFin = baseFin.Copiar();
            }
            else
            {
                tangenciaInicio = new AceroVigaPuntoMm(
                    centroInicio.Y + normalInterior.Y * radioContactoInicio,
                    centroInicio.Z + normalInterior.Z * radioContactoInicio);
                tangenciaFin = new AceroVigaPuntoMm(
                    centroFin.Y + normalInterior.Y * radioContactoFin *
                        (tipoS ? -1.0 : 1.0),
                    centroFin.Z + normalInterior.Z * radioContactoFin *
                        (tipoS ? -1.0 : 1.0));
                baseInicio = tangenciaInicio.Copiar();
                baseFin = tangenciaFin.Copiar();
            }

            AceroVigaPuntoMm tangenteCuerpo = NormalizarVectorMm(
                new AceroVigaPuntoMm(
                    baseFin.Y - baseInicio.Y,
                    baseFin.Z - baseInicio.Z));

            if (Math.Abs(tangenteCuerpo.Y) +
                Math.Abs(tangenteCuerpo.Z) <= Tol)
            {
                return false;
            }

            double extensionInicio = CalcularExtensionAmarreGanchoViga(
                radioContactoInicio,
                radioDobladoEje,
                distanciaEntreCentros);
            double extensionFin = CalcularExtensionAmarreGanchoViga(
                radioContactoFin,
                radioDobladoEje,
                distanciaEntreCentros);

            inicioCuerpo = new AceroVigaPuntoMm(
                baseInicio.Y - tangenteCuerpo.Y * extensionInicio,
                baseInicio.Z - tangenteCuerpo.Z * extensionInicio);
            finCuerpo = new AceroVigaPuntoMm(
                baseFin.Y + tangenteCuerpo.Y * extensionFin,
                baseFin.Z + tangenteCuerpo.Z * extensionFin);

            inicioCuerpo = LimitarPuntoEnDireccionDentroContornoViga(
                baseInicio,
                inicioCuerpo,
                contornoConcretoMm);
            finCuerpo = LimitarPuntoEnDireccionDentroContornoViga(
                baseFin,
                finCuerpo,
                contornoConcretoMm);

            return Distancia(inicioCuerpo, finCuerpo) > Tol;
        }

        private bool TryCalcularCuerpoGanchoSLongitudinalesViga(
            AceroVigaPuntoMm centroInicio,
            AceroVigaPuntoMm centroFin,
            double radioCurvatura,
            AceroVigaPuntoMm normalInterior,
            out AceroVigaPuntoMm inicioCuerpo,
            out AceroVigaPuntoMm finCuerpo)
        {
            inicioCuerpo = null;
            finCuerpo = null;

            double distanciaCentros = Distancia(centroInicio, centroFin);
            radioCurvatura = Math.Max(radioCurvatura, 0.5);

            if (distanciaCentros <= 2.0 * radioCurvatura + Tol)
                return false;

            AceroVigaPuntoMm ejeCentros = NormalizarVectorMm(
                new AceroVigaPuntoMm(
                    centroFin.Y - centroInicio.Y,
                    centroFin.Z - centroInicio.Z));
            AceroVigaPuntoMm normalEje = new AceroVigaPuntoMm(
                -ejeCentros.Z,
                ejeCentros.Y);

            double seno = Math.Max(
                0.0,
                Math.Min(0.999999, 2.0 * radioCurvatura / distanciaCentros));
            double coseno = Math.Sqrt(Math.Max(0.0, 1.0 - seno * seno));

            AceroVigaPuntoMm tangenteA = NormalizarVectorMm(
                new AceroVigaPuntoMm(
                    ejeCentros.Y * coseno + normalEje.Y * seno,
                    ejeCentros.Z * coseno + normalEje.Z * seno));
            AceroVigaPuntoMm normalA = new AceroVigaPuntoMm(
                -tangenteA.Z,
                tangenteA.Y);
            AceroVigaPuntoMm inicioA = new AceroVigaPuntoMm(
                centroInicio.Y - normalA.Y * radioCurvatura,
                centroInicio.Z - normalA.Z * radioCurvatura);
            AceroVigaPuntoMm finA = new AceroVigaPuntoMm(
                centroFin.Y + normalA.Y * radioCurvatura,
                centroFin.Z + normalA.Z * radioCurvatura);

            AceroVigaPuntoMm tangenteB = NormalizarVectorMm(
                new AceroVigaPuntoMm(
                    ejeCentros.Y * coseno - normalEje.Y * seno,
                    ejeCentros.Z * coseno - normalEje.Z * seno));
            AceroVigaPuntoMm normalB = new AceroVigaPuntoMm(
                -tangenteB.Z,
                tangenteB.Y);
            AceroVigaPuntoMm inicioB = new AceroVigaPuntoMm(
                centroInicio.Y + normalB.Y * radioCurvatura,
                centroInicio.Z + normalB.Z * radioCurvatura);
            AceroVigaPuntoMm finB = new AceroVigaPuntoMm(
                centroFin.Y - normalB.Y * radioCurvatura,
                centroFin.Z - normalB.Z * radioCurvatura);

            AceroVigaPuntoMm referenciaInicio = new AceroVigaPuntoMm(
                centroInicio.Y + normalInterior.Y * radioCurvatura,
                centroInicio.Z + normalInterior.Z * radioCurvatura);
            AceroVigaPuntoMm referenciaFin = new AceroVigaPuntoMm(
                centroFin.Y - normalInterior.Y * radioCurvatura,
                centroFin.Z - normalInterior.Z * radioCurvatura);

            double puntajeA =
                Distancia(inicioA, referenciaInicio) +
                Distancia(finA, referenciaFin);
            double puntajeB =
                Distancia(inicioB, referenciaInicio) +
                Distancia(finB, referenciaFin);

            if (PuntoDentroPoligono(inicioA, contornoConcretoMm) &&
                PuntoDentroPoligono(finA, contornoConcretoMm))
            {
                puntajeA -= distanciaCentros;
            }

            if (PuntoDentroPoligono(inicioB, contornoConcretoMm) &&
                PuntoDentroPoligono(finB, contornoConcretoMm))
            {
                puntajeB -= distanciaCentros;
            }

            if (puntajeA <= puntajeB)
            {
                inicioCuerpo = inicioA;
                finCuerpo = finA;
            }
            else
            {
                inicioCuerpo = inicioB;
                finCuerpo = finB;
            }

            return Distancia(inicioCuerpo, finCuerpo) > Tol;
        }

        private double CalcularExtensionAmarreGanchoViga(
            double radioContacto,
            double radioDobladoEje,
            double distanciaEntreCentros)
        {
            double senoMedio = Math.Sin(135.0 * Math.PI / 360.0);
            double extension =
                radioContacto +
                radioDobladoEje *
                ((1.0 / Math.Max(senoMedio, 0.20)) - 1.0);
            double limite = Math.Max(
                radioContacto,
                distanciaEntreCentros * 0.25);
            return Math.Max(radioContacto, Math.Min(extension, limite));
        }

        private AceroVigaPuntoMm LimitarPuntoEnDireccionDentroContornoViga(
            AceroVigaPuntoMm origenDentro,
            AceroVigaPuntoMm candidato,
            List<AceroVigaPuntoMm> contorno)
        {
            if (origenDentro == null || candidato == null ||
                contorno == null || contorno.Count < 3)
            {
                return candidato;
            }

            if (PuntoDentroPoligono(candidato, contorno))
                return candidato;

            double inferior = 0.0;
            double superior = 1.0;
            AceroVigaPuntoMm mejor = origenDentro.Copiar();

            for (int i = 0; i < 32; i++)
            {
                double t = (inferior + superior) * 0.5;
                AceroVigaPuntoMm prueba = new AceroVigaPuntoMm(
                    origenDentro.Y + (candidato.Y - origenDentro.Y) * t,
                    origenDentro.Z + (candidato.Z - origenDentro.Z) * t);

                if (PuntoDentroPoligono(prueba, contorno))
                {
                    inferior = t;
                    mejor = prueba;
                }
                else
                {
                    superior = t;
                }
            }

            return mejor;
        }

        private void DibujarGanchoAdaptadoLongitudinalesViga(
            Drawing.Graphics g,
            AceroVigaEstribo2D gancho,
            AceroVigaPuntoMm centroInicio,
            AceroVigaPuntoMm centroFin,
            Drawing.Color color,
            float espesor,
            bool tipoS,
            bool preview)
        {
            AceroVigaPuntoMm inicioCuerpo;
            AceroVigaPuntoMm finCuerpo;
            AceroVigaPuntoMm tangenciaInicio;
            AceroVigaPuntoMm tangenciaFin;

            if (!CalcularGeometriaGanchoLongitudinalesViga(
                gancho,
                centroInicio,
                centroFin,
                tipoS,
                out inicioCuerpo,
                out finCuerpo,
                out tangenciaInicio,
                out tangenciaFin))
            {
                return;
            }

            Drawing.PointF centroPantallaInicio =
                ConvertirModeloAPantalla(centroInicio);
            Drawing.PointF centroPantallaFin =
                ConvertirModeloAPantalla(centroFin);
            Drawing.PointF inicioPantalla =
                ConvertirModeloAPantalla(inicioCuerpo);
            Drawing.PointF finPantalla =
                ConvertirModeloAPantalla(finCuerpo);
            Drawing.PointF tangenciaPantallaInicio =
                ConvertirModeloAPantalla(tangenciaInicio);
            Drawing.PointF tangenciaPantallaFin =
                ConvertirModeloAPantalla(tangenciaFin);

            using (Drawing.Pen pen = new Drawing.Pen(color, espesor))
            using (Drawing.Font fuente = new Drawing.Font(
                "Segoe UI",
                7.5F,
                Drawing.FontStyle.Bold))
            using (Drawing.SolidBrush brocha = new Drawing.SolidBrush(color))
            {
                pen.LineJoin = Drawing2D.LineJoin.Round;
                pen.StartCap = Drawing2D.LineCap.Round;
                pen.EndCap = Drawing2D.LineCap.Round;
                if (preview)
                    pen.DashStyle = Drawing2D.DashStyle.Dash;

                g.DrawLine(pen, inicioPantalla, finPantalla);

                float sentidoInicio = 1F;
                float sentidoFin = tipoS ? -1F : 1F;

                DibujarAbrazoGanchoViga(
                    g,
                    pen,
                    centroPantallaInicio,
                    inicioPantalla,
                    tangenciaPantallaInicio,
                    sentidoInicio);
                DibujarAbrazoGanchoViga(
                    g,
                    pen,
                    centroPantallaFin,
                    finPantalla,
                    tangenciaPantallaFin,
                    sentidoFin);

                float x = (inicioPantalla.X + finPantalla.X) * 0.5F;
                float y = (inicioPantalla.Y + finPantalla.Y) * 0.5F;
                g.DrawString(tipoS ? "S" : "C", fuente, brocha, x + 5F, y + 5F);
            }
        }

        private void DibujarAbrazoGanchoViga(
            Drawing.Graphics g,
            Drawing.Pen pen,
            Drawing.PointF centroBarra,
            Drawing.PointF extremoCuerpo,
            Drawing.PointF puntoTangencia,
            float sentidoLateral)
        {
            float rx = puntoTangencia.X - centroBarra.X;
            float ry = puntoTangencia.Y - centroBarra.Y;
            float radio = (float)Math.Sqrt(rx * rx + ry * ry);

            if (radio <= 0.1F)
                return;

            rx /= radio;
            ry /= radio;
            float tx = -ry;
            float ty = rx;

            Drawing.PointF alrededor = new Drawing.PointF(
                centroBarra.X - rx * radio * 0.95F,
                centroBarra.Y - ry * radio * 0.95F);
            Drawing.PointF punta = new Drawing.PointF(
                centroBarra.X + tx * sentidoLateral * radio * 1.55F -
                    rx * radio * 0.10F,
                centroBarra.Y + ty * sentidoLateral * radio * 1.55F -
                    ry * radio * 0.10F);
            Drawing.PointF controlFinal = new Drawing.PointF(
                alrededor.X + tx * sentidoLateral * radio * 0.45F,
                alrededor.Y + ty * sentidoLateral * radio * 0.45F);

            g.DrawBezier(
                pen,
                extremoCuerpo,
                puntoTangencia,
                controlFinal,
                punta);
        }

        private void DibujarGanchosEstriboCerrado(
            Drawing.Graphics g,
            AceroVigaEstribo2D estribo,
            List<AceroVigaPuntoMm> puntos,
            Drawing.Color color,
            float espesor)
        {
            if (g == null || estribo == null || puntos == null ||
                !estribo.Cerrado || puntos.Count < 3)
            {
                return;
            }

            int indice = estribo.IndiceEsquinaGancho;
            if (indice < 0 || indice >= puntos.Count)
            {
                double mejor = double.MinValue;
                indice = 0;
                for (int i = 0; i < puntos.Count; i++)
                {
                    double puntaje = puntos[i].Y + puntos[i].Z;
                    if (puntaje > mejor)
                    {
                        mejor = puntaje;
                        indice = i;
                    }
                }
            }

            AceroVigaPuntoMm esquina = puntos[indice];
            AceroVigaPuntoMm anterior =
                puntos[(indice - 1 + puntos.Count) % puntos.Count];
            AceroVigaPuntoMm siguiente =
                puntos[(indice + 1) % puntos.Count];
            AceroVigaPuntoMm centro = CentroPromedio(puntos);

            AceroVigaPuntoMm interior = NormalizarVectorMm(
                new AceroVigaPuntoMm(
                    centro.Y - esquina.Y,
                    centro.Z - esquina.Z));
            AceroVigaPuntoMm haciaAnterior = NormalizarVectorMm(
                new AceroVigaPuntoMm(
                    anterior.Y - esquina.Y,
                    anterior.Z - esquina.Z));
            AceroVigaPuntoMm haciaSiguiente = NormalizarVectorMm(
                new AceroVigaPuntoMm(
                    siguiente.Y - esquina.Y,
                    siguiente.Z - esquina.Z));

            double longitudLado = Math.Min(
                Distancia(esquina, anterior),
                Distancia(esquina, siguiente));
            double longitudGancho = Math.Min(
                longitudLado * 0.30,
                Math.Max(
                    ObtenerToleranciaModelo(26F),
                    longitudLado * 0.12));

            AceroVigaPuntoMm direccion1 = NormalizarVectorMm(
                new AceroVigaPuntoMm(
                    interior.Y + haciaAnterior.Y * 0.45,
                    interior.Z + haciaAnterior.Z * 0.45));
            AceroVigaPuntoMm direccion2 = NormalizarVectorMm(
                new AceroVigaPuntoMm(
                    interior.Y + haciaSiguiente.Y * 0.45,
                    interior.Z + haciaSiguiente.Z * 0.45));

            AceroVigaPuntoMm punta1 = new AceroVigaPuntoMm(
                esquina.Y + direccion1.Y * longitudGancho,
                esquina.Z + direccion1.Z * longitudGancho);
            AceroVigaPuntoMm punta2 = new AceroVigaPuntoMm(
                esquina.Y + direccion2.Y * longitudGancho,
                esquina.Z + direccion2.Z * longitudGancho);

            using (Drawing.Pen pen = new Drawing.Pen(color, espesor))
            {
                pen.StartCap = Drawing2D.LineCap.Round;
                pen.EndCap = Drawing2D.LineCap.Round;
                g.DrawLine(
                    pen,
                    ConvertirModeloAPantalla(esquina),
                    ConvertirModeloAPantalla(punta1));
                g.DrawLine(
                    pen,
                    ConvertirModeloAPantalla(esquina),
                    ConvertirModeloAPantalla(punta2));
            }
        }

        private void DibujarLienzo(Drawing.Graphics g, Drawing.Rectangle area)
        {
            g.SmoothingMode = Drawing2D.SmoothingMode.AntiAlias;
            g.TextRenderingHint =
                System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            g.Clear(Drawing.Color.FromArgb(250, 250, 250));

            if (area.Width < 50 || area.Height < 50)
                return;

            DibujarEncabezadoVista(g);
            CalcularTransformacion(area);

            List<Drawing.PointF> contornoPantalla = contornoConcretoMm
                .Select(ConvertirModeloAPantalla)
                .ToList();

            using (Drawing.SolidBrush relleno = new Drawing.SolidBrush(
                Drawing.Color.FromArgb(226, 232, 238)))
            using (Drawing.Pen borde = new Drawing.Pen(
                Drawing.Color.FromArgb(45, 55, 65),
                2F))
            {
                borde.LineJoin = Drawing2D.LineJoin.Round;
                g.FillPolygon(relleno, contornoPantalla.ToArray());
                g.DrawPolygon(borde, contornoPantalla.ToArray());
            }

            List<AceroVigaPuntoMm> limite =
                modoEditorActual == AceroVigaModoEditorInicial.Estribos
                    ? ObtenerContornoEjeEstriboMm(TipoEstriboActual)
                    : ObtenerContornoCentrosLongitudinalMm(
                        TipoLongitudinalActual);

            DibujarLimitePorRecubrimiento(g, limite);
            DibujarGuiasCapasLongitudinales(g);
            DibujarEstribos(g);
            DibujarLongitudinales(g);
            DibujarPreviewDistribucionLongitudinal(g);
            DibujarCroquisActual(g);
            DibujarGuiasHerramientaYSnap(g);
            DibujarSeleccionRegionLongitudinal(g);
            DibujarSeleccionRegionEstribos(g);
            DibujarLeyendaDiametros(g);

            using (Drawing.Font fuente = new Drawing.Font("Segoe UI", 7.7F))
            using (Drawing.SolidBrush texto = new Drawing.SolidBrush(
                Drawing.Color.FromArgb(75, 75, 75)))
            {
                string leyenda =
                    "Concreto real  |  Línea discontinua: límite al eje del acero" +
                    "  |  Rueda: zoom  |  Botón central: desplazar";
                g.DrawString(
                    leyenda,
                    fuente,
                    texto,
                    12F,
                    panelLienzo.ClientSize.Height - 24F);
            }
        }

        private void DibujarGuiasHerramientaYSnap(Drawing.Graphics g)
        {
            if (g == null)
                return;

            bool previewGanchoLongitudinal = false;

            if ((herramienta == AceroVigaHerramientaEditor.GanchoC ||
                 herramienta == AceroVigaHerramientaEditor.GanchoS) &&
                primerPuntoHerramienta != null &&
                puntoSnapActual != null)
            {
                AceroVigaBarraLongitudinal2D barraFin;
                AceroVigaPuntoMm centroFin;

                if (TryObtenerBarraLongitudinalCercanaModelo(
                    puntoSnapActual,
                    30F,
                    out barraFin,
                    out centroFin) &&
                    centroFin != null &&
                    Distancia(primerPuntoHerramienta, centroFin) >
                        ObtenerToleranciaModelo(4F))
                {
                    AceroVigaEstribo2D temporal = new AceroVigaEstribo2D
                    {
                        Tipo = herramienta == AceroVigaHerramientaEditor.GanchoS
                            ? AceroVigaTipoEstribo2D.GanchoS
                            : AceroVigaTipoEstribo2D.GanchoC,
                        TipoBarra = TipoEstriboActual,
                        DiametroMm = ObtenerDiametroMm(TipoEstriboActual),
                        DiametroLongitudinalInicioMm =
                            Math.Max(diametroPrimerLongitudinalGanchoMm, Tol),
                        DiametroLongitudinalFinMm =
                            Math.Max(
                                barraFin.DiametroMm > Tol
                                    ? barraFin.DiametroMm
                                    : ObtenerDiametroMm(
                                        barraFin.TipoBarra ?? TipoLongitudinalActual),
                                Tol),
                        Cerrado = false
                    };

                    DibujarGanchoAdaptadoLongitudinalesViga(
                        g,
                        temporal,
                        primerPuntoHerramienta,
                        centroFin,
                        Drawing.Color.FromArgb(0, 120, 215),
                        2.4F,
                        temporal.Tipo == AceroVigaTipoEstribo2D.GanchoS,
                        true);

                    previewGanchoLongitudinal = true;
                }
            }

            AceroVigaPuntoMm baseGuia = creandoEstriboConArrastre
                ? puntoInicioArrastre
                : primerPuntoHerramienta;

            if (!previewGanchoLongitudinal &&
                baseGuia != null &&
                puntoSnapActual != null)
            {
                Drawing.PointF a =
                    ConvertirModeloAPantalla(baseGuia);
                Drawing.PointF b =
                    ConvertirModeloAPantalla(puntoSnapActual);

                using (Drawing.Pen pen = new Drawing.Pen(
                    Drawing.Color.FromArgb(0, 120, 215),
                    1.25F))
                {
                    pen.DashStyle = Drawing2D.DashStyle.Dash;
                    g.DrawLine(pen, a, b);
                }
            }

            DibujarVerticePrioritarioActual(g);

            if (puntoSnapActual == null)
                return;

            Drawing.PointF p =
                ConvertirModeloAPantalla(puntoSnapActual);
            DibujarSimboloSnap(g, p, textoSnapActual);

            if (!string.IsNullOrWhiteSpace(textoSnapActual))
            {
                bool etiquetaVertice =
                    textoSnapActual.IndexOf(
                        "Vértice",
                        StringComparison.OrdinalIgnoreCase) >= 0 ||
                    textoSnapActual.IndexOf(
                        "Punto base",
                        StringComparison.OrdinalIgnoreCase) >= 0 ||
                    textoSnapActual.IndexOf(
                        "Centro barra",
                        StringComparison.OrdinalIgnoreCase) >= 0;

                using (Drawing.Font fuente = new Drawing.Font(
                    "Segoe UI",
                    etiquetaVertice ? 8.2F : 7.5F,
                    Drawing.FontStyle.Bold))
                using (Drawing.SolidBrush fondo = new Drawing.SolidBrush(
                    etiquetaVertice
                        ? Drawing.Color.FromArgb(240, 255, 230, 245)
                        : Drawing.Color.FromArgb(235, 255, 255, 220)))
                using (Drawing.SolidBrush texto = new Drawing.SolidBrush(
                    etiquetaVertice
                        ? Drawing.Color.FromArgb(175, 20, 95)
                        : Drawing.Color.FromArgb(155, 55, 35)))
                {
                    Drawing.SizeF tam =
                        g.MeasureString(textoSnapActual, fuente);
                    Drawing.RectangleF caja = new Drawing.RectangleF(
                        p.X + 11F,
                        p.Y - tam.Height - 8F,
                        tam.Width + 8F,
                        tam.Height + 4F);

                    g.FillRectangle(fondo, caja);
                    g.DrawString(
                        textoSnapActual,
                        fuente,
                        texto,
                        caja.Left + 4F,
                        caja.Top + 2F);
                }
            }
        }

        private void DibujarVerticePrioritarioActual(
            Drawing.Graphics g)
        {
            if (g == null || verticePrioritarioActual == null)
                return;

            Drawing.PointF p =
                ConvertirModeloAPantalla(verticePrioritarioActual);

            Drawing.Color color = verticePrioritarioCapturado
                ? Drawing.Color.FromArgb(215, 35, 125)
                : Drawing.Color.FromArgb(0, 175, 150);

            using (Drawing.SolidBrush halo = new Drawing.SolidBrush(
                Drawing.Color.FromArgb(48, color)))
            using (Drawing.SolidBrush centro = new Drawing.SolidBrush(color))
            using (Drawing.Pen borde = new Drawing.Pen(color, 2.2F))
            using (Drawing.Pen bordeBlanco = new Drawing.Pen(
                Drawing.Color.White, 1.2F))
            {
                const float radioHalo = 11F;
                const float radioCentro = 4.5F;

                g.FillEllipse(
                    halo,
                    p.X - radioHalo,
                    p.Y - radioHalo,
                    radioHalo * 2F,
                    radioHalo * 2F);

                g.DrawEllipse(
                    borde,
                    p.X - 8F,
                    p.Y - 8F,
                    16F,
                    16F);

                g.FillRectangle(
                    centro,
                    p.X - radioCentro,
                    p.Y - radioCentro,
                    radioCentro * 2F,
                    radioCentro * 2F);

                g.DrawRectangle(
                    bordeBlanco,
                    p.X - radioCentro,
                    p.Y - radioCentro,
                    radioCentro * 2F,
                    radioCentro * 2F);
            }
        }

        private void DibujarSimboloSnap(
            Drawing.Graphics g,
            Drawing.PointF p,
            string tipo)
        {
            string texto = tipo ?? string.Empty;
            bool esVertice =
                texto.IndexOf("Vértice", StringComparison.OrdinalIgnoreCase) >= 0 ||
                texto.IndexOf("Punto base", StringComparison.OrdinalIgnoreCase) >= 0 ||
                texto.IndexOf("Centro barra", StringComparison.OrdinalIgnoreCase) >= 0;

            bool esPuntoMedio =
                texto.IndexOf("medio", StringComparison.OrdinalIgnoreCase) >= 0;
            bool esCercano =
                texto.IndexOf("Cercano", StringComparison.OrdinalIgnoreCase) >= 0;

            Drawing.Color color = esVertice
                ? Drawing.Color.FromArgb(215, 35, 125)
                : esPuntoMedio
                    ? Drawing.Color.FromArgb(0, 145, 220)
                    : esCercano
                        ? Drawing.Color.FromArgb(0, 155, 105)
                        : Drawing.Color.FromArgb(255, 145, 0);

            using (Drawing.Pen pen = new Drawing.Pen(color, esVertice ? 2.5F : 2F))
            {
                const float r = 6F;

                if (esVertice)
                {
                    using (Drawing.SolidBrush relleno =
                        new Drawing.SolidBrush(Drawing.Color.FromArgb(75, color)))
                    {
                        g.FillRectangle(
                            relleno,
                            p.X - r - 2F,
                            p.Y - r - 2F,
                            2F * r + 4F,
                            2F * r + 4F);
                    }
                    g.DrawRectangle(pen, p.X - r, p.Y - r, 2F * r, 2F * r);
                }
                else if (texto.IndexOf("Extremo", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    g.DrawRectangle(pen, p.X - r, p.Y - r, 2F * r, 2F * r);
                }
                else if (texto.IndexOf("medio", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    Drawing.PointF[] triangulo =
                    {
                        new Drawing.PointF(p.X, p.Y - r - 1F),
                        new Drawing.PointF(p.X - r, p.Y + r),
                        new Drawing.PointF(p.X + r, p.Y + r)
                    };
                    g.DrawPolygon(pen, triangulo);
                }
                else if (texto.IndexOf("Inter", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    g.DrawLine(pen, p.X - r, p.Y - r, p.X + r, p.Y + r);
                    g.DrawLine(pen, p.X - r, p.Y + r, p.X + r, p.Y - r);
                }
                else if (texto.IndexOf("Perp", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    g.DrawLine(pen, p.X - r, p.Y + r, p.X - r, p.Y - r);
                    g.DrawLine(pen, p.X - r, p.Y + r, p.X + r, p.Y + r);
                    g.DrawLine(pen, p.X - 2F, p.Y + 2F, p.X + 2F, p.Y + 2F);
                    g.DrawLine(pen, p.X - 2F, p.Y + 2F, p.X - 2F, p.Y - 2F);
                }
                else if (texto.IndexOf("Cercano", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    Drawing.PointF[] rombo =
                    {
                        new Drawing.PointF(p.X, p.Y - r),
                        new Drawing.PointF(p.X + r, p.Y),
                        new Drawing.PointF(p.X, p.Y + r),
                        new Drawing.PointF(p.X - r, p.Y)
                    };
                    g.DrawPolygon(pen, rombo);
                }
                else
                {
                    g.DrawEllipse(pen, p.X - r, p.Y - r, 2F * r, 2F * r);
                }
            }
        }

        private void DibujarLongitudinales(Drawing.Graphics g)
        {
            bool edicionActiva =
                modoEditorActual == AceroVigaModoEditorInicial.Longitudinales;

            foreach (AceroVigaBarraLongitudinal2D barra
                in disenoTrabajo.Longitudinales)
            {
                if (barra == null || barra.Punto == null ||
                    barra.OcultaPorSuperposicion)
                {
                    continue;
                }

                RebarBarType tipo =
                    barra.TipoBarra ?? TipoLongitudinalActual;

                List<AceroVigaPuntoMm> contorno =
                    ObtenerContornoCentrosLongitudinalMm(tipo);

                AceroVigaPuntoMm puntoModelo =
                    DesnormalizarEnCaja(barra.Punto, contorno);

                Drawing.PointF puntoPantalla =
                    ConvertirModeloAPantalla(puntoModelo);

                float diametroPx = ObtenerDiametroPantalla(tipo, 6F);
                float radio = diametroPx * 0.5F;
                bool seleccionado =
                    edicionActiva &&
                    EsLongitudinalSeleccionadoComoConjunto(barra);
                Drawing.Color color = ObtenerColorPorTipoBarra(tipo);

                if (!edicionActiva)
                    color = Drawing.Color.FromArgb(
                        190,
                        color.R,
                        color.G,
                        color.B);

                using (Drawing.SolidBrush relleno =
                    new Drawing.SolidBrush(color))
                using (Drawing.Pen borde = new Drawing.Pen(
                    seleccionado
                        ? Drawing.Color.FromArgb(255, 145, 0)
                        : Drawing.Color.White,
                    seleccionado ? 2.5F : 1F))
                {
                    g.FillEllipse(
                        relleno,
                        puntoPantalla.X - radio,
                        puntoPantalla.Y - radio,
                        diametroPx,
                        diametroPx);
                    g.DrawEllipse(
                        borde,
                        puntoPantalla.X - radio,
                        puntoPantalla.Y - radio,
                        diametroPx,
                        diametroPx);
                }
            }
            if (edicionActiva)
                DibujarControlesExtremosGrupoLongitudinal(g);

        }

        private void DibujarEstribos(Drawing.Graphics g)
        {
            bool edicionActiva =
                modoEditorActual == AceroVigaModoEditorInicial.Estribos;

            foreach (AceroVigaEstribo2D estribo in disenoTrabajo.Estribos)
            {
                if (estribo == null)
                    continue;

                List<AceroVigaPuntoMm> puntos =
                    ObtenerPuntosEstriboMm(estribo);

                if (puntos.Count < 2)
                    continue;

                bool seleccionado =
                    edicionActiva && EsEstriboSeleccionado(estribo.Id);
                bool seleccionPrimaria =
                    edicionActiva && estribo.Id == idSeleccionado;
                RebarBarType tipo =
                    estribo.TipoBarra ?? TipoEstriboActual;
                Drawing.Color color = ObtenerColorPorTipoBarra(tipo);

                if (!edicionActiva)
                {
                    color = Drawing.Color.FromArgb(
                        175,
                        color.R,
                        color.G,
                        color.B);
                }

                float grosor = ObtenerDiametroPantalla(tipo, 2.5F);
                if (seleccionado)
                {
                    color = Drawing.Color.FromArgb(255, 145, 0);
                    grosor += 1.8F;
                }

                using (Drawing.Pen lapiz =
                    new Drawing.Pen(color, grosor))
                {
                    lapiz.LineJoin = Drawing2D.LineJoin.Round;
                    lapiz.StartCap = Drawing2D.LineCap.Round;
                    lapiz.EndCap = Drawing2D.LineCap.Round;

                    bool esGanchoLongitudinal =
                        (estribo.Tipo == AceroVigaTipoEstribo2D.GanchoC ||
                         estribo.Tipo == AceroVigaTipoEstribo2D.GanchoS) &&
                        puntos.Count >= 2;

                    if (esGanchoLongitudinal)
                    {
                        DibujarGanchoAdaptadoLongitudinalesViga(
                            g,
                            estribo,
                            puntos[0],
                            puntos[puntos.Count - 1],
                            color,
                            grosor,
                            estribo.Tipo == AceroVigaTipoEstribo2D.GanchoS,
                            false);
                    }
                    else if (estribo.Cerrado && puntos.Count >= 3)
                    {
                        g.DrawPolygon(
                            lapiz,
                            puntos.Select(
                                ConvertirModeloAPantalla).ToArray());
                    }
                    else
                    {
                        g.DrawLines(
                            lapiz,
                            puntos.Select(
                                ConvertirModeloAPantalla).ToArray());
                    }
                }

                if (estribo.Cerrado)
                {
                    DibujarGanchosEstriboCerrado(
                        g,
                        estribo,
                        puntos,
                        color,
                        grosor);
                }

                if (seleccionPrimaria &&
                    !estribo.UsarContornoOffsetAutomatico)
                {
                    using (Drawing.SolidBrush relleno =
                        new Drawing.SolidBrush(Drawing.Color.White))
                    using (Drawing.Pen borde = new Drawing.Pen(
                        Drawing.Color.FromArgb(255, 145, 0),
                        2F))
                    {
                        for (int i = 0; i < puntos.Count; i++)
                        {
                            Drawing.PointF p =
                                ConvertirModeloAPantalla(puntos[i]);
                            float r = i == indiceVerticeSeleccionado
                                ? 6F
                                : 4.5F;

                            g.FillRectangle(
                                relleno,
                                p.X - r,
                                p.Y - r,
                                2F * r,
                                2F * r);
                            g.DrawRectangle(
                                borde,
                                p.X - r,
                                p.Y - r,
                                2F * r,
                                2F * r);
                        }
                    }
                }
            }
        }

        private void DibujarPreviewEstriboArrastre(Drawing.Graphics g)
        {
            if (g == null || !creandoEstriboConArrastre)
                return;

            Drawing.Color color = ObtenerColorPorTipoBarra(TipoEstriboActual);

            // En CROQUIS LIBRE se dibuja el tramo pendiente entre el último
            // vértice confirmado y el cursor. El tramo se materializa únicamente
            // con el siguiente clic; MouseMove no crea puntos.
            if (herramientaArrastre ==
                AceroVigaHerramientaEditor.EstriboLibreCerrado)
            {
                if (puntoInicioArrastre == null || puntoActualArrastre == null)
                    return;

                Drawing.PointF inicioPantalla =
                    ConvertirModeloAPantalla(puntoInicioArrastre);
                Drawing.PointF finPantalla =
                    ConvertirModeloAPantalla(puntoActualArrastre);

                using (Drawing.Pen penTramo = new Drawing.Pen(color, 2.2F))
                using (Drawing.SolidBrush brInicio =
                    new Drawing.SolidBrush(Drawing.Color.White))
                using (Drawing.SolidBrush brFin =
                    new Drawing.SolidBrush(color))
                {
                    penTramo.DashStyle = Drawing2D.DashStyle.Dash;
                    penTramo.StartCap = Drawing2D.LineCap.Round;
                    penTramo.EndCap = Drawing2D.LineCap.Round;
                    g.DrawLine(penTramo, inicioPantalla, finPantalla);

                    g.FillEllipse(
                        brInicio,
                        inicioPantalla.X - 4F,
                        inicioPantalla.Y - 4F,
                        8F,
                        8F);
                    g.DrawEllipse(
                        penTramo,
                        inicioPantalla.X - 4F,
                        inicioPantalla.Y - 4F,
                        8F,
                        8F);

                    g.FillEllipse(
                        brFin,
                        finPantalla.X - 4F,
                        finPantalla.Y - 4F,
                        8F,
                        8F);
                }

                // Guía de cierre al primer vértice: solo una línea tenue, sin
                // generar ni dibujar vértices intermedios.
                if (puntosCroquisActual.Count >= 3)
                {
                    Drawing.PointF primeroPantalla =
                        ConvertirModeloAPantalla(puntosCroquisActual[0]);
                    using (Drawing.Pen penCierre = new Drawing.Pen(
                        Drawing.Color.FromArgb(125, color),
                        1.2F))
                    {
                        penCierre.DashStyle = Drawing2D.DashStyle.Dot;
                        g.DrawLine(penCierre, finPantalla, primeroPantalla);
                    }
                }

                return;
            }

            List<AceroVigaPuntoMm> puntos = ConstruirPreviewEstriboArrastre();
            if (puntos == null || puntos.Count < 2)
                return;

            using (Drawing.Pen pen = new Drawing.Pen(color, 2.2F))
            using (Drawing.SolidBrush puntoBrush = new Drawing.SolidBrush(color))
            {
                pen.DashStyle = Drawing2D.DashStyle.Dash;
                pen.StartCap = Drawing2D.LineCap.Round;
                pen.EndCap = Drawing2D.LineCap.Round;

                for (int i = 0; i < puntos.Count - 1; i++)
                {
                    g.DrawLine(
                        pen,
                        ConvertirModeloAPantalla(puntos[i]),
                        ConvertirModeloAPantalla(puntos[i + 1]));
                }

                if (puntos.Count >= 3)
                {
                    g.DrawLine(
                        pen,
                        ConvertirModeloAPantalla(puntos[puntos.Count - 1]),
                        ConvertirModeloAPantalla(puntos[0]));
                }

                foreach (AceroVigaPuntoMm p in puntos)
                {
                    Drawing.PointF sp = ConvertirModeloAPantalla(p);
                    g.FillEllipse(puntoBrush, sp.X - 3F, sp.Y - 3F, 6F, 6F);
                }
            }
        }


        private void DibujarPreviewDistribucionLongitudinal(
            Drawing.Graphics g)
        {
            if (g == null ||
                !creandoDistribucionLongitudinalConArrastre ||
                puntoInicioDistribucionArrastre == null ||
                puntoFinDistribucionArrastre == null)
            {
                return;
            }

            AceroVigaGuiaCapaLongitudinal2D guia =
                ObtenerGuiaCapaActiva();
            List<AceroVigaPuntoMm> permitido =
                ObtenerContornoCentrosLongitudinalMm(
                    TipoLongitudinalActual);
            List<AceroVigaPuntoMm> puntosGuia =
                guia != null && permitido != null
                    ? ObtenerPuntosGuiaMm(guia, permitido)
                    : new List<AceroVigaPuntoMm>();

            double longitudMm =
                ObtenerLongitudSeleccionDistribucionMm(
                    guia,
                    puntosGuia);
            if (longitudMm <= 0.1)
                return;

            int cantidad = nudCantidadDistribucion != null
                ? Math.Max(1, (int)nudCantidadDistribucion.Value)
                : 4;
            double espaciadoCm = cantidad <= 1
                ? 0.0
                : (longitudMm / 10.0) / (cantidad - 1);

            AceroVigaGrupoLongitudinal2D temporal =
                new AceroVigaGrupoLongitudinal2D
                {
                    Regla = AceroVigaReglaGrupoLongitudinal.NumeroFijo,
                    EspaciadoCm = espaciadoCm,
                    Cantidad = cantidad,
                    ParametroInicioGuia =
                        parametroInicioDistribucionArrastre,
                    ParametroFinGuia =
                        parametroFinDistribucionArrastre,
                    PuntoInicio = permitido != null
                        ? NormalizarEnCaja(
                            puntoInicioDistribucionArrastre,
                            permitido)
                        : null,
                    PuntoFin = permitido != null
                        ? NormalizarEnCaja(
                            puntoFinDistribucionArrastre,
                            permitido)
                        : null
                };

            List<double> parametros =
                ObtenerParametrosGrupoLongitudinal(
                    temporal,
                    puntosGuia);
            List<AceroVigaPuntoMm> posiciones =
                new List<AceroVigaPuntoMm>();

            for (int i = 0; i < parametros.Count; i++)
            {
                AceroVigaPuntoMm punto = null;
                if (guia != null &&
                    puntosGuia != null &&
                    puntosGuia.Count >= 2 &&
                    temporal.ParametroInicioGuia >= 0.0 &&
                    temporal.ParametroFinGuia >= 0.0)
                {
                    punto = PuntoDistribucionEnGuia(
                        puntosGuia,
                        parametros[i]);
                }
                else
                {
                    double t = parametros[i];
                    punto = new AceroVigaPuntoMm(
                        puntoInicioDistribucionArrastre.Y +
                            (puntoFinDistribucionArrastre.Y -
                             puntoInicioDistribucionArrastre.Y) * t,
                        puntoInicioDistribucionArrastre.Z +
                            (puntoFinDistribucionArrastre.Z -
                             puntoInicioDistribucionArrastre.Z) * t);
                }

                if (punto != null)
                    posiciones.Add(punto);
            }

            Drawing.Color color =
                Drawing.Color.FromArgb(235, 130, 0);
            using (Drawing.Pen pen = new Drawing.Pen(color, 2.0F))
            using (Drawing.SolidBrush brocha =
                new Drawing.SolidBrush(color))
            using (Drawing.Font fuente = new Drawing.Font(
                "Segoe UI",
                7.8F,
                Drawing.FontStyle.Bold))
            using (Drawing.SolidBrush fondo =
                new Drawing.SolidBrush(
                    Drawing.Color.FromArgb(230, 255, 255, 255)))
            {
                pen.DashStyle = Drawing2D.DashStyle.Dash;
                pen.StartCap = Drawing2D.LineCap.Round;
                pen.EndCap = Drawing2D.LineCap.Round;

                Drawing.PointF a =
                    ConvertirModeloAPantalla(
                        puntoInicioDistribucionArrastre);
                Drawing.PointF b =
                    ConvertirModeloAPantalla(
                        puntoFinDistribucionArrastre);
                g.DrawLine(pen, a, b);

                foreach (AceroVigaPuntoMm posicion in posiciones)
                {
                    Drawing.PointF sp =
                        ConvertirModeloAPantalla(posicion);
                    float radio = 4.2F;
                    g.FillEllipse(
                        brocha,
                        sp.X - radio,
                        sp.Y - radio,
                        radio * 2F,
                        radio * 2F);
                }

                string reglaTexto =
                    cantidad + " BARRAS · NÚMERO FIJO" +
                    (cantidad > 1
                        ? " · sep. " +
                            espaciadoCm.ToString("0.##") + " cm"
                        : string.Empty);
                Drawing.SizeF tam =
                    g.MeasureString(reglaTexto, fuente);
                float x = (a.X + b.X) * 0.5F + 8F;
                float y = (a.Y + b.Y) * 0.5F -
                    tam.Height - 6F;
                g.FillRectangle(
                    fondo,
                    x - 3F,
                    y - 2F,
                    tam.Width + 6F,
                    tam.Height + 4F);
                g.DrawString(
                    reglaTexto,
                    fuente,
                    brocha,
                    x,
                    y);
            }
        }

        private void DibujarCroquisActual(Drawing.Graphics g)
        {
            DibujarPreviewEstriboArrastre(g);

            if (puntosCroquisActual.Count == 0 && primerPuntoDistribucion == null)
                return;

            using (Drawing.Pen pen = new Drawing.Pen(Drawing.Color.FromArgb(0, 150, 90), 1.5F))
            {
                pen.DashStyle = Drawing2D.DashStyle.Dash;
                for (int i = 0; i < puntosCroquisActual.Count - 1; i++)
                    g.DrawLine(pen,
                        ConvertirModeloAPantalla(puntosCroquisActual[i]),
                        ConvertirModeloAPantalla(puntosCroquisActual[i + 1]));
            }

            using (Drawing.SolidBrush br = new Drawing.SolidBrush(Drawing.Color.FromArgb(0, 150, 90)))
            {
                foreach (AceroVigaPuntoMm punto in puntosCroquisActual)
                {
                    Drawing.PointF sp = ConvertirModeloAPantalla(punto);
                    g.FillEllipse(br, sp.X - 3F, sp.Y - 3F, 6F, 6F);
                }

                if (primerPuntoDistribucion != null)
                {
                    Drawing.PointF sp = ConvertirModeloAPantalla(primerPuntoDistribucion);
                    g.FillEllipse(br, sp.X - 5F, sp.Y - 5F, 10F, 10F);
                }
            }
        }

        private List<AceroVigaPuntoMm> ObtenerPuntosEstriboMm(AceroVigaEstribo2D estribo)
        {
            List<AceroVigaPuntoMm> contorno = ObtenerContornoEjeEstriboMm(
                estribo.TipoBarra ?? TipoEstriboActual);

            if (estribo.UsarContornoOffsetAutomatico)
                return contorno;

            List<AceroVigaPuntoMm> resultado = new List<AceroVigaPuntoMm>();
            if (estribo.Puntos != null)
            {
                foreach (AceroVigaPuntoNormalizado punto in estribo.Puntos)
                {
                    if (punto != null)
                        resultado.Add(DesnormalizarEnCaja(punto, contorno));
                }
            }
            return resultado;
        }

        private void CalcularTransformacion(Drawing.Rectangle area)
        {
            List<AceroVigaPuntoMm> puntosEncuadre =
                contornoConcretoMm.Select(x => x.Copiar()).ToList();

            foreach (AceroVigaEstribo2D estribo in disenoTrabajo.Estribos)
            {
                if (estribo == null)
                    continue;
                List<AceroVigaPuntoMm> puntos = ObtenerPuntosEstriboMm(estribo);
                if (puntos != null)
                    puntosEncuadre.AddRange(puntos.Where(x => x != null).Select(x => x.Copiar()));
            }

            if (creandoEstriboConArrastre)
            {
                List<AceroVigaPuntoMm> preview = ConstruirPreviewEstriboArrastre();
                if (preview != null)
                    puntosEncuadre.AddRange(preview.Where(x => x != null).Select(x => x.Copiar()));
            }

            minYModelo = puntosEncuadre.Min(x => x.Y);
            maxYModelo = puntosEncuadre.Max(x => x.Y);
            minZModelo = puntosEncuadre.Min(x => x.Z);
            maxZModelo = puntosEncuadre.Max(x => x.Z);

            double ancho = Math.Max(1.0, maxYModelo - minYModelo);
            double alto = Math.Max(1.0, maxZModelo - minZModelo);
            double margen = Math.Max(ancho, alto) * 0.15;

            minYModelo -= margen;
            maxYModelo += margen;
            minZModelo -= margen;
            maxZModelo += margen;

            // Se reserva la franja superior para el título de la vista y la
            // inferior para la leyenda descriptiva, igual que en columnas.
            const float margenHorizontal = 36F;
            const float margenSuperior = 92F;
            const float margenInferior = 48F;

            float areaAncho = Math.Max(
                10F,
                area.Width - margenHorizontal * 2F);
            float areaAlto = Math.Max(
                10F,
                area.Height - margenSuperior - margenInferior);

            double escalaBase = Math.Min(
                areaAncho / (maxYModelo - minYModelo),
                areaAlto / (maxZModelo - minZModelo));

            double escala = escalaBase * Math.Max(0.25, zoomVista);

            float anchoPantalla =
                (float)((maxYModelo - minYModelo) * escala);
            float altoPantalla =
                (float)((maxZModelo - minZModelo) * escala);
            float posicionPantallaX =
                area.Left + (area.Width - anchoPantalla) * 0.5F +
                (float)panVistaX;
            float posicionPantallaY =
                area.Top + margenSuperior +
                (areaAlto - altoPantalla) * 0.5F +
                (float)panVistaY;

            rectModeloPantalla = new Drawing.RectangleF(
                posicionPantallaX,
                posicionPantallaY,
                anchoPantalla,
                altoPantalla);
        }

        private Drawing.PointF ConvertirModeloAPantalla(AceroVigaPuntoMm punto)
        {
            double u = (punto.Y - minYModelo) / Math.Max(Tol, maxYModelo - minYModelo);
            double v = (punto.Z - minZModelo) / Math.Max(Tol, maxZModelo - minZModelo);
            return new Drawing.PointF(
                rectModeloPantalla.Left + (float)(u * rectModeloPantalla.Width),
                rectModeloPantalla.Bottom - (float)(v * rectModeloPantalla.Height));
        }

        private AceroVigaPuntoMm ConvertirPantallaAModelo(Drawing.Point punto)
        {
            if (rectModeloPantalla.Width <= 0F || rectModeloPantalla.Height <= 0F)
                return null;

            double u = (punto.X - rectModeloPantalla.Left) / rectModeloPantalla.Width;
            double v = (rectModeloPantalla.Bottom - punto.Y) / rectModeloPantalla.Height;
            return new AceroVigaPuntoMm(
                minYModelo + u * (maxYModelo - minYModelo),
                minZModelo + v * (maxZModelo - minZModelo));
        }

        private double EscalaActual()
        {
            double ancho = Math.Max(Tol, maxYModelo - minYModelo);
            return rectModeloPantalla.Width / ancho;
        }

        private double ObtenerToleranciaModelo(float pixeles)
        {
            double escala = EscalaActual();
            return escala <= Tol ? 10.0 : pixeles / escala;
        }

        private static AceroVigaPuntoNormalizado NormalizarEnCaja(
            AceroVigaPuntoMm punto,
            List<AceroVigaPuntoMm> contorno)
        {
            if (punto == null || contorno == null || contorno.Count == 0)
                return new AceroVigaPuntoNormalizado(0.5, 0.5);

            double minY = contorno.Min(x => x.Y);
            double maxY = contorno.Max(x => x.Y);
            double minZ = contorno.Min(x => x.Z);
            double maxZ = contorno.Max(x => x.Z);
            double u = (punto.Y - minY) / Math.Max(Tol, maxY - minY);
            double v = (punto.Z - minZ) / Math.Max(Tol, maxZ - minZ);
            return new AceroVigaPuntoNormalizado(u, v);
        }

        private static AceroVigaPuntoMm DesnormalizarEnCaja(
            AceroVigaPuntoNormalizado punto,
            List<AceroVigaPuntoMm> contorno)
        {
            if (punto == null || contorno == null || contorno.Count == 0)
                return new AceroVigaPuntoMm();

            double minY = contorno.Min(x => x.Y);
            double maxY = contorno.Max(x => x.Y);
            double minZ = contorno.Min(x => x.Z);
            double maxZ = contorno.Max(x => x.Z);
            return new AceroVigaPuntoMm(
                minY + punto.U * (maxY - minY),
                minZ + punto.V * (maxZ - minZ));
        }

        private static AceroVigaPuntoMm AjustarPuntoAlContornoPermitido(
            AceroVigaPuntoMm punto,
            List<AceroVigaPuntoMm> contorno)
        {
            if (punto == null || contorno == null || contorno.Count < 3)
                return punto;

            if (PuntoDentroPoligono(punto, contorno))
                return punto;

            AceroVigaPuntoMm masCercano = null;
            double mejor = double.MaxValue;

            for (int i = 0; i < contorno.Count; i++)
            {
                AceroVigaPuntoMm a = contorno[i];
                AceroVigaPuntoMm b = contorno[(i + 1) % contorno.Count];
                AceroVigaPuntoMm q = PuntoMasCercanoSegmento(punto, a, b);
                double d = Distancia(punto, q);
                if (d < mejor)
                {
                    mejor = d;
                    masCercano = q;
                }
            }

            if (masCercano == null)
                return punto;

            AceroVigaPuntoMm centro = new AceroVigaPuntoMm(
                contorno.Average(x => x.Y),
                contorno.Average(x => x.Z));
            double dy = centro.Y - masCercano.Y;
            double dz = centro.Z - masCercano.Z;
            double len = Math.Sqrt(dy * dy + dz * dz);
            if (len > Tol)
            {
                masCercano.Y += dy / len * 0.2;
                masCercano.Z += dz / len * 0.2;
            }
            return masCercano;
        }

        private static List<AceroVigaPuntoMm> DesfasarPoligonoInterior(
            List<AceroVigaPuntoMm> poligono,
            double offset)
        {
            List<AceroVigaPuntoMm> resultado = new List<AceroVigaPuntoMm>();
            if (poligono == null || poligono.Count < 3)
                return resultado;

            List<AceroVigaPuntoMm> pts = poligono.Select(x => x.Copiar()).ToList();
            bool ccw = AreaFirmada(pts) > 0.0;
            AceroVigaPuntoMm centro = new AceroVigaPuntoMm(
                pts.Average(x => x.Y),
                pts.Average(x => x.Z));

            List<Linea2D> lineas = new List<Linea2D>();
            for (int i = 0; i < pts.Count; i++)
            {
                AceroVigaPuntoMm a = pts[i];
                AceroVigaPuntoMm b = pts[(i + 1) % pts.Count];
                double dy = b.Y - a.Y;
                double dz = b.Z - a.Z;
                double len = Math.Sqrt(dy * dy + dz * dz);
                if (len <= Tol)
                    return new List<AceroVigaPuntoMm>();

                double ny = ccw ? -dz / len : dz / len;
                double nz = ccw ? dy / len : -dy / len;

                AceroVigaPuntoMm medio = new AceroVigaPuntoMm(
                    (a.Y + b.Y) * 0.5,
                    (a.Z + b.Z) * 0.5);
                double haciaCentro = (centro.Y - medio.Y) * ny + (centro.Z - medio.Z) * nz;
                if (haciaCentro < 0.0)
                {
                    ny = -ny;
                    nz = -nz;
                }

                lineas.Add(new Linea2D(
                    new AceroVigaPuntoMm(a.Y + ny * offset, a.Z + nz * offset),
                    new AceroVigaPuntoMm(b.Y + ny * offset, b.Z + nz * offset)));
            }

            for (int i = 0; i < lineas.Count; i++)
            {
                Linea2D anterior = lineas[(i - 1 + lineas.Count) % lineas.Count];
                Linea2D actual = lineas[i];
                AceroVigaPuntoMm p;
                if (!TryIntersecarLineas(anterior, actual, out p))
                {
                    AceroVigaPuntoMm original = pts[i];
                    double dy = centro.Y - original.Y;
                    double dz = centro.Z - original.Z;
                    double len = Math.Sqrt(dy * dy + dz * dz);
                    if (len <= Tol)
                        return new List<AceroVigaPuntoMm>();
                    p = new AceroVigaPuntoMm(
                        original.Y + dy / len * offset,
                        original.Z + dz / len * offset);
                }
                resultado.Add(p);
            }

            if (resultado.Count < 3 || Math.Abs(AreaFirmada(resultado)) < 1.0)
                return new List<AceroVigaPuntoMm>();

            return resultado;
        }

        private sealed class Linea2D
        {
            public AceroVigaPuntoMm A;
            public AceroVigaPuntoMm B;

            public Linea2D(AceroVigaPuntoMm a, AceroVigaPuntoMm b)
            {
                A = a;
                B = b;
            }
        }

        private static bool TryIntersecarLineas(Linea2D l1, Linea2D l2, out AceroVigaPuntoMm p)
        {
            p = null;
            double x1 = l1.A.Y;
            double y1 = l1.A.Z;
            double x2 = l1.B.Y;
            double y2 = l1.B.Z;
            double x3 = l2.A.Y;
            double y3 = l2.A.Z;
            double x4 = l2.B.Y;
            double y4 = l2.B.Z;
            double den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
            if (Math.Abs(den) <= Tol)
                return false;

            double det1 = x1 * y2 - y1 * x2;
            double det2 = x3 * y4 - y3 * x4;
            p = new AceroVigaPuntoMm(
                (det1 * (x3 - x4) - (x1 - x2) * det2) / den,
                (det1 * (y3 - y4) - (y1 - y2) * det2) / den);
            return true;
        }

        private static double AreaFirmada(List<AceroVigaPuntoMm> puntos)
        {
            if (puntos == null || puntos.Count < 3)
                return 0.0;

            double area = 0.0;
            for (int i = 0; i < puntos.Count; i++)
            {
                AceroVigaPuntoMm a = puntos[i];
                AceroVigaPuntoMm b = puntos[(i + 1) % puntos.Count];
                area += a.Y * b.Z - b.Y * a.Z;
            }
            return area * 0.5;
        }

        private static bool PuntoDentroPoligono(
            AceroVigaPuntoMm punto,
            List<AceroVigaPuntoMm> poligono)
        {
            bool dentro = false;
            for (int i = 0, j = poligono.Count - 1; i < poligono.Count; j = i++)
            {
                AceroVigaPuntoMm pi = poligono[i];
                AceroVigaPuntoMm pj = poligono[j];
                double denominador = pj.Z - pi.Z;
                bool intersecta = Math.Abs(denominador) > Tol &&
                    ((pi.Z > punto.Z) != (pj.Z > punto.Z)) &&
                    (punto.Y < (pj.Y - pi.Y) * (punto.Z - pi.Z) /
                    denominador + pi.Y);
                if (intersecta)
                    dentro = !dentro;
            }
            return dentro;
        }

        private static AceroVigaPuntoMm PuntoMasCercanoSegmento(
            AceroVigaPuntoMm p,
            AceroVigaPuntoMm a,
            AceroVigaPuntoMm b)
        {
            double dy = b.Y - a.Y;
            double dz = b.Z - a.Z;
            double len2 = dy * dy + dz * dz;
            if (len2 <= Tol)
                return a.Copiar();
            double t = ((p.Y - a.Y) * dy + (p.Z - a.Z) * dz) / len2;
            t = Math.Max(0.0, Math.Min(1.0, t));
            return new AceroVigaPuntoMm(a.Y + t * dy, a.Z + t * dz);
        }

        private static double DistanciaPuntoSegmento(
            AceroVigaPuntoMm p,
            AceroVigaPuntoMm a,
            AceroVigaPuntoMm b)
        {
            return Distancia(p, PuntoMasCercanoSegmento(p, a, b));
        }

        private static double Distancia(AceroVigaPuntoMm a, AceroVigaPuntoMm b)
        {
            if (a == null || b == null)
                return double.MaxValue;
            double dy = a.Y - b.Y;
            double dz = a.Z - b.Z;
            return Math.Sqrt(dy * dy + dz * dz);
        }

        private static int ObtenerIndiceEsquinaSuperiorDerecha(List<AceroVigaPuntoMm> puntos)
        {
            if (puntos == null || puntos.Count == 0)
                return -1;

            double yMax = puntos.Max(x => x.Y);
            double zMax = puntos.Max(x => x.Z);
            int mejor = 0;
            double mejorValor = double.MaxValue;
            for (int i = 0; i < puntos.Count; i++)
            {
                double d = Math.Abs(yMax - puntos[i].Y) + Math.Abs(zMax - puntos[i].Z);
                if (d < mejorValor)
                {
                    mejorValor = d;
                    mejor = i;
                }
            }
            return mejor;
        }

        // =========================================================
        // V11.2 - PERSISTENCIA COMPLETA PARA GUARDAR/CARGAR DATA GLOBAL
        // =========================================================
        // Estos métodos reutilizan exactamente el mismo formato XML del editor
        // de sección, pero sin abrir un segundo diálogo. El botón GUARDAR DATA
        // puede incrustar este XML dentro del archivo .mygacero y restaurar
        // longitudinales, grupos, reglas, guías y estribos dibujados.
        public string ExportarDisenoXmlMYG()
        {
            ActualizarCoordenadasSeccionRealLongitudinales();

            // El diseño compartido es la fuente global entre las pestañas de
            // Estribos y Longitudinales. Así GUARDAR DATA no pierde los cambios
            // realizados en la otra pestaña aunque su editor local no se haya
            // reconstruido todavía.
            AceroVigaDisenoSeccion fuentePersistencia =
                AceroVigaDisenoSeccionCompartido.ObtenerCopia();

            if (fuentePersistencia == null ||
                ((fuentePersistencia.Longitudinales == null ||
                  fuentePersistencia.Longitudinales.Count == 0) &&
                 (fuentePersistencia.Estribos == null ||
                  fuentePersistencia.Estribos.Count == 0) &&
                 (fuentePersistencia.GuiasCapasLongitudinales == null ||
                  fuentePersistencia.GuiasCapasLongitudinales.Count == 0)))
            {
                fuentePersistencia = disenoTrabajo != null
                    ? disenoTrabajo.Copiar()
                    : new AceroVigaDisenoSeccion();
            }

            XElement raiz = new XElement("AceroVigaDisenoSeccion",
                new XAttribute("Version", 19),
                new XElement(
                    "RecubrimientoCm",
                    fuentePersistencia.RecubrimientoCm.ToString(
                        "0.###",
                        CultureInfo.InvariantCulture)),
                new XElement(
                    "RecubrimientoLongitudinalCm",
                    fuentePersistencia.RecubrimientoLongitudinalCm.ToString(
                        "0.###",
                        CultureInfo.InvariantCulture)),
                new XElement(
                    "RecubrimientoEstribosCm",
                    fuentePersistencia.RecubrimientoEstribosCm.ToString(
                        "0.###",
                        CultureInfo.InvariantCulture)),
                new XElement("NombreSeccion", fuentePersistencia.NombreSeccionReferencia ?? string.Empty),
                new XElement("Longitudinales",
                    fuentePersistencia.Longitudinales.Select(x =>
                        new XElement("Barra",
                            new XAttribute("Id", x.Id ?? string.Empty),
                            new XAttribute("Tipo", x.TipoBarra != null ? x.TipoBarra.Name : string.Empty),
                            new XAttribute("U", x.Punto != null ? x.Punto.U.ToString("0.########", CultureInfo.InvariantCulture) : "0.5"),
                            new XAttribute("V", x.Punto != null ? x.Punto.V.ToString("0.########", CultureInfo.InvariantCulture) : "0.5"),
                            new XAttribute("USec", x.PuntoSeccionReal != null ? x.PuntoSeccionReal.U.ToString("0.########", CultureInfo.InvariantCulture) : "-1"),
                            new XAttribute("VSec", x.PuntoSeccionReal != null ? x.PuntoSeccionReal.V.ToString("0.########", CultureInfo.InvariantCulture) : "-1"),
                            new XAttribute("Grupo", x.GrupoDistribucionId ?? string.Empty),
                            new XAttribute("Guia", x.GuiaCapaId ?? string.Empty),
                            new XAttribute("TipoCapa", x.TipoCapa.ToString()),
                            new XAttribute("NumeroCapa", x.NumeroCapa),
                            new XAttribute("ParametroGuia", x.ParametroSobreGuia.ToString("0.########", CultureInfo.InvariantCulture)),
                            new XAttribute("DesfaseNormalGuiaMm", x.DesfaseNormalGuiaMm.ToString("0.########", CultureInfo.InvariantCulture)),
                            new XAttribute("PosicionExacta", x.UsarPosicionExactaSeccion),
                            new XAttribute("OcultaSuperposicion", x.OcultaPorSuperposicion)))),
                new XElement("GruposLongitudinales",
                    (fuentePersistencia.GruposLongitudinales ??
                        new List<AceroVigaGrupoLongitudinal2D>()).Select(x =>
                        new XElement("Grupo",
                            new XAttribute("Id", x.Id ?? string.Empty),
                            new XAttribute("Tipo", x.TipoBarra != null ? x.TipoBarra.Name : string.Empty),
                            new XAttribute("DiametroMm", x.DiametroMm.ToString("0.###", CultureInfo.InvariantCulture)),
                            new XAttribute("Guia", x.GuiaCapaId ?? string.Empty),
                            new XAttribute("TipoCapa", x.TipoCapa.ToString()),
                            new XAttribute("NumeroCapa", x.NumeroCapa),
                            new XAttribute("Regla", x.Regla.ToString()),
                            new XAttribute("EspaciadoCm", x.EspaciadoCm.ToString("0.###", CultureInfo.InvariantCulture)),
                            new XAttribute("Cantidad", x.Cantidad),
                            new XAttribute("OmitirPrimera", x.OmitirPrimeraBarra),
                            new XAttribute("OmitirUltima", x.OmitirUltimaBarra),
                            new XAttribute("ParametroInicioGuia", x.ParametroInicioGuia.ToString("0.########", CultureInfo.InvariantCulture)),
                            new XAttribute("ParametroFinGuia", x.ParametroFinGuia.ToString("0.########", CultureInfo.InvariantCulture)),
                            new XAttribute("RespetarTrazoDosPuntos", x.RespetarTrazoDosPuntos),
                            new XElement("PuntoInicio",
                                new XAttribute("U", x.PuntoInicio != null ? x.PuntoInicio.U.ToString("0.########", CultureInfo.InvariantCulture) : "0"),
                                new XAttribute("V", x.PuntoInicio != null ? x.PuntoInicio.V.ToString("0.########", CultureInfo.InvariantCulture) : "0.5")),
                            new XElement("PuntoFin",
                                new XAttribute("U", x.PuntoFin != null ? x.PuntoFin.U.ToString("0.########", CultureInfo.InvariantCulture) : "1"),
                                new XAttribute("V", x.PuntoFin != null ? x.PuntoFin.V.ToString("0.########", CultureInfo.InvariantCulture) : "0.5")),
                            new XElement("PuntoInicioSeccionReal",
                                new XAttribute("U", x.PuntoInicioSeccionReal != null ? x.PuntoInicioSeccionReal.U.ToString("0.########", CultureInfo.InvariantCulture) : "-1"),
                                new XAttribute("V", x.PuntoInicioSeccionReal != null ? x.PuntoInicioSeccionReal.V.ToString("0.########", CultureInfo.InvariantCulture) : "-1")),
                            new XElement("PuntoFinSeccionReal",
                                new XAttribute("U", x.PuntoFinSeccionReal != null ? x.PuntoFinSeccionReal.U.ToString("0.########", CultureInfo.InvariantCulture) : "-1"),
                                new XAttribute("V", x.PuntoFinSeccionReal != null ? x.PuntoFinSeccionReal.V.ToString("0.########", CultureInfo.InvariantCulture) : "-1"))))),
                new XElement("GuiasCapasLongitudinales",
                    fuentePersistencia.GuiasCapasLongitudinales.Select(x =>
                        new XElement("Guia",
                            new XAttribute("Id", x.Id ?? string.Empty),
                            new XAttribute("Tipo", x.Tipo.ToString()),
                            new XAttribute("Numero", x.NumeroCapa),
                            new XAttribute("V", x.V.ToString("0.########", CultureInfo.InvariantCulture)),
                            new XAttribute("SeparacionLibreCm", x.SeparacionLibreCm.ToString("0.###", CultureInfo.InvariantCulture)),
                            new XAttribute("DiametroReferenciaMm", x.DiametroReferenciaMm.ToString("0.###", CultureInfo.InvariantCulture)),
                            new XAttribute("OffsetAcumuladoMm", x.OffsetAcumuladoMm.ToString("0.###", CultureInfo.InvariantCulture)),
                            new XAttribute("Adaptada", x.AdaptadaAlContorno),
                            new XElement("PuntosGuia",
                                (x.PuntosGuia ?? new List<AceroVigaPuntoNormalizado>()).Select(p =>
                                    new XElement("P",
                                        new XAttribute("U", p.U.ToString("0.########", CultureInfo.InvariantCulture)),
                                        new XAttribute("V", p.V.ToString("0.########", CultureInfo.InvariantCulture))))),
                            new XElement("PuntosGuiaSeccionReal",
                                (x.PuntosGuiaSeccionReal ?? new List<AceroVigaPuntoNormalizado>()).Select(p =>
                                    new XElement("P",
                                        new XAttribute("U", p.U.ToString("0.########", CultureInfo.InvariantCulture)),
                                        new XAttribute("V", p.V.ToString("0.########", CultureInfo.InvariantCulture)))))))),
                new XElement("Estribos",
                    fuentePersistencia.Estribos.Select(x =>
                        new XElement("Estribo",
                            new XAttribute("Tipo", x.TipoBarra != null ? x.TipoBarra.Name : string.Empty),
                            new XAttribute("Forma", x.Tipo.ToString()),
                            new XAttribute("Cerrado", x.Cerrado),
                            new XAttribute("Automatico", x.UsarContornoOffsetAutomatico),
                            new XAttribute("Gancho", x.IndiceEsquinaGancho),
                            new XElement("Puntos",
                                x.Puntos.Select(p =>
                                    new XElement("P",
                                        new XAttribute("U", p.U.ToString("0.########", CultureInfo.InvariantCulture)),
                                        new XAttribute("V", p.V.ToString("0.########", CultureInfo.InvariantCulture)))))))));

            return new XDocument(raiz).ToString(System.Xml.Linq.SaveOptions.DisableFormatting);
        }

        public bool ImportarDisenoXmlMYG(
            string contenidoXml,
            out string mensajeError)
        {
            mensajeError = string.Empty;

            if (string.IsNullOrWhiteSpace(contenidoXml))
                return true;

            try
            {
                XDocument documento = XDocument.Parse(contenidoXml);
                XElement raiz = documento.Root;
                if (raiz == null)
                {
                    mensajeError = "El archivo no contiene un diseño de sección válido.";
                    return false;
                }

                AceroVigaDisenoSeccion nuevo =
                    new AceroVigaDisenoSeccion();

                double recubrimientoAnterior = LeerDouble(
                    raiz.Element("RecubrimientoCm"),
                    4.0);

                nuevo.RecubrimientoCm = recubrimientoAnterior;
                nuevo.RecubrimientoLongitudinalCm = LeerDouble(
                    raiz.Element("RecubrimientoLongitudinalCm"),
                    recubrimientoAnterior);
                nuevo.RecubrimientoEstribosCm = LeerDouble(
                    raiz.Element("RecubrimientoEstribosCm"),
                    recubrimientoAnterior);

                nuevo.NombreSeccionReferencia =
                    (string)raiz.Element("NombreSeccion") ??
                    string.Empty;

                XElement longs = raiz.Element("Longitudinales");
                if (longs != null)
                {
                    foreach (XElement elementoBarraXml in longs.Elements("Barra"))
                    {
                        string nombreTipo = (string)elementoBarraXml.Attribute("Tipo") ?? string.Empty;
                        RebarBarType tipo = ResolverTipoPorNombre(nombreTipo, TipoLongitudinalActual);
                        AceroVigaTipoCapaLongitudinal tipoCapa =
                            AceroVigaTipoCapaLongitudinal.SinDefinir;
                        Enum.TryParse(
                            (string)elementoBarraXml.Attribute("TipoCapa") ?? "SinDefinir",
                            true,
                            out tipoCapa);
                        nuevo.Longitudinales.Add(new AceroVigaBarraLongitudinal2D
                        {
                            Id = (string)elementoBarraXml.Attribute("Id") ??
                                Guid.NewGuid().ToString("N"),
                            TipoBarra = tipo,
                            DiametroMm = ObtenerDiametroMm(tipo),
                            Punto = new AceroVigaPuntoNormalizado(
                                LeerDouble(elementoBarraXml.Attribute("U"), 0.5),
                                LeerDouble(elementoBarraXml.Attribute("V"), 0.5)),
                            PuntoSeccionReal =
                                elementoBarraXml.Attribute("USec") != null &&
                                elementoBarraXml.Attribute("VSec") != null &&
                                LeerDouble(elementoBarraXml.Attribute("USec"), -1.0) >= 0.0 &&
                                LeerDouble(elementoBarraXml.Attribute("VSec"), -1.0) >= 0.0
                                    ? new AceroVigaPuntoNormalizado(
                                        LeerDouble(elementoBarraXml.Attribute("USec"), 0.5),
                                        LeerDouble(elementoBarraXml.Attribute("VSec"), 0.5))
                                    : null,
                            GrupoDistribucionId =
                                (string)elementoBarraXml.Attribute("Grupo") ?? string.Empty,
                            GuiaCapaId =
                                (string)elementoBarraXml.Attribute("Guia") ?? string.Empty,
                            TipoCapa = tipoCapa,
                            NumeroCapa = (int?)elementoBarraXml.Attribute("NumeroCapa") ?? 0,
                            ParametroSobreGuia = LeerDouble(
                                elementoBarraXml.Attribute("ParametroGuia"), -1.0),
                            DesfaseNormalGuiaMm = LeerDouble(
                                elementoBarraXml.Attribute("DesfaseNormalGuiaMm"), 0.0),
                            UsarPosicionExactaSeccion = LeerBool(
                                elementoBarraXml.Attribute("PosicionExacta"),
                                false),
                            OcultaPorSuperposicion = LeerBool(
                                elementoBarraXml.Attribute("OcultaSuperposicion"),
                                false)
                        });
                    }
                }

                XElement gruposXml = raiz.Element("GruposLongitudinales");
                if (gruposXml != null)
                {
                    foreach (XElement grupoXml in gruposXml.Elements("Grupo"))
                    {
                        string nombreTipoGrupo =
                            (string)grupoXml.Attribute("Tipo") ?? string.Empty;
                        RebarBarType tipoGrupo = ResolverTipoPorNombre(
                            nombreTipoGrupo,
                            TipoLongitudinalActual);

                        AceroVigaTipoCapaLongitudinal tipoCapaGrupo =
                            AceroVigaTipoCapaLongitudinal.SinDefinir;
                        Enum.TryParse(
                            (string)grupoXml.Attribute("TipoCapa") ??
                                "SinDefinir",
                            true,
                            out tipoCapaGrupo);

                        AceroVigaReglaGrupoLongitudinal reglaGrupo =
                            AceroVigaReglaGrupoLongitudinal.NumeroFijo;
                        Enum.TryParse(
                            (string)grupoXml.Attribute("Regla") ??
                                "NumeroFijo",
                            true,
                            out reglaGrupo);

                        if (reglaGrupo !=
                            AceroVigaReglaGrupoLongitudinal.EspaciadoMaximo)
                        {
                            reglaGrupo =
                                AceroVigaReglaGrupoLongitudinal.NumeroFijo;
                        }

                        XElement puntoInicioXml =
                            grupoXml.Element("PuntoInicio");
                        XElement puntoFinXml =
                            grupoXml.Element("PuntoFin");
                        XElement puntoInicioRealXml =
                            grupoXml.Element("PuntoInicioSeccionReal");
                        XElement puntoFinRealXml =
                            grupoXml.Element("PuntoFinSeccionReal");

                        AceroVigaGrupoLongitudinal2D grupoNuevo =
                            new AceroVigaGrupoLongitudinal2D
                            {
                                Id = (string)grupoXml.Attribute("Id") ??
                                    Guid.NewGuid().ToString("N"),
                                TipoBarra = tipoGrupo,
                                DiametroMm = LeerDouble(
                                    grupoXml.Attribute("DiametroMm"),
                                    ObtenerDiametroMm(tipoGrupo)),
                                GuiaCapaId =
                                    (string)grupoXml.Attribute("Guia") ??
                                    string.Empty,
                                TipoCapa = tipoCapaGrupo,
                                NumeroCapa =
                                    (int?)grupoXml.Attribute("NumeroCapa") ?? 0,
                                Regla = reglaGrupo,
                                EspaciadoCm = LeerDouble(
                                    grupoXml.Attribute("EspaciadoCm"),
                                    20.0),
                                Cantidad = Math.Max(
                                    1,
                                    (int?)grupoXml.Attribute("Cantidad") ?? 4),
                                OmitirPrimeraBarra = LeerBool(
                                    grupoXml.Attribute("OmitirPrimera"),
                                    false),
                                OmitirUltimaBarra = LeerBool(
                                    grupoXml.Attribute("OmitirUltima"),
                                    false),
                                ParametroInicioGuia = LeerDouble(
                                    grupoXml.Attribute("ParametroInicioGuia"),
                                    -1.0),
                                ParametroFinGuia = LeerDouble(
                                    grupoXml.Attribute("ParametroFinGuia"),
                                    -1.0),
                                RespetarTrazoDosPuntos = LeerBool(
                                    grupoXml.Attribute("RespetarTrazoDosPuntos"),
                                    false),
                                PuntoInicio = new AceroVigaPuntoNormalizado(
                                    LeerDouble(
                                        puntoInicioXml != null
                                            ? puntoInicioXml.Attribute("U")
                                            : null,
                                        0.0),
                                    LeerDouble(
                                        puntoInicioXml != null
                                            ? puntoInicioXml.Attribute("V")
                                            : null,
                                        0.5)),
                                PuntoFin = new AceroVigaPuntoNormalizado(
                                    LeerDouble(
                                        puntoFinXml != null
                                            ? puntoFinXml.Attribute("U")
                                            : null,
                                        1.0),
                                    LeerDouble(
                                        puntoFinXml != null
                                            ? puntoFinXml.Attribute("V")
                                            : null,
                                        0.5)),
                                PuntoInicioSeccionReal =
                                    puntoInicioRealXml != null &&
                                    LeerDouble(puntoInicioRealXml.Attribute("U"), -1.0) >= 0.0
                                        ? new AceroVigaPuntoNormalizado(
                                            LeerDouble(puntoInicioRealXml.Attribute("U"), 0.0),
                                            LeerDouble(puntoInicioRealXml.Attribute("V"), 0.5))
                                        : null,
                                PuntoFinSeccionReal =
                                    puntoFinRealXml != null &&
                                    LeerDouble(puntoFinRealXml.Attribute("U"), -1.0) >= 0.0
                                        ? new AceroVigaPuntoNormalizado(
                                            LeerDouble(puntoFinRealXml.Attribute("U"), 1.0),
                                            LeerDouble(puntoFinRealXml.Attribute("V"), 0.5))
                                        : null
                            };

                        nuevo.GruposLongitudinales.Add(grupoNuevo);
                    }
                }

                XElement guiasXml = raiz.Element("GuiasCapasLongitudinales");
                if (guiasXml != null)
                {
                    foreach (XElement guiaXml in guiasXml.Elements("Guia"))
                    {
                        AceroVigaTipoCapaLongitudinal tipoGuia =
                            AceroVigaTipoCapaLongitudinal.SinDefinir;
                        Enum.TryParse(
                            (string)guiaXml.Attribute("Tipo") ?? "SinDefinir",
                            true,
                            out tipoGuia);
                        AceroVigaGuiaCapaLongitudinal2D guiaNueva =
                            new AceroVigaGuiaCapaLongitudinal2D
                            {
                                Id = (string)guiaXml.Attribute("Id") ??
                                    Guid.NewGuid().ToString("N"),
                                Tipo = tipoGuia,
                                NumeroCapa = (int?)guiaXml.Attribute("Numero") ?? 1,
                                V = LeerDouble(guiaXml.Attribute("V"), 0.5),
                                SeparacionLibreCm = LeerDouble(
                                    guiaXml.Attribute("SeparacionLibreCm"), 2.5),
                                DiametroReferenciaMm = LeerDouble(
                                    guiaXml.Attribute("DiametroReferenciaMm"), 12.7),
                                OffsetAcumuladoMm = LeerDouble(
                                    guiaXml.Attribute("OffsetAcumuladoMm"), 0.0),
                                AdaptadaAlContorno = (bool?)guiaXml.Attribute("Adaptada") ?? true
                            };

                        XElement puntosGuiaXml = guiaXml.Element("PuntosGuia");
                        if (puntosGuiaXml != null)
                        {
                            foreach (XElement puntoXml in puntosGuiaXml.Elements("P"))
                            {
                                guiaNueva.PuntosGuia.Add(
                                    new AceroVigaPuntoNormalizado(
                                        LeerDouble(puntoXml.Attribute("U"), 0.5),
                                        LeerDouble(puntoXml.Attribute("V"), guiaNueva.V)));
                            }
                        }

                        XElement puntosGuiaRealXml =
                            guiaXml.Element("PuntosGuiaSeccionReal");
                        if (puntosGuiaRealXml != null)
                        {
                            foreach (XElement puntoXml in
                                puntosGuiaRealXml.Elements("P"))
                            {
                                guiaNueva.PuntosGuiaSeccionReal.Add(
                                    new AceroVigaPuntoNormalizado(
                                        LeerDouble(
                                            puntoXml.Attribute("U"),
                                            0.5),
                                        LeerDouble(
                                            puntoXml.Attribute("V"),
                                            guiaNueva.V)));
                            }
                        }
                        nuevo.GuiasCapasLongitudinales.Add(guiaNueva);
                    }
                }

                XElement estribos = raiz.Element("Estribos");
                if (estribos != null)
                {
                    foreach (XElement elementoEstriboXml in estribos.Elements("Estribo"))
                    {
                        string nombreTipo = (string)elementoEstriboXml.Attribute("Tipo") ?? string.Empty;
                        RebarBarType tipo = ResolverTipoPorNombre(nombreTipo, TipoEstriboActual);
                        AceroVigaTipoEstribo2D forma =
                            AceroVigaTipoEstribo2D.Croquis;

                        string textoForma =
                            (string)elementoEstriboXml.Attribute("Forma") ??
                            string.Empty;

                        AceroVigaTipoEstribo2D formaLeida;
                        if (Enum.TryParse(textoForma, true, out formaLeida))
                            forma = formaLeida;

                        AceroVigaEstribo2D e = new AceroVigaEstribo2D
                        {
                            Tipo = forma,
                            TipoBarra = tipo,
                            DiametroMm = ObtenerDiametroMm(tipo),
                            Cerrado = LeerBool(elementoEstriboXml.Attribute("Cerrado"), true),
                            UsarContornoOffsetAutomatico = LeerBool(elementoEstriboXml.Attribute("Automatico"), false),
                            IndiceEsquinaGancho = LeerInt(elementoEstriboXml.Attribute("Gancho"), -1)
                        };

                        XElement puntos = elementoEstriboXml.Element("Puntos");
                        if (puntos != null)
                        {
                            foreach (XElement p in puntos.Elements("P"))
                            {
                                e.Puntos.Add(new AceroVigaPuntoNormalizado(
                                    LeerDouble(p.Attribute("U"), 0.5),
                                    LeerDouble(p.Attribute("V"), 0.5)));
                            }
                        }
                        nuevo.Estribos.Add(e);
                    }
                }

                RegistrarHistorial();
                disenoTrabajo = nuevo;
                double recubrimientoCargado =
                    modoEditorActual ==
                    AceroVigaModoEditorInicial.Estribos
                        ? nuevo.RecubrimientoEstribosCm
                        : nuevo.RecubrimientoLongitudinalCm;

                nudRecubrimiento.Value = (decimal)Math.Max(
                    (double)nudRecubrimiento.Minimum,
                    Math.Min(
                        (double)nudRecubrimiento.Maximum,
                        recubrimientoCargado));
                bool tieneGuiasPersistidas =
                            nuevo.GuiasCapasLongitudinales != null &&
                            nuevo.GuiasCapasLongitudinales.Any(g =>
                                g != null &&
                                ((g.PuntosGuiaSeccionReal != null && g.PuntosGuiaSeccionReal.Count >= 2) ||
                                 (g.PuntosGuia != null && g.PuntosGuia.Count >= 2)));

                // Si el archivo ya contiene las guías dibujadas, se respetan exactamente.
                // Solo se regeneran para archivos antiguos sin geometría persistida.
                if (!tieneGuiasPersistidas)
                    RecalcularGuiasCapasLongitudinales();
                ReconstruirTodosLosGruposLongitudinales();
                idSeleccionado = string.Empty;
                idsEstribosSeleccionados.Clear();
                indiceVerticeSeleccionado = -1;
                ActualizarResumen();
                panelLienzo.Invalidate();

                // Publica inmediatamente el diseño restaurado para los handlers
                // y para la otra pestaña del editor.
                DisenoResultado = disenoTrabajo != null
                    ? disenoTrabajo.Copiar()
                    : new AceroVigaDisenoSeccion();
                AceroVigaDisenoSeccionCompartido.Establecer(DisenoResultado);
                PublicarCambiosIncrustados();
                return true;
            }
            catch (Exception ex)
            {
                mensajeError = ex.Message;
                return false;
            }
        }

        private void GuardarDiseno()
        {
            ActualizarCoordenadasSeccionRealLongitudinales();

            using (WinForms.SaveFileDialog dlg = new WinForms.SaveFileDialog())
            {
                dlg.Title = "Guardar diseño de sección de viga";
                dlg.Filter = "Diseño MYG de sección (*.mygviga.xml)|*.mygviga.xml|XML (*.xml)|*.xml";
                dlg.FileName = "Diseno_Seccion_Viga.mygviga.xml";
                if (dlg.ShowDialog(this) != WinForms.DialogResult.OK)
                    return;

                XElement raiz = new XElement("AceroVigaDisenoSeccion",
                    new XAttribute("Version", 19),
                    new XElement(
                        "RecubrimientoCm",
                        disenoTrabajo.RecubrimientoCm.ToString(
                            "0.###",
                            CultureInfo.InvariantCulture)),
                    new XElement(
                        "RecubrimientoLongitudinalCm",
                        disenoTrabajo.RecubrimientoLongitudinalCm.ToString(
                            "0.###",
                            CultureInfo.InvariantCulture)),
                    new XElement(
                        "RecubrimientoEstribosCm",
                        disenoTrabajo.RecubrimientoEstribosCm.ToString(
                            "0.###",
                            CultureInfo.InvariantCulture)),
                    new XElement("NombreSeccion", disenoTrabajo.NombreSeccionReferencia ?? string.Empty),
                    new XElement("Longitudinales",
                        disenoTrabajo.Longitudinales.Select(x =>
                            new XElement("Barra",
                                new XAttribute("Id", x.Id ?? string.Empty),
                                new XAttribute("Tipo", x.TipoBarra != null ? x.TipoBarra.Name : string.Empty),
                                new XAttribute("U", x.Punto != null ? x.Punto.U.ToString("0.########", CultureInfo.InvariantCulture) : "0.5"),
                                new XAttribute("V", x.Punto != null ? x.Punto.V.ToString("0.########", CultureInfo.InvariantCulture) : "0.5"),
                                new XAttribute("USec", x.PuntoSeccionReal != null ? x.PuntoSeccionReal.U.ToString("0.########", CultureInfo.InvariantCulture) : "-1"),
                                new XAttribute("VSec", x.PuntoSeccionReal != null ? x.PuntoSeccionReal.V.ToString("0.########", CultureInfo.InvariantCulture) : "-1"),
                                new XAttribute("Grupo", x.GrupoDistribucionId ?? string.Empty),
                                new XAttribute("Guia", x.GuiaCapaId ?? string.Empty),
                                new XAttribute("TipoCapa", x.TipoCapa.ToString()),
                                new XAttribute("NumeroCapa", x.NumeroCapa),
                                new XAttribute("ParametroGuia", x.ParametroSobreGuia.ToString("0.########", CultureInfo.InvariantCulture)),
                                new XAttribute("DesfaseNormalGuiaMm", x.DesfaseNormalGuiaMm.ToString("0.########", CultureInfo.InvariantCulture)),
                                new XAttribute("PosicionExacta", x.UsarPosicionExactaSeccion),
                                new XAttribute("OcultaSuperposicion", x.OcultaPorSuperposicion)))),
                    new XElement("GruposLongitudinales",
                        (disenoTrabajo.GruposLongitudinales ??
                            new List<AceroVigaGrupoLongitudinal2D>()).Select(x =>
                            new XElement("Grupo",
                                new XAttribute("Id", x.Id ?? string.Empty),
                                new XAttribute("Tipo", x.TipoBarra != null ? x.TipoBarra.Name : string.Empty),
                                new XAttribute("DiametroMm", x.DiametroMm.ToString("0.###", CultureInfo.InvariantCulture)),
                                new XAttribute("Guia", x.GuiaCapaId ?? string.Empty),
                                new XAttribute("TipoCapa", x.TipoCapa.ToString()),
                                new XAttribute("NumeroCapa", x.NumeroCapa),
                                new XAttribute("Regla", x.Regla.ToString()),
                                new XAttribute("EspaciadoCm", x.EspaciadoCm.ToString("0.###", CultureInfo.InvariantCulture)),
                                new XAttribute("Cantidad", x.Cantidad),
                                new XAttribute("OmitirPrimera", x.OmitirPrimeraBarra),
                                new XAttribute("OmitirUltima", x.OmitirUltimaBarra),
                                new XAttribute("ParametroInicioGuia", x.ParametroInicioGuia.ToString("0.########", CultureInfo.InvariantCulture)),
                                new XAttribute("ParametroFinGuia", x.ParametroFinGuia.ToString("0.########", CultureInfo.InvariantCulture)),
                                new XAttribute("RespetarTrazoDosPuntos", x.RespetarTrazoDosPuntos),
                                new XElement("PuntoInicio",
                                    new XAttribute("U", x.PuntoInicio != null ? x.PuntoInicio.U.ToString("0.########", CultureInfo.InvariantCulture) : "0"),
                                    new XAttribute("V", x.PuntoInicio != null ? x.PuntoInicio.V.ToString("0.########", CultureInfo.InvariantCulture) : "0.5")),
                                new XElement("PuntoFin",
                                    new XAttribute("U", x.PuntoFin != null ? x.PuntoFin.U.ToString("0.########", CultureInfo.InvariantCulture) : "1"),
                                    new XAttribute("V", x.PuntoFin != null ? x.PuntoFin.V.ToString("0.########", CultureInfo.InvariantCulture) : "0.5")),
                                new XElement("PuntoInicioSeccionReal",
                                    new XAttribute("U", x.PuntoInicioSeccionReal != null ? x.PuntoInicioSeccionReal.U.ToString("0.########", CultureInfo.InvariantCulture) : "-1"),
                                    new XAttribute("V", x.PuntoInicioSeccionReal != null ? x.PuntoInicioSeccionReal.V.ToString("0.########", CultureInfo.InvariantCulture) : "-1")),
                                new XElement("PuntoFinSeccionReal",
                                    new XAttribute("U", x.PuntoFinSeccionReal != null ? x.PuntoFinSeccionReal.U.ToString("0.########", CultureInfo.InvariantCulture) : "-1"),
                                    new XAttribute("V", x.PuntoFinSeccionReal != null ? x.PuntoFinSeccionReal.V.ToString("0.########", CultureInfo.InvariantCulture) : "-1"))))),
                    new XElement("GuiasCapasLongitudinales",
                        disenoTrabajo.GuiasCapasLongitudinales.Select(x =>
                            new XElement("Guia",
                                new XAttribute("Id", x.Id ?? string.Empty),
                                new XAttribute("Tipo", x.Tipo.ToString()),
                                new XAttribute("Numero", x.NumeroCapa),
                                new XAttribute("V", x.V.ToString("0.########", CultureInfo.InvariantCulture)),
                                new XAttribute("SeparacionLibreCm", x.SeparacionLibreCm.ToString("0.###", CultureInfo.InvariantCulture)),
                                new XAttribute("DiametroReferenciaMm", x.DiametroReferenciaMm.ToString("0.###", CultureInfo.InvariantCulture)),
                                new XAttribute("OffsetAcumuladoMm", x.OffsetAcumuladoMm.ToString("0.###", CultureInfo.InvariantCulture)),
                                new XAttribute("Adaptada", x.AdaptadaAlContorno),
                                new XElement("PuntosGuia",
                                    (x.PuntosGuia ?? new List<AceroVigaPuntoNormalizado>()).Select(p =>
                                        new XElement("P",
                                            new XAttribute("U", p.U.ToString("0.########", CultureInfo.InvariantCulture)),
                                            new XAttribute("V", p.V.ToString("0.########", CultureInfo.InvariantCulture))))),
                                new XElement("PuntosGuiaSeccionReal",
                                    (x.PuntosGuiaSeccionReal ?? new List<AceroVigaPuntoNormalizado>()).Select(p =>
                                        new XElement("P",
                                            new XAttribute("U", p.U.ToString("0.########", CultureInfo.InvariantCulture)),
                                            new XAttribute("V", p.V.ToString("0.########", CultureInfo.InvariantCulture)))))))),
                    new XElement("Estribos",
                        disenoTrabajo.Estribos.Select(x =>
                            new XElement("Estribo",
                                new XAttribute("Tipo", x.TipoBarra != null ? x.TipoBarra.Name : string.Empty),
                                new XAttribute("Forma", x.Tipo.ToString()),
                                new XAttribute("Cerrado", x.Cerrado),
                                new XAttribute("Automatico", x.UsarContornoOffsetAutomatico),
                                new XAttribute("Gancho", x.IndiceEsquinaGancho),
                                new XElement("Puntos",
                                    x.Puntos.Select(p =>
                                        new XElement("P",
                                            new XAttribute("U", p.U.ToString("0.########", CultureInfo.InvariantCulture)),
                                            new XAttribute("V", p.V.ToString("0.########", CultureInfo.InvariantCulture)))))))));

                new XDocument(raiz).Save(dlg.FileName);
            }
        }

        private void CargarDiseno()
        {
            using (WinForms.OpenFileDialog dlg = new WinForms.OpenFileDialog())
            {
                dlg.Title = "Cargar diseño de sección de viga";
                dlg.Filter = "Diseño MYG de sección (*.mygviga.xml;*.xml)|*.mygviga.xml;*.xml";
                if (dlg.ShowDialog(this) != WinForms.DialogResult.OK)
                    return;

                try
                {
                    XDocument doc = XDocument.Load(dlg.FileName);
                    XElement raiz = doc.Root;
                    if (raiz == null)
                        return;

                    AceroVigaDisenoSeccion nuevo =
                        new AceroVigaDisenoSeccion();

                    double recubrimientoAnterior = LeerDouble(
                        raiz.Element("RecubrimientoCm"),
                        4.0);

                    nuevo.RecubrimientoCm = recubrimientoAnterior;
                    nuevo.RecubrimientoLongitudinalCm = LeerDouble(
                        raiz.Element("RecubrimientoLongitudinalCm"),
                        recubrimientoAnterior);
                    nuevo.RecubrimientoEstribosCm = LeerDouble(
                        raiz.Element("RecubrimientoEstribosCm"),
                        recubrimientoAnterior);

                    nuevo.NombreSeccionReferencia =
                        (string)raiz.Element("NombreSeccion") ??
                        string.Empty;

                    XElement longs = raiz.Element("Longitudinales");
                    if (longs != null)
                    {
                        foreach (XElement elementoBarraXml in longs.Elements("Barra"))
                        {
                            string nombreTipo = (string)elementoBarraXml.Attribute("Tipo") ?? string.Empty;
                            RebarBarType tipo = ResolverTipoPorNombre(nombreTipo, TipoLongitudinalActual);
                            AceroVigaTipoCapaLongitudinal tipoCapa =
                                AceroVigaTipoCapaLongitudinal.SinDefinir;
                            Enum.TryParse(
                                (string)elementoBarraXml.Attribute("TipoCapa") ?? "SinDefinir",
                                true,
                                out tipoCapa);
                            nuevo.Longitudinales.Add(new AceroVigaBarraLongitudinal2D
                            {
                                Id = (string)elementoBarraXml.Attribute("Id") ??
                                    Guid.NewGuid().ToString("N"),
                                TipoBarra = tipo,
                                DiametroMm = ObtenerDiametroMm(tipo),
                                Punto = new AceroVigaPuntoNormalizado(
                                    LeerDouble(elementoBarraXml.Attribute("U"), 0.5),
                                    LeerDouble(elementoBarraXml.Attribute("V"), 0.5)),
                                PuntoSeccionReal =
                                    elementoBarraXml.Attribute("USec") != null &&
                                    elementoBarraXml.Attribute("VSec") != null &&
                                    LeerDouble(elementoBarraXml.Attribute("USec"), -1.0) >= 0.0 &&
                                    LeerDouble(elementoBarraXml.Attribute("VSec"), -1.0) >= 0.0
                                        ? new AceroVigaPuntoNormalizado(
                                            LeerDouble(elementoBarraXml.Attribute("USec"), 0.5),
                                            LeerDouble(elementoBarraXml.Attribute("VSec"), 0.5))
                                        : null,
                                GrupoDistribucionId =
                                    (string)elementoBarraXml.Attribute("Grupo") ?? string.Empty,
                                GuiaCapaId =
                                    (string)elementoBarraXml.Attribute("Guia") ?? string.Empty,
                                TipoCapa = tipoCapa,
                                NumeroCapa = (int?)elementoBarraXml.Attribute("NumeroCapa") ?? 0,
                                ParametroSobreGuia = LeerDouble(
                                    elementoBarraXml.Attribute("ParametroGuia"), -1.0),
                                DesfaseNormalGuiaMm = LeerDouble(
                                    elementoBarraXml.Attribute("DesfaseNormalGuiaMm"), 0.0),
                                UsarPosicionExactaSeccion = LeerBool(
                                    elementoBarraXml.Attribute("PosicionExacta"),
                                    false),
                                OcultaPorSuperposicion = LeerBool(
                                    elementoBarraXml.Attribute("OcultaSuperposicion"),
                                    false)
                            });
                        }
                    }

                    XElement gruposXml = raiz.Element("GruposLongitudinales");
                    if (gruposXml != null)
                    {
                        foreach (XElement grupoXml in gruposXml.Elements("Grupo"))
                        {
                            string nombreTipoGrupo =
                                (string)grupoXml.Attribute("Tipo") ?? string.Empty;
                            RebarBarType tipoGrupo = ResolverTipoPorNombre(
                                nombreTipoGrupo,
                                TipoLongitudinalActual);

                            AceroVigaTipoCapaLongitudinal tipoCapaGrupo =
                                AceroVigaTipoCapaLongitudinal.SinDefinir;
                            Enum.TryParse(
                                (string)grupoXml.Attribute("TipoCapa") ??
                                    "SinDefinir",
                                true,
                                out tipoCapaGrupo);

                            AceroVigaReglaGrupoLongitudinal reglaGrupo =
                                AceroVigaReglaGrupoLongitudinal.NumeroFijo;
                            Enum.TryParse(
                                (string)grupoXml.Attribute("Regla") ??
                                    "NumeroFijo",
                                true,
                                out reglaGrupo);

                            if (reglaGrupo !=
                                AceroVigaReglaGrupoLongitudinal.EspaciadoMaximo)
                            {
                                reglaGrupo =
                                    AceroVigaReglaGrupoLongitudinal.NumeroFijo;
                            }

                            XElement puntoInicioXml =
                                grupoXml.Element("PuntoInicio");
                            XElement puntoFinXml =
                                grupoXml.Element("PuntoFin");
                            XElement puntoInicioRealXml =
                                grupoXml.Element("PuntoInicioSeccionReal");
                            XElement puntoFinRealXml =
                                grupoXml.Element("PuntoFinSeccionReal");

                            AceroVigaGrupoLongitudinal2D grupoNuevo =
                                new AceroVigaGrupoLongitudinal2D
                                {
                                    Id = (string)grupoXml.Attribute("Id") ??
                                        Guid.NewGuid().ToString("N"),
                                    TipoBarra = tipoGrupo,
                                    DiametroMm = LeerDouble(
                                        grupoXml.Attribute("DiametroMm"),
                                        ObtenerDiametroMm(tipoGrupo)),
                                    GuiaCapaId =
                                        (string)grupoXml.Attribute("Guia") ??
                                        string.Empty,
                                    TipoCapa = tipoCapaGrupo,
                                    NumeroCapa =
                                        (int?)grupoXml.Attribute("NumeroCapa") ?? 0,
                                    Regla = reglaGrupo,
                                    EspaciadoCm = LeerDouble(
                                        grupoXml.Attribute("EspaciadoCm"),
                                        20.0),
                                    Cantidad = Math.Max(
                                        1,
                                        (int?)grupoXml.Attribute("Cantidad") ?? 4),
                                    OmitirPrimeraBarra = LeerBool(
                                        grupoXml.Attribute("OmitirPrimera"),
                                        false),
                                    OmitirUltimaBarra = LeerBool(
                                        grupoXml.Attribute("OmitirUltima"),
                                        false),
                                    ParametroInicioGuia = LeerDouble(
                                        grupoXml.Attribute("ParametroInicioGuia"),
                                        -1.0),
                                    ParametroFinGuia = LeerDouble(
                                        grupoXml.Attribute("ParametroFinGuia"),
                                        -1.0),
                                    RespetarTrazoDosPuntos = LeerBool(
                                        grupoXml.Attribute("RespetarTrazoDosPuntos"),
                                        false),
                                    PuntoInicio = new AceroVigaPuntoNormalizado(
                                        LeerDouble(
                                            puntoInicioXml != null
                                                ? puntoInicioXml.Attribute("U")
                                                : null,
                                            0.0),
                                        LeerDouble(
                                            puntoInicioXml != null
                                                ? puntoInicioXml.Attribute("V")
                                                : null,
                                            0.5)),
                                    PuntoFin = new AceroVigaPuntoNormalizado(
                                        LeerDouble(
                                            puntoFinXml != null
                                                ? puntoFinXml.Attribute("U")
                                                : null,
                                            1.0),
                                        LeerDouble(
                                            puntoFinXml != null
                                                ? puntoFinXml.Attribute("V")
                                                : null,
                                            0.5)),
                                    PuntoInicioSeccionReal =
                                        puntoInicioRealXml != null &&
                                        LeerDouble(puntoInicioRealXml.Attribute("U"), -1.0) >= 0.0
                                            ? new AceroVigaPuntoNormalizado(
                                                LeerDouble(puntoInicioRealXml.Attribute("U"), 0.0),
                                                LeerDouble(puntoInicioRealXml.Attribute("V"), 0.5))
                                            : null,
                                    PuntoFinSeccionReal =
                                        puntoFinRealXml != null &&
                                        LeerDouble(puntoFinRealXml.Attribute("U"), -1.0) >= 0.0
                                            ? new AceroVigaPuntoNormalizado(
                                                LeerDouble(puntoFinRealXml.Attribute("U"), 1.0),
                                                LeerDouble(puntoFinRealXml.Attribute("V"), 0.5))
                                            : null
                                };

                            nuevo.GruposLongitudinales.Add(grupoNuevo);
                        }
                    }

                    XElement guiasXml = raiz.Element("GuiasCapasLongitudinales");
                    if (guiasXml != null)
                    {
                        foreach (XElement guiaXml in guiasXml.Elements("Guia"))
                        {
                            AceroVigaTipoCapaLongitudinal tipoGuia =
                                AceroVigaTipoCapaLongitudinal.SinDefinir;
                            Enum.TryParse(
                                (string)guiaXml.Attribute("Tipo") ?? "SinDefinir",
                                true,
                                out tipoGuia);
                            AceroVigaGuiaCapaLongitudinal2D guiaNueva =
                                new AceroVigaGuiaCapaLongitudinal2D
                                {
                                    Id = (string)guiaXml.Attribute("Id") ??
                                        Guid.NewGuid().ToString("N"),
                                    Tipo = tipoGuia,
                                    NumeroCapa = (int?)guiaXml.Attribute("Numero") ?? 1,
                                    V = LeerDouble(guiaXml.Attribute("V"), 0.5),
                                    SeparacionLibreCm = LeerDouble(
                                        guiaXml.Attribute("SeparacionLibreCm"), 2.5),
                                    DiametroReferenciaMm = LeerDouble(
                                        guiaXml.Attribute("DiametroReferenciaMm"), 12.7),
                                    OffsetAcumuladoMm = LeerDouble(
                                        guiaXml.Attribute("OffsetAcumuladoMm"), 0.0),
                                    AdaptadaAlContorno = (bool?)guiaXml.Attribute("Adaptada") ?? true
                                };

                            XElement puntosGuiaXml = guiaXml.Element("PuntosGuia");
                            if (puntosGuiaXml != null)
                            {
                                foreach (XElement puntoXml in puntosGuiaXml.Elements("P"))
                                {
                                    guiaNueva.PuntosGuia.Add(
                                        new AceroVigaPuntoNormalizado(
                                            LeerDouble(puntoXml.Attribute("U"), 0.5),
                                            LeerDouble(puntoXml.Attribute("V"), guiaNueva.V)));
                                }
                            }

                            XElement puntosGuiaRealXml =
                                guiaXml.Element("PuntosGuiaSeccionReal");
                            if (puntosGuiaRealXml != null)
                            {
                                foreach (XElement puntoXml in
                                    puntosGuiaRealXml.Elements("P"))
                                {
                                    guiaNueva.PuntosGuiaSeccionReal.Add(
                                        new AceroVigaPuntoNormalizado(
                                            LeerDouble(
                                                puntoXml.Attribute("U"),
                                                0.5),
                                            LeerDouble(
                                                puntoXml.Attribute("V"),
                                                guiaNueva.V)));
                                }
                            }
                            nuevo.GuiasCapasLongitudinales.Add(guiaNueva);
                        }
                    }

                    XElement estribos = raiz.Element("Estribos");
                    if (estribos != null)
                    {
                        foreach (XElement elementoEstriboXml in estribos.Elements("Estribo"))
                        {
                            string nombreTipo = (string)elementoEstriboXml.Attribute("Tipo") ?? string.Empty;
                            RebarBarType tipo = ResolverTipoPorNombre(nombreTipo, TipoEstriboActual);
                            AceroVigaTipoEstribo2D forma =
                                AceroVigaTipoEstribo2D.Croquis;

                            string textoForma =
                                (string)elementoEstriboXml.Attribute("Forma") ??
                                string.Empty;

                            AceroVigaTipoEstribo2D formaLeida;
                            if (Enum.TryParse(textoForma, true, out formaLeida))
                                forma = formaLeida;

                            AceroVigaEstribo2D e = new AceroVigaEstribo2D
                            {
                                Tipo = forma,
                                TipoBarra = tipo,
                                DiametroMm = ObtenerDiametroMm(tipo),
                                Cerrado = LeerBool(elementoEstriboXml.Attribute("Cerrado"), true),
                                UsarContornoOffsetAutomatico = LeerBool(elementoEstriboXml.Attribute("Automatico"), false),
                                IndiceEsquinaGancho = LeerInt(elementoEstriboXml.Attribute("Gancho"), -1)
                            };

                            XElement puntos = elementoEstriboXml.Element("Puntos");
                            if (puntos != null)
                            {
                                foreach (XElement p in puntos.Elements("P"))
                                {
                                    e.Puntos.Add(new AceroVigaPuntoNormalizado(
                                        LeerDouble(p.Attribute("U"), 0.5),
                                        LeerDouble(p.Attribute("V"), 0.5)));
                                }
                            }
                            nuevo.Estribos.Add(e);
                        }
                    }

                    RegistrarHistorial();
                    disenoTrabajo = nuevo;
                    double recubrimientoCargado =
                        modoEditorActual ==
                        AceroVigaModoEditorInicial.Estribos
                            ? nuevo.RecubrimientoEstribosCm
                            : nuevo.RecubrimientoLongitudinalCm;

                    nudRecubrimiento.Value = (decimal)Math.Max(
                        (double)nudRecubrimiento.Minimum,
                        Math.Min(
                            (double)nudRecubrimiento.Maximum,
                            recubrimientoCargado));
                    RecalcularGuiasCapasLongitudinales();
                    ReconstruirTodosLosGruposLongitudinales();
                    idSeleccionado = string.Empty;
                    idsEstribosSeleccionados.Clear();
                    indiceVerticeSeleccionado = -1;
                    ActualizarResumen();
                    panelLienzo.Invalidate();
                }
                catch (Exception ex)
                {
                    WinForms.MessageBox.Show(
                        this,
                        "No se pudo cargar el diseño:\n\n" + ex.Message,
                        "MYG",
                        WinForms.MessageBoxButtons.OK,
                        WinForms.MessageBoxIcon.Error);
                }
            }
        }

        private RebarBarType ResolverTipoPorNombre(string nombre, RebarBarType respaldo)
        {
            if (!string.IsNullOrWhiteSpace(nombre))
            {
                RebarBarType encontrado = tiposDisponibles.FirstOrDefault(x =>
                    x != null && string.Equals(x.Name, nombre, StringComparison.OrdinalIgnoreCase));
                if (encontrado != null)
                    return encontrado;
            }
            return respaldo ?? tiposDisponibles.FirstOrDefault();
        }

        private static double LeerDouble(XElement elemento, double respaldo)
        {
            if (elemento == null)
                return respaldo;

            double valor;
            return double.TryParse(
                elemento.Value,
                NumberStyles.Any,
                CultureInfo.InvariantCulture,
                out valor)
                ? valor
                : respaldo;
        }

        private static double LeerDouble(XAttribute atributo, double respaldo)
        {
            if (atributo == null)
                return respaldo;

            double valor;
            return double.TryParse(
                atributo.Value,
                NumberStyles.Any,
                CultureInfo.InvariantCulture,
                out valor)
                ? valor
                : respaldo;
        }

        private static bool LeerBool(XAttribute atributo, bool respaldo)
        {
            bool valor;
            return atributo != null && bool.TryParse(atributo.Value, out valor)
                ? valor
                : respaldo;
        }

        private static int LeerInt(XAttribute atributo, int respaldo)
        {
            int valor;
            return atributo != null && int.TryParse(atributo.Value, out valor)
                ? valor
                : respaldo;
        }

        private sealed class LienzoSeccion : WinForms.Panel
        {
            private readonly AceroVigaEditorSeccionForm owner;

            public LienzoSeccion(AceroVigaEditorSeccionForm owner)
            {
                this.owner = owner;
                DoubleBuffered = true;
                ResizeRedraw = true;
                TabStop = true;
                Cursor = WinForms.Cursors.Cross;
                SetStyle(
                    WinForms.ControlStyles.AllPaintingInWmPaint |
                    WinForms.ControlStyles.UserPaint |
                    WinForms.ControlStyles.OptimizedDoubleBuffer |
                    WinForms.ControlStyles.Selectable,
                    true);
            }

            protected override void OnMouseEnter(EventArgs e)
            {
                base.OnMouseEnter(e);
                Focus();
            }

            protected override void OnMouseWheel(WinForms.MouseEventArgs e)
            {
                base.OnMouseWheel(e);
                owner.OnLienzoMouseWheel(e);
            }

            protected override void OnPaint(WinForms.PaintEventArgs e)
            {
                base.OnPaint(e);
                owner.DibujarLienzo(e.Graphics, ClientRectangle);
            }

            protected override void OnMouseDown(WinForms.MouseEventArgs e)
            {
                base.OnMouseDown(e);
                owner.OnLienzoMouseDown(e);
            }

            protected override void OnMouseMove(WinForms.MouseEventArgs e)
            {
                base.OnMouseMove(e);
                owner.OnLienzoMouseMove(e);
            }

            protected override void OnMouseLeave(EventArgs e)
            {
                base.OnMouseLeave(e);
                owner.OnLienzoMouseLeave();
            }

            protected override void OnMouseUp(WinForms.MouseEventArgs e)
            {
                base.OnMouseUp(e);
                owner.OnLienzoMouseUp(e);
            }

            protected override void OnMouseDoubleClick(WinForms.MouseEventArgs e)
            {
                base.OnMouseDoubleClick(e);
                owner.OnLienzoDoubleClick(e);
            }
        }
    }
}
