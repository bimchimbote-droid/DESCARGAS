﻿using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Linq;
using Drawing = System.Drawing;
using WinForms = System.Windows.Forms;


// =====================================
// CLASE AUXILIAR - VISTA PRELIMINAR DE VIGA
// MODIFICADA:
// - Mantiene compatibilidad con la propiedad Columnas.
// - Permite registrar columnas y vigas transversales como apoyos.
// - Ordena y depura apoyos repetidos.
// - La detección real de Revit sigue estando en el handler de selección.
// =====================================
public class VigaLongitudinalPreview
{
    public double LongitudMm { get; set; }

    // Longitud visible/libre del sólido real de la viga.
    // Se mantiene como respaldo para la ventana.
    public double LongitudSolidoMm { get; set; }

    // Datos geométricos para que la ventana pueda detectar inclinación.
    public double DeltaZMm { get; set; }
    public double ProyeccionHorizontalMm { get; set; }
    public double AnguloGrados { get; set; }
    public bool EsInclinada { get; set; }

    // =========================================================
    // FORMA DE SECCIÓN DETECTADA DESDE LA SELECCIÓN REAL
    // =========================================================
    // Se llena desde SeleccionarVigasAceroLongitudinalHandler.
    // El MAIN y las ventanas lo leen por reflexión para no depender
    // solo del conteo simplificado de lados del preview.
    public bool EsCumbreraDetectada { get; set; }
    public int LadosSeccionTransversalDetectados { get; set; }
    public string MotivoDeteccionForma { get; set; }

    // PERFIL LIMPIO PARA VIGAS / ARMAZONES DE SECCIÓN VARIABLE.
    // Se guarda solo inicio y fin de la cara superior/inferior.
    // No se guardan todos los vértices del sólido para evitar picos o quiebres falsos.
    public bool TienePerfilSeccionVariable { get; set; }
    public double ZSuperiorInicioMm { get; set; }
    public double ZSuperiorFinMm { get; set; }
    public double ZInferiorInicioMm { get; set; }
    public double ZInferiorFinMm { get; set; }

    // PERFIL DETALLADO PARA QUE LA VENTANA Y EL HANDLER USEN LA MISMA RUTA.
    // La ventana lo lee por reflexión con los nombres PerfilSuperiorMm / PerfilInferiorMm.
    public class PuntoPerfilMm
    {
        public double XMm { get; set; }
        public double ZMm { get; set; }

        public PuntoPerfilMm(double xMm, double zMm)
        {
            XMm = xMm;
            ZMm = zMm;
        }
    }

    public List<PuntoPerfilMm> PerfilSuperiorMm { get; set; }
    public List<PuntoPerfilMm> PerfilInferiorMm { get; set; }

    // =========================================================
    // GEOMETRÍA 3D REAL DEL SÓLIDO DE REVIT PARA PREVIEW
    // =========================================================
    public class Punto3DPreview
    {
        public double XMm { get; set; }
        public double YMm { get; set; }
        public double ZMm { get; set; }

        public Punto3DPreview()
        {
            XMm = 0.0;
            YMm = 0.0;
            ZMm = 0.0;
        }

        public Punto3DPreview(double xMm, double yMm, double zMm)
        {
            XMm = xMm;
            YMm = yMm;
            ZMm = zMm;
        }
    }

    public class Cara3DPreview
    {
        public List<int> IndicesPuntos { get; set; }

        public Cara3DPreview()
        {
            IndicesPuntos = new List<int>();
        }

        public Cara3DPreview(params int[] indices)
        {
            IndicesPuntos = new List<int>();

            if (indices != null)
                IndicesPuntos.AddRange(indices);
        }
    }

    public class Solido3DPreview
    {
        public List<Punto3DPreview> Puntos { get; set; }
        public List<Cara3DPreview> Caras { get; set; }

        public Solido3DPreview()
        {
            Puntos = new List<Punto3DPreview>();
            Caras = new List<Cara3DPreview>();
        }
    }

    // =========================================================
    // INTERVALOS LONGITUDINALES REALES DEL SÓLIDO DE LA VIGA
    // =========================================================
    // Cada intervalo representa una porción continua de concreto sobre el eje
    // longitudinal. Si un corte divide un mismo ElementId en dos cuerpos,
    // la vista 2D recibirá dos intervalos y los tratará como dos tramos.
    public class IntervaloSolidoPreview
    {
        public double InicioMm { get; set; }
        public double FinMm { get; set; }

        public double LongitudMm
        {
            get { return Math.Max(0.0, FinMm - InicioMm); }
        }

        public IntervaloSolidoPreview()
        {
            InicioMm = 0.0;
            FinMm = 0.0;
        }

        public IntervaloSolidoPreview(double inicioMm, double finMm)
        {
            InicioMm = Math.Min(inicioMm, finMm);
            FinMm = Math.Max(inicioMm, finMm);
        }

        public IntervaloSolidoPreview Clonar()
        {
            return new IntervaloSolidoPreview(InicioMm, FinMm);
        }
    }

    public List<Solido3DPreview> Solidos3D { get; set; }

    // Intervalos continuos de concreto, medidos desde el inicio del envolvente
    // físico de la viga. No incluyen columnas, vigas transversales ni apoyos.
    public List<IntervaloSolidoPreview> IntervalosSolidoMm { get; set; }

    // =========================================================
    // APOYOS PARA VISTA 2D
    // =========================================================
    // Se mantiene el nombre Columnas para no romper tu código existente.
    // Aquí ahora pueden entrar:
    // - Columnas reales.
    // - Vigas transversales.
    // - Otros apoyos equivalentes.
    public List<AceroLongitudinalVigasForm.ColumnaPreview> Columnas { get; set; }

    public string Nombre { get; set; }

    public VigaLongitudinalPreview(
        double longitudMm,
        List<AceroLongitudinalVigasForm.ColumnaPreview> columnas,
        string nombre)
    {
        LongitudMm = longitudMm;
        LongitudSolidoMm = 0.0;
        DeltaZMm = 0.0;
        ProyeccionHorizontalMm = longitudMm;
        AnguloGrados = 0.0;
        EsInclinada = false;

        EsCumbreraDetectada = false;
        LadosSeccionTransversalDetectados = 0;
        MotivoDeteccionForma = string.Empty;

        TienePerfilSeccionVariable = false;
        ZSuperiorInicioMm = 0.0;
        ZSuperiorFinMm = 0.0;
        ZInferiorInicioMm = 0.0;
        ZInferiorFinMm = 0.0;
        PerfilSuperiorMm = new List<PuntoPerfilMm>();
        PerfilInferiorMm = new List<PuntoPerfilMm>();

        Solidos3D = new List<Solido3DPreview>();
        IntervalosSolidoMm = new List<IntervaloSolidoPreview>();

        Columnas = columnas ?? new List<AceroLongitudinalVigasForm.ColumnaPreview>();
        Nombre = nombre;

        NormalizarApoyos();
    }

    // Devuelve los intervalos depurados, ordenados y fusionados.
    // Una separación mayor que la tolerancia se conserva como un vacío real.
    public List<IntervaloSolidoPreview> ObtenerIntervalosSolidoNormalizados(
        double toleranciaUnionMm = 1.0)
    {
        List<IntervaloSolidoPreview> resultado =
            new List<IntervaloSolidoPreview>();

        if (IntervalosSolidoMm == null || IntervalosSolidoMm.Count == 0)
            return resultado;

        double longitudReferencia = LongitudMm > 0.0
            ? LongitudMm
            : LongitudSolidoMm;

        toleranciaUnionMm = Math.Max(0.0, toleranciaUnionMm);

        List<IntervaloSolidoPreview> validos =
            new List<IntervaloSolidoPreview>();

        foreach (IntervaloSolidoPreview intervalo in IntervalosSolidoMm)
        {
            if (intervalo == null)
                continue;

            double inicio = Math.Min(intervalo.InicioMm, intervalo.FinMm);
            double fin = Math.Max(intervalo.InicioMm, intervalo.FinMm);

            if (double.IsNaN(inicio) || double.IsInfinity(inicio) ||
                double.IsNaN(fin) || double.IsInfinity(fin))
            {
                continue;
            }

            if (longitudReferencia > 0.0)
            {
                inicio = Math.Max(0.0, Math.Min(longitudReferencia, inicio));
                fin = Math.Max(0.0, Math.Min(longitudReferencia, fin));
            }

            if (fin <= inicio + 1.0)
                continue;

            validos.Add(new IntervaloSolidoPreview(inicio, fin));
        }

        foreach (IntervaloSolidoPreview intervalo in validos
            .OrderBy(x => x.InicioMm)
            .ThenBy(x => x.FinMm))
        {
            if (resultado.Count == 0)
            {
                resultado.Add(intervalo.Clonar());
                continue;
            }

            IntervaloSolidoPreview ultimo = resultado[resultado.Count - 1];

            if (intervalo.InicioMm <= ultimo.FinMm + toleranciaUnionMm)
            {
                ultimo.InicioMm = Math.Min(ultimo.InicioMm, intervalo.InicioMm);
                ultimo.FinMm = Math.Max(ultimo.FinMm, intervalo.FinMm);
            }
            else
            {
                resultado.Add(intervalo.Clonar());
            }
        }

        return resultado;
    }

    // =========================================================
    // AGREGAR APOYO GENÉRICO
    // =========================================================
    public void AgregarApoyo(
        double centroMm,
        double anchoMm,
        string nombre)
    {
        if (Columnas == null)
            Columnas = new List<AceroLongitudinalVigasForm.ColumnaPreview>();

        if (double.IsNaN(centroMm) || double.IsInfinity(centroMm))
            return;

        if (double.IsNaN(anchoMm) || double.IsInfinity(anchoMm))
            anchoMm = 300.0;

        anchoMm = Math.Max(50.0, anchoMm);

        string nombreFinal = string.IsNullOrWhiteSpace(nombre)
            ? "Apoyo"
            : nombre.Trim();

        foreach (AceroLongitudinalVigasForm.ColumnaPreview apoyo in Columnas)
        {
            if (apoyo == null)
                continue;

            if (Math.Abs(apoyo.CentroMm - centroMm) <= 50.0)
            {
                apoyo.AnchoMm = Math.Max(apoyo.AnchoMm, anchoMm);

                if (string.IsNullOrWhiteSpace(apoyo.Nombre))
                    apoyo.Nombre = nombreFinal;

                return;
            }
        }

        Columnas.Add(
            new AceroLongitudinalVigasForm.ColumnaPreview(
                centroMm,
                anchoMm,
                nombreFinal));

        NormalizarApoyos();
    }

    public void AgregarColumna(
        double centroMm,
        double anchoMm,
        string nombre)
    {
        AgregarApoyo(
            centroMm,
            anchoMm,
            string.IsNullOrWhiteSpace(nombre) ? "Columna" : nombre);
    }

    public void AgregarVigaTransversal(
        double centroMm,
        double anchoMm,
        string nombre)
    {
        AgregarApoyo(
            centroMm,
            anchoMm,
            string.IsNullOrWhiteSpace(nombre) ? "Viga transversal" : nombre);
    }

    public void LimpiarApoyos()
    {
        if (Columnas == null)
            Columnas = new List<AceroLongitudinalVigasForm.ColumnaPreview>();

        Columnas.Clear();
    }

    // =========================================================
    // ORDENAR Y DEPURAR APOYOS
    // =========================================================
    public void NormalizarApoyos()
    {
        if (Columnas == null)
        {
            Columnas = new List<AceroLongitudinalVigasForm.ColumnaPreview>();
            return;
        }

        List<AceroLongitudinalVigasForm.ColumnaPreview> apoyosLimpios =
            new List<AceroLongitudinalVigasForm.ColumnaPreview>();

        foreach (AceroLongitudinalVigasForm.ColumnaPreview apoyo in Columnas)
        {
            if (apoyo == null)
                continue;

            if (double.IsNaN(apoyo.CentroMm) || double.IsInfinity(apoyo.CentroMm))
                continue;

            if (double.IsNaN(apoyo.AnchoMm) || double.IsInfinity(apoyo.AnchoMm))
                apoyo.AnchoMm = 300.0;

            apoyo.AnchoMm = Math.Max(50.0, apoyo.AnchoMm);

            bool fusionado = false;

            foreach (AceroLongitudinalVigasForm.ColumnaPreview existente in apoyosLimpios)
            {
                if (existente == null)
                    continue;

                if (Math.Abs(existente.CentroMm - apoyo.CentroMm) <= 50.0)
                {
                    existente.AnchoMm = Math.Max(existente.AnchoMm, apoyo.AnchoMm);

                    if (string.IsNullOrWhiteSpace(existente.Nombre))
                        existente.Nombre = apoyo.Nombre;

                    fusionado = true;
                    break;
                }
            }

            if (!fusionado)
                apoyosLimpios.Add(apoyo);
        }

        Columnas = apoyosLimpios
            .OrderBy(c => c.CentroMm)
            .ToList();
    }
}


// =====================================
// MODO DE LA VISTA PRELIMINAR GLOBAL
// =====================================
public enum ModoVistaPrevia
{
    SeleccionVigas = 0,
    Estribos = 1,
    Longitudinal = 2
}

public delegate void TramoEstriboSeleccionadoHandler(object sender, int index);

// =====================================
// PANEL ÚNICO DE VISTA PRELIMINAR
// - Vive en el MAIN.
// - Usa la lógica de dibujo existente de AceroLongitudinalVigasForm.
// - Solo permite seleccionar tramos cuando Modo = Estribos.
// =====================================
public class VistaPreviaVigasPanel : WinForms.Panel
{
    public AceroLongitudinalVigasForm VentanaLongitudinal { get; private set; }
    public AceroEstribosVigasForm VentanaEstribos { get; private set; }

    private ModoVistaPrevia _modo = ModoVistaPrevia.SeleccionVigas;
    public ModoVistaPrevia Modo
    {
        get { return _modo; }
        set
        {
            _modo = value;
            this.Cursor = _modo == ModoVistaPrevia.Estribos
                ? WinForms.Cursors.Hand
                : WinForms.Cursors.Default;
            Invalidate();
        }
    }

    public int TramoEstribosResaltado { get; set; } = -1;

    public event TramoEstriboSeleccionadoHandler TramoEstriboSeleccionado;

    public VistaPreviaVigasPanel()
    {
        this.DoubleBuffered = true;
        this.ResizeRedraw = true;
        this.BackColor = Drawing.Color.White;
    }

    public void ConfigurarReferencias(
        AceroLongitudinalVigasForm ventanaLongitudinal,
        AceroEstribosVigasForm ventanaEstribos)
    {
        VentanaLongitudinal = ventanaLongitudinal;
        VentanaEstribos = ventanaEstribos;
        Invalidate();
    }

    protected override void OnMouseClick(WinForms.MouseEventArgs e)
    {
        base.OnMouseClick(e);

        if (Modo != ModoVistaPrevia.Estribos)
            return;

        int index = DetectarTramoPorClick(e.Location);

        if (index < 0)
            return;

        TramoEstribosResaltado = index;
        Invalidate();

        TramoEstriboSeleccionadoHandler handler = TramoEstriboSeleccionado;
        if (handler != null)
            handler(this, index);
    }

    protected override void OnPaint(WinForms.PaintEventArgs e)
    {
        base.OnPaint(e);

        if (e == null || e.Graphics == null)
            return;

        Drawing.Graphics g = e.Graphics;
        g.Clear(Drawing.Color.White);

        System.Drawing.Drawing2D.SmoothingMode oldSmoothing = g.SmoothingMode;
        System.Drawing.Text.TextRenderingHint oldText = g.TextRenderingHint;

        try
        {
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            Drawing.Rectangle area = new Drawing.Rectangle(
                0,
                0,
                Math.Max(1, ClientSize.Width - 1),
                Math.Max(1, ClientSize.Height - 1));

            if (VentanaLongitudinal == null || VentanaLongitudinal.IsDisposed)
            {
                DibujarMensajeSinVigas(g, area);
                return;
            }

            Dictionary<int, List<Tuple<double, int>>> estribosPorTramo = null;

            if (Modo == ModoVistaPrevia.Estribos &&
                VentanaEstribos != null &&
                !VentanaEstribos.IsDisposed)
            {
                try
                {
                    estribosPorTramo = VentanaEstribos.ObtenerPosicionesEstribosPreview();
                }
                catch
                {
                    estribosPorTramo = null;
                }
            }

            bool mostrarLongitudinal = Modo == ModoVistaPrevia.Longitudinal;
            bool longitudinalEnGris = Modo == ModoVistaPrevia.Estribos;
            int tramoResaltado = Modo == ModoVistaPrevia.Estribos
                ? TramoEstribosResaltado
                : -1;

            try
            {
                VentanaLongitudinal.DibujarVistaPreviaComun(
                    g,
                    area,
                    mostrarLongitudinal,
                    longitudinalEnGris,
                    estribosPorTramo,
                    tramoResaltado);
            }
            catch
            {
                DibujarMensajeSinVigas(g, area);
            }
        }
        finally
        {
            g.SmoothingMode = oldSmoothing;
            g.TextRenderingHint = oldText;
        }
    }

    private int DetectarTramoPorClick(Drawing.Point punto)
    {
        if (VentanaLongitudinal == null || VentanaLongitudinal.IsDisposed)
            return -1;

        Drawing.Rectangle area = new Drawing.Rectangle(
            0,
            0,
            Math.Max(1, ClientSize.Width - 1),
            Math.Max(1, ClientSize.Height - 1));

        List<Drawing.RectangleF> hitBoxes = null;

        try
        {
            hitBoxes = VentanaLongitudinal.ObtenerHitBoxesTramosVistaPreviaComun(area);
        }
        catch
        {
            hitBoxes = null;
        }

        if (hitBoxes == null || hitBoxes.Count == 0)
            return -1;

        // Primero intenta una selección directa dentro del rectángulo del tramo.
        for (int i = 0; i < hitBoxes.Count; i++)
        {
            Drawing.RectangleF r = hitBoxes[i];

            if (r.Contains(punto))
                return i;
        }

        // Respaldo: selección flexible por rango horizontal del tramo.
        // Esto permite hacer clic sobre el dibujo/cota del tramo sin tener que acertar
        // exactamente sobre la línea de la viga.
        for (int i = 0; i < hitBoxes.Count; i++)
        {
            Drawing.RectangleF r = hitBoxes[i];
            float margenX = 3.0f;

            if (punto.X >= r.Left - margenX &&
                punto.X <= r.Right + margenX &&
                punto.Y >= 0 &&
                punto.Y <= ClientSize.Height)
            {
                return i;
            }
        }

        return -1;
    }

    private void DibujarMensajeSinVigas(Drawing.Graphics g, Drawing.Rectangle area)
    {
        using (Drawing.Brush brTitulo = new Drawing.SolidBrush(Drawing.Color.FromArgb(70, 70, 70)))
        using (Drawing.Brush brSub = new Drawing.SolidBrush(Drawing.Color.Gray))
        using (Drawing.Font fTitulo = new Drawing.Font("Segoe UI", 10.0f, Drawing.FontStyle.Bold))
        using (Drawing.Font fSub = new Drawing.Font("Segoe UI", 8.5f, Drawing.FontStyle.Regular))
        {
            string titulo = "NO HAY VIGAS SELECCIONADAS";
            string sub = "Presione SELECCIONAR VIGAS / ARMAZONES para actualizar la vista preliminar.";

            Drawing.SizeF s1 = g.MeasureString(titulo, fTitulo);
            Drawing.SizeF s2 = g.MeasureString(sub, fSub);

            float cx = area.Left + area.Width / 2.0f;
            float cy = area.Top + area.Height / 2.0f;

            g.DrawString(titulo, fTitulo, brTitulo, cx - s1.Width / 2.0f, cy - 22.0f);
            g.DrawString(sub, fSub, brSub, cx - s2.Width / 2.0f, cy + 4.0f);
        }
    }
}
