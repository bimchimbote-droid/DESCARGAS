using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{



    // =====================================
    // COMANDO - ACERO EN VIGAS
    // =====================================
    [Transaction(TransactionMode.Manual)]
    public class MYG_AceroVigasCommand : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            UIDocument uidoc = commandData.Application.ActiveUIDocument;

            if (uidoc == null)
                return Result.Cancelled;

            Document doc = uidoc.Document;

            // =====================================
            // CARGAR TIPOS DE BARRA DE ARMADURA
            // =====================================
            List<RebarBarType> tiposBarra = new FilteredElementCollector(doc)
                .OfClass(typeof(RebarBarType))
                .Cast<RebarBarType>()
                .OrderBy(x => x.Name)
                .ToList();

            if (tiposBarra == null || tiposBarra.Count == 0)
            {
                TaskDialog.Show(
                    "MYG",
                    "No se encontraron tipos de barra de armadura en el proyecto.");

                return Result.Cancelled;
            }

            // =====================================
            // CREAR VENTANA INTERNA LONGITUDINAL
            // =====================================
            AceroLongitudinalVigasForm formLongitudinal =
                new AceroLongitudinalVigasForm();

            formLongitudinal.CargarTiposArmadura(tiposBarra);

            // =====================================
            // CREAR VENTANA MAIN CON BARRA LATERAL
            // =====================================
            AceroVigasMainForm formMain =
                new AceroVigasMainForm(formLongitudinal);

            formMain.CargarTiposArmadura(tiposBarra);

            // =====================================
            // HANDLER - SELECCIONAR VIGAS
            // =====================================
            SeleccionarVigasAceroLongitudinalHandler seleccionarHandler =
                new SeleccionarVigasAceroLongitudinalHandler();

            seleccionarHandler.UiDoc = uidoc;
            seleccionarHandler.Form = formLongitudinal;
            seleccionarHandler.MainForm = formMain;

            ExternalEvent seleccionarEvent =
                ExternalEvent.Create(seleccionarHandler);

            // =====================================
            // HANDLER - EJECUTAR ACERO LONGITUDINAL
            // =====================================
            EjecutarAceroLongitudinalVigasHandler ejecutarHandler =
                new EjecutarAceroLongitudinalVigasHandler();

            ejecutarHandler.UiDoc = uidoc;
            ejecutarHandler.Form = formLongitudinal;
            ejecutarHandler.SeleccionHandler = seleccionarHandler;

            ExternalEvent ejecutarEvent =
                ExternalEvent.Create(ejecutarHandler);

            // =====================================
            // HANDLER - EJECUTAR ESTRIBOS
            // =====================================
            EjecutarEstribosVigasHandler ejecutarEstribosHandler =
                new EjecutarEstribosVigasHandler();

            ejecutarEstribosHandler.UiDoc = uidoc;
            ejecutarEstribosHandler.Form = formMain.VentanaEstribos;
            ejecutarEstribosHandler.SeleccionHandler = seleccionarHandler;

            ExternalEvent ejecutarEstribosEvent =
                ExternalEvent.Create(ejecutarEstribosHandler);

            // =====================================
            // V11.51 - EJECUTAR TODO / EJECUCIÓN MASIVA
            // =====================================
            EjecutarAceroVigasMasivoHandler ejecutarTodoHandler =
                new EjecutarAceroVigasMasivoHandler();

            ejecutarTodoHandler.UiDoc = uidoc;
            ejecutarTodoHandler.MainForm = formMain;
            ejecutarTodoHandler.FormSeleccion = formMain.VentanaSeleccionVigas;
            ejecutarTodoHandler.FormLongitudinal = formLongitudinal;
            ejecutarTodoHandler.FormEstribos = formMain.VentanaEstribos;
            ejecutarTodoHandler.SeleccionHandler = seleccionarHandler;
            ejecutarTodoHandler.HandlerLongitudinal = ejecutarHandler;
            ejecutarTodoHandler.HandlerEstribos = ejecutarEstribosHandler;

            ExternalEvent ejecutarTodoEvent =
                ExternalEvent.Create(ejecutarTodoHandler);

            // =====================================
            // CONECTAR EVENTOS
            // =====================================
            formLongitudinal.SeleccionarEvent = seleccionarEvent;
            formLongitudinal.EjecutarEvent = ejecutarEvent;

            if (formMain.VentanaEstribos != null)
                formMain.VentanaEstribos.EjecutarEstribosEvent = ejecutarEstribosEvent;

            if (formMain.VentanaSeleccionVigas != null)
                formMain.VentanaSeleccionVigas.EjecutarTodoEvent = ejecutarTodoEvent;

            // =====================================
            // MOSTRAR VENTANA MAIN
            // =====================================
            formMain.Show();

            return Result.Succeeded;
        }
    }

}
