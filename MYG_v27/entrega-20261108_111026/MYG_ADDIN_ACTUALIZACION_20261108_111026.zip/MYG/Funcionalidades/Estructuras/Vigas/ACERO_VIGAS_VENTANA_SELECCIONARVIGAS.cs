﻿using Autodesk.Revit.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Drawing = System.Drawing;
using WinForms = System.Windows.Forms;

namespace MYG_Addin
{
    // =====================================
    // VENTANA - SELECCIONAR VIGAS / ARMAZONES
    // VISTA 2D + VISTA 3D SOLO EN ESTA PESTAÑA
    // La vista 3D dibuja sólidos reales si VigaLongitudinalPreview.Solidos3D está lleno.
    // Si aún no llenas Solidos3D desde el handler, usa una vista 3D sólida esquemática como respaldo.
    // =====================================
    public class SeleccionarVigasForm : WinForms.Form
    {
        private AceroLongitudinalVigasForm ventanaLongitudinal;

        private WinForms.Label lblTitulo;
        private WinForms.Label lblDescripcion;

        private WinForms.Button btnSeleccionarCompartido;
        private WinForms.Control ctrlVistaPreviaCompartida;
        private WinForms.Control ctrlCantidadCompartida;

        // V11.51 - EJECUCIÓN MASIVA / EJECUTAR TODO
        private WinForms.CheckBox chkEjecutarMasivamenteMYG;
        private WinForms.NumericUpDown numMargenContinuidadMasivaMYG;
        private WinForms.Label lblMargenContinuidadMasivaMYG;
        private WinForms.Label lblUnidadMargenMasivaMYG;
        private WinForms.Button btnEjecutarTodoMYG;

        public ExternalEvent EjecutarTodoEvent { get; set; }

        public bool EjecutarMasivamenteMYG
        {
            get { return chkEjecutarMasivamenteMYG != null && chkEjecutarMasivamenteMYG.Checked; }
        }

        public double MargenContinuidadMasivaM
        {
            get { return numMargenContinuidadMasivaMYG != null ? (double)numMargenContinuidadMasivaMYG.Value : 0.50; }
        }

        private WinForms.GroupBox grpPreview3D;
        private VistaPrevia3DPanel panelPreview3D;

        private WinForms.Control parentOriginalVistaPrevia;
        private Drawing.Rectangle boundsOriginalVistaPrevia;
        private WinForms.AnchorStyles anchorOriginalVistaPrevia;
        private WinForms.DockStyle dockOriginalVistaPrevia;

        private bool controlesCompartidosPreparados = false;

        public SeleccionarVigasForm(AceroLongitudinalVigasForm ventanaLongitudinalBase)
        {
            ventanaLongitudinal = ventanaLongitudinalBase;

            this.Text = "Seleccionar vigas / armazones";
            this.FormBorderStyle = WinForms.FormBorderStyle.None;
            this.TopLevel = false;
            this.ShowInTaskbar = false;
            this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new Drawing.Font("Segoe UI", 9F);
            this.Dock = WinForms.DockStyle.Fill;

            CrearControlesBase();
            CrearVistaPreliminar3D();
            PrepararControlesCompartidos();

            this.Resize += (s, e) =>
            {
                ActualizarLayout();
            };
        }

        private void CrearControlesBase()
        {
            lblTitulo = new WinForms.Label()
            {
                Text = "Selección de vigas / armazones",
                Left = 20,
                Top = 18,
                Width = 700,
                Height = 25,
                Font = new Drawing.Font("Segoe UI", 10F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(45, 45, 45)
            };

            lblDescripcion = new WinForms.Label()
            {
                Text = "Seleccione previamente las vigas o armazones. La vista 2D queda fija abajo y aquí se muestra la vista 3D.",
                Left = 20,
                Top = 45,
                Width = 700,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F),
                ForeColor = Drawing.Color.Gray
            };

            this.Controls.Add(lblTitulo);
            this.Controls.Add(lblDescripcion);

            chkEjecutarMasivamenteMYG = new WinForms.CheckBox()
            {
                Text = "EJECUTAR MASIVAMENTE",
                Left = 630,
                Top = 120,
                Width = 190,
                Height = 26,
                Checked = false,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold)
            };

            lblMargenContinuidadMasivaMYG = new WinForms.Label()
            {
                Text = "Margen máx.:",
                Left = 830,
                Top = 123,
                Width = 88,
                Height = 22,
                Enabled = false
            };

            numMargenContinuidadMasivaMYG = new WinForms.NumericUpDown()
            {
                Left = 918,
                Top = 119,
                Width = 66,
                Height = 24,
                DecimalPlaces = 2,
                Minimum = 0.00M,
                Maximum = 5.00M,
                Increment = 0.05M,
                Value = 0.50M,
                TextAlign = WinForms.HorizontalAlignment.Center,
                Enabled = false
            };

            lblUnidadMargenMasivaMYG = new WinForms.Label()
            {
                Text = "m",
                Left = 989,
                Top = 123,
                Width = 20,
                Height = 22,
                ForeColor = Drawing.Color.Gray,
                Enabled = false
            };

            btnEjecutarTodoMYG = new WinForms.Button()
            {
                Text = "EJECUTAR TODO",
                Left = 1020,
                Top = 116,
                Width = 275,
                Height = 36,
                FlatStyle = WinForms.FlatStyle.Flat,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                Font = new Drawing.Font("Segoe UI", 8.2F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };
            btnEjecutarTodoMYG.FlatAppearance.BorderColor = Drawing.Color.FromArgb(0, 95, 175);

            chkEjecutarMasivamenteMYG.CheckedChanged += (s, e) =>
            {
                bool activo = chkEjecutarMasivamenteMYG.Checked;
                numMargenContinuidadMasivaMYG.Enabled = activo;
                lblMargenContinuidadMasivaMYG.Enabled = activo;
                lblUnidadMargenMasivaMYG.Enabled = activo;
            };

            btnEjecutarTodoMYG.Click += (s, e) =>
            {
                if (EjecutarTodoEvent != null)
                    EjecutarTodoEvent.Raise();
                else
                    WinForms.MessageBox.Show("Falta conectar el evento EJECUTAR TODO.",
                        "MYG - Acero en Vigas", WinForms.MessageBoxButtons.OK,
                        WinForms.MessageBoxIcon.Information);
            };

            this.Controls.Add(chkEjecutarMasivamenteMYG);
            this.Controls.Add(lblMargenContinuidadMasivaMYG);
            this.Controls.Add(numMargenContinuidadMasivaMYG);
            this.Controls.Add(lblUnidadMargenMasivaMYG);
            this.Controls.Add(btnEjecutarTodoMYG);
        }

        private void CrearVistaPreliminar3D()
        {
            grpPreview3D = new WinForms.GroupBox()
            {
                Text = "Vista preliminar 3D",
                Left = 20,
                Top = 220,
                Width = 700,
                Height = 210,
                Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50),
                BackColor = Drawing.Color.FromArgb(245, 247, 250),
                Anchor =
                    WinForms.AnchorStyles.Top |
                    WinForms.AnchorStyles.Bottom |
                    WinForms.AnchorStyles.Left |
                    WinForms.AnchorStyles.Right
            };

            panelPreview3D = new VistaPrevia3DPanel()
            {
                Left = 12,
                Top = 25,
                Width = grpPreview3D.Width - 24,
                Height = grpPreview3D.Height - 37,
                BackColor = Drawing.Color.White,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                Anchor =
                    WinForms.AnchorStyles.Top |
                    WinForms.AnchorStyles.Bottom |
                    WinForms.AnchorStyles.Left |
                    WinForms.AnchorStyles.Right
            };

            panelPreview3D.ObtenerVigas = ObtenerVigasPreviewActuales;

            grpPreview3D.Controls.Add(panelPreview3D);
            this.Controls.Add(grpPreview3D);
        }

        public void ActivarSeleccion()
        {
            PrepararControlesCompartidos();

            if (ventanaLongitudinal != null && !ventanaLongitudinal.IsDisposed)
                ventanaLongitudinal.EstablecerVistaSoloGeometria(true);

            AgregarControlesSeleccion();
            ActualizarLayout();

            // La vista preliminar 2D se mantiene fija en el Main.
            // Aquí solo se refresca la vista 3D.

            RefrescarVista3D();
        }

        public void RefrescarVista3D()
        {
            try
            {
                if (panelPreview3D != null)
                {
                    panelPreview3D.Invalidate();
                    panelPreview3D.Update();
                }
            }
            catch
            {
                // No se interrumpe la selección si el panel aún no está listo.
            }
        }

        public void RestaurarVistaPreviaEnLongitudinal()
        {
            PrepararControlesCompartidos();

            if (btnSeleccionarCompartido != null)
            {
                SepararControl(btnSeleccionarCompartido);
                btnSeleccionarCompartido.Visible = false;
            }

            if (ctrlCantidadCompartida != null)
            {
                SepararControl(ctrlCantidadCompartida);
                ctrlCantidadCompartida.Visible = false;
            }

            // La vista preliminar 2D ya no se restaura aquí.
            // AceroVigasMainForm la conserva fija en la zona inferior.
            if (ventanaLongitudinal != null && !ventanaLongitudinal.IsDisposed)
                ventanaLongitudinal.EstablecerVistaSoloGeometria(false);
        }

        private void PrepararControlesCompartidos()
        {
            if (controlesCompartidosPreparados)
                return;

            if (ventanaLongitudinal == null || ventanaLongitudinal.IsDisposed)
                return;

            btnSeleccionarCompartido = ventanaLongitudinal.btnSeleccionarVigas;

            ctrlVistaPreviaCompartida =
                BuscarControlPorTexto<WinForms.GroupBox>(
                    ventanaLongitudinal,
                    "Vista preliminar");

            ctrlCantidadCompartida =
                BuscarLabelQueEmpiezaCon(
                    ventanaLongitudinal,
                    "Vigas seleccionadas");

            if (ctrlVistaPreviaCompartida != null)
            {
                parentOriginalVistaPrevia = ctrlVistaPreviaCompartida.Parent;
                boundsOriginalVistaPrevia = ctrlVistaPreviaCompartida.Bounds;
                anchorOriginalVistaPrevia = ctrlVistaPreviaCompartida.Anchor;
                dockOriginalVistaPrevia = ctrlVistaPreviaCompartida.Dock;
            }

            controlesCompartidosPreparados = true;
        }

        private void AgregarControlesSeleccion()
        {
            if (btnSeleccionarCompartido != null)
            {
                SepararControl(btnSeleccionarCompartido);

                btnSeleccionarCompartido.Visible = true;
                btnSeleccionarCompartido.Enabled = true;
                btnSeleccionarCompartido.Text = "SELECCIONAR VIGAS / ARMAZONES";
                btnSeleccionarCompartido.Left = 20;
                btnSeleccionarCompartido.Top = 116;
                btnSeleccionarCompartido.Width = 310;
                btnSeleccionarCompartido.Height = 36;
                btnSeleccionarCompartido.Anchor =
                    WinForms.AnchorStyles.Top |
                    WinForms.AnchorStyles.Left;

                this.Controls.Add(btnSeleccionarCompartido);
                btnSeleccionarCompartido.BringToFront();
            }

            if (ctrlCantidadCompartida != null)
            {
                SepararControl(ctrlCantidadCompartida);

                ctrlCantidadCompartida.Visible = true;
                ctrlCantidadCompartida.Left = 350;
                ctrlCantidadCompartida.Top = 124;
                ctrlCantidadCompartida.Width = 260;
                ctrlCantidadCompartida.Height = 22;
                ctrlCantidadCompartida.Anchor =
                    WinForms.AnchorStyles.Top |
                    WinForms.AnchorStyles.Left;

                this.Controls.Add(ctrlCantidadCompartida);
                ctrlCantidadCompartida.BringToFront();
            }

            // IMPORTANTE:
            // Ya no se mueve ctrlVistaPreviaCompartida a esta pestaña.
            // Esa vista vive siempre en la región fija inferior del formulario Main.

            if (grpPreview3D != null)
            {
                if (grpPreview3D.Parent == null)
                    this.Controls.Add(grpPreview3D);

                grpPreview3D.Visible = true;
                grpPreview3D.BringToFront();
            }
        }

        private void ActualizarLayout()
        {
            if (lblTitulo != null)
                lblTitulo.Width = Math.Max(300, this.ClientSize.Width - 40);

            if (lblDescripcion != null)
                lblDescripcion.Width = Math.Max(300, this.ClientSize.Width - 40);

            int xMasivo = Math.Max(620, this.ClientSize.Width - 685);
            if (chkEjecutarMasivamenteMYG != null) chkEjecutarMasivamenteMYG.Left = xMasivo;
            if (lblMargenContinuidadMasivaMYG != null) lblMargenContinuidadMasivaMYG.Left = xMasivo + 195;
            if (numMargenContinuidadMasivaMYG != null) numMargenContinuidadMasivaMYG.Left = xMasivo + 283;
            if (lblUnidadMargenMasivaMYG != null) lblUnidadMargenMasivaMYG.Left = xMasivo + 354;
            if (btnEjecutarTodoMYG != null) btnEjecutarTodoMYG.Left = xMasivo + 382;

            // La vista preliminar 2D ya no se posiciona aquí.
            // Se mantiene fija en AceroVigasMainForm.

            if (grpPreview3D != null)
            {
                grpPreview3D.Left = 20;
                // Se baja un poco la vista 3D y se hace más alta,
                // dejando libre la zona superior del selector global.
                grpPreview3D.Top = 225;
                grpPreview3D.Width = Math.Max(500, this.ClientSize.Width - 40);

                // Vista 3D más grande, como el rectángulo marcado,
                // pero sin invadir la vista 2D fija inferior.
                int altoDisponible3D = this.ClientSize.Height - grpPreview3D.Top - 20;
                grpPreview3D.Height = Math.Max(170, Math.Min(215, altoDisponible3D));
            }

            if (panelPreview3D != null && grpPreview3D != null)
            {
                panelPreview3D.Left = 12;
                panelPreview3D.Top = 25;
                panelPreview3D.Width = Math.Max(100, grpPreview3D.ClientSize.Width - 24);
                panelPreview3D.Height = Math.Max(100, grpPreview3D.ClientSize.Height - 37);
            }
        }

        private List<VigaLongitudinalPreview> ObtenerVigasPreviewActuales()
        {
            List<VigaLongitudinalPreview> vacio =
                new List<VigaLongitudinalPreview>();

            if (ventanaLongitudinal == null || ventanaLongitudinal.IsDisposed)
                return vacio;

            try
            {
                FieldInfo campo = typeof(AceroLongitudinalVigasForm).GetField(
                    "previewVigas",
                    BindingFlags.Instance |
                    BindingFlags.NonPublic);

                if (campo == null)
                    return vacio;

                object valor = campo.GetValue(ventanaLongitudinal);

                List<VigaLongitudinalPreview> lista =
                    valor as List<VigaLongitudinalPreview>;

                if (lista == null)
                    return vacio;

                return lista;
            }
            catch
            {
                return vacio;
            }
        }

        private void SepararControl(WinForms.Control ctrl)
        {
            if (ctrl == null)
                return;

            if (ctrl.Parent != null)
                ctrl.Parent.Controls.Remove(ctrl);
        }

        private T BuscarControlPorTexto<T>(
            WinForms.Control raiz,
            string texto) where T : WinForms.Control
        {
            if (raiz == null)
                return default(T);

            foreach (WinForms.Control ctrl in raiz.Controls)
            {
                T encontrado = ctrl as T;

                if (encontrado != null &&
                    string.Equals(
                        (ctrl.Text ?? "").Trim(),
                        texto,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return encontrado;
                }

                T encontradoHijo = BuscarControlPorTexto<T>(ctrl, texto);

                if (encontradoHijo != null)
                    return encontradoHijo;
            }

            return default(T);
        }

        private WinForms.Label BuscarLabelQueEmpiezaCon(
            WinForms.Control raiz,
            string textoInicial)
        {
            if (raiz == null)
                return null;

            foreach (WinForms.Control ctrl in raiz.Controls)
            {
                WinForms.Label lbl = ctrl as WinForms.Label;

                if (lbl != null &&
                    !string.IsNullOrWhiteSpace(lbl.Text) &&
                    lbl.Text.Trim().StartsWith(
                        textoInicial,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return lbl;
                }

                WinForms.Label encontradoHijo =
                    BuscarLabelQueEmpiezaCon(ctrl, textoInicial);

                if (encontradoHijo != null)
                    return encontradoHijo;
            }

            return null;
        }

        // =========================================================
        // PANEL 3D ORBITABLE SOLO PARA SELECCIONAR VIGAS
        // =========================================================
        private class VistaPrevia3DPanel : WinForms.Panel
        {
            public Func<List<VigaLongitudinalPreview>> ObtenerVigas;

            private float rotX = -25.0f;
            private float rotZ = -35.0f;
            private float zoom = 1.0f;
            private float panX = 0.0f;
            private float panY = 0.0f;

            private bool arrastrando = false;
            private WinForms.MouseButtons botonArrastre = WinForms.MouseButtons.None;
            private Drawing.Point ultimoPunto = Drawing.Point.Empty;

            private const float ZOOM_MIN = 0.35f;
            private const float ZOOM_MAX = 8.0f;

            // El orbitado se centra en la viga/elemento enfocado, parecido al
            // comportamiento de Revit cuando orbita alrededor de una selección.
            private int indiceVigaEnfoque = 0;
            private P3 centroOrbitaActual = new P3(0.0, 0.0, 0.0);
            private List<CaraPantalla> ultimasCarasPantalla = new List<CaraPantalla>();
            private Drawing.Point puntoMouseDown = Drawing.Point.Empty;
            private bool huboMovimientoArrastre = false;

            public VistaPrevia3DPanel()
            {
                this.DoubleBuffered = true;
                this.TabStop = true;
                this.Cursor = WinForms.Cursors.Hand;

                this.SetStyle(
                    WinForms.ControlStyles.AllPaintingInWmPaint |
                    WinForms.ControlStyles.OptimizedDoubleBuffer |
                    WinForms.ControlStyles.ResizeRedraw |
                    WinForms.ControlStyles.UserPaint,
                    true);

                this.MouseEnter += (s, e) =>
                {
                    try { this.Focus(); } catch { }
                };

                this.MouseDown += VistaPrevia3DPanel_MouseDown;
                this.MouseMove += VistaPrevia3DPanel_MouseMove;
                this.MouseUp += VistaPrevia3DPanel_MouseUp;
                this.MouseLeave += VistaPrevia3DPanel_MouseLeave;
                this.MouseWheel += VistaPrevia3DPanel_MouseWheel;

                this.MouseDoubleClick += (s, e) =>
                {
                    ResetearVista();
                };
            }

            private void VistaPrevia3DPanel_MouseDown(object sender, WinForms.MouseEventArgs e)
            {
                arrastrando = true;
                botonArrastre = e.Button;
                ultimoPunto = e.Location;
                puntoMouseDown = e.Location;
                huboMovimientoArrastre = false;

                if (e.Button == WinForms.MouseButtons.Left)
                    this.Cursor = WinForms.Cursors.SizeAll;
                else
                    this.Cursor = WinForms.Cursors.Hand;

                try { this.Focus(); } catch { }
            }

            private void VistaPrevia3DPanel_MouseMove(object sender, WinForms.MouseEventArgs e)
            {
                if (!arrastrando)
                    return;

                int dx = e.X - ultimoPunto.X;
                int dy = e.Y - ultimoPunto.Y;

                if (Math.Abs(e.X - puntoMouseDown.X) > 4 ||
                    Math.Abs(e.Y - puntoMouseDown.Y) > 4)
                {
                    huboMovimientoArrastre = true;
                }

                if (botonArrastre == WinForms.MouseButtons.Left)
                {
                    rotZ += dx * 0.45f;
                    rotX += dy * 0.45f;

                    if (rotX < -89.0f) rotX = -89.0f;
                    if (rotX > 89.0f) rotX = 89.0f;
                }
                else if (botonArrastre == WinForms.MouseButtons.Middle ||
                         botonArrastre == WinForms.MouseButtons.Right)
                {
                    panX += dx;
                    panY += dy;
                }

                ultimoPunto = e.Location;
                this.Invalidate();
            }

            private void VistaPrevia3DPanel_MouseUp(object sender, WinForms.MouseEventArgs e)
            {
                bool fueClickSeleccion =
                    botonArrastre == WinForms.MouseButtons.Left &&
                    !huboMovimientoArrastre;

                arrastrando = false;
                botonArrastre = WinForms.MouseButtons.None;
                this.Cursor = WinForms.Cursors.Hand;

                if (fueClickSeleccion)
                {
                    SeleccionarElementoBajoCursor(e.Location);
                }
            }

            private void VistaPrevia3DPanel_MouseLeave(object sender, EventArgs e)
            {
                arrastrando = false;
                botonArrastre = WinForms.MouseButtons.None;
                this.Cursor = WinForms.Cursors.Hand;
            }

            private void VistaPrevia3DPanel_MouseWheel(object sender, WinForms.MouseEventArgs e)
            {
                float factor = e.Delta > 0 ? 1.15f : 1.0f / 1.15f;
                zoom *= factor;

                if (zoom < ZOOM_MIN) zoom = ZOOM_MIN;
                if (zoom > ZOOM_MAX) zoom = ZOOM_MAX;

                this.Invalidate();
            }

            private void ResetearVista()
            {
                rotX = -25.0f;
                rotZ = -35.0f;
                zoom = 1.0f;
                panX = 0.0f;
                panY = 0.0f;
                indiceVigaEnfoque = 0;
                arrastrando = false;
                botonArrastre = WinForms.MouseButtons.None;
                ultimoPunto = Drawing.Point.Empty;
                this.Invalidate();
            }

            protected override void OnPaint(WinForms.PaintEventArgs e)
            {
                base.OnPaint(e);

                Drawing.Graphics g = e.Graphics;
                g.Clear(Drawing.Color.FromArgb(252, 252, 252));
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;

                List<VigaLongitudinalPreview> vigas = ObtenerListaVigasSegura();

                if (vigas == null || vigas.Count == 0)
                {
                    DibujarTextoCentro(g, "NO HAY VIGAS SELECCIONADAS\nSeleccione vigas para visualizar el modelo 3D.", Drawing.Color.Gray);
                    return;
                }

                List<CaraRender> caras = ConstruirCarasReales(vigas);

                if (caras.Count == 0)
                    caras = ConstruirCarasFallback(vigas);

                if (caras.Count == 0)
                {
                    DibujarTextoCentro(g, "No hay geometría válida para la vista 3D.", Drawing.Color.Gray);
                    return;
                }

                Caja3D caja = CalcularCaja(caras);

                if (!caja.Valida)
                {
                    DibujarTextoCentro(g, "No hay geometría válida para la vista 3D.", Drawing.Color.Gray);
                    return;
                }

                indiceVigaEnfoque = CorregirIndiceVigaEnfoque(caras, indiceVigaEnfoque);

                Caja3D cajaFoco = CalcularCaja(
                    caras.Where(c => c != null && c.EsVigaSeleccionada && c.IndiceViga == indiceVigaEnfoque).ToList());

                if (!cajaFoco.Valida)
                {
                    cajaFoco = CalcularCaja(caras.Where(c => c != null && c.EsVigaSeleccionada).ToList());
                }

                centroOrbitaActual = cajaFoco.Valida
                    ? ObtenerCentroCaja(cajaFoco)
                    : ObtenerCentroCaja(caja);

                double escala = CalcularEscala(caja);

                List<CaraPantalla> pantalla = new List<CaraPantalla>();

                foreach (CaraRender cara in caras)
                {
                    CaraPantalla cp = ProyectarCara(cara, caja, escala);

                    if (cp != null && cp.Puntos.Length >= 3)
                        pantalla.Add(cp);
                }

                pantalla = pantalla
                    .OrderBy(x => x.Depth)
                    .ToList();

                ultimasCarasPantalla = pantalla;

                // MODO REVIT / LÍNEA OCULTA SOMBREADA:
                // Primero se dibuja una sombra suave de ambiente; luego se rellenan
                // caras de atrás hacia adelante y por último se dibujan solo aristas
                // reales visibles, evitando las diagonales internas de triangulación.
                Dictionary<string, AristaRender> aristasVisibles = ConstruirDiccionarioAristasVisibles(caras);

                DibujarSombrasAmbientales(g, pantalla);

                foreach (CaraPantalla cp in pantalla)
                {
                    DibujarCaraPantalla(g, cp);
                    DibujarAristasDeCaraPantalla(g, cp, aristasVisibles);
                }

                DibujarMarcaFoco(g, pantalla);
                DibujarAyuda(g, caras.Any(c => c.EsReal));
            }

            private List<VigaLongitudinalPreview> ObtenerListaVigasSegura()
            {
                try
                {
                    return ObtenerVigas != null
                        ? ObtenerVigas()
                        : new List<VigaLongitudinalPreview>();
                }
                catch
                {
                    return new List<VigaLongitudinalPreview>();
                }
            }

            private void DibujarTextoCentro(Drawing.Graphics g, string texto, Drawing.Color color)
            {
                using (Drawing.Font font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold))
                using (Drawing.Brush brush = new Drawing.SolidBrush(color))
                {
                    Drawing.SizeF size = g.MeasureString(texto, font);
                    g.DrawString(
                        texto,
                        font,
                        brush,
                        (this.ClientSize.Width - size.Width) / 2.0f,
                        (this.ClientSize.Height - size.Height) / 2.0f);
                }
            }

            // =========================================================
            // LECTURA DE SÓLIDOS REALES POR REFLEXIÓN
            // =========================================================
            private List<CaraRender> ConstruirCarasReales(List<VigaLongitudinalPreview> vigas)
            {
                List<CaraRender> caras = new List<CaraRender>();

                for (int indiceViga = 0; indiceViga < vigas.Count; indiceViga++)
                {
                    VigaLongitudinalPreview v = vigas[indiceViga];

                    if (v == null)
                        continue;

                    object listaSolidos = ObtenerPropiedad(v, "Solidos3D");

                    IEnumerable enumerableSolidos = listaSolidos as IEnumerable;

                    if (enumerableSolidos == null)
                        continue;

                    int indiceSolido = 0;

                    foreach (object solido in enumerableSolidos)
                    {
                        if (solido == null)
                        {
                            indiceSolido++;
                            continue;
                        }

                        // Por convención del handler:
                        // - el primer sólido de cada VigaLongitudinalPreview es la viga seleccionada.
                        // - los sólidos siguientes son columnas/vigas transversales de apoyo.
                        bool esVigaSeleccionada = indiceSolido == 0;

                        object puntosObj = ObtenerPropiedad(solido, "Puntos");
                        object carasObj = ObtenerPropiedad(solido, "Caras");

                        IList puntosList = puntosObj as IList;
                        IEnumerable carasEnum = carasObj as IEnumerable;

                        if (puntosList == null || carasEnum == null)
                            continue;

                        List<P3> puntos = new List<P3>();

                        foreach (object p in puntosList)
                        {
                            if (p == null)
                                continue;

                            double x = ObtenerDouble(p, "XMm");
                            double y = ObtenerDouble(p, "YMm");
                            double z = ObtenerDouble(p, "ZMm");

                            puntos.Add(new P3(x, y, z));
                        }

                        foreach (object caraObj in carasEnum)
                        {
                            if (caraObj == null)
                                continue;

                            object indicesObj = ObtenerPropiedad(caraObj, "IndicesPuntos");
                            IEnumerable indicesEnum = indicesObj as IEnumerable;

                            if (indicesEnum == null)
                                continue;

                            List<P3> ptsCara = new List<P3>();

                            foreach (object idxObj in indicesEnum)
                            {
                                int idx = -1;

                                try { idx = Convert.ToInt32(idxObj); }
                                catch { idx = -1; }

                                if (idx >= 0 && idx < puntos.Count)
                                    ptsCara.Add(puntos[idx]);
                            }

                            if (ptsCara.Count >= 3)
                            {
                                CaraRender cara = new CaraRender();
                                cara.Puntos = ptsCara;
                                cara.EsReal = true;
                                cara.EsVigaSeleccionada = esVigaSeleccionada;
                                cara.IndiceViga = indiceViga;
                                cara.Normal = CalcularNormal3D(ptsCara);
                                caras.Add(cara);
                            }
                        }

                        indiceSolido++;
                    }
                }

                return caras;
            }

            private object ObtenerPropiedad(object obj, string nombre)
            {
                if (obj == null || string.IsNullOrWhiteSpace(nombre))
                    return null;

                try
                {
                    PropertyInfo p = obj.GetType().GetProperty(
                        nombre,
                        BindingFlags.Instance |
                        BindingFlags.Public |
                        BindingFlags.NonPublic);

                    if (p == null)
                        return null;

                    return p.GetValue(obj, null);
                }
                catch
                {
                    return null;
                }
            }

            private double ObtenerDouble(object obj, string nombre)
            {
                object val = ObtenerPropiedad(obj, nombre);

                if (val == null)
                    return 0.0;

                try
                {
                    return Convert.ToDouble(
                        val,
                        System.Globalization.CultureInfo.InvariantCulture);
                }
                catch
                {
                    double d = 0.0;

                    double.TryParse(
                        val.ToString().Replace(",", "."),
                        System.Globalization.NumberStyles.Any,
                        System.Globalization.CultureInfo.InvariantCulture,
                        out d);

                    return d;
                }
            }

            // =========================================================
            // RESPALDO: SÓLIDOS ESQUEMÁTICOS SI AÚN NO LLEGAN SOLIDOS3D
            // =========================================================
            private List<CaraRender> ConstruirCarasFallback(List<VigaLongitudinalPreview> vigas)
            {
                List<CaraRender> caras = new List<CaraRender>();

                double cursorX = 0.0;

                for (int indiceViga = 0; indiceViga < vigas.Count; indiceViga++)
                {
                    VigaLongitudinalPreview v = vigas[indiceViga];

                    if (v == null)
                        continue;

                    double longitud = v.LongitudSolidoMm > 0.0
                        ? v.LongitudSolidoMm
                        : v.LongitudMm;

                    if (longitud <= 0.0)
                        longitud = 1000.0;

                    double zFin = v.EsInclinada ? v.DeltaZMm : 0.0;

                    if (v.TienePerfilSeccionVariable)
                        zFin = v.ZSuperiorFinMm - v.ZSuperiorInicioMm;

                    AgregarCaja(
                        caras,
                        cursorX,
                        -180.0,
                        -320.0,
                        cursorX + longitud,
                        180.0,
                        0.0,
                        zFin,
                        false,
                        true,
                        indiceViga);

                    if (v.Columnas != null)
                    {
                        foreach (AceroLongitudinalVigasForm.ColumnaPreview col in v.Columnas)
                        {
                            if (col == null)
                                continue;

                            double ancho = col.AnchoMm > 0.0 ? col.AnchoMm : 300.0;
                            double xc = cursorX + col.CentroMm;

                            AgregarCaja(
                                caras,
                                xc - ancho / 2.0,
                                -230.0,
                                -800.0,
                                xc + ancho / 2.0,
                                230.0,
                                180.0,
                                0.0,
                                false,
                                false,
                                indiceViga);
                        }
                    }

                    cursorX += longitud;
                }

                return caras;
            }

            private void AgregarCaja(
                List<CaraRender> caras,
                double x0,
                double y0,
                double z0,
                double x1,
                double y1,
                double z1,
                double zFinExtra,
                bool esReal,
                bool esVigaSeleccionada,
                int indiceViga)
            {
                P3 p000 = new P3(x0, y0, z0);
                P3 p100 = new P3(x1, y0, z0 + zFinExtra);
                P3 p110 = new P3(x1, y1, z0 + zFinExtra);
                P3 p010 = new P3(x0, y1, z0);

                P3 p001 = new P3(x0, y0, z1);
                P3 p101 = new P3(x1, y0, z1 + zFinExtra);
                P3 p111 = new P3(x1, y1, z1 + zFinExtra);
                P3 p011 = new P3(x0, y1, z1);

                AgregarCara(caras, esReal, esVigaSeleccionada, indiceViga, p000, p100, p110, p010); // abajo/frente
                AgregarCara(caras, esReal, esVigaSeleccionada, indiceViga, p001, p101, p111, p011); // arriba
                AgregarCara(caras, esReal, esVigaSeleccionada, indiceViga, p000, p100, p101, p001);
                AgregarCara(caras, esReal, esVigaSeleccionada, indiceViga, p100, p110, p111, p101);
                AgregarCara(caras, esReal, esVigaSeleccionada, indiceViga, p110, p010, p011, p111);
                AgregarCara(caras, esReal, esVigaSeleccionada, indiceViga, p010, p000, p001, p011);
            }

            private void AgregarCara(
                List<CaraRender> caras,
                bool esReal,
                bool esVigaSeleccionada,
                int indiceViga,
                params P3[] puntos)
            {
                if (puntos == null || puntos.Length < 3)
                    return;

                CaraRender cara = new CaraRender();
                cara.Puntos = puntos.ToList();
                cara.EsReal = esReal;
                cara.EsVigaSeleccionada = esVigaSeleccionada;
                cara.IndiceViga = indiceViga;
                cara.Normal = CalcularNormal3D(cara.Puntos);
                caras.Add(cara);
            }

            private Caja3D CalcularCaja(List<CaraRender> caras)
            {
                Caja3D caja = new Caja3D();
                caja.MinX = double.MaxValue;
                caja.MinY = double.MaxValue;
                caja.MinZ = double.MaxValue;
                caja.MaxX = double.MinValue;
                caja.MaxY = double.MinValue;
                caja.MaxZ = double.MinValue;

                foreach (CaraRender cara in caras)
                {
                    if (cara == null || cara.Puntos == null)
                        continue;

                    foreach (P3 p in cara.Puntos)
                    {
                        caja.MinX = Math.Min(caja.MinX, p.X);
                        caja.MinY = Math.Min(caja.MinY, p.Y);
                        caja.MinZ = Math.Min(caja.MinZ, p.Z);
                        caja.MaxX = Math.Max(caja.MaxX, p.X);
                        caja.MaxY = Math.Max(caja.MaxY, p.Y);
                        caja.MaxZ = Math.Max(caja.MaxZ, p.Z);
                        caja.Valida = true;
                    }
                }

                return caja;
            }

            private double CalcularEscala(Caja3D caja)
            {
                double dx = Math.Max(1.0, caja.MaxX - caja.MinX);
                double dy = Math.Max(1.0, caja.MaxY - caja.MinY);
                double dz = Math.Max(1.0, caja.MaxZ - caja.MinZ);

                // Para elementos largos y delgados, si se usa solo la dimensión mayor,
                // la vista queda demasiado pequeña. Se usa una escala ponderada para
                // aprovechar mejor el ancho del panel, similar al encuadre de Revit.
                double mayorPlanta = Math.Max(dx, dy);
                double mayorVisual = Math.Max(mayorPlanta, dz * 2.20);

                double ancho = Math.Max(100.0, this.ClientSize.Width - 70.0);
                double alto = Math.Max(100.0, this.ClientSize.Height - 55.0);

                return Math.Min(ancho / Math.Max(1.0, mayorPlanta), alto / Math.Max(1.0, mayorVisual)) * 0.92;
            }

            private CaraPantalla ProyectarCara(CaraRender cara, Caja3D caja, double escala)
            {
                if (cara == null || cara.Puntos == null || cara.Puntos.Count < 3)
                    return null;

                List<Drawing.PointF> pts = new List<Drawing.PointF>();
                double depth = 0.0;

                foreach (P3 p in cara.Puntos)
                {
                    P2 pr = Proyectar(p, caja, escala);
                    pts.Add(pr.Punto);
                    depth += pr.Depth;
                }

                depth /= cara.Puntos.Count;

                CaraPantalla cp = new CaraPantalla();
                cp.Puntos = pts.ToArray();
                cp.Depth = depth;
                cp.EsReal = cara.EsReal;
                cp.EsVigaSeleccionada = cara.EsVigaSeleccionada;
                cp.IndiceViga = cara.IndiceViga;
                cp.NormalZ = CalcularNormalZ(cara.Puntos);
                cp.ClavesAristas = ObtenerClavesAristasCara(cara);
                return cp;
            }

            private double CalcularNormalZ(List<P3> puntos)
            {
                if (puntos == null || puntos.Count < 3)
                    return 0.0;

                P3 a = puntos[0];
                P3 b = puntos[1];
                P3 c = puntos[2];

                double ux = b.X - a.X;
                double uy = b.Y - a.Y;
                double uz = b.Z - a.Z;

                double vx = c.X - a.X;
                double vy = c.Y - a.Y;
                double vz = c.Z - a.Z;

                double nx = uy * vz - uz * vy;
                double ny = uz * vx - ux * vz;
                double nz = ux * vy - uy * vx;

                double len = Math.Sqrt(nx * nx + ny * ny + nz * nz);

                if (len <= 1e-9)
                    return 0.0;

                return nz / len;
            }

            private P2 Proyectar(P3 p, Caja3D caja, double escala)
            {
                double cx = centroOrbitaActual.X;
                double cy = centroOrbitaActual.Y;
                double cz = centroOrbitaActual.Z;

                double x = p.X - cx;
                double y = p.Y - cy;
                double z = p.Z - cz;

                double rz = rotZ * Math.PI / 180.0;
                double rx = rotX * Math.PI / 180.0;

                double cosZ = Math.Cos(rz);
                double sinZ = Math.Sin(rz);

                double x1 = x * cosZ - y * sinZ;
                double y1 = x * sinZ + y * cosZ;
                double z1 = z;

                double cosX = Math.Cos(rx);
                double sinX = Math.Sin(rx);

                double y2 = y1 * cosX - z1 * sinX;
                double z2 = y1 * sinX + z1 * cosX;

                float sx = (float)(this.ClientSize.Width / 2.0 + panX + x1 * escala * zoom);
                float sy = (float)(this.ClientSize.Height / 2.0 + panY + y2 * escala * zoom);

                return new P2(new Drawing.PointF(sx, sy), z2);
            }

            private void DibujarCaraPantalla(Drawing.Graphics g, CaraPantalla cp)
            {
                if (cp == null || cp.Puntos == null || cp.Puntos.Length < 3)
                    return;

                int sombra = (int)Math.Max(-42.0, Math.Min(42.0, cp.NormalZ * 42.0));

                Drawing.Color fill;

                if (cp.EsVigaSeleccionada)
                {
                    // Verde similar a un resaltado suave, pero con sombreado por cara.
                    int r = Math.Max(55, Math.Min(115, 78 + sombra / 4));
                    int gr = Math.Max(135, Math.Min(220, 174 + sombra));
                    int b = Math.Max(70, Math.Min(145, 102 + sombra / 3));
                    fill = Drawing.Color.FromArgb(r, gr, b);
                }
                else
                {
                    // Gris estilo Revit con sombras ambientales suaves.
                    int baseColor = cp.EsReal ? 214 : 222;
                    int v = Math.Max(145, Math.Min(242, baseColor + sombra));
                    fill = Drawing.Color.FromArgb(v, v, v);
                }

                using (Drawing.Brush brush = new Drawing.SolidBrush(fill))
                {
                    g.FillPolygon(brush, cp.Puntos);
                }
            }

            private void DibujarSombrasAmbientales(
                Drawing.Graphics g,
                List<CaraPantalla> pantalla)
            {
                if (g == null || pantalla == null || pantalla.Count == 0)
                    return;

                // Simulación de sombras ambientales: se dibuja una copia muy suave
                // de las caras, desplazada y difuminada por capas, antes del sólido.
                // No es el motor de Revit, pero visualmente se parece al check
                // "Mostrar sombras ambientales".
                Drawing.PointF[] offsets = new Drawing.PointF[]
                {
                    new Drawing.PointF(7.0f, 9.0f),
                    new Drawing.PointF(4.0f, 5.0f),
                    new Drawing.PointF(2.0f, 3.0f)
                };

                int[] alphas = new int[] { 18, 12, 8 };

                for (int k = 0; k < offsets.Length; k++)
                {
                    using (Drawing.Brush br = new Drawing.SolidBrush(
                        Drawing.Color.FromArgb(alphas[k], 0, 0, 0)))
                    {
                        foreach (CaraPantalla cp in pantalla)
                        {
                            if (cp == null || cp.Puntos == null || cp.Puntos.Length < 3)
                                continue;

                            Drawing.PointF[] pts = new Drawing.PointF[cp.Puntos.Length];

                            for (int i = 0; i < cp.Puntos.Length; i++)
                            {
                                pts[i] = new Drawing.PointF(
                                    cp.Puntos[i].X + offsets[k].X,
                                    cp.Puntos[i].Y + offsets[k].Y);
                            }

                            g.FillPolygon(br, pts);
                        }
                    }
                }
            }

            private void DibujarMarcaFoco(
                Drawing.Graphics g,
                List<CaraPantalla> pantalla)
            {
                if (g == null || pantalla == null || pantalla.Count == 0)
                    return;

                List<Drawing.PointF> ptsFoco = pantalla
                    .Where(c => c != null && c.EsVigaSeleccionada && c.IndiceViga == indiceVigaEnfoque && c.Puntos != null)
                    .SelectMany(c => c.Puntos)
                    .ToList();

                if (ptsFoco.Count == 0)
                    return;

                float x = ptsFoco.Average(p => p.X);
                float y = ptsFoco.Average(p => p.Y);

                using (Drawing.Brush br = new Drawing.SolidBrush(Drawing.Color.FromArgb(170, 35, 140, 55)))
                using (Drawing.Pen pen = new Drawing.Pen(Drawing.Color.White, 1.2f))
                {
                    Drawing.RectangleF rc = new Drawing.RectangleF(x - 4.0f, y - 4.0f, 8.0f, 8.0f);
                    g.FillEllipse(br, rc);
                    g.DrawEllipse(pen, rc);
                }
            }

            private void SeleccionarElementoBajoCursor(Drawing.Point p)
            {
                if (ultimasCarasPantalla == null || ultimasCarasPantalla.Count == 0)
                    return;

                // Se recorre de adelante hacia atrás para tomar la cara visible superior.
                foreach (CaraPantalla cp in ultimasCarasPantalla.OrderByDescending(c => c.Depth))
                {
                    if (cp == null || cp.Puntos == null || cp.Puntos.Length < 3)
                        continue;

                    if (!PuntoDentroPoligono(p, cp.Puntos))
                        continue;

                    if (cp.EsVigaSeleccionada)
                    {
                        indiceVigaEnfoque = cp.IndiceViga;
                        this.Invalidate();
                        return;
                    }
                }
            }

            private bool PuntoDentroPoligono(
                Drawing.Point p,
                Drawing.PointF[] poligono)
            {
                if (poligono == null || poligono.Length < 3)
                    return false;

                bool dentro = false;
                int j = poligono.Length - 1;

                for (int i = 0; i < poligono.Length; i++)
                {
                    bool cruza =
                        ((poligono[i].Y > p.Y) != (poligono[j].Y > p.Y)) &&
                        (p.X < (poligono[j].X - poligono[i].X) * (p.Y - poligono[i].Y) /
                         Math.Max(0.0001f, poligono[j].Y - poligono[i].Y) + poligono[i].X);

                    if (cruza)
                        dentro = !dentro;

                    j = i;
                }

                return dentro;
            }

            private int CorregirIndiceVigaEnfoque(
                List<CaraRender> caras,
                int indiceActual)
            {
                if (caras == null || caras.Count == 0)
                    return 0;

                bool existe = caras.Any(c => c != null && c.EsVigaSeleccionada && c.IndiceViga == indiceActual);

                if (existe)
                    return indiceActual;

                CaraRender primera = caras.FirstOrDefault(c => c != null && c.EsVigaSeleccionada);

                return primera != null ? primera.IndiceViga : 0;
            }

            private P3 ObtenerCentroCaja(Caja3D caja)
            {
                if (!caja.Valida)
                    return new P3(0.0, 0.0, 0.0);

                return new P3(
                    (caja.MinX + caja.MaxX) / 2.0,
                    (caja.MinY + caja.MaxY) / 2.0,
                    (caja.MinZ + caja.MaxZ) / 2.0);
            }

            private List<string> ObtenerClavesAristasCara(CaraRender cara)
            {
                List<string> claves = new List<string>();

                if (cara == null || cara.Puntos == null || cara.Puntos.Count < 3)
                    return claves;

                for (int i = 0; i < cara.Puntos.Count; i++)
                {
                    P3 a = cara.Puntos[i];
                    P3 b = cara.Puntos[(i + 1) % cara.Puntos.Count];

                    string ka = ClavePunto3D(a);
                    string kb = ClavePunto3D(b);

                    string clave = string.CompareOrdinal(ka, kb) <= 0
                        ? ka + "|" + kb
                        : kb + "|" + ka;

                    claves.Add(clave);
                }

                return claves;
            }

            private Dictionary<string, AristaRender> ConstruirDiccionarioAristasVisibles(
                List<CaraRender> caras)
            {
                Dictionary<string, AristaRender> aristas = new Dictionary<string, AristaRender>();

                if (caras == null)
                    return aristas;

                foreach (CaraRender cara in caras)
                {
                    if (cara == null || cara.Puntos == null || cara.Puntos.Count < 3)
                        continue;

                    for (int i = 0; i < cara.Puntos.Count; i++)
                    {
                        P3 a = cara.Puntos[i];
                        P3 b = cara.Puntos[(i + 1) % cara.Puntos.Count];

                        string ka = ClavePunto3D(a);
                        string kb = ClavePunto3D(b);

                        string clave = string.CompareOrdinal(ka, kb) <= 0
                            ? ka + "|" + kb
                            : kb + "|" + ka;

                        AristaRender arista = null;

                        if (!aristas.TryGetValue(clave, out arista))
                        {
                            arista = new AristaRender();
                            arista.A = a;
                            arista.B = b;
                            arista.Cantidad = 0;
                            aristas[clave] = arista;
                        }

                        arista.Cantidad++;
                        arista.EsVigaSeleccionada = arista.EsVigaSeleccionada || cara.EsVigaSeleccionada;

                        if (arista.Normales == null)
                            arista.Normales = new List<P3>();

                        arista.Normales.Add(cara.Normal);
                    }
                }

                // Solo quedan activas las aristas que son contorno real o quiebre entre caras.
                // Las diagonales internas de triangulación coplanar quedan apagadas.
                Dictionary<string, AristaRender> visibles = new Dictionary<string, AristaRender>();

                foreach (KeyValuePair<string, AristaRender> kv in aristas)
                {
                    AristaRender arista = kv.Value;

                    if (arista == null)
                        continue;

                    bool visible = arista.Cantidad == 1 || AristaTieneQuiebre(arista);

                    if (visible)
                        visibles[kv.Key] = arista;
                }

                return visibles;
            }

            private void DibujarAristasDeCaraPantalla(
                Drawing.Graphics g,
                CaraPantalla cp,
                Dictionary<string, AristaRender> aristasVisibles)
            {
                if (g == null || cp == null || cp.Puntos == null || cp.Puntos.Length < 3)
                    return;

                if (cp.ClavesAristas == null || cp.ClavesAristas.Count == 0)
                    return;

                if (aristasVisibles == null || aristasVisibles.Count == 0)
                    return;

                using (Drawing.Pen penViga = new Drawing.Pen(Drawing.Color.FromArgb(28, 95, 42), 1.65f))
                using (Drawing.Pen penApoyo = new Drawing.Pen(Drawing.Color.FromArgb(88, 88, 88), 1.05f))
                {
                    int n = Math.Min(cp.Puntos.Length, cp.ClavesAristas.Count);

                    for (int i = 0; i < n; i++)
                    {
                        string clave = cp.ClavesAristas[i];

                        if (string.IsNullOrWhiteSpace(clave))
                            continue;

                        if (!aristasVisibles.ContainsKey(clave))
                            continue;

                        Drawing.PointF a = cp.Puntos[i];
                        Drawing.PointF b = cp.Puntos[(i + 1) % cp.Puntos.Length];

                        g.DrawLine(
                            cp.EsVigaSeleccionada ? penViga : penApoyo,
                            a,
                            b);
                    }
                }
            }

            private void DibujarAristasExteriores(
                Drawing.Graphics g,
                List<CaraRender> caras,
                Caja3D caja,
                double escala)
            {
                if (g == null || caras == null || caras.Count == 0)
                    return;

                Dictionary<string, AristaRender> aristas = new Dictionary<string, AristaRender>();

                foreach (CaraRender cara in caras)
                {
                    if (cara == null || cara.Puntos == null || cara.Puntos.Count < 3)
                        continue;

                    for (int i = 0; i < cara.Puntos.Count; i++)
                    {
                        P3 a = cara.Puntos[i];
                        P3 b = cara.Puntos[(i + 1) % cara.Puntos.Count];

                        string ka = ClavePunto3D(a);
                        string kb = ClavePunto3D(b);

                        string clave = string.CompareOrdinal(ka, kb) <= 0
                            ? ka + "|" + kb
                            : kb + "|" + ka;

                        AristaRender arista = null;

                        if (!aristas.TryGetValue(clave, out arista))
                        {
                            arista = new AristaRender();
                            arista.A = a;
                            arista.B = b;
                            arista.Cantidad = 0;
                            aristas[clave] = arista;
                        }

                        arista.Cantidad++;
                        arista.EsVigaSeleccionada = arista.EsVigaSeleccionada || cara.EsVigaSeleccionada;

                        if (arista.Normales == null)
                            arista.Normales = new List<P3>();

                        arista.Normales.Add(cara.Normal);
                    }
                }

                using (Drawing.Pen penViga = new Drawing.Pen(Drawing.Color.FromArgb(20, 95, 45), 1.35f))
                using (Drawing.Pen penApoyo = new Drawing.Pen(Drawing.Color.FromArgb(70, 70, 70), 1.05f))
                {
                    foreach (KeyValuePair<string, AristaRender> kv in aristas)
                    {
                        AristaRender arista = kv.Value;

                        if (arista == null)
                            continue;

                        // Se dibuja si es borde exterior o si une caras con distinto plano.
                        // Así aparecen los contornos del sólido, pero se evitan diagonales internas
                        // de triangulación entre caras coplanares.
                        bool dibujar = arista.Cantidad == 1 || AristaTieneQuiebre(arista);

                        if (!dibujar)
                            continue;

                        P2 pa = Proyectar(arista.A, caja, escala);
                        P2 pb = Proyectar(arista.B, caja, escala);

                        g.DrawLine(
                            arista.EsVigaSeleccionada ? penViga : penApoyo,
                            pa.Punto,
                            pb.Punto);
                    }
                }
            }

            private bool AristaTieneQuiebre(AristaRender arista)
            {
                if (arista == null || arista.Normales == null || arista.Normales.Count < 2)
                    return false;

                P3 n0 = Normalizar(arista.Normales[0]);

                for (int i = 1; i < arista.Normales.Count; i++)
                {
                    P3 n1 = Normalizar(arista.Normales[i]);
                    double dot = Math.Abs(Dot(n0, n1));

                    // 1.00 = coplanar/paralela. Si baja de 0.985, hay quiebre real.
                    if (dot < 0.985)
                        return true;
                }

                return false;
            }

            private P3 CalcularNormal3D(List<P3> puntos)
            {
                if (puntos == null || puntos.Count < 3)
                    return new P3(0.0, 0.0, 1.0);

                P3 a = puntos[0];
                P3 b = puntos[1];
                P3 c = puntos[2];

                double ux = b.X - a.X;
                double uy = b.Y - a.Y;
                double uz = b.Z - a.Z;

                double vx = c.X - a.X;
                double vy = c.Y - a.Y;
                double vz = c.Z - a.Z;

                P3 n = new P3(
                    (uy * vz) - (uz * vy),
                    (uz * vx) - (ux * vz),
                    (ux * vy) - (uy * vx));

                return Normalizar(n);
            }

            private P3 Normalizar(P3 p)
            {
                double len = Math.Sqrt((p.X * p.X) + (p.Y * p.Y) + (p.Z * p.Z));

                if (len <= 1e-9)
                    return new P3(0.0, 0.0, 1.0);

                return new P3(p.X / len, p.Y / len, p.Z / len);
            }

            private double Dot(P3 a, P3 b)
            {
                return (a.X * b.X) + (a.Y * b.Y) + (a.Z * b.Z);
            }

            private string ClavePunto3D(P3 p)
            {
                // Agrupa vértices prácticamente iguales aunque Revit los devuelva
                // duplicados por cada triángulo. Tolerancia: 1 mm.
                long x = (long)Math.Round(p.X);
                long y = (long)Math.Round(p.Y);
                long z = (long)Math.Round(p.Z);

                return x.ToString() + ";" + y.ToString() + ";" + z.ToString();
            }

            private void DibujarAyuda(Drawing.Graphics g, bool usaSolidosReales)
            {
                string modo = usaSolidosReales ? "Sólido real" : "Sólido esquemático";
                string texto = modo + " / línea oculta + sombras  |  Clic: enfocar viga  |  Arrastrar: orbitar  |  Rueda: zoom  |  Doble click: reset";

                using (Drawing.Font font = new Drawing.Font("Segoe UI", 7.5F))
                using (Drawing.Brush brush = new Drawing.SolidBrush(Drawing.Color.Gray))
                {
                    g.DrawString(texto, font, brush, 8, this.ClientSize.Height - 20);
                }
            }

            private class AristaRender
            {
                public P3 A;
                public P3 B;
                public int Cantidad;
                public bool EsVigaSeleccionada;
                public List<P3> Normales = new List<P3>();
            }

            private class CaraRender
            {
                public List<P3> Puntos = new List<P3>();
                public bool EsReal = false;
                public bool EsVigaSeleccionada = false;
                public int IndiceViga = 0;
                public P3 Normal = new P3(0.0, 0.0, 1.0);
            }

            private class CaraPantalla
            {
                public Drawing.PointF[] Puntos;
                public double Depth;
                public bool EsReal;
                public bool EsVigaSeleccionada;
                public int IndiceViga;
                public double NormalZ;
                public List<string> ClavesAristas = new List<string>();
            }

            private struct P3
            {
                public double X;
                public double Y;
                public double Z;

                public P3(double x, double y, double z)
                {
                    X = x;
                    Y = y;
                    Z = z;
                }
            }

            private struct P2
            {
                public Drawing.PointF Punto;
                public double Depth;

                public P2(Drawing.PointF punto, double depth)
                {
                    Punto = punto;
                    Depth = depth;
                }
            }

            private struct Caja3D
            {
                public bool Valida;
                public double MinX;
                public double MinY;
                public double MinZ;
                public double MaxX;
                public double MaxY;
                public double MaxZ;
            }
        }
    }
}
