﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Drawing = System.Drawing;
using WinForms = System.Windows.Forms;

namespace MYG_Addin
{
    // =====================================
    // VENTANA - CREAR ESTRIBOS EN VIGAS
    // Archivo independiente
    // =====================================
    public class AceroEstribosVigasForm : WinForms.Form
    {
        // =====================================
        // MODELOS
        // =====================================
        public class TramoInfo
        {
            public int Index { get; set; }
            public double LongitudMm { get; set; }
            public double ApoyoIzqMm { get; set; }
            public double ApoyoDerMm { get; set; }

            // Rango exacto del tramo dentro de la serie de la vista preliminar.
            // Esto permite que el handler cree los estribos por tramo aunque
            // Revit tenga toda la viga/armazón como un solo elemento.
            public double StartSerieMm { get; set; }
            public double EndSerieMm { get; set; }
            public double TotalSerieMm { get; set; }

            public string Nombre { get; set; }

            public TramoInfo(
                int index,
                double longitudMm,
                double apoyoIzqMm,
                double apoyoDerMm,
                string nombre)
            {
                Index = index;
                LongitudMm = longitudMm;
                ApoyoIzqMm = apoyoIzqMm;
                ApoyoDerMm = apoyoDerMm;
                StartSerieMm = 0.0;
                EndSerieMm = longitudMm;
                TotalSerieMm = 0.0;
                Nombre = nombre;
            }

            public TramoInfo(
                int index,
                double longitudMm,
                double apoyoIzqMm,
                double apoyoDerMm,
                string nombre,
                double startSerieMm,
                double endSerieMm,
                double totalSerieMm)
            {
                Index = index;
                LongitudMm = longitudMm;
                ApoyoIzqMm = apoyoIzqMm;
                ApoyoDerMm = apoyoDerMm;
                StartSerieMm = startSerieMm;
                EndSerieMm = endSerieMm;
                TotalSerieMm = totalSerieMm;
                Nombre = nombre;
            }
        }

        public class TramoEstriboConfig
        {
            public int TipoDistribucion { get; set; } = 1; // 1, 2, 3 o 4.
            public double[] SeparacionesCm { get; set; } = new double[4];
            public int[] Cantidades { get; set; } = new int[4];

            public TramoEstriboConfig Clonar()
            {
                TramoEstriboConfig c = new TramoEstriboConfig();
                c.TipoDistribucion = TipoDistribucion;
                c.SeparacionesCm = (double[])SeparacionesCm.Clone();
                c.Cantidades = (int[])Cantidades.Clone();
                return c;
            }
        }

        public class ModeloEstribosVigas
        {
            public List<TramoInfo> Tramos { get; set; }
            public Dictionary<int, TramoEstriboConfig> Configuraciones { get; set; }

            public ModeloEstribosVigas()
            {
                Tramos = new List<TramoInfo>();
                Configuraciones = new Dictionary<int, TramoEstriboConfig>();
            }
        }

        // =========================================================
        // DATA PERSISTENTE - ESTRIBOS + LONGITUDINALES
        // =========================================================
        public class ConfiguracionTramoEstribosPersistente
        {
            public int TipoDistribucion { get; set; }
            public double[] SeparacionesCm { get; set; }
            public int[] Cantidades { get; set; }

            public ConfiguracionTramoEstribosPersistente()
            {
                TipoDistribucion = 4;
                SeparacionesCm = new double[4];
                Cantidades = new int[4];
            }
        }

        public class ConfiguracionEstribosPersistente
        {
            public string TipoBarraEstribo { get; set; }
            public string RecubrimientoCm { get; set; }
            public int FormaEstribo { get; set; }
            public bool DetectarFormaAutomaticamente { get; set; }

            // Segundo estribo rectangular interior. Mantiene la misma altura
            // del estribo exterior y solo se retrae lateralmente en ambos lados.
            public bool CrearEstriboCentral { get; set; }
            public string RetiroLateralEstriboCentralCm { get; set; }

            public List<ConfiguracionTramoEstribosPersistente> Tramos { get; set; }

            public ConfiguracionEstribosPersistente()
            {
                TipoBarraEstribo = "";
                RecubrimientoCm = "4";
                FormaEstribo = 0;
                DetectarFormaAutomaticamente = true;
                CrearEstriboCentral = false;
                RetiroLateralEstriboCentralCm = "15";
                Tramos = new List<ConfiguracionTramoEstribosPersistente>();
            }
        }

        public class ConfiguracionLongitudinalPersistente
        {
            public string TipoSuperior { get; set; }
            public string TipoInferior { get; set; }
            public string TipoCentral { get; set; }
            public string TipoSuperiorCapa2 { get; set; }
            public string TipoSuperiorCapa3 { get; set; }
            public string TipoSuperiorCapa4 { get; set; }
            public string TipoInferiorCapa2 { get; set; }
            public string TipoInferiorCapa3 { get; set; }
            public string TipoInferiorCapa4 { get; set; }

            public int CapasSuperior { get; set; }
            public int CapasInferior { get; set; }

            public string CantidadSuperior { get; set; }
            public string CantidadInferior { get; set; }
            public string CantidadSuperiorCapa2 { get; set; }
            public string CantidadSuperiorCapa3 { get; set; }
            public string CantidadSuperiorCapa4 { get; set; }
            public string CantidadInferiorCapa2 { get; set; }
            public string CantidadInferiorCapa3 { get; set; }
            public string CantidadInferiorCapa4 { get; set; }
            public string RecubrimientoCm { get; set; }
            public string SeparacionCapas { get; set; }

            public bool AceroCentral { get; set; }
            public bool CrearEmpalmes { get; set; }
            public bool UsarRNE { get; set; }
            public string LongitudEmpalmeCm { get; set; }
            public string LongitudBarraM { get; set; }

            public bool GanchoInicio { get; set; }
            public bool GanchoFin { get; set; }
            public string LongitudGanchoInicioCm { get; set; }
            public string LongitudGanchoFinCm { get; set; }
            public string LongitudDesarrolloInicioCm { get; set; }
            public string LongitudDesarrolloFinCm { get; set; }
            public bool DesarrolloAutomaticoInicio { get; set; }
            public bool DesarrolloAutomaticoFin { get; set; }
            public bool GraficarEstribos { get; set; }

            public double RneFcKgCm2 { get; set; }
            public double RneFyMpa { get; set; }
            public double RnePsiE { get; set; }
            public double RneLambda { get; set; }
            public double RneFactorEmpalme { get; set; }
            public double RneMinEmpalmeMm { get; set; }
            public double RnePsiSuperior { get; set; }
            public double RnePsiInferior { get; set; }
            public double RnePsiCentral { get; set; }

            public ConfiguracionLongitudinalPersistente()
            {
                TipoSuperior = "";
                TipoInferior = "";
                TipoCentral = "";
                TipoSuperiorCapa2 = "";
                TipoSuperiorCapa3 = "";
                TipoSuperiorCapa4 = "";
                TipoInferiorCapa2 = "";
                TipoInferiorCapa3 = "";
                TipoInferiorCapa4 = "";
                CapasSuperior = 1;
                CapasInferior = 1;
                CantidadSuperior = "2";
                CantidadInferior = "2";
                CantidadSuperiorCapa2 = "2";
                CantidadSuperiorCapa3 = "2";
                CantidadSuperiorCapa4 = "2";
                CantidadInferiorCapa2 = "2";
                CantidadInferiorCapa3 = "2";
                CantidadInferiorCapa4 = "2";
                RecubrimientoCm = "4";
                SeparacionCapas = "1\"";
                AceroCentral = false;
                CrearEmpalmes = false;
                UsarRNE = false;
                LongitudEmpalmeCm = "60";
                LongitudBarraM = "9";
                GanchoInicio = false;
                GanchoFin = false;
                LongitudGanchoInicioCm = "15";
                LongitudGanchoFinCm = "15";
                LongitudDesarrolloInicioCm = "60";
                LongitudDesarrolloFinCm = "60";
                DesarrolloAutomaticoInicio = false;
                DesarrolloAutomaticoFin = false;
                GraficarEstribos = false;
                RneFcKgCm2 = 210.0;
                RneFyMpa = 420.0;
                RnePsiE = 1.0;
                RneLambda = 1.0;
                RneFactorEmpalme = 1.30;
                RneMinEmpalmeMm = 300.0;
                RnePsiSuperior = 1.30;
                RnePsiInferior = 1.00;
                RnePsiCentral = 1.00;
            }
        }

        public class ArchivoConfiguracionAceroVigas
        {
            public int Version { get; set; }
            public string FechaGuardado { get; set; }
            public ConfiguracionEstribosPersistente Estribos { get; set; }
            public ConfiguracionLongitudinalPersistente Longitudinal { get; set; }

            // V11.2 - Diseño gráfico completo del editor de sección. Se guarda
            // como XML interno para conservar barras, grupos, reglas, guías y
            // estribos dibujados, sin intentar serializar RebarBarType.
            public string DisenoSeccionXml { get; set; }

            // V11.32 - Estado de los modos CONTINUO/INTERMEDIO/AVANZADO:
            // selección exacta por barra y tramo, MIRROR visual, extensión al
            // aparecer y desarrollos de corte configurados por diámetro.
            public string EstadoLongitudinalAvanzadoXml { get; set; }

            public ArchivoConfiguracionAceroVigas()
            {
                Version = 5;
                FechaGuardado = "";
                Estribos = new ConfiguracionEstribosPersistente();
                Longitudinal = new ConfiguracionLongitudinalPersistente();
                DisenoSeccionXml = string.Empty;
                EstadoLongitudinalAvanzadoXml = string.Empty;
            }
        }

        // =====================================
        // FORMAS DE ESTRIBO PARA EJECUCIÓN
        // =====================================
        public enum TipoFormaEstribo
        {
            Rectangular = 0,
            Cumbrera = 1
        }

        private class TipoFormaEstriboItem
        {
            public TipoFormaEstribo Tipo { get; set; }
            public string Nombre { get; set; }

            public TipoFormaEstriboItem(TipoFormaEstribo tipo, string nombre)
            {
                Tipo = tipo;
                Nombre = nombre;
            }

            public override string ToString()
            {
                return Nombre;
            }
        }

        // =====================================
        // EVENTO EXTERNO PARA HANDLER DE EJECUCIÓN
        // =====================================
        public ExternalEvent EjecutarEstribosEvent;

        // V11.51 - preparación sin ExternalEvent anidado para EJECUTAR TODO.
        private bool prepararSoloEjecucionCombinadaMYG = false;
        private bool ultimaPreparacionCombinadaValidaMYG = false;

        // Evento para avisar al MAIN que debe redibujar la vista preliminar global.
        public event Action PreviewEstribosActualizado;

        public ModeloEstribosVigas ModeloEjecucionActual { get; private set; }

        // =====================================
        // CONTROLES
        // =====================================
        public WinForms.ComboBox cmbTipoEstribo;
        public WinForms.ComboBox cmbFormaEstribo;

        private AceroLongitudinalVigasForm ventanaLongitudinalOrigen;
        private List<VigaLongitudinalPreview> vigasPreview = new List<VigaLongitudinalPreview>();

        private WinForms.Label lblTitulo;
        private WinForms.Label lblDescripcion;

        private WinForms.GroupBox grpGeneral;
        private WinForms.GroupBox grpTramo;
        private WinForms.GroupBox grpPreview;

        private WinForms.Label lblTramoActual;
        private WinForms.Label lblLuzActual;
        private WinForms.Label lblResumenOcupacion;
        private WinForms.Label lblMensaje;

        private WinForms.TextBox txtRecubrimiento;
        private WinForms.ComboBox cboTipoDistribucion;
        private WinForms.CheckBox chkDibujarLongitudinalesGris;
        private WinForms.Label lblFormaEstribo;
        private WinForms.CheckBox chkDetectarFormaAutomaticamente;

        // Segundo estribo cerrado interior: misma altura y retiro solo lateral.
        private WinForms.CheckBox chkCrearEstriboCentral;
        private WinForms.Label lblRetiroEstriboCentral;
        private WinForms.TextBox txtRetiroLateralEstriboCentral;
        private WinForms.Label lblCmRetiroEstriboCentral;

        private Drawing.Image imgFormaRectangular;
        private Drawing.Image imgFormaCumbrera;

        private WinForms.Button btnCopiarAlResto;
        private WinForms.Button btnRestablecerTramo;
        private WinForms.Button btnGuardarData;
        private WinForms.Button btnCargarData;
        private WinForms.Button btnEjecutarEstribos;

        private WinForms.Panel panelFilasDistribucion;

        private WinForms.NumericUpDown[] numSeparacionesCm = new WinForms.NumericUpDown[4];
        private WinForms.NumericUpDown[] numCantidades = new WinForms.NumericUpDown[4];
        private WinForms.Label[] lblFila = new WinForms.Label[4];
        private WinForms.Label[] lblSep = new WinForms.Label[4];
        private WinForms.Label[] lblCant = new WinForms.Label[4];

        private VistaPreviaEstribosPanel panelPreview;

        // Editor gráfico integrado en esta misma pestaña. No contiene entradas
        // duplicadas: toma el tipo de barra y el recubrimiento de grpGeneral.
        private WinForms.Panel panelConfiguracionUnificada;
        private WinForms.Panel panelEditorSeccionIntegrado;
        private WinForms.Panel panelHerramientasEditorUnificado;
        private WinForms.Panel barraEdicionEditorUnificada;
        private AceroVigaEditorSeccionForm editorSeccionIntegrado;
        private WinForms.Label lblEditorSinGeometriaIntegrado;

        // V8 - composición visual equivalente al módulo de columnas.
        private WinForms.Panel panelFormatoColumnasV8Estribos;
        private WinForms.CheckBox chkCrearEstribosV8;
        private WinForms.Label lblAyudaFormatoV8Estribos;
        private WinForms.Button btnAplicarTipoSeleccionV8;

        // =====================================
        // DATOS
        // =====================================
        private List<TramoInfo> tramos = new List<TramoInfo>();

        private Dictionary<int, TramoEstriboConfig> configsPorTramo =
            new Dictionary<int, TramoEstriboConfig>();

        private int tramoSeleccionado = -1;
        private bool bloqueandoEventos = false;

        // Cuando se carga una data sin vigas seleccionadas, la configuración de
        // estribos queda pendiente y se aplica automáticamente al cargar los tramos.
        private ConfiguracionEstribosPersistente configuracionEstribosPendiente = null;

        // Bloquea cambios visuales/selección del combo de forma mientras
        // la forma está siendo aplicada automáticamente por código.
        private bool bloqueandoCambioFormaEstribo = false;

        // Forma detectada desde el handler de ejecución.
        // Esta tiene prioridad sobre la detección propia de la ventana,
        // para que lo que se grafica sea exactamente lo que usará el handler.
        private TipoFormaEstribo? formaDetectadaDesdeHandler = null;
        private EjecutarEstribosVigasHandler handlerDeteccionFormaAutomatico = null;

        // Forma recibida desde el MAIN.
        // Cuando está activo, el selector visual de esta ventana queda oculto
        // y el valor usado por el handler sale del selector global.
        private bool usarFormaEstriboDesdeMain = false;
        private TipoFormaEstribo formaEstriboDesdeMain = TipoFormaEstribo.Rectangular;
        private bool detectarFormaDesdeMain = true;

        public event Action<TipoFormaEstribo> FormaDetectadaAutomaticamenteChanged;

        // Referencias opcionales para detectar la forma directamente desde
        // la geometría real de Revit. Si no se conectan desde el comando,
        // la ventana intentará encontrarlas por reflexión desde la pestaña
        // de selección de vigas.
        public UIDocument UiDocFormaAutomatico;
        public SeleccionarVigasAceroLongitudinalHandler SeleccionHandlerFormaAutomatico;

        // Primer estribo a 5 cm desde la cara de la columna hacia dentro del tramo.
        private const double OFFSET_PRIMER_ESTRIBO_CM = 5.0;

        public RebarBarType TipoEstriboSeleccionado
        {
            get { return cmbTipoEstribo.SelectedItem as RebarBarType; }
        }

        /// <summary>
        /// Compatibilidad con versiones anteriores. El segundo estribo central
        /// automático fue retirado: todos los recorridos se dibujan manualmente.
        /// </summary>
        public bool CrearEstriboCentral
        {
            get { return false; }
        }

        public string RetiroLateralEstriboCentralTexto
        {
            get { return "0"; }
        }

        public TipoFormaEstribo FormaEstriboSeleccionada
        {
            get
            {
                if (usarFormaEstriboDesdeMain)
                    return formaEstriboDesdeMain;

                TipoFormaEstriboItem item = cmbFormaEstribo != null
                    ? cmbFormaEstribo.SelectedItem as TipoFormaEstriboItem
                    : null;

                if (item == null)
                    return TipoFormaEstribo.Rectangular;

                return item.Tipo;
            }
        }

        public string FormaEstriboTexto
        {
            get
            {
                return FormaEstriboSeleccionada == TipoFormaEstribo.Cumbrera
                    ? "Viga cumbrera"
                    : "Viga rectangular";
            }
        }

        public void EstablecerSelectorFormaDesdeMain(
            TipoFormaEstribo tipo,
            bool detectarAutomaticamente)
        {
            usarFormaEstriboDesdeMain = true;
            formaEstriboDesdeMain = tipo;
            detectarFormaDesdeMain = detectarAutomaticamente;

            try
            {
                if (cmbFormaEstribo != null && cmbFormaEstribo.Items.Count > 0)
                {
                    bool estadoPrevio = cmbFormaEstribo.Enabled;
                    cmbFormaEstribo.Enabled = true;
                    SeleccionarFormaEstribo(tipo);
                    cmbFormaEstribo.Enabled = estadoPrevio;
                }

                if (lblFormaEstribo != null)
                    lblFormaEstribo.Visible = false;

                if (cmbFormaEstribo != null)
                    cmbFormaEstribo.Visible = false;

                if (chkDetectarFormaAutomaticamente != null)
                    chkDetectarFormaAutomaticamente.Visible = false;
            }
            catch
            {
            }

            if (panelPreview != null)
                panelPreview.Invalidate();
        }

        public void RecalcularFormaAutomaticamenteDesdeMain()
        {
            if (!detectarFormaDesdeMain)
                return;

            TipoFormaEstribo tipoDetectado = DetectarFormaEstriboPorTramoActual();
            formaEstriboDesdeMain = tipoDetectado;

            try
            {
                if (cmbFormaEstribo != null && cmbFormaEstribo.Items.Count > 0)
                {
                    bool estadoPrevio = cmbFormaEstribo.Enabled;
                    cmbFormaEstribo.Enabled = true;
                    SeleccionarFormaEstribo(tipoDetectado);
                    cmbFormaEstribo.Enabled = estadoPrevio;
                }
            }
            catch
            {
            }

            try
            {
                FormaDetectadaAutomaticamenteChanged?.Invoke(tipoDetectado);
            }
            catch
            {
            }

            if (panelPreview != null)
                panelPreview.Invalidate();
        }

        public string RecubrimientoTexto
        {
            get { return txtRecubrimiento.Text.Trim(); }
        }


        public void EstablecerRecubrimientoDesdeEditor(double recubrimientoCm)
        {
            if (txtRecubrimiento == null)
                return;

            if (double.IsNaN(recubrimientoCm) ||
                double.IsInfinity(recubrimientoCm) ||
                recubrimientoCm <= 0.0)
            {
                return;
            }

            txtRecubrimiento.Text = recubrimientoCm.ToString(
                "0.##",
                System.Globalization.CultureInfo.InvariantCulture);

            SincronizarEstribosConVentanaLongitudinal();

            if (panelPreview != null)
                panelPreview.Invalidate();
        }

        // =========================================================
        // SINCRONIZACIÓN CON PESTAÑA ACERO LONGITUDINAL
        // =========================================================
        // Cada vez que se configura o recalcula la distribución de estribos,
        // se envía la referencia gráfica a la pestaña de acero longitudinal.
        // Así el check "Graficar estribos" no depende únicamente del botón EJECUTAR.
        private void SincronizarEstribosConVentanaLongitudinal()
        {
            if (ventanaLongitudinalOrigen == null || ventanaLongitudinalOrigen.IsDisposed)
                return;

            try
            {
                ventanaLongitudinalOrigen.EstablecerEstribosCreadosPreview(
                    ObtenerPosicionesEstribosPreview());
            }
            catch
            {
                // No se interrumpe la ventana si la pestaña longitudinal todavía no está lista.
            }

            NotificarPreviewEstribosActualizado();
        }

        private void LimpiarEstribosEnVentanaLongitudinal()
        {
            if (ventanaLongitudinalOrigen == null || ventanaLongitudinalOrigen.IsDisposed)
                return;

            try
            {
                ventanaLongitudinalOrigen.LimpiarEstribosCreadosPreview();
            }
            catch
            {
                // No se interrumpe la ventana si la pestaña longitudinal todavía no está lista.
            }
        }



        private void NotificarPreviewEstribosActualizado()
        {
            try
            {
                if (PreviewEstribosActualizado != null)
                    PreviewEstribosActualizado();
            }
            catch
            {
                // No interrumpir por un refresco visual.
            }
        }

        public AceroEstribosVigasForm()
        {
            this.Text = "MYG - Estribos en Vigas";
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.None;
            this.TopLevel = false;
            this.ShowInTaskbar = false;
            this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new Drawing.Font("Segoe UI", 9F);
            this.Dock = WinForms.DockStyle.Fill;

            ModeloEjecucionActual = new ModeloEstribosVigas();

            // V6: el editor usa exclusivamente geometría vectorial de la
            // sección real. No se cargan miniaturas ni imágenes de formas.
            CrearInterfaz();
            LimpiarTramos();

            this.FormClosed += (s, e) =>
            {
                LimpiarPanelesEditorUnificado();
                if (editorSeccionIntegrado != null &&
                    !editorSeccionIntegrado.IsDisposed)
                {
                    editorSeccionIntegrado.Dispose();
                }
            };
        }

        // =====================================
        // CREAR INTERFAZ
        // =====================================
        private void CrearInterfaz()
        {
            lblTitulo = new WinForms.Label()
            {
                Left = 20,
                Top = 16,
                Width = 760,
                Height = 24,
                Text = "Crear estribos por tramo",
                Font = new Drawing.Font("Segoe UI", 10F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(45, 45, 45)
            };

            lblDescripcion = new WinForms.Label()
            {
                Left = 20,
                Top = 42,
                Width = 820,
                Height = 22,
                Text = "Usa la geometría de la vista preliminar. Haga clic en un tramo para configurar sus estribos.",
                Font = new Drawing.Font("Segoe UI", 8.5F),
                ForeColor = Drawing.Color.Gray
            };

            this.Controls.Add(lblTitulo);
            this.Controls.Add(lblDescripcion);

            CrearGrupoGeneral();
            CrearGrupoTramo();

            // La vista preliminar 2D ya no se crea dentro de esta pestaña.
            // Ahora vive una sola vez en AceroVigasMainForm, en la región fija inferior.
            // CrearGrupoPreview();

            CrearBotonEjecutar();
            CrearPanelEditorSeccionIntegrado();
            CrearPanelConfiguracionUnificada();

            this.Resize += (s, e) =>
            {
                AjustarLayout();
            };

            AjustarLayout();
        }

        private void CrearGrupoGeneral()
        {
            grpGeneral = new WinForms.GroupBox()
            {
                Text = "Parámetros generales de estribos",
                Left = 20,
                Top = 72,
                Width = 500,
                Height = 92,
                Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50),
                BackColor = Drawing.Color.FromArgb(245, 247, 250)
            };

            WinForms.Label lblTipo = new WinForms.Label()
            {
                Text = "Tipo barra estribo:",
                Left = 18,
                Top = 28,
                Width = 105,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold)
            };

            cmbTipoEstribo = new WinForms.ComboBox()
            {
                Left = 145,
                Top = 25,
                Width = 120,
                Height = 24,
                DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
                MaxDropDownItems = 10,
                IntegralHeight = false
            };

            WinForms.Label lblRec = new WinForms.Label()
            {
                Text = "Recubrimiento:",
                Left = 320,
                Top = 28,
                Width = 90,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold)
            };

            txtRecubrimiento = new WinForms.TextBox()
            {
                Left = 410,
                Top = 25,
                Width = 55,
                Height = 24,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                Text = "4",
                TextAlign = WinForms.HorizontalAlignment.Center
            };

            cmbTipoEstribo.SelectedIndexChanged += (s, e) =>
            {
                RefrescarEditorSeccionIntegrado();
                NotificarPreviewEstribosActualizado();
            };

            txtRecubrimiento.TextChanged += (s, e) =>
            {
                RefrescarEditorSeccionIntegrado();
                NotificarPreviewEstribosActualizado();
            };

            WinForms.Label lblCm = new WinForms.Label()
            {
                Text = "cm",
                Left = 468,
                Top = 28,
                Width = 30,
                Height = 22,
                ForeColor = Drawing.Color.Gray
            };

            lblFormaEstribo = new WinForms.Label()
            {
                Text = "Forma estribo:",
                Left = 550,
                Top = 80,
                Width = 135,
                Height = 18,
                Font = new Drawing.Font("Segoe UI", 8.2F, Drawing.FontStyle.Bold)
            };

            cmbFormaEstribo = new WinForms.ComboBox()
            {
                Left = 550,
                Top = 102,
                Width = 92,
                Height = 44,
                DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
                DrawMode = WinForms.DrawMode.OwnerDrawFixed,
                ItemHeight = 48,
                MaxDropDownItems = 4,
                IntegralHeight = false,
                DropDownHeight = 106,
                DropDownWidth = 112
            };

            cmbFormaEstribo.Items.Add(
                new TipoFormaEstriboItem(
                    TipoFormaEstribo.Rectangular,
                    "Viga rectangular"));

            cmbFormaEstribo.Items.Add(
                new TipoFormaEstriboItem(
                    TipoFormaEstribo.Cumbrera,
                    "Viga cumbrera"));

            cmbFormaEstribo.DrawItem += CmbFormaEstribo_DrawItem;

            cmbFormaEstribo.SelectedIndexChanged += (s, e) =>
            {
                RefrescarComboFormaEstribo();

                if (panelPreview != null)
                    panelPreview.Invalidate();
            };

            // En modo automático el combo se mantiene HABILITADO para que WinForms
            // dibuje correctamente la imagen seleccionada.
            // Si se deshabilita con Enabled = false, el área cerrada del ComboBox
            // puede quedarse con la miniatura anterior aunque el SelectedIndex cambie.
            cmbFormaEstribo.SelectionChangeCommitted += (s, e) =>
            {
                if (bloqueandoCambioFormaEstribo)
                    return;

                if (chkDetectarFormaAutomaticamente != null &&
                    chkDetectarFormaAutomaticamente.Checked)
                {
                    DetectarYAplicarFormaEstriboAutomaticamente();
                }
            };

            cmbFormaEstribo.DropDown += (s, e) =>
            {
                if (chkDetectarFormaAutomaticamente != null &&
                    chkDetectarFormaAutomaticamente.Checked)
                {
                    BeginInvoke(new Action(() =>
                    {
                        if (cmbFormaEstribo != null)
                            cmbFormaEstribo.DroppedDown = false;
                    }));
                }
            };

            cmbFormaEstribo.MouseWheel += (s, e) =>
            {
                if (chkDetectarFormaAutomaticamente != null &&
                    chkDetectarFormaAutomaticamente.Checked)
                {
                    WinForms.HandledMouseEventArgs he = e as WinForms.HandledMouseEventArgs;
                    if (he != null)
                        he.Handled = true;
                }
            };

            if (cmbFormaEstribo.Items.Count > 0)
                cmbFormaEstribo.SelectedIndex = 0;

            chkDetectarFormaAutomaticamente = new WinForms.CheckBox()
            {
                Text = "Detectar automáticamente",
                Left = 535,
                Top = 160,
                Width = 190,
                Height = 18,
                Checked = true,
                BackColor = Drawing.Color.FromArgb(245, 247, 250),
                Font = new Drawing.Font("Segoe UI", 8.0F, Drawing.FontStyle.Regular),
                Cursor = WinForms.Cursors.Hand
            };

            chkDetectarFormaAutomaticamente.CheckedChanged += (s, e) =>
            {
                if (chkDetectarFormaAutomaticamente.Checked)
                    DetectarYAplicarFormaEstriboAutomaticamente();
                else
                    RefrescarComboFormaEstribo();

                ActualizarBloqueoComboFormaEstribo();

                if (panelPreview != null)
                    panelPreview.Invalidate();
            };

            // Si está activo Detectar automáticamente, la lista queda bloqueada.
            ActualizarBloqueoComboFormaEstribo();

            // Ya no se muestra acero longitudinal en la pestaña Estribos.
            // Se deja el objeto solo por compatibilidad interna, pero no se agrega al formulario.
            chkDibujarLongitudinalesGris = new WinForms.CheckBox()
            {
                Visible = false,
                Checked = false
            };

            btnCopiarAlResto = new WinForms.Button()
            {
                Left = 18,
                Top = 54,
                Width = 125,
                Height = 28,
                Text = "Copiar al resto",
                FlatStyle = WinForms.FlatStyle.Flat,
                Cursor = WinForms.Cursors.Hand
            };
            btnCopiarAlResto.FlatAppearance.BorderColor = Drawing.Color.Silver;
            btnCopiarAlResto.Click += BtnCopiarAlResto_Click;

            btnRestablecerTramo = new WinForms.Button()
            {
                Left = 155,
                Top = 54,
                Width = 115,
                Height = 28,
                Text = "Restablecer",
                FlatStyle = WinForms.FlatStyle.Flat,
                Cursor = WinForms.Cursors.Hand
            };
            btnRestablecerTramo.FlatAppearance.BorderColor = Drawing.Color.Silver;
            btnRestablecerTramo.Click += BtnRestablecerTramo_Click;

            // Controles legacy no visibles para poder leer datas antiguas sin
            // conservar el segundo estribo central automático en la interfaz.
            chkCrearEstriboCentral = new WinForms.CheckBox
            {
                Checked = false,
                Visible = false,
                Enabled = false
            };
            lblRetiroEstriboCentral = new WinForms.Label
            {
                Visible = false
            };
            txtRetiroLateralEstriboCentral = new WinForms.TextBox
            {
                Text = "0",
                Visible = false,
                Enabled = false
            };
            lblCmRetiroEstriboCentral = new WinForms.Label
            {
                Visible = false
            };

            grpGeneral.Controls.Add(lblTipo);
            grpGeneral.Controls.Add(cmbTipoEstribo);
            grpGeneral.Controls.Add(lblRec);
            grpGeneral.Controls.Add(txtRecubrimiento);
            grpGeneral.Controls.Add(lblCm);
            grpGeneral.Controls.Add(btnCopiarAlResto);
            grpGeneral.Controls.Add(btnRestablecerTramo);

            if (chkCrearEstriboCentral != null)
            {
                chkCrearEstriboCentral.Checked = false;
                chkCrearEstriboCentral.Visible = false;
            }
            if (lblRetiroEstriboCentral != null)
                lblRetiroEstriboCentral.Visible = false;
            if (txtRetiroLateralEstriboCentral != null)
                txtRetiroLateralEstriboCentral.Visible = false;
            if (lblCmRetiroEstriboCentral != null)
                lblCmRetiroEstriboCentral.Visible = false;

            ActualizarEstadoEstriboCentralMYG();

            this.Controls.Add(grpGeneral);
            this.Controls.Add(lblFormaEstribo);
            this.Controls.Add(cmbFormaEstribo);
            this.Controls.Add(chkDetectarFormaAutomaticamente);

            // El selector visual ahora vive en AceroVigasMainForm.
            // Estos controles quedan ocultos para compatibilidad interna.
            lblFormaEstribo.Visible = false;
            cmbFormaEstribo.Visible = false;
            chkDetectarFormaAutomaticamente.Visible = false;
        }

        private void ActualizarEstadoEstriboCentralMYG()
        {
            if (chkCrearEstriboCentral != null)
            {
                chkCrearEstriboCentral.Checked = false;
                chkCrearEstriboCentral.Visible = false;
                chkCrearEstriboCentral.Enabled = false;
            }

            if (txtRetiroLateralEstriboCentral != null)
            {
                txtRetiroLateralEstriboCentral.Text = "0";
                txtRetiroLateralEstriboCentral.Visible = false;
                txtRetiroLateralEstriboCentral.Enabled = false;
            }

            if (lblRetiroEstriboCentral != null)
                lblRetiroEstriboCentral.Visible = false;

            if (lblCmRetiroEstriboCentral != null)
                lblCmRetiroEstriboCentral.Visible = false;

            ActualizarEstadoBotonAplicarTipoSeleccionV8();
        }

        private void RefrescarComboFormaEstribo()
        {
            if (cmbFormaEstribo == null)
                return;

            try
            {
                cmbFormaEstribo.Invalidate();
                cmbFormaEstribo.Refresh();
                cmbFormaEstribo.Update();
            }
            catch
            {
                // No se interrumpe la ventana si WinForms no puede refrescar en ese instante.
            }
        }

        private void CmbFormaEstribo_DrawItem(
            object sender,
            WinForms.DrawItemEventArgs e)
        {
            if (cmbFormaEstribo == null || cmbFormaEstribo.Items.Count == 0)
                return;

            int index = e.Index;

            // En algunos repintados del área cerrada, WinForms puede mandar -1.
            // En ese caso se usa el SelectedIndex real.
            if (index < 0)
                index = cmbFormaEstribo.SelectedIndex;

            if (index < 0 || index >= cmbFormaEstribo.Items.Count)
                return;

            e.DrawBackground();

            TipoFormaEstriboItem item = cmbFormaEstribo.Items[index] as TipoFormaEstriboItem;

            if (item == null)
                return;

            bool seleccionado =
                index == cmbFormaEstribo.SelectedIndex ||
                (e.State & WinForms.DrawItemState.Selected) == WinForms.DrawItemState.Selected;

            Drawing.Color fondo = seleccionado
                ? Drawing.Color.FromArgb(220, 235, 252)
                : Drawing.Color.White;

            using (Drawing.Brush brFondo = new Drawing.SolidBrush(fondo))
                e.Graphics.FillRectangle(brFondo, e.Bounds);

            // El combo muestra solo la imagen, sin texto.
            Drawing.Rectangle iconRect = new Drawing.Rectangle(
                e.Bounds.Left + 8,
                e.Bounds.Top + 5,
                Math.Max(36, e.Bounds.Width - 16),
                Math.Max(34, e.Bounds.Height - 10));

            DibujarIconoFormaEstribo(
                e.Graphics,
                iconRect,
                item.Tipo,
                seleccionado);

            if (cmbFormaEstribo.Enabled)
                e.DrawFocusRectangle();
        }

        private void CargarImagenesFormaEstribo()
        {
            // El flujo nuevo no depende de archivos PNG. Los controles heredados
            // se conservan únicamente para compatibilidad con la detección
            // automática anterior, pero cualquier representación se dibuja por
            // código y el usuario trabaja desde el editor 2D de sección real.
            imgFormaRectangular = null;
            imgFormaCumbrera = null;
        }

        private Drawing.Image CargarImagenIcono(string nombreArchivo)
        {
            // Compatibilidad binaria: el método permanece, pero no se cargan PNG.
            return null;
        }

        private string BuscarRutaIconoForma(string nombreArchivo)
        {
            if (string.IsNullOrWhiteSpace(nombreArchivo))
                return null;

            List<string> candidatos = new List<string>();

            try
            {
                string assemblyPath = Assembly.GetExecutingAssembly().Location;
                string folder = System.IO.Path.GetDirectoryName(assemblyPath);

                if (!string.IsNullOrWhiteSpace(folder))
                {
                    candidatos.Add(System.IO.Path.Combine(folder, "iconos", nombreArchivo));
                    candidatos.Add(System.IO.Path.Combine(folder, nombreArchivo));
                }
            }
            catch
            {
            }

            try
            {
                string programData = Environment.GetFolderPath(
                    Environment.SpecialFolder.CommonApplicationData);

                if (!string.IsNullOrWhiteSpace(programData))
                {
                    candidatos.Add(System.IO.Path.Combine(
                        programData,
                        "Autodesk",
                        "Revit",
                        "Addins",
                        "2027",
                        "MYG",
                        "iconos",
                        nombreArchivo));
                }
            }
            catch
            {
            }

            foreach (string ruta in candidatos)
            {
                try
                {
                    if (!string.IsNullOrWhiteSpace(ruta) &&
                        System.IO.File.Exists(ruta))
                        return ruta;
                }
                catch
                {
                }
            }

            return null;
        }

        private void DibujarIconoFormaEstribo(
            Drawing.Graphics g,
            Drawing.Rectangle r,
            TipoFormaEstribo tipo,
            bool seleccionado)
        {
            Drawing.Image img = tipo == TipoFormaEstribo.Cumbrera
                ? imgFormaCumbrera
                : imgFormaRectangular;

            if (img == null)
            {
                DibujarMiniaturaFormaEstribo(g, r, tipo, seleccionado);
                return;
            }

            System.Drawing.Drawing2D.InterpolationMode oldInterpolation = g.InterpolationMode;
            System.Drawing.Drawing2D.SmoothingMode oldSmoothing = g.SmoothingMode;
            System.Drawing.Drawing2D.PixelOffsetMode oldPixel = g.PixelOffsetMode;

            try
            {
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;

                using (Drawing.Brush br = new Drawing.SolidBrush(Drawing.Color.White))
                    g.FillRectangle(br, r);

                Drawing.Rectangle destino = AjustarImagenEnRectangulo(img, r);
                g.DrawImage(img, destino);
            }
            finally
            {
                g.InterpolationMode = oldInterpolation;
                g.SmoothingMode = oldSmoothing;
                g.PixelOffsetMode = oldPixel;
            }
        }

        private Drawing.Rectangle AjustarImagenEnRectangulo(
            Drawing.Image img,
            Drawing.Rectangle r)
        {
            if (img == null || r.Width <= 0 || r.Height <= 0)
                return r;

            double ratioImg = (double)img.Width / Math.Max(1, img.Height);
            double ratioRect = (double)r.Width / Math.Max(1, r.Height);

            int w;
            int h;

            if (ratioImg > ratioRect)
            {
                w = r.Width;
                h = (int)Math.Round(w / ratioImg);
            }
            else
            {
                h = r.Height;
                w = (int)Math.Round(h * ratioImg);
            }

            int x = r.Left + (r.Width - w) / 2;
            int y = r.Top + (r.Height - h) / 2;

            return new Drawing.Rectangle(x, y, w, h);
        }

        private void DibujarMiniaturaFormaEstribo(
            Drawing.Graphics g,
            Drawing.Rectangle r,
            TipoFormaEstribo tipo,
            bool seleccionado)
        {
            if (g == null)
                return;

            System.Drawing.Drawing2D.SmoothingMode oldMode = g.SmoothingMode;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            try
            {
                using (Drawing.Brush br = new Drawing.SolidBrush(Drawing.Color.FromArgb(245, 248, 252)))
                using (Drawing.Pen penBorde = new Drawing.Pen(Drawing.Color.FromArgb(170, 190, 210), 1.0f))
                {
                    g.FillRectangle(br, r);
                    g.DrawRectangle(penBorde, r);
                }

                Drawing.Rectangle rr = new Drawing.Rectangle(
                    r.Left + 8,
                    r.Top + 6,
                    Math.Max(10, r.Width - 16),
                    Math.Max(10, r.Height - 12));

                using (Drawing.Pen penRojo = new Drawing.Pen(Drawing.Color.FromArgb(235, 0, 0), 2.0f))
                using (Drawing.Pen penAzul = new Drawing.Pen(Drawing.Color.FromArgb(0, 80, 210), 2.0f))
                using (Drawing.Pen penGris = new Drawing.Pen(Drawing.Color.FromArgb(110, 110, 110), 1.0f))
                {
                    if (tipo == TipoFormaEstribo.Cumbrera)
                    {
                        // Miniatura de dos estribos entrelazados para viga cumbrera.
                        int yMedio = rr.Left + rr.Width / 2;

                        Drawing.Point pLi = new Drawing.Point(rr.Left, rr.Top + (int)(rr.Height * 0.72));
                        Drawing.Point pLs = new Drawing.Point(rr.Left, rr.Top + (int)(rr.Height * 0.36));
                        Drawing.Point pCsup = new Drawing.Point(yMedio, rr.Top + 2);
                        Drawing.Point pCinf = new Drawing.Point(yMedio, rr.Bottom - 2);
                        Drawing.Point pRs = new Drawing.Point(rr.Right, rr.Top + (int)(rr.Height * 0.36));
                        Drawing.Point pRi = new Drawing.Point(rr.Right, rr.Top + (int)(rr.Height * 0.72));

                        Drawing.Point[] estriboIzq = new Drawing.Point[]
                        {
                            pLi,
                            pLs,
                            pCsup,
                            pCinf
                        };

                        Drawing.Point[] estriboDer = new Drawing.Point[]
                        {
                            pCinf,
                            pCsup,
                            pRs,
                            pRi
                        };

                        g.DrawPolygon(penRojo, estriboIzq);
                        g.DrawPolygon(penAzul, estriboDer);

                        // Pequeña línea central de referencia para que se entienda el traslape.
                        g.DrawLine(penGris, yMedio, rr.Top + 1, yMedio, rr.Bottom - 1);
                    }
                    else
                    {
                        // Miniatura simple de estribo rectangular.
                        g.DrawRectangle(penRojo, rr);
                    }
                }
            }
            finally
            {
                g.SmoothingMode = oldMode;
            }
        }

        private void CrearGrupoTramo()
        {
            grpTramo = new WinForms.GroupBox()
            {
                Text = "Configuración del tramo seleccionado",
                Left = 20,
                Top = 172,
                Width = 820,
                Height = 212,
                Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50),
                BackColor = Drawing.Color.FromArgb(245, 247, 250)
            };

            lblTramoActual = new WinForms.Label()
            {
                Left = 18,
                Top = 27,
                Width = 250,
                Height = 20,
                Text = "Tramo seleccionado: -",
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold)
            };

            lblLuzActual = new WinForms.Label()
            {
                Left = 280,
                Top = 27,
                Width = 220,
                Height = 20,
                Text = "Luz libre: -",
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold)
            };

            WinForms.Label lblTipo = new WinForms.Label()
            {
                Left = 18,
                Top = 58,
                Width = 125,
                Height = 22,
                Text = "Tipo distribución:",
                Font = new Drawing.Font("Segoe UI", 8.5F)
            };

            cboTipoDistribucion = new WinForms.ComboBox()
            {
                Left = 145,
                Top = 55,
                Width = 285,
                Height = 24,
                DropDownStyle = WinForms.ComboBoxStyle.DropDownList
            };

            cboTipoDistribucion.Items.Add("1. Separación constante de los estribos");
            cboTipoDistribucion.Items.Add("2. Dos tramos de espaciado");
            cboTipoDistribucion.Items.Add("3. Tres tramos de espaciado");
            cboTipoDistribucion.Items.Add("4. Cuatro tramos de espaciado");
            cboTipoDistribucion.SelectedIndexChanged += CboTipoDistribucion_SelectedIndexChanged;

            lblResumenOcupacion = new WinForms.Label()
            {
                Left = 450,
                Top = 58,
                Width = 330,
                Height = 22,
                Text = "Longitud ocupada: -",
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(70, 70, 70)
            };

            panelFilasDistribucion = new WinForms.Panel()
            {
                Left = 18,
                Top = 90,
                Width = 780,
                Height = 92,
                BorderStyle = WinForms.BorderStyle.None
            };

            CrearFilasDistribucion();

            lblMensaje = new WinForms.Label()
            {
                Left = 18,
                Top = 182,
                Width = 780,
                Height = 24,
                Text = "Seleccione vigas en la primera pestaña y luego seleccione un tramo.",
                Font = new Drawing.Font("Segoe UI", 8.3F),
                ForeColor = Drawing.Color.Gray
            };

            grpTramo.Controls.Add(lblTramoActual);
            grpTramo.Controls.Add(lblLuzActual);
            grpTramo.Controls.Add(lblTipo);
            grpTramo.Controls.Add(cboTipoDistribucion);
            grpTramo.Controls.Add(lblResumenOcupacion);
            grpTramo.Controls.Add(panelFilasDistribucion);
            grpTramo.Controls.Add(lblMensaje);

            this.Controls.Add(grpTramo);
        }

        private void CrearFilasDistribucion()
        {
            for (int i = 0; i < 4; i++)
            {
                int y = i * 22;

                lblFila[i] = new WinForms.Label()
                {
                    Left = 0,
                    Top = y + 2,
                    Width = 72,
                    Height = 20,
                    Text = "Zona " + (i + 1),
                    Font = new Drawing.Font("Segoe UI", 8.5F)
                };

                lblSep[i] = new WinForms.Label()
                {
                    Left = 85,
                    Top = y + 2,
                    Width = 90,
                    Height = 20,
                    Text = "Separación:",
                    Font = new Drawing.Font("Segoe UI", 8.5F)
                };

                numSeparacionesCm[i] = new WinForms.NumericUpDown()
                {
                    Left = 180,
                    Top = y,
                    Width = 70,
                    Height = 22,
                    DecimalPlaces = 0,
                    Minimum = 1,
                    Maximum = 100,
                    Increment = 1,
                    TextAlign = WinForms.HorizontalAlignment.Center
                };
                numSeparacionesCm[i].ValueChanged += NumDistribucion_ValueChanged;

                WinForms.Label lblCm = new WinForms.Label()
                {
                    Left = 255,
                    Top = y + 2,
                    Width = 30,
                    Height = 20,
                    Text = "cm",
                    Font = new Drawing.Font("Segoe UI", 8.5F)
                };

                lblCant[i] = new WinForms.Label()
                {
                    Left = 315,
                    Top = y + 2,
                    Width = 125,
                    Height = 20,
                    Text = "Cantidad aceros:",
                    Font = new Drawing.Font("Segoe UI", 8.5F)
                };

                numCantidades[i] = new WinForms.NumericUpDown()
                {
                    Left = 445,
                    Top = y,
                    Width = 80,
                    Height = 22,
                    DecimalPlaces = 0,
                    Minimum = 1,
                    Maximum = 1000,
                    Increment = 1,
                    TextAlign = WinForms.HorizontalAlignment.Center
                };
                numCantidades[i].ValueChanged += NumDistribucion_ValueChanged;

                WinForms.Label lblUnd = new WinForms.Label()
                {
                    Left = 530,
                    Top = y + 2,
                    Width = 40,
                    Height = 20,
                    Text = "und.",
                    Font = new Drawing.Font("Segoe UI", 8.5F)
                };

                panelFilasDistribucion.Controls.Add(lblFila[i]);
                panelFilasDistribucion.Controls.Add(lblSep[i]);
                panelFilasDistribucion.Controls.Add(numSeparacionesCm[i]);
                panelFilasDistribucion.Controls.Add(lblCm);
                panelFilasDistribucion.Controls.Add(lblCant[i]);
                panelFilasDistribucion.Controls.Add(numCantidades[i]);
                panelFilasDistribucion.Controls.Add(lblUnd);
            }
        }

        private void CrearGrupoPreview()
        {
            grpPreview = new WinForms.GroupBox()
            {
                Text = "Vista preliminar de estribos por tramo",
                Left = 20,
                Top = 392,
                Width = 820,
                Height = 230,
                Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50),
                BackColor = Drawing.Color.FromArgb(245, 247, 250)
            };

            panelPreview = new VistaPreviaEstribosPanel()
            {
                Left = 12,
                Top = 24,
                Width = 794,
                Height = 190,
                BackColor = Drawing.Color.White,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                Anchor = WinForms.AnchorStyles.Top |
                         WinForms.AnchorStyles.Bottom |
                         WinForms.AnchorStyles.Left |
                         WinForms.AnchorStyles.Right
            };

            panelPreview.Owner = this;
            panelPreview.TramoSeleccionadoChanged += PanelPreview_TramoSeleccionadoChanged;

            grpPreview.Controls.Add(panelPreview);
            this.Controls.Add(grpPreview);
        }


        public void RefrescarVistaPreliminarEstribos()
        {
            try
            {
                if (panelPreview != null)
                    panelPreview.Invalidate();
            }
            catch
            {
            }
        }

        private void CrearBotonEjecutar()
        {
            btnGuardarData = new WinForms.Button()
            {
                Text = "GUARDAR DATA",
                Left = 170,
                Top = 685,
                Width = 130,
                Height = 36,
                BackColor = Drawing.Color.FromArgb(90, 98, 108),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand,
                Anchor = WinForms.AnchorStyles.Bottom
            };

            btnGuardarData.FlatAppearance.BorderSize = 0;
            btnGuardarData.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(70, 78, 88);
            btnGuardarData.Click += BtnGuardarData_Click;

            btnEjecutarEstribos = new WinForms.Button()
            {
                Text = "EJECUTAR ESTRIBOS",
                Left = 320,
                Top = 685,
                Width = 220,
                Height = 36,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand,
                Anchor = WinForms.AnchorStyles.Bottom
            };

            btnEjecutarEstribos.FlatAppearance.BorderSize = 0;
            btnEjecutarEstribos.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(0, 100, 190);
            btnEjecutarEstribos.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(0, 84, 160);
            btnEjecutarEstribos.Click += BtnEjecutarEstribos_Click;

            btnCargarData = new WinForms.Button()
            {
                Text = "CARGAR DATA",
                Left = 560,
                Top = 685,
                Width = 130,
                Height = 36,
                BackColor = Drawing.Color.FromArgb(90, 98, 108),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand,
                Anchor = WinForms.AnchorStyles.Bottom
            };

            btnCargarData.FlatAppearance.BorderSize = 0;
            btnCargarData.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(70, 78, 88);
            btnCargarData.Click += BtnCargarData_Click;

            this.Controls.Add(btnGuardarData);
            this.Controls.Add(btnEjecutarEstribos);
            this.Controls.Add(btnCargarData);
        }

        private void CrearPanelConfiguracionUnificada()
        {
            if (panelConfiguracionUnificada != null &&
                !panelConfiguracionUnificada.IsDisposed)
            {
                return;
            }

            panelConfiguracionUnificada = new WinForms.Panel
            {
                BackColor = Drawing.Color.White,
                BorderStyle = WinForms.BorderStyle.None,
                AutoScroll = true
            };

            this.Controls.Add(panelConfiguracionUnificada);

            WinForms.Control[] controles = new WinForms.Control[]
            {
                lblTitulo,
                lblDescripcion,
                grpGeneral,
                grpTramo,
                btnGuardarData,
                btnEjecutarEstribos,
                btnCargarData
            };

            foreach (WinForms.Control control in controles)
            {
                if (control == null || control.IsDisposed)
                    continue;

                if (control.Parent != null)
                    control.Parent.Controls.Remove(control);

                panelConfiguracionUnificada.Controls.Add(control);
            }

            panelConfiguracionUnificada.BringToFront();
            if (panelEditorSeccionIntegrado != null)
                panelEditorSeccionIntegrado.BringToFront();

            ConstruirFormatoExactoColumnasV8Estribos();
        }

        private void LimpiarPanelesEditorUnificado()
        {
            if (panelHerramientasEditorUnificado != null)
            {
                try
                {
                    if (panelConfiguracionUnificada != null)
                    {
                        panelConfiguracionUnificada.Controls.Remove(
                            panelHerramientasEditorUnificado);
                    }
                    panelHerramientasEditorUnificado.Dispose();
                }
                catch
                {
                }
                panelHerramientasEditorUnificado = null;
            }

            if (barraEdicionEditorUnificada != null)
            {
                try
                {
                    if (panelEditorSeccionIntegrado != null)
                    {
                        panelEditorSeccionIntegrado.Controls.Remove(
                            barraEdicionEditorUnificada);
                    }
                    barraEdicionEditorUnificada.Dispose();
                }
                catch
                {
                }
                barraEdicionEditorUnificada = null;
            }
        }

        private WinForms.Label CrearEtiquetaFormatoV8Estribos(
            string texto,
            int left,
            int top,
            int width)
        {
            return new WinForms.Label
            {
                Text = texto,
                Left = left,
                Top = top,
                Width = width,
                Height = 22,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(55, 55, 55)
            };
        }

        private void ReubicarControlFormatoV8Estribos(
            WinForms.Control control,
            WinForms.Control nuevoPadre,
            int left,
            int top,
            int width)
        {
            if (control == null || control.IsDisposed || nuevoPadre == null)
                return;

            if (control.Parent != null)
                control.Parent.Controls.Remove(control);

            control.Left = left;
            control.Top = top;
            control.Width = width;
            control.Visible = true;
            nuevoPadre.Controls.Add(control);
            control.BringToFront();
        }

        private void ConstruirFormatoExactoColumnasV8Estribos()
        {
            if (panelConfiguracionUnificada == null ||
                panelConfiguracionUnificada.IsDisposed)
            {
                return;
            }

            if (panelFormatoColumnasV8Estribos == null ||
                panelFormatoColumnasV8Estribos.IsDisposed)
            {
                panelFormatoColumnasV8Estribos = new WinForms.Panel
                {
                    BackColor = Drawing.Color.White,
                    BorderStyle = WinForms.BorderStyle.FixedSingle,
                    AutoScroll = false
                };
                panelConfiguracionUnificada.Controls.Add(
                    panelFormatoColumnasV8Estribos);

                chkCrearEstribosV8 = new WinForms.CheckBox
                {
                    Text = "Crear estribos",
                    Left = 18,
                    Top = 14,
                    Width = 230,
                    Height = 25,
                    Checked = true,
                    Font = new Drawing.Font(
                        "Segoe UI",
                        9F,
                        Drawing.FontStyle.Bold)
                };
                chkCrearEstribosV8.CheckedChanged += (s, e) =>
                {
                    bool activo = chkCrearEstribosV8.Checked;
                    if (panelHerramientasEditorUnificado != null)
                        panelHerramientasEditorUnificado.Enabled = activo;
                    if (panelEditorSeccionIntegrado != null)
                        panelEditorSeccionIntegrado.Enabled = activo;
                    if (btnEjecutarEstribos != null)
                        btnEjecutarEstribos.Enabled = activo;

                    ActualizarEstadoBotonAplicarTipoSeleccionV8();
                };
                panelFormatoColumnasV8Estribos.Controls.Add(chkCrearEstribosV8);

                btnAplicarTipoSeleccionV8 = new WinForms.Button
                {
                    Text = "APLICAR",
                    Left = 332,
                    Top = 48,
                    Width = 82,
                    Height = 25,
                    Enabled = false,
                    FlatStyle = WinForms.FlatStyle.Flat,
                    BackColor = Drawing.Color.FromArgb(225, 229, 234),
                    ForeColor = Drawing.Color.FromArgb(120, 120, 120),
                    Font = new Drawing.Font(
                        "Segoe UI",
                        8.1F,
                        Drawing.FontStyle.Bold),
                    TextAlign = Drawing.ContentAlignment.MiddleCenter,
                    UseVisualStyleBackColor = false
                };
                btnAplicarTipoSeleccionV8.FlatAppearance.BorderColor =
                    Drawing.Color.FromArgb(175, 183, 192);
                btnAplicarTipoSeleccionV8.Click += (s, e) =>
                {
                    if (editorSeccionIntegrado == null ||
                        editorSeccionIntegrado.IsDisposed ||
                        !editorSeccionIntegrado.TieneSeleccionParaCambiarTipo)
                    {
                        ActualizarEstadoBotonAplicarTipoSeleccionV8();
                        return;
                    }

                    editorSeccionIntegrado
                        .AplicarTipoActualASeleccionDesdePestana();
                    ActualizarEstadoBotonAplicarTipoSeleccionV8();
                };
                panelFormatoColumnasV8Estribos.Controls.Add(
                    btnAplicarTipoSeleccionV8);

                panelFormatoColumnasV8Estribos.Controls.Add(
                    CrearEtiquetaFormatoV8Estribos(
                        "Tipo de barra:", 18, 51, 145));
                panelFormatoColumnasV8Estribos.Controls.Add(
                    CrearEtiquetaFormatoV8Estribos(
                        "Recubrimiento:", 18, 84, 145));
                panelFormatoColumnasV8Estribos.Controls.Add(
                    CrearEtiquetaFormatoV8Estribos(
                        "Tipo distribución:", 18, 117, 145));

                panelFormatoColumnasV8Estribos.Controls.Add(
                    new WinForms.Label
                    {
                        Text = "cm",
                        Left = 238,
                        Top = 84,
                        Width = 35,
                        Height = 22,
                        ForeColor = Drawing.Color.Gray
                    });

                WinForms.Label lblTramo = new WinForms.Label
                {
                    Text = "DISTRIBUCIÓN DEL TRAMO SELECCIONADO",
                    Left = 18,
                    Top = 151,
                    Width = 396,
                    Height = 22,
                    Font = new Drawing.Font(
                        "Segoe UI",
                        8.4F,
                        Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(0, 90, 160)
                };
                panelFormatoColumnasV8Estribos.Controls.Add(lblTramo);

                for (int i = 0; i < 4; i++)
                {
                    int y = 178 + i * 28;
                    string texto = i < 3
                        ? "Zona " + (i + 1).ToString() + ":"
                        : "RESTO:";

                    panelFormatoColumnasV8Estribos.Controls.Add(
                        new WinForms.Label
                        {
                            Text = texto,
                            Left = 18,
                            Top = y + 3,
                            Width = 68,
                            Height = 20,
                            Font = new Drawing.Font("Segoe UI", 8F)
                        });
                    panelFormatoColumnasV8Estribos.Controls.Add(
                        new WinForms.Label
                        {
                            Text = "Sep.:",
                            Left = 88,
                            Top = y + 3,
                            Width = 42,
                            Height = 20,
                            Font = new Drawing.Font("Segoe UI", 8F)
                        });
                    panelFormatoColumnasV8Estribos.Controls.Add(
                        new WinForms.Label
                        {
                            Text = "cm",
                            Left = 193,
                            Top = y + 3,
                            Width = 28,
                            Height = 20,
                            ForeColor = Drawing.Color.Gray
                        });
                    panelFormatoColumnasV8Estribos.Controls.Add(
                        new WinForms.Label
                        {
                            Text = "Cant.:",
                            Left = 228,
                            Top = y + 3,
                            Width = 42,
                            Height = 20,
                            Font = new Drawing.Font("Segoe UI", 8F)
                        });
                    panelFormatoColumnasV8Estribos.Controls.Add(
                        new WinForms.Label
                        {
                            Text = "und.",
                            Left = 338,
                            Top = y + 3,
                            Width = 38,
                            Height = 20,
                            ForeColor = Drawing.Color.Gray
                        });
                }

                lblAyudaFormatoV8Estribos = new WinForms.Label
                {
                    Text = "SECCIÓN LIMPIA: cree el estribo con RECTÁNGULO, " +
                           "ADAPTAR CONTORNO, CROQUIS LIBRE u otra herramienta. " +
                           "El OSNAP respeta la herramienta activa.",
                    Left = 18,
                    Top = 493,
                    Width = 396,
                    Height = 42,
                    Font = new Drawing.Font("Segoe UI", 8.1F),
                    ForeColor = Drawing.Color.FromArgb(75, 75, 75)
                };
                panelFormatoColumnasV8Estribos.Controls.Add(
                    lblAyudaFormatoV8Estribos);
            }

            ReubicarControlFormatoV8Estribos(
                cmbTipoEstribo,
                panelFormatoColumnasV8Estribos,
                168,
                48,
                158);

            if (btnAplicarTipoSeleccionV8 != null &&
                !btnAplicarTipoSeleccionV8.IsDisposed)
            {
                btnAplicarTipoSeleccionV8.SetBounds(332, 48, 82, 25);
                btnAplicarTipoSeleccionV8.BringToFront();
            }
            ReubicarControlFormatoV8Estribos(
                txtRecubrimiento,
                panelFormatoColumnasV8Estribos,
                168,
                81,
                62);
            ReubicarControlFormatoV8Estribos(
                cboTipoDistribucion,
                panelFormatoColumnasV8Estribos,
                168,
                114,
                246);

            for (int i = 0; i < 4; i++)
            {
                int y = 178 + i * 28;
                ReubicarControlFormatoV8Estribos(
                    numSeparacionesCm[i],
                    panelFormatoColumnasV8Estribos,
                    132,
                    y,
                    58);
                ReubicarControlFormatoV8Estribos(
                    numCantidades[i],
                    panelFormatoColumnasV8Estribos,
                    273,
                    y,
                    62);
            }

            if (panelHerramientasEditorUnificado != null &&
                !panelHerramientasEditorUnificado.IsDisposed)
            {
                if (panelHerramientasEditorUnificado.Parent !=
                    panelFormatoColumnasV8Estribos)
                {
                    if (panelHerramientasEditorUnificado.Parent != null)
                    {
                        panelHerramientasEditorUnificado.Parent.Controls.Remove(
                            panelHerramientasEditorUnificado);
                    }
                    panelFormatoColumnasV8Estribos.Controls.Add(
                        panelHerramientasEditorUnificado);
                }

                panelHerramientasEditorUnificado.Left = 10;
                panelHerramientasEditorUnificado.Top = 299;
                panelHerramientasEditorUnificado.Width = Math.Max(396, panelConfiguracionUnificada.ClientSize.Width - 20);
                panelHerramientasEditorUnificado.Height = 188;
                panelHerramientasEditorUnificado.BringToFront();
            }

            // El estribo central automático se elimina de la interfaz V8.
            if (chkCrearEstriboCentral != null)
            {
                chkCrearEstriboCentral.Checked = false;
                chkCrearEstriboCentral.Visible = false;
            }
            if (lblRetiroEstriboCentral != null)
                lblRetiroEstriboCentral.Visible = false;
            if (txtRetiroLateralEstriboCentral != null)
                txtRetiroLateralEstriboCentral.Visible = false;
            if (lblCmRetiroEstriboCentral != null)
                lblCmRetiroEstriboCentral.Visible = false;
        }

        private void EditorSeccionIntegrado_EstadoSeleccionTipoCambiado(
            object sender,
            EventArgs e)
        {
            if (editorSeccionIntegrado != null &&
                !editorSeccionIntegrado.IsDisposed &&
                editorSeccionIntegrado.TieneSeleccionParaCambiarTipo)
            {
                RebarBarType tipoSeleccionado =
                    editorSeccionIntegrado.TipoBarraDeSeleccionActual;

                SeleccionarTipoEstriboEnComboV8(tipoSeleccionado);
            }

            ActualizarEstadoBotonAplicarTipoSeleccionV8();
        }

        private void SeleccionarTipoEstriboEnComboV8(RebarBarType tipo)
        {
            if (tipo == null || cmbTipoEstribo == null)
                return;

            for (int i = 0; i < cmbTipoEstribo.Items.Count; i++)
            {
                RebarBarType item =
                    cmbTipoEstribo.Items[i] as RebarBarType;

                if (item == null)
                    continue;

                bool mismo = false;
                try
                {
                    mismo = item.Id == tipo.Id;
                }
                catch
                {
                    mismo = object.ReferenceEquals(item, tipo);
                }

                if (mismo)
                {
                    cmbTipoEstribo.SelectedIndex = i;
                    return;
                }
            }
        }

        private void ActualizarEstadoBotonAplicarTipoSeleccionV8()
        {
            if (btnAplicarTipoSeleccionV8 == null ||
                btnAplicarTipoSeleccionV8.IsDisposed)
            {
                return;
            }

            bool habilitado =
                chkCrearEstribosV8 != null &&
                chkCrearEstribosV8.Checked &&
                editorSeccionIntegrado != null &&
                !editorSeccionIntegrado.IsDisposed &&
                editorSeccionIntegrado.TieneSeleccionParaCambiarTipo;

            btnAplicarTipoSeleccionV8.Enabled = habilitado;
            btnAplicarTipoSeleccionV8.BackColor = habilitado
                ? Drawing.Color.FromArgb(0, 120, 215)
                : Drawing.Color.FromArgb(225, 229, 234);
            btnAplicarTipoSeleccionV8.ForeColor = habilitado
                ? Drawing.Color.White
                : Drawing.Color.FromArgb(120, 120, 120);
            btnAplicarTipoSeleccionV8.FlatAppearance.BorderColor = habilitado
                ? Drawing.Color.FromArgb(0, 95, 175)
                : Drawing.Color.FromArgb(175, 183, 192);
        }

        private void AjustarLayout()
        {
            int anchoTotal = Math.Max(1045, this.ClientSize.Width);
            int altoTotal = Math.Max(555, this.ClientSize.Height);
            const int margen = 8;
            const int anchoIzquierdo = 440;
            const int separacion = 8;

            if (panelConfiguracionUnificada != null)
            {
                panelConfiguracionUnificada.SetBounds(
                    margen,
                    margen,
                    anchoIzquierdo,
                    Math.Max(535, altoTotal - margen * 2));
                panelConfiguracionUnificada.AutoScroll = false;
            }

            int leftVista = margen + anchoIzquierdo + separacion;
            if (panelEditorSeccionIntegrado != null)
            {
                panelEditorSeccionIntegrado.SetBounds(
                    leftVista,
                    margen,
                    Math.Max(570, anchoTotal - leftVista - margen),
                    Math.Max(535, altoTotal - margen * 2));
                panelEditorSeccionIntegrado.BringToFront();
            }

            if (lblTitulo != null) lblTitulo.Visible = false;
            if (lblDescripcion != null) lblDescripcion.Visible = false;
            if (grpGeneral != null) grpGeneral.Visible = false;
            if (grpTramo != null) grpTramo.Visible = false;
            if (grpPreview != null) grpPreview.Visible = false;

            ConstruirFormatoExactoColumnasV8Estribos();

            if (panelFormatoColumnasV8Estribos != null)
            {
                panelFormatoColumnasV8Estribos.SetBounds(
                    0,
                    0,
                    anchoIzquierdo,
                    Math.Max(535, panelConfiguracionUnificada.ClientSize.Height));
                panelFormatoColumnasV8Estribos.BringToFront();
            }

            // Acciones principales en la franja inferior, conservando la lógica
            // original de guardar, ejecutar y cargar configuraciones por tramo.
            if (panelFormatoColumnasV8Estribos != null)
            {
                WinForms.Button[] botones = new WinForms.Button[]
                {
                    btnGuardarData,
                    btnEjecutarEstribos,
                    btnCargarData
                };

                foreach (WinForms.Button boton in botones)
                {
                    if (boton == null || boton.IsDisposed)
                        continue;
                    if (boton.Parent != panelFormatoColumnasV8Estribos)
                    {
                        if (boton.Parent != null)
                            boton.Parent.Controls.Remove(boton);
                        panelFormatoColumnasV8Estribos.Controls.Add(boton);
                    }
                    boton.Visible = true;
                    boton.Anchor = WinForms.AnchorStyles.None;
                }

                if (btnGuardarData != null)
                {
                    btnGuardarData.SetBounds(18, 505, 105, 32);
                    btnGuardarData.Text = "GUARDAR";
                }
                if (btnEjecutarEstribos != null)
                {
                    btnEjecutarEstribos.SetBounds(128, 505, 178, 32);
                    btnEjecutarEstribos.Text = "EJECUTAR ESTRIBOS";
                }
                if (btnCargarData != null)
                {
                    btnCargarData.SetBounds(311, 505, 105, 32);
                    btnCargarData.Text = "CARGAR";
                }

                if (lblAyudaFormatoV8Estribos != null)
                {
                    lblAyudaFormatoV8Estribos.Top = 482;
                    lblAyudaFormatoV8Estribos.Height = 20;
                    lblAyudaFormatoV8Estribos.Width = 396;
                }
            }
        }


        // =====================================
        // DETECCIÓN AUTOMÁTICA DE FORMA DE ESTRIBO
        // =====================================
        private void DetectarYAplicarFormaEstriboAutomaticamente()
        {
            if (chkDetectarFormaAutomaticamente == null ||
                !chkDetectarFormaAutomaticamente.Checked)
                return;

            if (cmbFormaEstribo == null || cmbFormaEstribo.Items.Count == 0)
                return;

            // La detección prioriza la sección transversal real del elemento.
            // Si por alguna razón no se puede leer la geometría de Revit,
            // recién usa la información de la vista preliminar como respaldo.
            TipoFormaEstribo tipoDetectado = DetectarFormaEstriboPorTramoActual();
            formaEstriboDesdeMain = tipoDetectado;

            try
            {
                FormaDetectadaAutomaticamenteChanged?.Invoke(tipoDetectado);
            }
            catch
            {
            }

            bloqueandoCambioFormaEstribo = true;

            try
            {
                // Se habilita temporalmente solo para asegurar que WinForms acepte
                // el SelectedIndex y repinte la miniatura antes de bloquear la lista.
                cmbFormaEstribo.Enabled = true;
                SeleccionarFormaEstribo(tipoDetectado);
            }
            finally
            {
                bloqueandoCambioFormaEstribo = false;
            }

            RefrescarComboFormaEstribo();
            ActualizarBloqueoComboFormaEstribo();

            if (panelPreview != null)
                panelPreview.Invalidate();
        }

        private void ActualizarBloqueoComboFormaEstribo()
        {
            if (cmbFormaEstribo == null)
                return;

            bool automatico = chkDetectarFormaAutomaticamente != null &&
                              chkDetectarFormaAutomaticamente.Checked;

            // Cuando está activo "Detectar automáticamente",
            // la lista queda realmente BLOQUEADA.
            // Primero la forma se selecciona por código y luego se deshabilita.
            cmbFormaEstribo.Enabled = !automatico;
            cmbFormaEstribo.TabStop = !automatico;
            cmbFormaEstribo.Cursor = automatico
                ? WinForms.Cursors.No
                : WinForms.Cursors.Hand;

            RefrescarComboFormaEstribo();
        }

        public void ConectarDeteccionAutomaticaForma(
            UIDocument uidoc,
            SeleccionarVigasAceroLongitudinalHandler seleccionHandler)
        {
            UiDocFormaAutomatico = uidoc;
            SeleccionHandlerFormaAutomatico = seleccionHandler;

            DetectarYAplicarFormaEstriboAutomaticamente();
        }

        public void ConectarDetectorFormaDesdeHandler(
            EjecutarEstribosVigasHandler handler)
        {
            handlerDeteccionFormaAutomatico = handler;

            if (handler != null)
            {
                try
                {
                    if (handler.UiDoc != null)
                        UiDocFormaAutomatico = handler.UiDoc;

                    if (handler.SeleccionHandler != null)
                        SeleccionHandlerFormaAutomatico = handler.SeleccionHandler;
                }
                catch
                {
                }
            }

            DetectarYAplicarFormaEstriboAutomaticamente();
        }

        public void AplicarFormaEstriboDetectadaDesdeHandler(TipoFormaEstribo tipo)
        {
            formaDetectadaDesdeHandler = tipo;
            formaEstriboDesdeMain = tipo;

            try
            {
                FormaDetectadaAutomaticamenteChanged?.Invoke(tipo);
            }
            catch
            {
            }

            if (cmbFormaEstribo == null || cmbFormaEstribo.Items.Count == 0)
                return;

            if (chkDetectarFormaAutomaticamente == null ||
                !chkDetectarFormaAutomaticamente.Checked)
            {
                RefrescarComboFormaEstribo();
                return;
            }

            bloqueandoCambioFormaEstribo = true;

            try
            {
                cmbFormaEstribo.Enabled = true;
                SeleccionarFormaEstribo(tipo);
                RefrescarComboFormaEstribo();
            }
            finally
            {
                bloqueandoCambioFormaEstribo = false;
                ActualizarBloqueoComboFormaEstribo();
            }

            if (panelPreview != null)
                panelPreview.Invalidate();
        }

        private bool TryDetectarFormaDesdeHandler(out TipoFormaEstribo tipo)
        {
            tipo = TipoFormaEstribo.Rectangular;

            if (handlerDeteccionFormaAutomatico == null)
                return false;

            try
            {
                return handlerDeteccionFormaAutomatico.DetectarFormaActualDesdeSeleccion(out tipo);
            }
            catch
            {
                tipo = TipoFormaEstribo.Rectangular;
                return false;
            }
        }

        private TipoFormaEstribo DetectarFormaEstriboPorTramoActual()
        {
            // PRIORIDAD 1: usar la detección del handler de ejecución.
            // Así la miniatura de la ventana y la geometría que se ejecuta
            // salen de la misma lógica.
            TipoFormaEstribo tipoHandler;
            if (TryDetectarFormaDesdeHandler(out tipoHandler))
            {
                formaDetectadaDesdeHandler = tipoHandler;
                return tipoHandler;
            }

            // PRIORIDAD 2: usar el último valor enviado por el handler.
            if (formaDetectadaDesdeHandler.HasValue)
                return formaDetectadaDesdeHandler.Value;

            // RESPALDO: detección propia de la ventana.
            TipoFormaEstribo? detectadoPorGeometria =
                DetectarFormaEstriboPorGeometriaRevit();

            if (detectadoPorGeometria.HasValue)
                return detectadoPorGeometria.Value;

            VigaLongitudinalPreview viga = ObtenerVigaPreviewParaTramoActual();

            if (viga == null)
                return TipoFormaEstribo.Rectangular;

            return EsVigaPreviewCumbreraReal(viga)
                ? TipoFormaEstribo.Cumbrera
                : TipoFormaEstribo.Rectangular;
        }

        private TipoFormaEstribo? DetectarFormaEstriboPorGeometriaRevit()
        {
            Element elemento = ObtenerElementoRevitParaTramoActual();

            if (elemento == null)
                return null;

            bool esCumbrera;

            if (!TryDetectarCumbreraPorSeccionTransversal(elemento, out esCumbrera))
                return null;

            return esCumbrera
                ? TipoFormaEstribo.Cumbrera
                : TipoFormaEstribo.Rectangular;
        }

        private bool EsVigaPreviewCumbreraReal(VigaLongitudinalPreview viga)
        {
            if (viga == null)
                return false;

            // Respaldo por datos del preview. No se usa EsInclinada, AnguloGrados
            // ni DeltaZMm porque una viga rectangular inclinada sigue siendo rectangular.
            if (LeerBoolPropiedad(viga, "TienePerfilSeccionVariableTransversal"))
                return true;

            if (LeerBoolPropiedad(viga, "TienePerfilSeccionVariable"))
                return true;

            int puntosPerfilSuperior = ObtenerCantidadListaPropiedad(viga, "PerfilSuperiorMm");
            int puntosPerfilInferior = ObtenerCantidadListaPropiedad(viga, "PerfilInferiorMm");

            if (puntosPerfilSuperior > 2 || puntosPerfilInferior > 2)
                return true;

            return false;
        }

        private Element ObtenerElementoRevitParaTramoActual()
        {
            Document doc = ObtenerDocumentoRevitFormaAutomatica();
            int index = tramoSeleccionado < 0 ? 0 : tramoSeleccionado;

            // 1) Ruta directa recomendada: handler de selección conectado desde el comando.
            Element desdeHandler = ObtenerElementoDesdeSeleccionHandler(
                SeleccionHandlerFormaAutomatico,
                doc,
                index);

            if (desdeHandler != null)
                return desdeHandler;

            // 2) Intentar leer el elemento o ElementId desde el objeto preview.
            VigaLongitudinalPreview preview = ObtenerVigaPreviewParaTramoActual();
            Element desdePreview = LeerElementoDesdeObjeto(preview, doc);

            if (desdePreview != null)
                return desdePreview;

            // 3) Intentar encontrar un handler de selección dentro de la ventana longitudinal.
            object handlerDesdeVentana = BuscarObjetoConVigasSeleccionadas(ventanaLongitudinalOrigen);
            Element desdeHandlerReflexion = ObtenerElementoDesdeObjetoConVigasSeleccionadas(
                handlerDesdeVentana,
                doc,
                index);

            if (desdeHandlerReflexion != null)
                return desdeHandlerReflexion;

            // 4) Último respaldo: buscar listas de Element o ElementId dentro de la ventana.
            Element desdeVentana = BuscarElementoEnObjetoPorIndice(
                ventanaLongitudinalOrigen,
                doc,
                index);

            return desdeVentana;
        }

        private Document ObtenerDocumentoRevitFormaAutomatica()
        {
            if (UiDocFormaAutomatico != null && UiDocFormaAutomatico.Document != null)
                return UiDocFormaAutomatico.Document;

            Document doc = LeerDocumentoDesdeObjeto(ventanaLongitudinalOrigen);

            if (doc != null)
                return doc;

            if (SeleccionHandlerFormaAutomatico != null)
                doc = LeerDocumentoDesdeObjeto(SeleccionHandlerFormaAutomatico);

            return doc;
        }

        private Element ObtenerElementoDesdeSeleccionHandler(
            SeleccionarVigasAceroLongitudinalHandler handler,
            Document doc,
            int index)
        {
            if (handler == null || doc == null || handler.VigasSeleccionadas == null)
                return null;

            if (handler.VigasSeleccionadas.Count == 0)
                return null;

            int idx = Math.Max(0, Math.Min(index, handler.VigasSeleccionadas.Count - 1));
            ElementId id = handler.VigasSeleccionadas[idx];

            if (id == null || id == ElementId.InvalidElementId)
                return null;

            try
            {
                return doc.GetElement(id);
            }
            catch
            {
                return null;
            }
        }

        private object BuscarObjetoConVigasSeleccionadas(object obj)
        {
            if (obj == null)
                return null;

            if (TieneMiembro(obj, "VigasSeleccionadas"))
                return obj;

            BindingFlags flags = BindingFlags.Instance |
                                 BindingFlags.Public |
                                 BindingFlags.NonPublic;

            try
            {
                foreach (FieldInfo f in obj.GetType().GetFields(flags))
                {
                    object valor = f.GetValue(obj);

                    if (valor == null)
                        continue;

                    if (TieneMiembro(valor, "VigasSeleccionadas"))
                        return valor;
                }

                foreach (PropertyInfo p in obj.GetType().GetProperties(flags))
                {
                    if (p.GetIndexParameters().Length > 0)
                        continue;

                    object valor = null;

                    try
                    {
                        valor = p.GetValue(obj, null);
                    }
                    catch
                    {
                        valor = null;
                    }

                    if (valor == null)
                        continue;

                    if (TieneMiembro(valor, "VigasSeleccionadas"))
                        return valor;
                }
            }
            catch
            {
            }

            return null;
        }

        private bool TieneMiembro(object obj, string nombre)
        {
            if (obj == null || string.IsNullOrWhiteSpace(nombre))
                return false;

            BindingFlags flags = BindingFlags.Instance |
                                 BindingFlags.Public |
                                 BindingFlags.NonPublic;

            Type t = obj.GetType();
            return t.GetField(nombre, flags) != null ||
                   t.GetProperty(nombre, flags) != null;
        }

        private Element ObtenerElementoDesdeObjetoConVigasSeleccionadas(
            object obj,
            Document doc,
            int index)
        {
            if (obj == null || doc == null)
                return null;

            object listaObj = LeerMiembroObjeto(obj, "VigasSeleccionadas");
            System.Collections.IEnumerable lista = listaObj as System.Collections.IEnumerable;

            if (lista == null)
                return null;

            List<ElementId> ids = new List<ElementId>();

            foreach (object item in lista)
            {
                ElementId id = item as ElementId;

                if (id != null && id != ElementId.InvalidElementId)
                    ids.Add(id);
            }

            if (ids.Count == 0)
                return null;

            int idx = Math.Max(0, Math.Min(index, ids.Count - 1));

            try
            {
                return doc.GetElement(ids[idx]);
            }
            catch
            {
                return null;
            }
        }

        private object LeerMiembroObjeto(object obj, string nombre)
        {
            if (obj == null || string.IsNullOrWhiteSpace(nombre))
                return null;

            BindingFlags flags = BindingFlags.Instance |
                                 BindingFlags.Public |
                                 BindingFlags.NonPublic;

            try
            {
                FieldInfo f = obj.GetType().GetField(nombre, flags);

                if (f != null)
                    return f.GetValue(obj);

                PropertyInfo p = obj.GetType().GetProperty(nombre, flags);

                if (p != null && p.GetIndexParameters().Length == 0)
                    return p.GetValue(obj, null);
            }
            catch
            {
            }

            return null;
        }

        private Document LeerDocumentoDesdeObjeto(object obj)
        {
            if (obj == null)
                return null;

            BindingFlags flags = BindingFlags.Instance |
                                 BindingFlags.Public |
                                 BindingFlags.NonPublic;

            try
            {
                UIDocument uidoc = obj as UIDocument;

                if (uidoc != null)
                    return uidoc.Document;

                Document directDoc = obj as Document;

                if (directDoc != null)
                    return directDoc;

                foreach (FieldInfo f in obj.GetType().GetFields(flags))
                {
                    object valor = f.GetValue(obj);

                    if (valor is Document)
                        return valor as Document;

                    if (valor is UIDocument)
                        return ((UIDocument)valor).Document;
                }

                foreach (PropertyInfo p in obj.GetType().GetProperties(flags))
                {
                    if (p.GetIndexParameters().Length > 0)
                        continue;

                    object valor = null;

                    try
                    {
                        valor = p.GetValue(obj, null);
                    }
                    catch
                    {
                        valor = null;
                    }

                    if (valor is Document)
                        return valor as Document;

                    if (valor is UIDocument)
                        return ((UIDocument)valor).Document;
                }
            }
            catch
            {
            }

            return null;
        }

        private Element LeerElementoDesdeObjeto(object obj, Document doc)
        {
            if (obj == null)
                return null;

            Element directo = obj as Element;

            if (directo != null)
                return directo;

            BindingFlags flags = BindingFlags.Instance |
                                 BindingFlags.Public |
                                 BindingFlags.NonPublic;

            try
            {
                List<string> nombresElemento = new List<string>()
                {
                    "Elemento", "Element", "Viga", "Host", "RevitElement"
                };

                foreach (string nombre in nombresElemento)
                {
                    object valor = LeerMiembroObjeto(obj, nombre);
                    Element e = valor as Element;

                    if (e != null)
                        return e;
                }

                if (doc == null)
                    return null;

                List<string> nombresId = new List<string>()
                {
                    "ElementId", "Id", "VigaId", "ElementoId", "RevitElementId"
                };

                foreach (string nombre in nombresId)
                {
                    object valor = LeerMiembroObjeto(obj, nombre);
                    ElementId id = ConvertirAElementId(valor);

                    if (id != null && id != ElementId.InvalidElementId)
                    {
                        Element e = doc.GetElement(id);

                        if (e != null)
                            return e;
                    }
                }
            }
            catch
            {
            }

            return null;
        }

        private Element BuscarElementoEnObjetoPorIndice(object obj, Document doc, int index)
        {
            if (obj == null)
                return null;

            BindingFlags flags = BindingFlags.Instance |
                                 BindingFlags.Public |
                                 BindingFlags.NonPublic;

            try
            {
                foreach (FieldInfo f in obj.GetType().GetFields(flags))
                {
                    Element e = ExtraerElementoDesdeEnumerable(f.GetValue(obj), doc, index);

                    if (e != null)
                        return e;
                }

                foreach (PropertyInfo p in obj.GetType().GetProperties(flags))
                {
                    if (p.GetIndexParameters().Length > 0)
                        continue;

                    object valor = null;

                    try
                    {
                        valor = p.GetValue(obj, null);
                    }
                    catch
                    {
                        valor = null;
                    }

                    Element e = ExtraerElementoDesdeEnumerable(valor, doc, index);

                    if (e != null)
                        return e;
                }
            }
            catch
            {
            }

            return null;
        }

        private Element ExtraerElementoDesdeEnumerable(object obj, Document doc, int index)
        {
            System.Collections.IEnumerable lista = obj as System.Collections.IEnumerable;

            if (lista == null)
                return null;

            List<Element> elementos = new List<Element>();
            List<ElementId> ids = new List<ElementId>();

            foreach (object item in lista)
            {
                Element e = item as Element;

                if (e != null)
                    elementos.Add(e);
                else
                {
                    ElementId id = ConvertirAElementId(item);

                    if (id != null && id != ElementId.InvalidElementId)
                        ids.Add(id);
                }
            }

            if (elementos.Count > 0)
            {
                int idx = Math.Max(0, Math.Min(index, elementos.Count - 1));
                return elementos[idx];
            }

            if (doc != null && ids.Count > 0)
            {
                int idx = Math.Max(0, Math.Min(index, ids.Count - 1));

                try
                {
                    return doc.GetElement(ids[idx]);
                }
                catch
                {
                    return null;
                }
            }

            return null;
        }

        private ElementId ConvertirAElementId(object valor)
        {
            if (valor == null)
                return null;

            ElementId id = valor as ElementId;

            if (id != null)
                return id;

            try
            {
                if (valor is long)
                    return new ElementId((long)valor);

                if (valor is int)
                    return new ElementId((long)(int)valor);
            }
            catch
            {
            }

            return null;
        }

        private class PuntoLocalSeccion
        {
            public double X;
            public double Y;
            public double Z;

            public PuntoLocalSeccion(double x, double y, double z)
            {
                X = x;
                Y = y;
                Z = z;
            }
        }

        private class PuntoYZSeccion
        {
            public double Y;
            public double Z;

            public PuntoYZSeccion(double y, double z)
            {
                Y = y;
                Z = z;
            }
        }

        private bool TryDetectarCumbreraPorSeccionTransversal(
            Element elemento,
            out bool esCumbrera)
        {
            esCumbrera = false;

            if (elemento == null)
                return false;

            Curve curva = ObtenerCurvaElementoParaForma(elemento);

            if (curva == null)
                return false;

            XYZ p0 = curva.GetEndPoint(0);
            XYZ p1 = curva.GetEndPoint(1);
            XYZ xAxis = p1 - p0;

            if (xAxis == null || xAxis.GetLength() <= 1e-9)
                return false;

            xAxis = xAxis.Normalize();

            XYZ yAxis = XYZ.BasisZ.CrossProduct(xAxis);

            if (yAxis.GetLength() <= 1e-9)
                yAxis = XYZ.BasisX.CrossProduct(xAxis);

            if (yAxis.GetLength() <= 1e-9)
                yAxis = XYZ.BasisY;

            yAxis = yAxis.Normalize();

            XYZ zAxis = xAxis.CrossProduct(yAxis);

            if (zAxis.GetLength() <= 1e-9)
                zAxis = XYZ.BasisZ;

            zAxis = zAxis.Normalize();

            if (zAxis.DotProduct(XYZ.BasisZ) < 0.0)
                zAxis = zAxis.Multiply(-1.0);

            List<XYZ> puntos = ObtenerPuntosSolidoElementoParaForma(elemento);

            if (puntos == null || puntos.Count == 0)
                puntos = ObtenerPuntosBoundingBoxElementoParaForma(elemento);

            if (puntos == null || puntos.Count == 0)
                return false;

            List<PuntoLocalSeccion> locales = new List<PuntoLocalSeccion>();

            foreach (XYZ p in puntos)
            {
                if (p == null)
                    continue;

                XYZ v = p - p0;

                locales.Add(new PuntoLocalSeccion(
                    v.DotProduct(xAxis),
                    v.DotProduct(yAxis),
                    v.DotProduct(zAxis)));
            }

            if (locales.Count < 4)
                return false;

            double tolAgruparX = UnitUtils.ConvertToInternalUnits(2.0, UnitTypeId.Centimeters);
            double tolSeccion = UnitUtils.ConvertToInternalUnits(8.0, UnitTypeId.Millimeters);

            List<List<PuntoLocalSeccion>> gruposX = AgruparPuntosPorX(locales, tolAgruparX);
            bool evaluoGrupo = false;

            foreach (List<PuntoLocalSeccion> grupo in gruposX.OrderByDescending(g => g.Count))
            {
                if (grupo == null || grupo.Count < 4)
                    continue;

                List<PuntoYZSeccion> yz = grupo
                    .Select(p => new PuntoYZSeccion(p.Y, p.Z))
                    .ToList();

                bool? resultadoGrupo = EvaluarCumbreraPorNubeYZ(yz, tolSeccion);

                if (!resultadoGrupo.HasValue)
                    continue;

                evaluoGrupo = true;

                if (resultadoGrupo.Value)
                {
                    esCumbrera = true;
                    return true;
                }
            }

            if (evaluoGrupo)
            {
                esCumbrera = false;
                return true;
            }

            // Respaldo si el sólido no tiene grupos claros por estación.
            List<PuntoYZSeccion> yzTodos = locales
                .Select(p => new PuntoYZSeccion(p.Y, p.Z))
                .ToList();

            bool? resultadoTodos = EvaluarCumbreraPorNubeYZ(yzTodos, tolSeccion);

            if (!resultadoTodos.HasValue)
                return false;

            esCumbrera = resultadoTodos.Value;
            return true;
        }

        private List<List<PuntoLocalSeccion>> AgruparPuntosPorX(
            List<PuntoLocalSeccion> puntos,
            double tolerancia)
        {
            List<List<PuntoLocalSeccion>> grupos = new List<List<PuntoLocalSeccion>>();

            if (puntos == null || puntos.Count == 0)
                return grupos;

            foreach (PuntoLocalSeccion p in puntos.OrderBy(x => x.X))
            {
                List<PuntoLocalSeccion> grupo = grupos.FirstOrDefault(g =>
                    g.Count > 0 && Math.Abs(g.Average(q => q.X) - p.X) <= tolerancia);

                if (grupo == null)
                {
                    grupo = new List<PuntoLocalSeccion>();
                    grupos.Add(grupo);
                }

                grupo.Add(p);
            }

            return grupos;
        }

        private bool? EvaluarCumbreraPorNubeYZ(
            List<PuntoYZSeccion> puntos,
            double tolerancia)
        {
            if (puntos == null || puntos.Count < 4)
                return null;

            List<PuntoYZSeccion> unicos = UnificarPuntosYZ(puntos, tolerancia);

            if (unicos.Count < 4)
                return null;

            List<PuntoYZSeccion> hull = ObtenerConvexHullYZ(unicos, tolerancia);
            hull = SimplificarHullYZ(hull, tolerancia);

            if (hull == null || hull.Count < 4)
                return null;

            if (hull.Count <= 4)
                return false;

            if (hull.Count >= 6)
                return true;

            // Con 5 vértices, validar que exista quiebre de cubierta en la parte
            // superior o inferior. Esto evita confundir pequeños chaflanes con cumbrera.
            return TieneQuiebreSuperiorOInferior(hull);
        }

        private List<PuntoYZSeccion> UnificarPuntosYZ(
            List<PuntoYZSeccion> puntos,
            double tolerancia)
        {
            List<PuntoYZSeccion> resultado = new List<PuntoYZSeccion>();

            foreach (PuntoYZSeccion p in puntos)
            {
                if (p == null)
                    continue;

                bool existe = resultado.Any(q =>
                    DistanciaYZ(p, q) <= tolerancia);

                if (!existe)
                    resultado.Add(p);
            }

            return resultado;
        }

        private List<PuntoYZSeccion> ObtenerConvexHullYZ(
            List<PuntoYZSeccion> puntos,
            double tolerancia)
        {
            List<PuntoYZSeccion> pts = puntos
                .Where(p => p != null)
                .OrderBy(p => p.Y)
                .ThenBy(p => p.Z)
                .ToList();

            if (pts.Count <= 1)
                return pts;

            List<PuntoYZSeccion> lower = new List<PuntoYZSeccion>();

            foreach (PuntoYZSeccion p in pts)
            {
                while (lower.Count >= 2 &&
                       CrossYZ(lower[lower.Count - 2], lower[lower.Count - 1], p) <= tolerancia)
                {
                    lower.RemoveAt(lower.Count - 1);
                }

                lower.Add(p);
            }

            List<PuntoYZSeccion> upper = new List<PuntoYZSeccion>();

            for (int i = pts.Count - 1; i >= 0; i--)
            {
                PuntoYZSeccion p = pts[i];

                while (upper.Count >= 2 &&
                       CrossYZ(upper[upper.Count - 2], upper[upper.Count - 1], p) <= tolerancia)
                {
                    upper.RemoveAt(upper.Count - 1);
                }

                upper.Add(p);
            }

            lower.RemoveAt(lower.Count - 1);
            upper.RemoveAt(upper.Count - 1);
            lower.AddRange(upper);

            return lower;
        }

        private List<PuntoYZSeccion> SimplificarHullYZ(
            List<PuntoYZSeccion> hull,
            double tolerancia)
        {
            if (hull == null || hull.Count <= 3)
                return hull;

            List<PuntoYZSeccion> resultado = new List<PuntoYZSeccion>(hull);
            bool cambio = true;
            int seguridad = 0;

            while (cambio && resultado.Count > 3 && seguridad < 100)
            {
                cambio = false;
                seguridad++;

                for (int i = 0; i < resultado.Count; i++)
                {
                    PuntoYZSeccion a = resultado[(i - 1 + resultado.Count) % resultado.Count];
                    PuntoYZSeccion b = resultado[i];
                    PuntoYZSeccion c = resultado[(i + 1) % resultado.Count];

                    double dist = DistanciaPuntoALineaYZ(b, a, c);

                    if (dist <= tolerancia)
                    {
                        resultado.RemoveAt(i);
                        cambio = true;
                        break;
                    }
                }
            }

            return resultado;
        }

        private bool TieneQuiebreSuperiorOInferior(List<PuntoYZSeccion> hull)
        {
            if (hull == null || hull.Count < 5)
                return false;

            double zMin = hull.Min(p => p.Z);
            double zMax = hull.Max(p => p.Z);
            double alto = zMax - zMin;

            if (alto <= 1e-9)
                return false;

            int arriba = hull.Count(p => p.Z >= zMin + alto * 0.60);
            int abajo = hull.Count(p => p.Z <= zMin + alto * 0.40);

            return arriba >= 3 || abajo >= 3;
        }

        private double CrossYZ(PuntoYZSeccion a, PuntoYZSeccion b, PuntoYZSeccion c)
        {
            return (b.Y - a.Y) * (c.Z - a.Z) -
                   (b.Z - a.Z) * (c.Y - a.Y);
        }

        private double DistanciaYZ(PuntoYZSeccion a, PuntoYZSeccion b)
        {
            double dy = a.Y - b.Y;
            double dz = a.Z - b.Z;
            return Math.Sqrt(dy * dy + dz * dz);
        }

        private double DistanciaPuntoALineaYZ(
            PuntoYZSeccion p,
            PuntoYZSeccion a,
            PuntoYZSeccion b)
        {
            double dy = b.Y - a.Y;
            double dz = b.Z - a.Z;
            double len = Math.Sqrt(dy * dy + dz * dz);

            if (len <= 1e-9)
                return DistanciaYZ(p, a);

            return Math.Abs((p.Y - a.Y) * dz - (p.Z - a.Z) * dy) / len;
        }

        private Curve ObtenerCurvaElementoParaForma(Element elemento)
        {
            if (elemento == null)
                return null;

            try
            {
                LocationCurve lc = elemento.Location as LocationCurve;

                if (lc != null)
                    return lc.Curve;
            }
            catch
            {
            }

            return null;
        }

        private List<XYZ> ObtenerPuntosSolidoElementoParaForma(Element elemento)
        {
            List<XYZ> puntos = new List<XYZ>();

            if (elemento == null)
                return puntos;

            try
            {
                Options opt = new Options();
                opt.ComputeReferences = false;
                opt.IncludeNonVisibleObjects = false;
                opt.DetailLevel = ViewDetailLevel.Fine;

                GeometryElement ge = elemento.get_Geometry(opt);

                if (ge != null)
                    AgregarPuntosGeometriaParaForma(ge, Transform.Identity, puntos);
            }
            catch
            {
            }

            return puntos;
        }

        private void AgregarPuntosGeometriaParaForma(
            GeometryElement ge,
            Transform tr,
            List<XYZ> puntos)
        {
            if (ge == null || puntos == null)
                return;

            foreach (GeometryObject obj in ge)
            {
                Solid solid = obj as Solid;

                if (solid != null)
                {
                    AgregarPuntosSolidoParaForma(solid, tr, puntos);
                    continue;
                }

                GeometryInstance gi = obj as GeometryInstance;

                if (gi != null)
                {
                    Transform tr2 = tr.Multiply(gi.Transform);
                    GeometryElement symbolGeometry = gi.GetSymbolGeometry();

                    if (symbolGeometry != null)
                        AgregarPuntosGeometriaParaForma(symbolGeometry, tr2, puntos);
                }
            }
        }

        private void AgregarPuntosSolidoParaForma(
            Solid solid,
            Transform tr,
            List<XYZ> puntos)
        {
            if (solid == null || puntos == null)
                return;

            if (solid.Faces == null || solid.Faces.Size == 0)
                return;

            try
            {
                foreach (Face face in solid.Faces)
                {
                    if (face == null)
                        continue;

                    Mesh mesh = face.Triangulate();

                    if (mesh == null)
                        continue;

                    // Revit API: Mesh no expone NumVertices ni get_Vertex directamente.
                    // Se recorren los triángulos y luego los 3 vértices de cada triángulo.
                    for (int i = 0; i < mesh.NumTriangles; i++)
                    {
                        MeshTriangle tri = mesh.get_Triangle(i);

                        if (tri == null)
                            continue;

                        for (int j = 0; j < 3; j++)
                        {
                            XYZ p = tri.get_Vertex(j);

                            if (p != null)
                                puntos.Add(tr.OfPoint(p));
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private List<XYZ> ObtenerPuntosBoundingBoxElementoParaForma(Element elemento)
        {
            List<XYZ> puntos = new List<XYZ>();

            if (elemento == null)
                return puntos;

            try
            {
                BoundingBoxXYZ bb = elemento.get_BoundingBox(null);

                if (bb == null)
                    return puntos;

                XYZ min = bb.Min;
                XYZ max = bb.Max;

                puntos.Add(new XYZ(min.X, min.Y, min.Z));
                puntos.Add(new XYZ(max.X, min.Y, min.Z));
                puntos.Add(new XYZ(min.X, max.Y, min.Z));
                puntos.Add(new XYZ(max.X, max.Y, min.Z));
                puntos.Add(new XYZ(min.X, min.Y, max.Z));
                puntos.Add(new XYZ(max.X, min.Y, max.Z));
                puntos.Add(new XYZ(min.X, max.Y, max.Z));
                puntos.Add(new XYZ(max.X, max.Y, max.Z));
            }
            catch
            {
            }

            return puntos;
        }

        private VigaLongitudinalPreview ObtenerVigaPreviewParaTramoActual()
        {
            if (vigasPreview == null || vigasPreview.Count == 0)
                return null;

            int index = tramoSeleccionado;

            if (tramos != null &&
                vigasPreview.Count == tramos.Count &&
                index >= 0 &&
                index < vigasPreview.Count)
            {
                return vigasPreview[index];
            }

            if (vigasPreview.Count == 1)
                return vigasPreview[0];

            if (index >= 0 && index < vigasPreview.Count)
                return vigasPreview[index];

            // Respaldo: si no se puede asociar por índice, se busca una viga con
            // perfil realmente cumbrera. No se usa inclinación como criterio.
            VigaLongitudinalPreview variable = vigasPreview.FirstOrDefault(v =>
                v != null && EsVigaPreviewCumbreraReal(v));

            return variable ?? vigasPreview.FirstOrDefault(v => v != null);
        }

        private void SeleccionarFormaEstribo(TipoFormaEstribo tipo)
        {
            if (cmbFormaEstribo == null || cmbFormaEstribo.Items.Count == 0)
                return;

            for (int i = 0; i < cmbFormaEstribo.Items.Count; i++)
            {
                TipoFormaEstriboItem item = cmbFormaEstribo.Items[i] as TipoFormaEstriboItem;

                if (item == null)
                    continue;

                if (item.Tipo == tipo)
                {
                    if (cmbFormaEstribo.SelectedIndex != i)
                        cmbFormaEstribo.SelectedIndex = i;

                    RefrescarComboFormaEstribo();

                    return;
                }
            }
        }

        private bool LeerBoolPropiedad(object obj, string nombrePropiedad)
        {
            if (obj == null || string.IsNullOrWhiteSpace(nombrePropiedad))
                return false;

            try
            {
                PropertyInfo prop = obj.GetType().GetProperty(
                    nombrePropiedad,
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

                if (prop == null)
                    return false;

                object valor = prop.GetValue(obj, null);

                if (valor is bool)
                    return (bool)valor;

                return false;
            }
            catch
            {
                return false;
            }
        }

        private double LeerDoublePropiedad(
            object obj,
            string nombrePropiedad,
            double valorDefecto)
        {
            if (obj == null || string.IsNullOrWhiteSpace(nombrePropiedad))
                return valorDefecto;

            try
            {
                PropertyInfo prop = obj.GetType().GetProperty(
                    nombrePropiedad,
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

                if (prop == null)
                    return valorDefecto;

                object valor = prop.GetValue(obj, null);

                if (valor == null)
                    return valorDefecto;

                return Convert.ToDouble(valor);
            }
            catch
            {
                return valorDefecto;
            }
        }

        private int ObtenerCantidadListaPropiedad(object obj, string nombrePropiedad)
        {
            if (obj == null || string.IsNullOrWhiteSpace(nombrePropiedad))
                return 0;

            try
            {
                PropertyInfo prop = obj.GetType().GetProperty(
                    nombrePropiedad,
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

                if (prop == null)
                    return 0;

                object valor = prop.GetValue(obj, null);

                System.Collections.ICollection col = valor as System.Collections.ICollection;

                if (col != null)
                    return col.Count;

                System.Collections.IEnumerable enumerable = valor as System.Collections.IEnumerable;

                if (enumerable == null)
                    return 0;

                int count = 0;

                foreach (object item in enumerable)
                    count++;

                return count;
            }
            catch
            {
                return 0;
            }
        }

        private void CmbTipoEstribo_Format(
            object sender,
            WinForms.ListControlConvertEventArgs e)
        {
            RebarBarType tipo = e != null
                ? e.ListItem as RebarBarType
                : null;

            if (tipo != null)
                e.Value = tipo.Name;
        }

        private double ObtenerRecubrimientoEditorIntegradoCm()
        {
            if (txtRecubrimiento == null ||
                string.IsNullOrWhiteSpace(txtRecubrimiento.Text))
            {
                return 4.0;
            }

            double valor;
            string texto = txtRecubrimiento.Text.Trim().Replace(',', '.');

            if (!double.TryParse(
                    texto,
                    System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out valor) ||
                valor <= 0.0 ||
                double.IsNaN(valor) ||
                double.IsInfinity(valor))
            {
                return 4.0;
            }

            return valor;
        }

        private void CrearPanelEditorSeccionIntegrado()
        {
            panelEditorSeccionIntegrado = new WinForms.Panel
            {
                BackColor = Drawing.Color.FromArgb(245, 247, 250),
                BorderStyle = WinForms.BorderStyle.None,
                AutoScroll = false
            };

            this.Controls.Add(panelEditorSeccionIntegrado);
            panelEditorSeccionIntegrado.BringToFront();
        }

        public void ConfigurarEditorSeccionIntegrado(
            List<AceroVigaPuntoMm> contorno,
            List<RebarBarType> tipos,
            RebarBarType tipoLongitudinalReferencia,
            AceroVigaDisenoSeccion diseno,
            string nombreSeccion)
        {
            if (panelEditorSeccionIntegrado == null ||
                panelEditorSeccionIntegrado.IsDisposed)
            {
                CrearPanelEditorSeccionIntegrado();
            }

            LimpiarPanelesEditorUnificado();

            if (editorSeccionIntegrado != null &&
                !editorSeccionIntegrado.IsDisposed)
            {
                try
                {
                    AceroVigaDisenoSeccion trabajo =
                        editorSeccionIntegrado.ObtenerDisenoTrabajo();
                    AceroVigaDisenoSeccionCompartido.Establecer(trabajo);
                }
                catch
                {
                }

                editorSeccionIntegrado.DisenoAplicado -=
                    EditorSeccionIntegrado_DisenoAplicado;
                editorSeccionIntegrado.EstadoSeleccionTipoCambiado -=
                    EditorSeccionIntegrado_EstadoSeleccionTipoCambiado;
                panelEditorSeccionIntegrado.Controls.Remove(
                    editorSeccionIntegrado);
                editorSeccionIntegrado.Dispose();
                editorSeccionIntegrado = null;
            }

            panelEditorSeccionIntegrado.Controls.Clear();

            if (contorno == null || contorno.Count < 3)
            {
                lblEditorSinGeometriaIntegrado = new WinForms.Label
                {
                    Dock = WinForms.DockStyle.Fill,
                    Text = "DISEÑO DE ESTRIBOS\n\n" +
                           "Seleccione una o más vigas para leer la sección real.",
                    TextAlign = Drawing.ContentAlignment.MiddleCenter,
                    Font = new Drawing.Font(
                        "Segoe UI",
                        10F,
                        Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(90, 90, 90),
                    BackColor = Drawing.Color.White
                };
                panelEditorSeccionIntegrado.Controls.Add(
                    lblEditorSinGeometriaIntegrado);
                AjustarLayout();
                return;
            }

            List<RebarBarType> listaTipos = tipos != null
                ? tipos.Where(x => x != null).ToList()
                : new List<RebarBarType>();

            RebarBarType tipoEstribo = TipoEstriboSeleccionado ??
                listaTipos.FirstOrDefault();
            RebarBarType tipoLongitudinal =
                tipoLongitudinalReferencia ?? listaTipos.FirstOrDefault();

            AceroVigaDisenoSeccion trabajoDiseno = diseno != null
                ? diseno.Copiar()
                : AceroVigaDisenoSeccionCompartido.ObtenerCopia();

            editorSeccionIntegrado = new AceroVigaEditorSeccionForm(
                contorno,
                listaTipos,
                tipoLongitudinal,
                tipoEstribo,
                ObtenerRecubrimientoEditorIntegradoCm(),
                trabajoDiseno,
                AceroVigaModoEditorInicial.Estribos,
                nombreSeccion ?? string.Empty);

            editorSeccionIntegrado.ConfigurarComoLienzoUnificadoEnPestana(
                delegate { return tipoLongitudinalReferencia; },
                delegate { return TipoEstriboSeleccionado; },
                ObtenerRecubrimientoEditorIntegradoCm);

            editorSeccionIntegrado.DisenoAplicado +=
                EditorSeccionIntegrado_DisenoAplicado;
            editorSeccionIntegrado.EstadoSeleccionTipoCambiado +=
                EditorSeccionIntegrado_EstadoSeleccionTipoCambiado;

            panelEditorSeccionIntegrado.Controls.Add(
                editorSeccionIntegrado);

            barraEdicionEditorUnificada =
                editorSeccionIntegrado
                    .CrearBarraEdicionSuperiorPestanaUnificada();
            panelEditorSeccionIntegrado.Controls.Add(
                barraEdicionEditorUnificada);
            barraEdicionEditorUnificada.BringToFront();

            panelHerramientasEditorUnificado =
                editorSeccionIntegrado
                    .CrearPanelHerramientasPestanaUnificada(
                        panelConfiguracionUnificada != null
                            ? Math.Max(390,
                                panelConfiguracionUnificada.ClientSize.Width - 18)
                            : 414);

            if (panelConfiguracionUnificada != null)
            {
                panelConfiguracionUnificada.Controls.Add(
                    panelHerramientasEditorUnificado);
                panelHerramientasEditorUnificado.BringToFront();
            }

            editorSeccionIntegrado.Show();
            editorSeccionIntegrado.BringToFront();
            barraEdicionEditorUnificada.BringToFront();
            ConstruirFormatoExactoColumnasV8Estribos();
            ActualizarEstadoBotonAplicarTipoSeleccionV8();
            AjustarLayout();
        }

        private void EditorSeccionIntegrado_DisenoAplicado(
            AceroVigaDisenoSeccion diseno)
        {
            if (diseno != null)
                AceroVigaDisenoSeccionCompartido.Establecer(diseno);

            NotificarPreviewEstribosActualizado();
        }

        public void RefrescarEditorSeccionIntegrado()
        {
            if (editorSeccionIntegrado != null &&
                !editorSeccionIntegrado.IsDisposed)
            {
                editorSeccionIntegrado.RefrescarEntradasExternas();
            }
        }

        // =====================================
        // CARGA DE TIPOS
        // =====================================
        public void CargarTiposArmadura(List<RebarBarType> tipos)
        {
            cmbTipoEstribo.Items.Clear();

            if (tipos != null)
            {
                foreach (RebarBarType t in tipos)
                    cmbTipoEstribo.Items.Add(t);
            }

            cmbTipoEstribo.DisplayMember = "Name";
            cmbTipoEstribo.FormattingEnabled = true;
            cmbTipoEstribo.Format -= CmbTipoEstribo_Format;
            cmbTipoEstribo.Format += CmbTipoEstribo_Format;

            if (cmbTipoEstribo.Items.Count > 0)
                cmbTipoEstribo.SelectedIndex = 0;
        }

        // =====================================
        // CARGA DESDE LA SELECCIÓN EXISTENTE
        // =====================================
        public void ActualizarDesdeVentanaLongitudinal(
            AceroLongitudinalVigasForm ventana)
        {
            ventanaLongitudinalOrigen = ventana;
            formaDetectadaDesdeHandler = null;

            // Si el handler ya está conectado, se toma inmediatamente la forma
            // que él detecta desde la geometría real seleccionada.
            TipoFormaEstribo tipoHandler;
            if (TryDetectarFormaDesdeHandler(out tipoHandler))
                AplicarFormaEstriboDetectadaDesdeHandler(tipoHandler);

            // Respaldo para que el panel de vista siga dibujando desde la ventana longitudinal.
            vigasPreview = ObtenerVigasPreviewDesdeVentanaLongitudinal(ventana);

            // NUEVO:
            // Se cargan los tramos con su inicio/fin exacto dentro de la serie visible.
            // Esto es clave cuando Revit tiene una sola viga continua, pero en la
            // vista preliminar existen varios tramos entre columnas.
            List<Tuple<double, double, double>> rangosSerie =
                ObtenerRangosTramosSerieDesdeVentana(ventana);

            if (rangosSerie != null && rangosSerie.Count > 0)
            {
                CargarDesdeRangosDeSerie(rangosSerie);
                return;
            }

            List<double> longitudesSerie = ObtenerLongitudesTramosSerieDesdeVentana(ventana);

            if (longitudesSerie != null && longitudesSerie.Count > 0)
            {
                CargarDesdeLongitudesDeSerie(longitudesSerie);
                return;
            }

            CargarDesdeVigasPreview(vigasPreview);
        }

        private List<Tuple<double, double, double>> ObtenerRangosTramosSerieDesdeVentana(
            AceroLongitudinalVigasForm ventana)
        {
            List<Tuple<double, double, double>> vacio =
                new List<Tuple<double, double, double>>();

            if (ventana == null || ventana.IsDisposed)
                return vacio;

            try
            {
                List<Tuple<double, double, double>> lista =
                    ventana.ObtenerRangosTramosSerieVistaPreviaMm();

                if (lista != null)
                    return lista;
            }
            catch
            {
            }

            return vacio;
        }

        private void CargarDesdeRangosDeSerie(
            List<Tuple<double, double, double>> rangosSerie)
        {
            List<TramoInfo> nuevosTramos = new List<TramoInfo>();

            if (rangosSerie != null)
            {
                for (int i = 0; i < rangosSerie.Count; i++)
                {
                    Tuple<double, double, double> r = rangosSerie[i];

                    if (r == null)
                        continue;

                    double start = r.Item1;
                    double end = r.Item2;
                    double total = r.Item3;
                    double L = end - start;

                    if (L <= 1.0)
                        continue;

                    nuevosTramos.Add(new TramoInfo(
                        nuevosTramos.Count,
                        L,
                        0.0,
                        0.0,
                        "Tramo " + (nuevosTramos.Count + 1),
                        start,
                        end,
                        total));
                }
            }

            if (nuevosTramos.Count == 0)
            {
                LimpiarTramos();
                return;
            }

            CargarTramos(nuevosTramos);
        }

        private List<double> ObtenerLongitudesTramosSerieDesdeVentana(
            AceroLongitudinalVigasForm ventana)
        {
            List<double> vacio = new List<double>();

            if (ventana == null || ventana.IsDisposed)
                return vacio;

            try
            {
                List<double> lista = ventana.ObtenerLongitudesTramosSerieVistaPreviaMm();
                if (lista != null)
                    return lista;
            }
            catch
            {
            }

            return vacio;
        }

        private void CargarDesdeLongitudesDeSerie(List<double> longitudesMm)
        {
            List<TramoInfo> nuevosTramos = new List<TramoInfo>();

            double total = 0.0;

            if (longitudesMm != null)
                total = longitudesMm.Where(x => x > 0.0).Sum();

            double cursor = 0.0;

            if (longitudesMm != null)
            {
                for (int i = 0; i < longitudesMm.Count; i++)
                {
                    double L = longitudesMm[i];

                    if (L <= 0.0)
                        continue;

                    double start = cursor;
                    double end = cursor + L;

                    nuevosTramos.Add(new TramoInfo(
                        nuevosTramos.Count,
                        L,
                        0.0,
                        0.0,
                        "Tramo " + (nuevosTramos.Count + 1),
                        start,
                        end,
                        total));

                    cursor = end;
                }
            }

            if (nuevosTramos.Count == 0)
            {
                LimpiarTramos();
                return;
            }

            CargarTramos(nuevosTramos);
        }

        private List<VigaLongitudinalPreview> ObtenerVigasPreviewDesdeVentanaLongitudinal(
            AceroLongitudinalVigasForm ventana)
        {
            List<VigaLongitudinalPreview> vacio = new List<VigaLongitudinalPreview>();

            if (ventana == null || ventana.IsDisposed)
                return vacio;

            try
            {
                List<VigaLongitudinalPreview> listaPublica =
                    ventana.ObtenerVigasPreviewActuales();

                if (listaPublica != null)
                    return listaPublica;
            }
            catch
            {
                // Respaldo por reflexión.
            }

            try
            {
                FieldInfo campo = typeof(AceroLongitudinalVigasForm).GetField(
                    "previewVigas",
                    BindingFlags.Instance |
                    BindingFlags.NonPublic);

                if (campo == null)
                    return vacio;

                object valor = campo.GetValue(ventana);

                List<VigaLongitudinalPreview> lista =
                    valor as List<VigaLongitudinalPreview>;

                if (lista == null)
                    return vacio;

                return lista;
            }
            catch
            {
                return vacio;
            }
        }

        public void CargarDesdeVigasPreview(
            List<VigaLongitudinalPreview> vigas)
        {
            vigasPreview = vigas ?? new List<VigaLongitudinalPreview>();

            // Al cambiar de selección, se descarta cualquier forma detectada previamente
            // para evitar que la miniatura global se quede con la viga anterior.
            formaDetectadaDesdeHandler = null;

            if (vigas == null || vigas.Count == 0)
            {
                LimpiarTramos();
                return;
            }

            List<TramoInfo> nuevosTramos = new List<TramoInfo>();

            for (int i = 0; i < vigas.Count; i++)
            {
                VigaLongitudinalPreview v = vigas[i];

                if (v == null)
                    continue;

                double longitud = v.LongitudSolidoMm > 0.0
                    ? v.LongitudSolidoMm
                    : v.LongitudMm;

                if (longitud <= 0.0)
                    continue;

                double apoyoIzq = ObtenerAnchoApoyoInicio(v);
                double apoyoDer = ObtenerAnchoApoyoFin(v);

                double startSerie = nuevosTramos.Sum(t => t.LongitudMm);
                double endSerie = startSerie + longitud;

                nuevosTramos.Add(new TramoInfo(
                    nuevosTramos.Count,
                    longitud,
                    apoyoIzq,
                    apoyoDer,
                    string.IsNullOrWhiteSpace(v.Nombre)
                        ? "Tramo " + (nuevosTramos.Count + 1)
                        : v.Nombre,
                    startSerie,
                    endSerie,
                    0.0));
            }

            if (nuevosTramos.Count == 0)
            {
                LimpiarTramos();
                return;
            }

            double totalFallback = nuevosTramos.Sum(t => t.LongitudMm);

            foreach (TramoInfo t in nuevosTramos)
                t.TotalSerieMm = totalFallback;

            CargarTramos(nuevosTramos);
        }

        private double ObtenerAnchoApoyoInicio(VigaLongitudinalPreview v)
        {
            if (v == null || v.Columnas == null || v.Columnas.Count == 0)
                return 450.0;

            AceroLongitudinalVigasForm.ColumnaPreview col =
                v.Columnas
                .Where(c => c != null)
                .OrderBy(c => c.CentroMm)
                .FirstOrDefault();

            if (col == null || col.AnchoMm <= 0.0)
                return 450.0;

            return col.AnchoMm;
        }

        private double ObtenerAnchoApoyoFin(VigaLongitudinalPreview v)
        {
            if (v == null || v.Columnas == null || v.Columnas.Count == 0)
                return 450.0;

            AceroLongitudinalVigasForm.ColumnaPreview col =
                v.Columnas
                .Where(c => c != null)
                .OrderByDescending(c => c.CentroMm)
                .FirstOrDefault();

            if (col == null || col.AnchoMm <= 0.0)
                return 450.0;

            return col.AnchoMm;
        }

        private void LimpiarTramos()
        {
            tramos = new List<TramoInfo>();
            configsPorTramo = new Dictionary<int, TramoEstriboConfig>();
            tramoSeleccionado = -1;

            if (panelPreview != null)
            {
                panelPreview.CargarDatos(tramos, configsPorTramo);
                panelPreview.SetSeleccion(-1);
            }

            LimpiarEstribosEnVentanaLongitudinal();
            ActualizarControlesDesdeSeleccion();
            DetectarYAplicarFormaEstriboAutomaticamente();
        }

        private void CargarTramos(List<TramoInfo> nuevosTramos)
        {
            if (nuevosTramos == null || nuevosTramos.Count == 0)
            {
                LimpiarTramos();
                return;
            }

            Dictionary<int, TramoEstriboConfig> anteriores =
                configsPorTramo ?? new Dictionary<int, TramoEstriboConfig>();

            tramos = nuevosTramos;
            configsPorTramo = new Dictionary<int, TramoEstriboConfig>();

            for (int i = 0; i < tramos.Count; i++)
            {
                tramos[i].Index = i;

                if (anteriores.ContainsKey(i))
                    configsPorTramo[i] = anteriores[i].Clonar();
                else
                    configsPorTramo[i] = CrearConfigPorDefecto(tramos[i].LongitudMm);

                int nCfg = Math.Max(1, Math.Min(4, configsPorTramo[i].TipoDistribucion));
                if (UltimaZonaEsResto(nCfg))
                {
                    int idxResto = ObtenerIndiceUltimaZona(nCfg);
                    configsPorTramo[i].Cantidades[idxResto] =
                        CalcularCantidadRestoAuto(tramos[i], configsPorTramo[i]);
                }
            }

            // Si la data fue cargada antes de seleccionar vigas, se aplica ahora.
            AplicarConfiguracionEstribosPendienteATramosMYG();

            if (tramoSeleccionado < 0 || tramoSeleccionado >= tramos.Count)
                tramoSeleccionado = 0;

            if (panelPreview != null)
            {
                panelPreview.CargarDatos(tramos, configsPorTramo);
                panelPreview.SetSeleccion(tramoSeleccionado);
            }

            ActualizarControlesDesdeSeleccion();
            DetectarYAplicarFormaEstriboAutomaticamente();
            SincronizarEstribosConVentanaLongitudinal();
            NotificarPreviewEstribosActualizado();
        }

        private TramoEstriboConfig CrearConfigPorDefecto(double luzMm)
        {
            TramoEstriboConfig c = new TramoEstriboConfig();

            // CRITERIO POR DEFECTO:
            // La primera fila representa SOLO el primer estribo fijo:
            // 1 estribo a 5 cm desde la cara del apoyo.
            // Las siguientes zonas arrancan con SU PROPIA separación
            // medida desde el último estribo anterior, en ambos extremos.
            c.TipoDistribucion = 4;

            c.SeparacionesCm[0] = 5.0;
            c.SeparacionesCm[1] = 10.0;
            c.SeparacionesCm[2] = 15.0;
            c.SeparacionesCm[3] = 30.0;

            c.Cantidades[0] = 1; // 1 @ 5 cm.
            c.Cantidades[1] = 3; // 3 @ 10 cm, desde el primer estribo.
            c.Cantidades[2] = 4; // 4 @ 15 cm.
            c.Cantidades[3] = 1; // RESTO: se recalcula automáticamente.

            return c;
        }

        private void AplicarCriterioPeruanoAlTramo(int index)
        {
            if (index < 0 || index >= tramos.Count)
                return;

            double Lcm = tramos[index].LongitudMm / 10.0;

            if (Lcm <= 0.0)
                return;

            TramoEstriboConfig cfg = new TramoEstriboConfig();

            // Criterio editable típico:
            // extremo izquierdo, extremo derecho y resto central.
            cfg.TipoDistribucion = 3;
            cfg.SeparacionesCm[0] = 10.0;
            cfg.SeparacionesCm[1] = 10.0;
            cfg.SeparacionesCm[2] = 20.0;
            cfg.SeparacionesCm[3] = 20.0;

            double zonaExtremoCm = Math.Max(20.0, Lcm / 4.0);
            cfg.Cantidades[0] = Math.Max(1, (int)Math.Floor(zonaExtremoCm / cfg.SeparacionesCm[0]) + 1);
            cfg.Cantidades[1] = Math.Max(1, (int)Math.Floor(zonaExtremoCm / cfg.SeparacionesCm[1]) + 1);

            // La última zona es el resto central. La cantidad puede quedar como referencia
            // pero la generación gráfica / ejecución llena el resto automáticamente.
            double restoCentroCm = Math.Max(1.0, Lcm -
                (cfg.Cantidades[0] * cfg.SeparacionesCm[0]) -
                (cfg.Cantidades[1] * cfg.SeparacionesCm[1]));

            cfg.Cantidades[2] = Math.Max(1, (int)Math.Floor(restoCentroCm / cfg.SeparacionesCm[2]) + 1);
            cfg.Cantidades[3] = 1;

            configsPorTramo[index] = cfg;
        }

        // =========================================================
        // GUARDAR / CARGAR DATA DE ACERO EN VIGAS
        // =========================================================
        private void BtnGuardarData_Click(object sender, EventArgs e)
        {
            GuardarControlesEnConfig();

            if (ventanaLongitudinalOrigen == null || ventanaLongitudinalOrigen.IsDisposed)
            {
                WinForms.MessageBox.Show(
                    "No se encontró la ventana de acero longitudinal conectada.\n\n" +
                    "Seleccione primero las vigas para inicializar ambas configuraciones.",
                    "MYG - Guardar data",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Warning);

                return;
            }

            ArchivoConfiguracionAceroVigas archivo =
                new ArchivoConfiguracionAceroVigas();

            archivo.Version = 5;
            archivo.FechaGuardado = DateTime.Now.ToString(
                "yyyy-MM-dd HH:mm:ss",
                System.Globalization.CultureInfo.InvariantCulture);

            archivo.Estribos = CapturarConfiguracionEstribosPersistenteMYG();
            archivo.Longitudinal = CapturarConfiguracionLongitudinalPorReflexionMYG();

            // Guarda también TODO lo dibujado en la sección: longitudinales
            // individuales, grupos 2 puntos, regla, guías de capa y estribos.
            try
            {
                archivo.DisenoSeccionXml =
                    ventanaLongitudinalOrigen
                        .ExportarDisenoSeccionPersistenteMYG();
            }
            catch
            {
                archivo.DisenoSeccionXml = string.Empty;
            }

            // V11.32 - guarda también todo lo incorporado en los modos por
            // estaciones: modo actual, cantidades/posiciones exactas por tramo,
            // MIRROR, extensión al aparecer y desarrollos por diámetro.
            try
            {
                archivo.EstadoLongitudinalAvanzadoXml =
                    ventanaLongitudinalOrigen
                        .ExportarEstadoLongitudinalAvanzadoPersistenteMYG();
            }
            catch
            {
                archivo.EstadoLongitudinalAvanzadoXml = string.Empty;
            }

            using (WinForms.SaveFileDialog dlg = new WinForms.SaveFileDialog())
            {
                dlg.Title = "Guardar configuración MYG - Acero en vigas";
                dlg.Filter =
                    "Configuración MYG Acero (*.mygacero)|*.mygacero|" +
                    "Archivo XML (*.xml)|*.xml";
                dlg.DefaultExt = "mygacero";
                dlg.AddExtension = true;
                dlg.OverwritePrompt = true;
                dlg.FileName = "MYG_AceroVigas_" + DateTime.Now.ToString("yyyyMMdd_HHmm") + ".mygacero";

                WinForms.DialogResult result = dlg.ShowDialog(this.FindForm());

                if (result != WinForms.DialogResult.OK || string.IsNullOrWhiteSpace(dlg.FileName))
                    return;

                try
                {
                    System.Xml.Serialization.XmlSerializer serializador =
                        new System.Xml.Serialization.XmlSerializer(
                            typeof(ArchivoConfiguracionAceroVigas));

                    System.Xml.XmlWriterSettings ajustes =
                        new System.Xml.XmlWriterSettings()
                        {
                            Indent = true,
                            Encoding = new System.Text.UTF8Encoding(false)
                        };

                    using (System.Xml.XmlWriter escritor =
                        System.Xml.XmlWriter.Create(dlg.FileName, ajustes))
                    {
                        serializador.Serialize(escritor, archivo);
                    }

                    lblMensaje.Text = "Data guardada correctamente.";

                    WinForms.MessageBox.Show(
                        "Se guardó la configuración, el diseño completo de acero y los modos por tramos/desarrollos.\n\n" +
                        dlg.FileName,
                        "MYG - Guardar data",
                        WinForms.MessageBoxButtons.OK,
                        WinForms.MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    WinForms.MessageBox.Show(
                        "No se pudo guardar la data.\n\n" + ex.Message,
                        "MYG - Guardar data",
                        WinForms.MessageBoxButtons.OK,
                        WinForms.MessageBoxIcon.Error);
                }
            }
        }

        private void BtnCargarData_Click(object sender, EventArgs e)
        {
            using (WinForms.OpenFileDialog dlg = new WinForms.OpenFileDialog())
            {
                dlg.Title = "Cargar configuración MYG - Acero en vigas";
                dlg.Filter =
                    "Configuración MYG Acero (*.mygacero;*.xml)|*.mygacero;*.xml|" +
                    "Todos los archivos (*.*)|*.*";
                dlg.CheckFileExists = true;
                dlg.Multiselect = false;

                WinForms.DialogResult result = dlg.ShowDialog(this.FindForm());

                if (result != WinForms.DialogResult.OK || string.IsNullOrWhiteSpace(dlg.FileName))
                    return;

                try
                {
                    System.Xml.Serialization.XmlSerializer serializador =
                        new System.Xml.Serialization.XmlSerializer(
                            typeof(ArchivoConfiguracionAceroVigas));

                    ArchivoConfiguracionAceroVigas archivo = null;

                    using (System.IO.FileStream flujo =
                        new System.IO.FileStream(
                            dlg.FileName,
                            System.IO.FileMode.Open,
                            System.IO.FileAccess.Read,
                            System.IO.FileShare.Read))
                    {
                        archivo = serializador.Deserialize(flujo)
                            as ArchivoConfiguracionAceroVigas;
                    }

                    if (archivo == null)
                        throw new InvalidOperationException("El archivo no contiene una configuración válida.");

                    if (ventanaLongitudinalOrigen != null &&
                        !ventanaLongitudinalOrigen.IsDisposed &&
                        archivo.Longitudinal != null)
                    {
                        AplicarConfiguracionLongitudinalPorReflexionMYG(
                            archivo.Longitudinal);
                    }

                    if (archivo.Estribos != null)
                        AplicarConfiguracionEstribosPersistenteMYG(archivo.Estribos);

                    // V11.2 - restaura el diseño gráfico completo después de los
                    // controles. Para archivos antiguos sin este campo se conserva
                    // exactamente el comportamiento previo.
                    if (!string.IsNullOrWhiteSpace(archivo.DisenoSeccionXml))
                    {
                        string errorDisenoMYG = string.Empty;

                        if (ventanaLongitudinalOrigen != null &&
                            !ventanaLongitudinalOrigen.IsDisposed)
                        {
                            if (!ventanaLongitudinalOrigen
                                    .ImportarDisenoSeccionPersistenteMYG(
                                        archivo.DisenoSeccionXml,
                                        out errorDisenoMYG))
                            {
                                throw new InvalidOperationException(
                                    "La configuración general se leyó, pero no se pudo " +
                                    "restaurar el acero dibujado en la sección.\n\n" +
                                    errorDisenoMYG);
                            }
                        }

                        // El botón CARGAR DATA vive en esta pestaña. Si el editor
                        // de estribos ya está abierto, también se reemplaza su copia
                        // local para que lo dibujado reaparezca inmediatamente.
                        if (editorSeccionIntegrado != null &&
                            !editorSeccionIntegrado.IsDisposed)
                        {
                            string errorEstribosMYG;
                            if (!editorSeccionIntegrado.ImportarDisenoXmlMYG(
                                    archivo.DisenoSeccionXml,
                                    out errorEstribosMYG))
                            {
                                throw new InvalidOperationException(
                                    "No se pudo restaurar el diseño en la pestaña de estribos.\n\n" +
                                    errorEstribosMYG);
                            }
                        }
                    }

                    // V11.32 - se restaura DESPUÉS del diseño de sección para que
                    // los GrupoId/BarraIndividualId coincidan con los aceros
                    // recién cargados. Los archivos antiguos no tienen este campo.
                    if (!string.IsNullOrWhiteSpace(
                            archivo.EstadoLongitudinalAvanzadoXml) &&
                        ventanaLongitudinalOrigen != null &&
                        !ventanaLongitudinalOrigen.IsDisposed)
                    {
                        string errorEstadoAvanzadoMYG;
                        if (!ventanaLongitudinalOrigen
                                .ImportarEstadoLongitudinalAvanzadoPersistenteMYG(
                                    archivo.EstadoLongitudinalAvanzadoXml,
                                    out errorEstadoAvanzadoMYG))
                        {
                            throw new InvalidOperationException(
                                "El diseño se cargó, pero no se pudo restaurar " +
                                "la configuración por tramos/desarrollos.\n\n" +
                                errorEstadoAvanzadoMYG);
                        }
                    }

                    SincronizarEstribosConVentanaLongitudinal();
                    NotificarPreviewEstribosActualizado();

                    lblMensaje.Text = tramos != null && tramos.Count > 0
                        ? "Data cargada y aplicada a los tramos actuales."
                        : "Data cargada. Se aplicará al seleccionar las vigas.";

                    WinForms.MessageBox.Show(
                        tramos != null && tramos.Count > 0
                            ? "La configuración y los aceros dibujados fueron cargados correctamente."
                            : "La configuración fue cargada.\n\n" +
                              "Los longitudinales ya fueron actualizados y los estribos se aplicarán al seleccionar las vigas.",
                        "MYG - Cargar data",
                        WinForms.MessageBoxButtons.OK,
                        WinForms.MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    WinForms.MessageBox.Show(
                        "No se pudo cargar la data.\n\n" + ex.Message,
                        "MYG - Cargar data",
                        WinForms.MessageBoxButtons.OK,
                        WinForms.MessageBoxIcon.Error);
                }
            }
        }

        // =========================================================
        // PERSISTENCIA LONGITUDINAL SIN DEPENDENCIAS DE COMPILACIÓN
        // =========================================================
        // Se accede a los controles y campos existentes por reflexión. De esta forma
        // AceroLongitudinalVigasForm NO necesita nuevas clases ni métodos públicos.
        private ConfiguracionLongitudinalPersistente CapturarConfiguracionLongitudinalPorReflexionMYG()
        {
            ConfiguracionLongitudinalPersistente data =
                new ConfiguracionLongitudinalPersistente();

            if (ventanaLongitudinalOrigen == null || ventanaLongitudinalOrigen.IsDisposed)
                return data;

            data.TipoSuperior = ObtenerNombreComboLongitudinalMYG("cmbTipoSuperior");
            data.TipoInferior = ObtenerNombreComboLongitudinalMYG("cmbTipoInferior");
            data.TipoCentral = ObtenerNombreComboLongitudinalMYG("cmbTipoCentral");
            data.TipoSuperiorCapa2 = ObtenerNombreComboLongitudinalMYG("cmbTipoSuperiorCapa2");
            data.TipoSuperiorCapa3 = ObtenerNombreComboLongitudinalMYG("cmbTipoSuperiorCapa3");
            data.TipoSuperiorCapa4 = ObtenerNombreComboLongitudinalMYG("cmbTipoSuperiorCapa4");
            data.TipoInferiorCapa2 = ObtenerNombreComboLongitudinalMYG("cmbTipoInferiorCapa2");
            data.TipoInferiorCapa3 = ObtenerNombreComboLongitudinalMYG("cmbTipoInferiorCapa3");
            data.TipoInferiorCapa4 = ObtenerNombreComboLongitudinalMYG("cmbTipoInferiorCapa4");

            data.CapasSuperior = ObtenerIndiceComboLongitudinalMYG("cmbCapasSuperior", 0) + 1;
            data.CapasInferior = ObtenerIndiceComboLongitudinalMYG("cmbCapasInferior", 0) + 1;

            data.CantidadSuperior = ObtenerTextoLongitudinalMYG("txtCantidadSuperior", "2");
            data.CantidadInferior = ObtenerTextoLongitudinalMYG("txtCantidadInferior", "2");
            data.CantidadSuperiorCapa2 = ObtenerTextoLongitudinalMYG("txtCantidadSuperiorCapa2", "2");
            data.CantidadSuperiorCapa3 = ObtenerTextoLongitudinalMYG("txtCantidadSuperiorCapa3", "2");
            data.CantidadSuperiorCapa4 = ObtenerTextoLongitudinalMYG("txtCantidadSuperiorCapa4", "2");
            data.CantidadInferiorCapa2 = ObtenerTextoLongitudinalMYG("txtCantidadInferiorCapa2", "2");
            data.CantidadInferiorCapa3 = ObtenerTextoLongitudinalMYG("txtCantidadInferiorCapa3", "2");
            data.CantidadInferiorCapa4 = ObtenerTextoLongitudinalMYG("txtCantidadInferiorCapa4", "2");
            data.RecubrimientoCm = ObtenerTextoLongitudinalMYG("txtRecubrimiento", "4");
            data.SeparacionCapas = ObtenerTextoLongitudinalMYG("txtSeparacionCapas", "1\"");

            data.AceroCentral = ObtenerCheckLongitudinalMYG("chkAceroCentral", false);
            data.CrearEmpalmes = ObtenerCheckLongitudinalMYG("chkCrearEmpalmes", false);
            data.UsarRNE = ObtenerCheckLongitudinalMYG("chkUsarRNE", false);
            data.LongitudEmpalmeCm = ObtenerTextoLongitudinalMYG("txtLongitudEmpalme", "60");
            data.LongitudBarraM = ObtenerTextoLongitudinalMYG("txtLongitudBarra", "9");

            data.GanchoInicio = ObtenerCheckLongitudinalMYG("chkGanchoInicio", false);
            data.GanchoFin = ObtenerCheckLongitudinalMYG("chkGanchoFin", false);
            data.LongitudGanchoInicioCm = ObtenerTextoLongitudinalMYG("txtLongitudGanchoInicio", "15");
            data.LongitudGanchoFinCm = ObtenerTextoLongitudinalMYG("txtLongitudGanchoFin", "15");
            data.LongitudDesarrolloInicioCm = ObtenerTextoLongitudinalMYG("txtLongitudDesarrolloInicio", "60");
            data.LongitudDesarrolloFinCm = ObtenerTextoLongitudinalMYG("txtLongitudDesarrolloFin", "60");
            data.DesarrolloAutomaticoInicio = ObtenerCheckLongitudinalMYG("chkDesarrolloAutomaticoInicio", false);
            data.DesarrolloAutomaticoFin = ObtenerCheckLongitudinalMYG("chkDesarrolloAutomaticoFin", false);
            data.GraficarEstribos = ObtenerCheckLongitudinalMYG("chkGraficarEstribosCreados", false);

            data.RneFcKgCm2 = ObtenerDoubleCampoLongitudinalMYG("rneFcKgCm2", 210.0);
            data.RneFyMpa = ObtenerDoubleCampoLongitudinalMYG("rneFyMpa", 420.0);
            data.RnePsiE = ObtenerDoubleCampoLongitudinalMYG("rnePsiE", 1.0);
            data.RneLambda = ObtenerDoubleCampoLongitudinalMYG("rneLambda", 1.0);
            data.RneFactorEmpalme = ObtenerDoubleCampoLongitudinalMYG("rneFactorEmpalme", 1.30);
            data.RneMinEmpalmeMm = ObtenerDoubleCampoLongitudinalMYG("rneMinEmpalmeMm", 300.0);
            data.RnePsiSuperior = ObtenerDoubleCampoLongitudinalMYG("rnePsiSuperior", 1.30);
            data.RnePsiInferior = ObtenerDoubleCampoLongitudinalMYG("rnePsiInferior", 1.00);
            data.RnePsiCentral = ObtenerDoubleCampoLongitudinalMYG("rnePsiCentral", 1.00);

            return data;
        }

        private void AplicarConfiguracionLongitudinalPorReflexionMYG(
            ConfiguracionLongitudinalPersistente data)
        {
            if (data == null ||
                ventanaLongitudinalOrigen == null ||
                ventanaLongitudinalOrigen.IsDisposed)
            {
                return;
            }

            bool estadoActualizando = ObtenerBoolCampoLongitudinalMYG("actualizandoRNE", false);
            AsignarCampoLongitudinalMYG("actualizandoRNE", true);

            try
            {
                AsignarCheckLongitudinalMYG("chkUsarRNE", false);

                SeleccionarComboLongitudinalPorNombreMYG("cmbTipoSuperior", data.TipoSuperior);
                SeleccionarComboLongitudinalPorNombreMYG("cmbTipoInferior", data.TipoInferior);
                SeleccionarComboLongitudinalPorNombreMYG("cmbTipoCentral", data.TipoCentral);
                SeleccionarComboLongitudinalPorNombreMYG("cmbTipoSuperiorCapa2", data.TipoSuperiorCapa2);
                SeleccionarComboLongitudinalPorNombreMYG("cmbTipoSuperiorCapa3", data.TipoSuperiorCapa3);
                SeleccionarComboLongitudinalPorNombreMYG("cmbTipoSuperiorCapa4", data.TipoSuperiorCapa4);
                SeleccionarComboLongitudinalPorNombreMYG("cmbTipoInferiorCapa2", data.TipoInferiorCapa2);
                SeleccionarComboLongitudinalPorNombreMYG("cmbTipoInferiorCapa3", data.TipoInferiorCapa3);
                SeleccionarComboLongitudinalPorNombreMYG("cmbTipoInferiorCapa4", data.TipoInferiorCapa4);

                AsignarIndiceComboLongitudinalMYG("cmbCapasSuperior", Math.Max(0, Math.Min(3, data.CapasSuperior - 1)));
                AsignarIndiceComboLongitudinalMYG("cmbCapasInferior", Math.Max(0, Math.Min(3, data.CapasInferior - 1)));

                AsignarTextoLongitudinalMYG("txtCantidadSuperior", data.CantidadSuperior, "2");
                AsignarTextoLongitudinalMYG("txtCantidadInferior", data.CantidadInferior, "2");
                AsignarTextoLongitudinalMYG("txtCantidadSuperiorCapa2", data.CantidadSuperiorCapa2, "2");
                AsignarTextoLongitudinalMYG("txtCantidadSuperiorCapa3", data.CantidadSuperiorCapa3, "2");
                AsignarTextoLongitudinalMYG("txtCantidadSuperiorCapa4", data.CantidadSuperiorCapa4, "2");
                AsignarTextoLongitudinalMYG("txtCantidadInferiorCapa2", data.CantidadInferiorCapa2, "2");
                AsignarTextoLongitudinalMYG("txtCantidadInferiorCapa3", data.CantidadInferiorCapa3, "2");
                AsignarTextoLongitudinalMYG("txtCantidadInferiorCapa4", data.CantidadInferiorCapa4, "2");
                AsignarTextoLongitudinalMYG("txtRecubrimiento", data.RecubrimientoCm, "4");
                AsignarTextoLongitudinalMYG(
                    "txtSeparacionCapas",
                    data.SeparacionCapas,
                    "1\"");
                AsignarTextoLongitudinalMYG("txtLongitudEmpalme", data.LongitudEmpalmeCm, "60");
                AsignarTextoLongitudinalMYG("txtLongitudBarra", data.LongitudBarraM, "9");
                AsignarTextoLongitudinalMYG("txtLongitudGanchoInicio", data.LongitudGanchoInicioCm, "15");
                AsignarTextoLongitudinalMYG("txtLongitudGanchoFin", data.LongitudGanchoFinCm, "15");
                AsignarTextoLongitudinalMYG("txtLongitudDesarrolloInicio", data.LongitudDesarrolloInicioCm, "60");
                AsignarTextoLongitudinalMYG("txtLongitudDesarrolloFin", data.LongitudDesarrolloFinCm, "60");

                AsignarCampoLongitudinalMYG("rneFcKgCm2", data.RneFcKgCm2 > 0.0 ? data.RneFcKgCm2 : 210.0);
                AsignarCampoLongitudinalMYG("rneFyMpa", data.RneFyMpa > 0.0 ? data.RneFyMpa : 420.0);
                AsignarCampoLongitudinalMYG("rnePsiE", data.RnePsiE > 0.0 ? data.RnePsiE : 1.0);
                AsignarCampoLongitudinalMYG("rneLambda", data.RneLambda > 0.0 ? data.RneLambda : 1.0);
                AsignarCampoLongitudinalMYG("rneFactorEmpalme", data.RneFactorEmpalme > 0.0 ? data.RneFactorEmpalme : 1.30);
                AsignarCampoLongitudinalMYG("rneMinEmpalmeMm", data.RneMinEmpalmeMm > 0.0 ? data.RneMinEmpalmeMm : 300.0);
                AsignarCampoLongitudinalMYG("rnePsiSuperior", data.RnePsiSuperior > 0.0 ? data.RnePsiSuperior : 1.30);
                AsignarCampoLongitudinalMYG("rnePsiInferior", data.RnePsiInferior > 0.0 ? data.RnePsiInferior : 1.00);
                AsignarCampoLongitudinalMYG("rnePsiCentral", data.RnePsiCentral > 0.0 ? data.RnePsiCentral : 1.00);

                AsignarCheckLongitudinalMYG("chkAceroCentral", data.AceroCentral);
                AsignarCheckLongitudinalMYG("chkCrearEmpalmes", data.CrearEmpalmes || data.UsarRNE);
                AsignarCheckLongitudinalMYG("chkGanchoInicio", data.GanchoInicio);
                AsignarCheckLongitudinalMYG("chkGanchoFin", data.GanchoFin);
                AsignarCheckLongitudinalMYG("chkDesarrolloAutomaticoInicio", data.DesarrolloAutomaticoInicio);
                AsignarCheckLongitudinalMYG("chkDesarrolloAutomaticoFin", data.DesarrolloAutomaticoFin);
                AsignarCheckLongitudinalMYG("chkGraficarEstribosCreados", data.GraficarEstribos);
                AsignarCheckLongitudinalMYG("chkUsarRNE", data.UsarRNE);
            }
            finally
            {
                AsignarCampoLongitudinalMYG("actualizandoRNE", estadoActualizando);
            }

            if (data.UsarRNE)
                InvocarMetodoLongitudinalMYG("CalcularYAplicarEmpalmeRNE");

            InvocarMetodoLongitudinalMYG("ActualizarVisibilidadCapasLongitudinales");
            InvocarMetodoLongitudinalMYG("ActualizarEstadoAceroCentral");
            InvocarMetodoLongitudinalMYG("ActualizarEstadoEmpalmes");
            InvocarMetodoLongitudinalMYG("ActualizarEstadoRNE");
            InvocarMetodoLongitudinalMYG("ActualizarEstadoDesarrolloPorVoladizo");
            InvocarMetodoLongitudinalMYG("ActualizarTextosDesarrolloAutomatico");
            InvocarMetodoLongitudinalMYG("RefrescarPreviewLongitudinalEnTiempoReal");
        }

        private object ObtenerCampoLongitudinalMYG(string nombre)
        {
            if (ventanaLongitudinalOrigen == null || string.IsNullOrWhiteSpace(nombre))
                return null;

            try
            {
                System.Reflection.FieldInfo campo =
                    ventanaLongitudinalOrigen.GetType().GetField(
                        nombre,
                        System.Reflection.BindingFlags.Instance |
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.NonPublic);

                return campo != null
                    ? campo.GetValue(ventanaLongitudinalOrigen)
                    : null;
            }
            catch
            {
                return null;
            }
        }

        private void AsignarCampoLongitudinalMYG(string nombre, object valor)
        {
            if (ventanaLongitudinalOrigen == null || string.IsNullOrWhiteSpace(nombre))
                return;

            try
            {
                System.Reflection.FieldInfo campo =
                    ventanaLongitudinalOrigen.GetType().GetField(
                        nombre,
                        System.Reflection.BindingFlags.Instance |
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.NonPublic);

                if (campo != null)
                    campo.SetValue(ventanaLongitudinalOrigen, valor);
            }
            catch
            {
            }
        }

        private WinForms.ComboBox ObtenerComboLongitudinalMYG(string nombre)
        {
            return ObtenerCampoLongitudinalMYG(nombre) as WinForms.ComboBox;
        }

        private WinForms.TextBox ObtenerTextBoxLongitudinalMYG(string nombre)
        {
            return ObtenerCampoLongitudinalMYG(nombre) as WinForms.TextBox;
        }

        private WinForms.CheckBox ObtenerCheckBoxLongitudinalMYG(string nombre)
        {
            return ObtenerCampoLongitudinalMYG(nombre) as WinForms.CheckBox;
        }

        private string ObtenerNombreComboLongitudinalMYG(string nombre)
        {
            WinForms.ComboBox combo = ObtenerComboLongitudinalMYG(nombre);

            if (combo == null || combo.SelectedItem == null)
                return "";

            RebarBarType tipo = combo.SelectedItem as RebarBarType;

            if (tipo != null)
            {
                try { return tipo.Name ?? ""; }
                catch { return combo.SelectedItem.ToString(); }
            }

            return combo.SelectedItem.ToString();
        }

        private int ObtenerIndiceComboLongitudinalMYG(string nombre, int respaldo)
        {
            WinForms.ComboBox combo = ObtenerComboLongitudinalMYG(nombre);
            return combo != null && combo.SelectedIndex >= 0
                ? combo.SelectedIndex
                : respaldo;
        }

        private string ObtenerTextoLongitudinalMYG(string nombre, string respaldo)
        {
            WinForms.TextBox txt = ObtenerTextBoxLongitudinalMYG(nombre);

            return txt != null && !string.IsNullOrWhiteSpace(txt.Text)
                ? txt.Text.Trim()
                : respaldo;
        }

        private bool ObtenerCheckLongitudinalMYG(string nombre, bool respaldo)
        {
            WinForms.CheckBox chk = ObtenerCheckBoxLongitudinalMYG(nombre);
            return chk != null ? chk.Checked : respaldo;
        }

        private double ObtenerDoubleCampoLongitudinalMYG(string nombre, double respaldo)
        {
            object valor = ObtenerCampoLongitudinalMYG(nombre);

            if (valor is double)
                return (double)valor;

            return respaldo;
        }

        private bool ObtenerBoolCampoLongitudinalMYG(string nombre, bool respaldo)
        {
            object valor = ObtenerCampoLongitudinalMYG(nombre);

            if (valor is bool)
                return (bool)valor;

            return respaldo;
        }

        private void SeleccionarComboLongitudinalPorNombreMYG(
            string nombreCampo,
            string nombreTipo)
        {
            WinForms.ComboBox combo = ObtenerComboLongitudinalMYG(nombreCampo);

            if (combo == null || combo.Items.Count == 0 || string.IsNullOrWhiteSpace(nombreTipo))
                return;

            for (int i = 0; i < combo.Items.Count; i++)
            {
                object item = combo.Items[i];
                string texto = "";

                RebarBarType tipo = item as RebarBarType;

                if (tipo != null)
                {
                    try { texto = tipo.Name ?? ""; }
                    catch { texto = item != null ? item.ToString() : ""; }
                }
                else
                {
                    texto = item != null ? item.ToString() : "";
                }

                if (string.Equals(
                    texto == null ? "" : texto.Trim(),
                    nombreTipo.Trim(),
                    StringComparison.OrdinalIgnoreCase))
                {
                    combo.SelectedIndex = i;
                    return;
                }
            }
        }

        private void AsignarIndiceComboLongitudinalMYG(string nombre, int indice)
        {
            WinForms.ComboBox combo = ObtenerComboLongitudinalMYG(nombre);

            if (combo == null || combo.Items.Count == 0)
                return;

            combo.SelectedIndex = Math.Max(0, Math.Min(combo.Items.Count - 1, indice));
        }

        private void AsignarTextoLongitudinalMYG(
            string nombre,
            string valor,
            string respaldo)
        {
            WinForms.TextBox txt = ObtenerTextBoxLongitudinalMYG(nombre);

            if (txt != null)
                txt.Text = string.IsNullOrWhiteSpace(valor) ? respaldo : valor.Trim();
        }

        private void AsignarCheckLongitudinalMYG(string nombre, bool valor)
        {
            WinForms.CheckBox chk = ObtenerCheckBoxLongitudinalMYG(nombre);

            if (chk != null)
                chk.Checked = valor;
        }

        private void InvocarMetodoLongitudinalMYG(string nombre)
        {
            if (ventanaLongitudinalOrigen == null || string.IsNullOrWhiteSpace(nombre))
                return;

            try
            {
                System.Reflection.MethodInfo metodo =
                    ventanaLongitudinalOrigen.GetType().GetMethod(
                        nombre,
                        System.Reflection.BindingFlags.Instance |
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.NonPublic,
                        null,
                        Type.EmptyTypes,
                        null);

                if (metodo != null)
                    metodo.Invoke(ventanaLongitudinalOrigen, null);
            }
            catch
            {
            }
        }

        private ConfiguracionEstribosPersistente CapturarConfiguracionEstribosPersistenteMYG()
        {
            ConfiguracionEstribosPersistente data =
                new ConfiguracionEstribosPersistente();

            RebarBarType tipo = TipoEstriboSeleccionado;

            if (tipo != null)
            {
                try
                {
                    data.TipoBarraEstribo = tipo.Name ?? "";
                }
                catch
                {
                    data.TipoBarraEstribo = "";
                }
            }

            data.RecubrimientoCm = txtRecubrimiento != null
                ? txtRecubrimiento.Text.Trim()
                : "4";

            data.FormaEstribo = (int)FormaEstriboSeleccionada;
            data.DetectarFormaAutomaticamente = usarFormaEstriboDesdeMain
                ? detectarFormaDesdeMain
                : chkDetectarFormaAutomaticamente != null && chkDetectarFormaAutomaticamente.Checked;

            data.CrearEstriboCentral = CrearEstriboCentral;
            data.RetiroLateralEstriboCentralCm = RetiroLateralEstriboCentralTexto;

            List<TramoInfo> tramosOrdenados = tramos == null
                ? new List<TramoInfo>()
                : tramos.Where(t => t != null).OrderBy(t => t.Index).ToList();

            foreach (TramoInfo tramo in tramosOrdenados)
            {
                TramoEstriboConfig cfg = configsPorTramo != null && configsPorTramo.ContainsKey(tramo.Index)
                    ? configsPorTramo[tramo.Index]
                    : null;

                if (cfg == null)
                    continue;

                ConfiguracionTramoEstribosPersistente item =
                    new ConfiguracionTramoEstribosPersistente();

                item.TipoDistribucion = cfg.TipoDistribucion;
                item.SeparacionesCm = cfg.SeparacionesCm != null
                    ? (double[])cfg.SeparacionesCm.Clone()
                    : new double[4];
                item.Cantidades = cfg.Cantidades != null
                    ? (int[])cfg.Cantidades.Clone()
                    : new int[4];

                data.Tramos.Add(item);
            }

            // Permite guardar una plantilla aun cuando todavía no se seleccionaron vigas.
            if (data.Tramos.Count == 0)
            {
                TramoEstriboConfig cfgActual = null;

                if (tramoSeleccionado >= 0 &&
                    configsPorTramo != null &&
                    configsPorTramo.ContainsKey(tramoSeleccionado))
                {
                    cfgActual = configsPorTramo[tramoSeleccionado];
                }

                if (cfgActual == null)
                {
                    cfgActual = new TramoEstriboConfig();
                    cfgActual.TipoDistribucion = Math.Max(1, Math.Min(4, cboTipoDistribucion.SelectedIndex + 1));

                    for (int i = 0; i < 4; i++)
                    {
                        cfgActual.SeparacionesCm[i] = numSeparacionesCm[i] != null
                            ? (double)numSeparacionesCm[i].Value
                            : 0.0;

                        cfgActual.Cantidades[i] = numCantidades[i] != null
                            ? (int)numCantidades[i].Value
                            : 0;
                    }
                }

                ConfiguracionTramoEstribosPersistente item =
                    new ConfiguracionTramoEstribosPersistente();

                item.TipoDistribucion = cfgActual.TipoDistribucion;
                item.SeparacionesCm = (double[])cfgActual.SeparacionesCm.Clone();
                item.Cantidades = (int[])cfgActual.Cantidades.Clone();
                data.Tramos.Add(item);
            }

            return data;
        }

        private void AplicarConfiguracionEstribosPersistenteMYG(
            ConfiguracionEstribosPersistente data)
        {
            if (data == null)
                return;

            SeleccionarTipoEstriboPorNombreDataMYG(data.TipoBarraEstribo);

            if (txtRecubrimiento != null)
                txtRecubrimiento.Text = string.IsNullOrWhiteSpace(data.RecubrimientoCm)
                    ? "4"
                    : data.RecubrimientoCm.Trim();

            if (chkCrearEstriboCentral != null)
                chkCrearEstriboCentral.Checked = data.CrearEstriboCentral;

            if (txtRetiroLateralEstriboCentral != null)
                txtRetiroLateralEstriboCentral.Text =
                    string.IsNullOrWhiteSpace(data.RetiroLateralEstriboCentralCm)
                        ? "15"
                        : data.RetiroLateralEstriboCentralCm.Trim();

            ActualizarEstadoEstriboCentralMYG();

            TipoFormaEstribo forma = data.FormaEstribo == (int)TipoFormaEstribo.Cumbrera
                ? TipoFormaEstribo.Cumbrera
                : TipoFormaEstribo.Rectangular;

            if (usarFormaEstriboDesdeMain)
            {
                formaEstriboDesdeMain = forma;
                detectarFormaDesdeMain = data.DetectarFormaAutomaticamente;
            }
            else
            {
                if (chkDetectarFormaAutomaticamente != null)
                    chkDetectarFormaAutomaticamente.Checked = data.DetectarFormaAutomaticamente;

                SeleccionarFormaEstribo(forma);
            }

            configuracionEstribosPendiente = ClonarConfiguracionEstribosPersistenteMYG(data);

            if (tramos != null && tramos.Count > 0)
                AplicarConfiguracionEstribosPendienteATramosMYG();

            RefrescarComboFormaEstribo();
            ActualizarControlesDesdeSeleccion();

            if (panelPreview != null)
                panelPreview.Invalidate();
        }

        private void AplicarConfiguracionEstribosPendienteATramosMYG()
        {
            if (configuracionEstribosPendiente == null ||
                tramos == null ||
                tramos.Count == 0 ||
                configuracionEstribosPendiente.Tramos == null ||
                configuracionEstribosPendiente.Tramos.Count == 0)
            {
                return;
            }

            List<ConfiguracionTramoEstribosPersistente> guardados =
                configuracionEstribosPendiente.Tramos
                    .Where(x => x != null)
                    .ToList();

            if (guardados.Count == 0)
                return;

            for (int i = 0; i < tramos.Count; i++)
            {
                ConfiguracionTramoEstribosPersistente origen =
                    i < guardados.Count
                        ? guardados[i]
                        : guardados[0];

                TramoEstriboConfig cfg = new TramoEstriboConfig();
                cfg.TipoDistribucion = Math.Max(1, Math.Min(4, origen.TipoDistribucion));

                for (int j = 0; j < 4; j++)
                {
                    double sep = origen.SeparacionesCm != null && j < origen.SeparacionesCm.Length
                        ? origen.SeparacionesCm[j]
                        : 0.0;

                    int cant = origen.Cantidades != null && j < origen.Cantidades.Length
                        ? origen.Cantidades[j]
                        : 0;

                    cfg.SeparacionesCm[j] = sep > 0.0 ? sep : 5.0;
                    cfg.Cantidades[j] = Math.Max(1, cant);
                }

                int n = Math.Max(1, Math.Min(4, cfg.TipoDistribucion));

                if (UltimaZonaEsResto(n))
                {
                    int idxResto = ObtenerIndiceUltimaZona(n);
                    cfg.Cantidades[idxResto] = CalcularCantidadRestoAuto(tramos[i], cfg);
                }

                configsPorTramo[i] = cfg;
            }

            configuracionEstribosPendiente = null;
        }

        private ConfiguracionEstribosPersistente ClonarConfiguracionEstribosPersistenteMYG(
            ConfiguracionEstribosPersistente origen)
        {
            ConfiguracionEstribosPersistente copia =
                new ConfiguracionEstribosPersistente();

            if (origen == null)
                return copia;

            copia.TipoBarraEstribo = origen.TipoBarraEstribo ?? "";
            copia.RecubrimientoCm = origen.RecubrimientoCm ?? "4";
            copia.FormaEstribo = origen.FormaEstribo;
            copia.DetectarFormaAutomaticamente = origen.DetectarFormaAutomaticamente;
            copia.CrearEstriboCentral = origen.CrearEstriboCentral;
            copia.RetiroLateralEstriboCentralCm =
                string.IsNullOrWhiteSpace(origen.RetiroLateralEstriboCentralCm)
                    ? "15"
                    : origen.RetiroLateralEstriboCentralCm;
            copia.Tramos.Clear();

            if (origen.Tramos != null)
            {
                foreach (ConfiguracionTramoEstribosPersistente item in origen.Tramos)
                {
                    if (item == null)
                        continue;

                    ConfiguracionTramoEstribosPersistente nuevo =
                        new ConfiguracionTramoEstribosPersistente();

                    nuevo.TipoDistribucion = item.TipoDistribucion;
                    nuevo.SeparacionesCm = item.SeparacionesCm != null
                        ? (double[])item.SeparacionesCm.Clone()
                        : new double[4];
                    nuevo.Cantidades = item.Cantidades != null
                        ? (int[])item.Cantidades.Clone()
                        : new int[4];

                    copia.Tramos.Add(nuevo);
                }
            }

            return copia;
        }

        private void SeleccionarTipoEstriboPorNombreDataMYG(string nombre)
        {
            if (cmbTipoEstribo == null ||
                cmbTipoEstribo.Items.Count == 0 ||
                string.IsNullOrWhiteSpace(nombre))
            {
                return;
            }

            for (int i = 0; i < cmbTipoEstribo.Items.Count; i++)
            {
                RebarBarType tipo = cmbTipoEstribo.Items[i] as RebarBarType;
                string nombreItem = "";

                if (tipo != null)
                {
                    try
                    {
                        nombreItem = tipo.Name ?? "";
                    }
                    catch
                    {
                        nombreItem = "";
                    }
                }

                if (string.Equals(
                    nombreItem.Trim(),
                    nombre.Trim(),
                    StringComparison.OrdinalIgnoreCase))
                {
                    cmbTipoEstribo.SelectedIndex = i;
                    return;
                }
            }
        }

        // =====================================
        // EVENTOS
        // =====================================
        private void PanelPreview_TramoSeleccionadoChanged(object sender, int index)
        {
            SeleccionarTramoDesdeVistaPrevia(index);
        }

        public void SeleccionarTramoDesdePreview(int index)
        {
            SeleccionarTramoDesdeVistaPrevia(index);
        }

        private void SeleccionarTramoDesdeVistaPrevia(int index)
        {
            if (index < 0 || tramos == null || index >= tramos.Count)
                return;

            if (tramoSeleccionado == index)
            {
                if (panelPreview != null)
                {
                    panelPreview.SetSeleccion(index);
                    panelPreview.Invalidate();
                }

                ActualizarControlesDesdeSeleccion();
                return;
            }

            try
            {
                // Antes de cambiar de tramo, guarda lo que el usuario haya modificado
                // en el tramo actual. Así cada tramo conserva su propia configuración.
                if (!bloqueandoEventos &&
                    tramoSeleccionado >= 0 &&
                    tramoSeleccionado < tramos.Count)
                {
                    GuardarControlesEnConfig();
                }
            }
            catch
            {
                // No interrumpir el cambio de tramo.
            }

            tramoSeleccionado = index;

            if (!configsPorTramo.ContainsKey(tramoSeleccionado))
                configsPorTramo[tramoSeleccionado] = CrearConfigPorDefecto(tramos[tramoSeleccionado].LongitudMm);

            if (panelPreview != null)
            {
                panelPreview.SetSeleccion(tramoSeleccionado);
                panelPreview.Invalidate();
            }

            ActualizarControlesDesdeSeleccion();
            DetectarYAplicarFormaEstriboAutomaticamente();
            SincronizarEstribosConVentanaLongitudinal();
            NotificarPreviewEstribosActualizado();
        }

        private void CboTipoDistribucion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (bloqueandoEventos)
                return;

            if (tramoSeleccionado < 0 || tramoSeleccionado >= tramos.Count)
                return;

            if (!configsPorTramo.ContainsKey(tramoSeleccionado))
                configsPorTramo[tramoSeleccionado] = CrearConfigPorDefecto(tramos[tramoSeleccionado].LongitudMm);

            TramoEstriboConfig cfg = configsPorTramo[tramoSeleccionado];

            cfg.TipoDistribucion = cboTipoDistribucion.SelectedIndex + 1;

            ActualizarFilasVisibles();
            RecalcularCantidadRestoSiCorresponde();
            CargarConfigEnControles(cfg);
            GuardarControlesEnConfig();
        }

        private void NumDistribucion_ValueChanged(object sender, EventArgs e)
        {
            if (bloqueandoEventos)
                return;

            GuardarControlesEnConfig();
        }

        private void BtnAplicarRNE_Click(object sender, EventArgs e)
        {
            if (tramoSeleccionado < 0 || tramoSeleccionado >= tramos.Count)
                return;

            AplicarCriterioPeruanoAlTramo(tramoSeleccionado);
            ActualizarControlesDesdeSeleccion();

            if (panelPreview != null)
                panelPreview.Invalidate();

            SincronizarEstribosConVentanaLongitudinal();

            lblMensaje.Text = "Se aplicó una distribución editable con criterio peruano al tramo seleccionado.";
        }

        private void BtnCopiarAlResto_Click(object sender, EventArgs e)
        {
            if (tramoSeleccionado < 0 || tramoSeleccionado >= tramos.Count)
                return;

            if (!configsPorTramo.ContainsKey(tramoSeleccionado))
                return;

            TramoEstriboConfig baseCfg = configsPorTramo[tramoSeleccionado].Clonar();

            foreach (TramoInfo t in tramos)
            {
                if (t == null)
                    continue;

                if (t.Index == tramoSeleccionado)
                    continue;

                configsPorTramo[t.Index] = baseCfg.Clonar();
            }

            if (panelPreview != null)
                panelPreview.Invalidate();

            SincronizarEstribosConVentanaLongitudinal();

            lblMensaje.Text = "Configuración copiada al resto de tramos.";
        }

        private void BtnRestablecerTramo_Click(object sender, EventArgs e)
        {
            if (tramoSeleccionado < 0 || tramoSeleccionado >= tramos.Count)
                return;

            configsPorTramo[tramoSeleccionado] =
                CrearConfigPorDefecto(tramos[tramoSeleccionado].LongitudMm);

            ActualizarControlesDesdeSeleccion();

            if (panelPreview != null)
                panelPreview.Invalidate();

            SincronizarEstribosConVentanaLongitudinal();

            lblMensaje.Text = "Configuración del tramo restablecida.";
        }

        public bool PrepararModeloEjecucionCombinadaMYG(out string mensaje)
        {
            mensaje = string.Empty;
            ultimaPreparacionCombinadaValidaMYG = false;
            ModeloEjecucionActual = null;
            prepararSoloEjecucionCombinadaMYG = true;

            try { BtnEjecutarEstribos_Click(this, EventArgs.Empty); }
            catch (Exception ex)
            {
                mensaje = ex.Message;
                ultimaPreparacionCombinadaValidaMYG = false;
            }
            finally { prepararSoloEjecucionCombinadaMYG = false; }

            if (!ultimaPreparacionCombinadaValidaMYG)
            {
                if (string.IsNullOrWhiteSpace(mensaje))
                    mensaje = "La configuración de estribos no pudo prepararse.";
                return false;
            }

            return ModeloEjecucionActual != null &&
                   ModeloEjecucionActual.Tramos != null &&
                   ModeloEjecucionActual.Tramos.Count > 0;
        }

        private void BtnEjecutarEstribos_Click(object sender, EventArgs e)
        {
            // Guarda la configuración actualmente visible antes de recargar tramos.
            GuardarControlesEnConfig();

            int cantidadRangosPreview = 0;

            // =========================================================
            // CLAVE:
            // Antes de ejecutar, volvemos a leer los rangos reales desde
            // la ventana longitudinal, porque ahí están los StartSerieMm,
            // EndSerieMm y TotalSerieMm correctos de la vista preliminar.
            // =========================================================
            if (ventanaLongitudinalOrigen != null && !ventanaLongitudinalOrigen.IsDisposed)
            {
                try
                {
                    List<Tuple<double, double, double>> rangosSerie =
                        ventanaLongitudinalOrigen.ObtenerRangosTramosSerieVistaPreviaMm();

                    if (rangosSerie != null && rangosSerie.Count > 0)
                    {
                        cantidadRangosPreview = rangosSerie.Count;

                        // Recarga directa desde los rangos buenos del preview.
                        CargarDesdeRangosDeSerie(rangosSerie);
                    }
                    else
                    {
                        List<double> longitudesSerie =
                            ventanaLongitudinalOrigen.ObtenerLongitudesTramosSerieVistaPreviaMm();

                        if (longitudesSerie != null && longitudesSerie.Count > 0)
                        {
                            cantidadRangosPreview = longitudesSerie.Count;

                            // Respaldo si por alguna razón no llegan rangos completos.
                            CargarDesdeLongitudesDeSerie(longitudesSerie);
                        }
                        else
                        {
                            // Último respaldo, mantiene el comportamiento anterior.
                            ActualizarDesdeVentanaLongitudinal(ventanaLongitudinalOrigen);
                        }
                    }
                }
                catch
                {
                    // Si algo falla, mantiene el comportamiento anterior.
                    ActualizarDesdeVentanaLongitudinal(ventanaLongitudinalOrigen);
                }
            }

            // Guarda de nuevo después de la recarga.
            GuardarControlesEnConfig();

            if (!ValidarConfiguraciones())
                return;

            if (TipoEstriboSeleccionado == null)
            {
                WinForms.MessageBox.Show(
                    "Debe seleccionar el tipo de barra de estribo.",
                    "MYG - Estribos",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Warning);

                return;
            }

            ModeloEjecucionActual = ConstruirModeloEjecucion();

            if (ModeloEjecucionActual == null ||
                ModeloEjecucionActual.Tramos == null ||
                ModeloEjecucionActual.Tramos.Count == 0)
            {
                WinForms.MessageBox.Show(
                    "No se pudieron cargar los tramos desde la vista preliminar.",
                    "MYG - Estribos",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Warning);

                return;
            }

            // =========================================================
            // SEGURIDAD:
            // Si la vista preliminar tiene varios tramos, pero el modelo
            // llega como un solo tramo, NO ejecuta para evitar que cree
            // todos los estribos como una sola franja continua.
            // =========================================================
            if (cantidadRangosPreview > 1 &&
                ModeloEjecucionActual.Tramos.Count <= 1)
            {
                WinForms.MessageBox.Show(
                    "La vista preliminar tiene varios tramos, pero el modelo de ejecución llegó como un solo tramo.\n\n" +
                    "No se ejecutará para evitar crear los estribos como una sola franja continua.",
                    "MYG - Estribos",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Warning);

                return;
            }

            // Guarda la distribución de estribos para que luego pueda verse
            // desde la pestaña Acero longitudinal.
            if (ventanaLongitudinalOrigen != null && !ventanaLongitudinalOrigen.IsDisposed)
            {
                ventanaLongitudinalOrigen.EstablecerEstribosCreadosPreview(
                    ObtenerPosicionesEstribosPreview());
            }

            ultimaPreparacionCombinadaValidaMYG = true;

            if (prepararSoloEjecucionCombinadaMYG)
                return;

            if (EjecutarEstribosEvent != null)
            {
                EjecutarEstribosEvent.Raise();
            }
            else
            {
                WinForms.MessageBox.Show(
                    "La configuración de estribos está lista, pero falta conectar el ExternalEvent del handler.",
                    "MYG - Estribos",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Information);
            }
        }

        private bool UltimaZonaEsResto(int tipoDistribucion)
        {
            return tipoDistribucion >= 2 && tipoDistribucion <= 4;
        }

        private int ObtenerIndiceUltimaZona(int tipoDistribucion)
        {
            return Math.Max(0, Math.Min(3, tipoDistribucion - 1));
        }

        private void ActualizarEtiquetasDeZonas()
        {
            int n = Math.Max(1, cboTipoDistribucion.SelectedIndex + 1);

            for (int i = 0; i < 4; i++)
                lblFila[i].Text = "Zona " + (i + 1);

            if (n >= 2)
            {
                for (int i = 0; i < n - 1; i++)
                    lblFila[i].Text = "Zona " + (i + 1) + " (extremos)";

                // La última fila ya no se llama Zona X: se llama RESTO.
                lblFila[n - 1].Text = "RESTO";
            }
        }

        private void ActualizarEstadoInputsCantidad()
        {
            int n = Math.Max(1, cboTipoDistribucion.SelectedIndex + 1);
            int idxResto = ObtenerIndiceUltimaZona(n);

            for (int i = 0; i < 4; i++)
            {
                // MODIFICADO:
                // Tipo 1 = Separación constante. La cantidad no debe editarse,
                // porque se calcula automáticamente como ESPACIAMIENTO MÁXIMO
                // entre 5 cm desde la cara izquierda y 5 cm antes de la cara derecha.
                bool bloqueadoPorSeparacionConstante = n == 1 && i == 0;
                bool bloqueadoPorResto = UltimaZonaEsResto(n) && i == idxResto;
                bool bloqueado = bloqueadoPorSeparacionConstante || bloqueadoPorResto;

                numCantidades[i].Enabled = !bloqueado;
                numCantidades[i].ReadOnly = bloqueado;
                numCantidades[i].BackColor = bloqueado
                    ? Drawing.Color.FromArgb(235, 235, 235)
                    : Drawing.SystemColors.Window;
            }
        }

        private int CalcularCantidadRestoAuto(TramoInfo tramo, TramoEstriboConfig cfg)
        {
            if (tramo == null || cfg == null)
                return 1;

            int n = Math.Max(1, Math.Min(4, cfg.TipoDistribucion));

            if (!UltimaZonaEsResto(n))
                return Math.Max(1, cfg.Cantidades[0]);

            int idxResto = ObtenerIndiceUltimaZona(n);
            double sepResto = cfg.SeparacionesCm[idxResto];

            if (sepResto <= 0.0)
                return 1;

            double Lcm = Math.Max(0.0, tramo.LongitudMm / 10.0);

            if (Lcm <= 0.0)
                return 1;

            // Se trabaja desde ambos extremos del tramo.
            // Zona 1: arranca a 5 cm de la cara.
            // Zona 2, 3, etc.: arrancan con su propia separación
            // respecto al último estribo colocado en el extremo correspondiente.
            double ultimoIzqCm = OFFSET_PRIMER_ESTRIBO_CM;
            double ultimoDerCm = Lcm - OFFSET_PRIMER_ESTRIBO_CM;
            bool hayZonaExtremo = false;

            for (int zona = 0; zona < n - 1; zona++)
            {
                double sepCm = cfg.SeparacionesCm[zona];
                int cantidad = cfg.Cantidades[zona];

                if (sepCm <= 0.0 || cantidad <= 0)
                    continue;

                double primerIzqCm = hayZonaExtremo
                    ? ultimoIzqCm + sepCm
                    : OFFSET_PRIMER_ESTRIBO_CM;

                double primerDerCm = hayZonaExtremo
                    ? ultimoDerCm - sepCm
                    : Lcm - OFFSET_PRIMER_ESTRIBO_CM;

                int cantidadUsada = AjustarCantidadSimetricaCm(
                    cantidad,
                    sepCm,
                    primerIzqCm,
                    primerDerCm);

                if (cantidadUsada <= 0)
                    break;

                ultimoIzqCm = primerIzqCm + ((cantidadUsada - 1) * sepCm);
                ultimoDerCm = primerDerCm - ((cantidadUsada - 1) * sepCm);
                hayZonaExtremo = true;
            }

            // RESTO:
            // El espaciado máximo debe calcularse con TODO el rango central
            // disponible entre el último estribo fijo izquierdo y el último
            // estribo fijo derecho.
            // No se adelanta 30 cm desde cada extremo del RESTO.
            double inicioRestoCm = hayZonaExtremo
                ? ultimoIzqCm
                : OFFSET_PRIMER_ESTRIBO_CM;

            double finRestoCm = hayZonaExtremo
                ? ultimoDerCm
                : Lcm - OFFSET_PRIMER_ESTRIBO_CM;

            int cantidadTotalRango = CalcularCantidadEspaciamientoMaximo(
                inicioRestoCm,
                finRestoCm,
                sepResto);

            // Si ya existen barras en los extremos por las zonas anteriores,
            // la fila RESTO muestra solo las barras interiores nuevas.
            if (hayZonaExtremo)
                return Math.Max(1, cantidadTotalRango - 2);

            return cantidadTotalRango;
        }

        private int AjustarCantidadSimetricaCm(
            int cantidadSolicitada,
            double separacionCm,
            double primerIzqCm,
            double primerDerCm)
        {
            if (cantidadSolicitada <= 0)
                return 0;

            if (separacionCm <= 0.0)
                return 0;

            if (primerDerCm < primerIzqCm)
                return 0;

            double disponibleCm = primerDerCm - primerIzqCm;

            if (disponibleCm <= 1e-6)
                return 1;

            // Como la misma zona se coloca a ambos extremos,
            // se limita la cantidad para que los bloques no se crucen.
            int cantidadMaxima = Math.Max(
                1,
                (int)Math.Floor((disponibleCm + 1e-6) / (2.0 * separacionCm)) + 1);

            return Math.Max(1, Math.Min(cantidadSolicitada, cantidadMaxima));
        }

        private int CalcularCantidadSeparacionConstanteAuto(TramoInfo tramo, TramoEstriboConfig cfg)
        {
            if (tramo == null || cfg == null)
                return 1;

            double sepCm = cfg.SeparacionesCm[0];

            if (sepCm <= 0.0)
                return 1;

            double Lcm = Math.Max(0.0, tramo.LongitudMm / 10.0);

            // Tipo 1 trabaja como ESPACIAMIENTO MÁXIMO:
            // desde 5 cm de la cara izquierda hasta 5 cm antes de la cara derecha.
            double inicioCm = OFFSET_PRIMER_ESTRIBO_CM;
            double finCm = Lcm - OFFSET_PRIMER_ESTRIBO_CM;

            return CalcularCantidadEspaciamientoMaximo(inicioCm, finCm, sepCm);
        }

        private int CalcularCantidadEspaciamientoMaximo(
            double inicioCm,
            double finCm,
            double separacionMaximaCm)
        {
            if (separacionMaximaCm <= 0.0)
                return 1;

            if (finCm < inicioCm)
                return 1;

            double longitudCm = finCm - inicioCm;

            if (longitudCm <= 1e-6)
                return 1;

            return Math.Max(2, (int)Math.Ceiling(longitudCm / separacionMaximaCm) + 1);
        }

        private void RecalcularCantidadRestoSiCorresponde()
        {
            if (tramoSeleccionado < 0 || tramoSeleccionado >= tramos.Count)
                return;

            if (!configsPorTramo.ContainsKey(tramoSeleccionado))
                return;

            TramoEstriboConfig cfg = configsPorTramo[tramoSeleccionado];
            int n = Math.Max(1, Math.Min(4, cfg.TipoDistribucion));

            // MODIFICADO:
            // Tipo 1 = separación constante con regla de ESPACIAMIENTO MÁXIMO.
            // Por eso la cantidad es automática y no editable.
            if (n == 1)
            {
                cfg.Cantidades[0] = CalcularCantidadSeparacionConstanteAuto(
                    tramos[tramoSeleccionado],
                    cfg);

                return;
            }

            if (!UltimaZonaEsResto(n))
                return;

            int idxResto = ObtenerIndiceUltimaZona(n);
            cfg.Cantidades[idxResto] = CalcularCantidadRestoAuto(tramos[tramoSeleccionado], cfg);
        }

        // =====================================
        // LÓGICA DE CONTROLES
        // =====================================
        private void ActualizarControlesDesdeSeleccion()
        {
            bloqueandoEventos = true;

            if (tramoSeleccionado < 0 || tramoSeleccionado >= tramos.Count)
            {
                lblTramoActual.Text = "Tramo seleccionado: -";
                lblLuzActual.Text = "Luz libre: -";
                lblResumenOcupacion.Text = "Longitud ocupada: -";
                lblMensaje.Text = "Seleccione vigas en la primera pestaña para cargar los tramos.";

                if (cboTipoDistribucion.Items.Count > 0)
                    cboTipoDistribucion.SelectedIndex = 0;

                for (int i = 0; i < 4; i++)
                {
                    numSeparacionesCm[i].Value = 1;
                    numCantidades[i].Value = 1;
                }

                ActualizarFilasVisibles();
                bloqueandoEventos = false;
                return;
            }

            TramoInfo tramo = tramos[tramoSeleccionado];

            if (!configsPorTramo.ContainsKey(tramoSeleccionado))
                configsPorTramo[tramoSeleccionado] = CrearConfigPorDefecto(tramo.LongitudMm);

            TramoEstriboConfig cfg = configsPorTramo[tramoSeleccionado];

            lblTramoActual.Text = "Tramo seleccionado: " + tramo.Nombre;
            lblLuzActual.Text = "Luz libre: " + FormatearMmAMetros(tramo.LongitudMm);

            int idx = Math.Max(0, Math.Min(3, cfg.TipoDistribucion - 1));

            if (cboTipoDistribucion.Items.Count > 0)
                cboTipoDistribucion.SelectedIndex = idx;

            RecalcularCantidadRestoSiCorresponde();
            ActualizarFilasVisibles();
            CargarConfigEnControles(cfg);
            ActualizarResumenOcupacion();

            lblMensaje.Text = cfg.TipoDistribucion == 1
                ? "Edite solo la separación. La cantidad se calcula con Espaciamiento máximo entre 5 cm de cada cara."
                : "Edite separación y cantidad. La fila RESTO se calcula automáticamente.";

            bloqueandoEventos = false;
        }

        private void CargarConfigEnControles(TramoEstriboConfig cfg)
        {
            if (cfg == null)
                return;

            for (int i = 0; i < 4; i++)
            {
                decimal sep = (decimal)Math.Max(1.0, cfg.SeparacionesCm[i] <= 0.0 ? 1.0 : cfg.SeparacionesCm[i]);
                decimal cant = Math.Max(1, cfg.Cantidades[i] <= 0 ? 1 : cfg.Cantidades[i]);

                if (sep < numSeparacionesCm[i].Minimum)
                    sep = numSeparacionesCm[i].Minimum;

                if (sep > numSeparacionesCm[i].Maximum)
                    sep = numSeparacionesCm[i].Maximum;

                if (cant < numCantidades[i].Minimum)
                    cant = numCantidades[i].Minimum;

                if (cant > numCantidades[i].Maximum)
                    cant = numCantidades[i].Maximum;

                numSeparacionesCm[i].Value = sep;
                numCantidades[i].Value = cant;
            }
        }

        private void GuardarControlesEnConfig()
        {
            if (tramoSeleccionado < 0 || tramoSeleccionado >= tramos.Count)
                return;

            if (!configsPorTramo.ContainsKey(tramoSeleccionado))
                configsPorTramo[tramoSeleccionado] = CrearConfigPorDefecto(tramos[tramoSeleccionado].LongitudMm);

            TramoEstriboConfig cfg = configsPorTramo[tramoSeleccionado];

            cfg.TipoDistribucion = cboTipoDistribucion.SelectedIndex + 1;

            for (int i = 0; i < 4; i++)
            {
                cfg.SeparacionesCm[i] = (double)numSeparacionesCm[i].Value;
                cfg.Cantidades[i] = (int)numCantidades[i].Value;
            }

            RecalcularCantidadRestoSiCorresponde();

            bloqueandoEventos = true;
            CargarConfigEnControles(cfg);
            bloqueandoEventos = false;

            ActualizarEstadoInputsCantidad();
            ActualizarResumenOcupacion();

            if (panelPreview != null)
            {
                panelPreview.CargarDatos(tramos, configsPorTramo);
                panelPreview.SetSeleccion(tramoSeleccionado);
                panelPreview.Invalidate();
            }

            SincronizarEstribosConVentanaLongitudinal();
        }

        private void ActualizarFilasVisibles()
        {
            int n = Math.Max(1, cboTipoDistribucion.SelectedIndex + 1);

            for (int i = 0; i < 4; i++)
            {
                bool visible = i < n;

                lblFila[i].Visible = visible;
                lblSep[i].Visible = visible;
                numSeparacionesCm[i].Visible = visible;
                lblCant[i].Visible = visible;
                numCantidades[i].Visible = visible;

                int baseIndex = i * 7;

                if (panelFilasDistribucion.Controls.Count >= baseIndex + 7)
                {
                    panelFilasDistribucion.Controls[baseIndex + 3].Visible = visible;
                    panelFilasDistribucion.Controls[baseIndex + 6].Visible = visible;
                }
            }

            ActualizarEtiquetasDeZonas();
            ActualizarEstadoInputsCantidad();
        }

        private void ActualizarResumenOcupacion()
        {
            if (tramoSeleccionado < 0 || tramoSeleccionado >= tramos.Count)
            {
                lblResumenOcupacion.Text = "Longitud ocupada: -";
                return;
            }

            if (!configsPorTramo.ContainsKey(tramoSeleccionado))
                return;

            TramoEstriboConfig cfg = configsPorTramo[tramoSeleccionado];

            double luzCm = tramos[tramoSeleccionado].LongitudMm / 10.0;
            double ocupadaCm = CalcularLongitudOcupadaCm(cfg);

            lblResumenOcupacion.Text =
                "Long. ocupada: " +
                (ocupadaCm / 100.0).ToString("0.###") +
                " m / Luz: " +
                (luzCm / 100.0).ToString("0.###") +
                " m";

            if (ocupadaCm <= luzCm + 0.1)
            {
                lblResumenOcupacion.ForeColor = Drawing.Color.FromArgb(0, 120, 0);
                lblMensaje.Text = "La distribución cabe dentro del tramo.";
            }
            else
            {
                lblResumenOcupacion.ForeColor = Drawing.Color.Firebrick;
                lblMensaje.Text = "La distribución supera la longitud del tramo.";
            }
        }

        private double CalcularLongitudOcupadaCm(TramoEstriboConfig cfg)
        {
            if (cfg == null)
                return 0.0;

            if (tramoSeleccionado < 0 || tramoSeleccionado >= tramos.Count)
                return 0.0;

            double luzCm = tramos[tramoSeleccionado].LongitudMm / 10.0;
            int n = Math.Max(1, Math.Min(4, cfg.TipoDistribucion));

            // Tipo 1 ocupa el tramo desde 5 cm de cada extremo.
            if (n == 1)
                return Math.Max(0.0, luzCm - 2.0 * OFFSET_PRIMER_ESTRIBO_CM);

            // Con RESTO la distribución final cubre la zona central disponible.
            return luzCm;
        }

        private bool ValidarConfiguraciones()
        {
            if (tramos == null || tramos.Count == 0)
            {
                WinForms.MessageBox.Show(
                    "No hay tramos cargados. Primero seleccione vigas en la pestaña Seleccionar vigas.",
                    "MYG - Estribos",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Warning);

                return false;
            }

            foreach (TramoInfo tramo in tramos)
            {
                if (tramo == null)
                    continue;

                if (!configsPorTramo.ContainsKey(tramo.Index))
                    return false;

                TramoEstriboConfig cfg = configsPorTramo[tramo.Index];
                int n = Math.Max(1, Math.Min(4, cfg.TipoDistribucion));

                for (int i = 0; i < n; i++)
                {
                    if (cfg.SeparacionesCm[i] <= 0.0 || cfg.Cantidades[i] <= 0)
                    {
                        WinForms.MessageBox.Show(
                            "Revise separación y cantidad de " +
                            (UltimaZonaEsResto(n) && i == n - 1 ? "RESTO" : "la zona " + (i + 1)) +
                            " del tramo " + (tramo.Index + 1) + ".",
                            "MYG - Estribos",
                            WinForms.MessageBoxButtons.OK,
                            WinForms.MessageBoxIcon.Warning);

                        return false;
                    }
                }
            }

            return true;
        }

        private ModeloEstribosVigas ConstruirModeloEjecucion()
        {
            ModeloEstribosVigas modelo = new ModeloEstribosVigas();

            modelo.Tramos = tramos
                .Select(t => new TramoInfo(
                    t.Index,
                    t.LongitudMm,
                    t.ApoyoIzqMm,
                    t.ApoyoDerMm,
                    t.Nombre,
                    t.StartSerieMm,
                    t.EndSerieMm,
                    t.TotalSerieMm))
                .ToList();

            foreach (KeyValuePair<int, TramoEstriboConfig> kv in configsPorTramo)
                modelo.Configuraciones[kv.Key] = kv.Value.Clonar();

            return modelo;
        }

        public Dictionary<int, TramoEstriboConfig> ObtenerConfiguraciones()
        {
            Dictionary<int, TramoEstriboConfig> resultado =
                new Dictionary<int, TramoEstriboConfig>();

            foreach (KeyValuePair<int, TramoEstriboConfig> kv in configsPorTramo)
                resultado[kv.Key] = kv.Value.Clonar();

            return resultado;
        }

        public Dictionary<int, List<Tuple<double, int>>> ObtenerPosicionesEstribosPreview()
        {
            Dictionary<int, List<Tuple<double, int>>> resultado =
                new Dictionary<int, List<Tuple<double, int>>>();

            foreach (TramoInfo tramo in tramos)
            {
                if (tramo == null)
                    continue;

                if (!configsPorTramo.ContainsKey(tramo.Index))
                    continue;

                TramoEstriboConfig cfg = configsPorTramo[tramo.Index];
                resultado[tramo.Index] = CalcularPosicionesEstribosTramo(tramo, cfg);
            }

            return resultado;
        }

        private List<Tuple<double, int>> CalcularPosicionesEstribosTramo(
            TramoInfo tramo,
            TramoEstriboConfig cfg)
        {
            List<Tuple<double, int>> posiciones = new List<Tuple<double, int>>();

            if (tramo == null || cfg == null)
                return posiciones;

            double Lcm = Math.Max(0.0, tramo.LongitudMm / 10.0);
            int n = Math.Max(1, Math.Min(4, cfg.TipoDistribucion));

            if (Lcm <= 0.0)
                return posiciones;

            if (n == 1)
            {
                // Separación constante: se usa como ESPACIAMIENTO MÁXIMO,
                // siempre desde 5 cm de la cara inicial hasta 5 cm antes de la cara final.
                AgregarZonaResto(
                    posiciones,
                    OFFSET_PRIMER_ESTRIBO_CM,
                    Lcm - OFFSET_PRIMER_ESTRIBO_CM,
                    cfg.SeparacionesCm[0],
                    0);

                return OrdenarYDepurar(posiciones, Lcm);
            }

            double ultimoIzqCm = OFFSET_PRIMER_ESTRIBO_CM;
            double ultimoDerCm = Lcm - OFFSET_PRIMER_ESTRIBO_CM;
            bool hayZonaExtremo = false;

            for (int zona = 0; zona < n - 1; zona++)
            {
                double sepCm = cfg.SeparacionesCm[zona];
                int cantidad = cfg.Cantidades[zona];

                if (sepCm <= 0.0 || cantidad <= 0)
                    continue;

                // CLAVE:
                // La primera zona arranca a 5 cm de la cara.
                // Las zonas siguientes arrancan con SU PROPIA separación
                // desde el último estribo anterior, no con la separación anterior.
                double primerIzqCm = hayZonaExtremo
                    ? ultimoIzqCm + sepCm
                    : OFFSET_PRIMER_ESTRIBO_CM;

                double primerDerCm = hayZonaExtremo
                    ? ultimoDerCm - sepCm
                    : Lcm - OFFSET_PRIMER_ESTRIBO_CM;

                int cantidadUsada = AjustarCantidadSimetricaCm(
                    cantidad,
                    sepCm,
                    primerIzqCm,
                    primerDerCm);

                if (cantidadUsada <= 0)
                    break;

                AgregarZonaBloque(
                    posiciones,
                    primerIzqCm,
                    sepCm,
                    cantidadUsada,
                    zona);

                AgregarZonaBloqueInvertida(
                    posiciones,
                    primerDerCm,
                    sepCm,
                    cantidadUsada,
                    zona);

                ultimoIzqCm = primerIzqCm + ((cantidadUsada - 1) * sepCm);
                ultimoDerCm = primerDerCm - ((cantidadUsada - 1) * sepCm);
                hayZonaExtremo = true;
            }

            int idxResto = n - 1;
            double sepRestoCm = cfg.SeparacionesCm[idxResto];

            // RESTO:
            // Primero se calcula el espaciamiento real con TODO el rango central
            // disponible entre el último estribo fijo izquierdo y el último fijo derecho.
            // Luego el rango que se grafica/crea para el RESTO empieza en el PRIMER
            // espaciamiento interior y termina en el PENÚLTIMO espaciamiento interior,
            // tal como indicó el usuario en las flechas.
            double inicioRestoCm = hayZonaExtremo
                ? ultimoIzqCm
                : OFFSET_PRIMER_ESTRIBO_CM;

            double finRestoCm = hayZonaExtremo
                ? ultimoDerCm
                : Lcm - OFFSET_PRIMER_ESTRIBO_CM;

            if (hayZonaExtremo)
            {
                int cantidadTotalRango = CalcularCantidadEspaciamientoMaximo(
                    inicioRestoCm,
                    finRestoCm,
                    sepRestoCm);

                if (cantidadTotalRango > 2)
                {
                    double separacionRealCm = (finRestoCm - inicioRestoCm) / (cantidadTotalRango - 1);
                    double inicioRestoInteriorCm = inicioRestoCm + separacionRealCm;
                    double finRestoInteriorCm = finRestoCm - separacionRealCm;

                    AgregarZonaResto(
                        posiciones,
                        inicioRestoInteriorCm,
                        finRestoInteriorCm,
                        sepRestoCm,
                        idxResto,
                        true,
                        true);
                }
            }
            else
            {
                AgregarZonaResto(
                    posiciones,
                    inicioRestoCm,
                    finRestoCm,
                    sepRestoCm,
                    idxResto,
                    true,
                    true);
            }

            return OrdenarYDepurar(posiciones, Lcm);
        }

        private double LongitudBloqueCm(TramoEstriboConfig cfg, int index)
        {
            if (cfg == null || index < 0 || index >= 4)
                return 0.0;

            double sep = cfg.SeparacionesCm[index];
            int cant = cfg.Cantidades[index];

            if (sep <= 0.0 || cant <= 0)
                return 0.0;

            return sep * cant;
        }

        private void AgregarZonaBloque(
            List<Tuple<double, int>> pos,
            double inicioCm,
            double sepCm,
            int cantidad,
            int zona)
        {
            if (pos == null || sepCm <= 0.0 || cantidad <= 0)
                return;

            for (int k = 0; k < cantidad; k++)
                pos.Add(Tuple.Create((inicioCm + k * sepCm) * 10.0, zona));
        }

        private void AgregarZonaBloqueInvertida(
            List<Tuple<double, int>> pos,
            double finCm,
            double sepCm,
            int cantidad,
            int zona)
        {
            if (pos == null || sepCm <= 0.0 || cantidad <= 0)
                return;

            for (int k = 0; k < cantidad; k++)
                pos.Add(Tuple.Create((finCm - k * sepCm) * 10.0, zona));
        }

        private void AgregarZonaResto(
            List<Tuple<double, int>> pos,
            double inicioCm,
            double finCm,
            double sepCm,
            int zona,
            bool incluirPrimeraBarra = true,
            bool incluirUltimaBarra = true)
        {
            if (pos == null || sepCm <= 0.0)
                return;

            if (finCm < inicioCm)
                return;

            // La zona RESTO y el Tipo 1 se grafican como ESPACIAMIENTO MÁXIMO.
            // PERO cuando ya existen barras fijas en los extremos del rango
            // (zonas anteriores), la separación real debe calcularse con TODO
            // el rango disponible y luego crear solo las barras interiores
            // para no superponerlas con esas barras fijas.
            int cantidad = CalcularCantidadEspaciamientoMaximo(
                inicioCm,
                finCm,
                sepCm);

            if (cantidad <= 1)
            {
                if (incluirPrimeraBarra || incluirUltimaBarra)
                    pos.Add(Tuple.Create(inicioCm * 10.0, zona));

                return;
            }

            double separacionRealCm = (finCm - inicioCm) / (cantidad - 1);

            int indiceInicio = incluirPrimeraBarra ? 0 : 1;
            int indiceFinExclusivo = incluirUltimaBarra ? cantidad : cantidad - 1;

            if (indiceFinExclusivo <= indiceInicio)
                return;

            for (int k = indiceInicio; k < indiceFinExclusivo; k++)
            {
                double x = inicioCm + k * separacionRealCm;

                if (k == cantidad - 1)
                    x = finCm;

                pos.Add(Tuple.Create(x * 10.0, zona));
            }
        }

        private List<Tuple<double, int>> OrdenarYDepurar(
            List<Tuple<double, int>> pos,
            double longitudTramoCm)
        {
            List<Tuple<double, int>> limpio = new List<Tuple<double, int>>();

            if (pos == null || pos.Count == 0)
                return limpio;

            double minMm = 0.0;
            double maxMm = longitudTramoCm * 10.0;

            foreach (Tuple<double, int> t in pos.OrderBy(x => x.Item1))
            {
                if (t == null)
                    continue;

                double xMm = t.Item1;
                if (xMm < minMm - 1.0 || xMm > maxMm + 1.0)
                    continue;

                if (limpio.Count > 0 && Math.Abs(limpio[limpio.Count - 1].Item1 - xMm) < 1.0)
                    continue;

                limpio.Add(Tuple.Create(Math.Max(minMm, Math.Min(maxMm, xMm)), t.Item2));
            }

            return limpio;
        }

        private List<Drawing.RectangleF> ObtenerHitBoxesTramosMismaVista(
            Drawing.Rectangle area)
        {
            if (ventanaLongitudinalOrigen != null &&
                !ventanaLongitudinalOrigen.IsDisposed)
            {
                try
                {
                    List<Drawing.RectangleF> rects =
                        ventanaLongitudinalOrigen.ObtenerHitBoxesTramosVistaPreviaComun(area);

                    if (rects != null && rects.Count > 0)
                        return rects;
                }
                catch
                {
                    // Si falla, usa respaldo proporcional.
                }
            }

            return ObtenerHitBoxesTramosFallback(area);
        }

        private List<Drawing.RectangleF> ObtenerHitBoxesTramosFallback(
            Drawing.Rectangle area)
        {
            List<Drawing.RectangleF> rects =
                new List<Drawing.RectangleF>();

            if (tramos == null || tramos.Count == 0)
                return rects;

            double total = tramos.Sum(t => t.LongitudMm);

            if (total <= 0.0)
                return rects;

            float margenX = 40f;
            float ancho = Math.Max(100f, area.Width - 68f);
            float y = 20f;
            float h = Math.Max(80f, area.Height - 40f);
            float cursor = margenX;

            foreach (TramoInfo t in tramos)
            {
                float w = (float)(ancho * (t.LongitudMm / total));

                if (w < 5f)
                    w = 5f;

                rects.Add(new Drawing.RectangleF(cursor, y, w, h));
                cursor += w;
            }

            return rects;
        }

        private string FormatearMmAMetros(double mm)
        {
            return (mm / 1000.0).ToString("0.###") + " m";
        }

        // =====================================
        // PANEL DE VISTA PRELIMINAR
        // =====================================
        private class VistaPreviaEstribosPanel : WinForms.Panel
        {
            public AceroEstribosVigasForm Owner;
            public event EventHandler<int> TramoSeleccionadoChanged;

            private List<TramoInfo> tramos =
                new List<TramoInfo>();

            private Dictionary<int, TramoEstriboConfig> configs =
                new Dictionary<int, TramoEstriboConfig>();

            private int seleccionado = -1;
            private List<Drawing.RectangleF> hitTramos =
                new List<Drawing.RectangleF>();

            // =====================================
            // NAVEGACIÓN 2D EN VISTA PRELIMINAR
            // Pan: arrastrar con clic izquierdo, medio o derecho.
            // Zoom: rueda del mouse hacia la posición del cursor.
            // Doble clic: reset de zoom/pan.
            // =====================================
            private const float PREVIEW_ZOOM_MIN = 0.35f;
            private const float PREVIEW_ZOOM_MAX = 6.00f;

            private float previewZoom = 1.0f;
            private float previewPanX = 0.0f;
            private float previewPanY = 0.0f;

            private bool previewPanActivo = false;
            private Drawing.Point previewPanUltimoPunto = Drawing.Point.Empty;
            private int previewPanMovimientoAcumulado = 0;
            private bool ignorarProximoClickSeleccion = false;

            public VistaPreviaEstribosPanel()
            {
                this.DoubleBuffered = true;
                this.Cursor = WinForms.Cursors.Hand;
                this.TabStop = true;

                this.SetStyle(
                    WinForms.ControlStyles.AllPaintingInWmPaint |
                    WinForms.ControlStyles.OptimizedDoubleBuffer |
                    WinForms.ControlStyles.ResizeRedraw |
                    WinForms.ControlStyles.UserPaint,
                    true);

                this.MouseEnter += VistaPreviaEstribosPanel_MouseEnter;
                this.MouseWheel += VistaPreviaEstribosPanel_MouseWheel;
                this.MouseDown += VistaPreviaEstribosPanel_MouseDown;
                this.MouseMove += VistaPreviaEstribosPanel_MouseMove;
                this.MouseUp += VistaPreviaEstribosPanel_MouseUp;
                this.MouseLeave += VistaPreviaEstribosPanel_MouseLeave;
                this.MouseDoubleClick += VistaPreviaEstribosPanel_MouseDoubleClick;
                this.MouseClick += VistaPreviaEstribosPanel_MouseClick;
            }

            public void CargarDatos(
                List<TramoInfo> tramosData,
                Dictionary<int, TramoEstriboConfig> configsData)
            {
                tramos = tramosData ?? new List<TramoInfo>();
                configs = configsData ?? new Dictionary<int, TramoEstriboConfig>();
                hitTramos.Clear();
                this.Invalidate();
            }

            public void SetSeleccion(int index)
            {
                seleccionado = index;
                this.Invalidate();
            }

            private void VistaPreviaEstribosPanel_MouseEnter(object sender, EventArgs e)
            {
                try
                {
                    this.Focus();
                }
                catch
                {
                    // No interrumpir.
                }
            }

            private void VistaPreviaEstribosPanel_MouseWheel(object sender, WinForms.MouseEventArgs e)
            {
                float zoomAnterior = previewZoom;
                float factor = e.Delta > 0 ? 1.15f : 1.0f / 1.15f;

                previewZoom *= factor;

                if (previewZoom < PREVIEW_ZOOM_MIN)
                    previewZoom = PREVIEW_ZOOM_MIN;

                if (previewZoom > PREVIEW_ZOOM_MAX)
                    previewZoom = PREVIEW_ZOOM_MAX;

                if (Math.Abs(zoomAnterior) > 0.0001f)
                {
                    float ratio = previewZoom / zoomAnterior;

                    // Zoom hacia el cursor, igual que en la vista preliminar longitudinal.
                    previewPanX = e.X - (e.X - previewPanX) * ratio;
                    previewPanY = e.Y - (e.Y - previewPanY) * ratio;
                }

                WinForms.HandledMouseEventArgs handled =
                    e as WinForms.HandledMouseEventArgs;

                if (handled != null)
                    handled.Handled = true;

                this.Invalidate();
            }

            private void VistaPreviaEstribosPanel_MouseDown(object sender, WinForms.MouseEventArgs e)
            {
                if (e.Button == WinForms.MouseButtons.Left ||
                    e.Button == WinForms.MouseButtons.Middle ||
                    e.Button == WinForms.MouseButtons.Right)
                {
                    previewPanActivo = true;
                    previewPanUltimoPunto = e.Location;
                    previewPanMovimientoAcumulado = 0;
                    ignorarProximoClickSeleccion = false;

                    this.Cursor = WinForms.Cursors.SizeAll;

                    try
                    {
                        this.Focus();
                    }
                    catch
                    {
                        // No interrumpir.
                    }
                }
            }

            private void VistaPreviaEstribosPanel_MouseMove(object sender, WinForms.MouseEventArgs e)
            {
                if (!previewPanActivo)
                    return;

                int dx = e.X - previewPanUltimoPunto.X;
                int dy = e.Y - previewPanUltimoPunto.Y;

                if (dx == 0 && dy == 0)
                    return;

                previewPanX += dx;
                previewPanY += dy;
                previewPanUltimoPunto = e.Location;

                previewPanMovimientoAcumulado += Math.Abs(dx) + Math.Abs(dy);

                if (previewPanMovimientoAcumulado > 12)
                    ignorarProximoClickSeleccion = true;

                this.Invalidate();
            }

            private void VistaPreviaEstribosPanel_MouseUp(object sender, WinForms.MouseEventArgs e)
            {
                previewPanActivo = false;
                this.Cursor = WinForms.Cursors.Hand;
            }

            private void VistaPreviaEstribosPanel_MouseLeave(object sender, EventArgs e)
            {
                previewPanActivo = false;
                this.Cursor = WinForms.Cursors.Hand;
            }

            private void VistaPreviaEstribosPanel_MouseDoubleClick(object sender, WinForms.MouseEventArgs e)
            {
                ResetearNavegacionVistaPrevia();
            }

            private void ResetearNavegacionVistaPrevia()
            {
                previewZoom = 1.0f;
                previewPanX = 0.0f;
                previewPanY = 0.0f;
                previewPanActivo = false;
                previewPanUltimoPunto = Drawing.Point.Empty;
                previewPanMovimientoAcumulado = 0;
                ignorarProximoClickSeleccion = false;

                this.Invalidate();
            }

            private void AplicarTransformacionNavegacion(Drawing.Graphics g)
            {
                if (g == null)
                    return;

                g.TranslateTransform(previewPanX, previewPanY);
                g.ScaleTransform(previewZoom, previewZoom);
            }

            private Drawing.PointF ConvertirPantallaAPreview(Drawing.Point puntoPantalla)
            {
                if (Math.Abs(previewZoom) <= 0.0001f)
                    return new Drawing.PointF(puntoPantalla.X, puntoPantalla.Y);

                return new Drawing.PointF(
                    (puntoPantalla.X - previewPanX) / previewZoom,
                    (puntoPantalla.Y - previewPanY) / previewZoom);
            }

            private void VistaPreviaEstribosPanel_MouseClick(object sender, WinForms.MouseEventArgs e)
            {
                if (e.Button != WinForms.MouseButtons.Left)
                    return;

                if (ignorarProximoClickSeleccion)
                {
                    ignorarProximoClickSeleccion = false;
                    return;
                }

                SeleccionarTramoPorPunto(e.Location);
            }

            private void SeleccionarTramoPorPunto(Drawing.Point puntoPantalla)
            {
                if (hitTramos == null || hitTramos.Count == 0)
                    ConstruirHitBoxes();

                Drawing.PointF puntoPreview =
                    ConvertirPantallaAPreview(puntoPantalla);

                int nuevoSeleccionado = -1;

                // 1) Intento exacto: clic dentro del polígono real de la viga/tramo.
                for (int i = 0; i < hitTramos.Count; i++)
                {
                    Drawing.PointF[] poligonoVisual = ObtenerPoligonoVisualTramo(i);

                    if (PuntoDentroDePoligono(puntoPreview, poligonoVisual))
                    {
                        nuevoSeleccionado = i;
                        break;
                    }
                }

                // 2) Intento flexible: rango X del tramo + banda vertical de la viga.
                if (nuevoSeleccionado < 0)
                    nuevoSeleccionado = ObtenerTramoPorRangoXDeClick(puntoPreview);

                // 3) Intento final: solo por estación X de la serie.
                // Esto permite seleccionar cualquier tramo aunque se haga clic sobre
                // estribos, cotas cercanas o cuando el tramo visual queda muy delgado.
                if (nuevoSeleccionado < 0)
                    nuevoSeleccionado = ObtenerTramoMasCercanoPorX(puntoPreview);

                if (nuevoSeleccionado >= 0)
                {
                    seleccionado = nuevoSeleccionado;
                    Invalidate();

                    if (TramoSeleccionadoChanged != null)
                        TramoSeleccionadoChanged(this, nuevoSeleccionado);
                }
            }

            protected override void OnPaint(WinForms.PaintEventArgs e)
            {
                base.OnPaint(e);

                Drawing.Graphics g = e.Graphics;
                g.SmoothingMode =
                    System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

                g.Clear(Drawing.Color.White);

                hitTramos.Clear();

                if (Owner == null ||
                    Owner.ventanaLongitudinalOrigen == null ||
                    Owner.ventanaLongitudinalOrigen.IsDisposed)
                {
                    DibujarTextoCentro(g, "No hay vista preliminar longitudinal disponible.");
                    return;
                }

                System.Drawing.Drawing2D.GraphicsState estado =
                    g.Save();

                try
                {
                    // NUEVO:
                    // Se aplica pan/zoom a todo el dibujo de la vista preliminar.
                    // Los hitboxes se mantienen en coordenadas originales; por eso
                    // el clic se convierte con ConvertirPantallaAPreview().
                    AplicarTransformacionNavegacion(g);

                    Dictionary<int, List<Tuple<double, int>>> estribosPreview =
                        Owner.ObtenerPosicionesEstribosPreview();

                    // CLAVE:
                    // Se reutiliza la misma vista preliminar 2D de Acero longitudinal.
                    // No se vuelve a crear otra geometría de viga en esta ventana.
                    Owner.ventanaLongitudinalOrigen.DibujarVistaPreviaComun(
                        g,
                        this.ClientRectangle,
                        false, // No dibujar longitudinales en la pestaña Estribos.
                        true,
                        estribosPreview,
                        seleccionado);

                    ConstruirHitBoxes();

                    // MODIFICADO:
                    // El resaltado azul ya no cubre toda la altura del panel.
                    // Solo marca la franja real del tramo de viga seleccionado.
                    DibujarTramoSeleccionado(g);

                    // IMPORTANTE:
                    // Ya no se dibujan líneas nuevas encima de los estribos.
                    // El resaltado del tramo seleccionado lo hace directamente
                    // DibujarVistaPreviaComun usando la misma geometría original.
                }
                finally
                {
                    g.Restore(estado);
                }
            }

            private void ConstruirHitBoxes()
            {
                hitTramos.Clear();

                if (Owner == null)
                    return;

                hitTramos =
                    Owner.ObtenerHitBoxesTramosMismaVista(this.ClientRectangle);

                if (hitTramos == null)
                    hitTramos = new List<Drawing.RectangleF>();
            }

            private void DibujarTramoSeleccionado(Drawing.Graphics g)
            {
                if (seleccionado < 0)
                    return;

                if (hitTramos == null || seleccionado >= hitTramos.Count)
                    return;

                // MODIFICADO:
                // El resaltado azul ya no usa el hitbox alto que incluye columnas/cotas.
                // Ahora se dibuja como polígono de la viga:
                // - rectangular en vigas normales;
                // - trapezoidal/inclinado en vigas de sección variable.
                Drawing.PointF[] poligono = ObtenerPoligonoVisualTramo(seleccionado);

                if (poligono == null || poligono.Length < 4)
                    return;

                using (Drawing.Pen pen = new Drawing.Pen(Drawing.Color.FromArgb(0, 120, 215), 2.0f))
                using (Drawing.Brush brush = new Drawing.SolidBrush(Drawing.Color.FromArgb(34, 0, 120, 215)))
                {
                    g.FillPolygon(brush, poligono);
                    g.DrawPolygon(pen, poligono);
                }
            }

            private Drawing.RectangleF ObtenerRectanguloVisualTramo(Drawing.RectangleF r)
            {
                if (r.Width <= 0.0f || r.Height <= 0.0f)
                    return r;

                // MISMA REFERENCIA DE LA VISTA LONGITUDINAL:
                // En DibujarVistaPreviaComun, la viga se dibuja con:
                // yBeam = 50 y hBeam = 30.
                // Por eso ya no se toma un porcentaje del hitbox,
                // porque ese hitbox incluye la extensión inferior de columnas.
                float yBeam = 50.0f;
                float hBeam = 30.0f;

                if (this.ClientRectangle.Height > 0)
                {
                    if (yBeam < 0.0f)
                        yBeam = 0.0f;

                    if (yBeam + hBeam > this.ClientRectangle.Height)
                        hBeam = Math.Max(12.0f, this.ClientRectangle.Height - yBeam - 1.0f);
                }

                return new Drawing.RectangleF(
                    r.Left,
                    yBeam,
                    r.Width,
                    hBeam);
            }

            private Drawing.PointF[] ObtenerPoligonoVisualTramo(int index)
            {
                if (hitTramos == null || index < 0 || index >= hitTramos.Count)
                    return new Drawing.PointF[0];

                // CORRECCIÓN CLAVE:
                // Primero se intenta leer el polígono EXACTO generado por la ventana
                // longitudinal, usando la misma escala, el mismo eje inclinado y el mismo
                // perfil variable con el que se dibuja la viga gris.
                Drawing.PointF[] poligonoExacto = ObtenerPoligonoExactoDesdeVistaLongitudinal(index);

                if (poligonoExacto != null && poligonoExacto.Length >= 4)
                    return poligonoExacto;

                // Respaldo local si aún no agregaste el método público en la ventana longitudinal.
                Drawing.RectangleF r = ObtenerRectanguloVisualTramo(hitTramos[index]);

                if (r.Width <= 0.0f || r.Height <= 0.0f)
                    return new Drawing.PointF[0];

                PerfilVisualTramo perfil;

                if (ObtenerPerfilVisualTramoVariable(index, r, out perfil))
                {
                    return new Drawing.PointF[]
                    {
                        new Drawing.PointF(r.Left, perfil.YSuperiorInicio),
                        new Drawing.PointF(r.Right, perfil.YSuperiorFin),
                        new Drawing.PointF(r.Right, perfil.YInferiorFin),
                        new Drawing.PointF(r.Left, perfil.YInferiorInicio)
                    };
                }

                return new Drawing.PointF[]
                {
                    new Drawing.PointF(r.Left, r.Top),
                    new Drawing.PointF(r.Right, r.Top),
                    new Drawing.PointF(r.Right, r.Bottom),
                    new Drawing.PointF(r.Left, r.Bottom)
                };
            }

            private Drawing.PointF[] ObtenerPoligonoExactoDesdeVistaLongitudinal(int index)
            {
                if (Owner == null || Owner.ventanaLongitudinalOrigen == null)
                    return null;

                try
                {
                    System.Reflection.MethodInfo metodo =
                        Owner.ventanaLongitudinalOrigen.GetType().GetMethod(
                            "ObtenerPoligonosTramosVistaPreviaComun",
                            System.Reflection.BindingFlags.Instance |
                            System.Reflection.BindingFlags.Public);

                    if (metodo == null)
                        return null;

                    object valor = metodo.Invoke(
                        Owner.ventanaLongitudinalOrigen,
                        new object[] { this.ClientRectangle });

                    List<Drawing.PointF[]> lista = valor as List<Drawing.PointF[]>;

                    if (lista == null)
                        return null;

                    if (index < 0 || index >= lista.Count)
                        return null;

                    Drawing.PointF[] poligono = lista[index];

                    if (poligono == null || poligono.Length < 4)
                        return null;

                    return poligono;
                }
                catch
                {
                    return null;
                }
            }

            private class PerfilVisualTramo
            {
                public float YSuperiorInicio;
                public float YSuperiorFin;
                public float YInferiorInicio;
                public float YInferiorFin;
            }

            private bool ObtenerPerfilVisualTramoVariable(
                int index,
                Drawing.RectangleF r,
                out PerfilVisualTramo perfil)
            {
                perfil = null;

                if (Owner == null)
                    return false;

                if (tramos == null || index < 0 || index >= tramos.Count)
                    return false;

                VigaLongitudinalPreview viga = ObtenerVigaPreviewParaTramo(index);

                if (viga == null || !viga.TienePerfilSeccionVariable)
                    return false;

                TramoInfo tramo = tramos[index];

                if (tramo == null || tramo.LongitudMm <= 0.0)
                    return false;

                double t0 = 0.0;
                double t1 = 1.0;

                // Si hay una viga por tramo, el tramo visual usa todo el perfil de esa viga.
                // Si hay una sola viga continua con varios tramos, se usa la posición del tramo
                // dentro de la serie para interpolar la sección variable.
                if (Owner.vigasPreview != null && Owner.vigasPreview.Count == tramos.Count)
                {
                    t0 = 0.0;
                    t1 = 1.0;
                }
                else if (tramo.TotalSerieMm > 1.0)
                {
                    t0 = tramo.StartSerieMm / tramo.TotalSerieMm;
                    t1 = tramo.EndSerieMm / tramo.TotalSerieMm;
                }
                else
                {
                    double total = tramos.Where(x => x != null).Sum(x => Math.Max(0.0, x.LongitudMm));
                    if (total > 1.0)
                    {
                        double acum = 0.0;
                        for (int i = 0; i < index; i++)
                            acum += tramos[i] == null ? 0.0 : Math.Max(0.0, tramos[i].LongitudMm);

                        t0 = acum / total;
                        t1 = (acum + tramo.LongitudMm) / total;
                    }
                }

                t0 = Clamp01(t0);
                t1 = Clamp01(t1);

                double zSupIni = InterpolarZPreview(viga, true, t0);
                double zSupFin = InterpolarZPreview(viga, true, t1);
                double zInfIni = InterpolarZPreview(viga, false, t0);
                double zInfFin = InterpolarZPreview(viga, false, t1);

                double minZ = Math.Min(Math.Min(zSupIni, zSupFin), Math.Min(zInfIni, zInfFin));
                double maxZ = Math.Max(Math.Max(zSupIni, zSupFin), Math.Max(zInfIni, zInfFin));

                if (maxZ <= minZ + 0.0001)
                    return false;

                double centroZ = (minZ + maxZ) / 2.0;
                double escala = r.Height / Math.Max(1.0, maxZ - minZ);
                float yCentro = r.Top + r.Height / 2.0f;

                perfil = new PerfilVisualTramo();
                perfil.YSuperiorInicio = yCentro - (float)((zSupIni - centroZ) * escala);
                perfil.YSuperiorFin = yCentro - (float)((zSupFin - centroZ) * escala);
                perfil.YInferiorInicio = yCentro - (float)((zInfIni - centroZ) * escala);
                perfil.YInferiorFin = yCentro - (float)((zInfFin - centroZ) * escala);

                // CORRECCIÓN:
                // En algunos armazones inclinados o de sección variable, los perfiles
                // superior/inferior que llegan desde la vista preliminar pueden venir casi
                // superpuestos. Eso hacía que el resaltado azul se viera como una sola línea
                // diagonal en vez de una franja con altura de viga.
                NormalizarPerfilVisualConAlturaMinima(perfil, r);

                return true;
            }

            private void NormalizarPerfilVisualConAlturaMinima(
                PerfilVisualTramo perfil,
                Drawing.RectangleF r)
            {
                if (perfil == null)
                    return;

                float alturaDeseada = r.Height;

                if (alturaDeseada < 18.0f)
                    alturaDeseada = 18.0f;

                // Asegura que el punto superior quede por encima del inferior.
                if (perfil.YSuperiorInicio > perfil.YInferiorInicio)
                {
                    float tmp = perfil.YSuperiorInicio;
                    perfil.YSuperiorInicio = perfil.YInferiorInicio;
                    perfil.YInferiorInicio = tmp;
                }

                if (perfil.YSuperiorFin > perfil.YInferiorFin)
                {
                    float tmp = perfil.YSuperiorFin;
                    perfil.YSuperiorFin = perfil.YInferiorFin;
                    perfil.YInferiorFin = tmp;
                }

                float espesorInicio = perfil.YInferiorInicio - perfil.YSuperiorInicio;
                float espesorFin = perfil.YInferiorFin - perfil.YSuperiorFin;

                // Si el perfil se colapsa, se toma la línea inferior visible como base
                // y se levanta la altura de la viga hacia arriba.
                if (espesorInicio < 8.0f)
                {
                    float yBase = Math.Max(perfil.YSuperiorInicio, perfil.YInferiorInicio);
                    perfil.YInferiorInicio = yBase;
                    perfil.YSuperiorInicio = yBase - alturaDeseada;
                }

                if (espesorFin < 8.0f)
                {
                    float yBase = Math.Max(perfil.YSuperiorFin, perfil.YInferiorFin);
                    perfil.YInferiorFin = yBase;
                    perfil.YSuperiorFin = yBase - alturaDeseada;
                }

                // Si por la inclinación queda muy fuera de la zona de la viga,
                // se limita suavemente para no invadir cotas inferiores.
                float margenSuperior = 4.0f;
                float margenInferior = this.ClientRectangle.Height - 4.0f;

                perfil.YSuperiorInicio = Math.Max(margenSuperior, perfil.YSuperiorInicio);
                perfil.YSuperiorFin = Math.Max(margenSuperior, perfil.YSuperiorFin);
                perfil.YInferiorInicio = Math.Min(margenInferior, perfil.YInferiorInicio);
                perfil.YInferiorFin = Math.Min(margenInferior, perfil.YInferiorFin);
            }

            private VigaLongitudinalPreview ObtenerVigaPreviewParaTramo(int index)
            {
                if (Owner == null || Owner.vigasPreview == null || Owner.vigasPreview.Count == 0)
                    return null;

                if (Owner.vigasPreview.Count == tramos.Count &&
                    index >= 0 &&
                    index < Owner.vigasPreview.Count)
                {
                    return Owner.vigasPreview[index];
                }

                if (Owner.vigasPreview.Count == 1)
                    return Owner.vigasPreview[0];

                VigaLongitudinalPreview porIndice = null;

                if (index >= 0 && index < Owner.vigasPreview.Count)
                    porIndice = Owner.vigasPreview[index];

                if (porIndice != null && porIndice.TienePerfilSeccionVariable)
                    return porIndice;

                VigaLongitudinalPreview variable =
                    Owner.vigasPreview.FirstOrDefault(x => x != null && x.TienePerfilSeccionVariable);

                return variable ?? porIndice ?? Owner.vigasPreview[0];
            }

            private double InterpolarZPreview(
                VigaLongitudinalPreview viga,
                bool superior,
                double t)
            {
                if (viga == null)
                    return 0.0;

                t = Clamp01(t);

                List<VigaLongitudinalPreview.PuntoPerfilMm> perfil =
                    superior ? viga.PerfilSuperiorMm : viga.PerfilInferiorMm;

                double longitudRef = viga.LongitudMm;

                if (longitudRef <= 1.0)
                    longitudRef = viga.LongitudSolidoMm;

                if (longitudRef <= 1.0)
                    longitudRef = 1.0;

                if (perfil != null && perfil.Count >= 2)
                {
                    double x = t * longitudRef;

                    List<VigaLongitudinalPreview.PuntoPerfilMm> ordenado =
                        perfil
                        .Where(p => p != null)
                        .OrderBy(p => p.XMm)
                        .ToList();

                    if (ordenado.Count >= 2)
                    {
                        if (x <= ordenado[0].XMm)
                            return ordenado[0].ZMm;

                        if (x >= ordenado[ordenado.Count - 1].XMm)
                            return ordenado[ordenado.Count - 1].ZMm;

                        for (int i = 0; i < ordenado.Count - 1; i++)
                        {
                            VigaLongitudinalPreview.PuntoPerfilMm a = ordenado[i];
                            VigaLongitudinalPreview.PuntoPerfilMm b = ordenado[i + 1];

                            if (x >= a.XMm && x <= b.XMm)
                            {
                                double dx = b.XMm - a.XMm;
                                double tt = Math.Abs(dx) <= 0.0001 ? 0.0 : (x - a.XMm) / dx;
                                tt = Clamp01(tt);
                                return a.ZMm + (b.ZMm - a.ZMm) * tt;
                            }
                        }
                    }
                }

                if (superior)
                {
                    return viga.ZSuperiorInicioMm +
                        (viga.ZSuperiorFinMm - viga.ZSuperiorInicioMm) * t;
                }

                return viga.ZInferiorInicioMm +
                    (viga.ZInferiorFinMm - viga.ZInferiorInicioMm) * t;
            }

            private double Clamp01(double valor)
            {
                if (valor < 0.0)
                    return 0.0;

                if (valor > 1.0)
                    return 1.0;

                return valor;
            }

            private bool PuntoDentroDePoligono(
                Drawing.PointF punto,
                Drawing.PointF[] poligono)
            {
                if (poligono == null || poligono.Length < 3)
                    return false;

                bool dentro = false;
                int j = poligono.Length - 1;

                for (int i = 0; i < poligono.Length; i++)
                {
                    bool cruza =
                        ((poligono[i].Y > punto.Y) != (poligono[j].Y > punto.Y)) &&
                        (punto.X < (poligono[j].X - poligono[i].X) *
                         (punto.Y - poligono[i].Y) /
                         ((poligono[j].Y - poligono[i].Y) == 0.0f
                            ? 0.0001f
                            : (poligono[j].Y - poligono[i].Y)) +
                         poligono[i].X);

                    if (cruza)
                        dentro = !dentro;

                    j = i;
                }

                return dentro;
            }

            private int ObtenerTramoPorRangoXDeClick(Drawing.PointF punto)
            {
                if (hitTramos == null || hitTramos.Count == 0)
                    return -1;

                int mejorIndice = -1;
                float mejorDistancia = float.MaxValue;

                for (int i = 0; i < hitTramos.Count; i++)
                {
                    Drawing.RectangleF r = ObtenerRectanguloVisualTramo(hitTramos[i]);

                    if (r.Width <= 0.0f || r.Height <= 0.0f)
                        continue;

                    // Tolerancia para que sea fácil seleccionar tramos inclinados
                    // sin volver a mostrar un rectángulo azul grande.
                    float toleranciaX = 8.0f;
                    float toleranciaY = 26.0f;

                    Drawing.RectangleF bandaSeleccion =
                        ObtenerBandaSeleccionTramo(i, r, toleranciaX, toleranciaY);

                    if (!bandaSeleccion.Contains(punto))
                        continue;

                    float centroX = r.Left + r.Width / 2.0f;
                    float distancia = Math.Abs(punto.X - centroX);

                    // Si por columnas o uniones se superponen hitboxes,
                    // se escoge el tramo cuyo centro está más cerca del clic.
                    if (distancia < mejorDistancia)
                    {
                        mejorDistancia = distancia;
                        mejorIndice = i;
                    }
                }

                return mejorIndice;
            }

            private int ObtenerTramoMasCercanoPorX(Drawing.PointF punto)
            {
                if (hitTramos == null || hitTramos.Count == 0)
                    return -1;

                int mejorIndice = -1;
                float mejorDistancia = float.MaxValue;

                for (int i = 0; i < hitTramos.Count; i++)
                {
                    Drawing.RectangleF r = ObtenerRectanguloVisualTramo(hitTramos[i]);

                    if (r.Width <= 0.0f || r.Height <= 0.0f)
                        continue;

                    float toleranciaX = Math.Max(10.0f, Math.Min(28.0f, r.Width * 0.08f));

                    bool dentroRangoX =
                        punto.X >= r.Left - toleranciaX &&
                        punto.X <= r.Right + toleranciaX;

                    if (!dentroRangoX)
                        continue;

                    float centroX = r.Left + r.Width / 2.0f;
                    float distancia = Math.Abs(punto.X - centroX);

                    if (distancia < mejorDistancia)
                    {
                        mejorDistancia = distancia;
                        mejorIndice = i;
                    }
                }

                return mejorIndice;
            }

            private Drawing.RectangleF ObtenerBandaSeleccionTramo(
                int index,
                Drawing.RectangleF r,
                float toleranciaX,
                float toleranciaY)
            {
                float minY = r.Top;
                float maxY = r.Bottom;

                Drawing.PointF[] poligono = ObtenerPoligonoVisualTramo(index);

                if (poligono != null && poligono.Length >= 3)
                {
                    minY = poligono.Min(p => p.Y);
                    maxY = poligono.Max(p => p.Y);
                }

                minY -= toleranciaY;
                maxY += toleranciaY;

                if (minY < 0.0f)
                    minY = 0.0f;

                if (maxY > this.ClientRectangle.Height)
                    maxY = this.ClientRectangle.Height;

                return new Drawing.RectangleF(
                    r.Left - toleranciaX,
                    minY,
                    r.Width + toleranciaX * 2.0f,
                    Math.Max(8.0f, maxY - minY));
            }

            private void DibujarEstribosTramoSeleccionadoResaltados(
                Drawing.Graphics g,
                Dictionary<int, List<Tuple<double, int>>> estribosPreview)
            {
                if (g == null)
                    return;

                if (seleccionado < 0)
                    return;

                if (hitTramos == null || seleccionado >= hitTramos.Count)
                    return;

                if (tramos == null || seleccionado >= tramos.Count)
                    return;

                if (estribosPreview == null || !estribosPreview.ContainsKey(seleccionado))
                    return;

                TramoInfo tramo = tramos[seleccionado];

                if (tramo == null || tramo.LongitudMm <= 0.0)
                    return;

                List<Tuple<double, int>> posiciones = estribosPreview[seleccionado];

                if (posiciones == null || posiciones.Count == 0)
                    return;

                Drawing.RectangleF r = ObtenerRectanguloVisualTramo(hitTramos[seleccionado]);

                using (Drawing.Pen penRojoIntenso = new Drawing.Pen(Drawing.Color.FromArgb(235, 0, 0), 2.2f))
                {
                    foreach (Tuple<double, int> item in posiciones)
                    {
                        if (item == null)
                            continue;

                        double xMm = item.Item1;

                        if (xMm < -1.0 || xMm > tramo.LongitudMm + 1.0)
                            continue;

                        double t = xMm / tramo.LongitudMm;
                        t = Clamp01(t);

                        float x = r.Left + (float)(t * r.Width);

                        float y1;
                        float y2;

                        ObtenerLimitesYEnTramoVisual(
                            seleccionado,
                            t,
                            r,
                            out y1,
                            out y2);

                        y1 += 3.0f;
                        y2 -= 3.0f;

                        if (y2 <= y1)
                            continue;

                        g.DrawLine(
                            penRojoIntenso,
                            x,
                            y1,
                            x,
                            y2);
                    }
                }
            }

            private void ObtenerLimitesYEnTramoVisual(
                int index,
                double tLocal,
                Drawing.RectangleF r,
                out float ySuperior,
                out float yInferior)
            {
                ySuperior = r.Top;
                yInferior = r.Bottom;

                PerfilVisualTramo perfil;

                if (!ObtenerPerfilVisualTramoVariable(index, r, out perfil))
                    return;

                tLocal = Clamp01(tLocal);

                ySuperior =
                    perfil.YSuperiorInicio +
                    (perfil.YSuperiorFin - perfil.YSuperiorInicio) * (float)tLocal;

                yInferior =
                    perfil.YInferiorInicio +
                    (perfil.YInferiorFin - perfil.YInferiorInicio) * (float)tLocal;
            }

            private void DibujarTextoCentro(Drawing.Graphics g, string texto)
            {
                using (Drawing.Font f = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold))
                using (Drawing.Brush br = new Drawing.SolidBrush(Drawing.Color.Gray))
                {
                    Drawing.SizeF size = g.MeasureString(texto, f);

                    g.DrawString(
                        texto,
                        f,
                        br,
                        (this.ClientSize.Width - size.Width) / 2.0f,
                        (this.ClientSize.Height - size.Height) / 2.0f);
                }
            }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // AceroEstribosVigasForm
            // 
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Name = "AceroEstribosVigasForm";
            this.Load += new System.EventHandler(this.AceroEstribosVigasForm_Load);
            this.ResumeLayout(false);

        }

        private void AceroEstribosVigasForm_Load(object sender, EventArgs e)
        {

        }
    }
}
