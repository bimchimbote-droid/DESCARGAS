﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_Addin
{
    // =====================================
    // HANDLER - EJECUTAR ESTRIBOS EN VIGAS
    // V4: MORDIDAS CURVAS TOLERANTES SIN ANULAR EL TRAMO COMPLETO
    // - Detecta tramos reales entre columnas.
    // - Crea estribos por grupos.
    // - Zonas = Número con espaciado.
    // - Resto = Espaciado máximo.
    // - Detecta sección variable.
    // - En vigas curvas recorta extremos mordidos hasta sección completa.
    // - Activa "Conj. armaduras variable" antes de aplicar la regla.
    // - CORREGIDO:
    //   Calcula límites Z seguros por cada set para que los estribos
    //   no salgan por debajo de la cara inclinada del sólido.
    // =====================================
    public class EjecutarEstribosVigasHandler : IExternalEventHandler
    {
        public UIDocument UiDoc;

        private AceroEstribosVigasForm _form;
        public AceroEstribosVigasForm Form
        {
            get { return _form; }
            set
            {
                _form = value;

                try
                {
                    if (_form != null)
                        _form.ConectarDetectorFormaDesdeHandler(this);
                }
                catch
                {
                }
            }
        }

        public SeleccionarVigasAceroLongitudinalHandler SeleccionHandler;

        private const double Tol = 1e-6;
        private const double OFFSET_PRIMER_ESTRIBO_CM = 5.0;
        private string ultimoErrorEstriboCurvoMYG = string.Empty;

        // Separación en el eje central para que los 2 estribos de cumbrera
        // se entrelacen y dejen 3/4" de espacio total.
        // Cada estribo se desplaza 3/8" desde el eje central.
        private const double OFFSET_ENTRELAZADO_CENTRAL_IN = 0.375;

        // Comentario correspondiente al tramo que se está creando. Se actualiza
        // antes de generar cada grupo y se escribe en todos los Rebar del tramo.
        private string comentarioDistribucionEstribosActualMYG = string.Empty;

        private class DatosViga
        {
            public Element Elemento;

            public XYZ P0;
            public XYZ P1;

            public XYZ XAxis;
            public XYZ YAxis;
            public XYZ ZAxis;

            public double Longitud;

            public double SolidoMin;
            public double SolidoMax;

            public double YMin;
            public double YMax;

            public double ZMin;
            public double ZMax;

            public bool TieneSeccionVariableEstribos;

            public double ZSuperiorInicio;
            public double ZSuperiorFin;
            public double ZInferiorInicio;
            public double ZInferiorFin;
            public bool TienePerfilZLinealEstribos;

            // Puntos reales del sólido para poder reconstruir la sección Y-Z.
            // Se usa especialmente en viga cumbrera, para que el estribo siga
            // las caras inclinadas del sólido con offset de recubrimiento.
            public List<XYZ> PuntosSolidoGlobal;

            // Sólidos reales de esta viga para validar que el estribo completo
            // permanezca dentro del concreto.
            public List<Solid> SolidosGlobales;

            // Solo obliga a crear barras individuales cuando existe una mordida
            // interna. Las mordidas de los extremos se resuelven recortando el set.
            public bool TieneMordidaInternaEstribos;

            // NUEVO: datos del eje curvo. En vigas curvas los estribos se crean
            // individualmente y cada uno usa la tangente local como normal.
            public Curve CurvaEje;
            public bool EsCurva;
            public XYZ NormalPlanoCurva;

            // Intervalos continuos del concreto sobre el eje longitudinal.
            // Un mismo ElementId puede contener más de un intervalo si un corte
            // atraviesa toda la sección y divide físicamente el sólido.
            public List<IntervaloSolidoLongitudinalMYG> IntervalosSolidoLongitudinal;
        }

        private class IntervaloSolidoLongitudinalMYG
        {
            public double Inicio;
            public double Fin;

            public double Longitud
            {
                get { return Math.Max(0.0, Fin - Inicio); }
            }

            public IntervaloSolidoLongitudinalMYG(double inicio, double fin)
            {
                Inicio = Math.Min(inicio, fin);
                Fin = Math.Max(inicio, fin);
            }
        }

        private class PuntoPerfilYZ
        {
            public double Y;
            public double Z;

            public PuntoPerfilYZ(double y, double z)
            {
                Y = y;
                Z = z;
            }
        }

        private class ReferenciaLongitudinalPerfilMYG
        {
            public PuntoPerfilYZ Centro;
            public double Diametro;
        }

        private class LineaPerfilYZ
        {
            public double Y1;
            public double Z1;
            public double Y2;
            public double Z2;

            public LineaPerfilYZ(double y1, double z1, double y2, double z2)
            {
                Y1 = y1;
                Z1 = z1;
                Y2 = y2;
                Z2 = z2;
            }
        }

        private class CaraPerfilYZ
        {
            public double NY;
            public double NZ;
            public double C;

            public double YMin;
            public double YMax;
            public double ZMin;
            public double ZMax;
            public double YMed;
            public double ZMed;
            public double Area;
        }

        private class PerfilCumbreraYZ
        {
            // Se mantiene YIzq/YDer como respaldo, pero la cumbrera usa
            // Y diferenciados arriba/abajo para que los laterales NO queden
            // verticales, sino paralelos a las caras inclinadas de la viga.
            public double YIzq;
            public double YDer;

            public bool TieneYLateralesDiferenciados;
            public double YIzqTop;
            public double YIzqBot;
            public double YDerTop;
            public double YDerBot;

            public double YCentroIzq;
            public double YCentroDer;

            public double ZTopIzq;
            public double ZTopCentroIzq;
            public double ZTopCentroDer;
            public double ZTopDer;

            public double ZBotIzq;
            public double ZBotCentroIzq;
            public double ZBotCentroDer;
            public double ZBotDer;
        }

        private class IntervaloColumnaSerie
        {
            public double Min;
            public double Max;

            public double Center
            {
                get { return (Min + Max) / 2.0; }
            }

            public double Width
            {
                get { return Max - Min; }
            }

            public IntervaloColumnaSerie(double min, double max)
            {
                Min = min;
                Max = max;
            }
        }

        private class TramoLibreSerie
        {
            public double InicioGlobal;
            public double FinGlobal;

            public DatosViga Viga;
            public double EstacionInicioViga;
            public double EstacionFinViga;

            public double Longitud
            {
                get { return Math.Abs(FinGlobal - InicioGlobal); }
            }

            public TramoLibreSerie(
                double inicioGlobal,
                double finGlobal,
                DatosViga viga,
                double estacionInicioViga,
                double estacionFinViga)
            {
                InicioGlobal = inicioGlobal;
                FinGlobal = finGlobal;
                Viga = viga;
                EstacionInicioViga = estacionInicioViga;
                EstacionFinViga = estacionFinViga;
            }
        }

        private class DatosSerieEstribos
        {
            public XYZ Origen;
            public XYZ XAxis;
            public XYZ YAxis;
            public XYZ ZAxis;

            public double SolidoMinGlobal;
            public double SolidoMaxGlobal;

            public List<DatosViga> Vigas;
            public List<IntervaloColumnaSerie> Columnas;
            public List<TramoLibreSerie> TramosLibres;
        }

        private class AjusteCirculoMaestroEstribosMYG
        {
            public XYZ Centro;
            public double Radio;
            public XYZ Normal;
            public double ErrorRadialMaximo;
        }

        public void Execute(UIApplication app)
        {
            UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

            if (uidoc == null)
                return;

            Document doc = uidoc.Document;

            if (doc == null || Form == null)
                return;

            if (SeleccionHandler == null ||
                SeleccionHandler.VigasSeleccionadas == null ||
                SeleccionHandler.VigasSeleccionadas.Count == 0)
            {
                TaskDialog.Show(
                    "MYG - Estribos",
                    "Primero seleccione vigas en la pestaña Seleccionar vigas.");

                return;
            }

            AceroEstribosVigasForm.ModeloEstribosVigas modelo =
                Form.ModeloEjecucionActual;

            if (modelo == null ||
                modelo.Tramos == null ||
                modelo.Tramos.Count == 0)
            {
                TaskDialog.Show(
                    "MYG - Estribos",
                    "No hay tramos configurados para crear estribos.");

                return;
            }

            AceroVigaDisenoSeccion disenoManualEstribos =
                AceroVigaDisenoSeccionCompartido.ObtenerCopia();
            bool usarDisenoManualEstribos =
                disenoManualEstribos != null &&
                disenoManualEstribos.TieneEstribos;

            RebarBarType tipoEstribo = Form.TipoEstriboSeleccionado;

            if (tipoEstribo == null && usarDisenoManualEstribos)
            {
                tipoEstribo = disenoManualEstribos.Estribos
                    .Where(x => x != null && x.TipoBarra != null)
                    .Select(x => x.TipoBarra)
                    .FirstOrDefault();
            }

            if (tipoEstribo == null)
            {
                TaskDialog.Show(
                    "MYG - Estribos",
                    usarDisenoManualEstribos
                        ? "El diseño manual no contiene un tipo de barra válido para los stirrups."
                        : "Debe seleccionar el tipo de barra de estribo.");

                return;
            }

            double recubrimientoManualEstribos =
                disenoManualEstribos != null &&
                disenoManualEstribos.RecubrimientoEstribosCm > 0.0
                    ? disenoManualEstribos.RecubrimientoEstribosCm
                    : disenoManualEstribos != null
                        ? disenoManualEstribos.RecubrimientoCm
                        : 0.0;

            double recubrimientoCm = usarDisenoManualEstribos &&
                recubrimientoManualEstribos > 0.0
                    ? recubrimientoManualEstribos
                    : 4.0;

            if (!usarDisenoManualEstribos)
            {
                double.TryParse(
                    (Form.RecubrimientoTexto ?? "4").Replace(",", "."),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out recubrimientoCm);
            }

            if (recubrimientoCm <= 0.0)
                recubrimientoCm = 4.0;

            double recubrimientoFt = UnitUtils.ConvertToInternalUnits(
                recubrimientoCm,
                UnitTypeId.Centimeters);

            // CLAVE:
            // Revit crea la armadura por el EJE de la barra.
            // Si el usuario ingresa 4 cm de recubrimiento, ese valor debe quedar
            // hasta la CARA EXTERIOR del estribo, no hasta su eje.
            // Por eso el eje del estribo se coloca a:
            // recubrimiento + diámetro/2.
            double diametroEstriboFt = ObtenerDiametroBarraFt(tipoEstribo);
            double recubrimientoAlEjeFt = recubrimientoFt + (diametroEstriboFt / 2.0);

            List<Element> vigasSerie = ObtenerVigasOrdenadas(
                doc,
                SeleccionHandler.VigasSeleccionadas);

            if (vigasSerie == null || vigasSerie.Count == 0)
            {
                TaskDialog.Show(
                    "MYG - Estribos",
                    "No se pudo ordenar la serie de vigas/armazones seleccionados.");

                return;
            }

            RebarHookType ganchoEstribo135 =
                ObtenerGanchoEstribo135(doc);

            // =========================================================
            // EJECUCIÓN 100 % INDEPENDIENTE POR CADA VIGA SELECCIONADA
            // =========================================================
            // No se ajustan todos los tramos a un círculo común. Cada elemento usa
            // su propia LocationCurve y su propio sólido, de modo que un tramo que
            // tenga un radio o centro ligeramente diferente no impida crear los demás.
            int totalCreados = 0;
            int vigasFallidas = 0;
            List<string> detalleFallidasMYG = new List<string>();
            int indiceConfiguracion = 0;

            using (Transaction tx = new Transaction(doc, "MYG - Estribos por viga independiente"))
            {
                tx.Start();

                foreach (Element vigaActual in vigasSerie)
                {
                    if (vigaActual == null)
                        continue;

                    AceroEstribosVigasForm.TramoEstriboConfig cfg =
                        ObtenerConfiguracionEstriboPorIndiceMYG(
                            modelo,
                            indiceConfiguracion);

                    // Si el modelo de la ventana tiene menos configuraciones que
                    // elementos seleccionados, se reutiliza siempre la primera.
                    if (cfg == null)
                    {
                        cfg = ObtenerConfiguracionEstriboPorIndiceMYG(modelo, 0);
                    }

                    int creadosEnViga = 0;
                    int configuracionesConsumidas = 1;
                    ultimoErrorEstriboCurvoMYG = string.Empty;
                    SubTransaction sub = new SubTransaction(doc);

                    try
                    {
                        sub.Start();

                        LocationCurve lcActual = vigaActual.Location as LocationCurve;
                        Curve ejeActual = lcActual != null ? lcActual.Curve : null;
                        bool esCurvaReal = ejeActual != null && !(ejeActual is Line);

                        if (esCurvaReal)
                        {
                            Curve ejeClonado = null;

                            try
                            {
                                ejeClonado = ejeActual.Clone();
                            }
                            catch
                            {
                                ejeClonado = ejeActual;
                            }

                            DatosViga datosCurva = ObtenerDatosVigaCurvaEstribosMYG(
                                doc,
                                vigaActual,
                                ejeClonado);

                            if (datosCurva != null && datosCurva.Longitud > Tol && cfg != null)
                            {
                                TramoLibreSerie tramoCurvo = new TramoLibreSerie(
                                    0.0,
                                    datosCurva.Longitud,
                                    datosCurva,
                                    0.0,
                                    datosCurva.Longitud);

                                creadosEnViga = CrearSetsEstribosEnTramoLibre(
                                    doc,
                                    tramoCurvo,
                                    tipoEstribo,
                                    ganchoEstribo135,
                                    cfg,
                                    recubrimientoAlEjeFt);

                                // Respaldo: si una configuración de zonas no cabe o
                                // alguna orientación de gancho es rechazada, se crea
                                // una distribución individual uniforme usando la
                                // separación del RESTO (o la última separación válida).
                                if (creadosEnViga <= 0)
                                {
                                    creadosEnViga = CrearEstribosCurvosRespaldoUniformeMYG(
                                        doc,
                                        datosCurva,
                                        tipoEstribo,
                                        ganchoEstribo135,
                                        cfg,
                                        recubrimientoAlEjeFt);
                                }
                            }
                        }
                        else
                        {
                            DatosSerieEstribos datosRecta = ObtenerDatosSerieEstribos(
                                doc,
                                new List<Element>() { vigaActual });

                            if (datosRecta != null &&
                                datosRecta.TramosLibres != null &&
                                datosRecta.TramosLibres.Count > 0)
                            {
                                List<TramoLibreSerie> tramosRectos =
                                    datosRecta.TramosLibres
                                        .Where(t => t != null && t.Longitud > Tol)
                                        .OrderBy(t => t.InicioGlobal)
                                        .ToList();

                                configuracionesConsumidas =
                                    Math.Max(1, tramosRectos.Count);

                                for (int iTramo = 0;
                                     iTramo < tramosRectos.Count;
                                     iTramo++)
                                {
                                    AceroEstribosVigasForm.TramoEstriboConfig cfgTramo =
                                        ObtenerConfiguracionEstriboPorIndiceMYG(
                                            modelo,
                                            indiceConfiguracion + iTramo);

                                    if (cfgTramo == null)
                                        cfgTramo = cfg;

                                    if (cfgTramo == null)
                                        continue;

                                    int creadosTramo =
                                        CrearSetsEstribosEnTramoLibre(
                                            doc,
                                            tramosRectos[iTramo],
                                            tipoEstribo,
                                            ganchoEstribo135,
                                            cfgTramo,
                                            recubrimientoAlEjeFt);

                                    creadosEnViga += Math.Max(0, creadosTramo);
                                }
                            }
                        }

                        if (creadosEnViga > 0)
                        {
                            sub.Commit();
                            totalCreados += creadosEnViga;
                        }
                        else
                        {
                            sub.RollBack();
                            vigasFallidas++;
                            detalleFallidasMYG.Add(
                                "Id " + vigaActual.Id.Value.ToString() +
                                (string.IsNullOrWhiteSpace(ultimoErrorEstriboCurvoMYG)
                                    ? string.Empty
                                    : ": " + ultimoErrorEstriboCurvoMYG));
                        }
                    }
                    catch (Exception ex)
                    {
                        try
                        {
                            if (sub.GetStatus() == TransactionStatus.Started)
                                sub.RollBack();
                        }
                        catch
                        {
                        }

                        vigasFallidas++;
                        detalleFallidasMYG.Add(
                            "Id " + vigaActual.Id.Value.ToString() + ": " + ex.Message);
                    }
                    finally
                    {
                        sub.Dispose();
                    }

                    indiceConfiguracion += Math.Max(
                        1,
                        configuracionesConsumidas);
                }

                tx.Commit();
            }

            if (vigasFallidas > 0)
            {
                string detalle = detalleFallidasMYG.Count > 0
                    ? "\n\nElementos no creados:\n" + string.Join("\n", detalleFallidasMYG.Take(10))
                    : string.Empty;

                TaskDialog.Show(
                    "MYG - Estribos",
                    "Los estribos se ejecutaron de manera independiente en cada viga.\n\n" +
                    "Creados: " + totalCreados.ToString() + "\n" +
                    "Vigas sin armadura: " + vigasFallidas.ToString() + detalle);
            }

            return;
        }


        // =========================================================
        // VIGAS CURVAS - ESTRIBOS INDIVIDUALES POR ESTACIÓN
        // =========================================================
        private bool EsElementoVigaCurvaEstriboMYG(Element elemento)
        {
            if (elemento == null)
                return false;

            LocationCurve lc = elemento.Location as LocationCurve;

            if (lc == null || lc.Curve == null)
                return false;

            return !(lc.Curve is Line);
        }

        private bool IntentarAjustarCirculoMaestroEstribosMYG(
            List<Element> elementos,
            out AjusteCirculoMaestroEstribosMYG ajuste)
        {
            ajuste = null;

            if (elementos == null || elementos.Count < 2)
                return false;

            List<XYZ> puntos = new List<XYZ>();
            XYZ sumaNormal = new XYZ(0.0, 0.0, 0.0);
            XYZ normalReferencia = XYZ.BasisZ;
            bool tieneCurvaReal = false;
            bool tieneNormal = false;

            foreach (Element elemento in elementos)
            {
                if (elemento == null)
                    continue;

                LocationCurve lc = elemento.Location as LocationCurve;
                Curve eje = lc != null ? lc.Curve : null;

                if (eje == null || !eje.IsBound || eje.Length <= Tol)
                    continue;

                Arc arco = eje as Arc;

                if (arco != null)
                {
                    tieneCurvaReal = true;

                    if (arco.Normal != null && arco.Normal.GetLength() > Tol)
                    {
                        XYZ n = arco.Normal.Normalize();

                        if (!tieneNormal)
                        {
                            normalReferencia = n;
                            tieneNormal = true;
                        }

                        if (n.DotProduct(normalReferencia) < 0.0)
                            n = n.Multiply(-1.0);

                        if (Math.Abs(n.DotProduct(normalReferencia)) < 0.94)
                            return false;

                        sumaNormal = sumaNormal.Add(n);
                    }
                }
                else if (!(eje is Line))
                {
                    tieneCurvaReal = true;
                }

                double[] parametros = new double[] { 0.0, 0.25, 0.50, 0.75, 1.0 };

                foreach (double u in parametros)
                {
                    try
                    {
                        XYZ p = eje.Evaluate(u, true);
                        if (p != null)
                            puntos.Add(p);
                    }
                    catch
                    {
                    }
                }
            }

            if (!tieneCurvaReal || puntos.Count < 3)
                return false;

            double promedioX = puntos.Average(p => p.X);
            double promedioY = puntos.Average(p => p.Y);
            double promedioZ = puntos.Average(p => p.Z);

            double sXX = 0.0;
            double sXY = 0.0;
            double sX = 0.0;
            double sYY = 0.0;
            double sY = 0.0;
            double sQX = 0.0;
            double sQY = 0.0;
            double sQ = 0.0;

            foreach (XYZ p in puntos)
            {
                double x = p.X - promedioX;
                double y = p.Y - promedioY;
                double q = (x * x) + (y * y);

                sXX += x * x;
                sXY += x * y;
                sX += x;
                sYY += y * y;
                sY += y;
                sQX += q * x;
                sQY += q * y;
                sQ += q;
            }

            double d;
            double e;
            double f;

            if (!ResolverSistema3x3EstribosMYG(
                sXX, sXY, sX,
                sXY, sYY, sY,
                sX, sY, puntos.Count,
                -sQX, -sQY, -sQ,
                out d, out e, out f))
            {
                return false;
            }

            double cxLocal = -d / 2.0;
            double cyLocal = -e / 2.0;
            double radio2 = (cxLocal * cxLocal) + (cyLocal * cyLocal) - f;

            if (radio2 <= Tol)
                return false;

            double radio = Math.Sqrt(radio2);
            XYZ centro = new XYZ(
                promedioX + cxLocal,
                promedioY + cyLocal,
                promedioZ);

            double errorMaximo = 0.0;
            double zMin = puntos.Min(p => p.Z);
            double zMax = puntos.Max(p => p.Z);

            foreach (XYZ p in puntos)
            {
                double r = Math.Sqrt(
                    ((p.X - centro.X) * (p.X - centro.X)) +
                    ((p.Y - centro.Y) * (p.Y - centro.Y)));

                errorMaximo = Math.Max(errorMaximo, Math.Abs(r - radio));
            }

            double toleranciaResidual = Math.Max(
                UnitUtils.ConvertToInternalUnits(25.0, UnitTypeId.Centimeters),
                Math.Min(
                    UnitUtils.ConvertToInternalUnits(75.0, UnitTypeId.Centimeters),
                    radio * 0.03));

            double toleranciaZ = UnitUtils.ConvertToInternalUnits(
                30.0,
                UnitTypeId.Centimeters);

            if (errorMaximo > toleranciaResidual || zMax - zMin > toleranciaZ)
                return false;

            XYZ normal = sumaNormal.GetLength() > Tol
                ? sumaNormal.Normalize()
                : XYZ.BasisZ;

            if (normal.DotProduct(XYZ.BasisZ) < 0.0)
                normal = normal.Multiply(-1.0);

            ajuste = new AjusteCirculoMaestroEstribosMYG();
            ajuste.Centro = centro;
            ajuste.Radio = radio;
            ajuste.Normal = normal;
            ajuste.ErrorRadialMaximo = errorMaximo;

            return true;
        }

        private Curve CrearEjeCurvoToleranteParaElementoEstribosMYG(
            Element elemento,
            AjusteCirculoMaestroEstribosMYG ajuste)
        {
            if (elemento == null || ajuste == null ||
                ajuste.Centro == null || ajuste.Normal == null ||
                ajuste.Radio <= Tol)
            {
                return null;
            }

            LocationCurve lc = elemento.Location as LocationCurve;
            Curve original = lc != null ? lc.Curve : null;

            if (original == null || !original.IsBound || original.Length <= Tol)
                return null;

            XYZ p0 = ProyectarPuntoSobreCirculoEstribosMYG(
                original.GetEndPoint(0), ajuste);
            XYZ pm = null;
            XYZ p1 = ProyectarPuntoSobreCirculoEstribosMYG(
                original.GetEndPoint(1), ajuste);

            try
            {
                pm = ProyectarPuntoSobreCirculoEstribosMYG(
                    original.Evaluate(0.5, true), ajuste);
            }
            catch
            {
                pm = null;
            }

            if (p0 == null || pm == null || p1 == null)
                return null;

            double tolerancia = UnitUtils.ConvertToInternalUnits(
                0.5,
                UnitTypeId.Centimeters);

            if (p0.DistanceTo(p1) <= tolerancia)
                return null;

            XYZ v0 = p0 - ajuste.Centro;
            XYZ vm = pm - ajuste.Centro;

            if (v0.GetLength() <= Tol || vm.GetLength() <= Tol ||
                v0.CrossProduct(vm).GetLength() <= Tol)
            {
                return null;
            }

            try
            {
                Arc arco = Arc.Create(p0, p1, pm);

                if (arco != null && arco.IsBound && arco.Length > Tol)
                    return arco;
            }
            catch
            {
            }

            return null;
        }

        private XYZ ProyectarPuntoSobreCirculoEstribosMYG(
            XYZ punto,
            AjusteCirculoMaestroEstribosMYG ajuste)
        {
            if (punto == null || ajuste == null || ajuste.Centro == null ||
                ajuste.Normal == null || ajuste.Normal.GetLength() <= Tol ||
                ajuste.Radio <= Tol)
            {
                return null;
            }

            XYZ n = ajuste.Normal.Normalize();
            XYZ v = punto - ajuste.Centro;
            XYZ vp = v - n.Multiply(v.DotProduct(n));

            if (vp.GetLength() <= Tol)
                return null;

            return ajuste.Centro.Add(vp.Normalize().Multiply(ajuste.Radio));
        }

        private bool ResolverSistema3x3EstribosMYG(
            double a11, double a12, double a13,
            double a21, double a22, double a23,
            double a31, double a32, double a33,
            double b1, double b2, double b3,
            out double x1, out double x2, out double x3)
        {
            x1 = 0.0;
            x2 = 0.0;
            x3 = 0.0;

            double det =
                a11 * ((a22 * a33) - (a23 * a32)) -
                a12 * ((a21 * a33) - (a23 * a31)) +
                a13 * ((a21 * a32) - (a22 * a31));

            if (Math.Abs(det) <= 1e-12)
                return false;

            double det1 =
                b1 * ((a22 * a33) - (a23 * a32)) -
                a12 * ((b2 * a33) - (a23 * b3)) +
                a13 * ((b2 * a32) - (a22 * b3));

            double det2 =
                a11 * ((b2 * a33) - (a23 * b3)) -
                b1 * ((a21 * a33) - (a23 * a31)) +
                a13 * ((a21 * b3) - (b2 * a31));

            double det3 =
                a11 * ((a22 * b3) - (b2 * a32)) -
                a12 * ((a21 * b3) - (b2 * a31)) +
                b1 * ((a21 * a32) - (a22 * a31));

            x1 = det1 / det;
            x2 = det2 / det;
            x3 = det3 / det;

            return !(double.IsNaN(x1) || double.IsInfinity(x1) ||
                     double.IsNaN(x2) || double.IsInfinity(x2) ||
                     double.IsNaN(x3) || double.IsInfinity(x3));
        }

        private AceroEstribosVigasForm.TramoEstriboConfig ObtenerConfiguracionEstriboPorIndiceMYG(
            AceroEstribosVigasForm.ModeloEstribosVigas modelo,
            int indice)
        {
            if (modelo == null || modelo.Configuraciones == null)
                return null;

            if (modelo.Configuraciones.ContainsKey(indice))
                return modelo.Configuraciones[indice];

            if (modelo.Configuraciones.ContainsKey(0))
                return modelo.Configuraciones[0];

            return modelo.Configuraciones
                .OrderBy(x => x.Key)
                .Select(x => x.Value)
                .FirstOrDefault();
        }

        private DatosViga ObtenerDatosVigaCurvaEstribosMYG(
            Document doc,
            Element elemento,
            Curve ejeForzado = null)
        {
            if (doc == null || elemento == null)
                return null;

            LocationCurve lc = elemento.Location as LocationCurve;

            if (lc == null || lc.Curve == null)
                return null;

            Curve eje = ejeForzado ?? lc.Curve;

            if (eje == null || (eje is Line && ejeForzado == null))
                return null;

            if (!eje.IsBound || eje.Length <= Tol)
                return null;

            XYZ puntoMedio;
            XYZ tangenteMedio;
            XYZ ejeY;
            XYZ ejeZ;

            if (!ObtenerMarcoCurvaEstriboMYG(
                eje,
                eje.Length * 0.5,
                out puntoMedio,
                out tangenteMedio,
                out ejeY,
                out ejeZ))
            {
                return null;
            }

            List<XYZ> puntos = ObtenerPuntosGeometriaTeseladosEstriboMYG(elemento);

            if (puntos == null || puntos.Count < 4)
                puntos = ObtenerPuntosBoundingBoxElemento(elemento);

            if (puntos == null || puntos.Count < 4)
                return null;

            double ventana = Math.Max(
                UnitUtils.ConvertToInternalUnits(12.0, UnitTypeId.Centimeters),
                Math.Min(
                    UnitUtils.ConvertToInternalUnits(45.0, UnitTypeId.Centimeters),
                    eje.Length * 0.03));

            List<XYZ> cercanos = puntos
                .Where(p => p != null)
                .Where(p => Math.Abs((p - puntoMedio).DotProduct(tangenteMedio)) <= ventana)
                .ToList();

            if (cercanos.Count < 4)
            {
                cercanos = puntos
                    .Where(p => p != null)
                    .OrderBy(p => Math.Abs((p - puntoMedio).DotProduct(tangenteMedio)))
                    .Take(Math.Min(80, puntos.Count))
                    .ToList();
            }

            double yMin = double.MaxValue;
            double yMax = double.MinValue;
            double zMin = double.MaxValue;
            double zMax = double.MinValue;

            foreach (XYZ p in cercanos)
            {
                XYZ v = p - puntoMedio;
                double y = v.DotProduct(ejeY);
                double z = v.DotProduct(ejeZ);

                if (y < yMin) yMin = y;
                if (y > yMax) yMax = y;
                if (z < zMin) zMin = z;
                if (z > zMax) zMax = z;
            }

            if (yMax <= yMin + Tol || zMax <= zMin + Tol)
                return null;

            DatosViga datos = new DatosViga();
            datos.Elemento = elemento;
            datos.P0 = eje.GetEndPoint(0);
            datos.P1 = eje.GetEndPoint(1);
            datos.XAxis = tangenteMedio;
            datos.YAxis = ejeY;
            datos.ZAxis = ejeZ;
            datos.Longitud = eje.Length;
            datos.SolidoMin = 0.0;
            datos.SolidoMax = eje.Length;
            datos.YMin = yMin;
            datos.YMax = yMax;
            datos.ZMin = zMin;
            datos.ZMax = zMax;
            datos.TieneSeccionVariableEstribos = false;
            datos.TienePerfilZLinealEstribos = false;
            datos.ZSuperiorInicio = zMax;
            datos.ZSuperiorFin = zMax;
            datos.ZInferiorInicio = zMin;
            datos.ZInferiorFin = zMin;
            datos.PuntosSolidoGlobal = puntos;
            datos.SolidosGlobales = ObtenerSolidosElementoParaValidacionEstriboMYG(elemento);
            datos.TieneMordidaInternaEstribos = false;
            datos.CurvaEje = eje;
            datos.EsCurva = true;
            datos.NormalPlanoCurva = ejeZ;

            return datos;
        }

        private bool ObtenerMarcoCurvaEstriboMYG(
            Curve eje,
            double estacion,
            out XYZ punto,
            out XYZ tangente,
            out XYZ ejeY,
            out XYZ ejeZ)
        {
            punto = null;
            tangente = null;
            ejeY = null;
            ejeZ = null;

            if (eje == null || eje.Length <= Tol)
                return false;

            double u = Math.Max(0.0, Math.Min(1.0, estacion / eje.Length));

            try
            {
                punto = eje.Evaluate(u, true);
                Transform derivadas = eje.ComputeDerivatives(u, true);
                tangente = derivadas.BasisX.Normalize();
            }
            catch
            {
                return false;
            }

            // El eje Z local se toma vertical y se proyecta perpendicularmente
            // a la tangente. Esto mantiene los estribos verticales aunque el arco
            // esté dibujado con sentido horario o antihorario.
            ejeZ = XYZ.BasisZ.Subtract(
                tangente.Multiply(XYZ.BasisZ.DotProduct(tangente)));

            if (ejeZ.GetLength() <= Tol)
                return false;

            ejeZ = ejeZ.Normalize();
            ejeY = ejeZ.CrossProduct(tangente);

            if (ejeY.GetLength() <= Tol)
                return false;

            ejeY = ejeY.Normalize();
            tangente = tangente.Normalize();

            return true;
        }

        private List<Rebar> CrearEstribosBaseEnCurvaMYG(
            Document doc,
            DatosViga viga,
            RebarBarType tipoEstribo,
            RebarHookType ganchoEstribo135,
            double estacion,
            double minY,
            double maxY,
            double minZ,
            double maxZ)
        {
            List<Rebar> resultado = new List<Rebar>();

            if (doc == null || viga == null || viga.Elemento == null || viga.CurvaEje == null)
            {
                ultimoErrorEstriboCurvoMYG = "Datos incompletos del anfitrión curvo.";
                return resultado;
            }

            if (RebarHostData.GetRebarHostData(viga.Elemento) == null)
            {
                ultimoErrorEstriboCurvoMYG = "El elemento no admite armadura como anfitrión.";
                return resultado;
            }

            double longitud = viga.CurvaEje.Length;
            estacion = Math.Max(0.0, Math.Min(longitud, estacion));

            XYZ centro;
            XYZ tangente;
            XYZ ejeY;
            XYZ ejeZ;

            if (!ObtenerMarcoCurvaEstriboMYG(
                viga.CurvaEje,
                estacion,
                out centro,
                out tangente,
                out ejeY,
                out ejeZ))
            {
                ultimoErrorEstriboCurvoMYG = "No se pudo calcular el marco local en la estación curva.";
                return resultado;
            }

            if (maxY <= minY + Tol || maxZ <= minZ + Tol)
            {
                ultimoErrorEstriboCurvoMYG = "La sección útil del estribo quedó sin ancho o peralte.";
                return resultado;
            }

            // Dos tamaños: primero el recubrimiento solicitado; después un
            // pequeño retranqueo adicional para resolver caras miteradas o
            // tolerancias de sólido en uniones cortas.
            double retranqueo = Math.Max(
                UnitUtils.ConvertToInternalUnits(0.20, UnitTypeId.Centimeters),
                ObtenerDiametroBarraFt(tipoEstribo) * 0.10);

            double ajusteMedio = Math.Max(
                retranqueo,
                UnitUtils.ConvertToInternalUnits(0.50, UnitTypeId.Centimeters));

            double ajusteMayor = Math.Max(
                ajusteMedio,
                UnitUtils.ConvertToInternalUnits(1.00, UnitTypeId.Centimeters));

            double[] ajustes = new double[]
            {
                0.0,
                retranqueo,
                ajusteMedio,
                ajusteMayor
            };
            List<string> errores = new List<string>();

            foreach (double ajuste in ajustes)
            {
                double y0 = minY + ajuste;
                double y1 = maxY - ajuste;
                double z0 = minZ + ajuste;
                double z1 = maxZ - ajuste;

                if (y1 <= y0 + Tol || z1 <= z0 + Tol)
                    continue;

                XYZ p1 = centro.Add(ejeY.Multiply(y0)).Add(ejeZ.Multiply(z0));
                XYZ p2 = centro.Add(ejeY.Multiply(y1)).Add(ejeZ.Multiply(z0));
                XYZ p3 = centro.Add(ejeY.Multiply(y1)).Add(ejeZ.Multiply(z1));
                XYZ p4 = centro.Add(ejeY.Multiply(y0)).Add(ejeZ.Multiply(z1));

                List<Curve> curvasBase = new List<Curve>();
                AgregarLineaSiValida(curvasBase, p1, p2);
                AgregarLineaSiValida(curvasBase, p2, p3);
                AgregarLineaSiValida(curvasBase, p3, p4);
                AgregarLineaSiValida(curvasBase, p4, p1);

                if (curvasBase.Count < 4)
                    continue;

                List<Curve> curvasInvertidas = InvertirCadenaCurvasEstriboMYG(curvasBase);
                List<List<Curve>> cadenas = new List<List<Curve>>()
                {
                    curvasBase,
                    curvasInvertidas
                };

                List<XYZ> normales = new List<XYZ>()
                {
                    tangente,
                    tangente.Multiply(-1.0)
                };

                RebarTerminationOrientation[] orientaciones = new RebarTerminationOrientation[]
                {
                    RebarTerminationOrientation.Left,
                    RebarTerminationOrientation.Right
                };

                foreach (List<Curve> cadena in cadenas)
                {
                    if (cadena == null || cadena.Count < 4)
                        continue;

                    foreach (XYZ normal in normales)
                    {
                        foreach (RebarTerminationOrientation oriIni in orientaciones)
                        {
                            foreach (RebarTerminationOrientation oriFin in orientaciones)
                            {
                                Rebar rb = CrearRebarDesdeCurvas2027(
                                    doc,
                                    RebarStyle.StirrupTie,
                                    tipoEstribo,
                                    ganchoEstribo135,
                                    ganchoEstribo135,
                                    viga.Elemento,
                                    normal,
                                    cadena,
                                    oriIni,
                                    oriFin);

                                if (rb != null)
                                {
                                    AplicarParametrosRebarEstriboMYG(
                                        doc,
                                        rb,
                                        viga.Elemento,
                                        comentarioDistribucionEstribosActualMYG);

                                    resultado.Add(rb);
                                    ultimoErrorEstriboCurvoMYG = string.Empty;
                                    return resultado;
                                }
                            }
                        }

                        // Respaldo sin ganchos. Es preferible crear el estribo
                        // geométricamente correcto a perder el tramo completo.
                        Rebar rbSinGancho = CrearRebarDesdeCurvas2027(
                            doc,
                            RebarStyle.Standard,
                            tipoEstribo,
                            null,
                            null,
                            viga.Elemento,
                            normal,
                            cadena,
                            RebarTerminationOrientation.Left,
                            RebarTerminationOrientation.Left);

                        if (rbSinGancho != null)
                        {
                            AplicarParametrosRebarEstriboMYG(
                                doc,
                                rbSinGancho,
                                viga.Elemento,
                                comentarioDistribucionEstribosActualMYG);

                            resultado.Add(rbSinGancho);
                            ultimoErrorEstriboCurvoMYG = string.Empty;
                            return resultado;
                        }
                    }
                }
            }

            ultimoErrorEstriboCurvoMYG =
                "Revit rechazó el lazo del estribo en la estación " +
                UnitUtils.ConvertFromInternalUnits(estacion, UnitTypeId.Meters).ToString("0.###") +
                " m, incluso probando ambos sentidos, orientaciones de gancho y un retranqueo adicional.";

            return resultado;
        }

        private List<Curve> InvertirCadenaCurvasEstriboMYG(
            List<Curve> curvas)
        {
            List<Curve> resultado = new List<Curve>();

            if (curvas == null)
                return resultado;

            for (int i = curvas.Count - 1; i >= 0; i--)
            {
                Curve c = curvas[i];

                if (c == null)
                    continue;

                try
                {
                    resultado.Add(c.CreateReversed());
                }
                catch
                {
                }
            }

            return resultado;
        }

        private int CrearEstribosCurvosRespaldoUniformeMYG(
            Document doc,
            DatosViga viga,
            RebarBarType tipoEstribo,
            RebarHookType ganchoEstribo135,
            AceroEstribosVigasForm.TramoEstriboConfig cfg,
            double recubrimientoAlEjeFt)
        {
            if (doc == null || viga == null || tipoEstribo == null || cfg == null)
                return 0;

            double minY = viga.YMin + recubrimientoAlEjeFt;
            double maxY = viga.YMax - recubrimientoAlEjeFt;
            double minZ = viga.ZMin + recubrimientoAlEjeFt;
            double maxZ = viga.ZMax - recubrimientoAlEjeFt;

            if (maxY <= minY + Tol || maxZ <= minZ + Tol)
                return 0;

            double inicioSeccionCompleta = 0.0;
            double finSeccionCompleta = viga.Longitud;

            double inicioDetectado;
            double finDetectado;

            if (TryCalcularIntervaloUtilEstribosCurvaMYG(
                viga,
                0.0,
                viga.Longitud,
                minY,
                maxY,
                minZ,
                maxZ,
                out inicioDetectado,
                out finDetectado))
            {
                inicioSeccionCompleta = Math.Max(0.0, inicioDetectado);
                finSeccionCompleta = Math.Min(viga.Longitud, finDetectado);
            }

            double offset = UnitUtils.ConvertToInternalUnits(
                OFFSET_PRIMER_ESTRIBO_CM,
                UnitTypeId.Centimeters);

            double inicio = inicioSeccionCompleta + offset;
            double fin = finSeccionCompleta - offset;

            if (fin <= inicio + Tol)
                return 0;

            double separacionCm = 0.0;

            if (cfg.SeparacionesCm != null)
            {
                for (int i = cfg.SeparacionesCm.Length - 1; i >= 0; i--)
                {
                    if (cfg.SeparacionesCm[i] > 0.0)
                    {
                        separacionCm = cfg.SeparacionesCm[i];
                        break;
                    }
                }
            }

            if (separacionCm <= 0.0)
                separacionCm = 20.0;

            double separacionFt = UnitUtils.ConvertToInternalUnits(
                separacionCm,
                UnitTypeId.Centimeters);

            return CrearEstribosIndividualesEspaciadoMaximo(
                doc,
                viga,
                tipoEstribo,
                ganchoEstribo135,
                inicio,
                fin,
                separacionFt,
                inicio,
                fin,
                minY,
                maxY,
                minZ,
                maxZ,
                recubrimientoAlEjeFt,
                true,
                true);
        }

        private List<TramoLibreSerie> ConstruirTramosLibresCurvaEstribosMYG(
            Document doc,
            DatosViga viga)
        {
            List<TramoLibreSerie> resultado = new List<TramoLibreSerie>();

            if (doc == null ||
                viga == null ||
                viga.Elemento == null ||
                viga.CurvaEje == null ||
                viga.CurvaEje.Length <= Tol)
            {
                return resultado;
            }

            // Sin lectura de apoyos ni elementos del entorno: todo el arco físico
            // de la viga constituye un único tramo independiente.
            resultado.Add(new TramoLibreSerie(
                0.0,
                viga.CurvaEje.Length,
                viga,
                0.0,
                viga.CurvaEje.Length));

            return resultado;
        }

        private double DistanciaPuntoABoundingBoxXYEstriboMYG(
            XYZ punto,
            BoundingBoxXYZ bb)
        {
            if (punto == null || bb == null)
                return double.MaxValue;

            double dx = 0.0;
            double dy = 0.0;

            if (punto.X < bb.Min.X) dx = bb.Min.X - punto.X;
            else if (punto.X > bb.Max.X) dx = punto.X - bb.Max.X;

            if (punto.Y < bb.Min.Y) dy = bb.Min.Y - punto.Y;
            else if (punto.Y > bb.Max.Y) dy = punto.Y - bb.Max.Y;

            return Math.Sqrt((dx * dx) + (dy * dy));
        }

        private List<XYZ> ObtenerEsquinasBoundingBoxEstriboMYG(BoundingBoxXYZ bb)
        {
            List<XYZ> puntos = new List<XYZ>();

            if (bb == null)
                return puntos;

            puntos.Add(new XYZ(bb.Min.X, bb.Min.Y, bb.Min.Z));
            puntos.Add(new XYZ(bb.Min.X, bb.Min.Y, bb.Max.Z));
            puntos.Add(new XYZ(bb.Min.X, bb.Max.Y, bb.Min.Z));
            puntos.Add(new XYZ(bb.Min.X, bb.Max.Y, bb.Max.Z));
            puntos.Add(new XYZ(bb.Max.X, bb.Min.Y, bb.Min.Z));
            puntos.Add(new XYZ(bb.Max.X, bb.Min.Y, bb.Max.Z));
            puntos.Add(new XYZ(bb.Max.X, bb.Max.Y, bb.Min.Z));
            puntos.Add(new XYZ(bb.Max.X, bb.Max.Y, bb.Max.Z));

            return puntos;
        }

        private List<XYZ> ObtenerPuntosGeometriaTeseladosEstriboMYG(Element elemento)
        {
            List<XYZ> puntos = new List<XYZ>();

            if (elemento == null)
                return puntos;

            Options opciones = new Options();
            opciones.DetailLevel = ViewDetailLevel.Fine;
            opciones.IncludeNonVisibleObjects = false;
            opciones.ComputeReferences = false;

            GeometryElement geometria = null;

            try
            {
                geometria = elemento.get_Geometry(opciones);
            }
            catch
            {
                geometria = null;
            }

            if (geometria == null)
                return puntos;

            RecolectarPuntosTeseladosEstriboMYG(
                geometria,
                Transform.Identity,
                puntos);

            return puntos;
        }

        private void RecolectarPuntosTeseladosEstriboMYG(
            GeometryElement geometria,
            Transform transformacion,
            List<XYZ> puntos)
        {
            if (geometria == null || puntos == null)
                return;

            foreach (GeometryObject obj in geometria)
            {
                if (obj == null)
                    continue;

                Solid solido = obj as Solid;

                if (solido != null)
                {
                    if (solido.Edges == null)
                        continue;

                    foreach (Edge arista in solido.Edges)
                    {
                        Curve curva = null;

                        try
                        {
                            curva = arista.AsCurve();
                        }
                        catch
                        {
                            curva = null;
                        }

                        if (curva == null)
                            continue;

                        IList<XYZ> teselado = null;

                        try
                        {
                            teselado = curva.Tessellate();
                        }
                        catch
                        {
                            teselado = null;
                        }

                        if (teselado == null || teselado.Count == 0)
                        {
                            teselado = new List<XYZ>()
                            {
                                curva.GetEndPoint(0),
                                curva.GetEndPoint(1)
                            };
                        }

                        foreach (XYZ p in teselado)
                        {
                            if (p == null)
                                continue;

                            XYZ q = transformacion != null && !transformacion.IsIdentity
                                ? transformacion.OfPoint(p)
                                : p;

                            puntos.Add(q);
                        }
                    }

                    continue;
                }

                GeometryInstance instancia = obj as GeometryInstance;

                if (instancia == null)
                    continue;

                try
                {
                    GeometryElement simbolo = instancia.GetSymbolGeometry();

                    if (simbolo != null)
                    {
                        Transform t = transformacion;

                        try
                        {
                            t = transformacion.Multiply(instancia.Transform);
                        }
                        catch
                        {
                            t = instancia.Transform;
                        }

                        RecolectarPuntosTeseladosEstriboMYG(simbolo, t, puntos);
                    }
                }
                catch
                {
                }
            }
        }

        public string GetName()
        {
            return "MYG - Ejecutar estribos en vigas";
        }

        public bool DetectarYEnviarFormaALaVentana()
        {
            AceroEstribosVigasForm.TipoFormaEstribo forma;

            if (!DetectarFormaActualDesdeSeleccion(out forma))
                return false;

            if (Form != null && !Form.IsDisposed)
                Form.AplicarFormaEstriboDetectadaDesdeHandler(forma);

            return true;
        }

        public bool DetectarFormaActualDesdeSeleccion(
            out AceroEstribosVigasForm.TipoFormaEstribo forma)
        {
            forma = AceroEstribosVigasForm.TipoFormaEstribo.Rectangular;

            try
            {
                UIDocument uidoc = UiDoc;

                if (uidoc == null)
                    return false;

                Document doc = uidoc.Document;

                if (doc == null)
                    return false;

                if (SeleccionHandler == null ||
                    SeleccionHandler.VigasSeleccionadas == null ||
                    SeleccionHandler.VigasSeleccionadas.Count == 0)
                {
                    return false;
                }

                List<Element> vigasSerie = ObtenerVigasOrdenadas(
                    doc,
                    SeleccionHandler.VigasSeleccionadas);

                if (vigasSerie == null || vigasSerie.Count == 0)
                    return false;

                DatosSerieEstribos datosSerie = ObtenerDatosSerieEstribos(
                    doc,
                    vigasSerie);

                if (datosSerie == null ||
                    datosSerie.Vigas == null ||
                    datosSerie.Vigas.Count == 0)
                {
                    return false;
                }

                bool esCumbrera = DetectarCumbreraDesdeDatosSerie(datosSerie);

                forma = esCumbrera
                    ? AceroEstribosVigasForm.TipoFormaEstribo.Cumbrera
                    : AceroEstribosVigasForm.TipoFormaEstribo.Rectangular;

                return true;
            }
            catch
            {
                forma = AceroEstribosVigasForm.TipoFormaEstribo.Rectangular;
                return false;
            }
        }

        private bool DetectarCumbreraDesdeDatosSerie(DatosSerieEstribos datosSerie)
        {
            if (datosSerie == null ||
                datosSerie.Vigas == null ||
                datosSerie.Vigas.Count == 0)
            {
                return false;
            }

            foreach (DatosViga viga in datosSerie.Vigas)
            {
                if (viga == null)
                    continue;

                // =========================================================
                // DETECCIÓN 100% GEOMÉTRICA
                // =========================================================
                // - 4 lados reales = Rectangular/trapezoidal.
                // - Más de 4 lados + quiebre superior/inferior = Cumbrera.
                // - No se usa nombre, tipo ni familia.
                int lados = ContarLadosGeometricosPerfilYZ(viga);

                if (lados <= 4)
                    continue;

                if (EsVigaCumbreraPorPerfilRealYZ(viga))
                    return true;
            }

            return false;
        }

        private bool EsVigaCumbreraPorNombreOTipo(DatosViga viga)
        {
            if (viga == null || viga.Elemento == null)
                return false;

            List<string> textos = new List<string>();

            try
            {
                textos.Add(viga.Elemento.Name ?? "");
            }
            catch
            {
            }

            try
            {
                ElementId tipoId = viga.Elemento.GetTypeId();

                if (tipoId != null && tipoId != ElementId.InvalidElementId)
                {
                    Element tipo = viga.Elemento.Document.GetElement(tipoId);

                    if (tipo != null)
                    {
                        textos.Add(tipo.Name ?? "");

                        FamilySymbol fs = tipo as FamilySymbol;

                        if (fs != null && fs.Family != null)
                            textos.Add(fs.Family.Name ?? "");
                    }
                }
            }
            catch
            {
            }

            foreach (string t in textos)
            {
                if (string.IsNullOrWhiteSpace(t))
                    continue;

                string s = t.Trim().ToLowerInvariant();

                // Palabras típicas de familias/modelos de viga cumbrera.
                // No se usa solo "inclinada" porque una viga rectangular inclinada
                // puede seguir siendo rectangular. "cumbrera" sí es intención clara.
                if (s.Contains("cumbrera") ||
                    s.Contains("cumbr") ||
                    s.Contains("ridge") ||
                    s.Contains("cumbre"))
                {
                    return true;
                }
            }

            return false;
        }

        private bool EsVigaCumbreraPorPerfilRealYZ(DatosViga viga)
        {
            if (viga == null)
                return false;

            List<PuntoPerfilYZ> puntos = ObtenerPuntosPerfilYZ(viga);

            if (puntos == null || puntos.Count < 5)
                return false;

            int lados = ContarLadosGeometricosPerfilYZDesdePuntos(puntos);

            // Regla solicitada: si geométricamente tiene 4 lados, es rectangular.
            if (lados <= 4)
                return false;

            if (EsVigaCumbreraPorQuiebreInternoYZ(puntos))
                return true;

            List<PuntoPerfilYZ> hull = ConstruirHullPerfilYZ(puntos);

            if (hull == null || hull.Count <= 4)
                return false;

            hull = LimpiarVerticesColinealesPerfilYZ(hull);

            if (hull == null || hull.Count <= 4)
                return false;

            double yMin = hull.Min(p => p.Y);
            double yMax = hull.Max(p => p.Y);
            double zMin = hull.Min(p => p.Z);
            double zMax = hull.Max(p => p.Z);

            double ancho = yMax - yMin;
            double peralte = zMax - zMin;

            if (ancho <= Tol || peralte <= Tol)
                return false;

            double toleranciaQuiebre = Math.Max(
                UnitUtils.ConvertToInternalUnits(1.5, UnitTypeId.Centimeters),
                peralte * 0.035);

            bool quiebreSuperior = ExisteQuiebreSuperiorCumbrera(
                hull,
                yMin,
                yMax,
                zMin,
                zMax,
                toleranciaQuiebre);

            bool quiebreInferior = ExisteQuiebreInferiorCumbrera(
                hull,
                yMin,
                yMax,
                zMin,
                zMax,
                toleranciaQuiebre);

            return quiebreSuperior || quiebreInferior;
        }

        private int ContarLadosGeometricosPerfilYZ(DatosViga viga)
        {
            if (viga == null)
                return 0;

            List<PuntoPerfilYZ> puntos = ObtenerPuntosPerfilYZ(viga);

            return ContarLadosGeometricosPerfilYZDesdePuntos(puntos);
        }

        private int ContarLadosGeometricosPerfilYZDesdePuntos(
            List<PuntoPerfilYZ> puntos)
        {
            List<PuntoPerfilYZ> pts = DepurarPuntosPerfilYZ(puntos);

            if (pts == null || pts.Count < 3)
                return 0;

            if (pts.Count <= 4)
                return pts.Count;

            // En una cumbrera real puede existir un vértice cóncavo/central
            // que el hull elimina. Si existe quiebre, se conserva como > 4 lados.
            if (EsVigaCumbreraPorQuiebreInternoYZ(pts))
                return Math.Max(5, pts.Count);

            List<PuntoPerfilYZ> hull = ConstruirHullPerfilYZ(pts);
            hull = LimpiarVerticesColinealesPerfilYZ(hull);

            return hull == null ? 0 : hull.Count;
        }

        private bool EsVigaCumbreraPorQuiebreInternoYZ(List<PuntoPerfilYZ> puntos)
        {
            if (puntos == null || puntos.Count < 5)
                return false;

            List<PuntoPerfilYZ> pts = DepurarPuntosPerfilYZ(puntos);

            if (pts == null || pts.Count < 5)
                return false;

            double yMin = pts.Min(p => p.Y);
            double yMax = pts.Max(p => p.Y);
            double zMin = pts.Min(p => p.Z);
            double zMax = pts.Max(p => p.Z);

            double ancho = yMax - yMin;
            double peralte = zMax - zMin;

            if (ancho <= Tol || peralte <= Tol)
                return false;

            double yCentro = (yMin + yMax) / 2.0;

            double margenCentral = Math.Max(
                UnitUtils.ConvertToInternalUnits(3.0, UnitTypeId.Centimeters),
                ancho * 0.22);

            double margenLateral = Math.Max(
                UnitUtils.ConvertToInternalUnits(2.0, UnitTypeId.Centimeters),
                ancho * 0.18);

            double toleranciaQuiebre = Math.Max(
                UnitUtils.ConvertToInternalUnits(1.5, UnitTypeId.Centimeters),
                peralte * 0.035);

            PuntoPerfilYZ topCentro = pts
                .Where(p => p != null && Math.Abs(p.Y - yCentro) <= margenCentral)
                .OrderByDescending(p => p.Z)
                .FirstOrDefault();

            PuntoPerfilYZ topIzq = pts
                .Where(p => p != null && p.Y <= yCentro - margenLateral)
                .OrderByDescending(p => p.Z)
                .FirstOrDefault();

            PuntoPerfilYZ topDer = pts
                .Where(p => p != null && p.Y >= yCentro + margenLateral)
                .OrderByDescending(p => p.Z)
                .FirstOrDefault();

            if (topCentro != null && topIzq != null && topDer != null)
            {
                double zLineaCentro = InterpolarZEnY(
                    topIzq.Y,
                    topIzq.Z,
                    topDer.Y,
                    topDer.Z,
                    topCentro.Y);

                double dif = topCentro.Z - zLineaCentro;

                if (dif >= toleranciaQuiebre &&
                    topCentro.Z >= zMin + peralte * 0.40)
                {
                    return true;
                }
            }

            PuntoPerfilYZ botCentro = pts
                .Where(p => p != null && Math.Abs(p.Y - yCentro) <= margenCentral)
                .OrderBy(p => p.Z)
                .FirstOrDefault();

            PuntoPerfilYZ botIzq = pts
                .Where(p => p != null && p.Y <= yCentro - margenLateral)
                .OrderBy(p => p.Z)
                .FirstOrDefault();

            PuntoPerfilYZ botDer = pts
                .Where(p => p != null && p.Y >= yCentro + margenLateral)
                .OrderBy(p => p.Z)
                .FirstOrDefault();

            if (botCentro != null && botIzq != null && botDer != null)
            {
                double zLineaCentro = InterpolarZEnY(
                    botIzq.Y,
                    botIzq.Z,
                    botDer.Y,
                    botDer.Z,
                    botCentro.Y);

                double dif = zLineaCentro - botCentro.Z;

                if (dif >= toleranciaQuiebre &&
                    botCentro.Z <= zMax - peralte * 0.40)
                {
                    return true;
                }
            }

            return false;
        }

        private bool ExisteQuiebreSuperiorCumbrera(
            List<PuntoPerfilYZ> hull,
            double yMin,
            double yMax,
            double zMin,
            double zMax,
            double toleranciaQuiebre)
        {
            if (hull == null || hull.Count < 5)
                return false;

            double ancho = yMax - yMin;
            double peralte = zMax - zMin;

            if (ancho <= Tol || peralte <= Tol)
                return false;

            double yCentro = (yMin + yMax) / 2.0;
            double margenCentral = ancho * 0.28;
            double margenLateral = ancho * 0.18;

            PuntoPerfilYZ pCentro = hull
                .Where(p => p != null && Math.Abs(p.Y - yCentro) <= margenCentral)
                .OrderByDescending(p => p.Z)
                .FirstOrDefault();

            PuntoPerfilYZ pIzq = hull
                .Where(p => p != null && p.Y <= yCentro - margenLateral)
                .OrderByDescending(p => p.Z)
                .FirstOrDefault();

            PuntoPerfilYZ pDer = hull
                .Where(p => p != null && p.Y >= yCentro + margenLateral)
                .OrderByDescending(p => p.Z)
                .FirstOrDefault();

            if (pCentro == null || pIzq == null || pDer == null)
                return false;

            if (Math.Abs(pDer.Y - pIzq.Y) <= Tol)
                return false;

            double zLinea = InterpolarZEnY(
                pIzq.Y,
                pIzq.Z,
                pDer.Y,
                pDer.Z,
                pCentro.Y);

            double diferencia = Math.Abs(pCentro.Z - zLinea);

            bool quiebreSuficiente = diferencia >= toleranciaQuiebre;
            bool puntoCentralRepresentativo = pCentro.Z >= zMin + peralte * 0.35;

            return quiebreSuficiente && puntoCentralRepresentativo;
        }

        private bool ExisteQuiebreInferiorCumbrera(
            List<PuntoPerfilYZ> hull,
            double yMin,
            double yMax,
            double zMin,
            double zMax,
            double toleranciaQuiebre)
        {
            if (hull == null || hull.Count < 5)
                return false;

            double ancho = yMax - yMin;
            double peralte = zMax - zMin;

            if (ancho <= Tol || peralte <= Tol)
                return false;

            double yCentro = (yMin + yMax) / 2.0;
            double margenCentral = ancho * 0.28;
            double margenLateral = ancho * 0.18;

            PuntoPerfilYZ pCentro = hull
                .Where(p => p != null && Math.Abs(p.Y - yCentro) <= margenCentral)
                .OrderBy(p => p.Z)
                .FirstOrDefault();

            PuntoPerfilYZ pIzq = hull
                .Where(p => p != null && p.Y <= yCentro - margenLateral)
                .OrderBy(p => p.Z)
                .FirstOrDefault();

            PuntoPerfilYZ pDer = hull
                .Where(p => p != null && p.Y >= yCentro + margenLateral)
                .OrderBy(p => p.Z)
                .FirstOrDefault();

            if (pCentro == null || pIzq == null || pDer == null)
                return false;

            if (Math.Abs(pDer.Y - pIzq.Y) <= Tol)
                return false;

            double zLinea = InterpolarZEnY(
                pIzq.Y,
                pIzq.Z,
                pDer.Y,
                pDer.Z,
                pCentro.Y);

            double diferencia = Math.Abs(pCentro.Z - zLinea);

            bool quiebreSuficiente = diferencia >= toleranciaQuiebre;
            bool puntoCentralRepresentativo = pCentro.Z <= zMax - peralte * 0.35;

            return quiebreSuficiente && puntoCentralRepresentativo;
        }

        private double InterpolarZEnY(
            double y1,
            double z1,
            double y2,
            double z2,
            double y)
        {
            if (Math.Abs(y2 - y1) <= Tol)
                return (z1 + z2) / 2.0;

            double t = (y - y1) / (y2 - y1);

            return z1 + (z2 - z1) * t;
        }

        private bool EsVigaCumbreraPorCarasInclinadasYZ(DatosViga viga)
        {
            if (viga == null)
                return false;

            double ancho = viga.YMax - viga.YMin;
            double peralte = viga.ZMax - viga.ZMin;

            if (ancho <= Tol || peralte <= Tol)
                return false;

            List<CaraPerfilYZ> caras = ObtenerCarasPerfilYZDesdeSolido(viga);

            if (caras == null || caras.Count == 0)
                return false;

            int carasInclinadasRepresentativas = 0;
            bool hayPendientePositiva = false;
            bool hayPendienteNegativa = false;

            foreach (CaraPerfilYZ cara in caras)
            {
                if (cara == null)
                    continue;

                double ny = cara.NY;
                double nz = cara.NZ;
                double len = Math.Sqrt((ny * ny) + (nz * nz));

                if (len <= Tol)
                    continue;

                ny /= len;
                nz /= len;

                double absY = Math.Abs(ny);
                double absZ = Math.Abs(nz);

                bool normalInclinadaYZ = absY > 0.18 && absZ > 0.18;

                if (!normalInclinadaYZ)
                    continue;

                double recorridoY = Math.Abs(cara.YMax - cara.YMin);
                double recorridoZ = Math.Abs(cara.ZMax - cara.ZMin);

                bool caraRepresentativa =
                    recorridoY >= ancho * 0.06 &&
                    recorridoZ >= peralte * 0.06;

                if (!caraRepresentativa)
                    continue;

                carasInclinadasRepresentativas++;

                if (Math.Abs(nz) > Tol)
                {
                    double pendiente = -ny / nz;

                    if (pendiente > 0.05)
                        hayPendientePositiva = true;
                    else if (pendiente < -0.05)
                        hayPendienteNegativa = true;
                }
            }

            return carasInclinadasRepresentativas >= 2 &&
                   hayPendientePositiva &&
                   hayPendienteNegativa;
        }

        private List<Element> ObtenerVigasOrdenadas(Document doc, List<ElementId> ids)
        {
            List<Element> vigas = new List<Element>();

            if (doc == null || ids == null)
                return vigas;

            foreach (ElementId id in ids)
            {
                if (id == null || id == ElementId.InvalidElementId)
                    continue;

                Element e = doc.GetElement(id);

                if (e == null)
                    continue;

                if (e.Location is LocationCurve)
                    vigas.Add(e);
            }

            if (vigas.Count <= 1)
                return vigas;

            Curve curvaBase = ObtenerCurvaElemento(vigas[0]);

            if (curvaBase == null)
                return vigas;

            XYZ origen = curvaBase.GetEndPoint(0);
            XYZ eje = curvaBase.GetEndPoint(1) - curvaBase.GetEndPoint(0);

            if (eje.GetLength() <= Tol)
                return vigas;

            eje = eje.Normalize();

            vigas = vigas
                .OrderBy(v =>
                {
                    Curve c = ObtenerCurvaElemento(v);

                    if (c == null)
                        return 0.0;

                    XYZ centro = (c.GetEndPoint(0) + c.GetEndPoint(1)).Multiply(0.5);

                    return (centro - origen).DotProduct(eje);
                })
                .ToList();

            return vigas;
        }

        private DatosSerieEstribos ObtenerDatosSerieEstribos(Document doc, List<Element> vigas)
        {
            if (doc == null || vigas == null || vigas.Count == 0)
                return null;

            List<DatosViga> datosVigas = new List<DatosViga>();

            foreach (Element viga in vigas)
            {
                DatosViga d = ObtenerDatosViga(viga);

                if (d != null)
                    datosVigas.Add(d);
            }

            if (datosVigas.Count == 0)
                return null;

            DatosViga baseDatos = datosVigas[0];

            XYZ origen = baseDatos.P0;
            XYZ eje = baseDatos.XAxis;
            XYZ yAxis = baseDatos.YAxis;
            XYZ zAxis = baseDatos.ZAxis;

            if (eje == null || eje.GetLength() <= Tol)
                return null;

            eje = eje.Normalize();

            datosVigas = datosVigas
                .OrderBy(d =>
                {
                    XYZ centro = (d.P0 + d.P1).Multiply(0.5);
                    return (centro - origen).DotProduct(eje);
                })
                .ToList();

            double minX = double.MaxValue;
            double maxX = double.MinValue;

            foreach (DatosViga d in datosVigas)
            {
                List<XYZ> puntos = ObtenerPuntosSolidoElemento(d.Elemento);

                if (puntos == null || puntos.Count == 0)
                    puntos = ObtenerPuntosBoundingBoxElemento(d.Elemento);

                foreach (XYZ p in puntos)
                {
                    double x = (p - origen).DotProduct(eje);

                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                }
            }

            if (maxX <= minX + Tol)
                return null;

            // No se leen columnas, zapatas ni ninguna otra categoría.
            List<IntervaloColumnaSerie> columnas =
                new List<IntervaloColumnaSerie>();

            List<TramoLibreSerie> tramosLibres =
                new List<TramoLibreSerie>();

            // Este método se invoca por una viga a la vez durante la ejecución.
            // Sin embargo, un mismo ElementId puede tener varios cuerpos de concreto
            // separados por un corte. Cada intervalo continuo se convierte en un
            // TramoLibreSerie independiente.
            DatosViga unica = datosVigas[0];

            List<IntervaloSolidoLongitudinalMYG> intervalosContinuos =
                unica.IntervalosSolidoLongitudinal == null
                    ? new List<IntervaloSolidoLongitudinalMYG>()
                    : unica.IntervalosSolidoLongitudinal
                        .Where(x => x != null && x.Longitud > Tol)
                        .OrderBy(x => x.Inicio)
                        .ToList();

            if (intervalosContinuos.Count == 0)
            {
                double estacionInicio =
                    Math.Min(unica.SolidoMin, unica.SolidoMax);

                double estacionFin =
                    Math.Max(unica.SolidoMin, unica.SolidoMax);

                if (estacionFin > estacionInicio + Tol)
                {
                    intervalosContinuos.Add(
                        new IntervaloSolidoLongitudinalMYG(
                            estacionInicio,
                            estacionFin));
                }
            }

            foreach (IntervaloSolidoLongitudinalMYG intervalo
                in intervalosContinuos)
            {
                if (intervalo == null || intervalo.Longitud <= Tol)
                    continue;

                // Para una sola viga, el origen global coincide con P0 y el eje
                // global coincide con XAxis; la estación local también es global.
                tramosLibres.Add(
                    new TramoLibreSerie(
                        intervalo.Inicio,
                        intervalo.Fin,
                        unica,
                        intervalo.Inicio,
                        intervalo.Fin));
            }

            DatosSerieEstribos serie = new DatosSerieEstribos();
            serie.Origen = origen;
            serie.XAxis = eje;
            serie.YAxis = yAxis;
            serie.ZAxis = zAxis;
            serie.SolidoMinGlobal = minX;
            serie.SolidoMaxGlobal = maxX;
            serie.Vigas = datosVigas;
            serie.Columnas = columnas;
            serie.TramosLibres = tramosLibres;

            return serie;
        }

        private DatosViga ObtenerDatosViga(Element viga)
        {
            if (viga == null)
                return null;

            Curve curva = ObtenerCurvaElemento(viga);

            if (curva == null)
                return null;

            XYZ p0 = curva.GetEndPoint(0);
            XYZ p1 = curva.GetEndPoint(1);

            XYZ xAxis = p1 - p0;
            double longitud = xAxis.GetLength();

            if (longitud <= Tol)
                return null;

            xAxis = xAxis.Normalize();

            XYZ yAxis = XYZ.BasisZ.CrossProduct(xAxis);

            if (yAxis.GetLength() <= Tol)
                yAxis = XYZ.BasisX.CrossProduct(xAxis);

            if (yAxis.GetLength() <= Tol)
                yAxis = XYZ.BasisY;

            yAxis = yAxis.Normalize();

            XYZ zAxis = xAxis.CrossProduct(yAxis);

            if (zAxis.GetLength() <= Tol)
                zAxis = XYZ.BasisZ;

            zAxis = zAxis.Normalize();

            if (zAxis.DotProduct(XYZ.BasisZ) < 0.0)
                zAxis = zAxis.Multiply(-1.0);

            List<XYZ> puntos = ObtenerPuntosSolidoElemento(viga);

            if (puntos == null || puntos.Count == 0)
                puntos = ObtenerPuntosBoundingBoxElemento(viga);

            if (puntos == null || puntos.Count == 0)
                return null;

            double minX = double.MaxValue;
            double maxX = double.MinValue;

            double minY = double.MaxValue;
            double maxY = double.MinValue;

            double minZ = double.MaxValue;
            double maxZ = double.MinValue;

            foreach (XYZ p in puntos)
            {
                double x = (p - p0).DotProduct(xAxis);
                double y = (p - p0).DotProduct(yAxis);
                double z = (p - p0).DotProduct(zAxis);

                if (x < minX) minX = x;
                if (x > maxX) maxX = x;

                if (y < minY) minY = y;
                if (y > maxY) maxY = y;

                if (z < minZ) minZ = z;
                if (z > maxZ) maxZ = z;
            }

            if (maxX <= minX + Tol ||
                maxY <= minY + Tol ||
                maxZ <= minZ + Tol)
            {
                return null;
            }

            DatosViga d = new DatosViga();

            d.Elemento = viga;
            d.P0 = p0;
            d.P1 = p1;

            d.XAxis = xAxis;
            d.YAxis = yAxis;
            d.ZAxis = zAxis;

            d.Longitud = longitud;

            d.SolidoMin = minX;
            d.SolidoMax = maxX;

            d.YMin = minY;
            d.YMax = maxY;

            d.ZMin = minZ;
            d.ZMax = maxZ;
            d.PuntosSolidoGlobal = puntos;
            d.SolidosGlobales = ObtenerSolidosElementoParaValidacionEstriboMYG(viga);
            d.IntervalosSolidoLongitudinal =
                ObtenerIntervalosSolidoLongitudinalEstribosMYG(d);
            d.TieneMordidaInternaEstribos = false;

            d.TieneSeccionVariableEstribos =
                DetectarSeccionVariableParaEstribos(
                    puntos,
                    p0,
                    xAxis,
                    zAxis,
                    minX,
                    maxX);

            InicializarPerfilZLinealParaEstribos(
                d,
                puntos,
                p0,
                xAxis,
                zAxis,
                minX,
                maxX);

            return d;
        }

        // =========================================================
        // INTERVALOS CONTINUOS DEL SÓLIDO REAL SOBRE EL EJE DE LA VIGA
        // =========================================================
        // SolidUtils.SplitVolumes separa volúmenes desconectados incluso cuando
        // Revit conserva un único ElementId. Después se proyecta cada volumen sobre
        // XAxis y se fusionan únicamente los intervalos que realmente se tocan.
        private List<IntervaloSolidoLongitudinalMYG>
            ObtenerIntervalosSolidoLongitudinalEstribosMYG(
                DatosViga viga)
        {
            List<IntervaloSolidoLongitudinalMYG> resultado =
                new List<IntervaloSolidoLongitudinalMYG>();

            if (viga == null ||
                viga.P0 == null ||
                viga.XAxis == null ||
                viga.XAxis.GetLength() <= Tol)
            {
                return resultado;
            }

            double minPermitido = Math.Min(viga.SolidoMin, viga.SolidoMax);
            double maxPermitido = Math.Max(viga.SolidoMin, viga.SolidoMax);

            if (maxPermitido <= minPermitido + Tol)
                return resultado;

            XYZ eje = viga.XAxis.Normalize();

            if (viga.SolidosGlobales != null)
            {
                foreach (Solid solid in viga.SolidosGlobales)
                {
                    if (solid == null)
                        continue;

                    List<Solid> partes = new List<Solid>();

                    try
                    {
                        IList<Solid> volumenes = SolidUtils.SplitVolumes(solid);

                        if (volumenes != null)
                        {
                            foreach (Solid parte in volumenes)
                            {
                                if (parte != null)
                                    partes.Add(parte);
                            }
                        }
                    }
                    catch
                    {
                        partes.Clear();
                    }

                    if (partes.Count == 0)
                        partes.Add(solid);

                    foreach (Solid parte in partes)
                    {
                        IntervaloSolidoLongitudinalMYG intervalo =
                            ObtenerIntervaloProyectadoSolidEstribosMYG(
                                parte,
                                viga.P0,
                                eje);

                        if (intervalo == null)
                            continue;

                        intervalo.Inicio = Math.Max(
                            minPermitido,
                            Math.Min(maxPermitido, intervalo.Inicio));

                        intervalo.Fin = Math.Max(
                            minPermitido,
                            Math.Min(maxPermitido, intervalo.Fin));

                        if (intervalo.Longitud > Tol)
                            resultado.Add(intervalo);
                    }
                }
            }

            double toleranciaUnion = UnitUtils.ConvertToInternalUnits(
                1.0,
                UnitTypeId.Millimeters);

            resultado = FusionarIntervalosSolidoEstribosMYG(
                resultado,
                toleranciaUnion);

            if (resultado.Count == 0)
            {
                resultado.Add(
                    new IntervaloSolidoLongitudinalMYG(
                        minPermitido,
                        maxPermitido));
            }

            return resultado;
        }

        private IntervaloSolidoLongitudinalMYG
            ObtenerIntervaloProyectadoSolidEstribosMYG(
                Solid solid,
                XYZ origen,
                XYZ eje)
        {
            if (solid == null || origen == null || eje == null)
                return null;

            if (eje.GetLength() <= Tol)
                return null;

            try
            {
                if (solid.Volume <= Tol ||
                    solid.Edges == null ||
                    solid.Edges.Size == 0)
                {
                    return null;
                }
            }
            catch
            {
                return null;
            }

            eje = eje.Normalize();

            double min = double.MaxValue;
            double max = double.MinValue;
            bool tienePuntos = false;

            foreach (Edge edge in solid.Edges)
            {
                if (edge == null)
                    continue;

                Curve curva = null;

                try
                {
                    curva = edge.AsCurve();
                }
                catch
                {
                    curva = null;
                }

                if (curva == null)
                    continue;

                try
                {
                    XYZ p0 = curva.GetEndPoint(0);
                    XYZ p1 = curva.GetEndPoint(1);

                    double x0 = (p0 - origen).DotProduct(eje);
                    double x1 = (p1 - origen).DotProduct(eje);

                    if (x0 < min) min = x0;
                    if (x0 > max) max = x0;
                    if (x1 < min) min = x1;
                    if (x1 > max) max = x1;

                    tienePuntos = true;
                }
                catch
                {
                }
            }

            if (!tienePuntos || max <= min + Tol)
                return null;

            return new IntervaloSolidoLongitudinalMYG(min, max);
        }

        private List<IntervaloSolidoLongitudinalMYG>
            FusionarIntervalosSolidoEstribosMYG(
                List<IntervaloSolidoLongitudinalMYG> intervalos,
                double toleranciaUnion)
        {
            List<IntervaloSolidoLongitudinalMYG> resultado =
                new List<IntervaloSolidoLongitudinalMYG>();

            if (intervalos == null || intervalos.Count == 0)
                return resultado;

            toleranciaUnion = Math.Max(0.0, toleranciaUnion);

            foreach (IntervaloSolidoLongitudinalMYG intervalo
                in intervalos
                    .Where(x => x != null && x.Longitud > Tol)
                    .OrderBy(x => x.Inicio)
                    .ThenBy(x => x.Fin))
            {
                if (resultado.Count == 0)
                {
                    resultado.Add(
                        new IntervaloSolidoLongitudinalMYG(
                            intervalo.Inicio,
                            intervalo.Fin));

                    continue;
                }

                IntervaloSolidoLongitudinalMYG ultimo =
                    resultado[resultado.Count - 1];

                if (intervalo.Inicio <= ultimo.Fin + toleranciaUnion)
                {
                    ultimo.Inicio = Math.Min(ultimo.Inicio, intervalo.Inicio);
                    ultimo.Fin = Math.Max(ultimo.Fin, intervalo.Fin);
                }
                else
                {
                    resultado.Add(
                        new IntervaloSolidoLongitudinalMYG(
                            intervalo.Inicio,
                            intervalo.Fin));
                }
            }

            return resultado;
        }


        private bool DetectarSeccionVariableParaEstribos(
            List<XYZ> puntos,
            XYZ origen,
            XYZ xAxis,
            XYZ zAxis,
            double solidoMin,
            double solidoMax)
        {
            if (puntos == null || puntos.Count == 0)
                return false;

            if (origen == null || xAxis == null || zAxis == null)
                return false;

            if (xAxis.GetLength() <= Tol || zAxis.GetLength() <= Tol)
                return false;

            if (solidoMax <= solidoMin + Tol)
                return false;

            xAxis = xAxis.Normalize();
            zAxis = zAxis.Normalize();

            double longitud = solidoMax - solidoMin;

            double ventanaFt = Math.Min(
                UnitUtils.ConvertToInternalUnits(25.0, UnitTypeId.Centimeters),
                longitud * 0.10);

            double ventanaMinFt = UnitUtils.ConvertToInternalUnits(
                5.0,
                UnitTypeId.Centimeters);

            if (ventanaFt < ventanaMinFt)
                ventanaFt = ventanaMinFt;

            double zSupIni;
            double zInfIni;
            double zSupFin;
            double zInfFin;

            bool okIni = ObtenerZSuperiorInferiorEnRango(
                puntos,
                origen,
                xAxis,
                zAxis,
                solidoMin - Tol,
                solidoMin + ventanaFt,
                out zSupIni,
                out zInfIni);

            bool okFin = ObtenerZSuperiorInferiorEnRango(
                puntos,
                origen,
                xAxis,
                zAxis,
                solidoMax - ventanaFt,
                solidoMax + Tol,
                out zSupFin,
                out zInfFin);

            if (!okIni || !okFin)
                return false;

            double peralteInicio = zSupIni - zInfIni;
            double peralteFin = zSupFin - zInfFin;

            double toleranciaVariableFt = UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Centimeters);

            return Math.Abs(peralteInicio - peralteFin) > toleranciaVariableFt;
        }

        private void InicializarPerfilZLinealParaEstribos(
            DatosViga viga,
            List<XYZ> puntos,
            XYZ origen,
            XYZ xAxis,
            XYZ zAxis,
            double solidoMin,
            double solidoMax)
        {
            if (viga == null)
                return;

            viga.TienePerfilZLinealEstribos = false;

            if (puntos == null || puntos.Count == 0)
                return;

            if (origen == null || xAxis == null || zAxis == null)
                return;

            if (xAxis.GetLength() <= Tol || zAxis.GetLength() <= Tol)
                return;

            if (solidoMax <= solidoMin + Tol)
                return;

            xAxis = xAxis.Normalize();
            zAxis = zAxis.Normalize();

            double longitud = solidoMax - solidoMin;

            double ventanaFt = Math.Min(
                UnitUtils.ConvertToInternalUnits(25.0, UnitTypeId.Centimeters),
                longitud * 0.10);

            double ventanaMinFt = UnitUtils.ConvertToInternalUnits(
                5.0,
                UnitTypeId.Centimeters);

            if (ventanaFt < ventanaMinFt)
                ventanaFt = ventanaMinFt;

            double zSupIni;
            double zInfIni;
            double zSupFin;
            double zInfFin;

            bool okIni = ObtenerZSuperiorInferiorEnRango(
                puntos,
                origen,
                xAxis,
                zAxis,
                solidoMin - Tol,
                solidoMin + ventanaFt,
                out zSupIni,
                out zInfIni);

            bool okFin = ObtenerZSuperiorInferiorEnRango(
                puntos,
                origen,
                xAxis,
                zAxis,
                solidoMax - ventanaFt,
                solidoMax + Tol,
                out zSupFin,
                out zInfFin);

            if (!okIni || !okFin)
                return;

            viga.ZSuperiorInicio = zSupIni;
            viga.ZInferiorInicio = zInfIni;
            viga.ZSuperiorFin = zSupFin;
            viga.ZInferiorFin = zInfFin;
            viga.TienePerfilZLinealEstribos = true;
        }

        private bool ObtenerZSuperiorInferiorEnRango(
            List<XYZ> puntos,
            XYZ origen,
            XYZ xAxis,
            XYZ zAxis,
            double xMin,
            double xMax,
            out double zSuperior,
            out double zInferior)
        {
            zSuperior = double.MinValue;
            zInferior = double.MaxValue;

            if (puntos == null || puntos.Count == 0)
                return false;

            bool encontrado = false;

            foreach (XYZ p in puntos)
            {
                if (p == null)
                    continue;

                double x = (p - origen).DotProduct(xAxis);

                if (x < xMin || x > xMax)
                    continue;

                double z = (p - origen).DotProduct(zAxis);

                if (z > zSuperior)
                    zSuperior = z;

                if (z < zInferior)
                    zInferior = z;

                encontrado = true;
            }

            if (!encontrado)
                return false;

            if (zSuperior <= zInferior + Tol)
                return false;

            return true;
        }

        private bool ObtenerLimitesZSegurosParaSet(
            DatosViga viga,
            double estacionInicio,
            double estacionFin,
            double recubrimientoFt,
            double minZFallback,
            double maxZFallback,
            out double minZSeguro,
            out double maxZSeguro)
        {
            minZSeguro = minZFallback;
            maxZSeguro = maxZFallback;

            if (viga == null)
                return false;

            if (!viga.TienePerfilZLinealEstribos)
                return true;

            double solidoMin = Math.Min(viga.SolidoMin, viga.SolidoMax);
            double solidoMax = Math.Max(viga.SolidoMin, viga.SolidoMax);

            if (solidoMax <= solidoMin + Tol)
                return true;

            estacionInicio = Math.Max(solidoMin, Math.Min(solidoMax, estacionInicio));
            estacionFin = Math.Max(solidoMin, Math.Min(solidoMax, estacionFin));

            if (estacionFin < estacionInicio)
            {
                double tmp = estacionInicio;
                estacionInicio = estacionFin;
                estacionFin = tmp;
            }

            double zInfIni = InterpolarZPerfilLineal(
                viga.ZInferiorInicio,
                viga.ZInferiorFin,
                solidoMin,
                solidoMax,
                estacionInicio);

            double zInfFin = InterpolarZPerfilLineal(
                viga.ZInferiorInicio,
                viga.ZInferiorFin,
                solidoMin,
                solidoMax,
                estacionFin);

            double zSupIni = InterpolarZPerfilLineal(
                viga.ZSuperiorInicio,
                viga.ZSuperiorFin,
                solidoMin,
                solidoMax,
                estacionInicio);

            double zSupFin = InterpolarZPerfilLineal(
                viga.ZSuperiorInicio,
                viga.ZSuperiorFin,
                solidoMin,
                solidoMax,
                estacionFin);

            double zInferiorSeguro = Math.Max(zInfIni, zInfFin) + recubrimientoFt;
            double zSuperiorSeguro = Math.Min(zSupIni, zSupFin) - recubrimientoFt;

            if (zSuperiorSeguro <= zInferiorSeguro + Tol)
                return true;

            minZSeguro = zInferiorSeguro;
            maxZSeguro = zSuperiorSeguro;

            return true;
        }

        private double InterpolarZPerfilLineal(
            double zInicio,
            double zFin,
            double xInicio,
            double xFin,
            double x)
        {
            if (Math.Abs(xFin - xInicio) <= Tol)
                return zInicio;

            double t = (x - xInicio) / (xFin - xInicio);

            if (t < 0.0) t = 0.0;
            if (t > 1.0) t = 1.0;

            return zInicio + (zFin - zInicio) * t;
        }

        private RebarShapeDrivenAccessor ObtenerAccessorConVariableSiCorresponde(
            Rebar rb,
            bool esSeccionVariable)
        {
            if (rb == null)
                return null;

            RebarShapeDrivenAccessor accessor = null;

            try
            {
                accessor = rb.GetShapeDrivenAccessor();

                if (accessor == null)
                    return null;

                if (esSeccionVariable)
                {
                    try
                    {
                        accessor.UseRebarConstraintsToProduceVaryingBars = true;
                    }
                    catch
                    {
                    }
                }

                return accessor;
            }
            catch
            {
                try
                {
                    if (accessor != null)
                        accessor.Dispose();
                }
                catch
                {
                }

                return null;
            }
        }

        private Outline CrearOutlineSerie(List<DatosViga> datosVigas)
        {
            if (datosVigas == null || datosVigas.Count == 0)
                return null;

            bool inicializado = false;

            XYZ min = null;
            XYZ max = null;

            foreach (DatosViga d in datosVigas)
            {
                if (d == null || d.Elemento == null)
                    continue;

                BoundingBoxXYZ bb = d.Elemento.get_BoundingBox(null);

                if (bb == null)
                    continue;

                if (!inicializado)
                {
                    min = bb.Min;
                    max = bb.Max;
                    inicializado = true;
                }
                else
                {
                    min = new XYZ(
                        Math.Min(min.X, bb.Min.X),
                        Math.Min(min.Y, bb.Min.Y),
                        Math.Min(min.Z, bb.Min.Z));

                    max = new XYZ(
                        Math.Max(max.X, bb.Max.X),
                        Math.Max(max.Y, bb.Max.Y),
                        Math.Max(max.Z, bb.Max.Z));
                }
            }

            if (!inicializado)
                return null;

            // Antes se expandía 200 cm también en Z, lo que jalaba columnas
            // de niveles o posiciones cercanas que no tocaban realmente la viga.
            // Se mantiene margen amplio en planta para no perder columnas reales,
            // pero el margen vertical queda pequeño porque luego se valida
            // contacto vertical estricto de 1 cm.
            double margenXY = UnitUtils.ConvertToInternalUnits(
                120.0,
                UnitTypeId.Centimeters);

            double margenZ = UnitUtils.ConvertToInternalUnits(
                10.0,
                UnitTypeId.Centimeters);

            XYZ min2 = new XYZ(
                min.X - margenXY,
                min.Y - margenXY,
                min.Z - margenZ);

            XYZ max2 = new XYZ(
                max.X + margenXY,
                max.Y + margenXY,
                max.Z + margenZ);

            return new Outline(min2, max2);
        }

        private bool ObtenerIntervaloGeometriaElementoEnEjeEstriboMYG(
            Element elemento,
            XYZ origen,
            XYZ eje,
            out double minEje,
            out double maxEje)
        {
            minEje = 0.0;
            maxEje = 0.0;

            if (elemento == null || origen == null || eje == null || eje.GetLength() <= Tol)
                return false;

            eje = eje.Normalize();

            List<XYZ> puntos = ObtenerPuntosSolidoElemento(elemento);

            if (puntos == null || puntos.Count == 0)
            {
                BoundingBoxXYZ bb = null;

                try
                {
                    bb = elemento.get_BoundingBox(null);
                }
                catch
                {
                    bb = null;
                }

                if (bb == null)
                    return false;

                puntos = ObtenerPuntosBoundingBox(bb);
            }

            if (puntos == null || puntos.Count == 0)
                return false;

            minEje = double.MaxValue;
            maxEje = double.MinValue;

            foreach (XYZ punto in puntos)
            {
                if (punto == null)
                    continue;

                double valor = (punto - origen).DotProduct(eje);

                if (valor < minEje) minEje = valor;
                if (valor > maxEje) maxEje = valor;
            }

            return minEje != double.MaxValue &&
                   maxEje != double.MinValue &&
                   maxEje > minEje + Tol;
        }

        private double ObtenerAnchoBoundingBoxEnDireccionEstriboMYG(
            BoundingBoxXYZ bb,
            XYZ direccion)
        {
            if (bb == null || direccion == null || direccion.GetLength() <= Tol)
                return 0.0;

            direccion = direccion.Normalize();
            List<XYZ> puntos = ObtenerPuntosBoundingBox(bb);

            if (puntos == null || puntos.Count == 0)
                return 0.0;

            double min = double.MaxValue;
            double max = double.MinValue;

            foreach (XYZ punto in puntos)
            {
                double valor = punto.DotProduct(direccion);

                if (valor < min) min = valor;
                if (valor > max) max = valor;
            }

            return max > min ? max - min : 0.0;
        }

        private bool ColumnaTieneContactoEstrictoConAlgunaViga(
            List<DatosViga> datosVigas,
            BoundingBoxXYZ bbColumna,
            double toleranciaPlanta,
            double toleranciaVertical)
        {
            if (datosVigas == null || datosVigas.Count == 0 || bbColumna == null)
                return false;

            foreach (DatosViga viga in datosVigas)
            {
                if (viga == null || viga.Elemento == null)
                    continue;

                BoundingBoxXYZ bbViga = null;

                try
                {
                    bbViga = viga.Elemento.get_BoundingBox(null);
                }
                catch
                {
                    bbViga = null;
                }

                if (bbViga == null)
                    continue;

                if (!EstaPegadoALaVigaEnPlanta(
                    bbViga,
                    bbColumna,
                    toleranciaPlanta))
                {
                    continue;
                }

                if (!TieneContactoVerticalConViga(
                    bbViga,
                    bbColumna,
                    toleranciaVertical))
                {
                    continue;
                }

                return true;
            }

            return false;
        }

        private bool TieneContactoVerticalConViga(
            BoundingBoxXYZ bbViga,
            BoundingBoxXYZ bbCandidato,
            double toleranciaZ)
        {
            if (bbViga == null || bbCandidato == null)
                return false;

            double separacionZ = 0.0;

            if (bbCandidato.Max.Z < bbViga.Min.Z)
            {
                separacionZ = bbViga.Min.Z - bbCandidato.Max.Z;
            }
            else if (bbViga.Max.Z < bbCandidato.Min.Z)
            {
                separacionZ = bbCandidato.Min.Z - bbViga.Max.Z;
            }
            else
            {
                // Hay traslape vertical real entre cajas.
                separacionZ = 0.0;
            }

            return separacionZ <= Math.Abs(toleranciaZ);
        }

        private bool EstaPegadoALaVigaEnPlanta(
            BoundingBoxXYZ bbViga,
            BoundingBoxXYZ bbCandidato,
            double toleranciaContacto)
        {
            if (bbViga == null || bbCandidato == null)
                return false;

            double separacionXY = ObtenerSeparacionMinimaBoundingBoxXY(
                bbViga,
                bbCandidato);

            return separacionXY <= Math.Abs(toleranciaContacto);
        }

        private double ObtenerSeparacionMinimaBoundingBoxXY(
            BoundingBoxXYZ a,
            BoundingBoxXYZ b)
        {
            if (a == null || b == null)
                return double.MaxValue;

            double dx = 0.0;
            double dy = 0.0;

            if (a.Max.X < b.Min.X)
                dx = b.Min.X - a.Max.X;
            else if (b.Max.X < a.Min.X)
                dx = a.Min.X - b.Max.X;

            if (a.Max.Y < b.Min.Y)
                dy = b.Min.Y - a.Max.Y;
            else if (b.Max.Y < a.Min.Y)
                dy = a.Min.Y - b.Max.Y;

            return Math.Sqrt((dx * dx) + (dy * dy));
        }

        private List<IntervaloColumnaSerie> FusionarIntervalosColumnas(
            List<IntervaloColumnaSerie> columnas)
        {
            List<IntervaloColumnaSerie> resultado =
                new List<IntervaloColumnaSerie>();

            if (columnas == null || columnas.Count == 0)
                return resultado;

            double toleranciaUnion = UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Centimeters);

            foreach (IntervaloColumnaSerie col in columnas.OrderBy(x => x.Min))
            {
                if (col == null)
                    continue;

                if (resultado.Count == 0)
                {
                    resultado.Add(new IntervaloColumnaSerie(col.Min, col.Max));
                    continue;
                }

                IntervaloColumnaSerie ultima = resultado[resultado.Count - 1];

                if (col.Min <= ultima.Max + toleranciaUnion)
                {
                    ultima.Min = Math.Min(ultima.Min, col.Min);
                    ultima.Max = Math.Max(ultima.Max, col.Max);
                }
                else
                {
                    resultado.Add(new IntervaloColumnaSerie(col.Min, col.Max));
                }
            }

            return resultado;
        }

        private List<TramoLibreSerie> ConstruirTramosLibresEntreColumnas(
            List<DatosViga> datosVigas,
            List<IntervaloColumnaSerie> columnas,
            XYZ origen,
            XYZ eje,
            double minSerie,
            double maxSerie)
        {
            List<TramoLibreSerie> tramos = new List<TramoLibreSerie>();

            if (datosVigas == null || datosVigas.Count == 0)
                return tramos;

            if (origen == null || eje == null || eje.GetLength() <= Tol)
                return tramos;

            eje = eje.Normalize();

            double longitudMinima = UnitUtils.ConvertToInternalUnits(
                20.0,
                UnitTypeId.Centimeters);

            List<IntervaloColumnaSerie> cols = columnas == null
                ? new List<IntervaloColumnaSerie>()
                : columnas
                    .Where(c => c != null && c.Max > c.Min + Tol)
                    .OrderBy(c => c.Min)
                    .ToList();

            if (cols.Count == 0)
            {
                AgregarTramoLibreSiValido(
                    tramos,
                    datosVigas,
                    origen,
                    eje,
                    minSerie,
                    maxSerie,
                    longitudMinima);

                return tramos;
            }

            double inicioAntes = minSerie;
            double finAntes = Math.Min(cols[0].Min, maxSerie);

            AgregarTramoLibreSiValido(
                tramos,
                datosVigas,
                origen,
                eje,
                inicioAntes,
                finAntes,
                longitudMinima);

            for (int i = 0; i < cols.Count - 1; i++)
            {
                double inicio = Math.Max(cols[i].Max, minSerie);
                double fin = Math.Min(cols[i + 1].Min, maxSerie);

                AgregarTramoLibreSiValido(
                    tramos,
                    datosVigas,
                    origen,
                    eje,
                    inicio,
                    fin,
                    longitudMinima);
            }

            double inicioDespues = Math.Max(cols[cols.Count - 1].Max, minSerie);
            double finDespues = maxSerie;

            AgregarTramoLibreSiValido(
                tramos,
                datosVigas,
                origen,
                eje,
                inicioDespues,
                finDespues,
                longitudMinima);

            return tramos
                .Where(t => t != null && t.Longitud > longitudMinima)
                .OrderBy(t => t.InicioGlobal)
                .ToList();
        }

        private void AgregarTramoLibreSiValido(
            List<TramoLibreSerie> tramos,
            List<DatosViga> datosVigas,
            XYZ origen,
            XYZ eje,
            double inicioGlobal,
            double finGlobal,
            double longitudMinima)
        {
            if (tramos == null || datosVigas == null)
                return;

            if (finGlobal <= inicioGlobal + longitudMinima)
                return;

            double centro = (inicioGlobal + finGlobal) / 2.0;

            DatosViga viga = ElegirVigaParaEstacionGlobal(
                datosVigas,
                origen,
                eje,
                centro);

            if (viga == null)
                return;

            double estacionInicio = CalcularEstacionVigaDesdeGlobal(
                viga,
                origen,
                eje,
                inicioGlobal);

            double estacionFin = CalcularEstacionVigaDesdeGlobal(
                viga,
                origen,
                eje,
                finGlobal);

            double minEst = Math.Min(viga.SolidoMin, viga.SolidoMax);
            double maxEst = Math.Max(viga.SolidoMin, viga.SolidoMax);

            estacionInicio = Math.Max(minEst, Math.Min(maxEst, estacionInicio));
            estacionFin = Math.Max(minEst, Math.Min(maxEst, estacionFin));

            if (Math.Abs(estacionFin - estacionInicio) <= longitudMinima)
                return;

            tramos.Add(
                new TramoLibreSerie(
                    inicioGlobal,
                    finGlobal,
                    viga,
                    estacionInicio,
                    estacionFin));
        }

        private DatosViga ElegirVigaParaEstacionGlobal(
            List<DatosViga> datosVigas,
            XYZ origen,
            XYZ eje,
            double estacionGlobal)
        {
            if (datosVigas == null || datosVigas.Count == 0)
                return null;

            eje = eje.Normalize();

            double tolerancia = UnitUtils.ConvertToInternalUnits(
                20.0,
                UnitTypeId.Centimeters);

            foreach (DatosViga v in datosVigas)
            {
                if (v == null)
                    continue;

                double g0 = (v.P0 - origen).DotProduct(eje);
                double g1 = (v.P1 - origen).DotProduct(eje);

                double gMin = Math.Min(g0, g1);
                double gMax = Math.Max(g0, g1);

                if (estacionGlobal >= gMin - tolerancia &&
                    estacionGlobal <= gMax + tolerancia)
                {
                    return v;
                }
            }

            DatosViga cercano = null;
            double menor = double.MaxValue;

            foreach (DatosViga v in datosVigas)
            {
                if (v == null)
                    continue;

                double g0 = (v.P0 - origen).DotProduct(eje);
                double g1 = (v.P1 - origen).DotProduct(eje);

                double gMin = Math.Min(g0, g1);
                double gMax = Math.Max(g0, g1);

                double dist = 0.0;

                if (estacionGlobal < gMin)
                    dist = gMin - estacionGlobal;
                else if (estacionGlobal > gMax)
                    dist = estacionGlobal - gMax;

                if (dist < menor)
                {
                    menor = dist;
                    cercano = v;
                }
            }

            return cercano ?? datosVigas[0];
        }

        private double CalcularEstacionVigaDesdeGlobal(
            DatosViga viga,
            XYZ origen,
            XYZ ejeGlobal,
            double estacionGlobal)
        {
            if (viga == null || origen == null || ejeGlobal == null)
                return 0.0;

            if (ejeGlobal.GetLength() <= Tol)
                return 0.0;

            ejeGlobal = ejeGlobal.Normalize();

            double g0 = (viga.P0 - origen).DotProduct(ejeGlobal);
            double g1 = (viga.P1 - origen).DotProduct(ejeGlobal);

            double delta = g1 - g0;

            if (Math.Abs(delta) <= Tol)
                return 0.0;

            double factor = (estacionGlobal - g0) / delta;

            return factor * viga.Longitud;
        }

        private List<TramoLibreSerie> AsignarTramosLibresAModelo(
            List<TramoLibreSerie> tramosLibres,
            List<AceroEstribosVigasForm.TramoInfo> tramosModelo)
        {
            List<TramoLibreSerie> resultado = new List<TramoLibreSerie>();

            if (tramosLibres == null || tramosLibres.Count == 0)
                return resultado;

            if (tramosModelo == null || tramosModelo.Count == 0)
                return tramosLibres;

            List<TramoLibreSerie> ordenados = tramosLibres
                .Where(t => t != null && t.Longitud > Tol)
                .OrderBy(t => t.InicioGlobal)
                .ToList();

            if (ordenados.Count == 0)
                return resultado;

            if (ordenados.Count == tramosModelo.Count)
                return ordenados;

            List<TramoLibreSerie> disponibles =
                new List<TramoLibreSerie>(ordenados);

            foreach (AceroEstribosVigasForm.TramoInfo tm in tramosModelo)
            {
                if (tm == null || tm.LongitudMm <= 0.0)
                    continue;

                TramoLibreSerie mejor = null;
                double mejorError = double.MaxValue;

                foreach (TramoLibreSerie tl in disponibles)
                {
                    if (tl == null)
                        continue;

                    double lMm = UnitUtils.ConvertFromInternalUnits(
                        tl.Longitud,
                        UnitTypeId.Millimeters);

                    double error = Math.Abs(lMm - tm.LongitudMm);

                    if (error < mejorError)
                    {
                        mejorError = error;
                        mejor = tl;
                    }
                }

                if (mejor != null)
                {
                    resultado.Add(mejor);
                    disponibles.Remove(mejor);
                }
            }

            if (resultado.Count > 0)
                return resultado.OrderBy(t => t.InicioGlobal).ToList();

            return ordenados;
        }


        // =========================================================
        // ASIGNACIÓN FINAL DE TRAMOS PARA EJECUCIÓN
        // =========================================================
        // Esta función mantiene intacta la lógica original para vigas
        // rectangulares y también para cumbreras que ya vienen correctamente
        // divididas por elementos/tramos.
        //
        // El respaldo solo entra en cumbreras continuas, cuando el modelo
        // necesita dividir la viga por vigas transversales/apoyos intermedios.
        // La diferencia clave es que NO toma límites visuales, sino las caras
        // reales de los apoyos detectados en Revit; por eso luego el estribo
        // queda a 5 cm de cada cara, igual que en un elemento por tramo.
        private List<TramoLibreSerie> ObtenerTramosAsignadosParaEjecucion(
            Document doc,
            DatosSerieEstribos datosSerie,
            AceroEstribosVigasForm.ModeloEstribosVigas modelo)
        {
            List<TramoLibreSerie> original = AsignarTramosLibresAModelo(
                datosSerie == null ? null : datosSerie.TramosLibres,
                modelo == null ? null : modelo.Tramos);

            // Rectangulares: se conserva exactamente la lógica original.
            if (!EsFormaCumbreraSeleccionada())
                return original;

            if (datosSerie == null || modelo == null || modelo.Tramos == null)
                return original;

            int cantidadModelo = modelo.Tramos
                .Where(t => t != null && t.LongitudMm > 0.0)
                .Count();

            if (cantidadModelo <= 1)
                return original;

            int cantidadOriginal = original == null
                ? 0
                : original.Where(t => t != null && t.Longitud > Tol).Count();

            int cantidadVigas = datosSerie.Vigas == null
                ? 0
                : datosSerie.Vigas
                    .Where(v => v != null && v.Elemento != null)
                    .Count();

            // =========================================================
            // CASO 1 - CUMBRERA CON UN ELEMENTO POR TRAMO
            // =========================================================
            // Este era el caso que ya te funcionaba: cada tramo de la vista
            // corresponde a un elemento físico independiente. Aquí NO se debe
            // usar la lógica de apoyos transversales de la cumbrera continua,
            // porque podría terminar escogiendo solo un tramo.
            //
            // Por eso se prioriza este caso antes que cualquier respaldo:
            // se crea un TramoLibreSerie por cada viga seleccionada, usando
            // el inicio/fin real del sólido del propio elemento. Luego la rutina
            // CrearSetsEstribosEnTramo(...) aplica los 5 cm en ambos extremos.
            if (cantidadVigas > 1)
            {
                List<TramoLibreSerie> porElemento = ConstruirTramosCumbreraPorElemento(
                    datosSerie,
                    modelo.Tramos);

                int cantidadPorElemento = porElemento == null
                    ? 0
                    : porElemento.Where(t => t != null && t.Longitud > Tol).Count();

                if (cantidadPorElemento > 0)
                    return porElemento;

                return original;
            }

            // =========================================================
            // CASO 2 - CUMBRERA CONTINUA CON VARIOS TRAMOS
            // =========================================================
            // Aquí sí se divide la viga continua por las caras reales de los
            // apoyos/vigas transversales. Así cada tramo queda desde la cara
            // real del apoyo anterior hasta la cara real del apoyo siguiente,
            // y posteriormente se colocan los estribos a 5 cm de esas caras.
            List<TramoLibreSerie> tramosCumbrera =
                ConstruirTramosCumbreraContinuaPorApoyosReales(
                    doc,
                    datosSerie);

            if (tramosCumbrera != null && tramosCumbrera.Count > 0)
            {
                List<TramoLibreSerie> asignadosCumbrera = AsignarTramosLibresAModelo(
                    tramosCumbrera,
                    modelo.Tramos);

                if (asignadosCumbrera != null && asignadosCumbrera.Count > 0)
                    return asignadosCumbrera;
            }

            // Último respaldo: lógica original.
            return original;
        }

        private List<TramoLibreSerie> ConstruirTramosCumbreraContinuaPorApoyosReales(
            Document doc,
            DatosSerieEstribos datosSerie)
        {
            List<TramoLibreSerie> resultado = new List<TramoLibreSerie>();

            if (datosSerie == null || datosSerie.Vigas == null)
                return resultado;

            // SOLO VIGAS SELECCIONADAS: no se buscan columnas, zapatas,
            // vigas transversales ni ningún otro elemento del entorno.
            foreach (DatosViga viga in datosSerie.Vigas)
            {
                if (viga == null || viga.Elemento == null)
                    continue;

                double inicio = Math.Min(viga.SolidoMin, viga.SolidoMax);
                double fin = Math.Max(viga.SolidoMin, viga.SolidoMax);

                if (fin <= inicio + Tol)
                    continue;

                resultado.Add(new TramoLibreSerie(
                    inicio,
                    fin,
                    viga,
                    inicio,
                    fin));
            }

            return resultado;
        }

        private bool VigaTransversalTieneContactoConSerie(
            List<DatosViga> datosVigas,
            BoundingBoxXYZ bbCandidato,
            double toleranciaXY,
            double toleranciaZ)
        {
            if (datosVigas == null || datosVigas.Count == 0 || bbCandidato == null)
                return false;

            foreach (DatosViga viga in datosVigas)
            {
                if (viga == null || viga.Elemento == null)
                    continue;

                BoundingBoxXYZ bbViga = null;

                try
                {
                    bbViga = viga.Elemento.get_BoundingBox(null);
                }
                catch
                {
                    bbViga = null;
                }

                if (bbViga == null)
                    continue;

                if (!EstaPegadoALaVigaEnPlanta(
                    bbViga,
                    bbCandidato,
                    toleranciaXY))
                {
                    continue;
                }

                if (!TieneContactoVerticalConViga(
                    bbViga,
                    bbCandidato,
                    toleranciaZ))
                {
                    continue;
                }

                return true;
            }

            return false;
        }

        // =========================================================
        // RESPALDO SOLO PARA CUMBRERA MULTI-ELEMENTO
        // =========================================================
        // No se usa para vigas rectangulares, para no alterar la creación que ya
        // parte correctamente desde las caras reales de columnas.
        private bool DebeUsarTramosPorElementoParaCumbrera(
            DatosSerieEstribos datosSerie,
            AceroEstribosVigasForm.ModeloEstribosVigas modelo)
        {
            if (!EsFormaCumbreraSeleccionada())
                return false;

            if (datosSerie == null || datosSerie.Vigas == null)
                return false;

            if (modelo == null || modelo.Tramos == null)
                return false;

            int cantidadVigas = datosSerie.Vigas
                .Where(v => v != null && v.Elemento != null)
                .Count();

            int cantidadModelo = modelo.Tramos
                .Where(t => t != null && t.LongitudMm > 0.0)
                .Count();

            if (cantidadVigas <= 1 || cantidadModelo <= 1)
                return false;

            int cantidadTramosLibres = datosSerie.TramosLibres == null
                ? 0
                : datosSerie.TramosLibres
                    .Where(t => t != null && t.Longitud > Tol)
                    .Count();

            // Caso típico del problema:
            // - En la vista preliminar existen varios tramos.
            // - Cada tramo corresponde a un elemento independiente.
            // - La detección por columnas devuelve menos tramos y solo crea en uno.
            // Si la cumbrera está modelada como un elemento independiente por cada
            // tramo configurado, se usa directamente un elemento por tramo. Esto evita
            // que toda la distribución se cree solo sobre una de las vigas.
            if (cantidadVigas == cantidadModelo)
                return true;

            if (cantidadTramosLibres < cantidadModelo && cantidadVigas >= cantidadModelo)
                return true;

            return false;
        }

        private List<TramoLibreSerie> ConstruirTramosCumbreraPorElemento(
            DatosSerieEstribos datosSerie,
            List<AceroEstribosVigasForm.TramoInfo> tramosModelo)
        {
            List<TramoLibreSerie> resultado = new List<TramoLibreSerie>();

            if (datosSerie == null || datosSerie.Vigas == null)
                return resultado;

            if (datosSerie.Origen == null ||
                datosSerie.XAxis == null ||
                datosSerie.XAxis.GetLength() <= Tol)
            {
                return resultado;
            }

            XYZ origen = datosSerie.Origen;
            XYZ eje = datosSerie.XAxis.Normalize();

            List<DatosViga> vigasOrdenadas = datosSerie.Vigas
                .Where(v => v != null && v.Elemento != null)
                .OrderBy(v =>
                {
                    XYZ centro = (v.P0 + v.P1).Multiply(0.5);
                    return (centro - origen).DotProduct(eje);
                })
                .ToList();

            if (vigasOrdenadas.Count == 0)
                return resultado;

            double longitudMinima = UnitUtils.ConvertToInternalUnits(
                20.0,
                UnitTypeId.Centimeters);

            foreach (DatosViga viga in vigasOrdenadas)
            {
                if (viga == null || viga.Elemento == null)
                    continue;

                double estacionInicioViga = Math.Min(viga.SolidoMin, viga.SolidoMax);
                double estacionFinViga = Math.Max(viga.SolidoMin, viga.SolidoMax);

                if (estacionFinViga <= estacionInicioViga + longitudMinima)
                    continue;

                // Coordenadas globales sobre el eje de la serie, solo para mantener
                // el orden y compatibilidad con el resto del handler.
                XYZ pInicioGlobal = viga.P0 + viga.XAxis.Multiply(estacionInicioViga);
                XYZ pFinGlobal = viga.P0 + viga.XAxis.Multiply(estacionFinViga);

                double inicioGlobal = (pInicioGlobal - origen).DotProduct(eje);
                double finGlobal = (pFinGlobal - origen).DotProduct(eje);

                if (finGlobal < inicioGlobal)
                {
                    double tmp = inicioGlobal;
                    inicioGlobal = finGlobal;
                    finGlobal = tmp;
                }

                resultado.Add(
                    new TramoLibreSerie(
                        inicioGlobal,
                        finGlobal,
                        viga,
                        estacionInicioViga,
                        estacionFinViga));
            }

            resultado = resultado
                .Where(t => t != null && t.Longitud > longitudMinima)
                .OrderBy(t => t.InicioGlobal)
                .ToList();

            if (tramosModelo == null || tramosModelo.Count == 0)
                return resultado;

            int cantidadModelo = tramosModelo
                .Where(t => t != null && t.LongitudMm > 0.0)
                .Count();

            if (cantidadModelo <= 0)
                return resultado;

            // Si hay más elementos que tramos configurados, se toma la misma cantidad
            // en orden. No se toca rectangular; esto solo se ejecuta para cumbrera.
            if (resultado.Count > cantidadModelo)
                resultado = resultado.Take(cantidadModelo).ToList();

            return resultado;
        }

        private int CrearSetsEstribosEnTramoLibre(
            Document doc,
            TramoLibreSerie tramoLibre,
            RebarBarType tipoEstribo,
            RebarHookType ganchoEstribo135,
            AceroEstribosVigasForm.TramoEstriboConfig cfg,
            double recubrimientoFt)
        {
            if (doc == null || tramoLibre == null || tramoLibre.Viga == null || cfg == null)
                return 0;

            comentarioDistribucionEstribosActualMYG =
                ConstruirComentarioDistribucionEstribosMYG(tipoEstribo, cfg);

            DatosViga viga = tramoLibre.Viga;

            double tramoInicio = tramoLibre.EstacionInicioViga;
            double tramoFin = tramoLibre.EstacionFinViga;

            if (tramoFin < tramoInicio)
            {
                double tmp = tramoInicio;
                tramoInicio = tramoFin;
                tramoFin = tmp;
            }

            double solidoMin = Math.Min(viga.SolidoMin, viga.SolidoMax);
            double solidoMax = Math.Max(viga.SolidoMin, viga.SolidoMax);

            tramoInicio = Math.Max(solidoMin, Math.Min(solidoMax, tramoInicio));
            tramoFin = Math.Max(solidoMin, Math.Min(solidoMax, tramoFin));

            if (tramoFin <= tramoInicio + Tol)
                return 0;

            double minY = viga.YMin + recubrimientoFt;
            double maxY = viga.YMax - recubrimientoFt;

            double minZ = viga.ZMin + recubrimientoFt;
            double maxZ = viga.ZMax - recubrimientoFt;

            if (maxY <= minY + Tol || maxZ <= minZ + Tol)
                return 0;

            return CrearSetsEstribosEnTramo(
                doc,
                viga,
                tipoEstribo,
                ganchoEstribo135,
                cfg,
                tramoInicio,
                tramoFin,
                minY,
                maxY,
                minZ,
                maxZ,
                recubrimientoFt);
        }


        // =========================================================
        // INTERVALO ÚTIL DE ESTRIBOS SEGÚN EL SÓLIDO REAL DE LA VIGA
        // =========================================================
        private bool TryCalcularIntervaloUtilEstribosMYG(
            DatosViga viga,
            double inicio,
            double fin,
            double minY,
            double maxY,
            double minZ,
            double maxZ,
            out double inicioUtil,
            out double finUtil,
            out bool tieneMordidaInterna)
        {
            inicioUtil = inicio;
            finUtil = fin;
            tieneMordidaInterna = false;

            if (viga == null || viga.SolidosGlobales == null || viga.SolidosGlobales.Count == 0)
                return false;

            if (fin < inicio)
            {
                double t = inicio;
                inicio = fin;
                fin = t;
            }

            if (fin <= inicio + Tol)
                return true;

            double longitud = fin - inicio;
            double pasoMin = UnitUtils.ConvertToInternalUnits(2.0, UnitTypeId.Centimeters);
            double pasoMax = UnitUtils.ConvertToInternalUnits(10.0, UnitTypeId.Centimeters);
            double paso = Math.Max(pasoMin, Math.Min(pasoMax, longitud / 100.0));

            double primerValido = double.NaN;
            double anterior = inicio;

            for (double s = inicio; s <= fin + Tol; s += paso)
            {
                double estacion = Math.Min(fin, s);

                if (CabeEstriboCompletoEnEstacionMYG(
                    viga,
                    estacion,
                    minY,
                    maxY,
                    minZ,
                    maxZ))
                {
                    primerValido = RefinarLimiteEstriboMYG(
                        viga,
                        Math.Max(inicio, anterior),
                        estacion,
                        true,
                        minY,
                        maxY,
                        minZ,
                        maxZ);
                    break;
                }

                anterior = estacion;
            }

            if (double.IsNaN(primerValido))
            {
                inicioUtil = fin;
                finUtil = fin;
                return true;
            }

            double ultimoValido = double.NaN;
            anterior = fin;

            for (double s = fin; s >= inicio - Tol; s -= paso)
            {
                double estacion = Math.Max(inicio, s);

                if (CabeEstriboCompletoEnEstacionMYG(
                    viga,
                    estacion,
                    minY,
                    maxY,
                    minZ,
                    maxZ))
                {
                    ultimoValido = RefinarLimiteEstriboMYG(
                        viga,
                        estacion,
                        Math.Min(fin, anterior),
                        false,
                        minY,
                        maxY,
                        minZ,
                        maxZ);
                    break;
                }

                anterior = estacion;
            }

            if (double.IsNaN(ultimoValido) || ultimoValido <= primerValido + Tol)
            {
                inicioUtil = fin;
                finUtil = fin;
                return true;
            }

            inicioUtil = primerValido;
            finUtil = ultimoValido;

            // Solo se considera mordida interna si, entre el primer y último punto
            // válidos, aparece nuevamente una estación donde el estribo completo
            // deja de caber. En ese caso no puede utilizarse un set lineal.
            double margen = Math.Min(paso, (finUtil - inicioUtil) * 0.10);

            for (double s = inicioUtil + margen; s <= finUtil - margen + Tol; s += paso)
            {
                if (!CabeEstriboCompletoEnEstacionMYG(
                    viga,
                    s,
                    minY,
                    maxY,
                    minZ,
                    maxZ))
                {
                    tieneMordidaInterna = true;
                    break;
                }
            }

            return true;
        }


        // =========================================================
        // INTERVALO ÚTIL EN VIGAS CURVAS CON EXTREMOS MORDIDOS
        // =========================================================
        // Busca desde ambos extremos la primera estación donde el estribo
        // COMPLETO cabe dentro del sólido real de la viga. Para evitar aceptar
        // una coincidencia aislada en un corte oblicuo, exige varias estaciones
        // válidas consecutivas antes de fijar el límite.
        private class CaraExtremoCurvaEstriboMYG
        {
            public double EstacionMin;
            public double EstacionMax;
            public double EstacionCentro;
            public double Area;
        }

        // =========================================================
        // INTERVALO DE SECCIÓN COMPLETA A PARTIR DE LAS CARAS EXTREMAS
        // =========================================================
        // En una terminación tipo cuchilla la LocationCurve empieza en la punta
        // del corte. El primer estribo no debe medirse desde esa punta, sino desde
        // la estación más interior de la cara oblicua, donde ya existe la sección
        // transversal completa.
        //
        // Para cada cara plana con componente longitudinal:
        // - se proyectan todos sus vértices sobre la curva;
        // - en el extremo inicial se usa la estación MÁXIMA de la cara;
        // - en el extremo final se usa la estación MÍNIMA de la cara.
        private bool TryObtenerIntervaloSeccionCompletaPorCarasCurvasMYG(
            DatosViga viga,
            out double inicioCompleto,
            out double finCompleto)
        {
            inicioCompleto = 0.0;
            finCompleto = 0.0;

            if (viga == null ||
                viga.CurvaEje == null ||
                viga.CurvaEje.Length <= Tol ||
                viga.SolidosGlobales == null ||
                viga.SolidosGlobales.Count == 0)
            {
                return false;
            }

            double longitud = viga.CurvaEje.Length;

            List<CaraExtremoCurvaEstriboMYG> candidatas =
                new List<CaraExtremoCurvaEstriboMYG>();

            foreach (Solid solido in viga.SolidosGlobales)
            {
                if (solido == null ||
                    solido.Volume <= Tol ||
                    solido.Faces == null)
                {
                    continue;
                }

                foreach (Face cara in solido.Faces)
                {
                    PlanarFace caraPlana = cara as PlanarFace;

                    if (caraPlana == null)
                        continue;

                    List<XYZ> vertices =
                        ObtenerVerticesCaraExtremoCurvaMYG(caraPlana);

                    if (vertices.Count < 3)
                        continue;

                    List<double> estaciones = new List<double>();

                    foreach (XYZ vertice in vertices)
                    {
                        double estacion;

                        if (TryObtenerEstacionPuntoSobreCurvaMYG(
                            viga.CurvaEje,
                            vertice,
                            out estacion))
                        {
                            estaciones.Add(estacion);
                        }
                    }

                    if (estaciones.Count < 3)
                        continue;

                    double estacionMin = estaciones.Min();
                    double estacionMax = estaciones.Max();
                    double estacionCentro = estaciones.Average();

                    XYZ centro;
                    XYZ tangente;
                    XYZ ejeY;
                    XYZ ejeZ;

                    if (!ObtenerMarcoCurvaEstriboMYG(
                        viga.CurvaEje,
                        estacionCentro,
                        out centro,
                        out tangente,
                        out ejeY,
                        out ejeZ))
                    {
                        continue;
                    }

                    XYZ normal = caraPlana.FaceNormal;

                    if (normal == null || normal.GetLength() <= Tol)
                        continue;

                    normal = normal.Normalize();

                    double componenteLongitudinal =
                        Math.Abs(normal.DotProduct(tangente));

                    // Las caras superior, inferior y laterales no sirven como
                    // límite longitudinal. La cara cuchilla sí tiene una
                    // componente clara en la dirección de la viga.
                    if (componenteLongitudinal < 0.15)
                        continue;

                    double area = 0.0;

                    try
                    {
                        area = caraPlana.Area;
                    }
                    catch
                    {
                        area = 0.0;
                    }

                    candidatas.Add(
                        new CaraExtremoCurvaEstriboMYG()
                        {
                            EstacionMin = estacionMin,
                            EstacionMax = estacionMax,
                            EstacionCentro = estacionCentro,
                            Area = area
                        });
                }
            }

            if (candidatas.Count < 2)
                return false;

            double ancho = Math.Max(0.0, viga.YMax - viga.YMin);
            double alto = Math.Max(0.0, viga.ZMax - viga.ZMin);

            double diagonalSeccion =
                Math.Sqrt((ancho * ancho) + (alto * alto));

            double profundidadBusqueda = Math.Min(
                longitud * 0.35,
                Math.Max(
                    UnitUtils.ConvertToInternalUnits(
                        50.0,
                        UnitTypeId.Centimeters),
                    diagonalSeccion * 2.0));

            List<CaraExtremoCurvaEstriboMYG> candidatasInicio =
                candidatas
                    .Where(c =>
                        c.EstacionCentro <= profundidadBusqueda + Tol)
                    .ToList();

            List<CaraExtremoCurvaEstriboMYG> candidatasFin =
                candidatas
                    .Where(c =>
                        c.EstacionCentro >=
                        longitud - profundidadBusqueda - Tol)
                    .ToList();

            if (candidatasInicio.Count == 0 ||
                candidatasFin.Count == 0)
            {
                return false;
            }

            // Se escoge la cara longitudinal más cercana a cada extremo.
            // Si hay varias prácticamente coincidentes, se prioriza la de mayor área.
            double toleranciaAgrupacion = UnitUtils.ConvertToInternalUnits(
                2.0,
                UnitTypeId.Centimeters);

            double centroMinimo =
                candidatasInicio.Min(c => c.EstacionCentro);

            CaraExtremoCurvaEstriboMYG caraInicio =
                candidatasInicio
                    .Where(c =>
                        c.EstacionCentro <=
                        centroMinimo + toleranciaAgrupacion)
                    .OrderByDescending(c => c.Area)
                    .ThenBy(c => c.EstacionCentro)
                    .FirstOrDefault();

            double centroMaximo =
                candidatasFin.Max(c => c.EstacionCentro);

            CaraExtremoCurvaEstriboMYG caraFin =
                candidatasFin
                    .Where(c =>
                        c.EstacionCentro >=
                        centroMaximo - toleranciaAgrupacion)
                    .OrderByDescending(c => c.Area)
                    .ThenByDescending(c => c.EstacionCentro)
                    .FirstOrDefault();

            if (caraInicio == null || caraFin == null)
                return false;

            // CLAVE:
            // En el inicio se toma el punto más interior de la cuchilla.
            // En el final se toma también el punto más interior hacia la viga.
            inicioCompleto = Math.Max(
                0.0,
                Math.Min(longitud, caraInicio.EstacionMax));

            finCompleto = Math.Max(
                0.0,
                Math.Min(longitud, caraFin.EstacionMin));

            double tolerancia = UnitUtils.ConvertToInternalUnits(
                0.2,
                UnitTypeId.Centimeters);

            return finCompleto > inicioCompleto + tolerancia;
        }

        private List<XYZ> ObtenerVerticesCaraExtremoCurvaMYG(
            Face cara)
        {
            List<XYZ> resultado = new List<XYZ>();

            if (cara == null)
                return resultado;

            EdgeArrayArray bucles = null;

            try
            {
                bucles = cara.EdgeLoops;
            }
            catch
            {
                bucles = null;
            }

            if (bucles == null)
                return resultado;

            double tolerancia = UnitUtils.ConvertToInternalUnits(
                0.05,
                UnitTypeId.Centimeters);

            foreach (EdgeArray bucle in bucles)
            {
                if (bucle == null)
                    continue;

                foreach (Edge arista in bucle)
                {
                    if (arista == null)
                        continue;

                    Curve curva = null;

                    try
                    {
                        curva = arista.AsCurve();
                    }
                    catch
                    {
                        curva = null;
                    }

                    if (curva == null)
                        continue;

                    for (int i = 0; i <= 1; i++)
                    {
                        XYZ punto = null;

                        try
                        {
                            punto = curva.GetEndPoint(i);
                        }
                        catch
                        {
                            punto = null;
                        }

                        if (punto == null)
                            continue;

                        bool repetido = resultado.Any(
                            p => p != null &&
                                 p.DistanceTo(punto) <= tolerancia);

                        if (!repetido)
                            resultado.Add(punto);
                    }
                }
            }

            return resultado;
        }

        private bool TryObtenerEstacionPuntoSobreCurvaMYG(
            Curve curva,
            XYZ punto,
            out double estacion)
        {
            estacion = 0.0;

            if (curva == null ||
                punto == null ||
                curva.Length <= Tol)
            {
                return false;
            }

            IntersectionResult proyeccion = null;

            try
            {
                proyeccion = curva.Project(punto);
            }
            catch
            {
                proyeccion = null;
            }

            if (proyeccion == null)
                return false;

            double parametroInicio;
            double parametroFin;

            try
            {
                parametroInicio = curva.GetEndParameter(0);
                parametroFin = curva.GetEndParameter(1);
            }
            catch
            {
                return false;
            }

            double denominador = parametroFin - parametroInicio;

            if (Math.Abs(denominador) <= 1e-12)
                return false;

            double normalizado =
                (proyeccion.Parameter - parametroInicio) /
                denominador;

            normalizado = Math.Max(
                0.0,
                Math.Min(1.0, normalizado));

            estacion = normalizado * curva.Length;
            return true;
        }


        private bool TryCalcularIntervaloUtilEstribosCurvaMYG(
            DatosViga viga,
            double inicio,
            double fin,
            double minY,
            double maxY,
            double minZ,
            double maxZ,
            out double inicioUtil,
            out double finUtil)
        {
            inicioUtil = inicio;
            finUtil = fin;

            if (viga == null || !viga.EsCurva || viga.CurvaEje == null)
                return false;

            if (viga.SolidosGlobales == null || viga.SolidosGlobales.Count == 0)
                return false;

            if (fin < inicio)
            {
                double tmp = inicio;
                inicio = fin;
                fin = tmp;
            }

            if (fin <= inicio + Tol)
                return false;

            double longitud = fin - inicio;

            // =========================================================
            // PRIMERA OPCIÓN: CARAS REALES DE LOS EXTREMOS TIPO CUCHILLA
            // =========================================================
            // Esta lectura no depende de que una sonda de sección coincida con
            // el sólido. Obtiene directamente la cara oblicua real y toma el
            // punto más interior donde ya cabe toda la sección.
            double inicioPorCara;
            double finPorCara;

            if (TryObtenerIntervaloSeccionCompletaPorCarasCurvasMYG(
                viga,
                out inicioPorCara,
                out finPorCara))
            {
                double seguridadCara = UnitUtils.ConvertToInternalUnits(
                    0.20,
                    UnitTypeId.Centimeters);

                inicioUtil = Math.Max(
                    inicio,
                    inicioPorCara + seguridadCara);

                finUtil = Math.Min(
                    fin,
                    finPorCara - seguridadCara);

                if (finUtil > inicioUtil + Tol)
                    return true;
            }

            // IMPORTANTE:
            // Para encontrar el final real de una mordida NO se comprueba el
            // rectángulo del estribo ya descontado por recubrimiento. Ese rectángulo
            // es más pequeño y puede caber dentro de la cuña antes de que la sección
            // completa de concreto exista, que era justamente el problema mostrado.
            //
            // Aquí se comprueba la sección exterior real de la viga, con solo un
            // retranqueo numérico de pocos milímetros respecto de las caras.
            double pasoMin = UnitUtils.ConvertToInternalUnits(
                0.75,
                UnitTypeId.Centimeters);

            double pasoMax = UnitUtils.ConvertToInternalUnits(
                3.0,
                UnitTypeId.Centimeters);

            double paso = Math.Max(
                pasoMin,
                Math.Min(pasoMax, longitud / 240.0));

            const int consecutivosNecesarios = 3;

            double primerValido = double.NaN;
            double ultimaEstacionInvalida = inicio;
            double primeraEstacionRacha = inicio;
            int consecutivos = 0;

            for (double s = inicio; s <= fin + Tol; s += paso)
            {
                double estacion = Math.Min(fin, s);

                bool seccionCompleta =
                    CabeSeccionCompletaCurvaEnEstacionMYG(
                        viga,
                        estacion);

                if (seccionCompleta)
                {
                    if (consecutivos == 0)
                        primeraEstacionRacha = estacion;

                    consecutivos++;

                    if (consecutivos >= consecutivosNecesarios)
                    {
                        primerValido = RefinarLimiteSeccionCompletaCurvaMYG(
                            viga,
                            Math.Max(inicio, ultimaEstacionInvalida),
                            primeraEstacionRacha,
                            true);
                        break;
                    }
                }
                else
                {
                    consecutivos = 0;
                    ultimaEstacionInvalida = estacion;
                }
            }

            if (double.IsNaN(primerValido))
                return false;

            double ultimoValido = double.NaN;
            ultimaEstacionInvalida = fin;
            double ultimaEstacionRacha = fin;
            consecutivos = 0;

            for (double s = fin; s >= inicio - Tol; s -= paso)
            {
                double estacion = Math.Max(inicio, s);

                bool seccionCompleta =
                    CabeSeccionCompletaCurvaEnEstacionMYG(
                        viga,
                        estacion);

                if (seccionCompleta)
                {
                    if (consecutivos == 0)
                        ultimaEstacionRacha = estacion;

                    consecutivos++;

                    if (consecutivos >= consecutivosNecesarios)
                    {
                        ultimoValido = RefinarLimiteSeccionCompletaCurvaMYG(
                            viga,
                            ultimaEstacionRacha,
                            Math.Min(fin, ultimaEstacionInvalida),
                            false);
                        break;
                    }
                }
                else
                {
                    consecutivos = 0;
                    ultimaEstacionInvalida = estacion;
                }
            }

            if (double.IsNaN(ultimoValido) ||
                ultimoValido <= primerValido + Tol)
            {
                return false;
            }

            // Se avanza apenas 2 mm dentro de la sección ya completa para evitar
            // que el límite coincida exactamente con la cara inclinada del corte.
            // Después, CrearSetsEstribosEnTramo agrega los 5 cm reglamentarios.
            double seguridad = UnitUtils.ConvertToInternalUnits(
                0.20,
                UnitTypeId.Centimeters);

            inicioUtil = Math.Min(ultimoValido, primerValido + seguridad);
            finUtil = Math.Max(inicioUtil, ultimoValido - seguridad);

            return finUtil > inicioUtil + Tol;
        }

        // =========================================================
        // REFINAR EL PUNTO DONDE APARECE LA SECCIÓN COMPLETA DE CONCRETO
        // =========================================================
        private double RefinarLimiteSeccionCompletaCurvaMYG(
            DatosViga viga,
            double a,
            double b,
            bool buscandoInicio)
        {
            if (b < a)
            {
                double tmp = a;
                a = b;
                b = tmp;
            }

            for (int i = 0; i < 16; i++)
            {
                double m = (a + b) * 0.5;
                bool completa = CabeSeccionCompletaCurvaEnEstacionMYG(viga, m);

                if (buscandoInicio)
                {
                    if (completa)
                        b = m;
                    else
                        a = m;
                }
                else
                {
                    if (completa)
                        a = m;
                    else
                        b = m;
                }
            }

            return buscandoInicio ? b : a;
        }

        // =========================================================
        // VALIDAR LA SECCIÓN EXTERIOR REAL, NO EL ESTRIBO INTERIOR
        // =========================================================
        // =========================================================
        // VALIDAR LA SECCIÓN EXTERIOR COMPLETA EN VIGAS CURVAS
        // =========================================================
        // El primer/último estribo debe medirse 5 cm después de que aparezca
        // la sección completa de concreto. Para detectar ese punto se evalúa
        // una malla 3 x 3 próxima a las caras exteriores de la sección.
        //
        // Esto es más estable que exigir que varias líneas largas coincidan
        // exactamente con Solid.IntersectWithCurve en familias con extremos
        // cortados, caras miteradas o pequeñas tolerancias geométricas.
        private bool CabeSeccionCompletaCurvaEnEstacionMYG(
            DatosViga viga,
            double estacion)
        {
            if (viga == null ||
                viga.CurvaEje == null ||
                viga.SolidosGlobales == null ||
                viga.SolidosGlobales.Count == 0)
            {
                return false;
            }

            XYZ centro;
            XYZ tangente;
            XYZ ejeY;
            XYZ ejeZ;

            if (!ObtenerMarcoCurvaEstriboMYG(
                viga.CurvaEje,
                estacion,
                out centro,
                out tangente,
                out ejeY,
                out ejeZ))
            {
                return false;
            }

            double ancho = viga.YMax - viga.YMin;
            double alto = viga.ZMax - viga.ZMin;

            if (ancho <= Tol || alto <= Tol)
                return false;

            // Se prueba muy cerca de las caras completas del concreto, pero sin
            // quedar exactamente sobre ellas. Así una esquina todavía cortada
            // hace fallar la estación hasta que realmente aparece toda la sección.
            double margenMin = UnitUtils.ConvertToInternalUnits(
                0.50,
                UnitTypeId.Centimeters);

            double margenMax = UnitUtils.ConvertToInternalUnits(
                1.00,
                UnitTypeId.Centimeters);

            double margen = Math.Max(
                margenMin,
                Math.Min(
                    margenMax,
                    Math.Min(ancho, alto) * 0.015));

            double y0 = viga.YMin + margen;
            double y1 = viga.YMax - margen;
            double z0 = viga.ZMin + margen;
            double z1 = viga.ZMax - margen;

            if (y1 <= y0 + Tol || z1 <= z0 + Tol)
                return false;

            double yMedio = (y0 + y1) * 0.5;
            double zMedio = (z0 + z1) * 0.5;

            double[] posicionesY = new double[]
            {
                y0,
                yMedio,
                y1
            };

            double[] posicionesZ = new double[]
            {
                z0,
                zMedio,
                z1
            };

            foreach (double y in posicionesY)
            {
                foreach (double z in posicionesZ)
                {
                    XYZ punto = centro
                        .Add(ejeY.Multiply(y))
                        .Add(ejeZ.Multiply(z));

                    if (!PuntoInteriorSeccionCurvaMYG(
                        viga.SolidosGlobales,
                        punto,
                        tangente))
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        // Comprueba que un punto pertenezca al sólido mediante una sonda corta
        // en la dirección tangencial de la viga. La sonda debe quedar cubierta
        // completamente por la unión de los sólidos del anfitrión.
        private bool PuntoInteriorSeccionCurvaMYG(
            List<Solid> solidos,
            XYZ punto,
            XYZ tangente)
        {
            if (solidos == null ||
                solidos.Count == 0 ||
                punto == null ||
                tangente == null ||
                tangente.GetLength() <= Tol)
            {
                return false;
            }

            XYZ direccion = tangente.Normalize();

            double semilongitud = UnitUtils.ConvertToInternalUnits(
                0.20,
                UnitTypeId.Centimeters);

            if (semilongitud <= Tol)
                return false;

            XYZ p0 = punto.Subtract(
                direccion.Multiply(semilongitud));

            XYZ p1 = punto.Add(
                direccion.Multiply(semilongitud));

            if (p0.DistanceTo(p1) <= Tol)
                return false;

            Line sonda;

            try
            {
                sonda = Line.CreateBound(p0, p1);
            }
            catch
            {
                return false;
            }

            return LineaCompletaDentroDeSolidosEstriboMYG(
                solidos,
                sonda);
        }


        private void AgregarLineaControlSeccionMYG(
            List<Line> destino,
            XYZ p0,
            XYZ p1)
        {
            if (destino == null || p0 == null || p1 == null)
                return;

            if (p0.DistanceTo(p1) <= Tol)
                return;

            try
            {
                destino.Add(Line.CreateBound(p0, p1));
            }
            catch
            {
            }
        }

        // Comprueba que la línea de control esté cubierta completamente por la
        // unión de los sólidos reales de la viga. Una mordida oblicua deja parte
        // de la línea fuera y por tanto la estación todavía no es sección completa.
        private bool LineaCompletaDentroDeSolidosEstriboMYG(
            List<Solid> solidos,
            Line lineaControl)
        {
            if (solidos == null || solidos.Count == 0 || lineaControl == null)
                return false;

            double longitud = lineaControl.Length;

            if (longitud <= Tol)
                return false;

            XYZ origen = lineaControl.GetEndPoint(0);
            XYZ direccion = lineaControl.Direction.Normalize();

            List<Tuple<double, double>> intervalos =
                new List<Tuple<double, double>>();

            foreach (Solid solid in solidos)
            {
                if (solid == null)
                    continue;

                try
                {
                    using (SolidCurveIntersectionOptions opciones =
                        new SolidCurveIntersectionOptions())
                    {
                        opciones.ResultType =
                            SolidCurveIntersectionMode.CurveSegmentsInside;

                        using (SolidCurveIntersection interseccion =
                            solid.IntersectWithCurve(lineaControl, opciones))
                        {
                            for (int i = 0; i < interseccion.SegmentCount; i++)
                            {
                                Curve segmento = interseccion.GetCurveSegment(i);

                                if (segmento == null || segmento.Length <= Tol)
                                    continue;

                                double t0 = (segmento.GetEndPoint(0) - origen)
                                    .DotProduct(direccion) / longitud;

                                double t1 = (segmento.GetEndPoint(1) - origen)
                                    .DotProduct(direccion) / longitud;

                                double minT = Math.Max(0.0, Math.Min(1.0, Math.Min(t0, t1)));
                                double maxT = Math.Max(0.0, Math.Min(1.0, Math.Max(t0, t1)));

                                if (maxT > minT + Tol)
                                    intervalos.Add(Tuple.Create(minT, maxT));
                            }
                        }
                    }
                }
                catch
                {
                }
            }

            if (intervalos.Count == 0)
                return false;

            intervalos = intervalos
                .OrderBy(x => x.Item1)
                .ThenBy(x => x.Item2)
                .ToList();

            double toleranciaLongitud = UnitUtils.ConvertToInternalUnits(
                0.15,
                UnitTypeId.Centimeters);

            double toleranciaT = Math.Min(
                0.05,
                toleranciaLongitud / longitud);

            double inicioCubierto = intervalos[0].Item1;
            double finCubierto = intervalos[0].Item2;

            if (inicioCubierto > toleranciaT)
                return false;

            for (int i = 1; i < intervalos.Count; i++)
            {
                Tuple<double, double> intervalo = intervalos[i];

                if (intervalo.Item1 > finCubierto + toleranciaT)
                    return false;

                if (intervalo.Item2 > finCubierto)
                    finCubierto = intervalo.Item2;
            }

            return finCubierto >= 1.0 - toleranciaT;
        }

        private double RefinarLimiteEstriboMYG(
            DatosViga viga,
            double a,
            double b,
            bool buscandoInicio,
            double minY,
            double maxY,
            double minZ,
            double maxZ)
        {
            if (b < a)
            {
                double t = a;
                a = b;
                b = t;
            }

            for (int i = 0; i < 14; i++)
            {
                double m = (a + b) / 2.0;
                bool cabe = CabeEstriboCompletoEnEstacionMYG(
                    viga,
                    m,
                    minY,
                    maxY,
                    minZ,
                    maxZ);

                if (buscandoInicio)
                {
                    if (cabe) b = m;
                    else a = m;
                }
                else
                {
                    if (cabe) a = m;
                    else b = m;
                }
            }

            return buscandoInicio ? b : a;
        }

        private bool CabeEstriboCompletoEnEstacionMYG(
            DatosViga viga,
            double estacion,
            double minY,
            double maxY,
            double minZ,
            double maxZ)
        {
            if (viga == null || viga.SolidosGlobales == null || viga.SolidosGlobales.Count == 0)
                return false;

            // En vigas curvas se usa una validación específica y tolerante.
            // El test anterior recorría todos los puntos de los cuatro lados y
            // podía devolver falsos negativos por teselado, caras miteradas o
            // pequeñas diferencias entre la LocationCurve y el sólido cortado.
            // Para una sección rectangular convexa basta comprobar las cuatro
            // esquinas útiles y el centro, aplicando un margen numérico mínimo.
            if (viga.EsCurva && viga.CurvaEje != null)
            {
                return CabeEstriboCurvoToleranteEnEstacionMYG(
                    viga,
                    estacion,
                    minY,
                    maxY,
                    minZ,
                    maxZ);
            }

            List<Curve> curvas = ConstruirCurvasEstriboValidacionMYG(
                viga,
                estacion,
                minY,
                maxY,
                minZ,
                maxZ);

            if (curvas == null || curvas.Count == 0)
                return false;

            XYZ direccionSonda = viga.XAxis;

            if (viga.EsCurva && viga.CurvaEje != null)
            {
                XYZ centro;
                XYZ tangente;
                XYZ ejeY;
                XYZ ejeZ;

                if (ObtenerMarcoCurvaEstriboMYG(
                    viga.CurvaEje,
                    estacion,
                    out centro,
                    out tangente,
                    out ejeY,
                    out ejeZ))
                {
                    direccionSonda = tangente;
                }
            }

            if (direccionSonda == null || direccionSonda.GetLength() <= Tol)
                direccionSonda = XYZ.BasisX;

            foreach (Curve curva in curvas)
            {
                if (curva == null)
                    continue;

                for (int i = 0; i <= 5; i++)
                {
                    double t = (double)i / 5.0;
                    XYZ punto = null;

                    try
                    {
                        punto = curva.Evaluate(t, true);
                    }
                    catch
                    {
                        punto = null;
                    }

                    if (punto == null ||
                        !PuntoDentroDeSolidosEstriboMYG(
                            viga.SolidosGlobales,
                            punto,
                            direccionSonda))
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        // =========================================================
        // VALIDACIÓN TOLERANTE DE SECCIÓN COMPLETA EN VIGA CURVA
        // =========================================================
        private bool CabeEstriboCurvoToleranteEnEstacionMYG(
            DatosViga viga,
            double estacion,
            double minY,
            double maxY,
            double minZ,
            double maxZ)
        {
            if (viga == null || viga.CurvaEje == null ||
                viga.SolidosGlobales == null || viga.SolidosGlobales.Count == 0)
            {
                return false;
            }

            XYZ centro;
            XYZ tangente;
            XYZ ejeY;
            XYZ ejeZ;

            if (!ObtenerMarcoCurvaEstriboMYG(
                viga.CurvaEje,
                estacion,
                out centro,
                out tangente,
                out ejeY,
                out ejeZ))
            {
                return false;
            }

            double margen1 = UnitUtils.ConvertToInternalUnits(
                0.15,
                UnitTypeId.Centimeters);

            double margen2 = UnitUtils.ConvertToInternalUnits(
                0.35,
                UnitTypeId.Centimeters);

            double margen3 = UnitUtils.ConvertToInternalUnits(
                0.60,
                UnitTypeId.Centimeters);

            double[] margenes = new double[]
            {
                margen1,
                margen2,
                margen3
            };

            foreach (double margen in margenes)
            {
                double y0 = minY + margen;
                double y1 = maxY - margen;
                double z0 = minZ + margen;
                double z1 = maxZ - margen;

                if (y1 <= y0 + Tol || z1 <= z0 + Tol)
                    continue;

                XYZ p1 = centro.Add(ejeY.Multiply(y0)).Add(ejeZ.Multiply(z0));
                XYZ p2 = centro.Add(ejeY.Multiply(y1)).Add(ejeZ.Multiply(z0));
                XYZ p3 = centro.Add(ejeY.Multiply(y1)).Add(ejeZ.Multiply(z1));
                XYZ p4 = centro.Add(ejeY.Multiply(y0)).Add(ejeZ.Multiply(z1));
                XYZ pc = centro
                    .Add(ejeY.Multiply((y0 + y1) * 0.5))
                    .Add(ejeZ.Multiply((z0 + z1) * 0.5));

                bool dentro1 = PuntoDentroDeSolidosEstriboMYG(
                    viga.SolidosGlobales,
                    p1,
                    tangente);

                bool dentro2 = PuntoDentroDeSolidosEstriboMYG(
                    viga.SolidosGlobales,
                    p2,
                    tangente);

                bool dentro3 = PuntoDentroDeSolidosEstriboMYG(
                    viga.SolidosGlobales,
                    p3,
                    tangente);

                bool dentro4 = PuntoDentroDeSolidosEstriboMYG(
                    viga.SolidosGlobales,
                    p4,
                    tangente);

                bool dentroCentro = PuntoDentroDeSolidosEstriboMYG(
                    viga.SolidosGlobales,
                    pc,
                    tangente);

                if (dentroCentro && dentro1 && dentro2 && dentro3 && dentro4)
                    return true;
            }

            return false;
        }

        private List<Curve> ConstruirCurvasEstriboValidacionMYG(
            DatosViga viga,
            double estacion,
            double minY,
            double maxY,
            double minZ,
            double maxZ)
        {
            List<Curve> resultado = new List<Curve>();

            if (viga == null)
                return resultado;

            if (viga.EsCurva && viga.CurvaEje != null)
            {
                XYZ centro;
                XYZ tangente;
                XYZ ejeY;
                XYZ ejeZ;

                if (!ObtenerMarcoCurvaEstriboMYG(
                    viga.CurvaEje,
                    estacion,
                    out centro,
                    out tangente,
                    out ejeY,
                    out ejeZ))
                {
                    return resultado;
                }

                XYZ p1 = centro.Add(ejeY.Multiply(minY)).Add(ejeZ.Multiply(minZ));
                XYZ p2 = centro.Add(ejeY.Multiply(maxY)).Add(ejeZ.Multiply(minZ));
                XYZ p3 = centro.Add(ejeY.Multiply(maxY)).Add(ejeZ.Multiply(maxZ));
                XYZ p4 = centro.Add(ejeY.Multiply(minY)).Add(ejeZ.Multiply(maxZ));

                AgregarLineaSiValida(resultado, p1, p2);
                AgregarLineaSiValida(resultado, p2, p3);
                AgregarLineaSiValida(resultado, p3, p4);
                AgregarLineaSiValida(resultado, p4, p1);
                return resultado;
            }

            XYZ centroRecto = viga.P0.Add(viga.XAxis.Multiply(estacion));

            if (EsFormaCumbreraSeleccionada())
            {
                List<List<Curve>> grupos = CrearCurvasEstribosCumbreraEntrelazados(
                    viga,
                    centroRecto,
                    minY,
                    maxY,
                    minZ,
                    maxZ,
                    0.0);

                if (grupos != null)
                {
                    foreach (List<Curve> grupo in grupos)
                    {
                        if (grupo != null)
                            resultado.AddRange(grupo.Where(c => c != null));
                    }
                }

                if (resultado.Count > 0)
                    return resultado;
            }

            return CrearCurvasEstriboRectangular(
                viga,
                centroRecto,
                minY,
                maxY,
                minZ,
                maxZ);
        }

        private bool PuntoDentroDeSolidosEstriboMYG(
            List<Solid> solidos,
            XYZ punto,
            XYZ direccion)
        {
            if (solidos == null || solidos.Count == 0 || punto == null)
                return false;

            List<XYZ> direcciones = new List<XYZ>();

            AgregarDireccionSondaEstriboMYG(direcciones, direccion);
            AgregarDireccionSondaEstriboMYG(direcciones, XYZ.BasisX);
            AgregarDireccionSondaEstriboMYG(direcciones, XYZ.BasisY);
            AgregarDireccionSondaEstriboMYG(direcciones, XYZ.BasisZ);

            if (direccion != null && direccion.GetLength() > Tol)
            {
                XYZ lateral = XYZ.BasisZ.CrossProduct(direccion);
                AgregarDireccionSondaEstriboMYG(direcciones, lateral);
            }

            if (direcciones.Count == 0)
                direcciones.Add(XYZ.BasisX);

            // La línea larga evita el falso negativo que se producía cuando una
            // sonda muy corta quedaba completamente contenida o casi coincidente
            // con una cara numérica del sólido.
            double semilongitud = UnitUtils.ConvertToInternalUnits(
                1.00,
                UnitTypeId.Meters);

            double desplazamiento = UnitUtils.ConvertToInternalUnits(
                0.10,
                UnitTypeId.Centimeters);

            double tolerancia = UnitUtils.ConvertToInternalUnits(
                0.50,
                UnitTypeId.Centimeters);

            List<XYZ> candidatos = new List<XYZ>()
            {
                punto,
                punto.Add(XYZ.BasisX.Multiply(desplazamiento)),
                punto.Subtract(XYZ.BasisX.Multiply(desplazamiento)),
                punto.Add(XYZ.BasisY.Multiply(desplazamiento)),
                punto.Subtract(XYZ.BasisY.Multiply(desplazamiento)),
                punto.Add(XYZ.BasisZ.Multiply(desplazamiento)),
                punto.Subtract(XYZ.BasisZ.Multiply(desplazamiento))
            };

            foreach (Solid solid in solidos)
            {
                if (solid == null)
                    continue;

                foreach (XYZ candidato in candidatos)
                {
                    if (candidato == null)
                        continue;

                    foreach (XYZ dir in direcciones)
                    {
                        if (dir == null || dir.GetLength() <= Tol)
                            continue;

                        XYZ d = dir.Normalize();
                        Line sonda = null;

                        try
                        {
                            sonda = Line.CreateBound(
                                candidato.Subtract(d.Multiply(semilongitud)),
                                candidato.Add(d.Multiply(semilongitud)));
                        }
                        catch
                        {
                            sonda = null;
                        }

                        if (sonda == null)
                            continue;

                        try
                        {
                            using (SolidCurveIntersectionOptions opciones =
                                new SolidCurveIntersectionOptions())
                            {
                                opciones.ResultType =
                                    SolidCurveIntersectionMode.CurveSegmentsInside;

                                using (SolidCurveIntersection interseccion =
                                    solid.IntersectWithCurve(sonda, opciones))
                                {
                                    for (int i = 0; i < interseccion.SegmentCount; i++)
                                    {
                                        Curve segmento = interseccion.GetCurveSegment(i);

                                        if (segmento == null || segmento.Length <= Tol)
                                            continue;

                                        XYZ a = segmento.GetEndPoint(0);
                                        XYZ b = segmento.GetEndPoint(1);

                                        double error = Math.Abs(
                                            candidato.DistanceTo(a) +
                                            candidato.DistanceTo(b) -
                                            segmento.Length);

                                        if (error <= tolerancia)
                                            return true;
                                    }
                                }
                            }
                        }
                        catch
                        {
                        }
                    }
                }
            }

            return false;
        }

        private void AgregarDireccionSondaEstriboMYG(
            List<XYZ> direcciones,
            XYZ direccion)
        {
            if (direcciones == null || direccion == null ||
                direccion.GetLength() <= Tol)
            {
                return;
            }

            XYZ d = direccion.Normalize();

            foreach (XYZ existente in direcciones)
            {
                if (existente == null || existente.GetLength() <= Tol)
                    continue;

                double paralelismo = Math.Abs(
                    existente.Normalize().DotProduct(d));

                if (paralelismo >= 0.999)
                    return;
            }

            direcciones.Add(d);
        }

        private List<Solid> ObtenerSolidosElementoParaValidacionEstriboMYG(Element elemento)
        {
            List<Solid> resultado = new List<Solid>();

            if (elemento == null)
                return resultado;

            Options opciones = new Options();
            opciones.DetailLevel = ViewDetailLevel.Fine;
            opciones.IncludeNonVisibleObjects = false;
            opciones.ComputeReferences = false;

            GeometryElement geometria = null;

            try
            {
                geometria = elemento.get_Geometry(opciones);
            }
            catch
            {
                geometria = null;
            }

            RecolectarSolidosParaValidacionEstriboMYG(
                geometria,
                Transform.Identity,
                resultado);

            return resultado;
        }

        private void RecolectarSolidosParaValidacionEstriboMYG(
            GeometryElement geometria,
            Transform transformacion,
            List<Solid> destino)
        {
            if (geometria == null || destino == null)
                return;

            foreach (GeometryObject objeto in geometria)
            {
                if (objeto == null)
                    continue;

                Solid solid = objeto as Solid;

                if (solid != null)
                {
                    try
                    {
                        if (solid.Volume <= Tol || solid.Faces == null || solid.Faces.Size == 0)
                            continue;

                        Solid copia = solid;

                        if (transformacion != null && !transformacion.IsIdentity)
                            copia = SolidUtils.CreateTransformed(solid, transformacion);

                        if (copia != null && copia.Volume > Tol)
                            destino.Add(copia);
                    }
                    catch
                    {
                    }

                    continue;
                }

                GeometryInstance instancia = objeto as GeometryInstance;

                if (instancia == null)
                    continue;

                bool procesada = false;

                try
                {
                    GeometryElement geometriaInstancia = instancia.GetInstanceGeometry();

                    if (geometriaInstancia != null)
                    {
                        RecolectarSolidosParaValidacionEstriboMYG(
                            geometriaInstancia,
                            Transform.Identity,
                            destino);

                        procesada = true;
                    }
                }
                catch
                {
                    procesada = false;
                }

                if (procesada)
                    continue;

                try
                {
                    GeometryElement geometriaSimbolo = instancia.GetSymbolGeometry();

                    if (geometriaSimbolo != null)
                    {
                        Transform t = transformacion == null
                            ? instancia.Transform
                            : transformacion.Multiply(instancia.Transform);

                        RecolectarSolidosParaValidacionEstriboMYG(
                            geometriaSimbolo,
                            t,
                            destino);
                    }
                }
                catch
                {
                }
            }
        }

        private int CrearSetsEstribosEnTramo(
            Document doc,
            DatosViga viga,
            RebarBarType tipoEstribo,
            RebarHookType ganchoEstribo135,
            AceroEstribosVigasForm.TramoEstriboConfig cfg,
            double tramoInicio,
            double tramoFin,
            double minY,
            double maxY,
            double minZ,
            double maxZ,
            double recubrimientoFt)
        {
            if (doc == null || viga == null || cfg == null)
                return 0;

            int totalBarras = 0;
            int n = Math.Max(1, Math.Min(4, cfg.TipoDistribucion));

            double inicioUtilMordida = tramoInicio;
            double finUtilMordida = tramoFin;
            bool mordidaInterna = false;

            // VIGAS RECTAS:
            // conserva la detección completa, incluyendo mordidas internas.
            if (!viga.EsCurva && TryCalcularIntervaloUtilEstribosMYG(
                viga,
                tramoInicio,
                tramoFin,
                minY,
                maxY,
                minZ,
                maxZ,
                out inicioUtilMordida,
                out finUtilMordida,
                out mordidaInterna))
            {
                tramoInicio = Math.Max(tramoInicio, inicioUtilMordida);
                tramoFin = Math.Min(tramoFin, finUtilMordida);
                viga.TieneMordidaInternaEstribos = mordidaInterna;
            }
            // VIGAS CURVAS:
            // recorta cada extremo hasta la primera estación donde aparece la
            // SECCIÓN EXTERIOR COMPLETA DE CONCRETO. No usa el rectángulo interior
            // del estribo porque este puede caber prematuramente dentro de una cuña.
            // Después de ese límite se mantienen los 5 cm del primer/último estribo.
            else if (viga.EsCurva && TryCalcularIntervaloUtilEstribosCurvaMYG(
                viga,
                tramoInicio,
                tramoFin,
                minY,
                maxY,
                minZ,
                maxZ,
                out inicioUtilMordida,
                out finUtilMordida))
            {
                tramoInicio = Math.Max(tramoInicio, inicioUtilMordida);
                tramoFin = Math.Min(tramoFin, finUtilMordida);
                viga.TieneMordidaInternaEstribos = false;
            }
            else if (viga.EsCurva)
            {
                // Respaldo conservador:
                // nunca se vuelve directamente a 0..L, porque eso colocaría
                // estribos desde la punta de la cuchilla. Si excepcionalmente
                // no se logra identificar la cara extrema, se retira como máximo
                // una diagonal de sección desde cada extremo.
                double anchoSeccion = Math.Max(
                    0.0,
                    viga.YMax - viga.YMin);

                double altoSeccion = Math.Max(
                    0.0,
                    viga.ZMax - viga.ZMin);

                double retiroRespaldo = Math.Sqrt(
                    (anchoSeccion * anchoSeccion) +
                    (altoSeccion * altoSeccion));

                retiroRespaldo = Math.Min(
                    retiroRespaldo,
                    Math.Max(
                        0.0,
                        (tramoFin - tramoInicio) * 0.20));

                if (retiroRespaldo > Tol)
                {
                    tramoInicio += retiroRespaldo;
                    tramoFin -= retiroRespaldo;
                }

                viga.TieneMordidaInternaEstribos = false;
            }

            if (tramoFin <= tramoInicio + Tol)
                return 0;

            double offsetFt = UnitUtils.ConvertToInternalUnits(
                OFFSET_PRIMER_ESTRIBO_CM,
                UnitTypeId.Centimeters);

            double longitudTramo = tramoFin - tramoInicio;

            if (longitudTramo <= 2.0 * offsetFt + Tol)
                return 0;

            double limiteInicio = tramoInicio + offsetFt;
            double limiteFin = tramoFin - offsetFt;

            if (limiteFin <= limiteInicio + Tol)
                return 0;

            // =========================================================
            // SECCIÓN VARIABLE LONGITUDINAL / CUMBRERA
            // =========================================================
            // Esta decisión no separa rectangular y cumbrera por distribución.
            // La distribución se calcula una sola vez por estación X.
            // Luego CrearEstribosBase(...) decide si crea rectangular o cumbrera
            // según la forma seleccionada/detectada.
            bool crearExactoPorBarra =
                DebeCrearEstribosIndividualesPorSeccionVariable(viga);

            if (n == 1)
            {
                double sepFt = UnitUtils.ConvertToInternalUnits(
                    cfg.SeparacionesCm[0],
                    UnitTypeId.Centimeters);

                if (sepFt <= Tol)
                    return 0;

                // Tipo 1 = Separación constante, pero en ejecución se trata como
                // ESPACIAMIENTO MÁXIMO, siempre respetando 5 cm en ambos extremos.
                if (crearExactoPorBarra)
                {
                    totalBarras += CrearEstribosIndividualesEspaciadoMaximo(
                        doc,
                        viga,
                        tipoEstribo,
                        ganchoEstribo135,
                        limiteInicio,
                        limiteFin,
                        sepFt,
                        limiteInicio,
                        limiteFin,
                        minY,
                        maxY,
                        minZ,
                        maxZ,
                        recubrimientoFt);
                }
                else
                {
                    totalBarras += CrearSetEspaciadoMaximo(
                        doc,
                        viga,
                        tipoEstribo,
                        ganchoEstribo135,
                        limiteInicio,
                        limiteFin,
                        sepFt,
                        limiteInicio,
                        limiteFin,
                        minY,
                        maxY,
                        minZ,
                        maxZ);
                }

                return totalBarras;
            }

            double ultimoIzq = limiteInicio;
            double ultimoDer = limiteFin;
            bool hayZonaExtremo = false;

            for (int zona = 0; zona < n - 1; zona++)
            {
                double sepCm = cfg.SeparacionesCm[zona];
                int cantidadSolicitada = cfg.Cantidades[zona];

                if (sepCm <= 0.0 || cantidadSolicitada <= 0)
                    continue;

                double sepFt = UnitUtils.ConvertToInternalUnits(
                    sepCm,
                    UnitTypeId.Centimeters);

                if (sepFt <= Tol)
                    continue;

                // CLAVE:
                // Zona 1 arranca a 5 cm de la cara.
                // Zona 2, 3, etc. arrancan con SU PROPIA separación
                // desde el último estribo colocado, en ambos extremos.
                double primerIzq = hayZonaExtremo
                    ? ultimoIzq + sepFt
                    : limiteInicio;

                double primerDer = hayZonaExtremo
                    ? ultimoDer - sepFt
                    : limiteFin;

                int cantidadUsada = AjustarCantidadSimetricaPorLongitud(
                    cantidadSolicitada,
                    sepFt,
                    primerIzq,
                    primerDer);

                if (cantidadUsada <= 0)
                    break;

                double ultimoBloqueIzq =
                    primerIzq + ((cantidadUsada - 1) * sepFt);

                double inicioBloqueDer =
                    primerDer - ((cantidadUsada - 1) * sepFt);

                if (ultimoBloqueIzq > inicioBloqueDer + Tol)
                    break;

                if (crearExactoPorBarra)
                {
                    totalBarras += CrearEstribosIndividualesNumeroConEspaciado(
                        doc,
                        viga,
                        tipoEstribo,
                        ganchoEstribo135,
                        primerIzq,
                        sepFt,
                        cantidadUsada,
                        limiteInicio,
                        limiteFin,
                        minY,
                        maxY,
                        minZ,
                        maxZ,
                        recubrimientoFt);
                }
                else
                {
                    totalBarras += CrearSetNumeroConEspaciado(
                        doc,
                        viga,
                        tipoEstribo,
                        ganchoEstribo135,
                        primerIzq,
                        sepFt,
                        cantidadUsada,
                        limiteInicio,
                        limiteFin,
                        minY,
                        maxY,
                        minZ,
                        maxZ);
                }

                // Bloque del extremo derecho: se crea de izquierda a derecha,
                // pero su ubicación viene medida desde la cara derecha hacia el centro.
                if (inicioBloqueDer > ultimoBloqueIzq + Tol)
                {
                    if (crearExactoPorBarra)
                    {
                        totalBarras += CrearEstribosIndividualesNumeroConEspaciado(
                            doc,
                            viga,
                            tipoEstribo,
                            ganchoEstribo135,
                            inicioBloqueDer,
                            sepFt,
                            cantidadUsada,
                            limiteInicio,
                            limiteFin,
                            minY,
                            maxY,
                            minZ,
                            maxZ,
                            recubrimientoFt);
                    }
                    else
                    {
                        totalBarras += CrearSetNumeroConEspaciado(
                            doc,
                            viga,
                            tipoEstribo,
                            ganchoEstribo135,
                            inicioBloqueDer,
                            sepFt,
                            cantidadUsada,
                            limiteInicio,
                            limiteFin,
                            minY,
                            maxY,
                            minZ,
                            maxZ);
                    }
                }

                ultimoIzq = ultimoBloqueIzq;
                ultimoDer = inicioBloqueDer;
                hayZonaExtremo = true;
            }

            int idxResto = n - 1;

            if (idxResto >= 0 &&
                idxResto < cfg.SeparacionesCm.Length &&
                cfg.SeparacionesCm[idxResto] > 0.0)
            {
                double sepRestoFt = UnitUtils.ConvertToInternalUnits(
                    cfg.SeparacionesCm[idxResto],
                    UnitTypeId.Centimeters);

                // RESTO:
                // Primero se calcula el espaciamiento real usando TODO el rango
                // central disponible entre el último estribo fijo izquierdo y el
                // último estribo fijo derecho.
                // Luego el rango REAL de creación del RESTO empieza en el primer
                // espaciamiento interior y termina en el penúltimo espaciamiento
                // interior, tal como se indicó en las flechas.
                double inicioResto = hayZonaExtremo
                    ? ultimoIzq
                    : limiteInicio;

                double finResto = hayZonaExtremo
                    ? ultimoDer
                    : limiteFin;

                if (sepRestoFt > Tol &&
                    finResto > inicioResto + Tol)
                {
                    double inicioCreacionResto = inicioResto;
                    double finCreacionResto = finResto;

                    if (hayZonaExtremo)
                    {
                        double longitudTotalResto = finResto - inicioResto;
                        int cantidadTotalResto = Math.Max(
                            2,
                            (int)Math.Ceiling(longitudTotalResto / sepRestoFt) + 1);

                        if (cantidadTotalResto > 2)
                        {
                            double separacionRealResto = longitudTotalResto / (cantidadTotalResto - 1);
                            inicioCreacionResto = inicioResto + separacionRealResto;
                            finCreacionResto = finResto - separacionRealResto;
                        }
                        else
                        {
                            inicioCreacionResto = 0.0;
                            finCreacionResto = 0.0;
                        }
                    }

                    if (finCreacionResto > inicioCreacionResto + Tol)
                    {
                        if (crearExactoPorBarra)
                        {
                            totalBarras += CrearEstribosIndividualesEspaciadoMaximo(
                                doc,
                                viga,
                                tipoEstribo,
                                ganchoEstribo135,
                                inicioCreacionResto,
                                finCreacionResto,
                                sepRestoFt,
                                limiteInicio,
                                limiteFin,
                                minY,
                                maxY,
                                minZ,
                                maxZ,
                                recubrimientoFt,
                                true,
                                true);
                        }
                        else
                        {
                            totalBarras += CrearSetEspaciadoMaximo(
                                doc,
                                viga,
                                tipoEstribo,
                                ganchoEstribo135,
                                inicioCreacionResto,
                                finCreacionResto,
                                sepRestoFt,
                                limiteInicio,
                                limiteFin,
                                minY,
                                maxY,
                                minZ,
                                maxZ,
                                true,
                                true);
                        }
                    }
                }
            }

            return totalBarras;
        }

        private bool DebeCrearEstribosIndividualesPorSeccionVariable(
            DatosViga viga)
        {
            if (viga == null)
                return false;

            if (viga.EsCurva)
                return true;

            if (viga.TieneMordidaInternaEstribos)
                return true;

            if (viga.TieneSeccionVariableEstribos)
                return true;

            double toleranciaCambio = UnitUtils.ConvertToInternalUnits(
                0.5,
                UnitTypeId.Centimeters);

            if (viga.TienePerfilZLinealEstribos)
            {
                double variacionSuperior = Math.Abs(
                    viga.ZSuperiorFin - viga.ZSuperiorInicio);

                double variacionInferior = Math.Abs(
                    viga.ZInferiorFin - viga.ZInferiorInicio);

                double peralteInicio = viga.ZSuperiorInicio - viga.ZInferiorInicio;
                double peralteFin = viga.ZSuperiorFin - viga.ZInferiorFin;
                double variacionPeralte = Math.Abs(peralteFin - peralteInicio);

                if (variacionSuperior > toleranciaCambio ||
                    variacionInferior > toleranciaCambio ||
                    variacionPeralte > toleranciaCambio)
                {
                    return true;
                }
            }

            return DetectarCambioZPorMuestrasDeSolido(viga, toleranciaCambio);
        }

        private bool DetectarCambioZPorMuestrasDeSolido(
            DatosViga viga,
            double toleranciaCambio)
        {
            if (viga == null)
                return false;

            double solidoMin = Math.Min(viga.SolidoMin, viga.SolidoMax);
            double solidoMax = Math.Max(viga.SolidoMin, viga.SolidoMax);

            if (solidoMax <= solidoMin + Tol)
                return false;

            double zMin0, zMax0;
            double zMin1, zMax1;
            double zMin2, zMax2;

            bool ok0 = TryObtenerRangoZDesdePuntosSolidoEnEstacion(
                viga,
                solidoMin,
                out zMin0,
                out zMax0);

            bool ok1 = TryObtenerRangoZDesdePuntosSolidoEnEstacion(
                viga,
                solidoMin + (solidoMax - solidoMin) * 0.50,
                out zMin1,
                out zMax1);

            bool ok2 = TryObtenerRangoZDesdePuntosSolidoEnEstacion(
                viga,
                solidoMax,
                out zMin2,
                out zMax2);

            if (!ok0 || !ok1 || !ok2)
                return false;

            double peralte0 = zMax0 - zMin0;
            double peralte1 = zMax1 - zMin1;
            double peralte2 = zMax2 - zMin2;

            return
                Math.Abs(zMin1 - zMin0) > toleranciaCambio ||
                Math.Abs(zMin2 - zMin0) > toleranciaCambio ||
                Math.Abs(zMax1 - zMax0) > toleranciaCambio ||
                Math.Abs(zMax2 - zMax0) > toleranciaCambio ||
                Math.Abs(peralte1 - peralte0) > toleranciaCambio ||
                Math.Abs(peralte2 - peralte0) > toleranciaCambio;
        }

        private int CrearEstribosIndividualesNumeroConEspaciado(
            Document doc,
            DatosViga viga,
            RebarBarType tipoEstribo,
            RebarHookType ganchoEstribo135,
            double estacionInicio,
            double separacionFt,
            int cantidad,
            double limiteInicio,
            double limiteFin,
            double minY,
            double maxY,
            double minZFallback,
            double maxZFallback,
            double recubrimientoFt)
        {
            if (doc == null || viga == null || viga.Elemento == null)
                return 0;

            if (cantidad <= 0 || separacionFt <= Tol)
                return 0;

            int creados = 0;

            for (int i = 0; i < cantidad; i++)
            {
                double estacion = estacionInicio + (i * separacionFt);

                if (estacion < limiteInicio - Tol || estacion > limiteFin + Tol)
                    continue;

                List<Rebar> rbsIndividuales = CrearEstribosIndividualesExactosEnEstacion(
                    doc,
                    viga,
                    tipoEstribo,
                    ganchoEstribo135,
                    estacion,
                    minY,
                    maxY,
                    minZFallback,
                    maxZFallback,
                    recubrimientoFt);

                if (rbsIndividuales != null && rbsIndividuales.Count > 0)
                {
                    foreach (Rebar rbIndividual in rbsIndividuales)
                    {
                        if (rbIndividual == null)
                            continue;

                        AplicarSeparacionEtiqueta(
                            rbIndividual,
                            separacionFt);

                        creados++;
                    }
                }
            }

            return creados;
        }

        private int CrearEstribosIndividualesEspaciadoMaximo(
            Document doc,
            DatosViga viga,
            RebarBarType tipoEstribo,
            RebarHookType ganchoEstribo135,
            double estacionInicio,
            double estacionFin,
            double separacionMaximaFt,
            double limiteInicio,
            double limiteFin,
            double minY,
            double maxY,
            double minZFallback,
            double maxZFallback,
            double recubrimientoFt,
            bool incluirPrimeraBarra = true,
            bool incluirUltimaBarra = true)
        {
            if (doc == null || viga == null || viga.Elemento == null)
                return 0;

            if (separacionMaximaFt <= Tol)
                return 0;

            if (estacionInicio < limiteInicio - Tol)
                return 0;

            if (estacionFin > limiteFin + Tol)
                return 0;

            double longitud = estacionFin - estacionInicio;

            if (longitud <= Tol)
                return 0;

            // RESTO:
            // primero se calcula la separación real con TODO el rango
            // disponible entre los estribos fijos extremos.
            // Luego, si esos extremos ya existen, solo se crean las barras
            // interiores para evitar superposición.
            int cantidad = Math.Max(2, (int)Math.Ceiling(longitud / separacionMaximaFt) + 1);
            double separacionReal = longitud / (cantidad - 1);

            int creados = 0;

            int indiceInicio = incluirPrimeraBarra ? 0 : 1;
            int indiceFinExclusivo = incluirUltimaBarra ? cantidad : cantidad - 1;

            if (indiceFinExclusivo <= indiceInicio)
                return 0;

            for (int i = indiceInicio; i < indiceFinExclusivo; i++)
            {
                double estacion = estacionInicio + (i * separacionReal);

                if (i == cantidad - 1)
                    estacion = estacionFin;

                if (estacion < limiteInicio - Tol || estacion > limiteFin + Tol)
                    continue;

                List<Rebar> rbsIndividuales = CrearEstribosIndividualesExactosEnEstacion(
                    doc,
                    viga,
                    tipoEstribo,
                    ganchoEstribo135,
                    estacion,
                    minY,
                    maxY,
                    minZFallback,
                    maxZFallback,
                    recubrimientoFt);

                if (rbsIndividuales != null && rbsIndividuales.Count > 0)
                {
                    foreach (Rebar rbIndividual in rbsIndividuales)
                    {
                        if (rbIndividual == null)
                            continue;

                        AplicarSeparacionEtiqueta(
                            rbIndividual,
                            separacionMaximaFt);

                        creados++;
                    }
                }
            }

            return creados;
        }

        private List<Rebar> CrearEstribosIndividualesExactosEnEstacion(
            Document doc,
            DatosViga viga,
            RebarBarType tipoEstribo,
            RebarHookType ganchoEstribo135,
            double estacion,
            double minY,
            double maxY,
            double minZFallback,
            double maxZFallback,
            double recubrimientoFt)
        {
            double minYExacto = minY;
            double maxYExacto = maxY;

            // =========================================================
            // VIGAS CURVAS: RECUBRIMIENTO LATERAL POR CADA ESTACIÓN
            // =========================================================
            // YMin/YMax de DatosViga se obtienen en la sección media de la viga.
            // En un arco, una unión, un corte oblicuo o una familia cuyo eje no
            // coincide exactamente con el centro de la sección, reutilizar esos
            // límites en toda la longitud puede desplazar uno de los laterales.
            //
            // Por eso, para cada estribo se intersecta el sólido real con líneas
            // contenidas en el plano transversal local y se obtienen nuevamente
            // las dos caras laterales. El recubrimiento se aplica desde esas caras
            // locales reales, no desde la envolvente calculada en el punto medio.
            if (viga != null && viga.EsCurva)
            {
                ObtenerLimitesYExactosCurvaEnEstacionMYG(
                    viga,
                    estacion,
                    recubrimientoFt,
                    minY,
                    maxY,
                    minZFallback,
                    maxZFallback,
                    out minYExacto,
                    out maxYExacto);

                if (maxYExacto <= minYExacto + Tol)
                    return new List<Rebar>();
            }

            if (viga != null &&
                viga.SolidosGlobales != null &&
                viga.SolidosGlobales.Count > 0 &&
                viga.TieneMordidaInternaEstribos &&
                !CabeEstriboCompletoEnEstacionMYG(
                    viga,
                    estacion,
                    minYExacto,
                    maxYExacto,
                    minZFallback,
                    maxZFallback))
            {
                // No crea barras en estaciones donde la sección está mordida,
                // aun cuando la distribución matemática incluya esa posición.
                return new List<Rebar>();
            }

            if (viga != null && viga.EsCurva)
            {
                return CrearEstribosBase(
                    doc,
                    viga,
                    tipoEstribo,
                    ganchoEstribo135,
                    estacion,
                    minYExacto,
                    maxYExacto,
                    minZFallback,
                    maxZFallback);
            }

            double minZExacto;
            double maxZExacto;

            ObtenerLimitesZExactosEnEstacion(
                viga,
                estacion,
                recubrimientoFt,
                minZFallback,
                maxZFallback,
                out minZExacto,
                out maxZExacto);

            if (maxZExacto <= minZExacto + Tol)
                return new List<Rebar>();

            return CrearEstribosBase(
                doc,
                viga,
                tipoEstribo,
                ganchoEstribo135,
                estacion,
                minYExacto,
                maxYExacto,
                minZExacto,
                maxZExacto);
        }

        // =========================================================
        // LÍMITES LATERALES REALES EN UNA SECCIÓN DE VIGA CURVA
        // =========================================================
        private bool ObtenerLimitesYExactosCurvaEnEstacionMYG(
            DatosViga viga,
            double estacion,
            double recubrimientoFt,
            double minYFallback,
            double maxYFallback,
            double minZFallback,
            double maxZFallback,
            out double minYExacto,
            out double maxYExacto)
        {
            minYExacto = minYFallback;
            maxYExacto = maxYFallback;

            if (viga == null ||
                !viga.EsCurva ||
                viga.CurvaEje == null ||
                viga.SolidosGlobales == null ||
                viga.SolidosGlobales.Count == 0)
            {
                return false;
            }

            XYZ centro;
            XYZ tangente;
            XYZ ejeY;
            XYZ ejeZ;

            if (!ObtenerMarcoCurvaEstriboMYG(
                viga.CurvaEje,
                estacion,
                out centro,
                out tangente,
                out ejeY,
                out ejeZ))
            {
                return false;
            }

            if (centro == null ||
                ejeY == null || ejeY.GetLength() <= Tol ||
                ejeZ == null || ejeZ.GetLength() <= Tol)
            {
                return false;
            }

            ejeY = ejeY.Normalize();
            ejeZ = ejeZ.Normalize();

            double altoUtilFallback =
                maxZFallback - minZFallback;

            if (altoUtilFallback <= Tol)
                return false;

            // Se evalúan tres alturas interiores. Tomar la intersección común
            // de sus anchos evita que una esquina achaflanada, una mordida o una
            // cara oblicua haga que un lateral del estribo salga del concreto.
            List<double> nivelesZ = new List<double>()
            {
                (minZFallback + maxZFallback) * 0.50,
                minZFallback + (altoUtilFallback * 0.25),
                minZFallback + (altoUtilFallback * 0.75)
            };

            List<IntervaloColumnaSerie> intervalosY =
                new List<IntervaloColumnaSerie>();

            foreach (double zLocal in nivelesZ)
            {
                XYZ origenSonda =
                    centro.Add(ejeZ.Multiply(zLocal));

                double yMinSonda;
                double yMaxSonda;

                if (TryObtenerIntervaloSolidoPorSondaCurvaMYG(
                    viga.SolidosGlobales,
                    centro,
                    origenSonda,
                    ejeY,
                    ejeY,
                    out yMinSonda,
                    out yMaxSonda))
                {
                    intervalosY.Add(
                        new IntervaloColumnaSerie(
                            yMinSonda,
                            yMaxSonda));
                }
            }

            if (intervalosY.Count == 0)
                return false;

            // Límite conservador común a todas las alturas ensayadas.
            double yMinSolido =
                intervalosY.Max(x => x.Min);

            double yMaxSolido =
                intervalosY.Min(x => x.Max);

            if (yMaxSolido <= yMinSolido + Tol)
            {
                // Respaldo: se usa el intervalo más ancho, normalmente el de la
                // altura media, sin abandonar la creación completa del tramo.
                IntervaloColumnaSerie mejor =
                    intervalosY
                        .OrderByDescending(x => x.Width)
                        .FirstOrDefault();

                if (mejor == null)
                    return false;

                yMinSolido = mejor.Min;
                yMaxSolido = mejor.Max;
            }

            double anchoSolido =
                yMaxSolido - yMinSolido;

            double anchoFallbackSinRecubrimiento =
                (maxYFallback - minYFallback) +
                (2.0 * recubrimientoFt);

            // Descarta intersecciones claramente ajenas a la sección principal.
            if (anchoFallbackSinRecubrimiento > Tol)
            {
                double relacion =
                    anchoSolido /
                    anchoFallbackSinRecubrimiento;

                if (relacion < 0.35 || relacion > 2.50)
                    return false;
            }

            double candidatoMin =
                yMinSolido + recubrimientoFt;

            double candidatoMax =
                yMaxSolido - recubrimientoFt;

            if (candidatoMax <= candidatoMin + Tol)
                return false;

            minYExacto = candidatoMin;
            maxYExacto = candidatoMax;

            return true;
        }

        private bool TryObtenerIntervaloSolidoPorSondaCurvaMYG(
            List<Solid> solidos,
            XYZ origenMarco,
            XYZ origenSonda,
            XYZ direccionSonda,
            XYZ ejeCoordenada,
            out double valorMin,
            out double valorMax)
        {
            valorMin = double.MaxValue;
            valorMax = double.MinValue;

            if (solidos == null ||
                solidos.Count == 0 ||
                origenMarco == null ||
                origenSonda == null ||
                direccionSonda == null ||
                direccionSonda.GetLength() <= Tol ||
                ejeCoordenada == null ||
                ejeCoordenada.GetLength() <= Tol)
            {
                return false;
            }

            XYZ direccion =
                direccionSonda.Normalize();

            XYZ eje =
                ejeCoordenada.Normalize();

            double semilongitud =
                UnitUtils.ConvertToInternalUnits(
                    5.0,
                    UnitTypeId.Meters);

            Line sonda = null;

            try
            {
                sonda = Line.CreateBound(
                    origenSonda.Subtract(
                        direccion.Multiply(semilongitud)),
                    origenSonda.Add(
                        direccion.Multiply(semilongitud)));
            }
            catch
            {
                sonda = null;
            }

            if (sonda == null)
                return false;

            List<IntervaloColumnaSerie> intervalos =
                new List<IntervaloColumnaSerie>();

            foreach (Solid solido in solidos)
            {
                if (solido == null)
                    continue;

                try
                {
                    using (SolidCurveIntersectionOptions opciones =
                        new SolidCurveIntersectionOptions())
                    {
                        opciones.ResultType =
                            SolidCurveIntersectionMode.CurveSegmentsInside;

                        using (SolidCurveIntersection interseccion =
                            solido.IntersectWithCurve(
                                sonda,
                                opciones))
                        {
                            for (int i = 0;
                                 i < interseccion.SegmentCount;
                                 i++)
                            {
                                Curve segmento =
                                    interseccion.GetCurveSegment(i);

                                if (segmento == null ||
                                    segmento.Length <= Tol)
                                {
                                    continue;
                                }

                                XYZ p0 =
                                    segmento.GetEndPoint(0);

                                XYZ p1 =
                                    segmento.GetEndPoint(1);

                                if (p0 == null || p1 == null)
                                    continue;

                                double a =
                                    (p0 - origenMarco)
                                        .DotProduct(eje);

                                double b =
                                    (p1 - origenMarco)
                                        .DotProduct(eje);

                                if (Math.Abs(b - a) <= Tol)
                                    continue;

                                intervalos.Add(
                                    new IntervaloColumnaSerie(
                                        Math.Min(a, b),
                                        Math.Max(a, b)));
                            }
                        }
                    }
                }
                catch
                {
                }
            }

            if (intervalos.Count == 0)
                return false;

            // Fusiona intervalos contiguos del mismo sólido o de sólidos
            // coincidentes para no perder una sección compuesta.
            double toleranciaUnion =
                UnitUtils.ConvertToInternalUnits(
                    0.20,
                    UnitTypeId.Centimeters);

            List<IntervaloColumnaSerie> ordenados =
                intervalos
                    .OrderBy(x => x.Min)
                    .ThenBy(x => x.Max)
                    .ToList();

            List<IntervaloColumnaSerie> fusionados =
                new List<IntervaloColumnaSerie>();

            foreach (IntervaloColumnaSerie intervalo
                in ordenados)
            {
                if (intervalo == null ||
                    intervalo.Max <= intervalo.Min + Tol)
                {
                    continue;
                }

                if (fusionados.Count == 0)
                {
                    fusionados.Add(
                        new IntervaloColumnaSerie(
                            intervalo.Min,
                            intervalo.Max));

                    continue;
                }

                IntervaloColumnaSerie ultimo =
                    fusionados[fusionados.Count - 1];

                if (intervalo.Min <=
                    ultimo.Max + toleranciaUnion)
                {
                    ultimo.Max =
                        Math.Max(
                            ultimo.Max,
                            intervalo.Max);
                }
                else
                {
                    fusionados.Add(
                        new IntervaloColumnaSerie(
                            intervalo.Min,
                            intervalo.Max));
                }
            }

            if (fusionados.Count == 0)
                return false;

            double toleranciaEje =
                UnitUtils.ConvertToInternalUnits(
                    0.50,
                    UnitTypeId.Centimeters);

            // Se prioriza el intervalo que contiene el eje de la viga. Si la
            // familia tiene el eje desplazado respecto de la sección, se toma
            // el intervalo de mayor longitud.
            IntervaloColumnaSerie elegido =
                fusionados
                    .Where(x =>
                        x.Min <= toleranciaEje &&
                        x.Max >= -toleranciaEje)
                    .OrderByDescending(x => x.Width)
                    .FirstOrDefault();

            if (elegido == null)
            {
                elegido = fusionados
                    .OrderByDescending(x => x.Width)
                    .FirstOrDefault();
            }

            if (elegido == null ||
                elegido.Max <= elegido.Min + Tol)
            {
                return false;
            }

            valorMin = elegido.Min;
            valorMax = elegido.Max;

            return true;
        }


        private bool TryObtenerRangoZDesdePuntosSolidoEnEstacion(
            DatosViga viga,
            double estacion,
            out double zMin,
            out double zMax)
        {
            zMin = double.MaxValue;
            zMax = double.MinValue;

            if (viga == null)
                return false;

            if (viga.PuntosSolidoGlobal == null || viga.PuntosSolidoGlobal.Count < 4)
                return false;

            if (viga.P0 == null ||
                viga.XAxis == null || viga.XAxis.GetLength() <= Tol ||
                viga.YAxis == null || viga.YAxis.GetLength() <= Tol ||
                viga.ZAxis == null || viga.ZAxis.GetLength() <= Tol)
            {
                return false;
            }

            XYZ xAxis = viga.XAxis.Normalize();
            XYZ yAxis = viga.YAxis.Normalize();
            XYZ zAxis = viga.ZAxis.Normalize();

            double solidoMin = Math.Min(viga.SolidoMin, viga.SolidoMax);
            double solidoMax = Math.Max(viga.SolidoMin, viga.SolidoMax);

            if (solidoMax <= solidoMin + Tol)
                return false;

            estacion = Math.Max(solidoMin, Math.Min(solidoMax, estacion));

            List<Tuple<double, double, double>> pts = new List<Tuple<double, double, double>>();

            foreach (XYZ p in viga.PuntosSolidoGlobal)
            {
                if (p == null)
                    continue;

                XYZ v = p - viga.P0;

                double x = v.DotProduct(xAxis);
                double y = v.DotProduct(yAxis);
                double z = v.DotProduct(zAxis);

                pts.Add(Tuple.Create(x, y, z));
            }

            if (pts.Count < 4)
                return false;

            double ancho = Math.Abs(viga.YMax - viga.YMin);
            double longitud = solidoMax - solidoMin;

            double toleranciaY = Math.Max(
                UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Centimeters),
                ancho * 0.08);

            double toleranciaX = Math.Max(
                UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Centimeters),
                longitud * 0.01);

            List<double> candidatosZ = new List<double>();

            foreach (Tuple<double, double, double> p in pts)
            {
                if (Math.Abs(p.Item1 - estacion) <= toleranciaX)
                    candidatosZ.Add(p.Item3);
            }

            for (int i = 0; i < pts.Count; i++)
            {
                Tuple<double, double, double> a = pts[i];

                for (int j = i + 1; j < pts.Count; j++)
                {
                    Tuple<double, double, double> b = pts[j];

                    double x0 = a.Item1;
                    double x1 = b.Item1;

                    if (Math.Abs(x1 - x0) <= Tol)
                        continue;

                    double minX = Math.Min(x0, x1);
                    double maxX = Math.Max(x0, x1);

                    if (estacion < minX - toleranciaX || estacion > maxX + toleranciaX)
                        continue;

                    // Las aristas longitudinales reales conservan aproximadamente el mismo Y.
                    // Esto evita usar diagonales internas del sólido como si fueran cara.
                    if (Math.Abs(a.Item2 - b.Item2) > toleranciaY)
                        continue;

                    double t = (estacion - x0) / (x1 - x0);

                    if (t < -0.02 || t > 1.02)
                        continue;

                    if (t < 0.0) t = 0.0;
                    if (t > 1.0) t = 1.0;

                    double z = a.Item3 + (b.Item3 - a.Item3) * t;
                    candidatosZ.Add(z);
                }
            }

            if (candidatosZ.Count < 2)
                return false;

            zMin = candidatosZ.Min();
            zMax = candidatosZ.Max();

            if (zMax <= zMin + Tol)
                return false;

            return true;
        }

        private bool ObtenerLimitesZExactosEnEstacion(
            DatosViga viga,
            double estacion,
            double recubrimientoFt,
            double minZFallback,
            double maxZFallback,
            out double minZExacto,
            out double maxZExacto)
        {
            minZExacto = minZFallback;
            maxZExacto = maxZFallback;

            if (viga == null)
                return false;

            double zMinSolidoEstacion;
            double zMaxSolidoEstacion;

            // Primero se lee la sección en la estación exacta del estribo.
            // En vigas con peralte variable, esta es la diferencia clave: no se usa
            // la envolvente global de toda la viga, sino la altura real local.
            if (TryObtenerRangoZDesdePuntosSolidoEnEstacion(
                viga,
                estacion,
                out zMinSolidoEstacion,
                out zMaxSolidoEstacion))
            {
                double zInferiorExacto = zMinSolidoEstacion + recubrimientoFt;
                double zSuperiorExacto = zMaxSolidoEstacion - recubrimientoFt;

                if (zSuperiorExacto > zInferiorExacto + Tol)
                {
                    minZExacto = zInferiorExacto;
                    maxZExacto = zSuperiorExacto;
                    return true;
                }
            }

            if (!viga.TienePerfilZLinealEstribos)
                return true;

            double solidoMin = Math.Min(viga.SolidoMin, viga.SolidoMax);
            double solidoMax = Math.Max(viga.SolidoMin, viga.SolidoMax);

            if (solidoMax <= solidoMin + Tol)
                return true;

            estacion = Math.Max(solidoMin, Math.Min(solidoMax, estacion));

            double zInf = InterpolarZPerfilLineal(
                viga.ZInferiorInicio,
                viga.ZInferiorFin,
                solidoMin,
                solidoMax,
                estacion);

            double zSup = InterpolarZPerfilLineal(
                viga.ZSuperiorInicio,
                viga.ZSuperiorFin,
                solidoMin,
                solidoMax,
                estacion);

            double zInferiorConRecubrimiento = zInf + recubrimientoFt;
            double zSuperiorConRecubrimiento = zSup - recubrimientoFt;

            if (zSuperiorConRecubrimiento <= zInferiorConRecubrimiento + Tol)
                return true;

            minZExacto = zInferiorConRecubrimiento;
            maxZExacto = zSuperiorConRecubrimiento;

            return true;
        }

        private void AplicarSeparacionEtiqueta(
            Rebar rb,
            double separacionDisenoFt)
        {
            if (rb == null)
                return;

            if (separacionDisenoFt <= Tol)
                return;

            // IMPORTANTE:
            // No se modifica el parámetro nativo "Espaciado" de Revit,
            // porque ese parámetro controla la geometría del conjunto y movería
            // los estribos. Este método llena un parámetro auxiliar para etiqueta,
            // manteniendo intacta la posición creada con la separación real.
            double separacionCm = UnitUtils.ConvertFromInternalUnits(
                separacionDisenoFt,
                UnitTypeId.Centimeters);

            double separacionMm = UnitUtils.ConvertFromInternalUnits(
                separacionDisenoFt,
                UnitTypeId.Millimeters);

            string textoCm = separacionCm.ToString(
                "0.##",
                System.Globalization.CultureInfo.InvariantCulture) + " cm";

            string[] nombresParametros = new string[]
            {
                "MYG_Espaciado_Etiqueta",
                "MYG_EspaciadoEtiqueta",
                "MYG_Espaciado",
                "MYG_Separacion",
                "MYG_Separación",
                "SHE_Espaciado",
                "SHE_Separacion",
                "SHE_Separación",
                "Espaciado etiqueta",
                "Espaciamiento etiqueta",
                "Separacion etiqueta",
                "Separación etiqueta",
                "Espaciado de diseño",
                "Espaciamiento de diseño",
                "Separacion de diseño",
                "Separación de diseño"
            };

            foreach (string nombre in nombresParametros)
            {
                if (string.IsNullOrWhiteSpace(nombre))
                    continue;

                Parameter p = null;

                try
                {
                    p = rb.LookupParameter(nombre);
                }
                catch
                {
                    p = null;
                }

                if (p == null || p.IsReadOnly)
                    continue;

                try
                {
                    if (p.StorageType == StorageType.Double)
                    {
                        // Para parámetros de longitud, se guarda en unidades internas.
                        p.Set(separacionDisenoFt);
                    }
                    else if (p.StorageType == StorageType.String)
                    {
                        // Para parámetros de texto, se guarda listo para etiqueta.
                        p.Set(textoCm);
                    }
                    else if (p.StorageType == StorageType.Integer)
                    {
                        // Respaldo: se guarda en milímetros enteros.
                        p.Set((int)Math.Round(separacionMm));
                    }
                }
                catch
                {
                    // No interrumpir la creación de estribos si un parámetro falla.
                }
            }
        }

        private int AjustarCantidadPorLongitud(
            int cantidadSolicitada,
            double separacionFt,
            double longitudDisponibleFt)
        {
            if (cantidadSolicitada <= 0)
                return 0;

            if (separacionFt <= Tol)
                return 0;

            if (longitudDisponibleFt < -Tol)
                return 0;

            if (longitudDisponibleFt <= Tol)
                return 1;

            int cantidadMaxima =
                Math.Max(1, (int)Math.Floor((longitudDisponibleFt + Tol) / separacionFt) + 1);

            return Math.Max(1, Math.Min(cantidadSolicitada, cantidadMaxima));
        }

        private int AjustarCantidadSimetricaPorLongitud(
            int cantidadSolicitada,
            double separacionFt,
            double primerIzq,
            double primerDer)
        {
            if (cantidadSolicitada <= 0)
                return 0;

            if (separacionFt <= Tol)
                return 0;

            if (primerDer < primerIzq - Tol)
                return 0;

            double disponible = primerDer - primerIzq;

            if (disponible <= Tol)
                return 1;

            // La zona se coloca en ambos extremos.
            // Por eso se limita la cantidad para que el bloque izquierdo
            // y el bloque derecho no se crucen en el centro.
            int cantidadMaxima = Math.Max(
                1,
                (int)Math.Floor((disponible + Tol) / (2.0 * separacionFt)) + 1);

            return Math.Max(1, Math.Min(cantidadSolicitada, cantidadMaxima));
        }

        private int CrearSetNumeroConEspaciado(
            Document doc,
            DatosViga viga,
            RebarBarType tipoEstribo,
            RebarHookType ganchoEstribo135,
            double estacionInicio,
            double separacionFt,
            int cantidad,
            double limiteInicio,
            double limiteFin,
            double minY,
            double maxY,
            double minZ,
            double maxZ)
        {
            if (doc == null || viga == null || viga.Elemento == null)
                return 0;

            if (cantidad <= 0 || separacionFt <= Tol)
                return 0;

            double estacionFin =
                estacionInicio + ((cantidad - 1) * separacionFt);

            if (estacionInicio < limiteInicio - Tol)
                return 0;

            if (estacionFin > limiteFin + Tol)
                return 0;

            if (maxZ <= minZ + Tol)
                return 0;

            List<Rebar> rbs = CrearEstribosBase(
                doc,
                viga,
                tipoEstribo,
                ganchoEstribo135,
                estacionInicio,
                minY,
                maxY,
                minZ,
                maxZ);

            if (rbs == null || rbs.Count == 0)
                return 0;

            int totalCreado = 0;

            foreach (Rebar rb in rbs)
            {
                if (rb == null)
                    continue;

                AplicarSeparacionEtiqueta(
                    rb,
                    separacionFt);

                RebarShapeDrivenAccessor accessor = null;

                try
                {
                    accessor = ObtenerAccessorConVariableSiCorresponde(
                        rb,
                        viga.TieneSeccionVariableEstribos);

                    if (accessor == null)
                    {
                        totalCreado += 1;
                        continue;
                    }

                    if (cantidad <= 1)
                    {
                        totalCreado += 1;
                        continue;
                    }

                    accessor.SetLayoutAsNumberWithSpacing(
                        cantidad,
                        separacionFt,
                        true,
                        true,
                        true);

                    totalCreado += cantidad;
                }
                catch
                {
                    totalCreado += 1;
                }
                finally
                {
                    try
                    {
                        if (accessor != null)
                            accessor.Dispose();
                    }
                    catch
                    {
                    }
                }
            }

            try
            {
                doc.Regenerate();
            }
            catch
            {
            }

            return totalCreado;
        }

        private int CrearSetEspaciadoMaximo(
            Document doc,
            DatosViga viga,
            RebarBarType tipoEstribo,
            RebarHookType ganchoEstribo135,
            double estacionInicio,
            double estacionFin,
            double separacionMaximaFt,
            double limiteInicio,
            double limiteFin,
            double minY,
            double maxY,
            double minZ,
            double maxZ,
            bool incluirPrimeraBarra = true,
            bool incluirUltimaBarra = true)
        {
            if (doc == null || viga == null || viga.Elemento == null)
                return 0;

            if (separacionMaximaFt <= Tol)
                return 0;

            if (estacionInicio < limiteInicio - Tol)
                return 0;

            if (estacionFin > limiteFin + Tol)
                return 0;

            if (maxZ <= minZ + Tol)
                return 0;

            double longitudArray = estacionFin - estacionInicio;

            if (longitudArray <= Tol)
                return 0;

            // =========================================================
            // CORRECCIÓN:
            // Para separación constante, el usuario ingresa un valor que
            // en realidad debe comportarse como ESPACIAMIENTO MÁXIMO.
            //
            // Por eso aquí NO usamos NumberWithSpacing con la separación
            // real calculada, porque Revit mostraría en el parámetro nativo
            // "Espaciado" ese valor real, por ejemplo 192.1 mm.
            //
            // Usamos SetLayoutAsMaximumSpacing con:
            // - separacionMaximaFt = valor digitado, por ejemplo 20 cm.
            // - longitudArray = distancia entre primer y último estribo.
            // - includeFirstBar = true.
            // - includeLastBar = true.
            //
            // Así el parámetro nativo "Espaciado" queda con el valor
            // digitado, pero Revit reparte internamente los estribos dentro
            // del rango sin superar esa separación.
            // =========================================================

            int cantidadBase = Math.Max(
                2,
                (int)Math.Ceiling(longitudArray / separacionMaximaFt) + 1);

            int cantidadAproximada = cantidadBase;

            if (!incluirPrimeraBarra)
                cantidadAproximada--;

            if (!incluirUltimaBarra)
                cantidadAproximada--;

            cantidadAproximada = Math.Max(0, cantidadAproximada);

            // Si el RESTO se calcula con el rango total, pero no alcanza para
            // barras interiores entre los extremos existentes, no se crea un set
            // adicional para evitar duplicar las barras de borde.
            if (cantidadAproximada <= 0)
                return 0;

            List<Rebar> rbs = CrearEstribosBase(
                doc,
                viga,
                tipoEstribo,
                ganchoEstribo135,
                estacionInicio,
                minY,
                maxY,
                minZ,
                maxZ);

            if (rbs == null || rbs.Count == 0)
                return 0;

            int totalCreado = 0;

            foreach (Rebar rb in rbs)
            {
                if (rb == null)
                    continue;

                // Se mantiene también el parámetro auxiliar, si existe,
                // para etiquetas personalizadas.
                AplicarSeparacionEtiqueta(
                    rb,
                    separacionMaximaFt);

                RebarShapeDrivenAccessor accessor = null;

                try
                {
                    accessor = ObtenerAccessorConVariableSiCorresponde(
                        rb,
                        viga.TieneSeccionVariableEstribos);

                    if (accessor == null)
                    {
                        totalCreado += 1;
                        continue;
                    }

                    accessor.SetLayoutAsMaximumSpacing(
                        separacionMaximaFt,
                        longitudArray,
                        true,
                        incluirPrimeraBarra,
                        incluirUltimaBarra);

                    totalCreado += cantidadAproximada;
                }
                catch
                {
                    totalCreado += 1;
                }
                finally
                {
                    try
                    {
                        if (accessor != null)
                            accessor.Dispose();
                    }
                    catch
                    {
                    }
                }
            }

            try
            {
                doc.Regenerate();
            }
            catch
            {
            }

            return totalCreado;
        }

        // =========================================================
        // SEGUNDO ESTRIBO RECTANGULAR CENTRAL
        // =========================================================
        // Mantiene exactamente el mismo minZ/maxZ del estribo exterior.
        // La única diferencia es que se retrae lateralmente en Y, por ambos lados.
        private bool DebeCrearEstriboCentralMYG()
        {
            // V6: se elimina el segundo estribo central automático. Cualquier
            // recorrido interior se dibuja manualmente en el editor de sección.
            return false;
        }

        private double ObtenerRetiroLateralEstriboCentralFtMYG()
        {
            double retiroCm = 15.0;

            try
            {
                string texto = Form != null
                    ? Form.RetiroLateralEstriboCentralTexto
                    : "15";

                double valor;
                if (double.TryParse(
                    (texto ?? "15").Replace(",", "."),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out valor))
                {
                    retiroCm = valor;
                }
            }
            catch
            {
                retiroCm = 15.0;
            }

            if (double.IsNaN(retiroCm) ||
                double.IsInfinity(retiroCm) ||
                retiroCm <= 0.0)
            {
                return 0.0;
            }

            return UnitUtils.ConvertToInternalUnits(
                retiroCm,
                UnitTypeId.Centimeters);
        }

        private bool TryObtenerLimitesEstriboCentralMYG(
            RebarBarType tipoEstribo,
            double minYExterior,
            double maxYExterior,
            out double minYCentral,
            out double maxYCentral)
        {
            minYCentral = minYExterior;
            maxYCentral = maxYExterior;

            if (!DebeCrearEstriboCentralMYG())
                return false;

            double retiroFt = ObtenerRetiroLateralEstriboCentralFtMYG();

            if (retiroFt <= Tol)
                return false;

            minYCentral = minYExterior + retiroFt;
            maxYCentral = maxYExterior - retiroFt;

            // Se exige un ancho útil mínimo para evitar lazos degenerados.
            double diametro = ObtenerDiametroBarraFt(tipoEstribo);
            double anchoMinimo = Math.Max(
                UnitUtils.ConvertToInternalUnits(5.0, UnitTypeId.Centimeters),
                diametro * 4.0);

            return maxYCentral - minYCentral > anchoMinimo;
        }

        private void EliminarRebarsTemporalesMYG(
            Document doc,
            IEnumerable<Rebar> rebars)
        {
            if (doc == null || rebars == null)
                return;

            foreach (Rebar rb in rebars)
            {
                if (rb == null)
                    continue;

                try
                {
                    if (rb.Id != null && rb.Id != ElementId.InvalidElementId)
                        doc.Delete(rb.Id);
                }
                catch
                {
                }
            }
        }

        private List<Rebar> CrearEstribosBase(
            Document doc,
            DatosViga viga,
            RebarBarType tipoEstribo,
            RebarHookType ganchoEstribo135,
            double estacion,
            double minY,
            double maxY,
            double minZ,
            double maxZ)
        {
            List<Rebar> resultado = new List<Rebar>();

            if (doc == null || viga == null || viga.Elemento == null)
                return resultado;

            AceroVigaDisenoSeccion disenoManual =
                AceroVigaDisenoSeccionCompartido.ObtenerCopia();

            if (disenoManual != null && disenoManual.TieneEstribos)
            {
                return CrearEstribosDesdeDisenoSeccionMYG(
                    doc,
                    viga,
                    tipoEstribo,
                    ganchoEstribo135,
                    estacion,
                    minY,
                    maxY,
                    minZ,
                    maxZ,
                    disenoManual);
            }

            if (viga.EsCurva && viga.CurvaEje != null)
            {
                List<Rebar> exterioresCurvos = CrearEstribosBaseEnCurvaMYG(
                    doc,
                    viga,
                    tipoEstribo,
                    ganchoEstribo135,
                    estacion,
                    minY,
                    maxY,
                    minZ,
                    maxZ);

                if (exterioresCurvos == null || exterioresCurvos.Count == 0)
                    return resultado;

                resultado.AddRange(exterioresCurvos);

                if (!DebeCrearEstriboCentralMYG())
                    return resultado;

                double minYCentralCurvo;
                double maxYCentralCurvo;

                if (!TryObtenerLimitesEstriboCentralMYG(
                    tipoEstribo,
                    minY,
                    maxY,
                    out minYCentralCurvo,
                    out maxYCentralCurvo))
                {
                    EliminarRebarsTemporalesMYG(doc, resultado);
                    resultado.Clear();
                    return resultado;
                }

                List<Rebar> interioresCurvos = CrearEstribosBaseEnCurvaMYG(
                    doc,
                    viga,
                    tipoEstribo,
                    ganchoEstribo135,
                    estacion,
                    minYCentralCurvo,
                    maxYCentralCurvo,
                    minZ,
                    maxZ);

                if (interioresCurvos == null || interioresCurvos.Count == 0)
                {
                    EliminarRebarsTemporalesMYG(doc, resultado);
                    resultado.Clear();
                    return resultado;
                }

                resultado.AddRange(interioresCurvos);
                return resultado;
            }

            XYZ centro = viga.P0 + viga.XAxis.Multiply(estacion);

            if (EsFormaCumbreraSeleccionada())
            {
                double diametroEstriboFt = ObtenerDiametroBarraFt(tipoEstribo);

                List<List<Curve>> gruposCumbrera = CrearCurvasEstribosCumbreraEntrelazados(
                    viga,
                    centro,
                    minY,
                    maxY,
                    minZ,
                    maxZ,
                    diametroEstriboFt);

                if (gruposCumbrera != null && gruposCumbrera.Count > 0)
                {
                    for (int i = 0; i < gruposCumbrera.Count; i++)
                    {
                        List<Curve> curvas = gruposCumbrera[i];

                        // Grupo 0 = lado izquierdo, grupo 1 = lado derecho.
                        // CLAVE FINAL:
                        // En cumbreras con un elemento por tramo, algunas familias traen el
                        // eje local invertido o el loop se interpreta al revés por Revit.
                        // Por eso no basta con fijar Left/Right manualmente.
                        // Se prueban las orientaciones de gancho y se conserva la que NO
                        // sobresale hacia el exterior del grupo, usando la caja real del
                        // estribo creado como verificación.
                        Rebar rbCumbrera = CrearRebarCumbreraConGanchoInterior(
                            doc,
                            viga,
                            tipoEstribo,
                            ganchoEstribo135,
                            curvas,
                            i);

                        if (rbCumbrera != null)
                            resultado.Add(rbCumbrera);
                    }
                }

                if (resultado.Count > 0)
                    return resultado;
            }

            List<Curve> curvasRectangular = CrearCurvasEstriboRectangular(
                viga,
                centro,
                minY,
                maxY,
                minZ,
                maxZ);

            // Se prueban automáticamente todas las combinaciones Left/Right
            // y ambos sentidos de la normal. Solo se conserva el Rebar cuyos
            // dos ganchos quedan dentro del rectángulo del estribo.
            Rebar rbRectangular = CrearRebarRectangularConGanchosHaciaAdentroMYG(
                doc,
                viga,
                tipoEstribo,
                ganchoEstribo135,
                curvasRectangular);

            if (rbRectangular == null)
                return resultado;

            resultado.Add(rbRectangular);

            if (!DebeCrearEstriboCentralMYG())
                return resultado;

            // Segundo estribo cerrado interior:
            // - MISMA altura: conserva minZ y maxZ.
            // - MENOR ancho: se retrae en minY y maxY la distancia ingresada.
            double minYCentral;
            double maxYCentral;

            if (!TryObtenerLimitesEstriboCentralMYG(
                tipoEstribo,
                minY,
                maxY,
                out minYCentral,
                out maxYCentral))
            {
                EliminarRebarsTemporalesMYG(doc, resultado);
                resultado.Clear();
                return resultado;
            }

            // IMPORTANTE:
            // El estribo central debe respetar exactamente el retiro lateral ingresado.
            // No se usa CrearCurvasEstriboRectangular(...) porque ese método intenta
            // reconstruir el contorno real de la sección y calcula un único offset con
            // el menor recubrimiento. Como arriba y abajo conservan el recubrimiento
            // exterior, terminaba reconstruyendo el mismo ancho del estribo exterior.
            //
            // Aquí se fuerza el rectángulo con los límites exactos:
            // - misma altura: minZ / maxZ del exterior;
            // - menor ancho: minYCentral / maxYCentral según el retiro lateral.
            List<Curve> curvasCentral = CrearCurvasEstriboRectangularDesdeLimites(
                viga,
                centro,
                minYCentral,
                maxYCentral,
                minZ,
                maxZ);

            // El estribo central usa la misma validación geométrica.
            // No se fija Left/Right manualmente porque el sentido local puede
            // cambiar según la orientación de la familia o del eje de la viga.
            Rebar rbCentral = CrearRebarRectangularConGanchosHaciaAdentroMYG(
                doc,
                viga,
                tipoEstribo,
                ganchoEstribo135,
                curvasCentral);

            if (rbCentral == null)
            {
                EliminarRebarsTemporalesMYG(doc, resultado);
                resultado.Clear();
                return resultado;
            }

            resultado.Add(rbCentral);
            return resultado;
        }

        // =========================================================
        // DISEÑO MANUAL COMPARTIDO DEL EDITOR 2D DE SECCIÓN
        // =========================================================
        private List<Rebar> CrearEstribosDesdeDisenoSeccionMYG(
            Document doc,
            DatosViga viga,
            RebarBarType tipoEstriboRespaldo,
            RebarHookType ganchoEstribo135,
            double estacion,
            double minY,
            double maxY,
            double minZ,
            double maxZ,
            AceroVigaDisenoSeccion diseno)
        {
            List<Rebar> resultado = new List<Rebar>();

            if (doc == null || viga == null || viga.Elemento == null ||
                diseno == null || diseno.Estribos == null)
            {
                return resultado;
            }

            XYZ centro;
            XYZ normal;
            XYZ ejeY;
            XYZ ejeZ;

            if (viga.EsCurva && viga.CurvaEje != null)
            {
                XYZ tangente;
                if (!ObtenerMarcoCurvaEstriboMYG(
                    viga.CurvaEje,
                    estacion,
                    out centro,
                    out tangente,
                    out ejeY,
                    out ejeZ))
                {
                    return resultado;
                }

                normal = tangente;
            }
            else
            {
                centro = viga.P0 + viga.XAxis.Multiply(estacion);
                normal = viga.XAxis;
                ejeY = viga.YAxis;
                ejeZ = viga.ZAxis;
            }

            foreach (AceroVigaEstribo2D definicion in diseno.Estribos)
            {
                if (definicion == null)
                    continue;

                RebarBarType tipo = definicion.TipoBarra ?? tipoEstriboRespaldo;
                if (tipo == null)
                    continue;

                double diametro = ObtenerDiametroBarraFt(tipo);
                double recubrimientoEstribosCm =
                    diseno.RecubrimientoEstribosCm > 0.0
                        ? diseno.RecubrimientoEstribosCm
                        : diseno.RecubrimientoCm;

                double recubrimiento = UnitUtils.ConvertToInternalUnits(
                    Math.Max(0.0, recubrimientoEstribosCm),
                    UnitTypeId.Centimeters);
                double offsetEje = recubrimiento + diametro * 0.5;

                List<PuntoPerfilYZ> contornoUtil = null;

                if (!viga.EsCurva)
                {
                    contornoUtil = ObtenerContornoInteriorSeccionRealYZ(
                        viga,
                        offsetEje);
                }

                if (contornoUtil == null || contornoUtil.Count < 3)
                {
                    // En una viga curva no se reutiliza el offset calculado con
                    // el tipo general de la ventana. Cada recorrido puede tener
                    // un diámetro distinto, por eso se reconstruye su caja útil
                    // desde los límites brutos del sólido y su propio offset al eje.
                    double y0 = viga.YMin + offsetEje;
                    double y1 = viga.YMax - offsetEje;
                    double z0 = viga.ZMin + offsetEje;
                    double z1 = viga.ZMax - offsetEje;

                    if (y1 <= y0 + Tol || z1 <= z0 + Tol)
                    {
                        // Respaldo para familias cuya extracción de límites no sea
                        // confiable: se mantienen los límites ya calculados por el
                        // flujo histórico del tramo.
                        y0 = minY;
                        y1 = maxY;
                        z0 = minZ;
                        z1 = maxZ;
                    }

                    contornoUtil = new List<PuntoPerfilYZ>()
                    {
                        new PuntoPerfilYZ(y0, z0),
                        new PuntoPerfilYZ(y1, z0),
                        new PuntoPerfilYZ(y1, z1),
                        new PuntoPerfilYZ(y0, z1)
                    };
                }

                List<PuntoPerfilYZ> puntosPerfil;

                if (definicion.UsarContornoOffsetAutomatico)
                {
                    puntosPerfil = contornoUtil
                        .Where(x => x != null)
                        .Select(x => new PuntoPerfilYZ(x.Y, x.Z))
                        .ToList();
                }
                else
                {
                    puntosPerfil = DesnormalizarPuntosEstriboEditorMYG(
                        definicion.Puntos,
                        contornoUtil);
                }

                int minimoPuntos = definicion.Cerrado ? 3 : 2;
                if (puntosPerfil == null || puntosPerfil.Count < minimoPuntos)
                    continue;

                if (!definicion.UsarContornoOffsetAutomatico &&
                    definicion.Cerrado &&
                    (definicion.Tipo == AceroVigaTipoEstribo2D.Rectangular ||
                     definicion.Tipo == AceroVigaTipoEstribo2D.Rombo))
                {
                    List<ReferenciaLongitudinalPerfilMYG> longitudinalesPerfil =
                        ObtenerReferenciasLongitudinalesPerfilMYG(
                            viga,
                            diseno,
                            recubrimiento,
                            diametro);

                    puntosPerfil = AjustarPerfilCerradoALongitudinalesMYG(
                        puntosPerfil,
                        definicion.Tipo,
                        contornoUtil,
                        longitudinalesPerfil,
                        diametro);

                    if (puntosPerfil == null || puntosPerfil.Count < 4)
                        continue;
                }

                RebarTerminationOrientation orientacionInicioGancho =
                    RebarTerminationOrientation.Right;
                RebarTerminationOrientation orientacionFinGancho =
                    RebarTerminationOrientation.Left;

                bool esGanchoTipoC =
                    definicion.Tipo == AceroVigaTipoEstribo2D.GanchoC;
                bool esGanchoTipoS =
                    definicion.Tipo == AceroVigaTipoEstribo2D.GanchoS;

                if (!definicion.Cerrado &&
                    (esGanchoTipoC || esGanchoTipoS) &&
                    puntosPerfil.Count >= 2)
                {
                    double diametroLongitudinalInicio =
                        ObtenerDiametroLongitudinalGanchoFtMYG(
                            definicion.DiametroLongitudinalInicioMm,
                            diseno);
                    double diametroLongitudinalFin =
                        ObtenerDiametroLongitudinalGanchoFtMYG(
                            definicion.DiametroLongitudinalFinMm,
                            diseno);

                    puntosPerfil = PrepararGanchoAdaptadoLongitudinalesVigaMYG(
                        puntosPerfil[0],
                        puntosPerfil[puntosPerfil.Count - 1],
                        esGanchoTipoS,
                        diametroLongitudinalInicio,
                        diametroLongitudinalFin,
                        diametro,
                        ObtenerRadioDobladoEjeEstriboVigaMYG(tipo),
                        contornoUtil,
                        out orientacionInicioGancho,
                        out orientacionFinGancho);

                    if (puntosPerfil == null || puntosPerfil.Count < 2)
                        continue;
                }
                else if (definicion.Cerrado)
                {
                    int indiceCierre = definicion.UsarContornoOffsetAutomatico
                        ? ObtenerIndiceSuperiorDerechoPerfilEditorMYG(puntosPerfil)
                        : definicion.IndiceEsquinaGancho;

                    puntosPerfil = ReordenarPerfilCerradoDesdeEsquinaMYG(
                        puntosPerfil,
                        indiceCierre);
                }

                List<Curve> curvas = CrearCurvasPerfilEditorMYG(
                    centro,
                    ejeY,
                    ejeZ,
                    puntosPerfil,
                    definicion.Cerrado);

                if (curvas == null || curvas.Count == 0)
                    continue;

                Rebar rb = CrearRebarEstriboEditorMYG(
                    doc,
                    viga,
                    tipo,
                    ganchoEstribo135,
                    normal,
                    curvas,
                    definicion.Cerrado,
                    centro,
                    ejeY,
                    ejeZ,
                    puntosPerfil,
                    definicion.Tipo,
                    orientacionInicioGancho,
                    orientacionFinGancho);

                if (rb == null)
                    continue;

                AplicarParametrosRebarEstriboMYG(
                    doc,
                    rb,
                    viga.Elemento,
                    comentarioDistribucionEstribosActualMYG);

                resultado.Add(rb);
            }

            return resultado;
        }

        private List<ReferenciaLongitudinalPerfilMYG>
            ObtenerReferenciasLongitudinalesPerfilMYG(
                DatosViga viga,
                AceroVigaDisenoSeccion diseno,
                double recubrimientoEstribo,
                double diametroEstribo)
        {
            List<ReferenciaLongitudinalPerfilMYG> resultado =
                new List<ReferenciaLongitudinalPerfilMYG>();

            if (viga == null || diseno == null ||
                diseno.Longitudinales == null)
            {
                return resultado;
            }

            double recubrimientoLongitudinalCm =
                diseno.RecubrimientoLongitudinalCm > 0.0
                    ? diseno.RecubrimientoLongitudinalCm
                    : diseno.RecubrimientoCm;
            double recubrimientoLongitudinal =
                UnitUtils.ConvertToInternalUnits(
                    Math.Max(0.0, recubrimientoLongitudinalCm),
                    UnitTypeId.Centimeters);

            foreach (AceroVigaBarraLongitudinal2D barra in
                diseno.Longitudinales)
            {
                if (barra == null || barra.Punto == null)
                    continue;

                double diametroLongitudinal = barra.DiametroMm > Tol
                    ? UnitUtils.ConvertToInternalUnits(
                        barra.DiametroMm,
                        UnitTypeId.Millimeters)
                    : ObtenerDiametroBarraFt(barra.TipoBarra);

                if (diametroLongitudinal <= Tol)
                    continue;

                double offsetCentroLongitudinal =
                    recubrimientoLongitudinal +
                    diametroEstribo +
                    diametroLongitudinal * 0.5;

                List<PuntoPerfilYZ> contornoLongitudinal = null;
                if (!viga.EsCurva)
                {
                    contornoLongitudinal =
                        ObtenerContornoInteriorSeccionRealYZ(
                            viga,
                            offsetCentroLongitudinal);
                }

                if (contornoLongitudinal == null ||
                    contornoLongitudinal.Count < 3)
                {
                    double y0 = viga.YMin + offsetCentroLongitudinal;
                    double y1 = viga.YMax - offsetCentroLongitudinal;
                    double z0 = viga.ZMin + offsetCentroLongitudinal;
                    double z1 = viga.ZMax - offsetCentroLongitudinal;

                    if (y1 <= y0 + Tol || z1 <= z0 + Tol)
                        continue;

                    contornoLongitudinal = new List<PuntoPerfilYZ>
                    {
                        new PuntoPerfilYZ(y0, z0),
                        new PuntoPerfilYZ(y1, z0),
                        new PuntoPerfilYZ(y1, z1),
                        new PuntoPerfilYZ(y0, z1)
                    };
                }

                List<PuntoPerfilYZ> centro =
                    DesnormalizarPuntosEstriboEditorMYG(
                        new List<AceroVigaPuntoNormalizado>
                        {
                            barra.Punto
                        },
                        contornoLongitudinal);

                if (centro == null || centro.Count == 0)
                    continue;

                resultado.Add(new ReferenciaLongitudinalPerfilMYG
                {
                    Centro = centro[0],
                    Diametro = diametroLongitudinal
                });
            }

            return resultado;
        }

        private List<PuntoPerfilYZ> AjustarPerfilCerradoALongitudinalesMYG(
            List<PuntoPerfilYZ> puntos,
            AceroVigaTipoEstribo2D tipo,
            List<PuntoPerfilYZ> limiteRecubrimiento,
            List<ReferenciaLongitudinalPerfilMYG> longitudinales,
            double diametroEstribo)
        {
            if (puntos == null || puntos.Count < 4 ||
                limiteRecubrimiento == null ||
                limiteRecubrimiento.Count < 3 ||
                longitudinales == null || longitudinales.Count == 0)
            {
                return puntos;
            }

            double proximidad = UnitUtils.ConvertToInternalUnits(
                3.0,
                UnitTypeId.Centimeters);
            List<ReferenciaLongitudinalPerfilMYG> cercanas =
                new List<ReferenciaLongitudinalPerfilMYG>();

            foreach (ReferenciaLongitudinalPerfilMYG referencia in longitudinales)
            {
                if (referencia == null || referencia.Centro == null)
                    continue;

                double holgura =
                    (Math.Max(referencia.Diametro, Tol) +
                     diametroEstribo) * 0.5 +
                    UnitUtils.ConvertToInternalUnits(
                        1.0,
                        UnitTypeId.Millimeters);
                double distancia = DistanciaPuntoAPoligonoYZ(
                    referencia.Centro.Y,
                    referencia.Centro.Z,
                    puntos);

                if (PuntoDentroOPegadoPoligonoYZ(
                        referencia.Centro.Y,
                        referencia.Centro.Z,
                        puntos,
                        Tol) ||
                    distancia <= holgura + proximidad)
                {
                    cercanas.Add(referencia);
                }
            }

            if (cercanas.Count == 0)
                return puntos;

            return tipo == AceroVigaTipoEstribo2D.Rectangular
                ? AjustarRectanguloPerfilMYG(
                    puntos,
                    limiteRecubrimiento,
                    cercanas,
                    diametroEstribo)
                : AjustarRomboPerfilMYG(
                    puntos,
                    limiteRecubrimiento,
                    cercanas,
                    diametroEstribo);
        }

        private List<PuntoPerfilYZ> AjustarRectanguloPerfilMYG(
            List<PuntoPerfilYZ> puntos,
            List<PuntoPerfilYZ> limite,
            List<ReferenciaLongitudinalPerfilMYG> longitudinales,
            double diametroEstribo)
        {
            double minY = puntos.Min(x => x.Y);
            double maxY = puntos.Max(x => x.Y);
            double minZ = puntos.Min(x => x.Z);
            double maxZ = puntos.Max(x => x.Z);

            foreach (ReferenciaLongitudinalPerfilMYG referencia in longitudinales)
            {
                double holgura =
                    (Math.Max(referencia.Diametro, Tol) +
                     diametroEstribo) * 0.5 +
                    UnitUtils.ConvertToInternalUnits(
                        1.0,
                        UnitTypeId.Millimeters);

                minY = Math.Min(minY, referencia.Centro.Y - holgura);
                maxY = Math.Max(maxY, referencia.Centro.Y + holgura);
                minZ = Math.Min(minZ, referencia.Centro.Z - holgura);
                maxZ = Math.Max(maxZ, referencia.Centro.Z + holgura);
            }

            double limMinY = limite.Min(x => x.Y);
            double limMaxY = limite.Max(x => x.Y);
            double limMinZ = limite.Min(x => x.Z);
            double limMaxZ = limite.Max(x => x.Z);
            double tolerancia = longitudinales.Max(x =>
                (Math.Max(x.Diametro, Tol) + diametroEstribo) * 0.5) +
                UnitUtils.ConvertToInternalUnits(
                    2.0,
                    UnitTypeId.Millimeters);

            minY = AjustarLadoPerfilMYG(minY, limMinY, limMaxY, tolerancia, true);
            maxY = AjustarLadoPerfilMYG(maxY, limMinY, limMaxY, tolerancia, false);
            minZ = AjustarLadoPerfilMYG(minZ, limMinZ, limMaxZ, tolerancia, true);
            maxZ = AjustarLadoPerfilMYG(maxZ, limMinZ, limMaxZ, tolerancia, false);

            if (maxY <= minY + Tol || maxZ <= minZ + Tol)
                return puntos;

            return new List<PuntoPerfilYZ>
            {
                new PuntoPerfilYZ(minY, minZ),
                new PuntoPerfilYZ(maxY, minZ),
                new PuntoPerfilYZ(maxY, maxZ),
                new PuntoPerfilYZ(minY, maxZ)
            };
        }

        private List<PuntoPerfilYZ> AjustarRomboPerfilMYG(
            List<PuntoPerfilYZ> puntos,
            List<PuntoPerfilYZ> limite,
            List<ReferenciaLongitudinalPerfilMYG> longitudinales,
            double diametroEstribo)
        {
            double centroY = (puntos.Min(x => x.Y) + puntos.Max(x => x.Y)) * 0.5;
            double centroZ = (puntos.Min(x => x.Z) + puntos.Max(x => x.Z)) * 0.5;
            double radioY = (puntos.Max(x => x.Y) - puntos.Min(x => x.Y)) * 0.5;
            double radioZ = (puntos.Max(x => x.Z) - puntos.Min(x => x.Z)) * 0.5;

            double limMinY = limite.Min(x => x.Y);
            double limMaxY = limite.Max(x => x.Y);
            double limMinZ = limite.Min(x => x.Z);
            double limMaxZ = limite.Max(x => x.Z);

            centroY = Math.Max(limMinY, Math.Min(limMaxY, centroY));
            centroZ = Math.Max(limMinZ, Math.Min(limMaxZ, centroZ));

            double radioMaxY = Math.Max(
                Tol,
                Math.Min(centroY - limMinY, limMaxY - centroY));
            double radioMaxZ = Math.Max(
                Tol,
                Math.Min(centroZ - limMinZ, limMaxZ - centroZ));

            radioY = Math.Min(Math.Max(radioY, Tol), radioMaxY);
            radioZ = Math.Min(Math.Max(radioZ, Tol), radioMaxZ);

            for (int iteracion = 0; iteracion < 80; iteracion++)
            {
                double factorNecesario = 1.0;

                foreach (ReferenciaLongitudinalPerfilMYG referencia in longitudinales)
                {
                    double holgura =
                        (Math.Max(referencia.Diametro, Tol) +
                         diametroEstribo) * 0.5 +
                        UnitUtils.ConvertToInternalUnits(
                            1.0,
                            UnitTypeId.Millimeters);
                    double dy = Math.Abs(referencia.Centro.Y - centroY);
                    double dz = Math.Abs(referencia.Centro.Z - centroZ);
                    double valor = dy / Math.Max(radioY, Tol) +
                                   dz / Math.Max(radioZ, Tol);
                    double normal = Math.Sqrt(
                        1.0 / Math.Max(radioY * radioY, Tol) +
                        1.0 / Math.Max(radioZ * radioZ, Tol));
                    factorNecesario = Math.Max(
                        factorNecesario,
                        (valor + holgura * normal) * 1.005);
                }

                if (factorNecesario <= 1.0001)
                    break;

                double nuevoY = Math.Min(radioMaxY, radioY * factorNecesario);
                double nuevoZ = Math.Min(radioMaxZ, radioZ * factorNecesario);

                if (nuevoY <= radioY + Tol && nuevoZ <= radioZ + Tol)
                    break;

                radioY = nuevoY;
                radioZ = nuevoZ;
            }

            double tolerancia = longitudinales.Max(x =>
                (Math.Max(x.Diametro, Tol) + diametroEstribo) * 0.5) +
                UnitUtils.ConvertToInternalUnits(
                    2.0,
                    UnitTypeId.Millimeters);

            if (radioMaxY - radioY <= tolerancia)
                radioY = radioMaxY;
            if (radioMaxZ - radioZ <= tolerancia)
                radioZ = radioMaxZ;

            return new List<PuntoPerfilYZ>
            {
                new PuntoPerfilYZ(centroY, centroZ + radioZ),
                new PuntoPerfilYZ(centroY + radioY, centroZ),
                new PuntoPerfilYZ(centroY, centroZ - radioZ),
                new PuntoPerfilYZ(centroY - radioY, centroZ)
            };
        }

        private double AjustarLadoPerfilMYG(
            double valor,
            double minimo,
            double maximo,
            double tolerancia,
            bool esMinimo)
        {
            valor = Math.Max(minimo, Math.Min(maximo, valor));

            if (esMinimo && valor - minimo <= tolerancia)
                return minimo;
            if (!esMinimo && maximo - valor <= tolerancia)
                return maximo;

            return valor;
        }

        private double ObtenerDiametroLongitudinalGanchoFtMYG(
            double diametroGuardadoMm,
            AceroVigaDisenoSeccion diseno)
        {
            if (diametroGuardadoMm > Tol)
            {
                return UnitUtils.ConvertToInternalUnits(
                    diametroGuardadoMm,
                    UnitTypeId.Millimeters);
            }

            double mayorMm = 0.0;

            if (diseno != null && diseno.Longitudinales != null)
            {
                foreach (AceroVigaBarraLongitudinal2D barra in
                    diseno.Longitudinales)
                {
                    if (barra == null)
                        continue;

                    double d = barra.DiametroMm;
                    if (d <= Tol && barra.TipoBarra != null)
                        d = ObtenerDiametroBarraFt(barra.TipoBarra) * 304.8;

                    mayorMm = Math.Max(mayorMm, d);
                }
            }

            if (mayorMm <= Tol)
                mayorMm = 16.0;

            return UnitUtils.ConvertToInternalUnits(
                mayorMm,
                UnitTypeId.Millimeters);
        }

        private double ObtenerRadioDobladoEjeEstriboVigaMYG(
            RebarBarType tipo)
        {
            if (tipo == null)
                return Tol;

            double diametroModelo = ObtenerDiametroBarraFt(tipo);
            double diametroDobladoInterior = 0.0;

            try
            {
                if (tipo.BarModelDiameter > Tol)
                    diametroModelo = tipo.BarModelDiameter;
            }
            catch
            {
            }

            try
            {
                diametroDobladoInterior = tipo.StirrupTieBendDiameter;
            }
            catch
            {
            }

            if (diametroDobladoInterior <= Tol)
            {
                try
                {
                    Parameter parametro = tipo.get_Parameter(
                        BuiltInParameter.REBAR_BAR_STIRRUP_BEND_DIAMETER);

                    if (parametro != null &&
                        parametro.StorageType == StorageType.Double)
                    {
                        diametroDobladoInterior = parametro.AsDouble();
                    }
                }
                catch
                {
                }
            }

            if (diametroDobladoInterior <= Tol)
                diametroDobladoInterior = diametroModelo * 4.0;

            return Math.Max(
                diametroDobladoInterior * 0.5 + diametroModelo * 0.5,
                Tol);
        }

        private List<PuntoPerfilYZ> PrepararGanchoAdaptadoLongitudinalesVigaMYG(
            PuntoPerfilYZ centroInicio,
            PuntoPerfilYZ centroFin,
            bool tipoS,
            double diametroLongitudinalInicio,
            double diametroLongitudinalFin,
            double diametroEstribo,
            double radioDobladoEje,
            List<PuntoPerfilYZ> contornoViga,
            out RebarTerminationOrientation orientacionInicio,
            out RebarTerminationOrientation orientacionFin)
        {
            orientacionInicio = RebarTerminationOrientation.Right;
            orientacionFin = tipoS
                ? RebarTerminationOrientation.Left
                : RebarTerminationOrientation.Right;

            if (centroInicio == null || centroFin == null)
                return new List<PuntoPerfilYZ>();

            PuntoPerfilYZ direccionCentros = NormalizarPuntoPerfilGanchoMYG(
                new PuntoPerfilYZ(
                    centroFin.Y - centroInicio.Y,
                    centroFin.Z - centroInicio.Z));

            if (direccionCentros == null)
                return new List<PuntoPerfilYZ>();

            PuntoPerfilYZ normalIzquierda = new PuntoPerfilYZ(
                -direccionCentros.Z,
                direccionCentros.Y);
            PuntoPerfilYZ centroide = CentroidePerfilGanchoMYG(contornoViga);
            PuntoPerfilYZ puntoMedio = new PuntoPerfilYZ(
                (centroInicio.Y + centroFin.Y) * 0.5,
                (centroInicio.Z + centroFin.Z) * 0.5);
            double productoInterior =
                normalIzquierda.Y * (centroide.Y - puntoMedio.Y) +
                normalIzquierda.Z * (centroide.Z - puntoMedio.Z);
            double signoInterior = productoInterior >= 0.0 ? 1.0 : -1.0;
            PuntoPerfilYZ normalInterior = new PuntoPerfilYZ(
                normalIzquierda.Y * signoInterior,
                normalIzquierda.Z * signoInterior);

            double radioContactoInicio = Math.Max(
                (diametroLongitudinalInicio + diametroEstribo) * 0.5,
                Tol);
            double radioContactoFin = Math.Max(
                (diametroLongitudinalFin + diametroEstribo) * 0.5,
                Tol);
            double distanciaCentros = DistanciaPerfilGanchoMYG(
                centroInicio,
                centroFin);

            PuntoPerfilYZ baseInicio;
            PuntoPerfilYZ baseFin;

            if (tipoS && TryCalcularCuerpoGanchoSVigaMYG(
                centroInicio,
                centroFin,
                radioDobladoEje,
                normalInterior,
                contornoViga,
                out baseInicio,
                out baseFin))
            {
                // El cuerpo S utiliza la tangente interior común a dos
                // curvaturas centradas en las barras; por eso su pendiente es
                // variable y depende de la separación y del radio real.
            }
            else
            {
                PuntoPerfilYZ tangenciaInicio = new PuntoPerfilYZ(
                    centroInicio.Y + normalInterior.Y * radioContactoInicio,
                    centroInicio.Z + normalInterior.Z * radioContactoInicio);
                PuntoPerfilYZ tangenciaFin = new PuntoPerfilYZ(
                    centroFin.Y + normalInterior.Y * radioContactoFin *
                        (tipoS ? -1.0 : 1.0),
                    centroFin.Z + normalInterior.Z * radioContactoFin *
                        (tipoS ? -1.0 : 1.0));
                baseInicio = tangenciaInicio;
                baseFin = tangenciaFin;
            }

            PuntoPerfilYZ tangenteCuerpo = NormalizarPuntoPerfilGanchoMYG(
                new PuntoPerfilYZ(
                    baseFin.Y - baseInicio.Y,
                    baseFin.Z - baseInicio.Z));

            if (tangenteCuerpo == null)
                return new List<PuntoPerfilYZ>();

            double extensionInicio = CalcularExtensionAmarreGanchoVigaMYG(
                radioContactoInicio,
                radioDobladoEje,
                distanciaCentros);
            double extensionFin = CalcularExtensionAmarreGanchoVigaMYG(
                radioContactoFin,
                radioDobladoEje,
                distanciaCentros);

            PuntoPerfilYZ inicioCuerpo = new PuntoPerfilYZ(
                baseInicio.Y - tangenteCuerpo.Y * extensionInicio,
                baseInicio.Z - tangenteCuerpo.Z * extensionInicio);
            PuntoPerfilYZ finCuerpo = new PuntoPerfilYZ(
                baseFin.Y + tangenteCuerpo.Y * extensionFin,
                baseFin.Z + tangenteCuerpo.Z * extensionFin);

            inicioCuerpo = LimitarPuntoGanchoDentroPerfilMYG(
                baseInicio,
                inicioCuerpo,
                contornoViga);
            finCuerpo = LimitarPuntoGanchoDentroPerfilMYG(
                baseFin,
                finCuerpo,
                contornoViga);

            PuntoPerfilYZ tangenteReal = NormalizarPuntoPerfilGanchoMYG(
                new PuntoPerfilYZ(
                    finCuerpo.Y - inicioCuerpo.Y,
                    finCuerpo.Z - inicioCuerpo.Z));
            PuntoPerfilYZ direccionGanchoInicio =
                NormalizarPuntoPerfilGanchoMYG(
                    new PuntoPerfilYZ(
                        centroInicio.Y - inicioCuerpo.Y,
                        centroInicio.Z - inicioCuerpo.Z));
            PuntoPerfilYZ direccionGanchoFin =
                NormalizarPuntoPerfilGanchoMYG(
                    new PuntoPerfilYZ(
                        centroFin.Y - finCuerpo.Y,
                        centroFin.Z - finCuerpo.Z));

            orientacionInicio = ResolverOrientacionInicioGanchoVigaMYG(
                tangenteReal,
                direccionGanchoInicio);
            orientacionFin = ResolverOrientacionFinGanchoVigaMYG(
                tangenteReal,
                direccionGanchoFin);

            if (tipoS)
            {
                if (orientacionInicio == orientacionFin)
                    orientacionFin = InvertirOrientacionEstriboEditorMYG(
                        orientacionFin);
            }
            else
            {
                if (orientacionInicio != orientacionFin)
                    orientacionFin = orientacionInicio;
            }

            // Mismo sentido validado en el módulo de columnas.
            orientacionInicio = InvertirOrientacionEstriboEditorMYG(
                orientacionInicio);
            orientacionFin = InvertirOrientacionEstriboEditorMYG(
                orientacionFin);

            return new List<PuntoPerfilYZ>
            {
                inicioCuerpo,
                finCuerpo
            };
        }

        private bool TryCalcularCuerpoGanchoSVigaMYG(
            PuntoPerfilYZ centroInicio,
            PuntoPerfilYZ centroFin,
            double radioCurvatura,
            PuntoPerfilYZ normalInterior,
            List<PuntoPerfilYZ> contornoViga,
            out PuntoPerfilYZ inicioCuerpo,
            out PuntoPerfilYZ finCuerpo)
        {
            inicioCuerpo = null;
            finCuerpo = null;

            double distanciaCentros = DistanciaPerfilGanchoMYG(
                centroInicio,
                centroFin);
            radioCurvatura = Math.Max(radioCurvatura, Tol);

            if (distanciaCentros <= 2.0 * radioCurvatura + Tol)
                return false;

            PuntoPerfilYZ ejeCentros = NormalizarPuntoPerfilGanchoMYG(
                new PuntoPerfilYZ(
                    centroFin.Y - centroInicio.Y,
                    centroFin.Z - centroInicio.Z));
            PuntoPerfilYZ normalEje = new PuntoPerfilYZ(
                -ejeCentros.Z,
                ejeCentros.Y);
            double seno = Math.Max(
                0.0,
                Math.Min(0.999999, 2.0 * radioCurvatura / distanciaCentros));
            double coseno = Math.Sqrt(Math.Max(0.0, 1.0 - seno * seno));

            PuntoPerfilYZ tangenteA = NormalizarPuntoPerfilGanchoMYG(
                new PuntoPerfilYZ(
                    ejeCentros.Y * coseno + normalEje.Y * seno,
                    ejeCentros.Z * coseno + normalEje.Z * seno));
            PuntoPerfilYZ normalA = new PuntoPerfilYZ(
                -tangenteA.Z,
                tangenteA.Y);
            PuntoPerfilYZ inicioA = new PuntoPerfilYZ(
                centroInicio.Y - normalA.Y * radioCurvatura,
                centroInicio.Z - normalA.Z * radioCurvatura);
            PuntoPerfilYZ finA = new PuntoPerfilYZ(
                centroFin.Y + normalA.Y * radioCurvatura,
                centroFin.Z + normalA.Z * radioCurvatura);

            PuntoPerfilYZ tangenteB = NormalizarPuntoPerfilGanchoMYG(
                new PuntoPerfilYZ(
                    ejeCentros.Y * coseno - normalEje.Y * seno,
                    ejeCentros.Z * coseno - normalEje.Z * seno));
            PuntoPerfilYZ normalB = new PuntoPerfilYZ(
                -tangenteB.Z,
                tangenteB.Y);
            PuntoPerfilYZ inicioB = new PuntoPerfilYZ(
                centroInicio.Y + normalB.Y * radioCurvatura,
                centroInicio.Z + normalB.Z * radioCurvatura);
            PuntoPerfilYZ finB = new PuntoPerfilYZ(
                centroFin.Y - normalB.Y * radioCurvatura,
                centroFin.Z - normalB.Z * radioCurvatura);

            PuntoPerfilYZ referenciaInicio = new PuntoPerfilYZ(
                centroInicio.Y + normalInterior.Y * radioCurvatura,
                centroInicio.Z + normalInterior.Z * radioCurvatura);
            PuntoPerfilYZ referenciaFin = new PuntoPerfilYZ(
                centroFin.Y - normalInterior.Y * radioCurvatura,
                centroFin.Z - normalInterior.Z * radioCurvatura);

            double puntajeA =
                DistanciaPerfilGanchoMYG(inicioA, referenciaInicio) +
                DistanciaPerfilGanchoMYG(finA, referenciaFin);
            double puntajeB =
                DistanciaPerfilGanchoMYG(inicioB, referenciaInicio) +
                DistanciaPerfilGanchoMYG(finB, referenciaFin);

            if (PuntoDentroOPegadoPoligonoYZ(
                inicioA.Y,
                inicioA.Z,
                contornoViga,
                Tol) &&
                PuntoDentroOPegadoPoligonoYZ(
                    finA.Y,
                    finA.Z,
                    contornoViga,
                    Tol))
            {
                puntajeA -= distanciaCentros;
            }

            if (PuntoDentroOPegadoPoligonoYZ(
                inicioB.Y,
                inicioB.Z,
                contornoViga,
                Tol) &&
                PuntoDentroOPegadoPoligonoYZ(
                    finB.Y,
                    finB.Z,
                    contornoViga,
                    Tol))
            {
                puntajeB -= distanciaCentros;
            }

            if (puntajeA <= puntajeB)
            {
                inicioCuerpo = inicioA;
                finCuerpo = finA;
            }
            else
            {
                inicioCuerpo = inicioB;
                finCuerpo = finB;
            }

            return DistanciaPerfilGanchoMYG(
                inicioCuerpo,
                finCuerpo) > Tol;
        }

        private double CalcularExtensionAmarreGanchoVigaMYG(
            double radioContacto,
            double radioDobladoEje,
            double distanciaEntreCentros)
        {
            double senoMedio = Math.Sin(135.0 * Math.PI / 360.0);
            double extension =
                radioContacto +
                radioDobladoEje *
                ((1.0 / Math.Max(senoMedio, 0.20)) - 1.0);
            double limite = Math.Max(
                radioContacto,
                distanciaEntreCentros * 0.25);
            return Math.Max(radioContacto, Math.Min(extension, limite));
        }

        private PuntoPerfilYZ LimitarPuntoGanchoDentroPerfilMYG(
            PuntoPerfilYZ origenDentro,
            PuntoPerfilYZ candidato,
            List<PuntoPerfilYZ> poligono)
        {
            if (origenDentro == null || candidato == null ||
                poligono == null || poligono.Count < 3)
            {
                return candidato;
            }

            if (PuntoDentroOPegadoPoligonoYZ(
                candidato.Y,
                candidato.Z,
                poligono,
                Tol))
            {
                return candidato;
            }

            double inferior = 0.0;
            double superior = 1.0;
            PuntoPerfilYZ mejor = new PuntoPerfilYZ(
                origenDentro.Y,
                origenDentro.Z);

            for (int i = 0; i < 32; i++)
            {
                double t = (inferior + superior) * 0.5;
                PuntoPerfilYZ prueba = new PuntoPerfilYZ(
                    origenDentro.Y + (candidato.Y - origenDentro.Y) * t,
                    origenDentro.Z + (candidato.Z - origenDentro.Z) * t);

                if (PuntoDentroOPegadoPoligonoYZ(
                    prueba.Y,
                    prueba.Z,
                    poligono,
                    Tol))
                {
                    inferior = t;
                    mejor = prueba;
                }
                else
                {
                    superior = t;
                }
            }

            return mejor;
        }

        private PuntoPerfilYZ CentroidePerfilGanchoMYG(
            List<PuntoPerfilYZ> puntos)
        {
            if (puntos == null || puntos.Count == 0)
                return new PuntoPerfilYZ(0.0, 0.0);

            return new PuntoPerfilYZ(
                puntos.Average(x => x.Y),
                puntos.Average(x => x.Z));
        }

        private PuntoPerfilYZ NormalizarPuntoPerfilGanchoMYG(
            PuntoPerfilYZ vector)
        {
            if (vector == null)
                return null;

            double longitud = Math.Sqrt(
                vector.Y * vector.Y + vector.Z * vector.Z);
            if (longitud <= Tol)
                return null;

            return new PuntoPerfilYZ(
                vector.Y / longitud,
                vector.Z / longitud);
        }

        private double DistanciaPerfilGanchoMYG(
            PuntoPerfilYZ a,
            PuntoPerfilYZ b)
        {
            if (a == null || b == null)
                return double.MaxValue;

            double dy = b.Y - a.Y;
            double dz = b.Z - a.Z;
            return Math.Sqrt(dy * dy + dz * dz);
        }

        private RebarTerminationOrientation ResolverOrientacionInicioGanchoVigaMYG(
            PuntoPerfilYZ tangente,
            PuntoPerfilYZ direccionDeseada)
        {
            PuntoPerfilYZ derecha = new PuntoPerfilYZ(
                -tangente.Z,
                tangente.Y);
            PuntoPerfilYZ izquierda = new PuntoPerfilYZ(
                tangente.Z,
                -tangente.Y);

            double productoDerecha =
                derecha.Y * direccionDeseada.Y +
                derecha.Z * direccionDeseada.Z;
            double productoIzquierda =
                izquierda.Y * direccionDeseada.Y +
                izquierda.Z * direccionDeseada.Z;

            return productoDerecha >= productoIzquierda
                ? RebarTerminationOrientation.Right
                : RebarTerminationOrientation.Left;
        }

        private RebarTerminationOrientation ResolverOrientacionFinGanchoVigaMYG(
            PuntoPerfilYZ tangente,
            PuntoPerfilYZ direccionDeseada)
        {
            PuntoPerfilYZ derecha = new PuntoPerfilYZ(
                tangente.Z,
                -tangente.Y);
            PuntoPerfilYZ izquierda = new PuntoPerfilYZ(
                -tangente.Z,
                tangente.Y);

            double productoDerecha =
                derecha.Y * direccionDeseada.Y +
                derecha.Z * direccionDeseada.Z;
            double productoIzquierda =
                izquierda.Y * direccionDeseada.Y +
                izquierda.Z * direccionDeseada.Z;

            return productoDerecha >= productoIzquierda
                ? RebarTerminationOrientation.Right
                : RebarTerminationOrientation.Left;
        }

        private RebarTerminationOrientation InvertirOrientacionEstriboEditorMYG(
            RebarTerminationOrientation orientacion)
        {
            return orientacion == RebarTerminationOrientation.Right
                ? RebarTerminationOrientation.Left
                : RebarTerminationOrientation.Right;
        }

        private List<PuntoPerfilYZ> DesnormalizarPuntosEstriboEditorMYG(
            List<AceroVigaPuntoNormalizado> puntos,
            List<PuntoPerfilYZ> contornoUtil)
        {
            List<PuntoPerfilYZ> resultado = new List<PuntoPerfilYZ>();

            if (puntos == null || contornoUtil == null || contornoUtil.Count < 3)
                return resultado;

            double yMin = contornoUtil.Min(x => x.Y);
            double yMax = contornoUtil.Max(x => x.Y);
            double zMin = contornoUtil.Min(x => x.Z);
            double zMax = contornoUtil.Max(x => x.Z);

            if (yMax <= yMin + Tol || zMax <= zMin + Tol)
                return resultado;

            foreach (AceroVigaPuntoNormalizado punto in puntos)
            {
                if (punto == null)
                    continue;

                double u = Math.Max(0.0, Math.Min(1.0, punto.U));
                double v = Math.Max(0.0, Math.Min(1.0, punto.V));

                resultado.Add(new PuntoPerfilYZ(
                    yMin + (yMax - yMin) * u,
                    zMin + (zMax - zMin) * v));
            }

            return resultado;
        }

        private int ObtenerIndiceSuperiorDerechoPerfilEditorMYG(
            List<PuntoPerfilYZ> puntos)
        {
            if (puntos == null || puntos.Count == 0)
                return -1;

            double yMin = puntos.Min(x => x.Y);
            double yMax = puntos.Max(x => x.Y);
            double zMin = puntos.Min(x => x.Z);
            double zMax = puntos.Max(x => x.Z);
            double ancho = Math.Max(yMax - yMin, Tol);
            double alto = Math.Max(zMax - zMin, Tol);
            int mejor = 0;
            double mejorPuntaje = double.MinValue;

            for (int i = 0; i < puntos.Count; i++)
            {
                PuntoPerfilYZ p = puntos[i];
                if (p == null)
                    continue;

                double puntaje =
                    ((p.Y - yMin) / ancho) +
                    ((p.Z - zMin) / alto);

                if (puntaje > mejorPuntaje)
                {
                    mejorPuntaje = puntaje;
                    mejor = i;
                }
            }

            return mejor;
        }

        private List<PuntoPerfilYZ> ReordenarPerfilCerradoDesdeEsquinaMYG(
            List<PuntoPerfilYZ> puntos,
            int indiceInicio)
        {
            List<PuntoPerfilYZ> resultado = new List<PuntoPerfilYZ>();

            if (puntos == null || puntos.Count < 3)
                return resultado;

            int cantidad = puntos.Count;

            if (indiceInicio < 0 || indiceInicio >= cantidad)
                indiceInicio = ObtenerIndiceSuperiorDerechoPerfilEditorMYG(puntos);

            if (indiceInicio < 0 || indiceInicio >= cantidad)
                indiceInicio = 0;

            for (int paso = 0; paso < cantidad; paso++)
            {
                PuntoPerfilYZ p = puntos[(indiceInicio + paso) % cantidad];
                if (p != null)
                    resultado.Add(new PuntoPerfilYZ(p.Y, p.Z));
            }

            return resultado;
        }

        private List<Curve> CrearCurvasPerfilEditorMYG(
            XYZ centro,
            XYZ ejeY,
            XYZ ejeZ,
            List<PuntoPerfilYZ> puntos,
            bool cerrado)
        {
            List<Curve> curvas = new List<Curve>();

            if (centro == null || ejeY == null || ejeZ == null ||
                puntos == null || puntos.Count < (cerrado ? 3 : 2))
            {
                return curvas;
            }

            int cantidadSegmentos = cerrado ? puntos.Count : puntos.Count - 1;

            for (int i = 0; i < cantidadSegmentos; i++)
            {
                PuntoPerfilYZ a = puntos[i];
                PuntoPerfilYZ b = puntos[(i + 1) % puntos.Count];

                if (a == null || b == null)
                    continue;

                XYZ p1 = centro
                    .Add(ejeY.Multiply(a.Y))
                    .Add(ejeZ.Multiply(a.Z));
                XYZ p2 = centro
                    .Add(ejeY.Multiply(b.Y))
                    .Add(ejeZ.Multiply(b.Z));

                AgregarLineaSiValida(curvas, p1, p2);
            }

            return curvas;
        }

        private Rebar CrearRebarEstriboEditorMYG(
            Document doc,
            DatosViga viga,
            RebarBarType tipo,
            RebarHookType gancho,
            XYZ normal,
            List<Curve> curvas,
            bool cerrado,
            XYZ centroPerfil,
            XYZ ejeYPerfil,
            XYZ ejeZPerfil,
            List<PuntoPerfilYZ> poligonoPerfil,
            AceroVigaTipoEstribo2D tipoDiseno,
            RebarTerminationOrientation orientacionInicioPreferida,
            RebarTerminationOrientation orientacionFinPreferida)
        {
            if (doc == null || viga == null || viga.Elemento == null ||
                tipo == null || normal == null ||
                normal.GetLength() <= Tol || curvas == null || curvas.Count == 0)
            {
                return null;
            }

            RebarTerminationOrientation[] orientaciones =
                new RebarTerminationOrientation[]
                {
                    RebarTerminationOrientation.Right,
                    RebarTerminationOrientation.Left
                };

            bool esGanchoTipoC =
                tipoDiseno == AceroVigaTipoEstribo2D.GanchoC;
            bool esGanchoTipoS =
                tipoDiseno == AceroVigaTipoEstribo2D.GanchoS;

            if (!cerrado && (esGanchoTipoC || esGanchoTipoS))
            {
                if (gancho == null)
                    return null;

                List<Tuple<RebarTerminationOrientation,
                           RebarTerminationOrientation>> combinaciones =
                    new List<Tuple<RebarTerminationOrientation,
                                   RebarTerminationOrientation>>();

                Action<RebarTerminationOrientation,
                       RebarTerminationOrientation> agregar =
                    (inicio, fin) =>
                    {
                        if (!combinaciones.Any(x =>
                            x.Item1 == inicio && x.Item2 == fin))
                        {
                            combinaciones.Add(Tuple.Create(inicio, fin));
                        }
                    };

                agregar(
                    orientacionInicioPreferida,
                    orientacionFinPreferida);
                agregar(
                    InvertirOrientacionEstriboEditorMYG(
                        orientacionInicioPreferida),
                    InvertirOrientacionEstriboEditorMYG(
                        orientacionFinPreferida));

                XYZ normalBase = normal.Normalize();
                List<XYZ> normales = new List<XYZ>
                {
                    normalBase,
                    normalBase.Multiply(-1.0)
                };

                foreach (XYZ normalCandidata in normales)
                {
                    foreach (Tuple<RebarTerminationOrientation,
                                   RebarTerminationOrientation> combinacion
                        in combinaciones)
                    {
                        Rebar rb = CrearRebarDesdeCurvas2027(
                            doc,
                            RebarStyle.StirrupTie,
                            tipo,
                            gancho,
                            gancho,
                            viga.Elemento,
                            normalCandidata,
                            curvas,
                            combinacion.Item1,
                            combinacion.Item2);

                        if (rb != null)
                            return rb;
                    }
                }

                // C/S nunca se degrada a una barra abierta sin ganchos.
                return null;
            }

            // Para un estribo cerrado no se acepta la primera combinación que
            // Revit permita. Se prueban independientemente las cuatro parejas
            // Left/Right y ambos sentidos de la normal. Solo se conserva el
            // candidato cuyas DOS puntas de gancho terminan dentro del perfil.
            if (cerrado && gancho != null && poligonoPerfil != null &&
                poligonoPerfil.Count >= 3 && centroPerfil != null &&
                ejeYPerfil != null && ejeZPerfil != null)
            {
                List<XYZ> normales = new List<XYZ>();
                XYZ n = normal.Normalize();
                normales.Add(n);
                normales.Add(n.Multiply(-1.0));

                foreach (XYZ normalCandidata in normales)
                {
                    foreach (RebarTerminationOrientation inicio in orientaciones)
                    {
                        foreach (RebarTerminationOrientation fin in orientaciones)
                        {
                            Rebar rb = CrearRebarDesdeCurvas2027(
                                doc,
                                RebarStyle.StirrupTie,
                                tipo,
                                gancho,
                                gancho,
                                viga.Elemento,
                                normalCandidata,
                                curvas,
                                inicio,
                                fin);

                            if (rb == null)
                                continue;

                            try
                            {
                                doc.Regenerate();
                            }
                            catch
                            {
                            }

                            bool ambasPuntasDentro;
                            double salidaPuntas =
                                CalcularSalidaPuntasGanchoEditorMYG(
                                    rb,
                                    centroPerfil,
                                    ejeYPerfil,
                                    ejeZPerfil,
                                    poligonoPerfil,
                                    out ambasPuntasDentro);

                            if (ambasPuntasDentro && salidaPuntas <= Tol)
                                return rb;

                            try
                            {
                                if (rb.Id != ElementId.InvalidElementId)
                                    doc.Delete(rb.Id);
                            }
                            catch
                            {
                            }
                        }
                    }
                }

                // Nunca se conserva un estribo cerrado cuyos ganchos apunten
                // hacia afuera. Si ninguna combinación deja ambas puntas dentro,
                // se cancela este recorrido para no crear una armadura incorrecta.
                return null;
            }

            // Recorridos abiertos o perfiles creados expresamente sin gancho.
            foreach (RebarTerminationOrientation inicio in orientaciones)
            {
                foreach (RebarTerminationOrientation fin in orientaciones)
                {
                    Rebar rb = CrearRebarDesdeCurvas2027(
                        doc,
                        cerrado ? RebarStyle.StirrupTie : RebarStyle.Standard,
                        tipo,
                        null,
                        null,
                        viga.Elemento,
                        normal,
                        curvas,
                        inicio,
                        fin);

                    if (rb != null)
                        return rb;
                }
            }

            return null;
        }

        private double CalcularSalidaPuntasGanchoEditorMYG(
            Rebar rebar,
            XYZ centroPerfil,
            XYZ ejeYPerfil,
            XYZ ejeZPerfil,
            List<PuntoPerfilYZ> poligonoPerfil,
            out bool ambasPuntasDentro)
        {
            ambasPuntasDentro = false;

            if (rebar == null || centroPerfil == null ||
                ejeYPerfil == null || ejeZPerfil == null ||
                poligonoPerfil == null || poligonoPerfil.Count < 3)
            {
                return double.MaxValue;
            }

            List<Curve> curvasCentro =
                ObtenerCurvasCentroRebarIncluyendoGanchos(rebar);

            if (curvasCentro == null || curvasCentro.Count == 0)
                return double.MaxValue;

            List<XYZ> puntasLibres =
                ObtenerPuntasLibresCentroRebarMYG(curvasCentro);

            if (puntasLibres == null || puntasLibres.Count < 2)
                return double.MaxValue;

            // Si por la teselación aparecen más de dos extremos, se conservan
            // los dos más alejados entre sí: corresponden a las puntas libres.
            if (puntasLibres.Count > 2)
            {
                XYZ mejorA = null;
                XYZ mejorB = null;
                double mayor = -1.0;

                for (int i = 0; i < puntasLibres.Count; i++)
                {
                    for (int j = i + 1; j < puntasLibres.Count; j++)
                    {
                        double d = puntasLibres[i].DistanceTo(puntasLibres[j]);
                        if (d > mayor)
                        {
                            mayor = d;
                            mejorA = puntasLibres[i];
                            mejorB = puntasLibres[j];
                        }
                    }
                }

                puntasLibres = new List<XYZ>();
                if (mejorA != null) puntasLibres.Add(mejorA);
                if (mejorB != null) puntasLibres.Add(mejorB);
            }

            double toleranciaDentro = UnitUtils.ConvertToInternalUnits(
                0.25,
                UnitTypeId.Centimeters);

            double salidaTotal = 0.0;
            int dentro = 0;

            foreach (XYZ punta in puntasLibres.Take(2))
            {
                XYZ vector = punta - centroPerfil;
                double y = vector.DotProduct(ejeYPerfil);
                double z = vector.DotProduct(ejeZPerfil);

                if (PuntoDentroOPegadoPoligonoYZ(
                    y,
                    z,
                    poligonoPerfil,
                    toleranciaDentro))
                {
                    dentro++;
                    continue;
                }

                salidaTotal += DistanciaPuntoAPoligonoYZ(
                    y,
                    z,
                    poligonoPerfil);
            }

            ambasPuntasDentro = dentro >= 2;
            return ambasPuntasDentro ? 0.0 : salidaTotal;
        }

        private List<XYZ> ObtenerPuntasLibresCentroRebarMYG(
            List<Curve> curvas)
        {
            List<XYZ> puntos = new List<XYZ>();
            List<int> incidencias = new List<int>();

            if (curvas == null)
                return puntos;

            double toleranciaAgrupacion = UnitUtils.ConvertToInternalUnits(
                0.10,
                UnitTypeId.Centimeters);

            Action<XYZ> registrar = punto =>
            {
                if (punto == null)
                    return;

                for (int i = 0; i < puntos.Count; i++)
                {
                    if (puntos[i].DistanceTo(punto) <= toleranciaAgrupacion)
                    {
                        incidencias[i]++;
                        return;
                    }
                }

                puntos.Add(punto);
                incidencias.Add(1);
            };

            foreach (Curve curva in curvas)
            {
                if (curva == null)
                    continue;

                try
                {
                    registrar(curva.GetEndPoint(0));
                    registrar(curva.GetEndPoint(1));
                }
                catch
                {
                }
            }

            List<XYZ> libres = new List<XYZ>();
            for (int i = 0; i < puntos.Count; i++)
            {
                if (incidencias[i] == 1)
                    libres.Add(puntos[i]);
            }

            return libres;
        }

        // =========================================================
        // ESTRIBOS RECTANGULARES - GANCHOS SIEMPRE HACIA ADENTRO
        // =========================================================
        // Revit interpreta Left/Right según:
        // - el orden de las curvas;
        // - el sentido de la normal;
        // - la orientación local de la familia anfitriona.
        // Por eso no se fija una orientación única. Se crean candidatos
        // temporales, se regenera el documento y se comprueba la geometría
        // real del Rebar incluyendo los ganchos. Solo se conserva el candidato
        // cuyos puntos permanecen dentro del polígono del estribo.
        private Rebar CrearRebarRectangularConGanchosHaciaAdentroMYG(
            Document doc,
            DatosViga viga,
            RebarBarType tipoEstribo,
            RebarHookType ganchoEstribo135,
            List<Curve> curvas)
        {
            if (doc == null || viga == null || viga.Elemento == null)
                return null;

            if (tipoEstribo == null || ganchoEstribo135 == null)
                return null;

            if (curvas == null || curvas.Count < 4)
                return null;

            List<Tuple<RebarTerminationOrientation, RebarTerminationOrientation>> combinaciones =
                new List<Tuple<RebarTerminationOrientation, RebarTerminationOrientation>>()
                {
                    Tuple.Create(RebarTerminationOrientation.Left, RebarTerminationOrientation.Left),
                    Tuple.Create(RebarTerminationOrientation.Left, RebarTerminationOrientation.Right),
                    Tuple.Create(RebarTerminationOrientation.Right, RebarTerminationOrientation.Left),
                    Tuple.Create(RebarTerminationOrientation.Right, RebarTerminationOrientation.Right)
                };

            List<XYZ> normales = new List<XYZ>();

            if (viga.XAxis != null && viga.XAxis.GetLength() > Tol)
            {
                XYZ n = viga.XAxis.Normalize();
                normales.Add(n);
                normales.Add(n.Multiply(-1.0));
            }

            if (normales.Count == 0)
                return null;

            Rebar mejor = null;
            double mejorSalida = double.MaxValue;

            // Se permite únicamente una pequeña tolerancia numérica.
            double toleranciaAceptable = UnitUtils.ConvertToInternalUnits(
                0.50,
                UnitTypeId.Centimeters);

            foreach (XYZ normal in normales)
            {
                foreach (Tuple<RebarTerminationOrientation, RebarTerminationOrientation> combo in combinaciones)
                {
                    Rebar rb = CrearRebarDesdeCurvasConGanchosObligatoriosMYG(
                        doc,
                        viga,
                        tipoEstribo,
                        ganchoEstribo135,
                        curvas,
                        normal,
                        combo.Item1,
                        combo.Item2);

                    if (rb == null)
                        continue;

                    try
                    {
                        doc.Regenerate();
                    }
                    catch
                    {
                    }

                    double salida = CalcularSalidaExteriorGanchoCumbrera(
                        rb,
                        viga,
                        curvas,
                        0);

                    if (salida < mejorSalida)
                    {
                        if (mejor != null && mejor.Id != ElementId.InvalidElementId)
                        {
                            try
                            {
                                doc.Delete(mejor.Id);
                            }
                            catch
                            {
                            }
                        }

                        mejor = rb;
                        mejorSalida = salida;
                    }
                    else
                    {
                        try
                        {
                            if (rb.Id != ElementId.InvalidElementId)
                                doc.Delete(rb.Id);
                        }
                        catch
                        {
                        }
                    }

                    // La geometría completa, incluidos ambos ganchos, está dentro.
                    if (mejor != null && mejorSalida <= toleranciaAceptable)
                        return mejor;
                }
            }

            // Si ninguna combinación logra meter totalmente los ganchos,
            // no se conserva un estribo con ganchos hacia afuera.
            if (mejor != null)
            {
                try
                {
                    if (mejor.Id != ElementId.InvalidElementId)
                        doc.Delete(mejor.Id);
                }
                catch
                {
                }
            }

            return null;
        }

        private Rebar CrearRebarDesdeCurvasConGanchosObligatoriosMYG(
            Document doc,
            DatosViga viga,
            RebarBarType tipoEstribo,
            RebarHookType ganchoEstribo135,
            List<Curve> curvas,
            XYZ normal,
            RebarTerminationOrientation orientacionGanchoInicio,
            RebarTerminationOrientation orientacionGanchoFin)
        {
            if (doc == null || viga == null || viga.Elemento == null)
                return null;

            if (tipoEstribo == null || ganchoEstribo135 == null)
                return null;

            if (normal == null || normal.GetLength() <= Tol)
                return null;

            if (curvas == null || curvas.Count < 4)
                return null;

            Rebar rb = CrearRebarDesdeCurvas2027(
                doc,
                RebarStyle.StirrupTie,
                tipoEstribo,
                ganchoEstribo135,
                ganchoEstribo135,
                viga.Elemento,
                normal,
                curvas,
                orientacionGanchoInicio,
                orientacionGanchoFin);

            if (rb == null)
            {
                rb = CrearRebarDesdeCurvas2027(
                    doc,
                    RebarStyle.Standard,
                    tipoEstribo,
                    ganchoEstribo135,
                    ganchoEstribo135,
                    viga.Elemento,
                    normal,
                    curvas,
                    orientacionGanchoInicio,
                    orientacionGanchoFin);
            }

            if (rb != null)
            {
                AplicarParametrosRebarEstriboMYG(
                    doc,
                    rb,
                    viga.Elemento,
                    comentarioDistribucionEstribosActualMYG);
            }

            return rb;
        }

        private Rebar CrearRebarCumbreraConGanchoInterior(
            Document doc,
            DatosViga viga,
            RebarBarType tipoEstribo,
            RebarHookType ganchoEstribo135,
            List<Curve> curvas,
            int indiceGrupoCumbrera)
        {
            if (doc == null || viga == null || viga.Elemento == null)
                return null;

            if (curvas == null || curvas.Count < 4)
                return null;

            // Se prueban las 4 combinaciones posibles porque en vigas cumbrera
            // multi-elemento el eje local de algunos elementos puede estar invertido.
            // La validación conserva el estribo cuyo gancho no sobresale hacia el
            // exterior del lado izquierdo/derecho del perfil.
            List<Tuple<RebarTerminationOrientation, RebarTerminationOrientation>> combinaciones =
                new List<Tuple<RebarTerminationOrientation, RebarTerminationOrientation>>();

            if (indiceGrupoCumbrera == 0)
            {
                // Grupo izquierdo: se priorizan combinaciones que normalmente
                // meten el gancho hacia el eje central de la cumbrera.
                combinaciones.Add(Tuple.Create(RebarTerminationOrientation.Right, RebarTerminationOrientation.Left));
                combinaciones.Add(Tuple.Create(RebarTerminationOrientation.Right, RebarTerminationOrientation.Right));
                combinaciones.Add(Tuple.Create(RebarTerminationOrientation.Left, RebarTerminationOrientation.Right));
                combinaciones.Add(Tuple.Create(RebarTerminationOrientation.Left, RebarTerminationOrientation.Left));
            }
            else
            {
                // Grupo derecho: espejo del grupo izquierdo.
                combinaciones.Add(Tuple.Create(RebarTerminationOrientation.Left, RebarTerminationOrientation.Right));
                combinaciones.Add(Tuple.Create(RebarTerminationOrientation.Left, RebarTerminationOrientation.Left));
                combinaciones.Add(Tuple.Create(RebarTerminationOrientation.Right, RebarTerminationOrientation.Left));
                combinaciones.Add(Tuple.Create(RebarTerminationOrientation.Right, RebarTerminationOrientation.Right));
            }

            Rebar mejor = null;
            double mejorSalidaExterior = double.MaxValue;

            double toleranciaAceptable = UnitUtils.ConvertToInternalUnits(
                0.5,
                UnitTypeId.Centimeters);

            foreach (Tuple<RebarTerminationOrientation, RebarTerminationOrientation> combo in combinaciones)
            {
                Rebar rb = CrearRebarDesdeCurvas(
                    doc,
                    viga,
                    tipoEstribo,
                    ganchoEstribo135,
                    curvas,
                    combo.Item1,
                    combo.Item2);

                if (rb == null)
                    continue;

                try
                {
                    doc.Regenerate();
                }
                catch
                {
                }

                double salidaExterior = CalcularSalidaExteriorGanchoCumbrera(
                    rb,
                    viga,
                    curvas,
                    indiceGrupoCumbrera);

                if (salidaExterior < mejorSalidaExterior)
                {
                    if (mejor != null && mejor.Id != ElementId.InvalidElementId)
                    {
                        try
                        {
                            doc.Delete(mejor.Id);
                        }
                        catch
                        {
                        }
                    }

                    mejor = rb;
                    mejorSalidaExterior = salidaExterior;
                }
                else
                {
                    try
                    {
                        if (rb.Id != ElementId.InvalidElementId)
                            doc.Delete(rb.Id);
                    }
                    catch
                    {
                    }
                }

                // Si ya no sobresale hacia afuera, nos quedamos con ese.
                if (mejor != null && mejorSalidaExterior <= toleranciaAceptable)
                    return mejor;
            }

            return mejor;
        }

        private double CalcularSalidaExteriorGanchoCumbrera(
            Rebar rb,
            DatosViga viga,
            List<Curve> curvasBase,
            int indiceGrupoCumbrera)
        {
            if (rb == null || viga == null || curvasBase == null || curvasBase.Count == 0)
                return double.MaxValue;

            // =========================================================
            // VALIDACIÓN ROBUSTA DE GANCHO HACIA ADENTRO
            // =========================================================
            // Ya no se valida con BoundingBox en Y, porque en cumbreras con
            // un elemento por tramo el gancho puede salir hacia afuera sin
            // aumentar claramente el rango Y de la caja.
            //
            // Ahora se obtiene la geometría real de centro de la barra creada
            // INCLUYENDO GANCHOS y se compara contra el polígono base del
            // estribo de cumbrera.
            //
            // Si el gancho queda hacia adentro, sus puntos quedan dentro del
            // polígono del estribo. Si queda hacia afuera, alguno de sus puntos
            // cae fuera del polígono y la combinación se descarta o queda con
            // peor puntaje.
            //
            // Esta corrección solo afecta la elección Left/Right en cumbreras.
            // No modifica la geometría rectangular ni cambia los tramos.
            // =========================================================

            List<PuntoPerfilYZ> poligonoBase = ObtenerPoligonoYZDesdeCurvas(
                viga,
                curvasBase);

            if (poligonoBase == null || poligonoBase.Count < 3)
                return double.MaxValue;

            List<Curve> curvasRebar = ObtenerCurvasCentroRebarIncluyendoGanchos(rb);

            if (curvasRebar == null || curvasRebar.Count == 0)
                return double.MaxValue;

            List<XYZ> puntosRebar = ObtenerPuntosMuestreadosDeCurvas(curvasRebar);

            if (puntosRebar == null || puntosRebar.Count == 0)
                return double.MaxValue;

            double toleranciaDentro = UnitUtils.ConvertToInternalUnits(
                0.20,
                UnitTypeId.Centimeters);

            double peorSalida = 0.0;
            double sumaSalida = 0.0;

            foreach (XYZ p in puntosRebar)
            {
                if (p == null)
                    continue;

                double y = (p - viga.P0).DotProduct(viga.YAxis);
                double z = (p - viga.P0).DotProduct(viga.ZAxis);

                if (PuntoDentroOPegadoPoligonoYZ(y, z, poligonoBase, toleranciaDentro))
                    continue;

                double salida = DistanciaPuntoAPoligonoYZ(y, z, poligonoBase);

                if (salida > peorSalida)
                    peorSalida = salida;

                sumaSalida += salida;
            }

            // Se pondera principalmente la peor salida; la suma ayuda a resolver
            // empates si varias combinaciones tienen pequeñas salidas numéricas.
            return peorSalida + (sumaSalida * 0.05);
        }

        private List<PuntoPerfilYZ> ObtenerPoligonoYZDesdeCurvas(
            DatosViga viga,
            List<Curve> curvas)
        {
            List<PuntoPerfilYZ> pts = new List<PuntoPerfilYZ>();

            if (viga == null || curvas == null || curvas.Count == 0)
                return pts;

            foreach (Curve c in curvas)
            {
                if (c == null)
                    continue;

                try
                {
                    XYZ p = c.GetEndPoint(0);

                    double y = (p - viga.P0).DotProduct(viga.YAxis);
                    double z = (p - viga.P0).DotProduct(viga.ZAxis);

                    AgregarPuntoYZSiNoRepite(pts, y, z);
                }
                catch
                {
                }
            }

            // Agrega el punto final de la última curva solo para asegurar el cierre.
            try
            {
                Curve ultima = curvas[curvas.Count - 1];

                if (ultima != null)
                {
                    XYZ pFin = ultima.GetEndPoint(1);

                    double yFin = (pFin - viga.P0).DotProduct(viga.YAxis);
                    double zFin = (pFin - viga.P0).DotProduct(viga.ZAxis);

                    AgregarPuntoYZSiNoRepite(pts, yFin, zFin);
                }
            }
            catch
            {
            }

            // Si el último punto repite al primero, se elimina para trabajar
            // con un polígono limpio.
            if (pts.Count > 1)
            {
                PuntoPerfilYZ a = pts[0];
                PuntoPerfilYZ b = pts[pts.Count - 1];

                if (DistanciaYZ(a.Y, a.Z, b.Y, b.Z) <= Tol)
                    pts.RemoveAt(pts.Count - 1);
            }

            return pts;
        }

        private void AgregarPuntoYZSiNoRepite(
            List<PuntoPerfilYZ> pts,
            double y,
            double z)
        {
            if (pts == null)
                return;

            if (pts.Count > 0)
            {
                PuntoPerfilYZ ultimo = pts[pts.Count - 1];

                if (DistanciaYZ(ultimo.Y, ultimo.Z, y, z) <= Tol)
                    return;
            }

            pts.Add(new PuntoPerfilYZ(y, z));
        }

        private List<Curve> ObtenerCurvasCentroRebarIncluyendoGanchos(Rebar rb)
        {
            List<Curve> resultado = new List<Curve>();

            if (rb == null)
                return resultado;

            try
            {
                IList<Curve> curvas = rb.GetCenterlineCurves(
                    false,
                    false,
                    true,
                    MultiplanarOption.IncludeAllMultiplanarCurves,
                    0);

                if (curvas != null)
                    resultado.AddRange(curvas.Where(c => c != null));
            }
            catch
            {
                try
                {
                    IList<Curve> curvas = rb.GetCenterlineCurves(
                        false,
                        false,
                        true,
                        MultiplanarOption.IncludeOnlyPlanarCurves,
                        0);

                    if (curvas != null)
                        resultado.AddRange(curvas.Where(c => c != null));
                }
                catch
                {
                }
            }

            return resultado;
        }

        private List<XYZ> ObtenerPuntosMuestreadosDeCurvas(List<Curve> curvas)
        {
            List<XYZ> pts = new List<XYZ>();

            if (curvas == null || curvas.Count == 0)
                return pts;

            foreach (Curve c in curvas)
            {
                if (c == null)
                    continue;

                bool agregadoPorTeselado = false;

                try
                {
                    IList<XYZ> tess = c.Tessellate();

                    if (tess != null && tess.Count > 0)
                    {
                        foreach (XYZ p in tess)
                        {
                            if (p != null)
                                pts.Add(p);
                        }

                        agregadoPorTeselado = true;
                    }
                }
                catch
                {
                    agregadoPorTeselado = false;
                }

                if (!agregadoPorTeselado)
                {
                    try
                    {
                        XYZ p0 = c.GetEndPoint(0);
                        XYZ p1 = c.GetEndPoint(1);

                        if (p0 != null) pts.Add(p0);
                        if (p1 != null) pts.Add(p1);
                    }
                    catch
                    {
                    }
                }

                try
                {
                    XYZ pm = c.Evaluate(0.5, true);

                    if (pm != null)
                        pts.Add(pm);
                }
                catch
                {
                }
            }

            return pts;
        }

        private bool PuntoDentroOPegadoPoligonoYZ(
            double y,
            double z,
            List<PuntoPerfilYZ> poligono,
            double tolerancia)
        {
            if (poligono == null || poligono.Count < 3)
                return false;

            if (DistanciaPuntoAPoligonoYZ(y, z, poligono) <= Math.Abs(tolerancia))
                return true;

            bool dentro = false;
            int n = poligono.Count;

            for (int i = 0, j = n - 1; i < n; j = i++)
            {
                PuntoPerfilYZ pi = poligono[i];
                PuntoPerfilYZ pj = poligono[j];

                bool cruza = ((pi.Z > z) != (pj.Z > z)) &&
                             (y < (pj.Y - pi.Y) * (z - pi.Z) / ((pj.Z - pi.Z) + 1e-12) + pi.Y);

                if (cruza)
                    dentro = !dentro;
            }

            return dentro;
        }

        private double DistanciaPuntoAPoligonoYZ(
            double y,
            double z,
            List<PuntoPerfilYZ> poligono)
        {
            if (poligono == null || poligono.Count == 0)
                return double.MaxValue;

            double menor = double.MaxValue;
            int n = poligono.Count;

            for (int i = 0; i < n; i++)
            {
                PuntoPerfilYZ a = poligono[i];
                PuntoPerfilYZ b = poligono[(i + 1) % n];

                double d = DistanciaPuntoSegmentoYZ(y, z, a.Y, a.Z, b.Y, b.Z);

                if (d < menor)
                    menor = d;
            }

            return menor;
        }

        private double DistanciaPuntoSegmentoYZ(
            double py,
            double pz,
            double ay,
            double az,
            double by,
            double bz)
        {
            double vy = by - ay;
            double vz = bz - az;

            double len2 = (vy * vy) + (vz * vz);

            if (len2 <= Tol)
                return DistanciaYZ(py, pz, ay, az);

            double t = ((py - ay) * vy + (pz - az) * vz) / len2;

            if (t < 0.0) t = 0.0;
            if (t > 1.0) t = 1.0;

            double cy = ay + t * vy;
            double cz = az + t * vz;

            return DistanciaYZ(py, pz, cy, cz);
        }

        private double DistanciaYZ(
            double y1,
            double z1,
            double y2,
            double z2)
        {
            double dy = y1 - y2;
            double dz = z1 - z2;

            return Math.Sqrt((dy * dy) + (dz * dz));
        }

        private bool ObtenerRangoYCurvasLocal(
            DatosViga viga,
            List<Curve> curvas,
            out double minY,
            out double maxY)
        {
            minY = double.MaxValue;
            maxY = double.MinValue;

            if (viga == null || viga.YAxis == null || curvas == null || curvas.Count == 0)
                return false;

            foreach (Curve c in curvas)
            {
                if (c == null)
                    continue;

                try
                {
                    XYZ p0 = c.GetEndPoint(0);
                    XYZ p1 = c.GetEndPoint(1);

                    double y0 = (p0 - viga.P0).DotProduct(viga.YAxis);
                    double y1 = (p1 - viga.P0).DotProduct(viga.YAxis);

                    if (y0 < minY) minY = y0;
                    if (y0 > maxY) maxY = y0;
                    if (y1 < minY) minY = y1;
                    if (y1 > maxY) maxY = y1;
                }
                catch
                {
                }
            }

            return maxY > minY + Tol;
        }

        private bool ObtenerRangoYBoundingBoxLocal(
            DatosViga viga,
            Element elemento,
            out double minY,
            out double maxY)
        {
            minY = double.MaxValue;
            maxY = double.MinValue;

            if (viga == null || viga.YAxis == null || elemento == null)
                return false;

            BoundingBoxXYZ bb = null;

            try
            {
                bb = elemento.get_BoundingBox(null);
            }
            catch
            {
                bb = null;
            }

            if (bb == null)
                return false;

            XYZ[] pts = new XYZ[]
            {
                new XYZ(bb.Min.X, bb.Min.Y, bb.Min.Z),
                new XYZ(bb.Min.X, bb.Min.Y, bb.Max.Z),
                new XYZ(bb.Min.X, bb.Max.Y, bb.Min.Z),
                new XYZ(bb.Min.X, bb.Max.Y, bb.Max.Z),
                new XYZ(bb.Max.X, bb.Min.Y, bb.Min.Z),
                new XYZ(bb.Max.X, bb.Min.Y, bb.Max.Z),
                new XYZ(bb.Max.X, bb.Max.Y, bb.Min.Z),
                new XYZ(bb.Max.X, bb.Max.Y, bb.Max.Z)
            };

            foreach (XYZ p in pts)
            {
                double y = (p - viga.P0).DotProduct(viga.YAxis);

                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }

            return maxY > minY + Tol;
        }

        private Rebar CrearRebarDesdeCurvas(
            Document doc,
            DatosViga viga,
            RebarBarType tipoEstribo,
            RebarHookType ganchoEstribo135,
            List<Curve> curvas,
            RebarTerminationOrientation orientacionGanchoInicio = RebarTerminationOrientation.Left,
            RebarTerminationOrientation orientacionGanchoFin = RebarTerminationOrientation.Left)
        {
            if (doc == null || viga == null || viga.Elemento == null)
                return null;

            if (curvas == null || curvas.Count < 4)
                return null;

            Rebar rb = CrearRebarDesdeCurvas2027(
                doc,
                RebarStyle.StirrupTie,
                tipoEstribo,
                ganchoEstribo135,
                ganchoEstribo135,
                viga.Elemento,
                viga.XAxis,
                curvas,
                orientacionGanchoInicio,
                orientacionGanchoFin);

            if (rb != null)
            {
                AplicarParametrosRebarEstriboMYG(
                    doc,
                    rb,
                    viga.Elemento,
                    comentarioDistribucionEstribosActualMYG);

                return rb;
            }

            rb = CrearRebarDesdeCurvas2027(
                doc,
                RebarStyle.Standard,
                tipoEstribo,
                ganchoEstribo135,
                ganchoEstribo135,
                viga.Elemento,
                viga.XAxis,
                curvas,
                orientacionGanchoInicio,
                orientacionGanchoFin);

            if (rb != null)
            {
                AplicarParametrosRebarEstriboMYG(
                    doc,
                    rb,
                    viga.Elemento,
                    comentarioDistribucionEstribosActualMYG);

                return rb;
            }

            rb = CrearRebarDesdeCurvas2027(
                doc,
                RebarStyle.Standard,
                tipoEstribo,
                null,
                null,
                viga.Elemento,
                viga.XAxis,
                curvas,
                orientacionGanchoInicio,
                orientacionGanchoFin);

            if (rb != null)
            {
                AplicarParametrosRebarEstriboMYG(
                    doc,
                    rb,
                    viga.Elemento,
                    comentarioDistribucionEstribosActualMYG);
            }

            return rb;
        }

        // =========================================================
        // PARÁMETROS MYG PARA REBAR DE ESTRIBOS
        // =========================================================
        private void AplicarParametrosRebarEstriboMYG(
            Document doc,
            Rebar rebar,
            Element anfitrion,
            string comentarioDistribucion)
        {
            if (doc == null || rebar == null || anfitrion == null)
                return;

            try
            {
                string descripcionTipo = ObtenerDescripcionTipoAnfitrionMYG(
                    doc,
                    anfitrion);

                EstablecerTextoParametroMYG(
                    rebar,
                    "STR_AnfitriónAcero",
                    descripcionTipo);

                EstablecerTextoParametroMYG(
                    rebar,
                    "STR_Resistencia",
                    "F'y=4200 kg/cm²");

                if (!EstablecerTextoParametroMYG(
                    rebar,
                    "STR_TipoDeElemento (V/H)",
                    "Estribos"))
                {
                    EstablecerTextoParametroMYG(
                        rebar,
                        "STR_TipoDeElemento",
                        "Estribos");
                }

                CopiarParametroEntreElementosMYG(
                    doc,
                    anfitrion,
                    rebar,
                    "STR_Ubicación");

                EstablecerTextoParametroMYG(
                    rebar,
                    "STR_Materialidad",
                    "Acero de refuerzo corrugado");

                EstablecerTextoParametroMYG(
                    rebar,
                    "GEN_Disciplina",
                    "Estructuras");

                EstablecerIdElementoParametroMYG(
                    rebar,
                    "GEN_ID Elemento",
                    rebar.Id.Value);

                CopiarParametroEntreElementosMYG(
                    doc,
                    anfitrion,
                    rebar,
                    "GEN_Nivel");

                // Se escribe tanto en el parámetro integrado de Comentarios como
                // en TODOS los parámetros editables que tengan exactamente el mismo nombre.
                // Esto cubre proyectos donde existen parámetros compartidos duplicados.
                Parameter pComentariosIntegrado = null;

                try
                {
                    pComentariosIntegrado = rebar.get_Parameter(
                        BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);
                }
                catch
                {
                    pComentariosIntegrado = null;
                }

                if (pComentariosIntegrado != null && !pComentariosIntegrado.IsReadOnly)
                {
                    EstablecerValorParametroDesdeTextoMYG(
                        pComentariosIntegrado,
                        comentarioDistribucion,
                        doc);
                }

                EstablecerTextoParametroMYG(
                    rebar,
                    "Comentarios",
                    comentarioDistribucion);
            }
            catch
            {
                // Los parámetros compartidos no deben detener la creación del acero.
            }
        }

        private string ConstruirComentarioDistribucionEstribosMYG(
            RebarBarType tipoEstribo,
            AceroEstribosVigasForm.TramoEstriboConfig cfg)
        {
            // 1 = solo estribo exterior.
            // 2 = estribo exterior + estribo central.
            int cantidadEstribosEnSeccionMYG =
                DebeCrearEstriboCentralMYG() ? 2 : 1;

            if (cfg == null)
            {
                return (
                    cantidadEstribosEnSeccionMYG.ToString(
                        System.Globalization.CultureInfo.InvariantCulture) +
                    " \u25AD " +
                    ObtenerSimboloEstriboMYG(tipoEstribo) +
                    ":"
                ).Trim();
            }

            string simbolo = ObtenerSimboloEstriboMYG(tipoEstribo);
            int n = Math.Max(1, Math.Min(4, cfg.TipoDistribucion));
            List<string> partes = new List<string>();

            for (int i = 0; i < n; i++)
            {
                double separacionCm =
                    cfg.SeparacionesCm != null &&
                    i < cfg.SeparacionesCm.Length
                        ? cfg.SeparacionesCm[i]
                        : 0.0;

                int cantidad =
                    cfg.Cantidades != null &&
                    i < cfg.Cantidades.Length
                        ? cfg.Cantidades[i]
                        : 0;

                string separacionM = (separacionCm / 100.0).ToString(
                    "0.00",
                    System.Globalization.CultureInfo.InvariantCulture);

                bool esResto = n >= 2 && i == n - 1;

                if (esResto)
                {
                    partes.Add("Rto. @ " + separacionM + "m");
                }
                else
                {
                    partes.Add(
                        Math.Max(1, cantidad).ToString(
                            System.Globalization.CultureInfo.InvariantCulture) +
                        " @ " +
                        separacionM +
                        "m");
                }
            }

            // U+25AD = WHITE RECTANGLE.
            return (
                cantidadEstribosEnSeccionMYG.ToString(
                    System.Globalization.CultureInfo.InvariantCulture) +
                " \u25AD " +
                simbolo +
                ": " +
                string.Join(", ", partes)
            ).Trim();
        }

        private string ObtenerSimboloEstriboMYG(RebarBarType tipoEstribo)
        {
            string nombre = "";

            if (tipoEstribo != null)
            {
                try
                {
                    nombre = tipoEstribo.Name ?? "";
                }
                catch
                {
                    nombre = "";
                }
            }

            if (!string.IsNullOrWhiteSpace(nombre))
            {
                System.Text.RegularExpressions.Match fraccion =
                    System.Text.RegularExpressions.Regex.Match(
                        nombre,
                        @"(?<!\d)(\d+\s+)?\d+\s*/\s*\d+\s*[""”]?");

                if (fraccion.Success)
                {
                    string valor = fraccion.Value
                        .Replace(" ", "")
                        .Replace("”", "\"");

                    if (!valor.EndsWith("\""))
                        valor += "\"";

                    return "Ø" + valor;
                }
            }

            double diametroFt = ObtenerDiametroBarraFt(tipoEstribo);
            double diametroMm = diametroFt > 0.0
                ? UnitUtils.ConvertFromInternalUnits(diametroFt, UnitTypeId.Millimeters)
                : 0.0;

            Tuple<double, string>[] equivalencias = new Tuple<double, string>[]
            {
                Tuple.Create(6.350, "1/4\""),
                Tuple.Create(7.938, "5/16\""),
                Tuple.Create(9.525, "3/8\""),
                Tuple.Create(12.700, "1/2\""),
                Tuple.Create(15.875, "5/8\""),
                Tuple.Create(19.050, "3/4\""),
                Tuple.Create(22.225, "7/8\""),
                Tuple.Create(25.400, "1\"")
            };

            Tuple<double, string> mejor = equivalencias
                .OrderBy(x => Math.Abs(x.Item1 - diametroMm))
                .FirstOrDefault();

            if (mejor != null && Math.Abs(mejor.Item1 - diametroMm) <= 1.0)
                return "Ø" + mejor.Item2;

            if (diametroMm > 0.0)
            {
                return "Ø" + diametroMm.ToString(
                    "0.#",
                    System.Globalization.CultureInfo.InvariantCulture) + " mm";
            }

            return "Ø";
        }

        private string ObtenerDescripcionTipoAnfitrionMYG(
            Document doc,
            Element anfitrion)
        {
            if (doc == null || anfitrion == null)
                return "";

            Element tipo = null;

            try
            {
                ElementId tipoId = anfitrion.GetTypeId();

                if (tipoId != null &&
                    tipoId != ElementId.InvalidElementId)
                {
                    tipo = doc.GetElement(tipoId);
                }
            }
            catch
            {
                tipo = null;
            }

            if (tipo == null)
                return "";

            string[] nombresDescripcion = new string[]
            {
                "Descripción de la cimentación",
                "Descripcion de la cimentacion",
                "Descripción cimentación",
                "Descripcion cimentacion",
                "Descripción",
                "Descripcion",
                "Description"
            };

            foreach (string nombre in nombresDescripcion)
            {
                List<Parameter> parametros =
                    BuscarTodosParametrosPorNombreMYG(
                        tipo,
                        nombre);

                foreach (Parameter parametro in parametros)
                {
                    string valor =
                        ObtenerTextoParametroMYG(
                            doc,
                            parametro);

                    if (!string.IsNullOrWhiteSpace(valor))
                        return valor.Trim();
                }
            }

            Parameter descripcionIntegrada = null;

            try
            {
                descripcionIntegrada = tipo.get_Parameter(
                    BuiltInParameter.ALL_MODEL_DESCRIPTION);
            }
            catch
            {
                descripcionIntegrada = null;
            }

            string valorIntegrado =
                ObtenerTextoParametroMYG(
                    doc,
                    descripcionIntegrada);

            if (!string.IsNullOrWhiteSpace(valorIntegrado))
                return valorIntegrado.Trim();

            try
            {
                return tipo.Name ?? "";
            }
            catch
            {
                return "";
            }
        }


        private bool CopiarParametroEntreElementosMYG(
            Document doc,
            Element origen,
            Element destino,
            string nombreParametro)
        {
            if (doc == null ||
                origen == null ||
                destino == null ||
                string.IsNullOrWhiteSpace(nombreParametro))
            {
                return false;
            }

            List<Parameter> parametrosOrigen =
                BuscarTodosParametrosPorNombreMYG(
                    origen,
                    nombreParametro);

            if (parametrosOrigen.Count == 0)
                return false;

            Parameter pOrigen = null;

            foreach (Parameter candidato in parametrosOrigen)
            {
                if (candidato == null)
                    continue;

                string valorCandidato =
                    ObtenerTextoParametroMYG(
                        doc,
                        candidato);

                if (!string.IsNullOrWhiteSpace(valorCandidato))
                {
                    pOrigen = candidato;
                    break;
                }
            }

            if (pOrigen == null)
                pOrigen = parametrosOrigen[0];

            List<Parameter> parametrosDestino =
                BuscarTodosParametrosPorNombreMYG(
                    destino,
                    nombreParametro);

            if (parametrosDestino.Count == 0)
                return false;

            bool algunoEscrito = false;

            foreach (Parameter pDestino in parametrosDestino)
            {
                if (pDestino == null || pDestino.IsReadOnly)
                    continue;

                bool escrito = false;

                try
                {
                    if (pOrigen.StorageType == pDestino.StorageType)
                    {
                        switch (pDestino.StorageType)
                        {
                            case StorageType.String:
                                pDestino.Set(pOrigen.AsString() ?? "");
                                escrito = true;
                                break;

                            case StorageType.Integer:
                                pDestino.Set(pOrigen.AsInteger());
                                escrito = true;
                                break;

                            case StorageType.Double:
                                pDestino.Set(pOrigen.AsDouble());
                                escrito = true;
                                break;

                            case StorageType.ElementId:
                                pDestino.Set(pOrigen.AsElementId());
                                escrito = true;
                                break;
                        }
                    }

                    if (!escrito)
                    {
                        escrito = EstablecerValorParametroDesdeTextoMYG(
                            pDestino,
                            ObtenerTextoParametroMYG(
                                doc,
                                pOrigen),
                            doc);
                    }
                }
                catch
                {
                    escrito = false;
                }

                if (escrito)
                    algunoEscrito = true;
            }

            return algunoEscrito;
        }


        private bool EstablecerTextoParametroMYG(
            Element elemento,
            string nombreParametro,
            string valor)
        {
            if (elemento == null || string.IsNullOrWhiteSpace(nombreParametro))
                return false;

            List<Parameter> parametros =
                BuscarTodosParametrosPorNombreMYG(elemento, nombreParametro);

            if (parametros.Count == 0)
                return false;

            bool algunoEscrito = false;

            foreach (Parameter p in parametros)
            {
                if (p == null || p.IsReadOnly)
                    continue;

                if (EstablecerValorParametroDesdeTextoMYG(
                    p,
                    valor ?? "",
                    elemento.Document))
                {
                    algunoEscrito = true;
                }
            }

            return algunoEscrito;
        }

        private bool EstablecerIdElementoParametroMYG(
            Element elemento,
            string nombreParametro,
            long valorId)
        {
            if (elemento == null || string.IsNullOrWhiteSpace(nombreParametro))
                return false;

            List<Parameter> parametros =
                BuscarTodosParametrosPorNombreMYG(elemento, nombreParametro);

            if (parametros.Count == 0)
                return false;

            bool algunoEscrito = false;

            foreach (Parameter p in parametros)
            {
                if (p == null || p.IsReadOnly)
                    continue;

                bool escrito = false;

                try
                {
                    switch (p.StorageType)
                    {
                        case StorageType.String:
                            p.Set(valorId.ToString(
                                System.Globalization.CultureInfo.InvariantCulture));
                            escrito = true;
                            break;

                        case StorageType.Integer:
                            if (valorId <= int.MaxValue && valorId >= int.MinValue)
                            {
                                p.Set((int)valorId);
                                escrito = true;
                            }
                            break;

                        case StorageType.ElementId:
                            p.Set(new ElementId(valorId));
                            escrito = true;
                            break;

                        case StorageType.Double:
                            p.Set((double)valorId);
                            escrito = true;
                            break;
                    }
                }
                catch
                {
                    escrito = false;
                }

                if (escrito)
                    algunoEscrito = true;
            }

            return algunoEscrito;
        }

        private bool EstablecerValorParametroDesdeTextoMYG(
            Parameter parametro,
            string valor,
            Document doc)
        {
            if (parametro == null || parametro.IsReadOnly)
                return false;

            valor = valor ?? "";

            try
            {
                switch (parametro.StorageType)
                {
                    case StorageType.String:
                        parametro.Set(valor);
                        return true;

                    case StorageType.Integer:
                        int entero;

                        if (int.TryParse(
                            valor,
                            System.Globalization.NumberStyles.Any,
                            System.Globalization.CultureInfo.InvariantCulture,
                            out entero))
                        {
                            parametro.Set(entero);
                            return true;
                        }

                        return false;

                    case StorageType.Double:
                        double numero;

                        if (double.TryParse(
                            valor.Replace(",", "."),
                            System.Globalization.NumberStyles.Any,
                            System.Globalization.CultureInfo.InvariantCulture,
                            out numero))
                        {
                            parametro.Set(numero);
                            return true;
                        }

                        return false;

                    case StorageType.ElementId:
                        long id;

                        if (long.TryParse(
                            valor,
                            System.Globalization.NumberStyles.Integer,
                            System.Globalization.CultureInfo.InvariantCulture,
                            out id))
                        {
                            parametro.Set(new ElementId(id));
                            return true;
                        }

                        return false;
                }
            }
            catch
            {
            }

            return false;
        }

        private string ObtenerTextoParametroMYG(
            Document doc,
            Parameter parametro)
        {
            if (parametro == null)
                return "";

            try
            {
                switch (parametro.StorageType)
                {
                    case StorageType.String:
                        return parametro.AsString() ?? "";

                    case StorageType.Integer:
                        return parametro.AsInteger().ToString(
                            System.Globalization.CultureInfo.InvariantCulture);

                    case StorageType.Double:
                        string valorFormateado = parametro.AsValueString();

                        if (!string.IsNullOrWhiteSpace(valorFormateado))
                            return valorFormateado;

                        return parametro.AsDouble().ToString(
                            System.Globalization.CultureInfo.InvariantCulture);

                    case StorageType.ElementId:
                        ElementId id = parametro.AsElementId();

                        if (id == null || id == ElementId.InvalidElementId)
                            return "";

                        if (doc != null)
                        {
                            Element e = doc.GetElement(id);

                            if (e != null)
                            {
                                try
                                {
                                    return e.Name ?? id.Value.ToString();
                                }
                                catch
                                {
                                }
                            }
                        }

                        return id.Value.ToString(
                            System.Globalization.CultureInfo.InvariantCulture);
                }
            }
            catch
            {
            }

            return "";
        }

        // =========================================================
        // BUSCAR TODOS LOS PARÁMETROS QUE COMPARTEN EL MISMO NOMBRE
        // =========================================================
        // LookupParameter devuelve solo uno cuando hay nombres duplicados.
        // GetParameters devuelve todos los parámetros coincidentes del elemento.
        private List<Parameter> BuscarTodosParametrosPorNombreMYG(
            Element elemento,
            string nombreParametro)
        {
            List<Parameter> resultado = new List<Parameter>();

            if (elemento == null || string.IsNullOrWhiteSpace(nombreParametro))
                return resultado;

            try
            {
                IList<Parameter> encontrados = elemento.GetParameters(nombreParametro);

                if (encontrados != null)
                {
                    foreach (Parameter p in encontrados)
                    {
                        if (p != null && !resultado.Contains(p))
                            resultado.Add(p);
                    }
                }
            }
            catch
            {
            }

            // Respaldo para familias/versiones donde GetParameters no devuelva resultados.
            if (resultado.Count == 0)
            {
                try
                {
                    Parameter p = elemento.LookupParameter(nombreParametro);

                    if (p != null)
                        resultado.Add(p);
                }
                catch
                {
                }
            }

            return resultado;
        }

        private Parameter BuscarParametroPorNombresMYG(
            Element elemento,
            IEnumerable<string> nombres)
        {
            if (elemento == null || nombres == null)
                return null;

            foreach (string nombre in nombres)
            {
                if (string.IsNullOrWhiteSpace(nombre))
                    continue;

                try
                {
                    Parameter p = elemento.LookupParameter(nombre);

                    if (p != null)
                        return p;
                }
                catch
                {
                }
            }

            return null;
        }

        private Rebar CrearRebarDesdeCurvas2027(
            Document doc,
            RebarStyle estilo,
            RebarBarType tipoBarra,
            RebarHookType ganchoInicio,
            RebarHookType ganchoFin,
            Element host,
            XYZ normal,
            List<Curve> curvas,
            RebarTerminationOrientation orientacionInicio,
            RebarTerminationOrientation orientacionFin)
        {
            if (doc == null)
                return null;

            if (tipoBarra == null)
                return null;

            if (host == null)
                return null;

            if (normal == null || normal.GetLength() <= Tol)
                return null;

            if (curvas == null || curvas.Count == 0)
                return null;

            try
            {
                using (BarTerminationsData terminaciones = new BarTerminationsData(doc))
                {
                    terminaciones.HookTypeIdAtStart =
                        ganchoInicio != null
                            ? ganchoInicio.Id
                            : ElementId.InvalidElementId;

                    terminaciones.HookTypeIdAtEnd =
                        ganchoFin != null
                            ? ganchoFin.Id
                            : ElementId.InvalidElementId;

                    terminaciones.TerminationOrientationAtStart = orientacionInicio;
                    terminaciones.TerminationOrientationAtEnd = orientacionFin;

                    return Rebar.CreateFromCurves(
                        doc,
                        estilo,
                        tipoBarra,
                        host,
                        normal,
                        curvas,
                        terminaciones,
                        true,
                        true);
                }
            }
            catch
            {
                return null;
            }
        }

        private bool EsFormaCumbreraSeleccionada()
        {
            try
            {
                return Form != null &&
                       Form.FormaEstriboSeleccionada == AceroEstribosVigasForm.TipoFormaEstribo.Cumbrera;
            }
            catch
            {
                return false;
            }
        }

        private bool DebeForzarRectangularPorEstacionVariable(
            DatosViga viga)
        {
            if (viga == null)
                return false;

            if (viga.TieneSeccionVariableEstribos)
                return true;

            if (viga.TienePerfilZLinealEstribos)
            {
                double tolerancia = UnitUtils.ConvertToInternalUnits(
                    0.5,
                    UnitTypeId.Centimeters);

                double peralteInicio = viga.ZSuperiorInicio - viga.ZInferiorInicio;
                double peralteFin = viga.ZSuperiorFin - viga.ZInferiorFin;

                if (Math.Abs(viga.ZSuperiorFin - viga.ZSuperiorInicio) > tolerancia ||
                    Math.Abs(viga.ZInferiorFin - viga.ZInferiorInicio) > tolerancia ||
                    Math.Abs(peralteFin - peralteInicio) > tolerancia)
                {
                    return true;
                }
            }

            double toleranciaCambio = UnitUtils.ConvertToInternalUnits(
                0.5,
                UnitTypeId.Centimeters);

            return DetectarCambioZPorMuestrasDeSolido(viga, toleranciaCambio);
        }

        private List<Curve> CrearCurvasEstriboRectangularDesdeLimites(
            DatosViga viga,
            XYZ centro,
            double minY,
            double maxY,
            double minZ,
            double maxZ)
        {
            List<Curve> curvas = new List<Curve>();

            if (viga == null || centro == null)
                return curvas;

            XYZ p1 = PuntoLocalEstribo(viga, centro, minY, minZ);
            XYZ p2 = PuntoLocalEstribo(viga, centro, maxY, minZ);
            XYZ p3 = PuntoLocalEstribo(viga, centro, maxY, maxZ);
            XYZ p4 = PuntoLocalEstribo(viga, centro, minY, maxZ);

            AgregarLineaSiValida(curvas, p1, p2);
            AgregarLineaSiValida(curvas, p2, p3);
            AgregarLineaSiValida(curvas, p3, p4);
            AgregarLineaSiValida(curvas, p4, p1);

            return curvas;
        }

        private List<Curve> CrearCurvasEstriboRectangular(
            DatosViga viga,
            XYZ centro,
            double minY,
            double maxY,
            double minZ,
            double maxZ)
        {
            List<Curve> curvas = new List<Curve>();

            if (viga == null || centro == null)
                return curvas;

            // =========================================================
            // CLAVE PARA VIGAS DE SECCIÓN VARIABLE EN LONGITUD:
            // En este caso NO se debe usar el contorno Y-Z global del sólido,
            // porque ese contorno es una envolvente de toda la viga.
            // Como cada estribo individual ya llega con minZ/maxZ exactos de
            // su estación, aquí se dibuja directamente esa sección local.
            // =========================================================
            if (DebeForzarRectangularPorEstacionVariable(viga))
            {
                List<Curve> curvasPorEstacion = CrearCurvasEstriboRectangularDesdeLimites(
                    viga,
                    centro,
                    minY,
                    maxY,
                    minZ,
                    maxZ);

                if (curvasPorEstacion != null && curvasPorEstacion.Count >= 4)
                    return curvasPorEstacion;
            }

            // =========================================================
            // RECTANGULAR / TRAPEZOIDAL / SECCIÓN REAL DE 4 LADOS O MÁS
            // =========================================================
            // Antes el estribo "rectangular" siempre se dibujaba con la caja
            // minY/maxY/minZ/maxZ, por eso una viga trapezoidal terminaba con
            // un estribo rectangular.
            //
            // Ahora, cuando la forma seleccionada NO es cumbrera, se toma el
            // contorno real Y-Z de la sección de la viga, se genera un offset
            // interior con el recubrimiento al eje de la barra, y recién desde
            // ese polígono se construye el boceto del estribo.
            //
            // Si por alguna familia la geometría real no se puede reconstruir,
            // se mantiene el respaldo rectangular anterior.
            // =========================================================
            double recubrimientoEje = ObtenerRecubrimientoEjeDesdeLimites(
                viga,
                minY,
                maxY,
                minZ,
                maxZ);

            List<PuntoPerfilYZ> contornoInterior = ObtenerContornoInteriorSeccionRealYZ(
                viga,
                recubrimientoEje);

            if (contornoInterior != null && contornoInterior.Count >= 4)
            {
                List<Curve> curvasSeccionReal = CrearCurvasDesdeContornoPerfilYZ(
                    viga,
                    centro,
                    contornoInterior);

                if (curvasSeccionReal != null && curvasSeccionReal.Count >= 4)
                    return curvasSeccionReal;
            }

            // Respaldo original.
            XYZ p1 = PuntoLocalEstribo(viga, centro, minY, minZ);
            XYZ p2 = PuntoLocalEstribo(viga, centro, maxY, minZ);
            XYZ p3 = PuntoLocalEstribo(viga, centro, maxY, maxZ);
            XYZ p4 = PuntoLocalEstribo(viga, centro, minY, maxZ);

            AgregarLineaSiValida(curvas, p1, p2);
            AgregarLineaSiValida(curvas, p2, p3);
            AgregarLineaSiValida(curvas, p3, p4);
            AgregarLineaSiValida(curvas, p4, p1);

            return curvas;
        }

        private double ObtenerRecubrimientoEjeDesdeLimites(
            DatosViga viga,
            double minY,
            double maxY,
            double minZ,
            double maxZ)
        {
            if (viga == null)
                return UnitUtils.ConvertToInternalUnits(4.0, UnitTypeId.Centimeters);

            double recIzq = Math.Abs(minY - viga.YMin);
            double recDer = Math.Abs(viga.YMax - maxY);
            double recInf = Math.Abs(minZ - viga.ZMin);
            double recSup = Math.Abs(viga.ZMax - maxZ);

            List<double> valores = new List<double>()
            {
                recIzq,
                recDer,
                recInf,
                recSup
            }
            .Where(x => x > Tol)
            .ToList();

            if (valores.Count == 0)
                return UnitUtils.ConvertToInternalUnits(4.0, UnitTypeId.Centimeters);

            return valores.Min();
        }

        private List<PuntoPerfilYZ> ObtenerContornoInteriorSeccionRealYZ(
            DatosViga viga,
            double offsetInterior)
        {
            List<PuntoPerfilYZ> resultado = new List<PuntoPerfilYZ>();

            if (viga == null)
                return resultado;

            List<PuntoPerfilYZ> puntos = ObtenerPuntosPerfilYZ(viga);

            if (puntos == null || puntos.Count < 4)
                return resultado;

            List<PuntoPerfilYZ> hull = ConstruirHullPerfilYZ(puntos);

            if (hull == null || hull.Count < 4)
                return resultado;

            hull = LimpiarVerticesColinealesPerfilYZ(hull);

            if (hull == null || hull.Count < 4)
                return resultado;

            double yMin = hull.Min(p => p.Y);
            double yMax = hull.Max(p => p.Y);
            double zMin = hull.Min(p => p.Z);
            double zMax = hull.Max(p => p.Z);

            if (yMax <= yMin + Tol || zMax <= zMin + Tol)
                return resultado;

            // Punto interno para decidir hacia qué lado se desfasa cada arista.
            PuntoPerfilYZ puntoInterior = new PuntoPerfilYZ(
                (yMin + yMax) / 2.0,
                (zMin + zMax) / 2.0);

            double offsetMinimo = UnitUtils.ConvertToInternalUnits(
                0.5,
                UnitTypeId.Centimeters);

            double offset = Math.Max(offsetMinimo, Math.Abs(offsetInterior));

            List<LineaPerfilYZ> lineasOffset = new List<LineaPerfilYZ>();

            for (int i = 0; i < hull.Count; i++)
            {
                PuntoPerfilYZ a = hull[i];
                PuntoPerfilYZ b = hull[(i + 1) % hull.Count];

                LineaPerfilYZ linea = CrearLineaOffsetHaciaInterior(
                    a,
                    b,
                    puntoInterior,
                    offset);

                if (linea == null)
                    return resultado;

                lineasOffset.Add(linea);
            }

            for (int i = 0; i < hull.Count; i++)
            {
                LineaPerfilYZ anterior = lineasOffset[(i - 1 + lineasOffset.Count) % lineasOffset.Count];
                LineaPerfilYZ actual = lineasOffset[i];

                PuntoPerfilYZ p = IntersecarLineasPerfil(anterior, actual);

                if (p == null)
                {
                    // Respaldo para aristas casi paralelas: usa el vértice original
                    // movido aproximadamente hacia el centro de la sección.
                    PuntoPerfilYZ v = hull[i];

                    double dy = puntoInterior.Y - v.Y;
                    double dz = puntoInterior.Z - v.Z;
                    double len = Math.Sqrt((dy * dy) + (dz * dz));

                    if (len <= Tol)
                        return new List<PuntoPerfilYZ>();

                    p = new PuntoPerfilYZ(
                        v.Y + (dy / len) * offset,
                        v.Z + (dz / len) * offset);
                }

                resultado.Add(p);
            }

            resultado = LimpiarVerticesColinealesPerfilYZ(resultado);

            if (resultado == null || resultado.Count < 4)
                return new List<PuntoPerfilYZ>();

            // Seguridad: si el offset generó un polígono degenerado, no se usa.
            double area = Math.Abs(CalcularAreaPoligonoPerfilYZ(resultado));
            double areaMinima = UnitUtils.ConvertToInternalUnits(4.0, UnitTypeId.Centimeters);
            areaMinima = areaMinima * areaMinima;

            if (area <= areaMinima)
                return new List<PuntoPerfilYZ>();

            return resultado;
        }

        private List<PuntoPerfilYZ> LimpiarVerticesColinealesPerfilYZ(
            List<PuntoPerfilYZ> puntos)
        {
            List<PuntoPerfilYZ> pts = DepurarPuntosPerfilYZ(puntos);

            if (pts == null || pts.Count <= 3)
                return pts ?? new List<PuntoPerfilYZ>();

            double toleranciaColineal = UnitUtils.ConvertToInternalUnits(
                0.15,
                UnitTypeId.Centimeters);

            bool cambio = true;
            int guardia = 0;

            while (cambio && guardia < 20 && pts.Count > 3)
            {
                cambio = false;
                guardia++;

                for (int i = 0; i < pts.Count; i++)
                {
                    PuntoPerfilYZ a = pts[(i - 1 + pts.Count) % pts.Count];
                    PuntoPerfilYZ b = pts[i];
                    PuntoPerfilYZ c = pts[(i + 1) % pts.Count];

                    double area2 = Math.Abs(CrossPerfilYZ(a, b, c));
                    double distAC = Math.Sqrt(
                        Math.Pow(c.Y - a.Y, 2.0) +
                        Math.Pow(c.Z - a.Z, 2.0));

                    if (distAC <= Tol)
                        continue;

                    double distancia = area2 / distAC;

                    if (distancia <= toleranciaColineal)
                    {
                        pts.RemoveAt(i);
                        cambio = true;
                        break;
                    }
                }
            }

            return pts;
        }

        private double CalcularAreaPoligonoPerfilYZ(List<PuntoPerfilYZ> puntos)
        {
            if (puntos == null || puntos.Count < 3)
                return 0.0;

            double area = 0.0;

            for (int i = 0; i < puntos.Count; i++)
            {
                PuntoPerfilYZ a = puntos[i];
                PuntoPerfilYZ b = puntos[(i + 1) % puntos.Count];

                if (a == null || b == null)
                    continue;

                area += (a.Y * b.Z) - (b.Y * a.Z);
            }

            return area / 2.0;
        }

        private List<Curve> CrearCurvasDesdeContornoPerfilYZ(
            DatosViga viga,
            XYZ centro,
            List<PuntoPerfilYZ> contorno)
        {
            List<Curve> curvas = new List<Curve>();

            if (viga == null || centro == null || contorno == null || contorno.Count < 4)
                return curvas;

            for (int i = 0; i < contorno.Count; i++)
            {
                PuntoPerfilYZ a = contorno[i];
                PuntoPerfilYZ b = contorno[(i + 1) % contorno.Count];

                if (a == null || b == null)
                    continue;

                XYZ p1 = PuntoLocalEstribo(viga, centro, a.Y, a.Z);
                XYZ p2 = PuntoLocalEstribo(viga, centro, b.Y, b.Z);

                AgregarLineaSiValida(curvas, p1, p2);
            }

            return curvas;
        }

        private List<List<Curve>> CrearCurvasEstribosCumbreraEntrelazados(
            DatosViga viga,
            XYZ centro,
            double minY,
            double maxY,
            double minZ,
            double maxZ,
            double diametroEstriboFt)
        {
            List<List<Curve>> grupos = new List<List<Curve>>();

            if (viga == null || centro == null)
                return grupos;

            double anchoY = maxY - minY;
            double peralteZ = maxZ - minZ;

            if (anchoY <= Tol || peralteZ <= Tol)
                return grupos;

            PerfilCumbreraYZ perfil = ObtenerPerfilCumbreraInterior(
                viga,
                minY,
                maxY,
                minZ,
                maxZ,
                diametroEstriboFt);

            if (perfil == null)
                return grupos;

            // =========================================================
            // CUMBRERA ENTRELazADA
            // =========================================================
            // Se crean DOS estribos independientes:
            // 1) Estribo izquierdo: lateral izquierdo + faldón superior izquierdo
            //    + pierna central izquierda + faldón inferior izquierdo.
            // 2) Estribo derecho: lateral derecho + faldón superior derecho
            //    + pierna central derecha + faldón inferior derecho.
            //
            // Las piernas centrales NO coinciden exactamente en el eje.
            // Se separan para dejar espacio al acero longitudinal de cumbrera.
            //
            // Las líneas superiores/inferiores se calculan paralelas a las caras
            // reales del sólido, usando un offset aproximado al eje del estribo
            // equivalente al recubrimiento que ya llegó como minY/maxY.
            // =========================================================

            // CLAVE: el lateral usa Y superior y Y inferior diferentes.
            // Antes se usaba un solo YIzq/YDer para ambos extremos y por eso
            // ese lado quedaba casi vertical. Ahora el segmento lateral conserva
            // la pendiente de la cara lateral calculada con offset.
            double yLiSup = perfil.TieneYLateralesDiferenciados ? perfil.YIzqTop : perfil.YIzq;
            double yLiInf = perfil.TieneYLateralesDiferenciados ? perfil.YIzqBot : perfil.YIzq;
            double yDeSup = perfil.TieneYLateralesDiferenciados ? perfil.YDerTop : perfil.YDer;
            double yDeInf = perfil.TieneYLateralesDiferenciados ? perfil.YDerBot : perfil.YDer;

            XYZ pLiSup = PuntoLocalEstribo(viga, centro, yLiSup, perfil.ZTopIzq);
            XYZ pLiInf = PuntoLocalEstribo(viga, centro, yLiInf, perfil.ZBotIzq);

            XYZ pCiSup = PuntoLocalEstribo(viga, centro, perfil.YCentroIzq, perfil.ZTopCentroIzq);
            XYZ pCiInf = PuntoLocalEstribo(viga, centro, perfil.YCentroIzq, perfil.ZBotCentroIzq);

            XYZ pCdSup = PuntoLocalEstribo(viga, centro, perfil.YCentroDer, perfil.ZTopCentroDer);
            XYZ pCdInf = PuntoLocalEstribo(viga, centro, perfil.YCentroDer, perfil.ZBotCentroDer);

            XYZ pDeSup = PuntoLocalEstribo(viga, centro, yDeSup, perfil.ZTopDer);
            XYZ pDeInf = PuntoLocalEstribo(viga, centro, yDeInf, perfil.ZBotDer);

            // Estribo izquierdo.
            // Inicio y cierre en el lateral izquierdo para que el gancho se ubique
            // en la posición lateral, no en la cumbrera.
            List<Curve> curvasIzquierda = new List<Curve>();
            AgregarLineaSiValida(curvasIzquierda, pLiSup, pCiSup); // paralelo al faldón superior izquierdo
            AgregarLineaSiValida(curvasIzquierda, pCiSup, pCiInf); // pierna central izquierda
            AgregarLineaSiValida(curvasIzquierda, pCiInf, pLiInf); // paralelo al faldón inferior izquierdo
            AgregarLineaSiValida(curvasIzquierda, pLiInf, pLiSup); // lateral izquierdo

            // Estribo derecho.
            // Inicio y cierre en el lateral derecho para que el gancho se ubique
            // en la posición lateral derecha.
            List<Curve> curvasDerecha = new List<Curve>();
            AgregarLineaSiValida(curvasDerecha, pDeSup, pCdSup); // paralelo al faldón superior derecho
            AgregarLineaSiValida(curvasDerecha, pCdSup, pCdInf); // pierna central derecha
            AgregarLineaSiValida(curvasDerecha, pCdInf, pDeInf); // paralelo al faldón inferior derecho
            AgregarLineaSiValida(curvasDerecha, pDeInf, pDeSup); // lateral derecho

            if (curvasIzquierda.Count >= 4)
                grupos.Add(curvasIzquierda);

            if (curvasDerecha.Count >= 4)
                grupos.Add(curvasDerecha);

            return grupos;
        }

        private PerfilCumbreraYZ ObtenerPerfilCumbreraInterior(
            DatosViga viga,
            double minY,
            double maxY,
            double minZ,
            double maxZ,
            double diametroEstriboFt)
        {
            if (viga == null)
                return null;

            double rawYMin = viga.YMin;
            double rawYMax = viga.YMax;
            double rawYMed = (rawYMin + rawYMax) / 2.0;
            double rawAncho = rawYMax - rawYMin;

            double rawZMin = viga.ZMin;
            double rawZMax = viga.ZMax;
            double rawPeralte = rawZMax - rawZMin;

            if (rawAncho <= Tol || rawPeralte <= Tol)
                return null;

            // Este valor es el recubrimiento AL EJE de la barra.
            // minY, maxY, minZ y maxZ ya llegan con recubrimiento + diámetro/2,
            // por eso se toma la menor distancia interior disponible.
            double recIzq = Math.Max(0.0, minY - rawYMin);
            double recDer = Math.Max(0.0, rawYMax - maxY);
            double recZInf = Math.Max(0.0, minZ - rawZMin);
            double recZSup = Math.Max(0.0, rawZMax - maxZ);

            double recubrimiento = Math.Max(
                UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Centimeters),
                new double[] { recIzq, recDer, recZInf, recZSup }
                    .Where(x => x > Tol)
                    .DefaultIfEmpty(UnitUtils.ConvertToInternalUnits(4.0, UnitTypeId.Centimeters))
                    .Min());

            List<PuntoPerfilYZ> pts = ObtenerPuntosPerfilYZ(viga);

            if (pts == null || pts.Count < 4)
                return null;

            // =========================================================
            // NUEVA LÓGICA PARA CUMBRERA
            // =========================================================
            // Antes se evaluaban Z por rangos de Y, lo cual podía tomar puntos
            // incorrectos y terminaba generando bocetos casi horizontales.
            // Ahora se identifican los vértices principales de la sección:
            // - esquina superior izquierda / derecha,
            // - cumbrera superior,
            // - esquina inferior izquierda / derecha,
            // - valle inferior central.
            // Luego se construyen líneas paralelas a esas caras y se desplazan
            // hacia adentro con el recubrimiento al eje de la barra.
            // El lado central se fuerza en el eje central de la viga.
            // =========================================================

            PuntoPerfilYZ pTopCentroRaw = ObtenerPuntoMasAltoCentro(
                pts,
                rawYMed,
                rawAncho);

            PuntoPerfilYZ pBotCentroRaw = ObtenerPuntoMasBajoCentro(
                pts,
                rawYMed,
                rawAncho);

            PuntoPerfilYZ pTopIzqRaw = ObtenerPuntoExteriorSuperior(
                pts,
                rawYMin,
                rawYMed,
                true);

            PuntoPerfilYZ pBotIzqRaw = ObtenerPuntoExteriorInferior(
                pts,
                rawYMin,
                rawYMed,
                true);

            PuntoPerfilYZ pTopDerRaw = ObtenerPuntoExteriorSuperior(
                pts,
                rawYMax,
                rawYMed,
                false);

            PuntoPerfilYZ pBotDerRaw = ObtenerPuntoExteriorInferior(
                pts,
                rawYMax,
                rawYMed,
                false);

            if (pTopCentroRaw == null || pBotCentroRaw == null ||
                pTopIzqRaw == null || pBotIzqRaw == null ||
                pTopDerRaw == null || pBotDerRaw == null)
            {
                return null;
            }

            PuntoPerfilYZ puntoReferenciaInterior = new PuntoPerfilYZ(
                rawYMed,
                (rawZMin + rawZMax) / 2.0);

            LineaPerfilYZ caraSupIzq = CrearLineaOffsetHaciaInterior(
                pTopIzqRaw,
                pTopCentroRaw,
                puntoReferenciaInterior,
                recubrimiento);

            LineaPerfilYZ caraSupDer = CrearLineaOffsetHaciaInterior(
                pTopCentroRaw,
                pTopDerRaw,
                puntoReferenciaInterior,
                recubrimiento);

            LineaPerfilYZ caraInfIzq = CrearLineaOffsetHaciaInterior(
                pBotCentroRaw,
                pBotIzqRaw,
                puntoReferenciaInterior,
                recubrimiento);

            LineaPerfilYZ caraInfDer = CrearLineaOffsetHaciaInterior(
                pBotDerRaw,
                pBotCentroRaw,
                puntoReferenciaInterior,
                recubrimiento);

            // CORRECCIÓN DE LATERALES:
            // Los laterales NO se toman como una línea vertical entre el punto más alto
            // y el más bajo del extremo, porque eso generaba el problema que marcaste.
            // Ahora se busca la arista exterior real del contorno Y-Z de la sección
            // mediante el casco convexo del sólido. Esa arista se desfasa hacia adentro
            // con el recubrimiento, por eso el lado del boceto queda paralelo a la cara
            // lateral de la viga.
            // PRIMERO se intenta obtener la cara lateral REAL del sólido.
            // Esto evita que el lateral del estribo quede vertical por usar solo puntos extremos.
            // La línea resultante viene de la ecuación del plano de la cara lateral
            // proyectada en el perfil Y-Z; luego se le aplica el offset hacia el interior.
            LineaPerfilYZ lateralIzqRaw = ObtenerLineaLateralExteriorPorCaraReal(
                viga,
                true,
                rawYMed,
                rawZMin,
                rawZMax);

            LineaPerfilYZ lateralDerRaw = ObtenerLineaLateralExteriorPorCaraReal(
                viga,
                false,
                rawYMed,
                rawZMin,
                rawZMax);

            // Respaldo: si no se pudo identificar la cara planar lateral,
            // se usa el contorno del sólido como en las versiones anteriores.
            if (lateralIzqRaw == null)
            {
                lateralIzqRaw = ObtenerLineaLateralExteriorPorHull(
                    pts,
                    rawYMed,
                    true);
            }

            if (lateralDerRaw == null)
            {
                lateralDerRaw = ObtenerLineaLateralExteriorPorHull(
                    pts,
                    rawYMed,
                    false);
            }

            if (lateralIzqRaw == null)
            {
                lateralIzqRaw = new LineaPerfilYZ(
                    pBotIzqRaw.Y,
                    pBotIzqRaw.Z,
                    pTopIzqRaw.Y,
                    pTopIzqRaw.Z);
            }

            if (lateralDerRaw == null)
            {
                lateralDerRaw = new LineaPerfilYZ(
                    pTopDerRaw.Y,
                    pTopDerRaw.Z,
                    pBotDerRaw.Y,
                    pBotDerRaw.Z);
            }

            LineaPerfilYZ caraLatIzq = CrearLineaOffsetHaciaInterior(
                lateralIzqRaw,
                puntoReferenciaInterior,
                recubrimiento);

            LineaPerfilYZ caraLatDer = CrearLineaOffsetHaciaInterior(
                lateralDerRaw,
                puntoReferenciaInterior,
                recubrimiento);

            if (caraSupIzq == null || caraSupDer == null ||
                caraInfIzq == null || caraInfDer == null ||
                caraLatIzq == null || caraLatDer == null)
            {
                return null;
            }

            double yCentro = rawYMed;

            // Seguridad para que el eje central base esté dentro del rango interior.
            yCentro = Math.Max(minY, Math.Min(maxY, yCentro));

            // =========================================================
            // ENTRELACE CENTRAL CON ESPACIO LIBRE REAL DE 3/4"
            // =========================================================
            // El offset NO debe partir del centro de la barra solamente.
            // Para que entre las caras exteriores de ambos estribos quede
            // un espacio libre de 3/4", la separación centro a centro debe ser:
            //
            //     3/4" + diámetro del estribo
            //
            // Por lo tanto, cada pierna central se aleja/cruza desde el eje en:
            //
            //     3/8" + diámetro/2
            //
            // Se mantiene el cruce:
            // - Estribo izquierdo pasa al lado derecho del eje.
            // - Estribo derecho pasa al lado izquierdo del eje.
            // =========================================================
            double medioEspacioLibreFt = UnitUtils.ConvertToInternalUnits(
                OFFSET_ENTRELAZADO_CENTRAL_IN,
                UnitTypeId.Inches);

            double medioDiametroEstriboFt = Math.Max(0.0, diametroEstriboFt) / 2.0;

            double offsetCentralEntrelazado = medioEspacioLibreFt + medioDiametroEstriboFt;

            double yCentroIzq = yCentro + offsetCentralEntrelazado;
            double yCentroDer = yCentro - offsetCentralEntrelazado;

            // Evita que el offset salga fuera del recubrimiento interior.
            yCentroIzq = Math.Max(minY, Math.Min(maxY, yCentroIzq));
            yCentroDer = Math.Max(minY, Math.Min(maxY, yCentroDer));

            // IMPORTANTE:
            // Aquí NO se corrige el orden yCentroDer <= yCentroIzq, porque
            // precisamente esa inversión es la que hace que los dos estribos
            // queden cruzados/entrelazados en la cumbrera.

            PuntoPerfilYZ pLiSup = IntersecarLineasPerfil(
                caraLatIzq,
                caraSupIzq);

            PuntoPerfilYZ pLiInf = IntersecarLineasPerfil(
                caraLatIzq,
                caraInfIzq);

            PuntoPerfilYZ pDeSup = IntersecarLineasPerfil(
                caraLatDer,
                caraSupDer);

            PuntoPerfilYZ pDeInf = IntersecarLineasPerfil(
                caraLatDer,
                caraInfDer);

            double zTopCentroIzq = ObtenerZEnYDeLinea(
                caraSupIzq,
                yCentroIzq);

            double zBotCentroIzq = ObtenerZEnYDeLinea(
                caraInfIzq,
                yCentroIzq);

            double zTopCentroDer = ObtenerZEnYDeLinea(
                caraSupDer,
                yCentroDer);

            double zBotCentroDer = ObtenerZEnYDeLinea(
                caraInfDer,
                yCentroDer);

            if (pLiSup == null)
                pLiSup = new PuntoPerfilYZ(minY, ObtenerZEnYDeLinea(caraSupIzq, minY));

            if (pLiInf == null)
                pLiInf = new PuntoPerfilYZ(minY, ObtenerZEnYDeLinea(caraInfIzq, minY));

            if (pDeSup == null)
                pDeSup = new PuntoPerfilYZ(maxY, ObtenerZEnYDeLinea(caraSupDer, maxY));

            if (pDeInf == null)
                pDeInf = new PuntoPerfilYZ(maxY, ObtenerZEnYDeLinea(caraInfDer, maxY));

            PerfilCumbreraYZ perfil = new PerfilCumbreraYZ();

            // CLAVE: guardar Y superior e inferior por separado.
            // Esto mantiene el lado lateral paralelo a la cara inclinada de la viga.
            perfil.TieneYLateralesDiferenciados = true;

            perfil.YIzqTop = pLiSup.Y;
            perfil.YIzqBot = pLiInf.Y;
            perfil.YDerTop = pDeSup.Y;
            perfil.YDerBot = pDeInf.Y;

            // Respaldo para compatibilidad interna.
            perfil.YIzq = (pLiSup.Y + pLiInf.Y) / 2.0;
            perfil.YDer = (pDeSup.Y + pDeInf.Y) / 2.0;

            // Cada estribo cruza el eje central con:
            // 3/8" + diámetro/2.
            // Así entre las CARAS EXTERIORES de los dos estribos queda
            // 3/4" de espacio libre, pero en posición invertida para que
            // se entrelacen.
            perfil.YCentroIzq = yCentroIzq;
            perfil.YCentroDer = yCentroDer;

            perfil.ZTopIzq = pLiSup.Z;
            perfil.ZTopCentroIzq = zTopCentroIzq;
            perfil.ZTopCentroDer = zTopCentroDer;
            perfil.ZTopDer = pDeSup.Z;

            perfil.ZBotIzq = pLiInf.Z;
            perfil.ZBotCentroIzq = zBotCentroIzq;
            perfil.ZBotCentroDer = zBotCentroDer;
            perfil.ZBotDer = pDeInf.Z;

            // Seguridad: evita inversión local en vigas muy delgadas o geometrías raras.
            double separacionVerticalMin = UnitUtils.ConvertToInternalUnits(
                4.0,
                UnitTypeId.Centimeters);

            CorregirAlturasPerfilCumbrera(
                perfil,
                minZ,
                maxZ,
                separacionVerticalMin);

            return perfil;
        }

        private List<PuntoPerfilYZ> ObtenerPuntosPerfilYZ(DatosViga viga)
        {
            List<PuntoPerfilYZ> resultado = new List<PuntoPerfilYZ>();

            if (viga == null || viga.PuntosSolidoGlobal == null)
                return resultado;

            foreach (XYZ p in viga.PuntosSolidoGlobal)
            {
                if (p == null)
                    continue;

                double y = (p - viga.P0).DotProduct(viga.YAxis);
                double z = (p - viga.P0).DotProduct(viga.ZAxis);

                resultado.Add(new PuntoPerfilYZ(y, z));
            }

            return resultado;
        }

        private double MaxZCercaDeY(
            List<PuntoPerfilYZ> puntos,
            double yObjetivo,
            double toleranciaY,
            double fallback)
        {
            if (puntos == null || puntos.Count == 0)
                return fallback;

            List<PuntoPerfilYZ> candidatos = puntos
                .Where(p => p != null && Math.Abs(p.Y - yObjetivo) <= toleranciaY)
                .ToList();

            if (candidatos.Count == 0)
            {
                candidatos = puntos
                    .OrderBy(p => Math.Abs(p.Y - yObjetivo))
                    .Take(6)
                    .ToList();
            }

            if (candidatos.Count == 0)
                return fallback;

            return candidatos.Max(p => p.Z);
        }

        private double MinZCercaDeY(
            List<PuntoPerfilYZ> puntos,
            double yObjetivo,
            double toleranciaY,
            double fallback)
        {
            if (puntos == null || puntos.Count == 0)
                return fallback;

            List<PuntoPerfilYZ> candidatos = puntos
                .Where(p => p != null && Math.Abs(p.Y - yObjetivo) <= toleranciaY)
                .ToList();

            if (candidatos.Count == 0)
            {
                candidatos = puntos
                    .OrderBy(p => Math.Abs(p.Y - yObjetivo))
                    .Take(6)
                    .ToList();
            }

            if (candidatos.Count == 0)
                return fallback;

            return candidatos.Min(p => p.Z);
        }

        private double EvaluarLineaOffsetParalela(
            double y1,
            double z1,
            double y2,
            double z2,
            double y,
            double offset,
            bool offsetHaciaArriba)
        {
            if (Math.Abs(y2 - y1) <= Tol)
                return offsetHaciaArriba ? z1 + offset : z1 - offset;

            double m = (z2 - z1) / (y2 - y1);
            double z = z1 + m * (y - y1);

            // Distancia vertical equivalente para mantener una línea paralela
            // a una distancia aproximada igual al recubrimiento.
            double dzOffset = offset * Math.Sqrt(1.0 + m * m);

            return offsetHaciaArriba
                ? z + dzOffset
                : z - dzOffset;
        }

        private PuntoPerfilYZ ObtenerPuntoMasAltoCentro(
            List<PuntoPerfilYZ> puntos,
            double yCentro,
            double ancho)
        {
            if (puntos == null || puntos.Count == 0)
                return null;

            double margenCentro = Math.Max(
                UnitUtils.ConvertToInternalUnits(4.0, UnitTypeId.Centimeters),
                ancho * 0.20);

            List<PuntoPerfilYZ> candidatos = puntos
                .Where(p => p != null && Math.Abs(p.Y - yCentro) <= margenCentro)
                .ToList();

            if (candidatos.Count == 0)
                candidatos = puntos;

            return candidatos
                .OrderByDescending(p => p.Z)
                .ThenBy(p => Math.Abs(p.Y - yCentro))
                .FirstOrDefault();
        }

        private PuntoPerfilYZ ObtenerPuntoMasBajoCentro(
            List<PuntoPerfilYZ> puntos,
            double yCentro,
            double ancho)
        {
            if (puntos == null || puntos.Count == 0)
                return null;

            double margenCentro = Math.Max(
                UnitUtils.ConvertToInternalUnits(4.0, UnitTypeId.Centimeters),
                ancho * 0.20);

            List<PuntoPerfilYZ> candidatos = puntos
                .Where(p => p != null && Math.Abs(p.Y - yCentro) <= margenCentro)
                .ToList();

            if (candidatos.Count == 0)
                candidatos = puntos;

            return candidatos
                .OrderBy(p => p.Z)
                .ThenBy(p => Math.Abs(p.Y - yCentro))
                .FirstOrDefault();
        }

        private PuntoPerfilYZ ObtenerPuntoExteriorSuperior(
            List<PuntoPerfilYZ> puntos,
            double yExterior,
            double yCentro,
            bool ladoIzquierdo)
        {
            if (puntos == null || puntos.Count == 0)
                return null;

            double ancho = Math.Abs((yCentro - yExterior) * 2.0);
            double franjaExterior = Math.Max(
                UnitUtils.ConvertToInternalUnits(6.0, UnitTypeId.Centimeters),
                ancho * 0.28);

            List<PuntoPerfilYZ> candidatos = puntos
                .Where(p => p != null && Math.Abs(p.Y - yExterior) <= franjaExterior)
                .ToList();

            if (candidatos.Count == 0)
            {
                candidatos = puntos
                    .Where(p => p != null && (ladoIzquierdo ? p.Y <= yCentro : p.Y >= yCentro))
                    .ToList();
            }

            if (candidatos.Count == 0)
                candidatos = puntos;

            return candidatos
                .OrderByDescending(p => p.Z)
                .ThenBy(p => Math.Abs(p.Y - yExterior))
                .FirstOrDefault();
        }

        private PuntoPerfilYZ ObtenerPuntoExteriorInferior(
            List<PuntoPerfilYZ> puntos,
            double yExterior,
            double yCentro,
            bool ladoIzquierdo)
        {
            if (puntos == null || puntos.Count == 0)
                return null;

            double ancho = Math.Abs((yCentro - yExterior) * 2.0);
            double franjaExterior = Math.Max(
                UnitUtils.ConvertToInternalUnits(6.0, UnitTypeId.Centimeters),
                ancho * 0.28);

            List<PuntoPerfilYZ> candidatos = puntos
                .Where(p => p != null && Math.Abs(p.Y - yExterior) <= franjaExterior)
                .ToList();

            if (candidatos.Count == 0)
            {
                candidatos = puntos
                    .Where(p => p != null && (ladoIzquierdo ? p.Y <= yCentro : p.Y >= yCentro))
                    .ToList();
            }

            if (candidatos.Count == 0)
                candidatos = puntos;

            return candidatos
                .OrderBy(p => p.Z)
                .ThenBy(p => Math.Abs(p.Y - yExterior))
                .FirstOrDefault();
        }

        private LineaPerfilYZ ObtenerLineaLateralExteriorPorCaraReal(
            DatosViga viga,
            bool ladoIzquierdo,
            double yCentro,
            double zMin,
            double zMax)
        {
            if (viga == null || viga.Elemento == null)
                return null;

            List<CaraPerfilYZ> caras = ObtenerCarasPerfilYZDesdeSolido(viga);

            if (caras == null || caras.Count == 0)
                return null;

            double peralte = zMax - zMin;

            if (peralte <= Tol)
                return null;

            CaraPerfilYZ mejor = null;
            double mejorNY = 0.0;
            double mejorNZ = 0.0;
            double mejorC = 0.0;
            double mejorScore = double.MinValue;

            foreach (CaraPerfilYZ cara in caras)
            {
                if (cara == null)
                    continue;

                double ny = cara.NY;
                double nz = cara.NZ;
                double c = cara.C;

                double len = Math.Sqrt(ny * ny + nz * nz);

                if (len <= Tol)
                    continue;

                ny /= len;
                nz /= len;
                c /= len;

                // Forzar que la normal 2D mire hacia el exterior del lado evaluado.
                if (ladoIzquierdo && ny > 0.0)
                {
                    ny *= -1.0;
                    nz *= -1.0;
                    c *= -1.0;
                }
                else if (!ladoIzquierdo && ny < 0.0)
                {
                    ny *= -1.0;
                    nz *= -1.0;
                    c *= -1.0;
                }

                // La cara lateral debe tener componente horizontal clara.
                // Las caras superior e inferior de la cumbrera tienen normalmente NZ dominante,
                // por eso aquí se descartan.
                double componenteHorizontal = Math.Abs(ny);
                double componenteVertical = Math.Abs(nz);

                if (componenteHorizontal < 0.20)
                    continue;

                if (componenteHorizontal < componenteVertical * 0.35)
                    continue;

                double exterioridad = ladoIzquierdo
                    ? yCentro - cara.YMed
                    : cara.YMed - yCentro;

                if (exterioridad <= 0.0)
                    continue;

                double recorridoZ = Math.Abs(cara.ZMax - cara.ZMin);

                if (recorridoZ < peralte * 0.20)
                    continue;

                double sideDominance = componenteHorizontal / (componenteHorizontal + componenteVertical + Tol);
                double coberturaZ = Math.Min(1.0, recorridoZ / peralte);

                // Puntaje: prioriza la cara más exterior, con normal de lateral
                // y con recorrido vertical suficiente. Esto evita agarrar los faldones.
                double score =
                    exterioridad * 12.0 +
                    sideDominance * 5.0 +
                    coberturaZ * 4.0 +
                    Math.Min(cara.Area, peralte * peralte) / Math.Max(peralte * peralte, Tol);

                if (score > mejorScore)
                {
                    mejorScore = score;
                    mejor = cara;
                    mejorNY = ny;
                    mejorNZ = nz;
                    mejorC = c;
                }
            }

            if (mejor == null)
                return null;

            if (Math.Abs(mejorNY) <= Tol)
                return null;

            // Se usa una línea larga de la misma cara lateral real.
            // Luego se intersecta con los faldones superior/inferior ya desfasados.
            double margen = Math.Max(
                UnitUtils.ConvertToInternalUnits(2.0, UnitTypeId.Centimeters),
                peralte * 0.08);

            double z1 = zMin + margen;
            double z2 = zMax - margen;

            if (z2 <= z1 + Tol)
            {
                z1 = zMin;
                z2 = zMax;
            }

            double y1 = -(mejorNZ * z1 + mejorC) / mejorNY;
            double y2 = -(mejorNZ * z2 + mejorC) / mejorNY;

            // Seguridad: si por geometría rara la línea quedó al lado incorrecto,
            // se descarta y se deja que actúe el método por hull.
            double yMedLinea = (y1 + y2) / 2.0;

            if (ladoIzquierdo && yMedLinea > yCentro)
                return null;

            if (!ladoIzquierdo && yMedLinea < yCentro)
                return null;

            return new LineaPerfilYZ(y1, z1, y2, z2);
        }

        private List<CaraPerfilYZ> ObtenerCarasPerfilYZDesdeSolido(DatosViga viga)
        {
            List<CaraPerfilYZ> caras = new List<CaraPerfilYZ>();

            if (viga == null || viga.Elemento == null)
                return caras;

            Options opt = new Options();
            opt.DetailLevel = ViewDetailLevel.Fine;
            opt.IncludeNonVisibleObjects = false;
            opt.ComputeReferences = false;

            GeometryElement geo = null;

            try
            {
                geo = viga.Elemento.get_Geometry(opt);
            }
            catch
            {
                geo = null;
            }

            if (geo == null)
                return caras;

            RecolectarCarasPerfilYZGeometria(
                geo,
                Transform.Identity,
                viga,
                caras);

            return caras;
        }

        private void RecolectarCarasPerfilYZGeometria(
            GeometryElement geo,
            Transform transform,
            DatosViga viga,
            List<CaraPerfilYZ> caras)
        {
            if (geo == null || viga == null || caras == null)
                return;

            foreach (GeometryObject obj in geo)
            {
                if (obj == null)
                    continue;

                Solid solid = obj as Solid;

                if (solid != null)
                {
                    RecolectarCarasPerfilYZSolido(
                        solid,
                        transform,
                        viga,
                        caras);

                    continue;
                }

                GeometryInstance gi = obj as GeometryInstance;

                if (gi != null)
                {
                    bool procesado = false;

                    try
                    {
                        GeometryElement geoInst = gi.GetInstanceGeometry();

                        if (geoInst != null)
                        {
                            // GetInstanceGeometry normalmente ya viene en coordenadas de modelo.
                            RecolectarCarasPerfilYZGeometria(
                                geoInst,
                                Transform.Identity,
                                viga,
                                caras);

                            procesado = true;
                        }
                    }
                    catch
                    {
                        procesado = false;
                    }

                    if (procesado)
                        continue;

                    try
                    {
                        GeometryElement geoSym = gi.GetSymbolGeometry();

                        if (geoSym != null)
                        {
                            Transform t2 = transform;

                            try
                            {
                                t2 = transform.Multiply(gi.Transform);
                            }
                            catch
                            {
                                t2 = gi.Transform;
                            }

                            RecolectarCarasPerfilYZGeometria(
                                geoSym,
                                t2,
                                viga,
                                caras);
                        }
                    }
                    catch
                    {
                    }
                }
            }
        }

        private void RecolectarCarasPerfilYZSolido(
            Solid solid,
            Transform transform,
            DatosViga viga,
            List<CaraPerfilYZ> caras)
        {
            if (solid == null || viga == null || caras == null)
                return;

            try
            {
                if (solid.Volume <= Tol)
                    return;
            }
            catch
            {
            }

            foreach (Face f in solid.Faces)
            {
                PlanarFace pf = f as PlanarFace;

                if (pf == null)
                    continue;

                XYZ normal = pf.FaceNormal;

                if (normal == null || normal.GetLength() <= Tol)
                    continue;

                try
                {
                    if (transform != null && !transform.IsIdentity)
                        normal = transform.OfVector(normal);
                }
                catch
                {
                }

                if (normal == null || normal.GetLength() <= Tol)
                    continue;

                normal = normal.Normalize();

                double nX = normal.DotProduct(viga.XAxis);
                double nY = normal.DotProduct(viga.YAxis);
                double nZ = normal.DotProduct(viga.ZAxis);

                // Las caras extremas de la viga tienen normal casi paralela al eje X.
                // No sirven para definir el contorno del estribo.
                if (Math.Abs(nX) > 0.35)
                    continue;

                double lenYZ = Math.Sqrt(nY * nY + nZ * nZ);

                if (lenYZ <= Tol)
                    continue;

                nY /= lenYZ;
                nZ /= lenYZ;

                List<XYZ> vertices = ObtenerVerticesCaraPlanar(
                    pf,
                    transform);

                if (vertices == null || vertices.Count < 2)
                    continue;

                double yMin = double.MaxValue;
                double yMax = double.MinValue;
                double zMin = double.MaxValue;
                double zMax = double.MinValue;
                double ySum = 0.0;
                double zSum = 0.0;
                int n = 0;

                foreach (XYZ p in vertices)
                {
                    if (p == null)
                        continue;

                    double y = (p - viga.P0).DotProduct(viga.YAxis);
                    double z = (p - viga.P0).DotProduct(viga.ZAxis);

                    if (y < yMin) yMin = y;
                    if (y > yMax) yMax = y;
                    if (z < zMin) zMin = z;
                    if (z > zMax) zMax = z;

                    ySum += y;
                    zSum += z;
                    n++;
                }

                if (n <= 0)
                    continue;

                double yMed = ySum / n;
                double zMed = zSum / n;

                double c = -(nY * yMed + nZ * zMed);

                CaraPerfilYZ cara = new CaraPerfilYZ();
                cara.NY = nY;
                cara.NZ = nZ;
                cara.C = c;
                cara.YMin = yMin;
                cara.YMax = yMax;
                cara.ZMin = zMin;
                cara.ZMax = zMax;
                cara.YMed = yMed;
                cara.ZMed = zMed;

                try
                {
                    cara.Area = pf.Area;
                }
                catch
                {
                    cara.Area = 0.0;
                }

                caras.Add(cara);
            }
        }

        private List<XYZ> ObtenerVerticesCaraPlanar(
            PlanarFace face,
            Transform transform)
        {
            List<XYZ> vertices = new List<XYZ>();

            if (face == null)
                return vertices;

            try
            {
                foreach (EdgeArray edgeArray in face.EdgeLoops)
                {
                    if (edgeArray == null)
                        continue;

                    foreach (Edge edge in edgeArray)
                    {
                        if (edge == null)
                            continue;

                        Curve c = null;

                        try
                        {
                            c = edge.AsCurve();
                        }
                        catch
                        {
                            c = null;
                        }

                        if (c == null)
                            continue;

                        try
                        {
                            XYZ p0 = c.GetEndPoint(0);
                            XYZ p1 = c.GetEndPoint(1);

                            if (transform != null && !transform.IsIdentity)
                            {
                                p0 = transform.OfPoint(p0);
                                p1 = transform.OfPoint(p1);
                            }

                            vertices.Add(p0);
                            vertices.Add(p1);
                        }
                        catch
                        {
                        }
                    }
                }
            }
            catch
            {
            }

            return vertices;
        }

        private LineaPerfilYZ ObtenerLineaLateralExteriorPorHull(
            List<PuntoPerfilYZ> puntos,
            double yCentro,
            bool ladoIzquierdo)
        {
            if (puntos == null || puntos.Count < 3)
                return null;

            List<PuntoPerfilYZ> hull = ConstruirHullPerfilYZ(puntos);

            if (hull == null || hull.Count < 3)
                return null;

            double yMin = hull.Min(p => p.Y);
            double yMax = hull.Max(p => p.Y);
            double zMin = hull.Min(p => p.Z);
            double zMax = hull.Max(p => p.Z);

            double ancho = yMax - yMin;
            double peralte = zMax - zMin;

            if (ancho <= Tol || peralte <= Tol)
                return null;

            // =========================================================
            // CORRECCIÓN FINAL DE LATERALES CUMBRERA
            // =========================================================
            // El problema anterior era que una sola arista del hull podía ser
            // tomada desde un vértice equivocado y el lado del boceto quedaba
            // casi vertical. Ahora se calcula primero la ENVOLVENTE EXTERIOR
            // del sólido: se muestrean las aristas del casco y, para cada nivel Z,
            // se toma el punto más exterior en Y. Con esos puntos se ajusta una
            // recta Y=f(Z). Esa recta representa la cara lateral real, por lo que
            // al aplicarle offset el boceto queda PARALELO a la cara inclinada.
            // =========================================================
            LineaPerfilYZ lineaEnvolvente = ObtenerLineaLateralPorEnvolventeExterior(
                hull,
                yCentro,
                ladoIzquierdo);

            if (lineaEnvolvente != null)
                return lineaEnvolvente;

            LineaPerfilYZ mejor = null;
            double mejorScore = double.MinValue;

            // Respaldo 1: busca una arista lateral real del casco convexo.
            // Ahora el puntaje prioriza la exterioridad y que el segmento recorra
            // altura suficiente, no solo la verticalidad.
            mejor = BuscarMejorAristaLateralHull(
                hull,
                yCentro,
                ancho,
                peralte,
                ladoIzquierdo,
                0.12,
                0.22,
                out mejorScore);

            if (mejor != null)
                return mejor;

            // Respaldo 2 más permisivo para familias con pocos vértices.
            mejor = BuscarMejorAristaLateralHull(
                hull,
                yCentro,
                ancho,
                peralte,
                ladoIzquierdo,
                0.05,
                0.12,
                out mejorScore);

            return mejor;
        }

        private LineaPerfilYZ ObtenerLineaLateralPorEnvolventeExterior(
            List<PuntoPerfilYZ> hull,
            double yCentro,
            bool ladoIzquierdo)
        {
            if (hull == null || hull.Count < 3)
                return null;

            double yMin = hull.Min(p => p.Y);
            double yMax = hull.Max(p => p.Y);
            double zMin = hull.Min(p => p.Z);
            double zMax = hull.Max(p => p.Z);

            double ancho = yMax - yMin;
            double peralte = zMax - zMin;

            if (ancho <= Tol || peralte <= Tol)
                return null;

            // Muestrea todas las aristas del hull para reconstruir la envolvente.
            List<PuntoPerfilYZ> muestras = new List<PuntoPerfilYZ>();

            for (int i = 0; i < hull.Count; i++)
            {
                PuntoPerfilYZ a = hull[i];
                PuntoPerfilYZ b = hull[(i + 1) % hull.Count];

                if (a == null || b == null)
                    continue;

                double dy = b.Y - a.Y;
                double dz = b.Z - a.Z;
                double len = Math.Sqrt(dy * dy + dz * dz);

                if (len <= Tol)
                    continue;

                int pasos = Math.Max(4, Math.Min(24, (int)Math.Ceiling(len / Math.Max(peralte, ancho) * 24.0)));

                for (int j = 0; j <= pasos; j++)
                {
                    double t = (double)j / (double)pasos;
                    double y = a.Y + dy * t;
                    double z = a.Z + dz * t;

                    if (ladoIzquierdo && y > yCentro + ancho * 0.08)
                        continue;

                    if (!ladoIzquierdo && y < yCentro - ancho * 0.08)
                        continue;

                    muestras.Add(new PuntoPerfilYZ(y, z));
                }
            }

            if (muestras.Count < 2)
                return null;

            // Se evita la cumbrera extrema y el valle extremo para que el ajuste
            // no tome los faldones superior/inferior como si fueran el lateral.
            double zBajo = zMin + peralte * 0.10;
            double zAlto = zMax - peralte * 0.10;

            if (zAlto <= zBajo + Tol)
            {
                zBajo = zMin;
                zAlto = zMax;
            }

            int cantidadFranjas = 10;
            List<PuntoPerfilYZ> envolvente = new List<PuntoPerfilYZ>();

            for (int i = 0; i < cantidadFranjas; i++)
            {
                double z0 = zBajo + (zAlto - zBajo) * i / cantidadFranjas;
                double z1 = zBajo + (zAlto - zBajo) * (i + 1) / cantidadFranjas;

                List<PuntoPerfilYZ> franja = muestras
                    .Where(p => p != null && p.Z >= z0 - Tol && p.Z <= z1 + Tol)
                    .ToList();

                if (franja.Count == 0)
                    continue;

                PuntoPerfilYZ elegido = ladoIzquierdo
                    ? franja.OrderBy(p => p.Y).FirstOrDefault()
                    : franja.OrderByDescending(p => p.Y).FirstOrDefault();

                if (elegido != null)
                    envolvente.Add(elegido);
            }

            // Si hay pocos puntos, usa las muestras más exteriores disponibles.
            if (envolvente.Count < 2)
            {
                envolvente = ladoIzquierdo
                    ? muestras.OrderBy(p => p.Y).Take(6).ToList()
                    : muestras.OrderByDescending(p => p.Y).Take(6).ToList();
            }

            if (envolvente.Count < 2)
                return null;

            // Ajuste por mínimos cuadrados de Y = aZ + b.
            double sumaZ = 0.0;
            double sumaY = 0.0;
            double sumaZZ = 0.0;
            double sumaZY = 0.0;
            int n = 0;

            foreach (PuntoPerfilYZ p in envolvente)
            {
                if (p == null)
                    continue;

                sumaZ += p.Z;
                sumaY += p.Y;
                sumaZZ += p.Z * p.Z;
                sumaZY += p.Z * p.Y;
                n++;
            }

            if (n < 2)
                return null;

            double den = n * sumaZZ - sumaZ * sumaZ;

            if (Math.Abs(den) <= Tol)
                return null;

            double aPendiente = (n * sumaZY - sumaZ * sumaY) / den;
            double bInterseccion = (sumaY - aPendiente * sumaZ) / n;

            double z1Linea = zBajo;
            double z2Linea = zAlto;

            double y1Linea = aPendiente * z1Linea + bInterseccion;
            double y2Linea = aPendiente * z2Linea + bInterseccion;

            // Control de seguridad: la línea ajustada debe quedar en el lado correcto
            // y con una pendiente razonable respecto a los puntos exteriores.
            double yMedLinea = (y1Linea + y2Linea) / 2.0;

            if (ladoIzquierdo && yMedLinea > yCentro)
                return null;

            if (!ladoIzquierdo && yMedLinea < yCentro)
                return null;

            double recorridoY = Math.Abs(y2Linea - y1Linea);
            double recorridoZ = Math.Abs(z2Linea - z1Linea);

            if (recorridoZ <= Tol)
                return null;

            // Si la recta sale excesivamente acostada, probablemente agarró un faldón.
            if (recorridoY > ancho * 0.90)
                return null;

            return new LineaPerfilYZ(
                y1Linea,
                z1Linea,
                y2Linea,
                z2Linea);
        }

        private LineaPerfilYZ BuscarMejorAristaLateralHull(
            List<PuntoPerfilYZ> hull,
            double yCentro,
            double ancho,
            double peralte,
            bool ladoIzquierdo,
            double verticalidadMinima,
            double proporcionZMinima,
            out double mejorScore)
        {
            mejorScore = double.MinValue;

            if (hull == null || hull.Count < 2)
                return null;

            LineaPerfilYZ mejor = null;

            for (int i = 0; i < hull.Count; i++)
            {
                PuntoPerfilYZ a = hull[i];
                PuntoPerfilYZ b = hull[(i + 1) % hull.Count];

                if (a == null || b == null)
                    continue;

                double dy = b.Y - a.Y;
                double dz = b.Z - a.Z;
                double len = Math.Sqrt(dy * dy + dz * dz);

                if (len <= Tol)
                    continue;

                double midY = (a.Y + b.Y) / 2.0;

                if (ladoIzquierdo && midY > yCentro)
                    continue;

                if (!ladoIzquierdo && midY < yCentro)
                    continue;

                double verticalidad = Math.Abs(dz) / len;
                double proporcionZ = Math.Abs(dz) / peralte;

                // Evita agarrar los faldones superior/inferior como si fueran laterales.
                if (verticalidad < verticalidadMinima)
                    continue;

                if (proporcionZ < proporcionZMinima)
                    continue;

                double exterioridad = ladoIzquierdo
                    ? (yCentro - midY) / ancho
                    : (midY - yCentro) / ancho;

                if (exterioridad < -0.02)
                    continue;

                // Se prioriza que la arista esté al exterior, tenga recorrido vertical
                // y sea lo suficientemente larga. Esto permite tomar la cara lateral real.
                double score =
                    exterioridad * 8.0 +
                    verticalidad * 3.0 +
                    proporcionZ * 3.0 +
                    (len / Math.Max(ancho, peralte));

                if (score > mejorScore)
                {
                    mejorScore = score;
                    mejor = new LineaPerfilYZ(
                        a.Y,
                        a.Z,
                        b.Y,
                        b.Z);
                }
            }

            return mejor;
        }

        private List<PuntoPerfilYZ> ConstruirHullPerfilYZ(
            List<PuntoPerfilYZ> puntos)
        {
            List<PuntoPerfilYZ> pts = DepurarPuntosPerfilYZ(puntos);

            if (pts.Count <= 1)
                return pts;

            pts = pts
                .OrderBy(p => p.Y)
                .ThenBy(p => p.Z)
                .ToList();

            List<PuntoPerfilYZ> lower = new List<PuntoPerfilYZ>();

            foreach (PuntoPerfilYZ p in pts)
            {
                while (lower.Count >= 2 &&
                       CrossPerfilYZ(
                           lower[lower.Count - 2],
                           lower[lower.Count - 1],
                           p) <= Tol)
                {
                    lower.RemoveAt(lower.Count - 1);
                }

                lower.Add(p);
            }

            List<PuntoPerfilYZ> upper = new List<PuntoPerfilYZ>();

            for (int i = pts.Count - 1; i >= 0; i--)
            {
                PuntoPerfilYZ p = pts[i];

                while (upper.Count >= 2 &&
                       CrossPerfilYZ(
                           upper[upper.Count - 2],
                           upper[upper.Count - 1],
                           p) <= Tol)
                {
                    upper.RemoveAt(upper.Count - 1);
                }

                upper.Add(p);
            }

            if (lower.Count > 0)
                lower.RemoveAt(lower.Count - 1);

            if (upper.Count > 0)
                upper.RemoveAt(upper.Count - 1);

            lower.AddRange(upper);

            return lower;
        }

        private List<PuntoPerfilYZ> DepurarPuntosPerfilYZ(
            List<PuntoPerfilYZ> puntos)
        {
            List<PuntoPerfilYZ> resultado = new List<PuntoPerfilYZ>();

            if (puntos == null)
                return resultado;

            double tolPunto = UnitUtils.ConvertToInternalUnits(
                0.2,
                UnitTypeId.Centimeters);

            foreach (PuntoPerfilYZ p in puntos)
            {
                if (p == null)
                    continue;

                bool existe = resultado.Any(q =>
                    Math.Abs(q.Y - p.Y) <= tolPunto &&
                    Math.Abs(q.Z - p.Z) <= tolPunto);

                if (!existe)
                    resultado.Add(new PuntoPerfilYZ(p.Y, p.Z));
            }

            return resultado;
        }

        private double CrossPerfilYZ(
            PuntoPerfilYZ a,
            PuntoPerfilYZ b,
            PuntoPerfilYZ c)
        {
            if (a == null || b == null || c == null)
                return 0.0;

            return
                (b.Y - a.Y) * (c.Z - a.Z) -
                (b.Z - a.Z) * (c.Y - a.Y);
        }

        private LineaPerfilYZ CrearLineaOffsetHaciaInterior(
            LineaPerfilYZ linea,
            PuntoPerfilYZ puntoInterior,
            double offset)
        {
            if (linea == null || puntoInterior == null)
                return null;

            PuntoPerfilYZ p1 = new PuntoPerfilYZ(linea.Y1, linea.Z1);
            PuntoPerfilYZ p2 = new PuntoPerfilYZ(linea.Y2, linea.Z2);

            return CrearLineaOffsetHaciaInterior(
                p1,
                p2,
                puntoInterior,
                offset);
        }

        private LineaPerfilYZ CrearLineaOffsetHaciaInterior(
            PuntoPerfilYZ p1,
            PuntoPerfilYZ p2,
            PuntoPerfilYZ puntoInterior,
            double offset)
        {
            if (p1 == null || p2 == null || puntoInterior == null)
                return null;

            double vy = p2.Y - p1.Y;
            double vz = p2.Z - p1.Z;
            double len = Math.Sqrt(vy * vy + vz * vz);

            if (len <= Tol)
                return null;

            double ny = -vz / len;
            double nz = vy / len;

            LineaPerfilYZ l1 = new LineaPerfilYZ(
                p1.Y + ny * offset,
                p1.Z + nz * offset,
                p2.Y + ny * offset,
                p2.Z + nz * offset);

            LineaPerfilYZ l2 = new LineaPerfilYZ(
                p1.Y - ny * offset,
                p1.Z - nz * offset,
                p2.Y - ny * offset,
                p2.Z - nz * offset);

            double d1 = DistanciaPuntoLineaAbs(
                puntoInterior,
                l1);

            double d2 = DistanciaPuntoLineaAbs(
                puntoInterior,
                l2);

            return d1 <= d2 ? l1 : l2;
        }

        private double DistanciaPuntoLineaAbs(
            PuntoPerfilYZ p,
            LineaPerfilYZ l)
        {
            if (p == null || l == null)
                return double.MaxValue;

            double vy = l.Y2 - l.Y1;
            double vz = l.Z2 - l.Z1;
            double len = Math.Sqrt(vy * vy + vz * vz);

            if (len <= Tol)
                return double.MaxValue;

            double dy = p.Y - l.Y1;
            double dz = p.Z - l.Z1;

            return Math.Abs(vy * dz - vz * dy) / len;
        }

        private PuntoPerfilYZ IntersecarLineasPerfil(
            LineaPerfilYZ a,
            LineaPerfilYZ b)
        {
            if (a == null || b == null)
                return null;

            double ax = a.Y1;
            double ay = a.Z1;
            double avx = a.Y2 - a.Y1;
            double avy = a.Z2 - a.Z1;

            double bx = b.Y1;
            double by = b.Z1;
            double bvx = b.Y2 - b.Y1;
            double bvy = b.Z2 - b.Z1;

            double det = avx * bvy - avy * bvx;

            if (Math.Abs(det) <= Tol)
                return null;

            double t = ((bx - ax) * bvy - (by - ay) * bvx) / det;

            return new PuntoPerfilYZ(
                ax + avx * t,
                ay + avy * t);
        }

        private double ObtenerZEnYDeLinea(
            LineaPerfilYZ linea,
            double y)
        {
            if (linea == null)
                return 0.0;

            double dy = linea.Y2 - linea.Y1;

            if (Math.Abs(dy) <= Tol)
                return (linea.Z1 + linea.Z2) / 2.0;

            double t = (y - linea.Y1) / dy;

            return linea.Z1 + (linea.Z2 - linea.Z1) * t;
        }

        private void CorregirAlturasPerfilCumbrera(
            PerfilCumbreraYZ perfil,
            double minZ,
            double maxZ,
            double separacionVerticalMin)
        {
            if (perfil == null)
                return;

            CorregirParZ(
                ref perfil.ZBotIzq,
                ref perfil.ZTopIzq,
                minZ,
                maxZ,
                separacionVerticalMin);

            CorregirParZ(
                ref perfil.ZBotCentroIzq,
                ref perfil.ZTopCentroIzq,
                minZ,
                maxZ,
                separacionVerticalMin);

            CorregirParZ(
                ref perfil.ZBotCentroDer,
                ref perfil.ZTopCentroDer,
                minZ,
                maxZ,
                separacionVerticalMin);

            CorregirParZ(
                ref perfil.ZBotDer,
                ref perfil.ZTopDer,
                minZ,
                maxZ,
                separacionVerticalMin);
        }

        private void CorregirParZ(
            ref double zInferior,
            ref double zSuperior,
            double minZ,
            double maxZ,
            double separacionVerticalMin)
        {
            zInferior = Math.Max(minZ, Math.Min(maxZ, zInferior));
            zSuperior = Math.Max(minZ, Math.Min(maxZ, zSuperior));

            if (zSuperior <= zInferior + separacionVerticalMin)
            {
                double centro = (zSuperior + zInferior) / 2.0;
                zInferior = centro - separacionVerticalMin / 2.0;
                zSuperior = centro + separacionVerticalMin / 2.0;

                if (zInferior < minZ)
                {
                    zInferior = minZ;
                    zSuperior = minZ + separacionVerticalMin;
                }

                if (zSuperior > maxZ)
                {
                    zSuperior = maxZ;
                    zInferior = maxZ - separacionVerticalMin;
                }
            }
        }

        private XYZ PuntoLocalEstribo(
            DatosViga viga,
            XYZ centro,
            double y,
            double z)
        {
            return centro + viga.YAxis.Multiply(y) + viga.ZAxis.Multiply(z);
        }

        private void AgregarLineaSiValida(
            List<Curve> curvas,
            XYZ p1,
            XYZ p2)
        {
            if (curvas == null || p1 == null || p2 == null)
                return;

            if (p1.DistanceTo(p2) <= Tol)
                return;

            curvas.Add(Line.CreateBound(p1, p2));
        }

        private double ObtenerDiametroBarraFt(RebarBarType tipoBarra)
        {
            if (tipoBarra == null)
                return 0.0;

            // Primero intenta propiedades API según versión de Revit.
            string[] propiedades = new string[]
            {
                "BarModelDiameter",
                "BarNominalDiameter",
                "BarDiameter"
            };

            foreach (string nombrePropiedad in propiedades)
            {
                try
                {
                    System.Reflection.PropertyInfo prop =
                        typeof(RebarBarType).GetProperty(nombrePropiedad);

                    if (prop == null)
                        continue;

                    object valor = prop.GetValue(tipoBarra, null);

                    if (valor is double)
                    {
                        double d = (double)valor;

                        if (d > Tol)
                            return d;
                    }
                }
                catch
                {
                    // Sigue intentando por parámetros.
                }
            }

            // Luego intenta por nombres de parámetro en español/inglés.
            string[] nombresParametros = new string[]
            {
                "Diámetro de barra",
                "Diametro de barra",
                "Diámetro de barra de modelo",
                "Diametro de barra de modelo",
                "Bar Diameter",
                "Model Bar Diameter",
                "Nominal Diameter"
            };

            foreach (string nombre in nombresParametros)
            {
                try
                {
                    Parameter p = tipoBarra.LookupParameter(nombre);

                    if (p == null || p.StorageType != StorageType.Double)
                        continue;

                    double d = p.AsDouble();

                    if (d > Tol)
                        return d;
                }
                catch
                {
                }
            }

            // Último intento: busca cualquier parámetro que contenga diámetro/diameter.
            try
            {
                foreach (Parameter p in tipoBarra.Parameters)
                {
                    if (p == null || p.Definition == null)
                        continue;

                    if (p.StorageType != StorageType.Double)
                        continue;

                    string nombre = p.Definition.Name ?? "";
                    string n = nombre.ToLowerInvariant();

                    bool pareceDiametro =
                        n.Contains("diámetro") ||
                        n.Contains("diametro") ||
                        n.Contains("diameter");

                    if (!pareceDiametro)
                        continue;

                    double d = p.AsDouble();

                    if (d > Tol)
                        return d;
                }
            }
            catch
            {
            }

            // Si no se encuentra, no suma radio para no romper la ejecución.
            return 0.0;
        }

        private RebarHookType ObtenerGanchoEstribo135(Document doc)
        {
            if (doc == null)
                return null;

            List<RebarHookType> hooks = new FilteredElementCollector(doc)
                .OfClass(typeof(RebarHookType))
                .Cast<RebarHookType>()
                .OrderBy(x => x.Name)
                .ToList();

            if (hooks == null || hooks.Count == 0)
                return null;

            foreach (RebarHookType h in hooks)
            {
                if (h == null || string.IsNullOrWhiteSpace(h.Name))
                    continue;

                string n = h.Name.ToLowerInvariant();

                if (n.Contains("135") &&
                    (n.Contains("estrib") ||
                     n.Contains("tirante") ||
                     n.Contains("stirrup") ||
                     n.Contains("tie")))
                {
                    return h;
                }
            }

            foreach (RebarHookType h in hooks)
            {
                if (h == null || string.IsNullOrWhiteSpace(h.Name))
                    continue;

                if (h.Name.ToLowerInvariant().Contains("135"))
                    return h;
            }

            return null;
        }

        private Curve ObtenerCurvaElemento(Element elem)
        {
            if (elem == null)
                return null;

            LocationCurve lc = elem.Location as LocationCurve;

            if (lc == null)
                return null;

            return lc.Curve;
        }

        private List<XYZ> ObtenerPuntosSolidoElemento(Element elem)
        {
            List<XYZ> puntos = new List<XYZ>();

            if (elem == null)
                return puntos;

            Options opt = new Options();
            opt.DetailLevel = ViewDetailLevel.Fine;
            opt.IncludeNonVisibleObjects = false;
            opt.ComputeReferences = false;

            GeometryElement geo = null;

            try
            {
                geo = elem.get_Geometry(opt);
            }
            catch
            {
                geo = null;
            }

            if (geo == null)
                return puntos;

            RecolectarPuntosGeometria(
                geo,
                Transform.Identity,
                puntos);

            return puntos;
        }

        private void RecolectarPuntosGeometria(
            GeometryElement geo,
            Transform transform,
            List<XYZ> puntos)
        {
            if (geo == null || puntos == null)
                return;

            foreach (GeometryObject obj in geo)
            {
                if (obj == null)
                    continue;

                Solid solid = obj as Solid;

                if (solid != null)
                {
                    RecolectarPuntosSolido(
                        solid,
                        transform,
                        puntos);

                    continue;
                }

                GeometryInstance gi = obj as GeometryInstance;

                if (gi != null)
                {
                    bool procesado = false;

                    try
                    {
                        GeometryElement geoInst = gi.GetInstanceGeometry();

                        if (geoInst != null)
                        {
                            RecolectarPuntosGeometria(
                                geoInst,
                                Transform.Identity,
                                puntos);

                            procesado = true;
                        }
                    }
                    catch
                    {
                        procesado = false;
                    }

                    if (procesado)
                        continue;

                    try
                    {
                        GeometryElement geoSym = gi.GetSymbolGeometry();

                        if (geoSym != null)
                        {
                            Transform t2 = transform;

                            try
                            {
                                t2 = transform.Multiply(gi.Transform);
                            }
                            catch
                            {
                                t2 = gi.Transform;
                            }

                            RecolectarPuntosGeometria(
                                geoSym,
                                t2,
                                puntos);
                        }
                    }
                    catch
                    {
                    }
                }
            }
        }

        private void RecolectarPuntosSolido(
            Solid solid,
            Transform transform,
            List<XYZ> puntos)
        {
            if (solid == null || puntos == null)
                return;

            try
            {
                if (solid.Volume <= Tol)
                    return;
            }
            catch
            {
            }

            if (solid.Edges == null || solid.Edges.Size == 0)
                return;

            foreach (Edge edge in solid.Edges)
            {
                if (edge == null)
                    continue;

                Curve c = null;

                try
                {
                    c = edge.AsCurve();
                }
                catch
                {
                    c = null;
                }

                if (c == null)
                    continue;

                try
                {
                    XYZ a = c.GetEndPoint(0);
                    XYZ b = c.GetEndPoint(1);

                    if (transform != null && !transform.IsIdentity)
                    {
                        a = transform.OfPoint(a);
                        b = transform.OfPoint(b);
                    }

                    puntos.Add(a);
                    puntos.Add(b);
                }
                catch
                {
                }
            }
        }

        private List<XYZ> ObtenerPuntosBoundingBoxElemento(Element elem)
        {
            if (elem == null)
                return new List<XYZ>();

            BoundingBoxXYZ bb = elem.get_BoundingBox(null);

            if (bb == null)
                return new List<XYZ>();

            return ObtenerPuntosBoundingBox(bb);
        }

        private bool ObtenerIntervaloBoundingBoxEnEje(
            BoundingBoxXYZ bb,
            XYZ origen,
            XYZ eje,
            out double minEje,
            out double maxEje)
        {
            minEje = 0.0;
            maxEje = 0.0;

            if (bb == null)
                return false;

            if (origen == null || eje == null || eje.GetLength() <= Tol)
                return false;

            eje = eje.Normalize();

            List<XYZ> puntos = ObtenerPuntosBoundingBox(bb);

            if (puntos == null || puntos.Count == 0)
                return false;

            minEje = double.MaxValue;
            maxEje = double.MinValue;

            foreach (XYZ p in puntos)
            {
                double d = (p - origen).DotProduct(eje);

                if (d < minEje) minEje = d;
                if (d > maxEje) maxEje = d;
            }

            if (minEje == double.MaxValue || maxEje == double.MinValue)
                return false;

            return maxEje > minEje + Tol;
        }

        private double ObtenerDistanciaHorizontalMinimaAlEje(
            BoundingBoxXYZ bb,
            XYZ origen,
            XYZ eje,
            double longitudEje)
        {
            if (bb == null)
                return double.MaxValue;

            if (origen == null || eje == null || eje.GetLength() <= Tol)
                return double.MaxValue;

            eje = eje.Normalize();

            List<XYZ> puntos = ObtenerPuntosBoundingBox(bb);

            XYZ centro = new XYZ(
                (bb.Min.X + bb.Max.X) / 2.0,
                (bb.Min.Y + bb.Max.Y) / 2.0,
                (bb.Min.Z + bb.Max.Z) / 2.0);

            puntos.Add(centro);

            double minDist = double.MaxValue;

            foreach (XYZ p in puntos)
            {
                double t = (p - origen).DotProduct(eje);

                if (t < 0.0) t = 0.0;
                if (t > longitudEje) t = longitudEje;

                XYZ puntoEje = origen + eje.Multiply(t);

                double dist = DistanciaHorizontal(p, puntoEje);

                if (dist < minDist)
                    minDist = dist;
            }

            return minDist;
        }

        private double DistanciaHorizontal(XYZ a, XYZ b)
        {
            double dx = a.X - b.X;
            double dy = a.Y - b.Y;

            return Math.Sqrt(dx * dx + dy * dy);
        }

        private List<XYZ> ObtenerPuntosBoundingBox(BoundingBoxXYZ bb)
        {
            List<XYZ> puntos = new List<XYZ>();

            if (bb == null)
                return puntos;

            XYZ min = bb.Min;
            XYZ max = bb.Max;

            puntos.Add(new XYZ(min.X, min.Y, min.Z));
            puntos.Add(new XYZ(max.X, min.Y, min.Z));
            puntos.Add(new XYZ(min.X, max.Y, min.Z));
            puntos.Add(new XYZ(max.X, max.Y, min.Z));

            puntos.Add(new XYZ(min.X, min.Y, max.Z));
            puntos.Add(new XYZ(max.X, min.Y, max.Z));
            puntos.Add(new XYZ(min.X, max.Y, max.Z));
            puntos.Add(new XYZ(max.X, max.Y, max.Z));

            return puntos;
        }
    }
}
