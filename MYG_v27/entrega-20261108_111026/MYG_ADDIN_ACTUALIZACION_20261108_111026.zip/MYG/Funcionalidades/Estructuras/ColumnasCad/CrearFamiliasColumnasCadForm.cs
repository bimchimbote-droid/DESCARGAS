using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // VENTANA BOTÓN 3.5 - CREAR FAMILIAS DE COLUMNAS DESDE DWG
    // ESTILO SIMPLE TIPO TARRAJEO + LISTA BUSCADOR MULTICHECK
    // SIN USING NI NAMESPACE
    // =====================================

    public class CrearFamiliasColumnasCadForm : System.Windows.Forms.Form
    {
        private System.Windows.Forms.Label lblAutor;
        private System.Windows.Forms.Label lblTituloDwg;
        private System.Windows.Forms.Label lblInfoDwg;
        private System.Windows.Forms.Label lblDwgSeleccionado;

        private System.Windows.Forms.Label lblTituloPlantilla;
        private System.Windows.Forms.Label lblPlantilla;
        private System.Windows.Forms.Label lblCarpetaSalida;

        private System.Windows.Forms.Label lblTituloOpciones;
        private System.Windows.Forms.Label lblPrefijo;
        private System.Windows.Forms.Label lblAltura;

        private System.Windows.Forms.Label lblTituloBloques;
        private System.Windows.Forms.Label lblInfoBloques;

        private System.Windows.Forms.Label lblTituloCrear;
        private System.Windows.Forms.Label lblInfoCrear;
        private System.Windows.Forms.Label lblEstado;

        private System.Windows.Forms.TextBox txtPlantilla;
        private System.Windows.Forms.TextBox txtCarpetaSalida;
        private System.Windows.Forms.TextBox txtPrefijo;
        private System.Windows.Forms.TextBox txtAlturaMm;
        private System.Windows.Forms.TextBox txtResultado;

        private System.Windows.Forms.Button btnSeleccionarDwg;
        private System.Windows.Forms.Button btnBuscarPlantilla;
        private System.Windows.Forms.Button btnBuscarCarpeta;
        private System.Windows.Forms.Button btnDetectarBloques;
        private System.Windows.Forms.Button btnMarcarTodos;
        private System.Windows.Forms.Button btnDesmarcarTodos;
        private System.Windows.Forms.Button btnCrearFamilias;
        private System.Windows.Forms.Button btnCerrar;

        private System.Windows.Forms.CheckBox chkColocarInstancias;
        private System.Windows.Forms.CheckBox chkSobrescribir;
        private System.Windows.Forms.CheckBox chkCrearComoPilarEstructural;
        private System.Windows.Forms.CheckBox chkBloquearSuperiorInferior;

        private System.Windows.Forms.TextBox txtBuscarBloque;
        private System.Windows.Forms.ListView lstBloquesDetectados;

        private System.Collections.Generic.List<BloqueDetectadoItem> todosLosBloques =
            new System.Collections.Generic.List<BloqueDetectadoItem>();

        private System.Collections.Generic.HashSet<int> indicesBloquesSeleccionados =
            new System.Collections.Generic.HashSet<int>();

        private bool actualizandoChecksBloques = false;
        private bool aplicarCheckMultipleBloques = false;

        private System.Collections.Generic.List<System.Windows.Forms.ListViewItem> itemsParaCheckMultipleBloques =
            new System.Collections.Generic.List<System.Windows.Forms.ListViewItem>();

        private CrearFamiliasColumnasCadHandler handler;
        private Autodesk.Revit.UI.ExternalEvent externalEvent;

        public Autodesk.Revit.DB.ElementId DwgElementId { get; private set; }

        public string RutaPlantilla
        {
            get
            {
                return txtPlantilla != null
                    ? (txtPlantilla.Text ?? string.Empty).Trim()
                    : string.Empty;
            }
            set
            {
                if (txtPlantilla != null)
                    txtPlantilla.Text = value ?? string.Empty;
            }
        }

        public string CarpetaSalida
        {
            get
            {
                return txtCarpetaSalida != null
                    ? (txtCarpetaSalida.Text ?? string.Empty).Trim()
                    : string.Empty;
            }
            set
            {
                if (txtCarpetaSalida != null)
                    txtCarpetaSalida.Text = value ?? string.Empty;
            }
        }

        public string PrefijoFamilia
        {
            get
            {
                string valor = txtPrefijo != null
                    ? (txtPrefijo.Text ?? string.Empty).Trim()
                    : string.Empty;

                return string.IsNullOrWhiteSpace(valor)
                    ? "COL_CAD_"
                    : valor;
            }
        }

        public double AlturaMm
        {
            get
            {
                double valor = 3000.0;

                if (txtAlturaMm == null)
                    return valor;

                string texto = (txtAlturaMm.Text ?? string.Empty).Trim();

                if (string.IsNullOrWhiteSpace(texto))
                    return valor;

                texto = texto.Replace(",", ".");

                if (!double.TryParse(
                    texto,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out valor))
                {
                    valor = 3000.0;
                }

                if (valor <= 0.0)
                    valor = 3000.0;

                return valor;
            }
        }

        public bool ColocarInstancias
        {
            get
            {
                return chkColocarInstancias != null &&
                       chkColocarInstancias.Checked;
            }
        }

        public bool SobrescribirFamilias
        {
            get
            {
                return chkSobrescribir != null &&
                       chkSobrescribir.Checked;
            }
        }

        public bool CrearComoPilarEstructural
        {
            get
            {
                return chkCrearComoPilarEstructural != null &&
                       chkCrearComoPilarEstructural.Checked;
            }
        }

        public bool BloquearSuperiorInferior
        {
            get
            {
                return chkBloquearSuperiorInferior != null &&
                       chkBloquearSuperiorInferior.Checked;
            }
        }

        public int CantidadBloquesDetectados
        {
            get
            {
                return todosLosBloques != null
                    ? todosLosBloques.Count
                    : 0;
            }
        }

        public System.Collections.Generic.List<int> IndicesBloquesSeleccionados
        {
            get
            {
                System.Collections.Generic.List<int> indices =
                    new System.Collections.Generic.List<int>(indicesBloquesSeleccionados);

                indices.Sort();

                return indices;
            }
        }

        public CrearFamiliasColumnasCadForm(
            CrearFamiliasColumnasCadHandler handlerExterno,
            Autodesk.Revit.UI.ExternalEvent eventoExterno)
        {
            handler = handlerExterno;
            externalEvent = eventoExterno;

            DwgElementId = Autodesk.Revit.DB.ElementId.InvalidElementId;

            this.Text = "Familias de Columnas desde DWG";
            this.Width = 700;
            this.Height = 810;
            this.MinimumSize = new System.Drawing.Size(700, 810);
            this.MaximumSize = new System.Drawing.Size(700, 810);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = true;
            this.ShowInTaskbar = true;
            this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = false;

            CrearControles();

            this.FormClosed += (s, e) =>
            {
                try
                {
                    if (externalEvent != null)
                        externalEvent.Dispose();
                }
                catch
                {
                }
            };

            MostrarResultado("Seleccione un DWG y luego detecte los bloques.");
        }

        private void CrearControles()
        {
            lblAutor = new System.Windows.Forms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  MYG",
                Left = 20,
                Top = 8,
                Width = 640,
                Height = 20,
                Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.Gray
            };

            lblTituloDwg = new System.Windows.Forms.Label()
            {
                Text = "01. SELECCIONAR DWG CON BLOQUES DE COLUMNAS",
                Left = 20,
                Top = 38,
                Width = 640,
                Height = 22,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            lblInfoDwg = new System.Windows.Forms.Label()
            {
                Text = "Seleccione un DWG importado o vinculado. Cada sección debe estar como polilínea cerrada dentro del bloque.",
                Left = 20,
                Top = 62,
                Width = 640,
                Height = 38,
                ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
            };

            btnSeleccionarDwg = CrearBotonGris("SELECCIONAR DWG", 20, 105, 210, 34);

            btnSeleccionarDwg.Click += (s, e) =>
            {
                if (handler == null || externalEvent == null)
                    return;

                SetStatus("Selecciona el DWG en Revit...", true);
                handler.MakeRequest(CrearFamiliasColumnasCadHandler.RequestId.SeleccionarDwg);
                externalEvent.Raise();
            };

            lblDwgSeleccionado = new System.Windows.Forms.Label()
            {
                Text = "DWG seleccionado: Ninguno",
                Left = 250,
                Top = 104,
                Width = 420,
                Height = 42,
                ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
            };

            lblTituloPlantilla = new System.Windows.Forms.Label()
            {
                Text = "02. PLANTILLA DE FAMILIA Y CARPETA DE SALIDA",
                Left = 20,
                Top = 158,
                Width = 640,
                Height = 22,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            lblPlantilla = new System.Windows.Forms.Label()
            {
                Text = "Plantilla de familia estructural (.rft):",
                Left = 20,
                Top = 188,
                Width = 230,
                Height = 22,
                ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
            };

            txtPlantilla = new System.Windows.Forms.TextBox()
            {
                Left = 250,
                Top = 185,
                Width = 300,
                Height = 24,
                ReadOnly = true,
                BackColor = System.Drawing.Color.White,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            };

            btnBuscarPlantilla = CrearBotonGris("BUSCAR .RFT", 560, 183, 110, 28);
            btnBuscarPlantilla.Click += (s, e) => BuscarPlantilla();

            lblCarpetaSalida = new System.Windows.Forms.Label()
            {
                Text = "Carpeta de salida de las familias:",
                Left = 20,
                Top = 223,
                Width = 230,
                Height = 22,
                ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
            };

            txtCarpetaSalida = new System.Windows.Forms.TextBox()
            {
                Left = 250,
                Top = 220,
                Width = 300,
                Height = 24,
                ReadOnly = true,
                BackColor = System.Drawing.Color.White,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            };

            btnBuscarCarpeta = CrearBotonGris("CARPETA", 560, 218, 110, 28);
            btnBuscarCarpeta.Click += (s, e) => BuscarCarpetaSalida();

            lblTituloOpciones = new System.Windows.Forms.Label()
            {
                Text = "03. CONFIGURACIÓN DE FAMILIAS",
                Left = 20,
                Top = 263,
                Width = 640,
                Height = 22,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            lblPrefijo = new System.Windows.Forms.Label()
            {
                Text = "Prefijo de familia:",
                Left = 20,
                Top = 293,
                Width = 230,
                Height = 22,
                ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
            };

            txtPrefijo = new System.Windows.Forms.TextBox()
            {
                Left = 250,
                Top = 290,
                Width = 160,
                Height = 24,
                Text = "COL_CAD_",
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            };

            lblAltura = new System.Windows.Forms.Label()
            {
                Text = "Altura ref. superior (mm):",
                Left = 20,
                Top = 326,
                Width = 230,
                Height = 22,
                ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
            };

            txtAlturaMm = new System.Windows.Forms.TextBox()
            {
                Left = 250,
                Top = 323,
                Width = 160,
                Height = 24,
                Text = "3000",
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            };

            chkColocarInstancias = new System.Windows.Forms.CheckBox()
            {
                Text = "Cargar y colocar cada familia en la ubicación del bloque DWG",
                Left = 20,
                Top = 355,
                Width = 560,
                Height = 22,
                Checked = true,
                ForeColor = System.Drawing.Color.FromArgb(70, 70, 70),
                BackColor = System.Drawing.Color.FromArgb(245, 247, 250)
            };

            chkSobrescribir = new System.Windows.Forms.CheckBox()
            {
                Text = "Sobrescribir familias existentes con el mismo nombre",
                Left = 20,
                Top = 378,
                Width = 400,
                Height = 22,
                Checked = true,
                ForeColor = System.Drawing.Color.FromArgb(70, 70, 70),
                BackColor = System.Drawing.Color.FromArgb(245, 247, 250)
            };

            chkCrearComoPilarEstructural = new System.Windows.Forms.CheckBox()
            {
                Text = "Crear como Pilar Estructural",
                Left = 20,
                Top = 401,
                Width = 300,
                Height = 22,
                Checked = true,
                ForeColor = System.Drawing.Color.FromArgb(70, 70, 70),
                BackColor = System.Drawing.Color.FromArgb(245, 247, 250),
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold)
            };

            chkBloquearSuperiorInferior = new System.Windows.Forms.CheckBox()
            {
                Text = "Bloquear extrusión a Lower Ref. Level y Upper Ref. Level",
                Left = 20,
                Top = 424,
                Width = 520,
                Height = 22,
                Checked = true,
                ForeColor = System.Drawing.Color.FromArgb(70, 70, 70),
                BackColor = System.Drawing.Color.FromArgb(245, 247, 250)
            };

            lblTituloBloques = new System.Windows.Forms.Label()
            {
                Text = "04. BLOQUES DETECTADOS EN EL CAD",
                Left = 20,
                Top = 458,
                Width = 640,
                Height = 22,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            lblInfoBloques = new System.Windows.Forms.Label()
            {
                Text = "Detecte los bloques/secciones del DWG y marque con check solo los que desea crear.",
                Left = 20,
                Top = 481,
                Width = 640,
                Height = 20,
                ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
            };

            btnDetectarBloques = CrearBotonGris("DETECTAR BLOQUES", 20, 506, 170, 30);
            btnDetectarBloques.Click += (s, e) =>
            {
                if (handler == null || externalEvent == null)
                    return;

                if (DwgElementId == null ||
                    DwgElementId == Autodesk.Revit.DB.ElementId.InvalidElementId)
                {
                    MostrarResultado("Debe seleccionar un DWG primero.");
                    return;
                }

                SetStatus("Detectando bloques del DWG...", true);
                handler.MakeRequest(CrearFamiliasColumnasCadHandler.RequestId.AnalizarDwg);
                externalEvent.Raise();
            };

            btnMarcarTodos = CrearBotonSecundarioClaro("Seleccionar todo", 200, 506, 160, 30);
            btnMarcarTodos.Click += (s, e) => MarcarTodosLosBloques(true);

            btnDesmarcarTodos = CrearBotonSecundarioClaro("Deseleccionar todo", 370, 506, 160, 30);
            btnDesmarcarTodos.Click += (s, e) => MarcarTodosLosBloques(false);

            txtBuscarBloque = new System.Windows.Forms.TextBox()
            {
                Left = 20,
                Top = 542,
                Width = 650,
                Height = 24,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                BackColor = System.Drawing.Color.FromArgb(250, 250, 250)
            };

            txtBuscarBloque.TextChanged += TxtBuscarBloque_TextChanged;

            lstBloquesDetectados = new System.Windows.Forms.ListView()
            {
                Left = 20,
                Top = 572,
                Width = 650,
                Height = 104,
                CheckBoxes = true,
                FullRowSelect = true,
                MultiSelect = true,
                View = System.Windows.Forms.View.Details,
                HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None,
                HideSelection = false,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                BackColor = System.Drawing.Color.FromArgb(250, 250, 250),
                Font = new System.Drawing.Font("Segoe UI", 8.5F)
            };

            lstBloquesDetectados.Columns.Add("Bloque", 625);
            lstBloquesDetectados.ItemChecked += LstBloquesDetectados_ItemChecked;
            lstBloquesDetectados.MouseDown += LstBloquesDetectados_MouseDown;

            lblTituloCrear = new System.Windows.Forms.Label()
            {
                Text = "05. CREAR FAMILIAS",
                Left = 20,
                Top = 686,
                Width = 640,
                Height = 22,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            btnCrearFamilias = CrearBotonAzul("CREAR FAMILIAS", 20, 712, 215, 38);
            btnCrearFamilias.Click += (s, e) => EjecutarCrearFamilias();

            btnCerrar = CrearBotonGris("CERRAR", 550, 712, 120, 38);
            btnCerrar.Click += (s, e) => this.Close();

            lblEstado = new System.Windows.Forms.Label()
            {
                Text = "Listo.",
                Left = 250,
                Top = 710,
                Width = 285,
                Height = 42,
                ForeColor = System.Drawing.Color.FromArgb(90, 90, 90)
            };

            txtResultado = new System.Windows.Forms.TextBox()
            {
                Left = 250,
                Top = 730,
                Width = 285,
                Height = 45,
                Multiline = true,
                ReadOnly = true,
                ScrollBars = System.Windows.Forms.ScrollBars.Vertical,
                BackColor = System.Drawing.Color.White,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                Font = new System.Drawing.Font("Consolas", 8F),
                Visible = false
            };

            Controls.Add(lblAutor);

            Controls.Add(lblTituloDwg);
            Controls.Add(lblInfoDwg);
            Controls.Add(btnSeleccionarDwg);
            Controls.Add(lblDwgSeleccionado);

            Controls.Add(lblTituloPlantilla);
            Controls.Add(lblPlantilla);
            Controls.Add(txtPlantilla);
            Controls.Add(btnBuscarPlantilla);
            Controls.Add(lblCarpetaSalida);
            Controls.Add(txtCarpetaSalida);
            Controls.Add(btnBuscarCarpeta);

            Controls.Add(lblTituloOpciones);
            Controls.Add(lblPrefijo);
            Controls.Add(txtPrefijo);
            Controls.Add(lblAltura);
            Controls.Add(txtAlturaMm);
            Controls.Add(chkColocarInstancias);
            Controls.Add(chkSobrescribir);
            Controls.Add(chkCrearComoPilarEstructural);
            Controls.Add(chkBloquearSuperiorInferior);

            Controls.Add(lblTituloBloques);
            Controls.Add(lblInfoBloques);
            Controls.Add(btnDetectarBloques);
            Controls.Add(btnMarcarTodos);
            Controls.Add(btnDesmarcarTodos);
            Controls.Add(txtBuscarBloque);
            Controls.Add(lstBloquesDetectados);

            Controls.Add(lblTituloCrear);
            Controls.Add(btnCrearFamilias);
            Controls.Add(btnCerrar);
            Controls.Add(lblEstado);
            Controls.Add(txtResultado);
        }

        private System.Windows.Forms.Button CrearBotonAzul(string texto, int left, int top, int width, int height)
        {
            System.Windows.Forms.Button btn = new System.Windows.Forms.Button()
            {
                Text = texto,
                Left = left,
                Top = top,
                Width = width,
                Height = height,
                BackColor = System.Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = System.Drawing.Color.White,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                Cursor = System.Windows.Forms.Cursors.Hand
            };

            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(0, 100, 190);
            btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(0, 84, 160);

            return btn;
        }

        private System.Windows.Forms.Button CrearBotonGris(string texto, int left, int top, int width, int height)
        {
            System.Windows.Forms.Button btn = new System.Windows.Forms.Button()
            {
                Text = texto,
                Left = left,
                Top = top,
                Width = width,
                Height = height,
                BackColor = System.Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = System.Drawing.Color.White,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                Cursor = System.Windows.Forms.Cursors.Hand
            };

            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(80, 80, 80);
            btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(60, 60, 60);

            return btn;
        }

        private System.Windows.Forms.Button CrearBotonSecundarioClaro(string texto, int left, int top, int width, int height)
        {
            System.Windows.Forms.Button btn = new System.Windows.Forms.Button()
            {
                Text = texto,
                Left = left,
                Top = top,
                Width = width,
                Height = height,
                BackColor = System.Drawing.Color.FromArgb(240, 240, 240),
                ForeColor = System.Drawing.Color.FromArgb(30, 30, 30),
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Regular),
                Cursor = System.Windows.Forms.Cursors.Hand
            };

            btn.FlatAppearance.BorderSize = 1;
            btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(200, 200, 200);
            btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(225, 225, 225);
            btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(210, 210, 210);

            return btn;
        }

        private void EjecutarCrearFamilias()
        {
            if (handler == null || externalEvent == null)
                return;

            if (DwgElementId == null ||
                DwgElementId == Autodesk.Revit.DB.ElementId.InvalidElementId)
            {
                MostrarResultado("Debe seleccionar un DWG importado o vinculado.");
                return;
            }

            if (CantidadBloquesDetectados == 0)
            {
                MostrarResultado("Primero detecta los bloques del CAD.");
                return;
            }

            if (IndicesBloquesSeleccionados == null ||
                IndicesBloquesSeleccionados.Count == 0)
            {
                MostrarResultado("Debe marcar al menos un bloque de la lista.");
                return;
            }

            if (string.IsNullOrWhiteSpace(RutaPlantilla) ||
                !System.IO.File.Exists(RutaPlantilla))
            {
                MostrarResultado("Debe seleccionar una plantilla .RFT válida.");
                return;
            }

            if (string.IsNullOrWhiteSpace(CarpetaSalida))
            {
                MostrarResultado("Debe seleccionar una carpeta de salida válida.");
                return;
            }

            MostrarResultado("Creando familias desde los bloques seleccionados...");
            SetStatus("Creando familias...", true);

            handler.MakeRequest(CrearFamiliasColumnasCadHandler.RequestId.CrearFamilias);
            externalEvent.Raise();
        }

        private void BuscarPlantilla()
        {
            using (System.Windows.Forms.OpenFileDialog ofd =
                   new System.Windows.Forms.OpenFileDialog())
            {
                ofd.Title = "Seleccionar plantilla de familia de columna";
                ofd.Filter = "Plantilla de familia Revit (*.rft)|*.rft|Todos los archivos (*.*)|*.*";
                ofd.CheckFileExists = true;
                ofd.Multiselect = false;

                if (!string.IsNullOrWhiteSpace(RutaPlantilla) &&
                    System.IO.File.Exists(RutaPlantilla))
                {
                    ofd.InitialDirectory = System.IO.Path.GetDirectoryName(RutaPlantilla);
                    ofd.FileName = System.IO.Path.GetFileName(RutaPlantilla);
                }

                if (ofd.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
                {
                    RutaPlantilla = ofd.FileName;
                    MostrarResultado("Plantilla seleccionada correctamente.");
                }
            }
        }

        private void BuscarCarpetaSalida()
        {
            using (System.Windows.Forms.FolderBrowserDialog fbd =
                   new System.Windows.Forms.FolderBrowserDialog())
            {
                fbd.Description = "Selecciona la carpeta donde se guardarán las familias .rfa";

                if (!string.IsNullOrWhiteSpace(CarpetaSalida) &&
                    System.IO.Directory.Exists(CarpetaSalida))
                {
                    fbd.SelectedPath = CarpetaSalida;
                }

                if (fbd.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
                {
                    CarpetaSalida = fbd.SelectedPath;
                    MostrarResultado("Carpeta de salida seleccionada correctamente.");
                }
            }
        }

        public void ActualizarDwgSeleccionado(Autodesk.Revit.DB.ElementId id, string nombre)
        {
            DwgElementId = id ?? Autodesk.Revit.DB.ElementId.InvalidElementId;

            if (lblDwgSeleccionado != null)
            {
                lblDwgSeleccionado.Text = string.Format(
                    "DWG seleccionado:\r\n{0}  |  Id: {1}",
                    string.IsNullOrWhiteSpace(nombre) ? "DWG seleccionado" : nombre,
                    DwgElementId.Value);
            }

            LimpiarBloquesDetectados();

            MostrarResultado("DWG seleccionado correctamente. Ahora detecta los bloques.");
            SetStatus("DWG seleccionado correctamente.", false);
        }

        public void ActualizarBloquesDetectados(System.Collections.Generic.List<string> bloques)
        {
            todosLosBloques.Clear();
            indicesBloquesSeleccionados.Clear();

            if (lstBloquesDetectados != null)
                lstBloquesDetectados.Items.Clear();

            if (bloques == null || bloques.Count == 0)
            {
                MostrarResultado("No se detectaron bloques o polilíneas cerradas.");
                return;
            }

            for (int i = 0; i < bloques.Count; i++)
            {
                BloqueDetectadoItem item = new BloqueDetectadoItem();
                item.Indice = i;
                item.Nombre = bloques[i];

                todosLosBloques.Add(item);
                indicesBloquesSeleccionados.Add(item.Indice);
            }

            CargarListaBloquesFiltrada(
                txtBuscarBloque != null ? txtBuscarBloque.Text : "");

            MostrarResultado("Bloques detectados: " + bloques.Count.ToString());
            SetStatus("Bloques detectados: " + bloques.Count.ToString(), false);
        }

        private void LimpiarBloquesDetectados()
        {
            todosLosBloques.Clear();
            indicesBloquesSeleccionados.Clear();

            if (txtBuscarBloque != null)
                txtBuscarBloque.Text = "";

            if (lstBloquesDetectados != null)
                lstBloquesDetectados.Items.Clear();
        }

        private void MarcarTodosLosBloques(bool marcar)
        {
            if (lstBloquesDetectados == null)
                return;

            actualizandoChecksBloques = true;

            if (!marcar)
                indicesBloquesSeleccionados.Clear();

            lstBloquesDetectados.BeginUpdate();

            foreach (System.Windows.Forms.ListViewItem lvi in lstBloquesDetectados.Items)
            {
                BloqueDetectadoItem item = lvi.Tag as BloqueDetectadoItem;

                if (item == null)
                    continue;

                ActualizarEstadoBloque(item, marcar);
                lvi.Checked = marcar;
            }

            lstBloquesDetectados.EndUpdate();

            actualizandoChecksBloques = false;

            if (marcar)
                MostrarResultado("Bloques visibles seleccionados.");
            else
                MostrarResultado("Bloques deseleccionados.");
        }

        private void TxtBuscarBloque_TextChanged(object sender, System.EventArgs e)
        {
            CargarListaBloquesFiltrada(txtBuscarBloque != null ? txtBuscarBloque.Text : "");
        }

        private void CargarListaBloquesFiltrada(string filtro)
        {
            if (lstBloquesDetectados == null)
                return;

            string texto = filtro == null
                ? ""
                : filtro.Trim().ToLowerInvariant();

            actualizandoChecksBloques = true;

            lstBloquesDetectados.BeginUpdate();
            lstBloquesDetectados.Items.Clear();

            foreach (BloqueDetectadoItem item in todosLosBloques)
            {
                if (item == null)
                    continue;

                string nombre = item.Nombre == null ? "" : item.Nombre;

                if (!string.IsNullOrWhiteSpace(texto) &&
                    !nombre.ToLowerInvariant().Contains(texto))
                {
                    continue;
                }

                System.Windows.Forms.ListViewItem lvi =
                    new System.Windows.Forms.ListViewItem(nombre);

                lvi.Tag = item;
                lvi.Checked = indicesBloquesSeleccionados.Contains(item.Indice);

                lstBloquesDetectados.Items.Add(lvi);
            }

            lstBloquesDetectados.EndUpdate();

            actualizandoChecksBloques = false;
        }

        private void LstBloquesDetectados_MouseDown(
            object sender,
            System.Windows.Forms.MouseEventArgs e)
        {
            if (lstBloquesDetectados == null)
                return;

            System.Windows.Forms.ListViewHitTestInfo hit =
                lstBloquesDetectados.HitTest(e.Location);

            if (hit == null || hit.Item == null)
                return;

            bool clicEnCheck =
                (hit.Location & System.Windows.Forms.ListViewHitTestLocations.StateImage)
                == System.Windows.Forms.ListViewHitTestLocations.StateImage;

            if (!clicEnCheck)
                return;

            aplicarCheckMultipleBloques = false;
            itemsParaCheckMultipleBloques.Clear();

            if (lstBloquesDetectados.SelectedItems.Count <= 1)
                return;

            foreach (System.Windows.Forms.ListViewItem itemSeleccionado in lstBloquesDetectados.SelectedItems)
            {
                itemsParaCheckMultipleBloques.Add(itemSeleccionado);
            }

            if (!itemsParaCheckMultipleBloques.Contains(hit.Item))
                itemsParaCheckMultipleBloques.Add(hit.Item);

            aplicarCheckMultipleBloques = true;
        }

        private void LstBloquesDetectados_ItemChecked(
            object sender,
            System.Windows.Forms.ItemCheckedEventArgs e)
        {
            if (actualizandoChecksBloques)
                return;

            BloqueDetectadoItem item = e.Item.Tag as BloqueDetectadoItem;

            if (item == null)
                return;

            ActualizarEstadoBloque(item, e.Item.Checked);

            if (!aplicarCheckMultipleBloques)
                return;

            bool nuevoEstado = e.Item.Checked;

            this.BeginInvoke(new System.Action(() =>
            {
                actualizandoChecksBloques = true;

                foreach (System.Windows.Forms.ListViewItem itemSeleccionado in itemsParaCheckMultipleBloques)
                {
                    if (itemSeleccionado == null)
                        continue;

                    itemSeleccionado.Checked = nuevoEstado;

                    BloqueDetectadoItem bloque = itemSeleccionado.Tag as BloqueDetectadoItem;

                    if (bloque == null)
                        continue;

                    ActualizarEstadoBloque(bloque, nuevoEstado);
                }

                e.Item.Checked = nuevoEstado;
                ActualizarEstadoBloque(item, nuevoEstado);

                actualizandoChecksBloques = false;
                aplicarCheckMultipleBloques = false;
                itemsParaCheckMultipleBloques.Clear();
            }));
        }

        private void ActualizarEstadoBloque(
            BloqueDetectadoItem item,
            bool seleccionado)
        {
            if (item == null)
                return;

            if (seleccionado)
            {
                if (!indicesBloquesSeleccionados.Contains(item.Indice))
                    indicesBloquesSeleccionados.Add(item.Indice);
            }
            else
            {
                if (indicesBloquesSeleccionados.Contains(item.Indice))
                    indicesBloquesSeleccionados.Remove(item.Indice);
            }
        }

        public void SetBusy(bool ocupado)
        {
            try
            {
                if (btnCrearFamilias != null)
                    btnCrearFamilias.Enabled = !ocupado;

                if (btnSeleccionarDwg != null)
                    btnSeleccionarDwg.Enabled = !ocupado;

                if (btnBuscarPlantilla != null)
                    btnBuscarPlantilla.Enabled = !ocupado;

                if (btnBuscarCarpeta != null)
                    btnBuscarCarpeta.Enabled = !ocupado;

                if (btnDetectarBloques != null)
                    btnDetectarBloques.Enabled = !ocupado;

                if (txtBuscarBloque != null)
                    txtBuscarBloque.Enabled = !ocupado;

                if (lstBloquesDetectados != null)
                    lstBloquesDetectados.Enabled = !ocupado;

                this.Cursor = ocupado
                    ? System.Windows.Forms.Cursors.WaitCursor
                    : System.Windows.Forms.Cursors.Default;
            }
            catch
            {
            }
        }

        public void SetStatus(string texto, bool ocupado)
        {
            if (lblEstado != null)
                lblEstado.Text = texto ?? string.Empty;

            SetBusy(ocupado);

            try
            {
                if (lblEstado != null)
                    lblEstado.Refresh();
            }
            catch
            {
            }
        }

        public void SetResultado(string texto)
        {
            if (txtResultado != null)
                txtResultado.Text = texto ?? string.Empty;

            MostrarResultado(texto);
        }

        public void AgregarResultado(string texto)
        {
            if (txtResultado != null)
            {
                if (txtResultado.TextLength > 0)
                    txtResultado.AppendText(System.Environment.NewLine);

                txtResultado.AppendText(texto ?? string.Empty);

                txtResultado.SelectionStart = txtResultado.TextLength;
                txtResultado.ScrollToCaret();
            }

            if (!string.IsNullOrWhiteSpace(texto))
                MostrarResultado(texto);
        }

        private void MostrarResultado(string texto)
        {
            if (lblEstado == null)
                return;

            lblEstado.Text = texto ?? "";
            lblEstado.Visible = true;

            if (string.IsNullOrWhiteSpace(texto))
                return;

            if (texto.StartsWith("ERROR", System.StringComparison.OrdinalIgnoreCase) ||
                texto.StartsWith("Debe", System.StringComparison.OrdinalIgnoreCase) ||
                texto.StartsWith("No se", System.StringComparison.OrdinalIgnoreCase) ||
                texto.StartsWith("Primero", System.StringComparison.OrdinalIgnoreCase))
            {
                lblEstado.ForeColor = System.Drawing.Color.FromArgb(190, 40, 40);
            }
            else
            {
                lblEstado.ForeColor = System.Drawing.Color.FromArgb(90, 90, 90);
            }
        }

        private class BloqueDetectadoItem
        {
            public int Indice { get; set; }
            public string Nombre { get; set; }

            public override string ToString()
            {
                return Nombre;
            }
        }
    }

}
