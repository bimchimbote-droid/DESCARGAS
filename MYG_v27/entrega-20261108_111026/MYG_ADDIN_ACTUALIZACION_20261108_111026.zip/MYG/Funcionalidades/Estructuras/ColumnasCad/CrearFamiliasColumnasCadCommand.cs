using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // COMANDO BOTÓN 3.5 - CREAR FAMILIAS DE COLUMNAS DESDE DWG
    // SIN USING
    // =====================================

    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class CrearFamiliasColumnasCadCommand : Autodesk.Revit.UI.IExternalCommand
    {
        private static CrearFamiliasColumnasCadForm ventanaActiva;

        public Autodesk.Revit.UI.Result Execute(
            Autodesk.Revit.UI.ExternalCommandData commandData,
            ref string message,
            Autodesk.Revit.DB.ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            try
            {
                if (ventanaActiva != null && !ventanaActiva.IsDisposed)
                {
                    ventanaActiva.BringToFront();
                    ventanaActiva.Activate();
                    return Autodesk.Revit.UI.Result.Succeeded;
                }

                CrearFamiliasColumnasCadHandler handler =
                    new CrearFamiliasColumnasCadHandler();

                Autodesk.Revit.UI.ExternalEvent externalEvent =
                    Autodesk.Revit.UI.ExternalEvent.Create(handler);

                ventanaActiva =
                    new CrearFamiliasColumnasCadForm(handler, externalEvent);

                handler.Form = ventanaActiva;

                Autodesk.Revit.DB.Document doc =
                    commandData.Application.ActiveUIDocument.Document;

                ventanaActiva.RutaPlantilla =
                    ObtenerRutaPlantillaPorDefecto();

                ventanaActiva.CarpetaSalida =
                    ObtenerCarpetaSalidaPorDefecto(doc);

                ventanaActiva.FormClosed += (s, e) =>
                {
                    ventanaActiva = null;
                };

                ventanaActiva.Show();

                return Autodesk.Revit.UI.Result.Succeeded;
            }
            catch (System.Exception ex)
            {
                message = ex.Message;

                Autodesk.Revit.UI.TaskDialog.Show(
                    "MYG - Familias Columnas CAD",
                    "No se pudo abrir la ventana.\n\n" + ex.Message);

                return Autodesk.Revit.UI.Result.Failed;
            }
        }

        private string ObtenerRutaPlantillaPorDefecto()
        {
            string[] candidatos = new string[]
            {
                @"C:\ProgramData\Autodesk\RVT 2027\Family Templates\Spanish\Structural Columns\Columna estructural métrica.rft",
                @"C:\ProgramData\Autodesk\RVT 2027\Family Templates\Spanish\Columnas estructurales\Columna estructural métrica.rft",
                @"C:\ProgramData\Autodesk\RVT 2027\Family Templates\English\Structural Columns\Metric Structural Column.rft",
                @"C:\ProgramData\Autodesk\RVT 2027\Family Templates\English\Structural Columns\Structural Column.rft"
            };

            foreach (string ruta in candidatos)
            {
                try
                {
                    if (!string.IsNullOrWhiteSpace(ruta) &&
                        System.IO.File.Exists(ruta))
                    {
                        return ruta;
                    }
                }
                catch
                {
                }
            }

            return string.Empty;
        }

        private string ObtenerCarpetaSalidaPorDefecto(
            Autodesk.Revit.DB.Document doc)
        {
            try
            {
                string carpetaModelo = null;

                if (doc != null &&
                    !string.IsNullOrWhiteSpace(doc.PathName))
                {
                    carpetaModelo =
                        System.IO.Path.GetDirectoryName(doc.PathName);
                }

                if (string.IsNullOrWhiteSpace(carpetaModelo) ||
                    !System.IO.Directory.Exists(carpetaModelo))
                {
                    carpetaModelo =
                        System.Environment.GetFolderPath(
                            System.Environment.SpecialFolder.MyDocuments);
                }

                string carpeta = System.IO.Path.Combine(
                    carpetaModelo,
                    "Familias_Columnas_CAD");

                if (!System.IO.Directory.Exists(carpeta))
                    System.IO.Directory.CreateDirectory(carpeta);

                return carpeta;
            }
            catch
            {
                return System.Environment.GetFolderPath(
                    System.Environment.SpecialFolder.MyDocuments);
            }
        }
    }

}
