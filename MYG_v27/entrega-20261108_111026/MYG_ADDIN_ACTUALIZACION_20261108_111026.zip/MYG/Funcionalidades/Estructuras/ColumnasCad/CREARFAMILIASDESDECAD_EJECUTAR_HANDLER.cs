﻿// =====================================
// HANDLER EXTERNO BOTÓN 3.5 - CREAR FAMILIAS DE COLUMNAS DESDE DWG
// FUNCIONA POR CAPAS CAD + PARÁMETROS COMPARTIDOS DE TIPO
// CON USING
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace MYG_Addin
{
    public class CrearFamiliasColumnasCadHandler : IExternalEventHandler
    {
        public enum RequestId
        {
            Ninguno = 0,
            SeleccionarDwg = 1,
            CrearFamilias = 2,
            AnalizarDwg = 3
        }

        private RequestId requestActual = RequestId.Ninguno;

        public CrearFamiliasColumnasCadForm Form { get; set; }

        private const double TOL = 0.003280839895; // 1 mm aprox. en pies internos Revit.

        // GUIDs tomados de Estructuras.txt
        private static readonly Guid GUID_AREA_SECCION =
            new Guid("08bea590-9f22-4070-adab-a9e4112e948c");

        private static readonly Guid GUID_PERIMETRO_CURADO =
            new Guid("24cbc9d6-b0e5-4c96-a80d-7b5027415e14");

        private const string NOMBRE_PARAM_AREA_SECCION = "Área de sección (m²)";
        private const string NOMBRE_PARAM_PERIMETRO_CURADO = "Perímetro de curado";
        private const string GRUPO_PARAM_ESTRUCTURAS = "Estructuras";

        public void MakeRequest(RequestId request)
        {
            requestActual = request;
        }

        public string GetName()
        {
            return "MYG - Crear Familias de Columnas desde DWG";
        }

        public void Execute(UIApplication app)
        {
            RequestId request = requestActual;
            requestActual = RequestId.Ninguno;

            if (Form == null || Form.IsDisposed)
                return;

            try
            {
                if (request == RequestId.SeleccionarDwg)
                {
                    SeleccionarDwg(app);
                    return;
                }

                if (request == RequestId.AnalizarDwg)
                {
                    AnalizarDwg(app);
                    return;
                }

                if (request == RequestId.CrearFamilias)
                {
                    CrearFamilias(app);
                    return;
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                Form.SetStatus("Selección cancelada.", false);
            }
            catch (Exception ex)
            {
                Form.SetStatus("Error en el proceso.", false);
                Form.AgregarResultado("ERROR: " + ex.Message);

                TaskDialog.Show(
                    "MYG - Crear familias CAD",
                    ex.Message);
            }
            finally
            {
                Form.SetBusy(false);
            }
        }

        // =========================================================
        // SELECCIONAR DWG
        // =========================================================

        private void SeleccionarDwg(UIApplication uiapp)
        {
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;

            bool estabaVisible = Form.Visible;

            try
            {
                Form.TopMost = false;
                Form.Hide();

                Reference referencia = uidoc.Selection.PickObject(
                    ObjectType.Element,
                    new FiltroDwgImportado(),
                    "Selecciona el DWG importado o vinculado que contiene las columnas por capas");

                if (referencia == null)
                {
                    Form.SetStatus("No se seleccionó ningún DWG.", false);
                    return;
                }

                ImportInstance cad = doc.GetElement(referencia.ElementId) as ImportInstance;

                if (cad == null)
                {
                    Form.SetStatus("El elemento seleccionado no es un DWG.", false);
                    return;
                }

                Form.ActualizarDwgSeleccionado(cad.Id, cad.Name);
            }
            finally
            {
                if (estabaVisible && Form != null && !Form.IsDisposed)
                {
                    Form.Show();
                    Form.TopMost = true;
                    Form.BringToFront();
                    Form.Activate();
                }
            }
        }

        // =========================================================
        // ANALIZAR DWG / LLENAR LISTA POR CAPAS
        // =========================================================

        private void AnalizarDwg(UIApplication uiapp)
        {
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;

            if (Form.DwgElementId == null ||
                Form.DwgElementId == ElementId.InvalidElementId)
            {
                throw new Exception("Primero selecciona un DWG.");
            }

            ImportInstance cad = doc.GetElement(Form.DwgElementId) as ImportInstance;

            if (cad == null)
                throw new Exception("No se encontró el DWG seleccionado. Puede que haya sido eliminado.");

            Form.SetResultado("Analizando capas/secciones del DWG..." + Environment.NewLine);

            List<PerfilCadCerrado> perfiles = ObtenerPerfilesCerrados(doc, cad);
            perfiles = QuitarDuplicados(perfiles);
            AsignarIndicesPerfilesPorCapa(perfiles);

            if (perfiles.Count == 0)
            {
                Form.ActualizarBloquesDetectados(new List<string>());

                throw new Exception(
                    "No se encontraron polilíneas cerradas en el DWG.\n\n" +
                    "Organiza el CAD dejando cada sección como una polilínea cerrada y coloca cada tipo en su capa, por ejemplo C1, C2, C3.");
            }

            List<string> textos = new List<string>();

            foreach (PerfilCadCerrado perfil in perfiles)
            {
                textos.Add(CrearTextoBloqueDetectadoPorCapa(perfil));
            }

            Form.ActualizarBloquesDetectados(textos);

            Form.AgregarResultado(
                "Secciones detectadas por capa: " +
                perfiles.Count.ToString(CultureInfo.InvariantCulture));

            Form.SetStatus(
                "Secciones detectadas: " +
                perfiles.Count.ToString(CultureInfo.InvariantCulture),
                false);
        }

        // =========================================================
        // CREAR FAMILIAS
        // =========================================================

        private void CrearFamilias(UIApplication uiapp)
        {
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;

            if (Form.DwgElementId == null ||
                Form.DwgElementId == ElementId.InvalidElementId)
            {
                throw new Exception("Primero selecciona un DWG.");
            }

            ImportInstance cad = doc.GetElement(Form.DwgElementId) as ImportInstance;

            if (cad == null)
                throw new Exception("No se encontró el DWG seleccionado. Puede que haya sido eliminado.");

            string rutaPlantilla = Form.RutaPlantilla;
            string carpetaSalida = Form.CarpetaSalida;
            string prefijo = Form.PrefijoFamilia;
            double alturaMm = Form.AlturaMm;
            bool colocarInstancias = Form.ColocarInstancias;
            bool sobrescribir = Form.SobrescribirFamilias;
            bool crearComoPilarEstructural = Form.CrearComoPilarEstructural;
            bool bloquearSuperiorInferior = Form.BloquearSuperiorInferior;

            if (string.IsNullOrWhiteSpace(rutaPlantilla) ||
                !File.Exists(rutaPlantilla))
            {
                throw new Exception("La plantilla .RFT no existe: " + rutaPlantilla);
            }

            if (string.IsNullOrWhiteSpace(carpetaSalida))
                throw new Exception("La carpeta de salida no es válida.");

            if (!Directory.Exists(carpetaSalida))
                Directory.CreateDirectory(carpetaSalida);

            List<int> indicesSeleccionados = Form.IndicesBloquesSeleccionados;

            if (indicesSeleccionados == null || indicesSeleccionados.Count == 0)
                throw new Exception("Debe marcar al menos una sección/capa de la lista.");

            Form.SetResultado("Leyendo geometría del DWG..." + Environment.NewLine);

            List<PerfilCadCerrado> perfiles = ObtenerPerfilesCerrados(doc, cad);
            perfiles = QuitarDuplicados(perfiles);
            AsignarIndicesPerfilesPorCapa(perfiles);

            if (perfiles.Count == 0)
            {
                throw new Exception(
                    "No se encontraron polilíneas cerradas en el DWG.\n\n" +
                    "Organiza el CAD por capas y deja cada sección como polilínea cerrada.");
            }

            HashSet<int> setIndices = new HashSet<int>(indicesSeleccionados);

            perfiles = perfiles
                .Where(x => x != null && setIndices.Contains(x.Indice))
                .ToList();

            if (perfiles.Count == 0)
                throw new Exception("No hay secciones seleccionadas válidas para crear.");

            Form.AgregarResultado(
                "Secciones seleccionadas para crear: " +
                perfiles.Count.ToString(CultureInfo.InvariantCulture));

            Level nivel = ObtenerNivelParaColocacion(doc);

            if (colocarInstancias && nivel == null)
                throw new Exception("No se encontró un nivel para colocar las familias.");

            int creadas = 0;
            int colocadas = 0;

            List<string> errores = new List<string>();

            foreach (PerfilCadCerrado perfil in perfiles)
            {
                string nombreFamilia = CrearNombreFamilia(
                    prefijo,
                    perfil.Indice + 1,
                    perfil);

                string rutaRfa = Path.Combine(
                    carpetaSalida,
                    nombreFamilia + ".rfa");

                try
                {
                    if (File.Exists(rutaRfa) && !sobrescribir)
                    {
                        Form.AgregarResultado("Omitida por existir: " + nombreFamilia);
                        continue;
                    }

                    ResultadoFamilia resultadoFamilia = CrearFamiliaRfa(
                        uiapp.Application,
                        rutaPlantilla,
                        rutaRfa,
                        perfil,
                        alturaMm,
                        sobrescribir,
                        crearComoPilarEstructural,
                        bloquearSuperiorInferior);

                    creadas++;

                    Form.AgregarResultado("Familia creada: " + nombreFamilia);

                    if (!string.IsNullOrWhiteSpace(resultadoFamilia.MensajeParametros))
                        Form.AgregarResultado("  " + resultadoFamilia.MensajeParametros);

                    if (!string.IsNullOrWhiteSpace(resultadoFamilia.MensajeMaterial))
                        Form.AgregarResultado("  " + resultadoFamilia.MensajeMaterial);

                    if (!string.IsNullOrWhiteSpace(resultadoFamilia.MensajeRestriccion))
                        Form.AgregarResultado("  " + resultadoFamilia.MensajeRestriccion);

                    if (colocarInstancias)
                    {
                        Family familiaCargada = CargarFamilia(
                            doc,
                            rutaRfa,
                            sobrescribir);

                        if (familiaCargada != null)
                        {
                            FamilyInstance instancia = ColocarFamilia(
                                doc,
                                familiaCargada,
                                perfil.Centro,
                                nivel,
                                crearComoPilarEstructural);

                            if (instancia != null)
                            {
                                colocadas++;
                                EscribirIdElementoSiExiste(instancia);
                            }
                        }
                    }
                }
                catch (Exception exPerfil)
                {
                    errores.Add(nombreFamilia + ": " + exPerfil.Message);

                    Form.AgregarResultado(
                        "ERROR " + nombreFamilia + ": " + exPerfil.Message);
                }
            }

            string resumen =
                "Proceso terminado." + Environment.NewLine +
                "Familias creadas: " + creadas.ToString(CultureInfo.InvariantCulture) + Environment.NewLine +
                "Instancias colocadas: " + colocadas.ToString(CultureInfo.InvariantCulture) + Environment.NewLine +
                "Carpeta:" + Environment.NewLine + carpetaSalida;

            if (errores.Count > 0)
            {
                resumen += Environment.NewLine +
                           "Errores: " +
                           errores.Count.ToString(CultureInfo.InvariantCulture);

                foreach (string error in errores)
                {
                    resumen += Environment.NewLine + "- " + error;
                }
            }

            Form.AgregarResultado(string.Empty);
            Form.AgregarResultado(resumen);
            Form.SetStatus("Proceso terminado.", false);

            TaskDialog.Show("MYG - Crear familias CAD", resumen);
        }

        // =========================================================
        // EXTRAER PERFILES DEL DWG
        // =========================================================

        private List<PerfilCadCerrado> ObtenerPerfilesCerrados(
            Document doc,
            ImportInstance cad)
        {
            Options opt = new Options();
            opt.ComputeReferences = false;
            opt.IncludeNonVisibleObjects = false;
            opt.DetailLevel = ViewDetailLevel.Fine;

            try
            {
                if (doc.ActiveView != null)
                    opt.View = doc.ActiveView;
            }
            catch
            {
            }

            GeometryElement geo = cad.get_Geometry(opt);

            List<PerfilCadCerrado> perfiles = new List<PerfilCadCerrado>();

            if (geo == null)
                return perfiles;

            ExtraerPerfilesDesdeGeometria(
                doc,
                geo,
                Transform.Identity,
                "",
                perfiles);

            return perfiles;
        }

        private void ExtraerPerfilesDesdeGeometria(
            Document doc,
            GeometryElement geo,
            Transform transformAcumulado,
            string capaAcumulada,
            List<PerfilCadCerrado> perfiles)
        {
            if (geo == null)
                return;

            foreach (GeometryObject obj in geo)
            {
                if (obj == null)
                    continue;

                GeometryInstance gi = obj as GeometryInstance;

                if (gi != null)
                {
                    Transform nuevoTransform = transformAcumulado.Multiply(gi.Transform);

                    string capaGi = ObtenerNombreCapaDesdeGeometryObject(doc, gi);

                    string nuevaCapa = !string.IsNullOrWhiteSpace(capaGi)
                        ? capaGi
                        : capaAcumulada;

                    GeometryElement geoInstancia = gi.GetSymbolGeometry();

                    ExtraerPerfilesDesdeGeometria(
                        doc,
                        geoInstancia,
                        nuevoTransform,
                        nuevaCapa,
                        perfiles);

                    continue;
                }

                PolyLine pl = obj as PolyLine;

                if (pl != null)
                {
                    PerfilCadCerrado perfil = CrearPerfilDesdePolyline(
                        doc,
                        pl,
                        transformAcumulado,
                        capaAcumulada);

                    if (perfil != null)
                        perfiles.Add(perfil);

                    continue;
                }

                Curve curva = obj as Curve;

                if (curva != null)
                {
                    PerfilCadCerrado perfilCurva = CrearPerfilDesdeCurvaSiCerrada(
                        doc,
                        curva,
                        transformAcumulado,
                        capaAcumulada);

                    if (perfilCurva != null)
                        perfiles.Add(perfilCurva);
                }
            }
        }

        private PerfilCadCerrado CrearPerfilDesdePolyline(
            Document doc,
            PolyLine pl,
            Transform tr,
            string capaAcumulada)
        {
            IList<XYZ> coords = pl.GetCoordinates();

            if (coords == null || coords.Count < 4)
                return null;

            List<XYZ> puntos = new List<XYZ>();

            foreach (XYZ p in coords)
            {
                XYZ q = tr.OfPoint(p);
                puntos.Add(new XYZ(q.X, q.Y, 0.0));
            }

            puntos = LimpiarPuntosConsecutivos(puntos, TOL);

            if (puntos.Count < 4)
                return null;

            if (puntos[0].DistanceTo(puntos[puntos.Count - 1]) > TOL)
                return null;

            List<Curve> curvas = new List<Curve>();

            for (int i = 0; i < puntos.Count - 1; i++)
            {
                XYZ p0 = puntos[i];
                XYZ p1 = puntos[i + 1];

                if (p0.DistanceTo(p1) <= TOL)
                    continue;

                curvas.Add(Line.CreateBound(p0, p1));
            }

            if (curvas.Count < 3)
                return null;

            double area = Math.Abs(CalcularArea2D(puntos));

            if (area <= TOL * TOL)
                return null;

            XYZ centro = CalcularCentroBounding(curvas);

            string nombreCapa = ObtenerNombreCapaDesdeGeometryObject(doc, pl);

            if (string.IsNullOrWhiteSpace(nombreCapa))
                nombreCapa = capaAcumulada;

            nombreCapa = NormalizarNombreCapa(nombreCapa);

            return new PerfilCadCerrado()
            {
                Indice = -1,
                NombreBloque = nombreCapa,
                NombreCapa = nombreCapa,
                Curvas = curvas,
                Puntos = puntos,
                Centro = centro,
                Area = area
            };
        }

        private PerfilCadCerrado CrearPerfilDesdeCurvaSiCerrada(
            Document doc,
            Curve curva,
            Transform tr,
            string capaAcumulada)
        {
            return null;
        }

        private List<XYZ> LimpiarPuntosConsecutivos(
            List<XYZ> puntos,
            double tolerancia)
        {
            List<XYZ> resultado = new List<XYZ>();

            if (puntos == null)
                return resultado;

            foreach (XYZ p in puntos)
            {
                if (p == null)
                    continue;

                if (resultado.Count == 0 ||
                    resultado[resultado.Count - 1].DistanceTo(p) > tolerancia)
                {
                    resultado.Add(p);
                }
            }

            return resultado;
        }

        private XYZ CalcularCentroBounding(List<Curve> curvas)
        {
            double minX = double.MaxValue;
            double minY = double.MaxValue;
            double maxX = double.MinValue;
            double maxY = double.MinValue;

            foreach (Curve c in curvas)
            {
                for (int i = 0; i < 2; i++)
                {
                    XYZ p = c.GetEndPoint(i);

                    minX = Math.Min(minX, p.X);
                    minY = Math.Min(minY, p.Y);
                    maxX = Math.Max(maxX, p.X);
                    maxY = Math.Max(maxY, p.Y);
                }
            }

            return new XYZ(
                (minX + maxX) / 2.0,
                (minY + maxY) / 2.0,
                0.0);
        }

        private double CalcularArea2D(List<XYZ> puntos)
        {
            if (puntos == null || puntos.Count < 4)
                return 0.0;

            double suma = 0.0;

            for (int i = 0; i < puntos.Count - 1; i++)
            {
                XYZ p0 = puntos[i];
                XYZ p1 = puntos[i + 1];

                suma += (p0.X * p1.Y) - (p1.X * p0.Y);
            }

            return suma / 2.0;
        }

        private double CalcularPerimetroInterno(PerfilCadCerrado perfil)
        {
            if (perfil == null ||
                perfil.Curvas == null ||
                perfil.Curvas.Count == 0)
            {
                return 0.0;
            }

            double perimetro = 0.0;

            foreach (Curve c in perfil.Curvas)
            {
                if (c == null)
                    continue;

                perimetro += c.Length;
            }

            return perimetro;
        }

        private List<PerfilCadCerrado> QuitarDuplicados(
            List<PerfilCadCerrado> perfiles)
        {
            List<PerfilCadCerrado> resultado = new List<PerfilCadCerrado>();

            if (perfiles == null)
                return resultado;

            foreach (PerfilCadCerrado p in perfiles)
            {
                if (p == null)
                    continue;

                bool existe = false;

                foreach (PerfilCadCerrado q in resultado)
                {
                    if (p.Centro.DistanceTo(q.Centro) <= TOL * 2.0 &&
                        Math.Abs(p.Area - q.Area) <= TOL * TOL * 10.0 &&
                        string.Equals(p.NombreCapa, q.NombreCapa, StringComparison.OrdinalIgnoreCase))
                    {
                        existe = true;
                        break;
                    }
                }

                if (!existe)
                    resultado.Add(p);
            }

            return resultado;
        }

        private void AsignarIndicesPerfilesPorCapa(List<PerfilCadCerrado> perfiles)
        {
            if (perfiles == null)
                return;

            for (int i = 0; i < perfiles.Count; i++)
            {
                perfiles[i].Indice = i;

                string capa = NormalizarNombreCapa(perfiles[i].NombreCapa);

                if (string.IsNullOrWhiteSpace(capa))
                    capa = "SIN_CAPA";

                perfiles[i].NombreCapa = capa;
                perfiles[i].NombreBloque = capa;
            }
        }

        private string CrearTextoBloqueDetectadoPorCapa(PerfilCadCerrado perfil)
        {
            if (perfil == null)
                return "Sección no válida";

            double anchoMm = 0.0;
            double altoMm = 0.0;

            ObtenerDimensionesMm(
                perfil,
                out anchoMm,
                out altoMm);

            string capa = NormalizarNombreCapa(perfil.NombreCapa);

            if (string.IsNullOrWhiteSpace(capa))
                capa = "SIN_CAPA";

            return string.Format(
                CultureInfo.InvariantCulture,
                "{0}  |  #{1:000}  |  {2:0} x {3:0} mm  |  Capa: {0}",
                capa,
                perfil.Indice + 1,
                anchoMm,
                altoMm);
        }

        private string ObtenerNombreCapaDesdeGeometryObject(
            Document doc,
            GeometryObject obj)
        {
            try
            {
                if (doc == null || obj == null)
                    return "";

                if (obj.GraphicsStyleId == null ||
                    obj.GraphicsStyleId == ElementId.InvalidElementId)
                    return "";

                Element e = doc.GetElement(obj.GraphicsStyleId);

                GraphicsStyle gs = e as GraphicsStyle;

                if (gs != null && gs.GraphicsStyleCategory != null)
                    return NormalizarNombreCapa(gs.GraphicsStyleCategory.Name);
            }
            catch
            {
            }

            return "";
        }

        private string NormalizarNombreCapa(string nombreCapa)
        {
            if (string.IsNullOrWhiteSpace(nombreCapa))
                return "";

            string capa = nombreCapa.Trim();

            int idx = capa.LastIndexOf('|');

            if (idx >= 0 && idx < capa.Length - 1)
                capa = capa.Substring(idx + 1).Trim();

            while (capa.Contains("  "))
                capa = capa.Replace("  ", " ");

            return capa;
        }

        // =========================================================
        // NOMBRES Y DIMENSIONES
        // =========================================================

        private string CrearNombreFamilia(
            string prefijo,
            int index,
            PerfilCadCerrado perfil)
        {
            double anchoMm = 0.0;
            double altoMm = 0.0;

            ObtenerDimensionesMm(
                perfil,
                out anchoMm,
                out altoMm);

            int ancho = Math.Max(1, (int)Math.Round(anchoMm));
            int alto = Math.Max(1, (int)Math.Round(altoMm));

            string capa = "";

            if (perfil != null)
                capa = NormalizarNombreCapa(perfil.NombreCapa);

            if (string.IsNullOrWhiteSpace(capa))
            {
                capa =
                    "SIN_CAPA_" +
                    index.ToString("000", CultureInfo.InvariantCulture);
            }

            string nombre =
                prefijo +
                LimpiarNombreArchivo(capa) +
                "_" +
                index.ToString("000", CultureInfo.InvariantCulture) +
                "_" +
                ancho.ToString(CultureInfo.InvariantCulture) +
                "x" +
                alto.ToString(CultureInfo.InvariantCulture);

            return LimpiarNombreArchivo(nombre);
        }

        private void ObtenerDimensionesMm(
            PerfilCadCerrado perfil,
            out double anchoMm,
            out double altoMm)
        {
            anchoMm = 0.0;
            altoMm = 0.0;

            if (perfil == null ||
                perfil.Curvas == null ||
                perfil.Curvas.Count == 0)
            {
                return;
            }

            double minX = double.MaxValue;
            double minY = double.MaxValue;
            double maxX = double.MinValue;
            double maxY = double.MinValue;

            foreach (Curve c in perfil.Curvas)
            {
                for (int i = 0; i < 2; i++)
                {
                    XYZ p = c.GetEndPoint(i);

                    minX = Math.Min(minX, p.X);
                    minY = Math.Min(minY, p.Y);
                    maxX = Math.Max(maxX, p.X);
                    maxY = Math.Max(maxY, p.Y);
                }
            }

            anchoMm = UnitUtils.ConvertFromInternalUnits(
                maxX - minX,
                UnitTypeId.Millimeters);

            altoMm = UnitUtils.ConvertFromInternalUnits(
                maxY - minY,
                UnitTypeId.Millimeters);
        }

        private string LimpiarNombreArchivo(string nombre)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                return "COL_CAD";

            foreach (char c in Path.GetInvalidFileNameChars())
                nombre = nombre.Replace(c.ToString(), "_");

            nombre = nombre.Replace(" ", "_");
            nombre = nombre.Replace(".", "_");
            nombre = nombre.Replace(":", "_");
            nombre = nombre.Replace(";", "_");
            nombre = nombre.Replace(",", "_");
            nombre = nombre.Replace("|", "_");
            nombre = nombre.Replace("/", "_");
            nombre = nombre.Replace("\\", "_");

            while (nombre.Contains("__"))
                nombre = nombre.Replace("__", "_");

            return nombre.Trim('_');
        }

        // =========================================================
        // CREAR FAMILIA RFA
        // =========================================================

        private ResultadoFamilia CrearFamiliaRfa(
            Autodesk.Revit.ApplicationServices.Application app,
            string rutaPlantilla,
            string rutaRfa,
            PerfilCadCerrado perfil,
            double alturaMm,
            bool sobrescribir,
            bool crearComoPilarEstructural,
            bool bloquearSuperiorInferior)
        {
            ResultadoFamilia resultado = new ResultadoFamilia();

            if (File.Exists(rutaRfa) && sobrescribir)
            {
                try
                {
                    File.Delete(rutaRfa);
                }
                catch
                {
                }
            }

            Document famDoc = null;

            try
            {
                famDoc = app.NewFamilyDocument(rutaPlantilla);

                using (Transaction t = new Transaction(famDoc, "Crear sección desde DWG"))
                {
                    t.Start();

                    if (crearComoPilarEstructural)
                        IntentarAsignarCategoriaPilarEstructural(famDoc);

                    // IMPORTANTE:
                    // No se crea ningún parámetro adicional de material.
                    // Se usa solo el parámetro interno existente:
                    // "Material estructural (por defecto)", porque ese es el que usas en tus tablas.
                    // Si la plantilla permite convertirlo a TIPO, se convierte; si no, Revit lo mantendrá como Ejemplar.

                    Level lowerLevel = ObtenerNivelFamiliaPorNombreOElevacion(
                        famDoc,
                        "Lower Ref. Level",
                        0.0);

                    double alturaInterna = UnitUtils.ConvertToInternalUnits(
                        alturaMm,
                        UnitTypeId.Millimeters);

                    Level upperLevel = ObtenerNivelFamiliaPorNombreOElevacion(
                        famDoc,
                        "Upper Ref. Level",
                        alturaInterna);

                    if (upperLevel != null)
                    {
                        Parameter elevParam = upperLevel.get_Parameter(
                            BuiltInParameter.LEVEL_ELEV);

                        if (elevParam != null && !elevParam.IsReadOnly)
                            elevParam.Set(alturaInterna);
                    }

                    CurveArray perfilCurvas = new CurveArray();

                    foreach (Curve c in perfil.Curvas)
                    {
                        XYZ p0 = c.GetEndPoint(0);
                        XYZ p1 = c.GetEndPoint(1);

                        XYZ q0 = new XYZ(
                            p0.X - perfil.Centro.X,
                            p0.Y - perfil.Centro.Y,
                            0.0);

                        XYZ q1 = new XYZ(
                            p1.X - perfil.Centro.X,
                            p1.Y - perfil.Centro.Y,
                            0.0);

                        if (q0.DistanceTo(q1) <= TOL)
                            continue;

                        perfilCurvas.Append(Line.CreateBound(q0, q1));
                    }

                    CurveArrArray perfiles = new CurveArrArray();
                    perfiles.Append(perfilCurvas);

                    Plane plano = Plane.CreateByNormalAndOrigin(
                        XYZ.BasisZ,
                        XYZ.Zero);

                    SketchPlane sketchPlane = SketchPlane.Create(
                        famDoc,
                        plano);

                    Extrusion extrusion = famDoc.FamilyCreate.NewExtrusion(
                        true,
                        perfiles,
                        sketchPlane,
                        alturaInterna);

                    AjustarParametrosExtrusionInicioFin(
                        extrusion,
                        0.0,
                        alturaInterna);

                    famDoc.Regenerate();

                    resultado.MensajeParametros = CrearParametrosCompartidosTipoYAsignarValores(
                        app,
                        famDoc,
                        perfil);

                    resultado.MensajeMaterial = ConfigurarMaterialDeExtrusionConParametroInterno(
                        famDoc,
                        extrusion);

                    famDoc.Regenerate();

                    if (bloquearSuperiorInferior)
                    {
                        string msg = BloquearExtrusionANivelesReferencia(
                            famDoc,
                            extrusion,
                            lowerLevel,
                            upperLevel);

                        resultado.MensajeRestriccion = msg;
                    }

                    t.Commit();
                }

                SaveAsOptions saveOptions = new SaveAsOptions();
                saveOptions.OverwriteExistingFile = true;

                famDoc.SaveAs(rutaRfa, saveOptions);
            }
            finally
            {
                if (famDoc != null)
                {
                    try
                    {
                        famDoc.Close(false);
                    }
                    catch
                    {
                    }
                }
            }

            return resultado;
        }

        private void IntentarAsignarCategoriaPilarEstructural(Document famDoc)
        {
            try
            {
                if (famDoc == null ||
                    famDoc.OwnerFamily == null ||
                    famDoc.Settings == null ||
                    famDoc.Settings.Categories == null)
                    return;

                Category cat = famDoc.Settings.Categories.get_Item(
                    BuiltInCategory.OST_StructuralColumns);

                if (cat != null)
                    famDoc.OwnerFamily.FamilyCategory = cat;
            }
            catch
            {
            }
        }

        private void AjustarParametrosExtrusionInicioFin(
            Extrusion extrusion,
            double inicio,
            double fin)
        {
            if (extrusion == null)
                return;

            try
            {
                Parameter pStart = extrusion.get_Parameter(
                    BuiltInParameter.EXTRUSION_START_PARAM);

                if (pStart != null && !pStart.IsReadOnly)
                    pStart.Set(inicio);
            }
            catch
            {
            }

            try
            {
                Parameter pEnd = extrusion.get_Parameter(
                    BuiltInParameter.EXTRUSION_END_PARAM);

                if (pEnd != null && !pEnd.IsReadOnly)
                    pEnd.Set(fin);
            }
            catch
            {
            }
        }

        // =========================================================
        // PARÁMETROS COMPARTIDOS DE TIPO
        // =========================================================

        private string CrearParametrosCompartidosTipoYAsignarValores(
            Autodesk.Revit.ApplicationServices.Application app,
            Document famDoc,
            PerfilCadCerrado perfil)
        {
            if (app == null || famDoc == null || perfil == null)
                return "Aviso: no se pudieron crear parámetros porque faltan datos.";

            FamilyManager fm = famDoc.FamilyManager;

            if (fm == null)
                return "Aviso: no se encontró FamilyManager.";

            if (fm.CurrentType == null)
                fm.NewType("Tipo 1");

            FamilyParameter pArea = ObtenerOCrearParametroCompartidoTipo(
                app,
                famDoc,
                NOMBRE_PARAM_AREA_SECCION,
                GUID_AREA_SECCION,
                SpecTypeId.Area);

            FamilyParameter pPerimetro = ObtenerOCrearParametroCompartidoTipo(
                app,
                famDoc,
                NOMBRE_PARAM_PERIMETRO_CURADO,
                GUID_PERIMETRO_CURADO,
                SpecTypeId.Length);

            if (pArea == null)
                throw new Exception("No se pudo crear/encontrar el parámetro compartido de tipo: " + NOMBRE_PARAM_AREA_SECCION);

            if (pPerimetro == null)
                throw new Exception("No se pudo crear/encontrar el parámetro compartido de tipo: " + NOMBRE_PARAM_PERIMETRO_CURADO);

            if (pArea.IsInstance)
            {
                try
                {
                    fm.MakeType(pArea);
                }
                catch
                {
                }
            }

            if (pPerimetro.IsInstance)
            {
                try
                {
                    fm.MakeType(pPerimetro);
                }
                catch
                {
                }
            }

            double areaInterna = perfil.Area; // ft² internos Revit.
            double perimetroInterno = CalcularPerimetroInterno(perfil); // ft internos Revit.

            if (!pArea.IsReadOnly)
                fm.Set(pArea, areaInterna);

            if (!pPerimetro.IsReadOnly)
                fm.Set(pPerimetro, perimetroInterno);

            return "Parámetros OK: área y perímetro creados como TIPO.";
        }

        private FamilyParameter ObtenerOCrearParametroCompartidoTipo(
            Autodesk.Revit.ApplicationServices.Application app,
            Document famDoc,
            string nombreParametro,
            Guid guidParametro,
            ForgeTypeId tipoDato)
        {
            if (app == null || famDoc == null)
                return null;

            FamilyManager fm = famDoc.FamilyManager;

            FamilyParameter existente = BuscarFamilyParameterPorNombre(
                fm,
                nombreParametro);

            if (existente != null)
            {
                try
                {
                    if (existente.IsInstance)
                        fm.MakeType(existente);
                }
                catch
                {
                }

                return existente;
            }

            string archivoOriginal = app.SharedParametersFilename;

            try
            {
                string rutaTemporal = PrepararArchivoParametrosCompartidosTemporal();

                app.SharedParametersFilename = rutaTemporal;

                DefinitionFile defFile = app.OpenSharedParameterFile();

                if (defFile == null)
                    return null;

                DefinitionGroup grupo = defFile.Groups.get_Item(GRUPO_PARAM_ESTRUCTURAS);

                if (grupo == null)
                    grupo = defFile.Groups.Create(GRUPO_PARAM_ESTRUCTURAS);

                Definition definicion = grupo.Definitions.get_Item(nombreParametro);

                if (definicion == null)
                {
                    ExternalDefinitionCreationOptions opciones =
                        new ExternalDefinitionCreationOptions(nombreParametro, tipoDato);

                    opciones.GUID = guidParametro;
                    opciones.Visible = true;
                    opciones.UserModifiable = true;

                    definicion = grupo.Definitions.Create(opciones);
                }

                ExternalDefinition externalDef = definicion as ExternalDefinition;

                if (externalDef == null)
                    return null;

                FamilyParameter nuevoParametro = fm.AddParameter(
                    externalDef,
                    GroupTypeId.Geometry,
                    false); // false = TIPO / grupo COTAS

                return nuevoParametro;
            }
            finally
            {
                try
                {
                    app.SharedParametersFilename = archivoOriginal;
                }
                catch
                {
                }
            }
        }

        private string PrepararArchivoParametrosCompartidosTemporal()
        {
            string carpeta = Path.Combine(
                Path.GetTempPath(),
                "MYG_Revit_SharedParameters");

            if (!Directory.Exists(carpeta))
                Directory.CreateDirectory(carpeta);

            string ruta = Path.Combine(
                carpeta,
                "MYG_Estructuras_SharedParameters.txt");

            // Se reescribe siempre para garantizar GUIDs correctos y evitar archivos temporales antiguos.
            string contenido =
                "# This is a Revit shared parameter file." + Environment.NewLine +
                "# Do not edit manually." + Environment.NewLine +
                "*META\tVERSION\tMINVERSION" + Environment.NewLine +
                "META\t2\t1" + Environment.NewLine +
                "*GROUP\tID\tNAME" + Environment.NewLine +
                "GROUP\t1\tEstructuras" + Environment.NewLine +
                "*PARAM\tGUID\tNAME\tDATATYPE\tDATACATEGORY\tGROUP\tVISIBLE\tDESCRIPTION\tUSERMODIFIABLE\tHIDEWHENNOVALUE" + Environment.NewLine +
                "PARAM\t08bea590-9f22-4070-adab-a9e4112e948c\tÁrea de sección (m²)\tAREA\t\t1\t1\t\t1\t0" + Environment.NewLine +
                "PARAM\t24cbc9d6-b0e5-4c96-a80d-7b5027415e14\tPerímetro de curado\tLENGTH\t\t1\t1\t\t1\t0" + Environment.NewLine;

            File.WriteAllText(ruta, contenido, new UTF8Encoding(true));

            return ruta;
        }

        private FamilyParameter BuscarFamilyParameterPorNombre(
            FamilyManager fm,
            string nombre)
        {
            if (fm == null || string.IsNullOrWhiteSpace(nombre))
                return null;

            foreach (FamilyParameter p in fm.Parameters)
            {
                if (p == null || p.Definition == null)
                    continue;

                if (p.Definition.Name.Equals(
                    nombre,
                    StringComparison.OrdinalIgnoreCase))
                {
                    return p;
                }
            }

            return null;
        }

        // =========================================================
        // MATERIAL DE LA EXTRUSIÓN CON EL PARÁMETRO INTERNO DE REVIT
        // =========================================================

        private string ConfigurarMaterialDeExtrusionConParametroInterno(
            Document famDoc,
            Extrusion extrusion)
        {
            if (famDoc == null || famDoc.FamilyManager == null || extrusion == null)
                return "Aviso: no se pudo configurar el material porque faltan datos.";

            FamilyManager fm = famDoc.FamilyManager;

            Parameter pMaterialExtrusion = null;

            try
            {
                pMaterialExtrusion = extrusion.get_Parameter(BuiltInParameter.MATERIAL_ID_PARAM);
            }
            catch
            {
                pMaterialExtrusion = null;
            }

            if (pMaterialExtrusion == null)
                return "Aviso: no se encontró el parámetro Material de la extrusión.";

            FamilyParameter paramInterno = ObtenerParametroMaterialEstructuralPorDefecto(fm);

            if (paramInterno == null)
                return "Aviso: no se encontró el parámetro interno Material estructural (por defecto).";

            string avisoTipo = "";

            if (paramInterno.IsInstance)
            {
                try
                {
                    fm.MakeType(paramInterno);
                }
                catch
                {
                    avisoTipo = " Revit no permitió convertirlo a TIPO en esta plantilla.";
                }
            }

            try
            {
                FamilyParameter asociadoActual = null;

                try
                {
                    asociadoActual = fm.GetAssociatedFamilyParameter(pMaterialExtrusion);
                }
                catch
                {
                    asociadoActual = null;
                }

                if (asociadoActual == null ||
                    asociadoActual.Definition == null ||
                    paramInterno.Definition == null ||
                    !asociadoActual.Definition.Name.Equals(
                        paramInterno.Definition.Name,
                        StringComparison.OrdinalIgnoreCase))
                {
                    fm.AssociateElementParameterToFamilyParameter(
                        pMaterialExtrusion,
                        paramInterno);
                }

                if (!paramInterno.IsInstance)
                {
                    return "Material OK: la extrusión quedó asociada a Material estructural (por defecto) como parámetro de TIPO.";
                }

                return "Material OK: la extrusión quedó asociada a Material estructural (por defecto), pero sigue como EJEMPLAR." + avisoTipo;
            }
            catch (Exception ex)
            {
                return "Aviso: no se pudo asociar el material de la extrusión al parámetro interno Material estructural (por defecto): " + ex.Message;
            }
        }

        private FamilyParameter ObtenerParametroMaterialEstructuralPorDefecto(
            FamilyManager fm)
        {
            if (fm == null)
                return null;

            FamilyParameter mejorCoincidencia = null;

            try
            {
                foreach (FamilyParameter fp in fm.Parameters)
                {
                    if (fp == null || fp.Definition == null)
                        continue;

                    string nombre = fp.Definition.Name ?? "";
                    string nombreLower = nombre.ToLowerInvariant();

                    if (nombre.Equals("Material estructural", StringComparison.OrdinalIgnoreCase) ||
                        nombre.Equals("Material estructural (por defecto)", StringComparison.OrdinalIgnoreCase) ||
                        nombre.Equals("Structural Material", StringComparison.OrdinalIgnoreCase) ||
                        nombre.Equals("Structural Material (Default)", StringComparison.OrdinalIgnoreCase))
                    {
                        return fp;
                    }

                    if (mejorCoincidencia == null &&
                        nombreLower.Contains("material estructural"))
                    {
                        mejorCoincidencia = fp;
                    }

                    if (mejorCoincidencia == null &&
                        nombreLower.Contains("structural") &&
                        nombreLower.Contains("material"))
                    {
                        mejorCoincidencia = fp;
                    }
                }
            }
            catch
            {
            }

            return mejorCoincidencia;
        }

        // =========================================================
        // BLOQUEAR A LOWER / UPPER REF LEVEL
        // =========================================================

        private string BloquearExtrusionANivelesReferencia(
            Document famDoc,
            Extrusion extrusion,
            Level lowerLevel,
            Level upperLevel)
        {
            if (famDoc == null || extrusion == null)
                return "Aviso: no se pudo bloquear la extrusión porque no existe el documento o la extrusión.";

            if (lowerLevel == null || upperLevel == null)
                return "Aviso: no se encontraron Lower Ref. Level y/o Upper Ref. Level.";

            View vista = ObtenerVistaElevacionParaAlinear(famDoc);

            if (vista == null)
                return "Aviso: no se encontró una vista de elevación para crear los bloqueos.";

            Reference refLower = ObtenerReferenciaNivel(lowerLevel);
            Reference refUpper = ObtenerReferenciaNivel(upperLevel);

            if (refLower == null || refUpper == null)
                return "Aviso: no se pudo obtener la referencia de Lower/Upper Ref. Level.";

            ReferenciasCarasExtrusion refs = ObtenerReferenciasCarasSuperiorInferior(extrusion);

            if (refs == null || refs.RefInferior == null || refs.RefSuperior == null)
                return "Aviso: no se pudieron obtener las referencias de las caras superior/inferior de la extrusión.";

            bool lockInf = IntentarCrearAlineacionBloqueada(
                famDoc,
                vista,
                refLower,
                refs.RefInferior);

            bool lockSup = IntentarCrearAlineacionBloqueada(
                famDoc,
                vista,
                refUpper,
                refs.RefSuperior);

            if (lockInf && lockSup)
                return "Restricción OK: extrusión bloqueada a Lower Ref. Level y Upper Ref. Level.";

            if (lockInf || lockSup)
                return "Aviso: solo se pudo bloquear una cara de la extrusión.";

            return "Aviso: no se pudieron crear los bloqueos de alineación.";
        }

        private bool IntentarCrearAlineacionBloqueada(
            Document famDoc,
            View vista,
            Reference referenciaPlano,
            Reference referenciaCara)
        {
            try
            {
                Dimension dim = famDoc.FamilyCreate.NewAlignment(
                    vista,
                    referenciaPlano,
                    referenciaCara);

                if (dim != null)
                    dim.IsLocked = true;

                return true;
            }
            catch
            {
                return false;
            }
        }

        private ReferenciasCarasExtrusion ObtenerReferenciasCarasSuperiorInferior(
            Extrusion extrusion)
        {
            if (extrusion == null)
                return null;

            Options opt = new Options();
            opt.ComputeReferences = true;
            opt.IncludeNonVisibleObjects = true;
            opt.DetailLevel = ViewDetailLevel.Fine;

            GeometryElement geo = extrusion.get_Geometry(opt);

            if (geo == null)
                return null;

            Reference refInf = null;
            Reference refSup = null;

            double zMin = double.MaxValue;
            double zMax = double.MinValue;

            foreach (GeometryObject obj in geo)
            {
                Solid solid = obj as Solid;

                if (solid == null ||
                    solid.Faces == null ||
                    solid.Faces.Size == 0)
                    continue;

                foreach (Face f in solid.Faces)
                {
                    PlanarFace pf = f as PlanarFace;

                    if (pf == null || pf.Reference == null)
                        continue;

                    XYZ n = pf.FaceNormal;

                    if (n == null)
                        continue;

                    if (Math.Abs(n.Z) < 0.90)
                        continue;

                    double z = pf.Origin.Z;

                    if (n.Z < -0.90 && z < zMin)
                    {
                        zMin = z;
                        refInf = pf.Reference;
                    }

                    if (n.Z > 0.90 && z > zMax)
                    {
                        zMax = z;
                        refSup = pf.Reference;
                    }
                }
            }

            return new ReferenciasCarasExtrusion()
            {
                RefInferior = refInf,
                RefSuperior = refSup
            };
        }

        private Reference ObtenerReferenciaNivel(Level level)
        {
            if (level == null)
                return null;

            try
            {
                MethodInfo mi = typeof(Level).GetMethod(
                    "GetPlaneReference",
                    BindingFlags.Instance | BindingFlags.Public);

                if (mi != null)
                {
                    object obj = mi.Invoke(level, null);
                    Reference r = obj as Reference;

                    if (r != null)
                        return r;
                }
            }
            catch
            {
            }

            try
            {
                PropertyInfo pi = typeof(Level).GetProperty(
                    "Reference",
                    BindingFlags.Instance | BindingFlags.Public);

                if (pi != null)
                {
                    object obj = pi.GetValue(level, null);
                    Reference r = obj as Reference;

                    if (r != null)
                        return r;
                }
            }
            catch
            {
            }

            return null;
        }

        private View ObtenerVistaElevacionParaAlinear(Document famDoc)
        {
            if (famDoc == null)
                return null;

            List<View> vistas = new FilteredElementCollector(famDoc)
                .OfClass(typeof(View))
                .Cast<View>()
                .Where(v => v != null && !v.IsTemplate)
                .ToList();

            View vistaElevacion = vistas
                .Where(v =>
                    v.ViewType == ViewType.Elevation ||
                    v.ViewType == ViewType.Section)
                .FirstOrDefault();

            if (vistaElevacion != null)
                return vistaElevacion;

            return vistas.FirstOrDefault();
        }

        private Level ObtenerNivelFamiliaPorNombreOElevacion(
            Document famDoc,
            string nombre,
            double elevacionDeseada)
        {
            List<Level> niveles = new FilteredElementCollector(famDoc)
                .OfClass(typeof(Level))
                .Cast<Level>()
                .OrderBy(x => x.Elevation)
                .ToList();

            Level porNombre = niveles
                .FirstOrDefault(x =>
                    x != null &&
                    !string.IsNullOrWhiteSpace(x.Name) &&
                    x.Name.Trim().Equals(nombre, StringComparison.OrdinalIgnoreCase));

            if (porNombre != null)
                return porNombre;

            if (niveles.Count == 0)
                return null;

            if (nombre != null &&
                nombre.ToLowerInvariant().Contains("lower"))
            {
                return niveles.FirstOrDefault();
            }

            if (nombre != null &&
                nombre.ToLowerInvariant().Contains("upper"))
            {
                Level superior = niveles.LastOrDefault();

                if (superior != null)
                    return superior;
            }

            return niveles
                .OrderBy(x => Math.Abs(x.Elevation - elevacionDeseada))
                .FirstOrDefault();
        }

        // =========================================================
        // CARGAR Y COLOCAR FAMILIA
        // =========================================================

        private Family CargarFamilia(
            Document doc,
            string rutaRfa,
            bool sobrescribir)
        {
            if (doc == null)
                return null;

            if (string.IsNullOrWhiteSpace(rutaRfa) ||
                !File.Exists(rutaRfa))
            {
                return null;
            }

            Family familia = null;

            using (Transaction t = new Transaction(doc, "Cargar familia CAD"))
            {
                t.Start();

                doc.LoadFamily(
                    rutaRfa,
                    new OpcionesCargaFamilia(sobrescribir),
                    out familia);

                t.Commit();
            }

            return familia;
        }

        private FamilyInstance ColocarFamilia(
            Document doc,
            Family familia,
            XYZ ubicacion,
            Level nivel,
            bool comoPilarEstructural)
        {
            if (doc == null ||
                familia == null ||
                ubicacion == null ||
                nivel == null)
            {
                return null;
            }

            FamilySymbol symbol = ObtenerPrimerTipoFamilia(
                doc,
                familia);

            if (symbol == null)
                return null;

            FamilyInstance instancia = null;

            using (Transaction t = new Transaction(doc, "Colocar familia CAD"))
            {
                t.Start();

                if (!symbol.IsActive)
                {
                    symbol.Activate();
                    doc.Regenerate();
                }

                XYZ punto = new XYZ(
                    ubicacion.X,
                    ubicacion.Y,
                    nivel.Elevation);

                if (comoPilarEstructural)
                {
                    instancia = doc.Create.NewFamilyInstance(
                        punto,
                        symbol,
                        nivel,
                        StructuralType.Column);
                }
                else
                {
                    instancia = doc.Create.NewFamilyInstance(
                        punto,
                        symbol,
                        nivel,
                        StructuralType.NonStructural);
                }

                t.Commit();
            }

            return instancia;
        }

        private FamilySymbol ObtenerPrimerTipoFamilia(
            Document doc,
            Family familia)
        {
            if (doc == null || familia == null)
                return null;

            foreach (ElementId id in familia.GetFamilySymbolIds())
            {
                FamilySymbol fs = doc.GetElement(id) as FamilySymbol;

                if (fs != null)
                    return fs;
            }

            return null;
        }

        private Level ObtenerNivelParaColocacion(Document doc)
        {
            if (doc == null)
                return null;

            try
            {
                ViewPlan viewPlan = doc.ActiveView as ViewPlan;

                if (viewPlan != null && viewPlan.GenLevel != null)
                    return viewPlan.GenLevel;
            }
            catch
            {
            }

            return new FilteredElementCollector(doc)
                .OfClass(typeof(Level))
                .Cast<Level>()
                .OrderBy(x => x.Elevation)
                .FirstOrDefault();
        }

        private void EscribirIdElementoSiExiste(FamilyInstance instancia)
        {
            if (instancia == null)
                return;

            try
            {
                Parameter p = instancia.LookupParameter("GEN_ID Elemento");

                if (p != null && !p.IsReadOnly)
                {
                    using (Transaction t = new Transaction(
                        instancia.Document,
                        "Registrar GEN_ID Elemento"))
                    {
                        t.Start();

                        p.Set(instancia.Id.Value.ToString(CultureInfo.InvariantCulture));

                        t.Commit();
                    }
                }
            }
            catch
            {
            }
        }

        // =========================================================
        // CLASES INTERNAS
        // =========================================================

        private class PerfilCadCerrado
        {
            public int Indice { get; set; }
            public string NombreBloque { get; set; }
            public string NombreCapa { get; set; }
            public List<Curve> Curvas { get; set; }
            public List<XYZ> Puntos { get; set; }
            public XYZ Centro { get; set; }
            public double Area { get; set; }
        }

        private class ResultadoFamilia
        {
            public string MensajeRestriccion { get; set; }
            public string MensajeParametros { get; set; }
            public string MensajeMaterial { get; set; }
        }

        private class ReferenciasCarasExtrusion
        {
            public Reference RefInferior { get; set; }
            public Reference RefSuperior { get; set; }
        }

        private class FiltroDwgImportado : ISelectionFilter
        {
            public bool AllowElement(Element elem)
            {
                return elem is ImportInstance;
            }

            public bool AllowReference(Reference reference, XYZ position)
            {
                return true;
            }
        }

        private class OpcionesCargaFamilia : IFamilyLoadOptions
        {
            private bool sobrescribir;

            public OpcionesCargaFamilia(bool sobrescribirFamilia)
            {
                sobrescribir = sobrescribirFamilia;
            }

            public bool OnFamilyFound(
                bool familyInUse,
                out bool overwriteParameterValues)
            {
                overwriteParameterValues = sobrescribir;
                return true;
            }

            public bool OnSharedFamilyFound(
                Family sharedFamily,
                bool familyInUse,
                out FamilySource source,
                out bool overwriteParameterValues)
            {
                source = FamilySource.Family;
                overwriteParameterValues = sobrescribir;
                return true;
            }
        }
    }
}
