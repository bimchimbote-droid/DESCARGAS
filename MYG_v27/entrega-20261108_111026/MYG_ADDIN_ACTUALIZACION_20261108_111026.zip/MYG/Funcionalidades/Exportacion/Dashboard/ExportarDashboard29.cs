using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // VENTANA 2.7 - EXPORTAR DASHBOARD BIM LOCAL
    // EXPORTADOR LOCAL CSV + DASHBOARD 3D HTML/OBJ
    // SIN USING NI NAMESPACE
    // =====================================


    public static class ExportarDashboard29
    {
        public enum ExportarDataOperacion
        {
            Ninguna = 0,
            Exportar = 1,
            CrearCsvPartidas = 2
        }

        public class ExportarDashboardForm : System.Windows.Forms.Form
        {
            private System.Windows.Forms.TextBox txtCarpeta;
            private System.Windows.Forms.Button btnBuscarCarpeta;
            private System.Windows.Forms.Button btnExportar;
            private System.Windows.Forms.Button btnCerrar;
            private System.Windows.Forms.Button btnPrecios;
            private System.Windows.Forms.CheckBox chkSoloVistaActiva;
            private System.Windows.Forms.CheckBox chkSoloCategoriasModelo;
            private System.Windows.Forms.CheckBox chkParametrosInstancia;
            private System.Windows.Forms.CheckBox chkParametrosTipo;
            private System.Windows.Forms.CheckBox chkIncluirSinCategoria;
            private System.Windows.Forms.CheckBox chkExportarVisor3D;
            private System.Windows.Forms.CheckBox chkHtmlEmbebido;
            private System.Windows.Forms.CheckBox chkObjSeparado;
            private System.Windows.Forms.RichTextBox txtResultado;
            private System.Windows.Forms.Label lblEstado;
            private bool usarPreciosEnTablas;
            private string rutaCsvPrecios;

            public Autodesk.Revit.UI.ExternalEvent EjecutarEvent;
            public global::MYG_Addin.EjecutarExportarDashboardHandler Handler;

            public ExportarDashboardForm()
            {
                this.Text = "📊 Exportar Dashboard BIM Local";
                this.Width = 660;
                this.Height = 690;
                this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
                this.MaximizeBox = false;
                this.MinimizeBox = true;
                this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
                this.Font = new System.Drawing.Font("Segoe UI", 9F);
                this.TopMost = true;

                System.Windows.Forms.Label lblAutor = new System.Windows.Forms.Label()
                {
                    Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                    Left = 20,
                    Top = 10,
                    Width = 600,
                    Height = 20,
                    Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                    ForeColor = System.Drawing.Color.Gray
                };

                System.Windows.Forms.Label lblTitulo = new System.Windows.Forms.Label()
                {
                    Text = "PANEL 2 - BOTÓN 2.7 | EXPORTAR DASHBOARD BIM LOCAL",
                    Left = 20,
                    Top = 42,
                    Width = 600,
                    Height = 24,
                    Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold),
                    ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
                };

                System.Windows.Forms.Label lblDescripcion = new System.Windows.Forms.Label()
                {
                    Text = "Exporta información del modelo nativo a CSV y genera un dashboard 3D local HTML/OBJ para visualizar el modelo sin ACC ni Data Exchange.",
                    Left = 20,
                    Top = 70,
                    Width = 600,
                    Height = 48,
                    ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
                };

                System.Windows.Forms.Label lblCarpeta = new System.Windows.Forms.Label()
                {
                    Text = "Carpeta base de exportación:",
                    Left = 20,
                    Top = 125,
                    Width = 250,
                    Height = 22,
                    ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
                };

                txtCarpeta = new System.Windows.Forms.TextBox()
                {
                    Left = 20,
                    Top = 150,
                    Width = 475,
                    Height = 25,
                    BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
                };

                btnBuscarCarpeta = CrearBotonAccion(
                    "BUSCAR",
                    505,
                    148,
                    115,
                    System.Drawing.Color.FromArgb(90, 90, 90));

                System.Windows.Forms.GroupBox grpData = new System.Windows.Forms.GroupBox()
                {
                    Text = "Data CSV para análisis",
                    Left = 20,
                    Top = 190,
                    Width = 600,
                    Height = 145,
                    ForeColor = System.Drawing.Color.FromArgb(55, 55, 55)
                };

                chkSoloVistaActiva = CrearCheck(
                    "Exportar solo elementos visibles en la vista activa",
                    15,
                    25,
                    false);

                chkSoloCategoriasModelo = CrearCheck(
                    "Exportar solo categorías de modelo",
                    15,
                    52,
                    true);

                chkParametrosInstancia = CrearCheck(
                    "Exportar parámetros de instancia",
                    15,
                    79,
                    true);

                chkParametrosTipo = CrearCheck(
                    "Exportar parámetros de tipo",
                    15,
                    106,
                    true);

                grpData.Controls.Add(chkSoloVistaActiva);
                grpData.Controls.Add(chkSoloCategoriasModelo);
                grpData.Controls.Add(chkParametrosInstancia);
                grpData.Controls.Add(chkParametrosTipo);

                System.Windows.Forms.GroupBox grpVisor = new System.Windows.Forms.GroupBox()
                {
                    Text = "Dashboard 3D local",
                    Left = 20,
                    Top = 345,
                    Width = 600,
                    Height = 100,
                    ForeColor = System.Drawing.Color.FromArgb(55, 55, 55)
                };

                chkExportarVisor3D = CrearCheck(
                    "Exportar dashboard 3D local HTML/OBJ",
                    15,
                    25,
                    true);

                chkHtmlEmbebido = CrearCheck(
                    "HTML dashboard con modelo embebido",
                    15,
                    52,
                    true);

                chkObjSeparado = CrearCheck(
                    "Guardar OBJ/MTL separados para pruebas",
                    310,
                    52,
                    true);

                grpVisor.Controls.Add(chkExportarVisor3D);
                grpVisor.Controls.Add(chkHtmlEmbebido);
                grpVisor.Controls.Add(chkObjSeparado);

                chkIncluirSinCategoria = CrearCheck(
                    "Incluir elementos sin categoría",
                    20,
                    455,
                    false);

                btnExportar = CrearBotonAccion(
                    "EXPORTAR DASHBOARD",
                    20,
                    490,
                    210,
                    System.Drawing.Color.FromArgb(0, 120, 215));

                btnCerrar = CrearBotonAccion(
                    "CERRAR",
                    240,
                    490,
                    120,
                    System.Drawing.Color.FromArgb(70, 70, 70));

                btnPrecios = CrearBotonAccion(
                    "USAR PRECIOS EN TABLAS",
                    370,
                    490,
                    250,
                    System.Drawing.Color.FromArgb(22, 120, 90));

                lblEstado = new System.Windows.Forms.Label()
                {
                    Text = "Listo.",
                    Left = 20,
                    Top = 532,
                    Width = 600,
                    Height = 20,
                    ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
                };

                System.Windows.Forms.Label lblResultado = new System.Windows.Forms.Label()
                {
                    Text = "RESULTADO",
                    Left = 20,
                    Top = 558,
                    Width = 600,
                    Height = 18,
                    Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                    ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
                };

                txtResultado = new System.Windows.Forms.RichTextBox()
                {
                    Left = 20,
                    Top = 578,
                    Width = 600,
                    Height = 35,
                    Multiline = true,
                    ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical,
                    ReadOnly = true,
                    BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                    BackColor = System.Drawing.Color.White,
                    Font = new System.Drawing.Font("Consolas", 8.5F),
                    WordWrap = false
                };

                btnBuscarCarpeta.Click += (s, e) =>
                {
                    BuscarCarpeta();
                };

                btnExportar.Click += (s, e) =>
                {
                    SolicitarExportacion();
                };

                btnCerrar.Click += (s, e) =>
                {
                    this.Close();
                };

                btnPrecios.Click += (s, e) =>
                {
                    AbrirVentanaPrecios();
                };

                chkExportarVisor3D.CheckedChanged += (s, e) =>
                {
                    chkHtmlEmbebido.Enabled = chkExportarVisor3D.Checked;
                    chkObjSeparado.Enabled = chkExportarVisor3D.Checked;
                };

                Controls.Add(lblAutor);
                Controls.Add(lblTitulo);
                Controls.Add(lblDescripcion);
                Controls.Add(lblCarpeta);
                Controls.Add(txtCarpeta);
                Controls.Add(btnBuscarCarpeta);
                Controls.Add(grpData);
                Controls.Add(grpVisor);
                Controls.Add(chkIncluirSinCategoria);
                Controls.Add(btnExportar);
                Controls.Add(btnCerrar);
                Controls.Add(btnPrecios);
                Controls.Add(lblEstado);
                Controls.Add(lblResultado);
                Controls.Add(txtResultado);

                string escritorio = System.Environment.GetFolderPath(System.Environment.SpecialFolder.DesktopDirectory);
                txtCarpeta.Text = System.IO.Path.Combine(escritorio, "MYG_DASHBOARD_EXPORT");
                usarPreciosEnTablas = false;
                rutaCsvPrecios = "";

                MostrarResultado(
                    "Generará CSV + Viewer/index.html + Viewer/modelo.obj.");
            }

            private System.Windows.Forms.CheckBox CrearCheck(
                string texto,
                int left,
                int top,
                bool marcado)
            {
                System.Windows.Forms.CheckBox chk = new System.Windows.Forms.CheckBox()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = 560,
                    Height = 24,
                    Checked = marcado,
                    ForeColor = System.Drawing.Color.FromArgb(55, 55, 55)
                };

                return chk;
            }

            private System.Windows.Forms.Button CrearBotonAccion(
                string texto,
                int left,
                int top,
                int width,
                System.Drawing.Color color)
            {
                System.Windows.Forms.Button boton = new System.Windows.Forms.Button()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 34,
                    BackColor = color,
                    ForeColor = System.Drawing.Color.White,
                    FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                    Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                    Cursor = System.Windows.Forms.Cursors.Hand
                };

                boton.FlatAppearance.BorderSize = 0;

                return boton;
            }

            private void BuscarCarpeta()
            {
                using (System.Windows.Forms.FolderBrowserDialog dialog =
                    new System.Windows.Forms.FolderBrowserDialog())
                {
                    dialog.Description = "Selecciona la carpeta base donde se creará la exportación.";
                    dialog.ShowNewFolderButton = true;

                    if (!string.IsNullOrWhiteSpace(txtCarpeta.Text) && System.IO.Directory.Exists(txtCarpeta.Text))
                        dialog.SelectedPath = txtCarpeta.Text;

                    System.Windows.Forms.DialogResult result = dialog.ShowDialog(this);

                    if (result == System.Windows.Forms.DialogResult.OK)
                    {
                        txtCarpeta.Text = dialog.SelectedPath;
                        MostrarEstado("Carpeta seleccionada.");
                    }
                }
            }

            private void AbrirVentanaPrecios()
            {
                PreciosTablasForm form = new PreciosTablasForm(this, usarPreciosEnTablas, rutaCsvPrecios);
                form.Show(this);
            }

            public void ConfigurarPreciosEnTablas(bool usar, string ruta)
            {
                usarPreciosEnTablas = usar;
                rutaCsvPrecios = ruta == null ? "" : ruta.Trim();

                if (usarPreciosEnTablas)
                    MostrarEstado("Precios en tablas activado: " + rutaCsvPrecios);
                else
                    MostrarEstado("Precios en tablas desactivado.");
            }

            public void SolicitarCrearCsvPartidas(string pathCsv)
            {
                if (EjecutarEvent == null || Handler == null)
                {
                    MostrarResultado("No se pudo inicializar el evento externo.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(pathCsv))
                {
                    MostrarResultado("Debes indicar dónde guardar el CSV de partidas.");
                    return;
                }

                try
                {
                    string dir = System.IO.Path.GetDirectoryName(pathCsv);

                    if (!string.IsNullOrWhiteSpace(dir))
                        System.IO.Directory.CreateDirectory(dir);
                }
                catch (System.Exception ex)
                {
                    MostrarResultado("No se pudo acceder a la carpeta del CSV:\r\n" + ex.Message);
                    return;
                }

                Handler.FormInicial = this;
                Handler.Operacion = ExportarDataOperacion.CrearCsvPartidas;
                Handler.RutaCsvPartidasDestino = pathCsv;

                if (btnExportar != null)
                    btnExportar.Enabled = false;

                if (btnPrecios != null)
                    btnPrecios.Enabled = false;

                MostrarEstado("Creando CSV de partidas...");
                MostrarResultado("Leyendo tablas de planificación para generar plantilla de precios...");

                EjecutarEvent.Raise();
            }

            private void SolicitarExportacion()
            {
                if (EjecutarEvent == null || Handler == null)
                {
                    MostrarResultado("No se pudo inicializar el evento externo.");
                    return;
                }

                string carpeta = "";

                if (txtCarpeta != null && txtCarpeta.Text != null)
                    carpeta = txtCarpeta.Text.Trim();

                if (string.IsNullOrWhiteSpace(carpeta))
                {
                    MostrarResultado("Debes indicar una carpeta de exportación.");
                    return;
                }

                try
                {
                    System.IO.Directory.CreateDirectory(carpeta);
                }
                catch (System.Exception ex)
                {
                    MostrarResultado("No se pudo crear/acceder a la carpeta:\r\n" + ex.Message);
                    return;
                }

                Handler.FormInicial = this;
                Handler.Operacion = ExportarDataOperacion.Exportar;
                Handler.CarpetaBase = carpeta;
                Handler.SoloVistaActiva = chkSoloVistaActiva.Checked;
                Handler.SoloCategoriasModelo = chkSoloCategoriasModelo.Checked;
                Handler.ExportarParametrosInstancia = chkParametrosInstancia.Checked;
                Handler.ExportarParametrosTipo = chkParametrosTipo.Checked;
                Handler.IncluirElementosSinCategoria = chkIncluirSinCategoria.Checked;
                if (usarPreciosEnTablas)
                {
                    if (string.IsNullOrWhiteSpace(rutaCsvPrecios) || !System.IO.File.Exists(rutaCsvPrecios))
                    {
                        MostrarResultado("Activaste precios en tablas, pero el CSV no existe o no fue seleccionado.\r\n" +
                            "Abre 'Usar precios en tablas' y selecciona el CSV llenado.");
                        return;
                    }
                }

                Handler.ExportarVisor3D = chkExportarVisor3D.Checked;
                Handler.HtmlVisorEmbebido = chkHtmlEmbebido.Checked;
                Handler.ExportarObjSeparado = chkObjSeparado.Checked;
                Handler.UsarPreciosEnTablas = usarPreciosEnTablas;
                Handler.RutaCsvPrecios = rutaCsvPrecios;

                btnExportar.Enabled = false;
                MostrarEstado("Exportando data y visor 3D...");
                MostrarResultado("Procesando elementos y geometría. Espera unos segundos...");

                EjecutarEvent.Raise();
            }

            public void FinalizarExportacion(string resultado, bool correcto)
            {
                if (this.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() =>
                    {
                        FinalizarExportacion(resultado, correcto);
                    }));

                    return;
                }

                if (btnExportar != null && !btnExportar.IsDisposed)
                    btnExportar.Enabled = true;

                if (btnPrecios != null && !btnPrecios.IsDisposed)
                    btnPrecios.Enabled = true;

                MostrarEstado(correcto ? "Exportación terminada." : "Exportación con error.");
                MostrarResultado(resultado);
            }

            public void MostrarEstado(string texto)
            {
                if (lblEstado == null || lblEstado.IsDisposed)
                    return;

                if (lblEstado.InvokeRequired)
                {
                    lblEstado.BeginInvoke(new System.Action(() =>
                    {
                        MostrarEstado(texto);
                    }));

                    return;
                }

                lblEstado.Text = texto;
            }

            public void MostrarResultado(string texto)
            {
                if (txtResultado == null || txtResultado.IsDisposed)
                    return;

                if (txtResultado.InvokeRequired)
                {
                    txtResultado.BeginInvoke(new System.Action(() =>
                    {
                        MostrarResultado(texto);
                    }));

                    return;
                }

                txtResultado.Clear();

                if (string.IsNullOrWhiteSpace(texto))
                    return;

                string[] lineas = texto.Replace("\r\n", "\n").Split('\n');

                foreach (string linea in lineas)
                {
                    if (linea.ToUpperInvariant().Contains("ERROR"))
                    {
                        txtResultado.SelectionColor = System.Drawing.Color.Red;
                        txtResultado.SelectionFont = new System.Drawing.Font("Consolas", 8.5F, System.Drawing.FontStyle.Bold);
                    }
                    else if (linea.ToUpperInvariant().Contains("EXPORTADO") ||
                             linea.ToUpperInvariant().Contains("TERMINADA"))
                    {
                        txtResultado.SelectionColor = System.Drawing.Color.FromArgb(30, 120, 30);
                        txtResultado.SelectionFont = new System.Drawing.Font("Consolas", 8.5F, System.Drawing.FontStyle.Bold);
                    }
                    else
                    {
                        txtResultado.SelectionColor = System.Drawing.Color.FromArgb(50, 50, 50);
                        txtResultado.SelectionFont = new System.Drawing.Font("Consolas", 8.5F, System.Drawing.FontStyle.Regular);
                    }

                    txtResultado.AppendText(linea + System.Environment.NewLine);
                }

                txtResultado.SelectionStart = 0;
                txtResultado.ScrollToCaret();
            }
        }

        public class PreciosTablasForm : System.Windows.Forms.Form
        {
            private ExportarDashboardForm formPadre;
            private System.Windows.Forms.CheckBox chkUsarPrecios;
            private System.Windows.Forms.TextBox txtCsvPrecios;
            private System.Windows.Forms.Button btnBuscarCsv;
            private System.Windows.Forms.Button btnCrearCsv;
            private System.Windows.Forms.Button btnAceptar;
            private System.Windows.Forms.Button btnCancelar;
            private System.Windows.Forms.Label lblInfo;

            public PreciosTablasForm(
                ExportarDashboardForm padre,
                bool usarActual,
                string rutaActual)
            {
                formPadre = padre;

                this.Text = "Usar precios en tablas";
                this.Width = 640;
                this.Height = 330;
                this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
                this.MaximizeBox = false;
                this.MinimizeBox = false;
                this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
                this.Font = new System.Drawing.Font("Segoe UI", 9F);
                this.TopMost = true;

                System.Windows.Forms.Label lblTitulo = new System.Windows.Forms.Label()
                {
                    Text = "PRECIOS EN TABLAS DE PLANIFICACIÓN",
                    Left = 20,
                    Top = 18,
                    Width = 590,
                    Height = 24,
                    Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold),
                    ForeColor = System.Drawing.Color.FromArgb(40, 40, 40)
                };

                lblInfo = new System.Windows.Forms.Label()
                {
                    Text = "1) Crea el CSV de partidas. 2) Llena PrecioUnitario. 3) Selecciona ese CSV para que el dashboard calcule P.U. y Parcial.",
                    Left = 20,
                    Top = 48,
                    Width = 590,
                    Height = 42,
                    ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
                };

                chkUsarPrecios = new System.Windows.Forms.CheckBox()
                {
                    Text = "Usar precios en tablas al exportar dashboard",
                    Left = 20,
                    Top = 95,
                    Width = 500,
                    Height = 24,
                    Checked = usarActual,
                    ForeColor = System.Drawing.Color.FromArgb(55, 55, 55)
                };

                System.Windows.Forms.Label lblCsv = new System.Windows.Forms.Label()
                {
                    Text = "CSV de precios unitarios llenado:",
                    Left = 20,
                    Top = 130,
                    Width = 300,
                    Height = 22,
                    ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
                };

                txtCsvPrecios = new System.Windows.Forms.TextBox()
                {
                    Left = 20,
                    Top = 155,
                    Width = 455,
                    Height = 25,
                    Text = rutaActual == null ? "" : rutaActual,
                    BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
                };

                btnBuscarCsv = CrearBoton("BUSCAR CSV", 485, 153, 125, System.Drawing.Color.FromArgb(90, 90, 90));
                btnCrearCsv = CrearBoton("CREAR CSV DE PARTIDAS", 20, 200, 220, System.Drawing.Color.FromArgb(0, 120, 215));
                btnAceptar = CrearBoton("ACEPTAR", 360, 245, 115, System.Drawing.Color.FromArgb(22, 120, 90));
                btnCancelar = CrearBoton("CERRAR", 490, 245, 120, System.Drawing.Color.FromArgb(70, 70, 70));

                btnBuscarCsv.Click += (s, e) => BuscarCsvPrecios();
                btnCrearCsv.Click += (s, e) => CrearCsvPartidas();
                btnAceptar.Click += (s, e) => Aceptar();
                btnCancelar.Click += (s, e) => this.Close();

                Controls.Add(lblTitulo);
                Controls.Add(lblInfo);
                Controls.Add(chkUsarPrecios);
                Controls.Add(lblCsv);
                Controls.Add(txtCsvPrecios);
                Controls.Add(btnBuscarCsv);
                Controls.Add(btnCrearCsv);
                Controls.Add(btnAceptar);
                Controls.Add(btnCancelar);
            }

            private System.Windows.Forms.Button CrearBoton(string texto, int left, int top, int width, System.Drawing.Color color)
            {
                System.Windows.Forms.Button boton = new System.Windows.Forms.Button()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 34,
                    BackColor = color,
                    ForeColor = System.Drawing.Color.White,
                    FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                    Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                    Cursor = System.Windows.Forms.Cursors.Hand
                };

                boton.FlatAppearance.BorderSize = 0;
                return boton;
            }

            private void BuscarCsvPrecios()
            {
                using (System.Windows.Forms.OpenFileDialog dialog = new System.Windows.Forms.OpenFileDialog())
                {
                    dialog.Title = "Selecciona el CSV de precios unitarios";
                    dialog.Filter = "CSV (*.csv)|*.csv|Todos los archivos (*.*)|*.*";
                    dialog.Multiselect = false;

                    if (!string.IsNullOrWhiteSpace(txtCsvPrecios.Text))
                    {
                        string dir = System.IO.Path.GetDirectoryName(txtCsvPrecios.Text);

                        if (!string.IsNullOrWhiteSpace(dir) && System.IO.Directory.Exists(dir))
                            dialog.InitialDirectory = dir;
                    }

                    if (dialog.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
                        txtCsvPrecios.Text = dialog.FileName;
                }
            }

            private void CrearCsvPartidas()
            {
                using (System.Windows.Forms.SaveFileDialog dialog = new System.Windows.Forms.SaveFileDialog())
                {
                    dialog.Title = "Crear CSV de partidas para precios unitarios";
                    dialog.Filter = "CSV (*.csv)|*.csv";
                    dialog.FileName = "Precios_Unitarios.csv";

                    if (!string.IsNullOrWhiteSpace(txtCsvPrecios.Text))
                    {
                        string dir = System.IO.Path.GetDirectoryName(txtCsvPrecios.Text);

                        if (!string.IsNullOrWhiteSpace(dir) && System.IO.Directory.Exists(dir))
                            dialog.InitialDirectory = dir;
                    }

                    if (dialog.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
                    {
                        txtCsvPrecios.Text = dialog.FileName;
                        chkUsarPrecios.Checked = true;

                        if (formPadre != null && !formPadre.IsDisposed)
                            formPadre.SolicitarCrearCsvPartidas(dialog.FileName);
                    }
                }
            }

            private void Aceptar()
            {
                string ruta = txtCsvPrecios.Text == null ? "" : txtCsvPrecios.Text.Trim();

                if (chkUsarPrecios.Checked)
                {
                    if (string.IsNullOrWhiteSpace(ruta) || !System.IO.File.Exists(ruta))
                    {
                        System.Windows.Forms.MessageBox.Show(
                            this,
                            "Selecciona un CSV de precios válido antes de activar esta opción.",
                            "MYG - Precios en tablas",
                            System.Windows.Forms.MessageBoxButtons.OK,
                            System.Windows.Forms.MessageBoxIcon.Warning);
                        return;
                    }
                }

                if (formPadre != null && !formPadre.IsDisposed)
                    formPadre.ConfigurarPreciosEnTablas(chkUsarPrecios.Checked, ruta);

                this.Close();
            }
        }

    }

}
