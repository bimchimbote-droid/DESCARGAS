﻿
// =====================================
// HELPER 2.7 - DASHBOARD 3D LOCAL
// EXPORTA OBJ/MTL + HTML DASHBOARD + RELACIONES + DIM_VISOR.CSV
// FILTRA ORIGENES/FUENTES DE LUZ ANIDADAS
// SIN ACC / SIN DATA EXCHANGE
// CON USING Y NAMESPACE
// =====================================


using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace MYG_Addin
{
    public static class MYG_DashboardLocalHelper
    {
        private static readonly System.Globalization.CultureInfo CI = System.Globalization.CultureInfo.InvariantCulture;

        public class ExportResult
        {
            public string ViewerFolder { get; set; }
            public string HtmlPath { get; set; }
            public string ObjPath { get; set; }
            public string MtlPath { get; set; }
            public string JsonPath { get; set; }
            public string DashboardJsonPath { get; set; }
            public string CsvPath { get; set; }
            public string ViewerUrl { get; set; }
            public int ElementosConGeometria { get; set; }
            public int TotalTriangulos { get; set; }
            public int TablasPlanificacion { get; set; }
            public string PreciosUnitariosPath { get; set; }
            public string PreciosPlantillaPath { get; set; }
        }

        private class VisorItem
        {
            public string Modelo { get; set; }
            public string ElementId { get; set; }
            public long ElementIdValor { get; set; }
            public string UniqueId { get; set; }
            public string MeshName { get; set; }
            public string Categoria { get; set; }
            public string Nombre { get; set; }
            public int Triangulos { get; set; }
            public string ColorHex { get; set; }
        }

        private class ObjContext
        {
            public System.Text.StringBuilder Obj = new System.Text.StringBuilder();
            public System.Text.StringBuilder Mtl = new System.Text.StringBuilder();
            public System.Collections.Generic.HashSet<string> Materiales = new System.Collections.Generic.HashSet<string>();
            public System.Collections.Generic.Dictionary<string, string> MaterialesHex =
                new System.Collections.Generic.Dictionary<string, string>(System.StringComparer.OrdinalIgnoreCase);
            public System.Collections.Generic.List<VisorItem> Items = new System.Collections.Generic.List<VisorItem>();

            // Optimización para modelos medianos/grandes:
            // antes se escribían 3 vértices nuevos por cada triángulo, generando OBJ enormes.
            // Ahora se reutilizan vértices por coordenada redondeada, reduciendo peso y memoria en el navegador.
            public System.Collections.Generic.Dictionary<string, int> VertexMap =
                new System.Collections.Generic.Dictionary<string, int>(System.StringComparer.OrdinalIgnoreCase);

            public int VertexIndex = 0;
            public int TotalTriangulos = 0;
            public int TotalLineas = 0;
        }

        private class ScheduleInfo
        {
            public string ScheduleId { get; set; }
            public string Codigo { get; set; }
            public string Nombre { get; set; }
            public string Tipo { get; set; }
            public string Unidad { get; set; }
            public string MetradoTotalTexto { get; set; }
            public double MetradoTotal { get; set; }
            public string PrecioUnitarioTexto { get; set; }
            public double PrecioUnitario { get; set; }
            public string ParcialTexto { get; set; }
            public double Parcial { get; set; }
            public bool TienePrecio { get; set; }
            public System.Collections.Generic.List<string> ElementIds = new System.Collections.Generic.List<string>();
        }

        private class PrecioUnitarioInfo
        {
            public string Codigo { get; set; }
            public string Unidad { get; set; }
            public double PrecioUnitario { get; set; }
            public string PrecioUnitarioTexto { get; set; }
        }

        public static ExportResult Exportar(
            Autodesk.Revit.DB.Document doc,
            string carpetaExportacion,
            bool soloVistaActiva,
            bool soloCategoriasModelo,
            bool incluirElementosSinCategoria,
            bool htmlEmbebido,
            bool exportarObjSeparado,
            bool usarPreciosEnTablas,
            string rutaCsvPrecios)
        {
            if (doc == null)
                throw new System.Exception("Documento inválido para exportar dashboard 3D.");

            if (string.IsNullOrWhiteSpace(carpetaExportacion))
                throw new System.Exception("Carpeta de exportación inválida para dashboard 3D.");

            string carpetaViewer = System.IO.Path.Combine(carpetaExportacion, "Viewer");
            System.IO.Directory.CreateDirectory(carpetaViewer);

            string pathObj = System.IO.Path.Combine(carpetaViewer, "modelo.obj");
            string pathMtl = System.IO.Path.Combine(carpetaViewer, "modelo.mtl");
            string pathJson = System.IO.Path.Combine(carpetaViewer, "relaciones.json");
            string pathDashboardJson = System.IO.Path.Combine(carpetaViewer, "dashboard_data.json");
            string pathSchedulesJson = System.IO.Path.Combine(carpetaViewer, "schedules_data.json");
            string pathHtml = System.IO.Path.Combine(carpetaViewer, "index.html");
            string pathCsv = System.IO.Path.Combine(carpetaExportacion, "Dim_Visor.csv");
            string pathPreciosPlantilla = "";
            string pathPreciosBase = LimpiarRutaCsvPrecios(rutaCsvPrecios);
            string viewerUrl = CrearFileUrl(pathHtml);

            ObjContext ctx = new ObjContext();

            ctx.Obj.AppendLine("# MYG - OBJ exportado desde Revit");
            ctx.Obj.AppendLine("# Modelo: " + (doc.Title ?? ""));
            ctx.Obj.AppendLine("mtllib modelo.mtl");
            ctx.Obj.AppendLine("");

            ctx.Mtl.AppendLine("# MYG - Materiales por categoría");
            ctx.Mtl.AppendLine("");

            System.Collections.Generic.IEnumerable<Autodesk.Revit.DB.Element> elementos = ObtenerElementosBase(doc, soloVistaActiva);

            foreach (Autodesk.Revit.DB.Element e in elementos)
            {
                try
                {
                    if (!EsElementoExportable(doc, e, soloCategoriasModelo, incluirElementosSinCategoria))
                        continue;

                    ExportarElementoObj(doc, e, ctx, soloVistaActiva);
                }
                catch
                {
                }
            }

            if (exportarObjSeparado || !htmlEmbebido)
            {
                System.IO.File.WriteAllText(pathObj, ctx.Obj.ToString(), new System.Text.UTF8Encoding(true));
                System.IO.File.WriteAllText(pathMtl, ctx.Mtl.ToString(), new System.Text.UTF8Encoding(true));
            }

            string relacionesJson = CrearRelacionesJson(ctx.Items);
            System.IO.File.WriteAllText(pathJson, relacionesJson, new System.Text.UTF8Encoding(true));

            string dashboardJson = CrearDashboardJson(ctx.Items);
            System.IO.File.WriteAllText(pathDashboardJson, dashboardJson, new System.Text.UTF8Encoding(true));

            System.Collections.Generic.Dictionary<string, PrecioUnitarioInfo> preciosUnitarios =
                usarPreciosEnTablas ? LeerPreciosUnitarios(pathPreciosBase) :
                new System.Collections.Generic.Dictionary<string, PrecioUnitarioInfo>(System.StringComparer.OrdinalIgnoreCase);

            System.Collections.Generic.List<ScheduleInfo> schedules = ObtenerSchedules(doc, ctx.Items, preciosUnitarios);

            string schedulesJson = CrearSchedulesJson(schedules);
            System.IO.File.WriteAllText(pathSchedulesJson, schedulesJson, new System.Text.UTF8Encoding(true));

            string materialesJson = CrearMaterialesJson(ctx.MaterialesHex);

            string objBase64 = System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(ctx.Obj.ToString()));
            string html = CrearHtmlViewer(
                doc.Title ?? "Modelo Revit",
                objBase64,
                relacionesJson,
                dashboardJson,
                schedulesJson,
                materialesJson,
                htmlEmbebido,
                CrearFileUrl(pathObj));

            System.IO.File.WriteAllText(pathHtml, html, new System.Text.UTF8Encoding(true));

            System.Collections.Generic.List<string> csv = new System.Collections.Generic.List<string>();
            csv.Add(Csv(
                "Modelo",
                "ElementId",
                "UniqueId",
                "MeshName",
                "Categoria",
                "Nombre",
                "Triangulos",
                "ColorHex",
                "ViewerHtmlUrl",
                "ViewerElementUrl",
                "HtmlPath",
                "ObjPath"));

            System.Collections.Generic.List<VisorItem> itemsOrdenados = new System.Collections.Generic.List<VisorItem>(ctx.Items);
            itemsOrdenados.Sort((a, b) => a.ElementIdValor.CompareTo(b.ElementIdValor));

            foreach (VisorItem item in itemsOrdenados)
            {
                csv.Add(Csv(
                    item.Modelo,
                    item.ElementId,
                    item.UniqueId,
                    item.MeshName,
                    item.Categoria,
                    item.Nombre,
                    item.Triangulos.ToString(CI),
                    item.ColorHex,
                    viewerUrl,
                    viewerUrl + "?id=" + item.ElementId,
                    pathHtml,
                    pathObj));
            }

            System.IO.File.WriteAllLines(pathCsv, csv, new System.Text.UTF8Encoding(true));

            return new ExportResult()
            {
                ViewerFolder = carpetaViewer,
                HtmlPath = pathHtml,
                ObjPath = pathObj,
                MtlPath = pathMtl,
                JsonPath = pathJson,
                DashboardJsonPath = pathDashboardJson,
                CsvPath = pathCsv,
                ViewerUrl = viewerUrl,
                ElementosConGeometria = ctx.Items.Count,
                TotalTriangulos = ctx.TotalTriangulos,
                TablasPlanificacion = schedules.Count,
                PreciosUnitariosPath = pathPreciosBase,
                PreciosPlantillaPath = pathPreciosPlantilla
            };
        }

        public static string CrearCsvPartidas(
            Autodesk.Revit.DB.Document doc,
            string pathCsvDestino)
        {
            if (doc == null)
                throw new System.Exception("Documento inválido para crear CSV de partidas.");

            if (string.IsNullOrWhiteSpace(pathCsvDestino))
                throw new System.Exception("Ruta inválida para crear CSV de partidas.");

            string carpeta = System.IO.Path.GetDirectoryName(pathCsvDestino);

            if (!string.IsNullOrWhiteSpace(carpeta))
                System.IO.Directory.CreateDirectory(carpeta);

            System.Collections.Generic.Dictionary<string, PrecioUnitarioInfo> preciosVacios =
                new System.Collections.Generic.Dictionary<string, PrecioUnitarioInfo>(System.StringComparer.OrdinalIgnoreCase);

            System.Collections.Generic.List<ScheduleInfo> schedules =
                ObtenerSchedules(doc, new System.Collections.Generic.List<VisorItem>(), preciosVacios);

            System.Collections.Generic.List<string> lineas = CrearLineasPlantillaPrecios(schedules, true);
            System.IO.File.WriteAllLines(pathCsvDestino, lineas, new System.Text.UTF8Encoding(true));

            return
                "CSV DE PARTIDAS CREADO" + System.Environment.NewLine +
                "----------------------------------------" + System.Environment.NewLine +
                "Tablas detectadas: " + schedules.Count.ToString(CI) + System.Environment.NewLine +
                "Archivo:" + System.Environment.NewLine +
                pathCsvDestino + System.Environment.NewLine + System.Environment.NewLine +
                "Llena la columna PrecioUnitario, guarda el archivo como CSV y luego selecciónalo desde 'Usar precios en tablas'.";
        }

        private static System.Collections.Generic.IEnumerable<Autodesk.Revit.DB.Element> ObtenerElementosBase(Autodesk.Revit.DB.Document doc, bool soloVistaActiva)
        {
            Autodesk.Revit.DB.FilteredElementCollector collector;

            Autodesk.Revit.DB.View vistaActiva = ObtenerVistaActivaValida(doc);

            // Para el dashboard 3D se prioriza la vista activa si es una vista válida.
            // Esto hace que el exportador respete mejor lo visible en la vista que estás revisando,
            // incluyendo categorías/elementos MEP visibles en esa vista.
            if (vistaActiva != null)
            {
                collector = new Autodesk.Revit.DB.FilteredElementCollector(doc, vistaActiva.Id);
            }
            else if (soloVistaActiva && doc.ActiveView != null && !doc.ActiveView.IsTemplate)
            {
                collector = new Autodesk.Revit.DB.FilteredElementCollector(doc, doc.ActiveView.Id);
            }
            else
            {
                collector = new Autodesk.Revit.DB.FilteredElementCollector(doc);
            }

            return collector.WhereElementIsNotElementType().ToElements();
        }

        private static Autodesk.Revit.DB.View ObtenerVistaActivaValida(Autodesk.Revit.DB.Document doc)
        {
            if (doc == null)
                return null;

            try
            {
                Autodesk.Revit.DB.View v = doc.ActiveView;

                if (v == null || v.IsTemplate)
                    return null;

                return v;
            }
            catch
            {
                return null;
            }
        }

        private static bool EsElementoExportable(
            Autodesk.Revit.DB.Document doc,
            Autodesk.Revit.DB.Element e,
            bool soloCategoriasModelo,
            bool incluirElementosSinCategoria)
        {
            if (e == null)
                return false;

            if (e.ViewSpecific)
                return false;

            if (e is Autodesk.Revit.DB.ElementType)
                return false;

            if (e is Autodesk.Revit.DB.RevitLinkInstance)
                return false;

            if (e is Autodesk.Revit.DB.ImportInstance)
                return false;

            Autodesk.Revit.DB.Category categoria = e.Category;

            if (categoria == null)
                return incluirElementosSinCategoria;

            if (soloCategoriasModelo && categoria.CategoryType != Autodesk.Revit.DB.CategoryType.Model)
                return false;

            string nombreCategoria = categoria.Name ?? "";

            // No exportar habitaciones/rooms al dashboard 3D ni a Dim_Visor.
            // Las habitaciones no son geometría física útil para el visor y pueden ensuciar la lectura.
            try
            {
                long categoriaBuiltIn = IdToLong(categoria.Id);

                if (categoriaBuiltIn == (long)Autodesk.Revit.DB.BuiltInCategory.OST_Rooms)
                    return false;
            }
            catch
            {
            }

            if (nombreCategoria.Equals("Habitaciones", System.StringComparison.OrdinalIgnoreCase) ||
                nombreCategoria.Equals("Rooms", System.StringComparison.OrdinalIgnoreCase))
                return false;

            if (nombreCategoria.Equals("Cámaras", System.StringComparison.OrdinalIgnoreCase))
                return false;

            // Respeta la vista activa: elementos/categorías/filtros ocultos en la vista no se exportan.
            Autodesk.Revit.DB.View vistaActiva = ObtenerVistaActivaValida(doc);

            try
            {
                if (vistaActiva != null && e.IsHidden(vistaActiva))
                    return false;
            }
            catch
            {
            }

            try
            {
                if (vistaActiva != null && categoria != null && vistaActiva.GetCategoryHidden(categoria.Id))
                    return false;
            }
            catch
            {
            }

            try
            {
                if (ElementoOcultoPorFiltroVista(doc, vistaActiva, e))
                    return false;
            }
            catch
            {
            }

            return true;
        }

        private static void ExportarElementoObj(
            Autodesk.Revit.DB.Document doc,
            Autodesk.Revit.DB.Element e,
            ObjContext ctx,
            bool soloVistaActiva)
        {
            string elementId = IdToText(e.Id);
            string meshName = "E_" + elementId;
            string categoria = e.Category != null ? e.Category.Name ?? "" : "Sin categoría";
            string nombre = ObtenerNombreSeguro(e);
            string uniqueId = e.UniqueId ?? "";
            string colorHex = ObtenerColorElementoHex(doc, e, e.Category, ObtenerVistaActivaValida(doc));
            string materialName = CrearMaterialDesdeHex(ctx, "MAT_" + SafeNameToken(categoria) + "_" + colorHex.Replace("#", ""), colorHex);

            int triAntes = ctx.TotalTriangulos;
            int lineasAntes = ctx.TotalLineas;

            ctx.Obj.AppendLine("o " + meshName);
            ctx.Obj.AppendLine("g " + meshName);
            ctx.Obj.AppendLine("usemtl " + materialName);

            Autodesk.Revit.DB.Options opt = CrearOpcionesGeometriaVistaActiva(doc);

            Autodesk.Revit.DB.GeometryElement geo = null;

            try
            {
                geo = e.get_Geometry(opt);
            }
            catch
            {
                geo = null;
            }

            bool esRebar = EsArmaduraRebar(e);

            // ARMADURA / REBAR:
            // No se reconstruye con curvas ni reglas de espaciado.
            // Primero se intenta tomar la geometría real que Revit entrega para la vista activa.
            // Esto respeta mejor la forma sólida que ves en Revit y evita inventar barras.
            if (esRebar)
            {
                bool exportoRebar = ExportarRebarComoSolidoDeVistaActiva(doc, e, ctx, materialName);

                // Respaldo: si Revit no entrega GetFullGeometryForView, se usa la geometría normal
                // de la vista activa, pero solo sólidos/mallas reales; nunca curvas reconstruidas.
                if (!exportoRebar)
                {
                    ProcesarGeometryElementAObj(
                        doc,
                        e,
                        geo,
                        ctx,
                        Autodesk.Revit.DB.Transform.Identity,
                        materialName,
                        true,
                        false);
                }
            }
            else
            {
                // Primera pasada: sólidos y mallas reales.
                // No exportamos curvas simbólicas en familias para evitar que fittings/uniones salgan como líneas de detalle bajo.
                ProcesarGeometryElementAObj(
                    doc,
                    e,
                    geo,
                    ctx,
                    Autodesk.Revit.DB.Transform.Identity,
                    materialName,
                    true,
                    false);

                // Segunda pasada opcional: curvas solo para elementos que realmente son lineales
                // y únicamente si no se consiguió geometría sólida.
                if (ctx.TotalTriangulos == triAntes && PermitirExportarCurvasComoElemento(e))
                {
                    ProcesarGeometryElementAObj(
                        doc,
                        e,
                        geo,
                        ctx,
                        Autodesk.Revit.DB.Transform.Identity,
                        materialName,
                        false,
                        true);
                }
            }

            int triangulosElemento = ctx.TotalTriangulos - triAntes;
            int lineasElemento = ctx.TotalLineas - lineasAntes;

            if (triangulosElemento > 0 || lineasElemento > 0)
            {
                ctx.Items.Add(new VisorItem()
                {
                    Modelo = doc.Title ?? "",
                    ElementId = elementId,
                    ElementIdValor = IdToLong(e.Id),
                    UniqueId = uniqueId,
                    MeshName = meshName,
                    Categoria = categoria,
                    Nombre = nombre,
                    Triangulos = triangulosElemento,
                    ColorHex = colorHex
                });
            }
            else
            {
                ctx.Obj.AppendLine("# Sin geometria triangulable: " + meshName);
            }

            ctx.Obj.AppendLine("");
        }

        private static void ProcesarGeometryElementAObj(
            Autodesk.Revit.DB.Document doc,
            Autodesk.Revit.DB.Element elementoOrigen,
            Autodesk.Revit.DB.GeometryElement geo,
            ObjContext ctx,
            Autodesk.Revit.DB.Transform transform,
            string materialName,
            bool procesarSolidos,
            bool procesarCurvas)
        {
            if (geo == null)
                return;

            foreach (Autodesk.Revit.DB.GeometryObject go in geo)
            {
                try
                {
                    if (go == null)
                        continue;

                    if (EsGeometriaOcultaOSimbolica(doc, elementoOrigen, go))
                        continue;

                    Autodesk.Revit.DB.Solid solid = go as Autodesk.Revit.DB.Solid;

                    if (solid != null)
                    {
                        if (EsSolidFuenteLuminosa(doc, elementoOrigen, solid))
                            continue;

                        if (procesarSolidos)
                            ProcesarSolidAObj(doc, solid, ctx, transform, materialName);

                        continue;
                    }

                    Autodesk.Revit.DB.Mesh mesh = go as Autodesk.Revit.DB.Mesh;

                    if (mesh != null)
                    {
                        if (EsGeometryObjectFuenteLuminosa(doc, elementoOrigen, mesh))
                            continue;

                        if (procesarSolidos)
                        {
                            ctx.Obj.AppendLine("usemtl " + materialName);
                            ProcesarMeshAObj(mesh, ctx, transform);
                        }

                        continue;
                    }

                    Autodesk.Revit.DB.Curve curva = go as Autodesk.Revit.DB.Curve;

                    if (curva != null)
                    {
                        if (procesarCurvas)
                        {
                            ctx.Obj.AppendLine("usemtl " + materialName);
                            ProcesarCurveAObj(curva, ctx, transform);
                        }

                        continue;
                    }

                    Autodesk.Revit.DB.PolyLine poly = go as Autodesk.Revit.DB.PolyLine;

                    if (poly != null)
                    {
                        if (procesarCurvas)
                        {
                            ctx.Obj.AppendLine("usemtl " + materialName);
                            ProcesarPolyLineAObj(poly, ctx, transform);
                        }

                        continue;
                    }

                    Autodesk.Revit.DB.GeometryInstance gi = go as Autodesk.Revit.DB.GeometryInstance;

                    if (gi != null)
                    {
                        if (EsGeometryInstanceFuenteLuminosa(doc, elementoOrigen, gi))
                            continue;

                        Autodesk.Revit.DB.Transform t = transform;

                        try
                        {
                            if (gi.Transform != null)
                                t = transform.Multiply(gi.Transform);
                        }
                        catch
                        {
                            t = transform;
                        }

                        Autodesk.Revit.DB.GeometryElement geoInst = null;

                        // Primero se intenta con GetInstanceGeometry para respetar mejor la geometría
                        // visible/real de la instancia en la vista activa, especialmente en uniones y fittings MEP.
                        try
                        {
                            geoInst = gi.GetInstanceGeometry();
                            t = Autodesk.Revit.DB.Transform.Identity;
                        }
                        catch
                        {
                            geoInst = null;
                        }

                        if (geoInst == null)
                        {
                            try
                            {
                                geoInst = gi.GetSymbolGeometry();

                                if (gi.Transform != null)
                                    t = transform.Multiply(gi.Transform);
                            }
                            catch
                            {
                                geoInst = null;
                            }
                        }

                        ProcesarGeometryElementAObj(
                            doc,
                            elementoOrigen,
                            geoInst,
                            ctx,
                            t,
                            materialName,
                            procesarSolidos,
                            procesarCurvas);
                    }
                }
                catch
                {
                }
            }
        }

        private static void ProcesarSolidAObj(
            Autodesk.Revit.DB.Document doc,
            Autodesk.Revit.DB.Solid solid,
            ObjContext ctx,
            Autodesk.Revit.DB.Transform transform,
            string materialName)
        {
            if (solid == null || solid.Faces == null || solid.Faces.Size == 0)
                return;

            try
            {
                if (solid.Volume <= 0.0000001)
                    return;
            }
            catch
            {
            }

            foreach (Autodesk.Revit.DB.Face face in solid.Faces)
            {
                try
                {
                    ctx.Obj.AppendLine("usemtl " + materialName);
                    Autodesk.Revit.DB.Mesh mesh = face.Triangulate();
                    ProcesarMeshAObj(mesh, ctx, transform);
                }
                catch
                {
                }
            }
        }


        private static Autodesk.Revit.DB.Options CrearOpcionesGeometriaVistaActiva(Autodesk.Revit.DB.Document doc)
        {
            Autodesk.Revit.DB.Options opt = new Autodesk.Revit.DB.Options();
            opt.ComputeReferences = false;
            opt.IncludeNonVisibleObjects = false;
            opt.DetailLevel = Autodesk.Revit.DB.ViewDetailLevel.Fine;

            try
            {
                Autodesk.Revit.DB.View vistaActiva = ObtenerVistaActivaValida(doc);

                if (vistaActiva != null)
                {
                    opt.View = vistaActiva;

                    try
                    {
                        opt.DetailLevel = vistaActiva.DetailLevel;
                    }
                    catch
                    {
                        opt.DetailLevel = Autodesk.Revit.DB.ViewDetailLevel.Fine;
                    }
                }
            }
            catch
            {
            }

            return opt;
        }


        private static bool EsArmaduraRebar(Autodesk.Revit.DB.Element e)
        {
            if (e == null)
                return false;

            Autodesk.Revit.DB.Category cat = null;

            try
            {
                cat = e.Category;
            }
            catch
            {
                cat = null;
            }

            if (cat == null)
                return false;

            try
            {
                long bic = IdToLong(cat.Id);

                if (bic == (long)Autodesk.Revit.DB.BuiltInCategory.OST_Rebar)
                    return true;
            }
            catch
            {
            }

            string c = "";

            try
            {
                c = (cat.Name ?? "").Trim().ToUpperInvariant();
            }
            catch
            {
                c = "";
            }

            // OJO: no usar "ARMAZÓN ESTRUCTURAL", porque esa categoría corresponde a vigas/pórticos,
            // no a la armadura. Así evitamos alterar elementos que no tienen nada que ver.
            if (c.Equals("ARMADURA ESTRUCTURAL", System.StringComparison.OrdinalIgnoreCase) ||
                c.Equals("STRUCTURAL REBAR", System.StringComparison.OrdinalIgnoreCase) ||
                c.Equals("REBAR", System.StringComparison.OrdinalIgnoreCase) ||
                c.Contains("ARMADURA ESTRUCTURAL") ||
                c.Contains("STRUCTURAL REBAR"))
                return true;

            return false;
        }

        private static bool ExportarRebarComoSolidoDeVistaActiva(
            Autodesk.Revit.DB.Document doc,
            Autodesk.Revit.DB.Element e,
            ObjContext ctx,
            string materialName)
        {
            if (doc == null || e == null || ctx == null)
                return false;

            int triAntes = ctx.TotalTriangulos;
            int lineasAntes = ctx.TotalLineas;

            try
            {
                object geoVista = ObtenerObjetoGeometriaRebarVistaActiva(doc, e);

                if (geoVista != null)
                {
                    ProcesarObjetoGeometriaRebarSolido(
                        doc,
                        e,
                        geoVista,
                        ctx,
                        Autodesk.Revit.DB.Transform.Identity,
                        materialName);
                }
            }
            catch
            {
            }

            return ctx.TotalTriangulos > triAntes || ctx.TotalLineas > lineasAntes;
        }

        private static object ObtenerObjetoGeometriaRebarVistaActiva(
            Autodesk.Revit.DB.Document doc,
            Autodesk.Revit.DB.Element e)
        {
            if (doc == null || e == null)
                return null;

            Autodesk.Revit.DB.View vistaActiva = ObtenerVistaActivaValida(doc);

            // Rebar tiene una geometría especial para vistas. Se llama por reflexión para evitar
            // depender de una firma exacta entre versiones de Revit.
            try
            {
                if (vistaActiva != null)
                {
                    System.Reflection.MethodInfo mi = e.GetType().GetMethod(
                        "GetFullGeometryForView",
                        new System.Type[] { typeof(Autodesk.Revit.DB.View) });

                    if (mi != null)
                    {
                        object res = mi.Invoke(e, new object[] { vistaActiva });

                        if (res != null)
                            return res;
                    }
                }
            }
            catch
            {
            }

            // Respaldo: geometría normal respetando vista activa y detalle de la vista.
            try
            {
                Autodesk.Revit.DB.Options opt = CrearOpcionesGeometriaVistaActiva(doc);
                return e.get_Geometry(opt);
            }
            catch
            {
                return null;
            }
        }

        private static void ProcesarObjetoGeometriaRebarSolido(
            Autodesk.Revit.DB.Document doc,
            Autodesk.Revit.DB.Element elementoOrigen,
            object geoObj,
            ObjContext ctx,
            Autodesk.Revit.DB.Transform transform,
            string materialName)
        {
            if (geoObj == null || ctx == null)
                return;

            Autodesk.Revit.DB.GeometryElement geoElem = geoObj as Autodesk.Revit.DB.GeometryElement;

            if (geoElem != null)
            {
                ProcesarGeometryElementAObj(
                    doc,
                    elementoOrigen,
                    geoElem,
                    ctx,
                    transform,
                    materialName,
                    true,
                    false);
                return;
            }

            Autodesk.Revit.DB.Solid solid = geoObj as Autodesk.Revit.DB.Solid;

            if (solid != null)
            {
                ctx.Obj.AppendLine("usemtl " + materialName);
                ProcesarSolidAObj(doc, solid, ctx, transform, materialName);
                return;
            }

            Autodesk.Revit.DB.Mesh mesh = geoObj as Autodesk.Revit.DB.Mesh;

            if (mesh != null)
            {
                ctx.Obj.AppendLine("usemtl " + materialName);
                ProcesarMeshAObj(mesh, ctx, transform);
                return;
            }

            Autodesk.Revit.DB.GeometryInstance gi = geoObj as Autodesk.Revit.DB.GeometryInstance;

            if (gi != null)
            {
                Autodesk.Revit.DB.Transform t = transform;

                try
                {
                    if (gi.Transform != null)
                        t = transform.Multiply(gi.Transform);
                }
                catch
                {
                    t = transform;
                }

                Autodesk.Revit.DB.GeometryElement geoInst = null;

                try
                {
                    geoInst = gi.GetInstanceGeometry();
                    t = Autodesk.Revit.DB.Transform.Identity;
                }
                catch
                {
                    geoInst = null;
                }

                if (geoInst == null)
                {
                    try
                    {
                        geoInst = gi.GetSymbolGeometry();

                        if (gi.Transform != null)
                            t = transform.Multiply(gi.Transform);
                    }
                    catch
                    {
                        geoInst = null;
                    }
                }

                if (geoInst != null)
                {
                    ProcesarObjetoGeometriaRebarSolido(
                        doc,
                        elementoOrigen,
                        geoInst,
                        ctx,
                        t,
                        materialName);
                }

                return;
            }

            System.Collections.IEnumerable enumerable = geoObj as System.Collections.IEnumerable;

            if (enumerable != null && !(geoObj is string))
            {
                foreach (object item in enumerable)
                {
                    try
                    {
                        ProcesarObjetoGeometriaRebarSolido(
                            doc,
                            elementoOrigen,
                            item,
                            ctx,
                            transform,
                            materialName);
                    }
                    catch
                    {
                    }
                }
            }
        }

        private static bool PermitirExportarCurvasComoElemento(Autodesk.Revit.DB.Element e)
        {
            if (e == null)
                return false;

            // Evita líneas simbólicas de familias cargables, como fittings/uniones, luminarias y símbolos 2D.
            if (e is Autodesk.Revit.DB.FamilyInstance)
                return false;

            string categoria = "";

            try
            {
                if (e.Category != null)
                    categoria = e.Category.Name ?? "";
            }
            catch
            {
                categoria = "";
            }

            string c = categoria.ToUpperInvariant();

            if (c.Contains("CABLE") ||
                c.Contains("CIRCU") ||
                c.Contains("CONDUIT") ||
                c.Contains("TUB") ||
                c.Contains("PIPE") ||
                c.Contains("DUCT") ||
                c.Contains("BANDEJA") ||
                c.Contains("TRAY") ||
                c.Contains("LÍNEA DE MODELO") ||
                c.Contains("LINEA DE MODELO"))
                return true;

            return false;
        }

        private static bool EsGeometriaOcultaOSimbolica(
            Autodesk.Revit.DB.Document doc,
            Autodesk.Revit.DB.Element elementoOrigen,
            Autodesk.Revit.DB.GeometryObject go)
        {
            if (doc == null || go == null)
                return false;

            try
            {
                if (EsGeometryObjectFuenteLuminosa(doc, elementoOrigen, go))
                    return true;
            }
            catch
            {
            }

            try
            {
                Autodesk.Revit.DB.ElementId gsId = go.GraphicsStyleId;

                if (gsId == null || gsId == Autodesk.Revit.DB.ElementId.InvalidElementId)
                    return false;

                Autodesk.Revit.DB.GraphicsStyle gs = doc.GetElement(gsId) as Autodesk.Revit.DB.GraphicsStyle;

                if (gs == null)
                    return false;

                string nombre = gs.Name ?? "";
                string cat = gs.GraphicsStyleCategory != null ? gs.GraphicsStyleCategory.Name ?? "" : "";
                string texto = (nombre + " " + cat).ToUpperInvariant();

                // Evita exportar esferas/conos/orígenes de fuente luminosa y simbología 2D.
                // OJO: no se filtra toda la categoría de luminarias, solo subgeometrías que indiquen
                // fuente/origen de luz, fotometría o anotación.
                if (TextoIndicaFuenteLuminosa(texto) ||
                    texto.Contains("SÍMBOLO") ||
                    texto.Contains("SIMBOLO") ||
                    texto.Contains("ANNOTATION") ||
                    texto.Contains("ANOTACI"))
                    return true;
            }
            catch
            {
            }

            return false;
        }

        private static bool EsGeometryInstanceFuenteLuminosa(
            Autodesk.Revit.DB.Document doc,
            Autodesk.Revit.DB.Element elementoOrigen,
            Autodesk.Revit.DB.GeometryInstance gi)
        {
            if (doc == null || gi == null)
                return false;

            try
            {
                if (EsGeometryObjectFuenteLuminosa(doc, elementoOrigen, gi))
                    return true;
            }
            catch
            {
            }

            return false;
        }

        private static bool EsGeometryObjectFuenteLuminosa(
            Autodesk.Revit.DB.Document doc,
            Autodesk.Revit.DB.Element elementoOrigen,
            Autodesk.Revit.DB.GeometryObject go)
        {
            if (doc == null || go == null)
                return false;

            try
            {
                Autodesk.Revit.DB.ElementId gsId = go.GraphicsStyleId;

                if (gsId != null && gsId != Autodesk.Revit.DB.ElementId.InvalidElementId)
                {
                    Autodesk.Revit.DB.GraphicsStyle gs = doc.GetElement(gsId) as Autodesk.Revit.DB.GraphicsStyle;

                    if (gs != null)
                    {
                        string nombre = gs.Name ?? "";
                        string cat = gs.GraphicsStyleCategory != null ? gs.GraphicsStyleCategory.Name ?? "" : "";
                        string texto = (nombre + " " + cat).ToUpperInvariant();

                        if (TextoIndicaFuenteLuminosa(texto))
                            return true;
                    }
                }
            }
            catch
            {
            }

            try
            {
                if (EsGeneradoPorFuenteLuminosa(doc, elementoOrigen, go))
                    return true;
            }
            catch
            {
            }

            return false;
        }

        private static bool EsSolidFuenteLuminosa(
            Autodesk.Revit.DB.Document doc,
            Autodesk.Revit.DB.Element elementoOrigen,
            Autodesk.Revit.DB.Solid solid)
        {
            if (doc == null || solid == null)
                return false;

            try
            {
                if (EsGeometryObjectFuenteLuminosa(doc, elementoOrigen, solid))
                    return true;
            }
            catch
            {
            }

            try
            {
                int carasConMaterial = 0;
                int carasFuente = 0;

                foreach (Autodesk.Revit.DB.Face face in solid.Faces)
                {
                    if (face == null)
                        continue;

                    Autodesk.Revit.DB.ElementId matId = Autodesk.Revit.DB.ElementId.InvalidElementId;

                    try
                    {
                        matId = face.MaterialElementId;
                    }
                    catch
                    {
                        matId = Autodesk.Revit.DB.ElementId.InvalidElementId;
                    }

                    if (matId == null || matId == Autodesk.Revit.DB.ElementId.InvalidElementId)
                        continue;

                    carasConMaterial++;

                    Autodesk.Revit.DB.Material mat = doc.GetElement(matId) as Autodesk.Revit.DB.Material;

                    if (MaterialIndicaFuenteLuminosa(mat))
                        carasFuente++;
                }

                // Si la mayoría de caras del sólido pertenecen al material de fuente/origen de luz,
                // se trata de una geometría auxiliar de fotometría y no del cuerpo real de la luminaria.
                if (carasConMaterial > 0 && carasFuente >= System.Math.Max(1, (int)System.Math.Ceiling(carasConMaterial * 0.60)))
                    return true;
            }
            catch
            {
            }

            return false;
        }

        private static bool MaterialIndicaFuenteLuminosa(Autodesk.Revit.DB.Material mat)
        {
            if (mat == null)
                return false;

            try
            {
                string texto = (mat.Name ?? "").ToUpperInvariant();

                if (TextoIndicaFuenteLuminosa(texto))
                    return true;
            }
            catch
            {
            }

            return false;
        }

        private static bool EsGeneradoPorFuenteLuminosa(
            Autodesk.Revit.DB.Document doc,
            Autodesk.Revit.DB.Element elementoOrigen,
            Autodesk.Revit.DB.GeometryObject go)
        {
            if (doc == null || elementoOrigen == null || go == null)
                return false;

            try
            {
                System.Reflection.MethodInfo metodo =
                    typeof(Autodesk.Revit.DB.Element).GetMethod(
                        "GetGeneratingElementIds",
                        new System.Type[] { typeof(Autodesk.Revit.DB.GeometryObject) });

                if (metodo == null)
                    return false;

                object resultado = metodo.Invoke(elementoOrigen, new object[] { go });

                System.Collections.IEnumerable ids = resultado as System.Collections.IEnumerable;

                if (ids == null)
                    return false;

                foreach (object objId in ids)
                {
                    Autodesk.Revit.DB.ElementId id = objId as Autodesk.Revit.DB.ElementId;

                    if (id == null || id == Autodesk.Revit.DB.ElementId.InvalidElementId)
                        continue;

                    Autodesk.Revit.DB.Element gen = doc.GetElement(id);

                    if (ElementoIndicaFuenteLuminosa(doc, gen))
                        return true;
                }
            }
            catch
            {
            }

            return false;
        }

        private static bool ElementoIndicaFuenteLuminosa(Autodesk.Revit.DB.Document doc, Autodesk.Revit.DB.Element e)
        {
            if (e == null)
                return false;

            try
            {
                string nombre = ObtenerNombreSeguro(e);
                string categoria = e.Category != null ? e.Category.Name ?? "" : "";
                string texto = (nombre + " " + categoria).ToUpperInvariant();

                if (TextoIndicaFuenteLuminosa(texto))
                    return true;
            }
            catch
            {
            }

            try
            {
                Autodesk.Revit.DB.ElementType tipo = null;
                Autodesk.Revit.DB.ElementId tipoId = e.GetTypeId();

                if (tipoId != null && tipoId != Autodesk.Revit.DB.ElementId.InvalidElementId)
                    tipo = doc.GetElement(tipoId) as Autodesk.Revit.DB.ElementType;

                if (tipo != null)
                {
                    string textoTipo = ((tipo.Name ?? "") + " " + ObtenerNombreSeguro(tipo)).ToUpperInvariant();

                    if (TextoIndicaFuenteLuminosa(textoTipo))
                        return true;
                }
            }
            catch
            {
            }

            return false;
        }

        private static bool TextoIndicaFuenteLuminosa(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return false;

            string t = texto.ToUpperInvariant();

            // Español / inglés. Se evita usar solo "LIGHTING" o "ILUMINACIÓN"
            // porque eso eliminaría el cuerpo real de las luminarias.
            if (t.Contains("LIGHT SOURCE") ||
                t.Contains("LIGHT-SOURCE") ||
                t.Contains("SOURCE LIGHT") ||
                t.Contains("FUENTE DE LUZ") ||
                t.Contains("FUENTE LUMINOSA") ||
                t.Contains("ORIGEN DE LUZ") ||
                t.Contains("ORIGEN LUZ") ||
                t.Contains("PHOTOMETRIC") ||
                t.Contains("PHOTOMETR") ||
                t.Contains("FOTOMETR") ||
                t.Contains("IES LIGHT") ||
                t.Contains("LUZ IES") ||
                t.Contains("LIGHT EMITTER") ||
                t.Contains("EMISOR DE LUZ"))
                return true;

            return false;
        }

        private static void ProcesarCurveAObj(Autodesk.Revit.DB.Curve curva, ObjContext ctx, Autodesk.Revit.DB.Transform transform)
        {
            if (curva == null)
                return;

            try
            {
                System.Collections.Generic.IList<Autodesk.Revit.DB.XYZ> puntos = curva.Tessellate();

                if (puntos == null || puntos.Count < 2)
                    return;

                for (int i = 0; i < puntos.Count - 1; i++)
                {
                    Autodesk.Revit.DB.XYZ p0 = puntos[i];
                    Autodesk.Revit.DB.XYZ p1 = puntos[i + 1];

                    if (transform != null)
                    {
                        p0 = transform.OfPoint(p0);
                        p1 = transform.OfPoint(p1);
                    }

                    int i0 = AgregarVerticeObj(ctx, p0);
                    int i1 = AgregarVerticeObj(ctx, p1);

                    if (i0 == i1)
                        continue;

                    ctx.Obj.AppendLine("l " + i0.ToString(CI) + " " + i1.ToString(CI));
                    ctx.TotalLineas++;
                }
            }
            catch
            {
            }
        }

        private static void ProcesarPolyLineAObj(Autodesk.Revit.DB.PolyLine poly, ObjContext ctx, Autodesk.Revit.DB.Transform transform)
        {
            if (poly == null)
                return;

            try
            {
                System.Collections.Generic.IList<Autodesk.Revit.DB.XYZ> puntos = poly.GetCoordinates();

                if (puntos == null || puntos.Count < 2)
                    return;

                for (int i = 0; i < puntos.Count - 1; i++)
                {
                    Autodesk.Revit.DB.XYZ p0 = puntos[i];
                    Autodesk.Revit.DB.XYZ p1 = puntos[i + 1];

                    if (transform != null)
                    {
                        p0 = transform.OfPoint(p0);
                        p1 = transform.OfPoint(p1);
                    }

                    int i0 = AgregarVerticeObj(ctx, p0);
                    int i1 = AgregarVerticeObj(ctx, p1);

                    if (i0 == i1)
                        continue;

                    ctx.Obj.AppendLine("l " + i0.ToString(CI) + " " + i1.ToString(CI));
                    ctx.TotalLineas++;
                }
            }
            catch
            {
            }
        }

        private static void ProcesarMeshAObj(Autodesk.Revit.DB.Mesh mesh, ObjContext ctx, Autodesk.Revit.DB.Transform transform)
        {
            if (mesh == null)
                return;

            int numTri = 0;

            try
            {
                numTri = mesh.NumTriangles;
            }
            catch
            {
                numTri = 0;
            }

            if (numTri <= 0)
                return;

            for (int i = 0; i < numTri; i++)
            {
                try
                {
                    Autodesk.Revit.DB.MeshTriangle tri = mesh.get_Triangle(i);

                    Autodesk.Revit.DB.XYZ p0 = tri.get_Vertex(0);
                    Autodesk.Revit.DB.XYZ p1 = tri.get_Vertex(1);
                    Autodesk.Revit.DB.XYZ p2 = tri.get_Vertex(2);

                    if (transform != null)
                    {
                        p0 = transform.OfPoint(p0);
                        p1 = transform.OfPoint(p1);
                        p2 = transform.OfPoint(p2);
                    }

                    int i0 = AgregarVerticeObj(ctx, p0);
                    int i1 = AgregarVerticeObj(ctx, p1);
                    int i2 = AgregarVerticeObj(ctx, p2);

                    // Evita triángulos degenerados luego de la deduplicación por coordenada.
                    if (i0 == i1 || i1 == i2 || i0 == i2)
                        continue;

                    ctx.Obj.AppendLine("f " + i0.ToString(CI) + " " + i1.ToString(CI) + " " + i2.ToString(CI));
                    ctx.TotalTriangulos++;
                }
                catch
                {
                }
            }
        }

        private static int AgregarVerticeObj(ObjContext ctx, Autodesk.Revit.DB.XYZ p)
        {
            double x = Autodesk.Revit.DB.UnitUtils.ConvertFromInternalUnits(p.X, Autodesk.Revit.DB.UnitTypeId.Meters);
            double y = Autodesk.Revit.DB.UnitUtils.ConvertFromInternalUnits(p.Y, Autodesk.Revit.DB.UnitTypeId.Meters);
            double z = Autodesk.Revit.DB.UnitUtils.ConvertFromInternalUnits(p.Z, Autodesk.Revit.DB.UnitTypeId.Meters);

            // Revit Z-up a WebGL Y-up: X, Z, -Y
            double wx = x;
            double wy = z;
            double wz = -y;

            // Precisión 0.1 mm. Reduce mucho el peso del OBJ sin deformar el modelo para visor/metrados.
            long kx = (long)System.Math.Round(wx * 10000.0);
            long ky = (long)System.Math.Round(wy * 10000.0);
            long kz = (long)System.Math.Round(wz * 10000.0);

            string key = kx.ToString(CI) + "|" + ky.ToString(CI) + "|" + kz.ToString(CI);

            int existente;
            if (ctx.VertexMap.TryGetValue(key, out existente))
                return existente;

            wx = kx / 10000.0;
            wy = ky / 10000.0;
            wz = kz / 10000.0;

            ctx.VertexIndex++;
            ctx.VertexMap[key] = ctx.VertexIndex;

            ctx.Obj.AppendLine("v " + Format(wx) + " " + Format(wy) + " " + Format(wz));

            return ctx.VertexIndex;
        }

        private static string CrearMaterialDesdeHex(ObjContext ctx, string nombreBase, string colorHex)
        {
            string nombre = SafeNameToken(nombreBase);

            if (string.IsNullOrWhiteSpace(colorHex))
                colorHex = "#9e9e9e";

            if (ctx.Materiales.Contains(nombre))
                return nombre;

            ctx.Materiales.Add(nombre);
            ctx.MaterialesHex[nombre] = colorHex;

            int rInt = 158;
            int gInt = 158;
            int bInt = 158;

            try
            {
                string h = colorHex.Trim().TrimStart('#');

                if (h.Length == 6)
                {
                    rInt = System.Convert.ToInt32(h.Substring(0, 2), 16);
                    gInt = System.Convert.ToInt32(h.Substring(2, 2), 16);
                    bInt = System.Convert.ToInt32(h.Substring(4, 2), 16);
                }
            }
            catch
            {
                rInt = 158;
                gInt = 158;
                bInt = 158;
            }

            double r = rInt / 255.0;
            double g = gInt / 255.0;
            double b = bInt / 255.0;

            ctx.Mtl.AppendLine("newmtl " + nombre);
            ctx.Mtl.AppendLine("Kd " + Format(r) + " " + Format(g) + " " + Format(b));
            ctx.Mtl.AppendLine("Ka 0.25 0.25 0.25");
            ctx.Mtl.AppendLine("Ks 0.10 0.10 0.10");
            ctx.Mtl.AppendLine("d 1.0");
            ctx.Mtl.AppendLine("");

            return nombre;
        }

        private static string ObtenerColorElementoHex(
            Autodesk.Revit.DB.Document doc,
            Autodesk.Revit.DB.Element e,
            Autodesk.Revit.DB.Category cat,
            Autodesk.Revit.DB.View vistaActiva)
        {
            /*
             * COLOR DEL VISOR = COLOR DE MATERIAL EN MODO SOMBREADO DE REVIT
             * -------------------------------------------------------------
             * En Revit, el modo "Colores coherentes / Sombreado" toma como base
             * el color de sombreado del material: Material.Color.
             *
             * Por eso aquí NO se priorizan overrides de vista ni colores inventados.
             * Primero se busca el material dominante de las caras reales del sólido
             * y luego se usa el color de sombreado del material.
             */

            string colorVista = ObtenerColorVistaActivaHex(vistaActiva, e, cat);

            if (EsHexUtil(colorVista))
                return colorVista;

            string colorMaterialDominante = ObtenerColorSombreadoMaterialDominante(doc, e, vistaActiva);

            if (EsHexUtil(colorMaterialDominante))
                return colorMaterialDominante;

            // Respaldo: materiales asignados al elemento, si la geometría no entregó caras/materiales.
            try
            {
                if (doc != null && e != null)
                {
                    System.Collections.Generic.ICollection<Autodesk.Revit.DB.ElementId> matIds = e.GetMaterialIds(false);

                    if (matIds != null && matIds.Count > 0)
                    {
                        foreach (Autodesk.Revit.DB.ElementId matId in matIds)
                        {
                            Autodesk.Revit.DB.Material mat = doc.GetElement(matId) as Autodesk.Revit.DB.Material;

                            string hex = ObtenerColorSombreadoMaterialHex(mat);

                            if (EsHexUtil(hex))
                                return hex;
                        }
                    }
                }
            }
            catch
            {
            }

            // Último respaldo: color de categoría de Revit.
            try
            {
                if (cat != null && cat.LineColor != null)
                {
                    string hexCat = ColorToHex(cat.LineColor);

                    if (EsHexUtil(hexCat))
                        return hexCat;
                }
            }
            catch
            {
            }

            return "#B4B4B4";
        }

        private static string ObtenerColorSombreadoMaterialDominante(
            Autodesk.Revit.DB.Document doc,
            Autodesk.Revit.DB.Element e,
            Autodesk.Revit.DB.View vistaActiva)
        {
            if (doc == null || e == null)
                return "";

            try
            {
                Autodesk.Revit.DB.Options opt = CrearOpcionesGeometriaVistaActiva(doc);

                Autodesk.Revit.DB.GeometryElement geo = e.get_Geometry(opt);

                System.Collections.Generic.Dictionary<long, double> areaPorMaterial =
                    new System.Collections.Generic.Dictionary<long, double>();

                System.Collections.Generic.Dictionary<long, Autodesk.Revit.DB.ElementId> idPorMaterial =
                    new System.Collections.Generic.Dictionary<long, Autodesk.Revit.DB.ElementId>();

                AcumularAreasMateriales(geo, areaPorMaterial, idPorMaterial);

                if (areaPorMaterial.Count == 0)
                    return "";

                long idDominante = 0;
                double areaMayor = -1.0;

                foreach (System.Collections.Generic.KeyValuePair<long, double> kv in areaPorMaterial)
                {
                    if (kv.Value > areaMayor)
                    {
                        areaMayor = kv.Value;
                        idDominante = kv.Key;
                    }
                }

                if (!idPorMaterial.ContainsKey(idDominante))
                    return "";

                Autodesk.Revit.DB.Material mat =
                    doc.GetElement(idPorMaterial[idDominante]) as Autodesk.Revit.DB.Material;

                return ObtenerColorSombreadoMaterialHex(mat);
            }
            catch
            {
                return "";
            }
        }

        private static void AcumularAreasMateriales(
            Autodesk.Revit.DB.GeometryElement geo,
            System.Collections.Generic.Dictionary<long, double> areaPorMaterial,
            System.Collections.Generic.Dictionary<long, Autodesk.Revit.DB.ElementId> idPorMaterial)
        {
            if (geo == null)
                return;

            foreach (Autodesk.Revit.DB.GeometryObject go in geo)
            {
                try
                {
                    Autodesk.Revit.DB.Solid solid = go as Autodesk.Revit.DB.Solid;

                    if (solid != null && solid.Faces != null && solid.Faces.Size > 0)
                    {
                        foreach (Autodesk.Revit.DB.Face face in solid.Faces)
                        {
                            try
                            {
                                Autodesk.Revit.DB.ElementId matId = face.MaterialElementId;

                                if (matId == null || matId == Autodesk.Revit.DB.ElementId.InvalidElementId)
                                    continue;

                                long idValor = IdToLong(matId);

                                if (idValor == 0)
                                    continue;

                                double area = 1.0;

                                try
                                {
                                    area = System.Math.Abs(face.Area);
                                }
                                catch
                                {
                                    area = 1.0;
                                }

                                if (!areaPorMaterial.ContainsKey(idValor))
                                    areaPorMaterial[idValor] = 0.0;

                                if (!idPorMaterial.ContainsKey(idValor))
                                    idPorMaterial[idValor] = matId;

                                areaPorMaterial[idValor] += area;
                            }
                            catch
                            {
                            }
                        }
                    }

                    Autodesk.Revit.DB.GeometryInstance gi = go as Autodesk.Revit.DB.GeometryInstance;

                    if (gi != null)
                    {
                        Autodesk.Revit.DB.GeometryElement geoInst = null;

                        try
                        {
                            geoInst = gi.GetInstanceGeometry();
                        }
                        catch
                        {
                            geoInst = null;
                        }

                        if (geoInst == null)
                        {
                            try
                            {
                                geoInst = gi.GetSymbolGeometry();
                            }
                            catch
                            {
                                geoInst = null;
                            }
                        }

                        AcumularAreasMateriales(geoInst, areaPorMaterial, idPorMaterial);
                    }
                }
                catch
                {
                }
            }
        }

        private static string ObtenerColorSombreadoMaterialHex(Autodesk.Revit.DB.Material mat)
        {
            if (mat == null)
                return "";

            try
            {
                Autodesk.Revit.DB.Color c = mat.Color;

                if (c == null)
                    return "";

                return ColorToHex(c);
            }
            catch
            {
                return "";
            }
        }

        private static string ObtenerColorVistaActivaHex(
            Autodesk.Revit.DB.View vistaActiva,
            Autodesk.Revit.DB.Element e,
            Autodesk.Revit.DB.Category cat)
        {
            if (vistaActiva == null)
                return "";

            // Primero intenta overrides propios del elemento en la vista activa.
            try
            {
                if (e != null)
                {
                    Autodesk.Revit.DB.OverrideGraphicSettings ogs = vistaActiva.GetElementOverrides(e.Id);
                    string hex = ObtenerColorSuperficieOverrideHex(ogs);

                    if (EsHexUtil(hex))
                        return hex;
                }
            }
            catch
            {
            }

            // Luego intenta filtros de la vista activa.
            try
            {
                string hexFiltro = ObtenerColorFiltrosVistaActivaHex(vistaActiva, e);

                if (EsHexUtil(hexFiltro))
                    return hexFiltro;
            }
            catch
            {
            }

            // Luego intenta overrides de categoría en esa vista.
            try
            {
                if (cat != null)
                {
                    Autodesk.Revit.DB.OverrideGraphicSettings ogsCat = vistaActiva.GetCategoryOverrides(cat.Id);
                    string hexCat = ObtenerColorSuperficieOverrideHex(ogsCat);

                    if (EsHexUtil(hexCat))
                        return hexCat;
                }
            }
            catch
            {
            }

            return "";
        }


        private static string ObtenerColorFiltrosVistaActivaHex(Autodesk.Revit.DB.View vistaActiva, Autodesk.Revit.DB.Element e)
        {
            if (vistaActiva == null || e == null)
                return "";

            Autodesk.Revit.DB.Document doc = e.Document;

            foreach (Autodesk.Revit.DB.ElementId filtroId in ObtenerFiltrosVistaEnOrden(vistaActiva))
            {
                try
                {
                    Autodesk.Revit.DB.ParameterFilterElement pfe = doc.GetElement(filtroId) as Autodesk.Revit.DB.ParameterFilterElement;

                    if (pfe == null)
                        continue;

                    Autodesk.Revit.DB.ElementFilter filtro = pfe.GetElementFilter();

                    if (filtro == null)
                        continue;

                    bool pasa = false;

                    try
                    {
                        pasa = filtro.PassesFilter(doc, e.Id);
                    }
                    catch
                    {
                        pasa = false;
                    }

                    if (!pasa)
                        continue;

                    Autodesk.Revit.DB.OverrideGraphicSettings ogsFiltro = vistaActiva.GetFilterOverrides(filtroId);
                    string hex = ObtenerColorSuperficieOverrideHex(ogsFiltro);

                    if (EsHexUtil(hex))
                        return hex;
                }
                catch
                {
                }
            }

            return "";
        }

        private static bool ElementoOcultoPorFiltroVista(Autodesk.Revit.DB.Document doc, Autodesk.Revit.DB.View vistaActiva, Autodesk.Revit.DB.Element e)
        {
            if (doc == null || vistaActiva == null || e == null)
                return false;

            foreach (Autodesk.Revit.DB.ElementId filtroId in ObtenerFiltrosVistaEnOrden(vistaActiva))
            {
                try
                {
                    Autodesk.Revit.DB.ParameterFilterElement pfe = doc.GetElement(filtroId) as Autodesk.Revit.DB.ParameterFilterElement;

                    if (pfe == null)
                        continue;

                    Autodesk.Revit.DB.ElementFilter filtro = pfe.GetElementFilter();

                    if (filtro == null)
                        continue;

                    bool pasa = false;

                    try
                    {
                        pasa = filtro.PassesFilter(doc, e.Id);
                    }
                    catch
                    {
                        pasa = false;
                    }

                    if (!pasa)
                        continue;

                    try
                    {
                        if (!vistaActiva.GetFilterVisibility(filtroId))
                            return true;
                    }
                    catch
                    {
                    }
                }
                catch
                {
                }
            }

            return false;
        }

        private static System.Collections.Generic.IList<Autodesk.Revit.DB.ElementId> ObtenerFiltrosVistaEnOrden(Autodesk.Revit.DB.View vistaActiva)
        {
            System.Collections.Generic.List<Autodesk.Revit.DB.ElementId> lista = new System.Collections.Generic.List<Autodesk.Revit.DB.ElementId>();

            if (vistaActiva == null)
                return lista;

            try
            {
                // Revit 2024+ puede exponer GetOrderedFilters. Se usa por reflexión para mantener compatibilidad.
                System.Reflection.MethodInfo mi = vistaActiva.GetType().GetMethod("GetOrderedFilters");

                if (mi != null)
                {
                    object resultado = mi.Invoke(vistaActiva, null);
                    System.Collections.Generic.IEnumerable<Autodesk.Revit.DB.ElementId> idsOrdenados =
                        resultado as System.Collections.Generic.IEnumerable<Autodesk.Revit.DB.ElementId>;

                    if (idsOrdenados != null)
                    {
                        foreach (Autodesk.Revit.DB.ElementId id in idsOrdenados)
                            lista.Add(id);

                        if (lista.Count > 0)
                        {
                            lista.Reverse();
                            return lista;
                        }
                    }
                }
            }
            catch
            {
            }

            try
            {
                System.Collections.Generic.ICollection<Autodesk.Revit.DB.ElementId> ids = vistaActiva.GetFilters();

                if (ids != null)
                {
                    foreach (Autodesk.Revit.DB.ElementId id in ids)
                        lista.Add(id);
                }
            }
            catch
            {
            }

            lista.Reverse();
            return lista;
        }

        private static string ObtenerColorSuperficieOverrideHex(object overrideGraphics)
        {
            if (overrideGraphics == null)
                return "";

            string[] nombresPropiedades = new string[]
            {
                "SurfaceForegroundPatternColor",
                "ProjectionLineColor",
                "CutLineColor",
                "SurfaceBackgroundPatternColor"
            };

            foreach (string nombre in nombresPropiedades)
            {
                try
                {
                    System.Reflection.PropertyInfo prop = overrideGraphics.GetType().GetProperty(nombre);

                    if (prop == null)
                        continue;

                    Autodesk.Revit.DB.Color c = prop.GetValue(overrideGraphics, null) as Autodesk.Revit.DB.Color;

                    if (c == null)
                        continue;

                    string hex = ColorToHex(c);

                    // En filtros/vista activa el negro puede ser un color real. Solo evitamos blanco puro
                    // como valor de respaldo porque suele lavar el visor.
                    if (string.Equals(hex, "#FFFFFF", System.StringComparison.OrdinalIgnoreCase))
                        continue;

                    if (EsHexUtil(hex))
                        return hex;
                }
                catch
                {
                }
            }

            return "";
        }

        private static string ObtenerColorOverrideHex(object overrideGraphics)
        {
            if (overrideGraphics == null)
                return "";

            string[] nombresPropiedades = new string[]
            {
                "SurfaceForegroundPatternColor",
                "ProjectionLineColor",
                "CutForegroundPatternColor",
                "CutLineColor"
            };

            foreach (string nombre in nombresPropiedades)
            {
                try
                {
                    System.Reflection.PropertyInfo prop = overrideGraphics.GetType().GetProperty(nombre);

                    if (prop == null)
                        continue;

                    Autodesk.Revit.DB.Color c = prop.GetValue(overrideGraphics, null) as Autodesk.Revit.DB.Color;

                    if (c == null)
                        continue;

                    string hex = ColorToHex(c);

                    // En filtros/vista activa el negro puede ser un color real. Solo evitamos blanco puro
                    // como valor de respaldo porque suele lavar el visor.
                    if (string.Equals(hex, "#FFFFFF", System.StringComparison.OrdinalIgnoreCase))
                        continue;

                    if (EsHexUtil(hex))
                        return hex;
                }
                catch
                {
                }
            }

            return "";
        }

        private static bool EsHexUtil(string hex)
        {
            if (string.IsNullOrWhiteSpace(hex))
                return false;

            string h = hex.Trim().TrimStart('#');

            if (h.Length != 6)
                return false;

            int r = System.Convert.ToInt32(h.Substring(0, 2), 16);
            int g = System.Convert.ToInt32(h.Substring(2, 2), 16);
            int b = System.Convert.ToInt32(h.Substring(4, 2), 16);

            // Para esta versión se respeta el color de sombreado del material de Revit,
            // incluso si es claro u oscuro. Solo se valida que sea un RGB correcto.
            return true;
        }

        private static string ColorSuavePorTexto(string texto)
        {
            string[] colores = new string[]
            {
                "#B8C0CC", "#C7B299", "#A8B8A0", "#B6A0A8", "#A7B7C8",
                "#C0B27C", "#9FB3B8", "#B4B4A1", "#B7A7C8", "#C8B0A0"
            };

            if (texto == null)
                texto = "";

            int hash = 17;

            foreach (char c in texto)
                hash = hash * 31 + c;

            if (hash < 0)
                hash = -hash;

            return colores[hash % colores.Length];
        }

        private static string ColorToHex(Autodesk.Revit.DB.Color c)
        {
            if (c == null)
                return "#9e9e9e";

            return "#" +
                ClampByte(c.Red).ToString("X2", CI) +
                ClampByte(c.Green).ToString("X2", CI) +
                ClampByte(c.Blue).ToString("X2", CI);
        }

        private static int ClampByte(int v)
        {
            if (v < 0)
                return 0;

            if (v > 255)
                return 255;

            return v;
        }

        private static string CrearRelacionesJson(System.Collections.Generic.List<VisorItem> items)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine("[");

            for (int i = 0; i < items.Count; i++)
            {
                VisorItem item = items[i];

                sb.Append("  {");
                sb.Append("\"ElementId\":\"" + JsonEscape(item.ElementId) + "\",");
                sb.Append("\"UniqueId\":\"" + JsonEscape(item.UniqueId) + "\",");
                sb.Append("\"MeshName\":\"" + JsonEscape(item.MeshName) + "\",");
                sb.Append("\"Categoria\":\"" + JsonEscape(item.Categoria) + "\",");
                sb.Append("\"Nombre\":\"" + JsonEscape(item.Nombre) + "\",");
                sb.Append("\"ColorHex\":\"" + JsonEscape(item.ColorHex) + "\",");
                sb.Append("\"Triangulos\":" + item.Triangulos.ToString(CI));
                sb.Append("}");

                if (i < items.Count - 1)
                    sb.Append(",");

                sb.AppendLine();
            }

            sb.AppendLine("]");
            return sb.ToString();
        }

        private static string CrearDashboardJson(System.Collections.Generic.List<VisorItem> items)
        {
            if (items == null)
                items = new System.Collections.Generic.List<VisorItem>();

            System.Collections.Generic.Dictionary<string, int> porCategoria =
                new System.Collections.Generic.Dictionary<string, int>(System.StringComparer.OrdinalIgnoreCase);

            System.Collections.Generic.Dictionary<string, int> triangulosPorCategoria =
                new System.Collections.Generic.Dictionary<string, int>(System.StringComparer.OrdinalIgnoreCase);

            int totalTriangulos = 0;

            foreach (VisorItem item in items)
            {
                if (item == null)
                    continue;

                string cat = string.IsNullOrWhiteSpace(item.Categoria) ? "Sin categoría" : item.Categoria;

                if (!porCategoria.ContainsKey(cat))
                    porCategoria[cat] = 0;

                if (!triangulosPorCategoria.ContainsKey(cat))
                    triangulosPorCategoria[cat] = 0;

                porCategoria[cat]++;
                triangulosPorCategoria[cat] += item.Triangulos;
                totalTriangulos += item.Triangulos;
            }

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine("{");
            sb.AppendLine("  \"Resumen\": {");
            sb.AppendLine("    \"TotalElementos\": " + items.Count.ToString(CI) + ",");
            sb.AppendLine("    \"TotalCategorias\": " + porCategoria.Keys.Count.ToString(CI) + ",");
            sb.AppendLine("    \"TotalTriangulos\": " + totalTriangulos.ToString(CI));
            sb.AppendLine("  },");
            sb.AppendLine("  \"Categorias\": [");

            int i = 0;
            foreach (string cat in porCategoria.Keys.OrderBy(x => x))
            {
                if (i > 0)
                    sb.AppendLine(",");

                sb.Append("    {\"Categoria\":\"");
                sb.Append(JsonEscape(cat));
                sb.Append("\",\"Cantidad\":");
                sb.Append(porCategoria[cat].ToString(CI));
                sb.Append(",\"Triangulos\":");
                sb.Append(triangulosPorCategoria[cat].ToString(CI));
                sb.Append("}");
                i++;
            }

            sb.AppendLine();
            sb.AppendLine("  ]");
            sb.AppendLine("}");

            return sb.ToString();
        }

        private static System.Collections.Generic.List<ScheduleInfo> ObtenerSchedules(
            Autodesk.Revit.DB.Document doc,
            System.Collections.Generic.List<VisorItem> items,
            System.Collections.Generic.Dictionary<string, PrecioUnitarioInfo> preciosUnitarios)
        {
            System.Collections.Generic.List<ScheduleInfo> resultado = new System.Collections.Generic.List<ScheduleInfo>();

            if (doc == null)
                return resultado;

            System.Collections.Generic.HashSet<string> idsConGeometria =
                new System.Collections.Generic.HashSet<string>(System.StringComparer.OrdinalIgnoreCase);

            if (items != null)
            {
                foreach (VisorItem item in items)
                {
                    if (item != null && !string.IsNullOrWhiteSpace(item.ElementId))
                        idsConGeometria.Add(item.ElementId);
                }
            }

            Autodesk.Revit.DB.FilteredElementCollector collectorSchedules =
                new Autodesk.Revit.DB.FilteredElementCollector(doc)
                    .OfClass(typeof(Autodesk.Revit.DB.ViewSchedule));

            foreach (Autodesk.Revit.DB.Element elem in collectorSchedules)
            {
                Autodesk.Revit.DB.ViewSchedule schedule = elem as Autodesk.Revit.DB.ViewSchedule;

                if (schedule == null)
                    continue;

                try
                {
                    if (schedule.IsTemplate)
                        continue;
                }
                catch
                {
                }

                ScheduleInfo info = new ScheduleInfo();
                info.ScheduleId = IdToText(schedule.Id);
                info.Nombre = schedule.Name ?? "";
                info.Codigo = ExtraerCodigoPartida(info.Nombre);
                info.Tipo = "Tabla de planificación";

                DatosMetradoSchedule datosMetrado = ObtenerMetradoTotalSchedule(schedule);
                info.Unidad = datosMetrado.Unidad;
                info.MetradoTotalTexto = datosMetrado.MetradoTexto;
                info.MetradoTotal = datosMetrado.Metrado;

                AplicarPrecioUnitario(info, preciosUnitarios);

                try
                {
                    Autodesk.Revit.DB.FilteredElementCollector elementosTabla =
                        new Autodesk.Revit.DB.FilteredElementCollector(doc, schedule.Id)
                            .WhereElementIsNotElementType();

                    foreach (Autodesk.Revit.DB.Element e in elementosTabla)
                    {
                        if (e == null)
                            continue;

                        string id = IdToText(e.Id);

                        // Para el visor, solo interesa aislar los elementos que también tienen geometría exportada.
                        if (idsConGeometria.Count > 0 && !idsConGeometria.Contains(id))
                            continue;

                        if (!info.ElementIds.Contains(id))
                            info.ElementIds.Add(id);
                    }
                }
                catch
                {
                    // Algunas tablas no exponen elementos físicos 3D. Se listan igual como referencia.
                }

                info.ElementIds.Sort((a, b) =>
                {
                    long la = 0;
                    long lb = 0;
                    long.TryParse(a, out la);
                    long.TryParse(b, out lb);
                    return la.CompareTo(lb);
                });

                resultado.Add(info);
            }

            resultado.Sort((a, b) => string.Compare(a.Nombre, b.Nombre, System.StringComparison.CurrentCultureIgnoreCase));
            return resultado;
        }

        private class DatosMetradoSchedule
        {
            public string Unidad { get; set; }
            public string MetradoTexto { get; set; }
            public double Metrado { get; set; }
        }

        private static DatosMetradoSchedule ObtenerMetradoTotalSchedule(Autodesk.Revit.DB.ViewSchedule schedule)
        {
            DatosMetradoSchedule datos = new DatosMetradoSchedule();
            datos.Unidad = ObtenerUnidadDesdeUltimaColumnaSchedule(schedule);
            datos.MetradoTexto = "";
            datos.Metrado = 0.0;

            if (schedule == null)
                return datos;

            try
            {
                Autodesk.Revit.DB.TableData tableData = schedule.GetTableData();

                if (tableData == null)
                    return datos;

                Autodesk.Revit.DB.TableSectionData body = tableData.GetSectionData(Autodesk.Revit.DB.SectionType.Body);

                if (body == null)
                    return datos;

                int rows = body.NumberOfRows;
                int cols = body.NumberOfColumns;

                if (rows <= 0 || cols <= 0)
                    return datos;

                for (int r = rows - 1; r >= 0; r--)
                {
                    for (int c = cols - 1; c >= 0; c--)
                    {
                        string texto = ObtenerTextoCeldaSchedule(schedule, Autodesk.Revit.DB.SectionType.Body, r, c);
                        double valor = 0.0;

                        if (TryParseNumeroFlexible(texto, out valor))
                        {
                            datos.MetradoTexto = texto;
                            datos.Metrado = valor;
                            return datos;
                        }
                    }
                }
            }
            catch
            {
            }

            return datos;
        }

        private static string ObtenerTextoCeldaSchedule(
            Autodesk.Revit.DB.ViewSchedule schedule,
            Autodesk.Revit.DB.SectionType sectionType,
            int row,
            int col)
        {
            if (schedule == null)
                return "";

            try
            {
                string t = schedule.GetCellText(sectionType, row, col);

                if (!string.IsNullOrWhiteSpace(t))
                    return t.Trim();
            }
            catch
            {
            }

            return "";
        }

        private static string ObtenerUnidadDesdeUltimaColumnaSchedule(Autodesk.Revit.DB.ViewSchedule schedule)
        {
            if (schedule == null)
                return "";

            try
            {
                Autodesk.Revit.DB.TableData tableData = schedule.GetTableData();

                if (tableData == null)
                    return "";

                Autodesk.Revit.DB.TableSectionData body = tableData.GetSectionData(Autodesk.Revit.DB.SectionType.Body);

                if (body == null)
                    return "";

                int bodyCols = body.NumberOfColumns;

                if (bodyCols <= 0)
                    return "";

                int colUnidad = bodyCols - 1;

                // PRIORIDAD 1:
                // La unidad se toma del ENCABEZADO de la última columna de la tabla.
                // Ejemplo: "ÁREA TOTAL (m²)"  ->  "m2"
                //          "VOLUMEN TOTAL (m³)" -> "m3"
                //          "CANTIDAD TOTAL (und)" -> "und"
                string unidadDesdeHeader = ObtenerUnidadDesdeHeaderColumna(schedule, tableData, colUnidad);

                if (!string.IsNullOrWhiteSpace(unidadDesdeHeader))
                    return unidadDesdeHeader;

                // PRIORIDAD 2:
                // Si por celdas combinadas Revit no devuelve texto en la última columna exacta,
                // se revisan los encabezados de derecha a izquierda y se toma el primer texto
                // que contenga unidad entre paréntesis.
                string unidadDesdeHeaderDerecha = ObtenerUnidadDesdeHeadersDerechaIzquierda(schedule, tableData, bodyCols);

                if (!string.IsNullOrWhiteSpace(unidadDesdeHeaderDerecha))
                    return unidadDesdeHeaderDerecha;

                // RESPALDO:
                // Si alguna tabla antigua tenía la unidad escrita en la última columna del cuerpo,
                // se conserva esa lectura.
                int rows = body.NumberOfRows;

                for (int r = rows - 1; r >= 0; r--)
                {
                    string texto = ObtenerTextoCeldaSchedule(schedule, Autodesk.Revit.DB.SectionType.Body, r, colUnidad);
                    string unidad = NormalizarUnidadSchedule(texto);

                    if (!string.IsNullOrWhiteSpace(unidad))
                        return unidad;
                }
            }
            catch
            {
            }

            return "";
        }

        private static string ObtenerUnidadDesdeHeaderColumna(
            Autodesk.Revit.DB.ViewSchedule schedule,
            Autodesk.Revit.DB.TableData tableData,
            int col)
        {
            if (schedule == null || tableData == null || col < 0)
                return "";

            try
            {
                Autodesk.Revit.DB.TableSectionData header = tableData.GetSectionData(Autodesk.Revit.DB.SectionType.Header);

                if (header == null)
                    return "";

                int rows = header.NumberOfRows;
                int cols = header.NumberOfColumns;

                if (rows <= 0 || cols <= 0)
                    return "";

                int c = col;
                if (c >= cols)
                    c = cols - 1;

                for (int r = rows - 1; r >= 0; r--)
                {
                    string texto = ObtenerTextoCeldaSchedule(schedule, Autodesk.Revit.DB.SectionType.Header, r, c);
                    string unidad = ExtraerUnidadEntreParentesis(texto);

                    if (!string.IsNullOrWhiteSpace(unidad))
                        return unidad;
                }
            }
            catch
            {
            }

            return "";
        }

        private static string ObtenerUnidadDesdeHeadersDerechaIzquierda(
            Autodesk.Revit.DB.ViewSchedule schedule,
            Autodesk.Revit.DB.TableData tableData,
            int bodyCols)
        {
            if (schedule == null || tableData == null)
                return "";

            try
            {
                Autodesk.Revit.DB.TableSectionData header = tableData.GetSectionData(Autodesk.Revit.DB.SectionType.Header);

                if (header == null)
                    return "";

                int rows = header.NumberOfRows;
                int cols = header.NumberOfColumns;

                if (rows <= 0 || cols <= 0)
                    return "";

                int colMax = System.Math.Min(cols - 1, bodyCols - 1);

                for (int c = colMax; c >= 0; c--)
                {
                    for (int r = rows - 1; r >= 0; r--)
                    {
                        string texto = ObtenerTextoCeldaSchedule(schedule, Autodesk.Revit.DB.SectionType.Header, r, c);
                        string unidad = ExtraerUnidadEntreParentesis(texto);

                        if (!string.IsNullOrWhiteSpace(unidad))
                            return unidad;
                    }
                }
            }
            catch
            {
            }

            return "";
        }

        private static string ExtraerUnidadEntreParentesis(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return "";

            string t = texto.Trim().Replace("\r", " ").Replace("\n", " ").Trim();

            if (string.IsNullOrWhiteSpace(t))
                return "";

            try
            {
                System.Text.RegularExpressions.MatchCollection matches =
                    System.Text.RegularExpressions.Regex.Matches(t, @"\(([^\(\)]{1,30})\)");

                for (int i = matches.Count - 1; i >= 0; i--)
                {
                    string contenido = matches[i].Groups[1].Value.Trim();
                    string unidad = NormalizarUnidadSchedule(contenido);

                    if (!string.IsNullOrWhiteSpace(unidad))
                        return unidad;
                }
            }
            catch
            {
            }

            return "";
        }

        private static string NormalizarUnidadSchedule(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return "";

            string t = texto.Trim();
            t = t.Replace("\r", " ").Replace("\n", " ").Trim();

            if (string.IsNullOrWhiteSpace(t))
                return "";

            // Normaliza superíndices y variantes frecuentes.
            t = t.Replace("㎡", "m2");
            t = t.Replace("㎥", "m3");
            t = t.Replace("m²", "m2").Replace("M²", "m2");
            t = t.Replace("m³", "m3").Replace("M³", "m3");
            t = t.Replace("M2", "m2").Replace("M3", "m3");

            string sinEspacios = t.Replace(" ", "").Replace(".", "").Trim();
            string upper = sinEspacios.ToUpperInvariant();

            double numero = 0.0;
            if (TryParseNumeroFlexible(t, out numero))
                return "";

            if (upper.Contains("TOTAL") || upper.Contains("GENERAL") || upper.Contains("METRADO") || upper.Contains("CANTIDAD") || upper.Contains("PRECIO") || upper.Contains("PARCIAL") || upper.Contains("AREA") || upper.Contains("ÁREA") || upper.Contains("VOLUMEN") || upper.Contains("LONGITUD"))
                return "";

            if (upper == "M3" || upper == "M^3" || upper == "M03" || upper == "MTS3" || upper == "M3TOTAL" || upper.Contains("METROCUB") || upper.Contains("METROSCUB"))
                return "m3";

            if (upper == "M2" || upper == "M^2" || upper == "M02" || upper == "MTS2" || upper == "M2TOTAL" || upper.Contains("METROCUAD") || upper.Contains("METROSCUAD"))
                return "m2";

            if (upper == "ML" || upper == "M L" || upper == "M" || upper == "MT" || upper == "MTS" || upper.Contains("METROLINEAL") || upper.Contains("METROSLINEALES"))
                return "m";

            if (upper == "KG" || upper == "KGS" || upper == "KILOGRAMO" || upper == "KILOGRAMOS")
                return "kg";

            if (upper == "UND" || upper == "UNID" || upper == "UNIDAD" || upper == "UNIDADES" || upper == "U" || upper == "PTO" || upper == "PUNTOS")
                return "und";

            if (upper == "GLB" || upper == "GLOBAL")
                return "glb";

            if (upper == "JGO" || upper == "JUEGO" || upper == "JUEGOS")
                return "jgo";

            if (upper == "MES" || upper == "DIA" || upper == "DÍA" || upper == "HORA" || upper == "HH")
                return t;

            // Si el contenido del paréntesis es una unidad personalizada corta, se respeta.
            // Ejemplos: pza, lote, par, und/día.
            if (t.Length <= 15 && System.Text.RegularExpressions.Regex.IsMatch(t, @"[A-Za-zÁÉÍÓÚáéíóúÑñ]") && !System.Text.RegularExpressions.Regex.IsMatch(t, @"[0-9]{2,}"))
                return t;

            return "";
        }

        private static string ExtraerCodigoPartida(string nombreTabla)
        {
            if (string.IsNullOrWhiteSpace(nombreTabla)) return "";
            string t = nombreTabla.Trim();
            try
            {
                System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(t, @"^\s*([0-9]+(?:[\.\-][0-9A-Za-z]+)+|[0-9]+(?:\.[0-9]+)*)");
                if (m.Success) return m.Groups[1].Value.Trim();
            }
            catch { }
            int i = t.IndexOf(' ');
            if (i > 0) return t.Substring(0, i).Trim();
            return t;
        }

        private static string NormalizarCodigoPrecio(string codigo)
        {
            if (string.IsNullOrWhiteSpace(codigo)) return "";
            return codigo.Trim().ToUpperInvariant().Replace(" ", "");
        }

        private static string LimpiarRutaCsvPrecios(string rutaCsvPrecios)
        {
            if (string.IsNullOrWhiteSpace(rutaCsvPrecios))
                return "";

            return rutaCsvPrecios.Trim().Trim('\"');
        }

        private static System.Collections.Generic.Dictionary<string, PrecioUnitarioInfo> LeerPreciosUnitarios(string path)
        {
            System.Collections.Generic.Dictionary<string, PrecioUnitarioInfo> precios = new System.Collections.Generic.Dictionary<string, PrecioUnitarioInfo>(System.StringComparer.OrdinalIgnoreCase);
            if (string.IsNullOrWhiteSpace(path) || !System.IO.File.Exists(path)) return precios;
            try
            {
                string[] lineas = System.IO.File.ReadAllLines(path, new System.Text.UTF8Encoding(true));
                for (int i = 0; i < lineas.Length; i++)
                {
                    string linea = lineas[i];
                    if (string.IsNullOrWhiteSpace(linea) || linea.TrimStart().StartsWith("#")) continue;
                    string[] partes = SepararLineaPrecios(linea);
                    if (partes == null || partes.Length < 3) continue;
                    string codigo = (partes[0] ?? "").Trim();
                    if (i == 0 && codigo.Equals("Codigo", System.StringComparison.OrdinalIgnoreCase)) continue;
                    string unidad = (partes[1] ?? "").Trim();
                    string precioTxt = (partes[2] ?? "").Trim();
                    double precio = 0.0;
                    if (!TryParseNumeroFlexible(precioTxt, out precio)) continue;
                    string key = NormalizarCodigoPrecio(codigo);
                    if (string.IsNullOrWhiteSpace(key)) continue;
                    precios[key] = new PrecioUnitarioInfo() { Codigo = codigo, Unidad = unidad, PrecioUnitario = precio, PrecioUnitarioTexto = precioTxt };
                }
            }
            catch { }
            return precios;
        }

        private static string[] SepararLineaPrecios(string linea)
        {
            if (linea == null) return new string[0];
            if (linea.Contains(";")) return linea.Split(';');
            return linea.Split(',');
        }

        private static void AplicarPrecioUnitario(ScheduleInfo info, System.Collections.Generic.Dictionary<string, PrecioUnitarioInfo> preciosUnitarios)
        {
            if (info == null) return;
            info.PrecioUnitarioTexto = "";
            info.PrecioUnitario = 0.0;
            info.ParcialTexto = "";
            info.Parcial = 0.0;
            info.TienePrecio = false;
            if (preciosUnitarios == null || preciosUnitarios.Count == 0) return;
            string key = NormalizarCodigoPrecio(info.Codigo);
            if (string.IsNullOrWhiteSpace(key) || !preciosUnitarios.ContainsKey(key)) return;
            PrecioUnitarioInfo precio = preciosUnitarios[key];
            if (precio == null) return;
            if (string.IsNullOrWhiteSpace(info.Unidad) && !string.IsNullOrWhiteSpace(precio.Unidad)) info.Unidad = precio.Unidad;
            info.PrecioUnitario = precio.PrecioUnitario;
            info.PrecioUnitarioTexto = precio.PrecioUnitarioTexto;
            info.Parcial = info.MetradoTotal * precio.PrecioUnitario;
            info.ParcialTexto = FormatMoneda(info.Parcial);
            info.TienePrecio = true;
        }

        private static void EscribirPlantillaPreciosUnitarios(string path, System.Collections.Generic.List<ScheduleInfo> schedules)
        {
            if (string.IsNullOrWhiteSpace(path)) return;
            try { System.IO.File.WriteAllLines(path, CrearLineasPlantillaPrecios(schedules, false), new System.Text.UTF8Encoding(true)); } catch { }
        }

        private static void AsegurarPlantillaPreciosBase(string path, System.Collections.Generic.List<ScheduleInfo> schedules)
        {
            if (string.IsNullOrWhiteSpace(path)) return;
            try { if (!System.IO.File.Exists(path)) System.IO.File.WriteAllLines(path, CrearLineasPlantillaPrecios(schedules, true), new System.Text.UTF8Encoding(true)); } catch { }
        }

        private static System.Collections.Generic.List<string> CrearLineasPlantillaPrecios(System.Collections.Generic.List<ScheduleInfo> schedules, bool incluirComentario)
        {
            System.Collections.Generic.List<string> lineas = new System.Collections.Generic.List<string>();
            if (incluirComentario)
            {
                lineas.Add("# Archivo de precios unitarios para MYG Dashboard BIM Local");
                lineas.Add("# Llena PrecioUnitario y conserva el Codigo igual al código inicial de la tabla de planificación.");
                lineas.Add("# Separador recomendado: punto y coma (;). Ejemplo: 02.03.05.03;m3;520.00");
            }
            lineas.Add("Codigo;Unidad;PrecioUnitario;NombreTabla;MetradoTotalReferencia");
            if (schedules == null) return lineas;
            foreach (ScheduleInfo s in schedules.OrderBy(x => x.Codigo).ThenBy(x => x.Nombre))
            {
                if (s == null) continue;
                lineas.Add(CsvSemicolon(s.Codigo, s.Unidad, s.TienePrecio ? Format(s.PrecioUnitario) : "", s.Nombre, s.MetradoTotalTexto));
            }
            return lineas;
        }

        private static bool TryParseNumeroFlexible(string texto, out double valor)
        {
            valor = 0.0;
            if (string.IsNullOrWhiteSpace(texto)) return false;
            string t = texto.Trim();
            t = t.Replace("S/", "").Replace("s/", "").Replace("$", "").Replace("m³", "").Replace("m²", "").Replace("M³", "").Replace("M²", "");
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            foreach (char ch in t) if (char.IsDigit(ch) || ch == '.' || ch == ',' || ch == '-') sb.Append(ch);
            string n = sb.ToString();
            if (string.IsNullOrWhiteSpace(n)) return false;
            int lastDot = n.LastIndexOf('.');
            int lastComma = n.LastIndexOf(',');
            if (lastDot >= 0 && lastComma >= 0)
            {
                if (lastDot > lastComma) n = n.Replace(",", "");
                else { n = n.Replace(".", ""); n = n.Replace(',', '.'); }
            }
            else if (lastComma >= 0)
            {
                int dec = n.Length - lastComma - 1;
                if (dec == 1 || dec == 2 || dec == 3) n = n.Replace(',', '.');
                else n = n.Replace(",", "");
            }
            return double.TryParse(n, System.Globalization.NumberStyles.Float, CI, out valor);
        }

        private static string FormatNumeroJson(double valor)
        {
            if (double.IsNaN(valor) || double.IsInfinity(valor)) return "0";
            return valor.ToString("0.######", CI);
        }

        private static string FormatMoneda(double valor)
        {
            return "S/ " + valor.ToString("#,##0.00", CI);
        }

        private static string CsvSemicolon(params string[] values)
        {
            if (values == null || values.Length == 0) return "";
            System.Collections.Generic.List<string> result = new System.Collections.Generic.List<string>();
            foreach (string raw in values)
            {
                string v = raw ?? "";
                v = v.Replace("\r", " ").Replace("\n", " ");
                if (v.Contains(";") || v.Contains("\"") || v.Contains("\n")) v = "\"" + v.Replace("\"", "\"\"") + "\"";
                result.Add(v);
            }
            return string.Join(";", result.ToArray());
        }

        private static string CrearSchedulesJson(System.Collections.Generic.List<ScheduleInfo> schedules)
        {
            if (schedules == null)
                schedules = new System.Collections.Generic.List<ScheduleInfo>();

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine("[");

            for (int i = 0; i < schedules.Count; i++)
            {
                ScheduleInfo s = schedules[i];

                sb.Append("  {");
                sb.Append("\"ScheduleId\":\"" + JsonEscape(s.ScheduleId) + "\",");
                sb.Append("\"Codigo\":\"" + JsonEscape(s.Codigo) + "\",");
                sb.Append("\"Nombre\":\"" + JsonEscape(s.Nombre) + "\",");
                sb.Append("\"Tipo\":\"" + JsonEscape(s.Tipo) + "\",");
                sb.Append("\"Unidad\":\"" + JsonEscape(s.Unidad) + "\",");
                sb.Append("\"MetradoTotalTexto\":\"" + JsonEscape(s.MetradoTotalTexto) + "\",");
                sb.Append("\"MetradoTotal\":" + FormatNumeroJson(s.MetradoTotal) + ",");
                sb.Append("\"PrecioUnitarioTexto\":\"" + JsonEscape(s.PrecioUnitarioTexto) + "\",");
                sb.Append("\"PrecioUnitario\":" + FormatNumeroJson(s.PrecioUnitario) + ",");
                sb.Append("\"ParcialTexto\":\"" + JsonEscape(s.ParcialTexto) + "\",");
                sb.Append("\"Parcial\":" + FormatNumeroJson(s.Parcial) + ",");
                sb.Append("\"TienePrecio\":" + (s.TienePrecio ? "true" : "false") + ",");
                sb.Append("\"CantidadElementos\":" + (s.ElementIds == null ? 0 : s.ElementIds.Count).ToString(CI) + ",");
                sb.Append("\"ElementIds\":[");

                if (s.ElementIds != null)
                {
                    for (int j = 0; j < s.ElementIds.Count; j++)
                    {
                        if (j > 0)
                            sb.Append(",");

                        sb.Append("\"" + JsonEscape(s.ElementIds[j]) + "\"");
                    }
                }

                sb.Append("]}");

                if (i < schedules.Count - 1)
                    sb.Append(",");

                sb.AppendLine();
            }

            sb.AppendLine("]");
            return sb.ToString();
        }

        private static string CrearMaterialesJson(System.Collections.Generic.Dictionary<string, string> materialesHex)
        {
            if (materialesHex == null)
                materialesHex = new System.Collections.Generic.Dictionary<string, string>();

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine("{");

            int i = 0;
            foreach (System.Collections.Generic.KeyValuePair<string, string> kv in materialesHex.OrderBy(x => x.Key))
            {
                if (i > 0)
                    sb.AppendLine(",");

                sb.Append("  \"" + JsonEscape(kv.Key) + "\":\"" + JsonEscape(kv.Value) + "\"");
                i++;
            }

            sb.AppendLine();
            sb.AppendLine("}");
            return sb.ToString();
        }

        private static string CrearHtmlViewer(
            string titulo,
            string objBase64,
            string relacionesJson,
            string dashboardJson,
            string schedulesJson,
            string materialesJson,
            bool htmlEmbebido,
            string objUrl)
        {
            string objFinal = htmlEmbebido ? objBase64 : "";
            string jsonBase64 = System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(relacionesJson ?? "[]"));
            string dashboardBase64 = System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(dashboardJson ?? "{}"));
            string schedulesBase64 = System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(schedulesJson ?? "[]"));
            string materialsBase64 = System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(materialesJson ?? "{}"));

            System.Text.StringBuilder html = new System.Text.StringBuilder();

            html.AppendLine("<!DOCTYPE html>");
            html.AppendLine("<html lang='es'>");
            html.AppendLine("<head>");
            html.AppendLine("<meta charset='utf-8'>");
            html.AppendLine("<meta name='viewport' content='width=device-width,initial-scale=1'>");
            html.AppendLine("<title>MYG Dashboard BIM Local</title>");
            html.AppendLine("<style>");
            html.AppendLine(":root{--bg:#0f172a;--panel:#111827;--panel2:#1f2937;--line:#334155;--txt:#e5e7eb;--muted:#94a3b8;--blue:#2563eb;--blue2:#1d4ed8;--ok:#22c55e;--warn:#b45309;}");
            html.AppendLine("*{box-sizing:border-box}body{margin:0;overflow:hidden;background:var(--bg);color:var(--txt);font-family:Segoe UI,Arial,sans-serif;font-size:13px}");
            html.AppendLine("#app{position:absolute;inset:0;display:grid;grid-template-columns:350px 1fr 390px;grid-template-rows:58px 1fr 235px;grid-template-areas:'top top top' 'left view right' 'bottom bottom bottom'}");
            html.AppendLine("#top{grid-area:top;background:#0b1220;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:10px;padding:10px 12px}");
            html.AppendLine("#brand{font-weight:800;font-size:16px;white-space:nowrap}.tag{padding:4px 8px;border:1px solid var(--line);border-radius:999px;color:var(--muted)}");
            html.AppendLine("#left{grid-area:left;background:var(--panel);border-right:1px solid var(--line);overflow:auto;padding:12px}");
            html.AppendLine("#right{grid-area:right;background:var(--panel);border-left:1px solid var(--line);overflow:auto;padding:12px}");
            html.AppendLine("#view{grid-area:view;position:relative;background:linear-gradient(180deg,#dbe4ee 0%,#f8fafc 55%,#eef2f7 100%)}#container{position:absolute;inset:0}");
            html.AppendLine("#bottom{grid-area:bottom;background:#0b1220;border-top:1px solid var(--line);display:grid;grid-template-columns:1fr 390px;gap:0;min-height:0}");
            html.AppendLine(".section{margin-bottom:12px}.section h3{margin:0 0 8px 0;font-size:12px;text-transform:uppercase;color:#cbd5e1;letter-spacing:.06em}.cards{display:grid;grid-template-columns:1fr 1fr;gap:8px}.card{background:var(--panel2);border:1px solid var(--line);border-radius:10px;padding:10px}.card .label{color:var(--muted);font-size:12px}.card .value{font-size:22px;font-weight:800;margin-top:4px}");
            html.AppendLine("input,select,button{height:32px;border-radius:7px;border:1px solid var(--line);background:#0b1220;color:var(--txt);padding:0 9px}input{width:100%}button{cursor:pointer;background:var(--blue);border-color:var(--blue);font-weight:700}button:hover{background:var(--blue2)}button.gray{background:#374151;border-color:#4b5563}button.warn{background:#b45309;border-color:#b45309}.row{display:flex;gap:7px;align-items:center}.row>*{min-width:0}.grow{flex:1}");
            html.AppendLine("#catButtons{display:flex;flex-wrap:wrap;gap:7px}.catBtn{font-size:12px;height:29px;background:#172033;border-color:#334155}.catBtn.active{background:var(--blue);border-color:var(--blue)}");
            html.AppendLine(".scheduleBox{max-height:185px;overflow:auto;border:1px solid var(--line);border-radius:10px;background:#0b1220}.scheduleItem{padding:8px 9px;border-bottom:1px solid #1e293b;cursor:pointer}.scheduleItem:hover{background:#172033}.scheduleItem.active{background:#1e3a8a}.scheduleName{font-weight:700;font-size:12px}.scheduleMeta{color:var(--muted);font-size:11px;margin-top:3px}");
            html.AppendLine(".barItem{margin:7px 0}.barLabel{display:flex;justify-content:space-between;color:#cbd5e1;font-size:12px;margin-bottom:3px}.barTrack{height:8px;background:#0b1220;border:1px solid #263244;border-radius:10px;overflow:hidden}.barFill{height:100%;background:#3b82f6;border-radius:10px}");
            html.AppendLine(".tableWrap{overflow:auto;height:100%;padding:10px}table{width:100%;border-collapse:collapse}th,td{border-bottom:1px solid #1e293b;padding:6px 8px;text-align:left;white-space:nowrap}th{position:sticky;top:0;background:#0b1220;color:#cbd5e1;z-index:1}tr:hover{background:#172033}tr.sel{background:#1e3a8a}");
            html.AppendLine("#props{background:#0b1220;border:1px solid var(--line);border-radius:10px;padding:10px;line-height:1.55;word-break:break-word}.muted{color:var(--muted)}.pill{display:inline-block;padding:3px 7px;background:#172033;border:1px solid #334155;border-radius:999px;margin:2px 4px 2px 0}.small{font-size:12px}.splitTitle{font-weight:700;color:#fff;margin-bottom:7px}");
            html.AppendLine("#toast{position:absolute;left:12px;bottom:12px;background:rgba(15,23,42,.94);border:1px solid var(--line);border-radius:10px;padding:10px;max-width:560px;z-index:6;box-shadow:0 12px 28px rgba(0,0,0,.35)}");
            html.AppendLine("#ctxMenu{position:absolute;display:none;z-index:20;min-width:190px;background:rgba(15,23,42,.98);border:1px solid var(--line);border-radius:10px;padding:6px;box-shadow:0 16px 36px rgba(0,0,0,.42)}#ctxMenu .ctxTitle{color:#cbd5e1;font-weight:800;font-size:12px;padding:6px 8px;border-bottom:1px solid #1e293b;margin-bottom:4px;max-width:260px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#ctxMenu button{display:block;width:100%;height:30px;text-align:left;background:transparent;border:0;color:var(--txt);font-weight:600;border-radius:7px}#ctxMenu button:hover{background:#1e3a8a}");
            html.AppendLine("#viewerToolbar{position:absolute;left:50%;bottom:18px;transform:translateX(-50%);z-index:12;display:flex;align-items:center;gap:7px;background:rgba(15,23,42,.92);border:1px solid rgba(148,163,184,.45);border-radius:12px;padding:7px 8px;box-shadow:0 14px 34px rgba(0,0,0,.34);backdrop-filter:blur(8px)}");
            html.AppendLine("#partidaTop{position:absolute;left:50%;top:14px;transform:translateX(-50%);z-index:14;width:min(760px,calc(100% - 46px));display:none;background:rgba(15,23,42,.92);border:1px solid rgba(96,165,250,.55);border-radius:13px;padding:10px 12px;box-shadow:0 16px 38px rgba(0,0,0,.34);backdrop-filter:blur(8px);pointer-events:auto}#partidaTop.show{display:block}.partidaHead{display:flex;align-items:flex-start;gap:10px}.partidaCode{flex:0 0 auto;background:#2563eb;border:1px solid #60a5fa;border-radius:999px;padding:4px 9px;font-weight:900;color:white;font-size:12px}.partidaTitle{flex:1;min-width:0;color:#fff;font-weight:900;font-size:14px;line-height:1.28}.partidaClose{height:25px;min-width:25px;padding:0 7px;border-radius:7px;background:#111827;border:1px solid #334155;color:#cbd5e1;font-weight:900}.partidaGrid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:7px;margin-top:9px}.partidaData{background:rgba(15,23,42,.78);border:1px solid rgba(148,163,184,.25);border-radius:9px;padding:7px 8px;min-width:0}.partidaData .k{font-size:10px;text-transform:uppercase;letter-spacing:.06em;color:#94a3b8}.partidaData .v{font-size:13px;font-weight:900;color:#e5e7eb;margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.partidaData .money{color:#bbf7d0}.partidaNote{margin-top:7px;font-size:11px;color:#cbd5e1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}");
            html.AppendLine(".toolGroup{display:flex;gap:5px;padding:0 6px;border-right:1px solid rgba(148,163,184,.28)}.toolGroup:last-child{border-right:0}.toolBtn{height:34px;min-width:36px;padding:0 10px;background:#111827;border:1px solid #334155;border-radius:8px;color:#e5e7eb;font-size:15px;font-weight:800;line-height:1}.toolBtn:hover{background:#1f2937;border-color:#64748b}.toolBtn.active{background:#2563eb;border-color:#60a5fa;color:#fff}.toolBtn.warnTool{background:#7c2d12;border-color:#c2410c}.toolBtn .txt{font-size:12px;margin-left:5px;font-weight:700}.fpHint{position:absolute;left:50%;top:76px;transform:translateX(-50%);z-index:13;background:rgba(15,23,42,.92);border:1px solid var(--line);border-radius:10px;padding:9px 12px;color:#e5e7eb;display:none;box-shadow:0 12px 28px rgba(0,0,0,.30)}");
            html.AppendLine(".measureSprite{pointer-events:none}");
            html.AppendLine(".fpCursor{display:none;position:absolute;left:50%;top:50%;width:28px;height:28px;transform:translate(-50%,-50%);z-index:18;pointer-events:none;border:2px solid rgba(255,255,255,.95);border-radius:50%;box-shadow:0 0 0 2px rgba(15,23,42,.55),0 0 14px rgba(96,165,250,.45)}.fpCursor:before,.fpCursor:after{content:'';position:absolute;background:rgba(255,255,255,.95);box-shadow:0 0 0 1px rgba(15,23,42,.45)}.fpCursor:before{left:50%;top:-9px;width:2px;height:44px;transform:translateX(-50%)}.fpCursor:after{top:50%;left:-9px;height:2px;width:44px;transform:translateY(-50%)}.fpCursor.medir{border-color:#facc15;box-shadow:0 0 0 2px rgba(15,23,42,.55),0 0 16px rgba(250,204,21,.70)}.fpCursor.medir:before,.fpCursor.medir:after{background:#facc15}");
            html.AppendLine("@media(max-width:1250px){#app{grid-template-columns:320px 1fr;grid-template-areas:'top top' 'left view' 'bottom bottom'}#right{display:none}}");
            html.AppendLine("</style>");
            html.AppendLine("</head>");
            html.AppendLine("<body>");
            html.AppendLine("<div id='app'>");
            html.AppendLine("<div id='top'><div id='brand'>MYG Dashboard BIM Local</div><span class='tag' id='modeloTag'></span><span class='tag'>Controles tipo Revit</span><span class='tag'>Modo rápido</span><div class='grow'></div><button onclick='mostrarTodo()'>Mostrar todo</button><button class='gray' onclick='vistaIso()'>Isométrica</button><button class='gray' onclick='toggleModoAlambricoResto()'>Resto alámbrico</button><button class='gray' onclick='toggleBordes()'>Bordes</button><button class='gray' onclick='encuadrar()'>Encuadrar</button><button class='gray' onclick='capturarPNG()'>Captura PNG</button></div>");
            html.AppendLine("<div id='left'>");
            html.AppendLine("<div class='section'><h3>Resumen</h3><div class='cards'><div class='card'><div class='label'>Elementos</div><div class='value' id='cardElementos'>0</div></div><div class='card'><div class='label'>Categorías</div><div class='value' id='cardCategorias'>0</div></div><div class='card'><div class='label'>Tablas</div><div class='value' id='cardSchedules'>0</div></div><div class='card'><div class='label'>Visibles</div><div class='value' id='cardVisibles'>0</div></div></div></div>");
            html.AppendLine("<div class='section'><h3>Búsqueda</h3><div class='row'><input id='txtBuscar' placeholder='ElementId / categoría / nombre'><button onclick='buscar()'>Buscar</button></div><div class='row' style='margin-top:7px'><button onclick='aislarBusqueda()'>Aislar</button><button class='gray' onclick='limpiarBusqueda()'>Limpiar</button></div></div>");
            html.AppendLine("<div class='section'><h3>Tablas de planificación</h3><div class='row'><input id='txtBuscarSchedule' placeholder='Buscar tabla de metrado' oninput='pintarSchedules()'><button class='gray' onclick='limpiarSchedule()'>Todas</button></div><div id='scheduleList' class='scheduleBox' style='margin-top:8px'></div></div>");
            html.AppendLine("<div class='section'><h3>Categorías</h3><div id='catButtons'></div></div>");
            html.AppendLine("<div class='section'><h3>Elementos por categoría</h3><div id='bars'></div></div>");
            html.AppendLine("</div>");
            html.AppendLine("<div id='view'><div id='container'></div><div id='partidaTop' class='partidaTop'></div><div id='fpCursor' class='fpCursor'></div><div id='fpHint' class='fpHint'>Primera persona activa: WASD para moverte, mouse para mirar, Shift rápido, Esc para salir. Puedes pulsar M para medir desde el centro.</div><div id='viewerToolbar'><div class='toolGroup'><button id='toolSelect' class='toolBtn active' title='Seleccionar'>↖</button><button id='toolMedir' class='toolBtn' title='Medir distancia' onclick='toggleMedicion()'>📏<span class='txt'>Medir</span></button><button class='toolBtn' title='Limpiar mediciones' onclick='limpiarMediciones()'>✕</button></div><div class='toolGroup'><button id='toolFP' class='toolBtn' title='Primera persona' onclick='togglePrimeraPersona()'>🚶<span class='txt'>1ra</span></button><button class='toolBtn' title='Isométrica' onclick='vistaIso()'>⌂</button><button class='toolBtn' title='Encuadrar' onclick='encuadrar()'>▣</button></div><div class='toolGroup'><button class='toolBtn' title='Mostrar todo' onclick='mostrarTodo()'>☷</button><button class='toolBtn' title='Resto alámbrico' onclick='toggleModoAlambricoResto()'>◩</button><button class='toolBtn' title='Bordes' onclick='toggleBordes()'>▥</button><button class='toolBtn' title='Captura PNG' onclick='capturarPNG()'>▣</button></div></div><div id='toast'>Cargando dashboard 3D...</div><div id='ctxMenu'><div class='ctxTitle' id='ctxTitle'>Elemento</div><button onclick='ctxAccion(\"enfocar\")'>Enfocar</button><button onclick='ctxAccion(\"aislar\")'>Aislar</button><button onclick='ctxAccion(\"copiar\")'>Copiar ElementId</button><button onclick='ctxAccion(\"ocultar\")'>Ocultar</button><button onclick='ctxAccion(\"mostrarTodo\")'>Mostrar todo</button></div></div>");
            html.AppendLine("<div id='right'><div class='section'><h3>Elemento seleccionado</h3><div id='props'><span class='muted'>Selecciona un elemento del modelo o de la tabla.</span></div></div><div class='section'><h3>Acciones</h3><div class='row'><button onclick='aislarSeleccionado()'>Aislar seleccionado</button><button class='gray' onclick='copiarId()'>Copiar ID</button></div><div class='row' style='margin-top:7px'><button class='gray' onclick='enfocarSeleccionado()'>Enfocar</button><button class='warn' onclick='ocultarSeleccionado()'>Ocultar</button></div></div><div class='section'><h3>Filtros activos</h3><div id='filtrosActivos'><span class='muted'>Sin filtros.</span></div></div><div class='section'><h3>Mouse</h3><div class='small muted'>Izquierdo: seleccionar elemento<br>Rueda: zoom<br>Rueda presionada: pan<br>Shift + rueda presionada: orbitar 3D<br>Doble clic: abrir/enfocar elemento<br>Derecho: menú contextual</div></div></div>");
            html.AppendLine("<div id='bottom'><div class='tableWrap'><table id='tabla'><thead><tr><th>ElementId</th><th>Categoría</th><th>Nombre</th><th>Triángulos</th><th>Acción</th></tr></thead><tbody></tbody></table></div><div class='tableWrap'><div class='splitTitle'>Detalle rápido</div><div id='detalleRapido' class='muted'>Haz clic sobre una fila para aislar o enfocar.</div></div></div>");
            html.AppendLine("</div>");
            html.AppendLine("<script src='https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js'></script>");
            html.AppendLine("<script src='https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/OBJLoader.js'></script>");
            html.AppendLine("<script src='https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js'></script>");
            html.AppendLine("<script>");
            html.AppendLine("");
            html.AppendLine("const TITLE='" + JsonEscape(titulo ?? "Modelo Revit") + "';");
            html.AppendLine("const OBJ_B64='" + objFinal + "';");
            html.AppendLine("const OBJ_URL='" + JsonEscape(objUrl) + "';");
            html.AppendLine("const REL_B64='" + jsonBase64 + "';");
            html.AppendLine("const DASH_B64='" + dashboardBase64 + "';");
            html.AppendLine("const SCHEDULES_B64='" + schedulesBase64 + "';");
            html.AppendLine("const MATERIALS_B64='" + materialsBase64 + "';");
            html.AppendLine("");
            html.AppendLine("let scene,camera,renderer,controls,root,raycaster,mouse,bordesActivos=true,modoAlambricoResto=true; let meshesModelo=[],edgeQueue=[],edgeTimer=null,sombraAmbiente=null,camAnim=null; let modoMedicion=false,puntosMedicion=[],objetosMedicion=[],etiquetasMedicion=[],medidasGrupo=null,snapMarkerMedida=null; let modoPrimeraPersona=false,fpKeys={},fpLoop=null,fpLast=0,fpSpeed=4.0;");
            html.AppendLine("let relaciones=JSON.parse(b64utf8(REL_B64));");
            html.AppendLine("let dashboard=JSON.parse(b64utf8(DASH_B64));");
            html.AppendLine("let schedules=JSON.parse(b64utf8(SCHEDULES_B64));");
            html.AppendLine("let materialColors=JSON.parse(b64utf8(MATERIALS_B64));");
            html.AppendLine("let porMesh={},porId={},seleccionado=null,categoriaActiva='',textoActivo='',scheduleActiva=null,scheduleSet=null,contextRel=null,hoverObj=null,hoverRel=null,hoverRAF=null;");
            html.AppendLine("relaciones.forEach(r=>{porMesh[r.MeshName]=r;porId[String(r.ElementId)]=r;});");
            html.AppendLine("init();");
            html.AppendLine("function b64utf8(b64){const bin=atob(b64); const len=bin.length; const bytes=new Uint8Array(len); const paso=32768; for(let i=0;i<len;i+=paso){const fin=Math.min(i+paso,len); for(let j=i;j<fin;j++)bytes[j]=bin.charCodeAt(j);} return new TextDecoder('utf-8').decode(bytes);}");
            html.AppendLine("function objTextFromB64(b64){return atob(b64);}");
            html.AppendLine("function n(x){return (Number(x)||0).toLocaleString('es-PE');}");
            html.AppendLine("function esc(s){return String(s??'').replace(/[&<>\"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',\"'\":'&#39;'}[m];});}");
            html.AppendLine("function init(){");
            html.AppendLine(" document.getElementById('modeloTag').textContent=TITLE;");
            html.AppendLine(" pintarDashboardBase();");
            html.AppendLine(" const c=document.getElementById('container');");
            html.AppendLine(" scene=new THREE.Scene(); scene.background=new THREE.Color(0xdbe4ee); scene.fog=new THREE.Fog(0xdbe4ee,80,420);");
            html.AppendLine(" camera=new THREE.PerspectiveCamera(45,c.clientWidth/c.clientHeight,0.01,100000); camera.position.set(12,10,12);");
            html.AppendLine(" renderer=new THREE.WebGLRenderer({antialias:false,preserveDrawingBuffer:true,powerPreference:'high-performance'}); renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.15)); renderer.setSize(c.clientWidth,c.clientHeight); renderer.setClearColor(0xdbe4ee,1); if(THREE.sRGBEncoding)renderer.outputEncoding=THREE.sRGBEncoding; if(THREE.NoToneMapping)renderer.toneMapping=THREE.NoToneMapping; renderer.toneMappingExposure=1.0; c.appendChild(renderer.domElement);");
            html.AppendLine(" controls=new THREE.OrbitControls(camera,renderer.domElement); controls.enableDamping=false; controls.screenSpacePanning=true; controls.rotateSpeed=0.95; controls.zoomSpeed=1.15; controls.panSpeed=0.95; controls.minDistance=0.05; controls.maxDistance=100000; controls.mouseButtons.LEFT=null; controls.mouseButtons.MIDDLE=THREE.MOUSE.PAN; controls.mouseButtons.RIGHT=null; controls.enableRotate=false; controls.enablePan=true; controls.enableZoom=true; controls.enableKeys=false;");
            html.AppendLine(" controls.mouseButtons={LEFT:null,MIDDLE:THREE.MOUSE.PAN,RIGHT:null}; controls.touches={ONE:THREE.TOUCH.ROTATE,TWO:THREE.TOUCH.DOLLY_PAN};");
            html.AppendLine(" renderer.domElement.addEventListener('contextmenu',onContextMenu,false); renderer.domElement.addEventListener('pointerdown',prepararControlRevit,true); renderer.domElement.addEventListener('mousedown',prepararControlRevit,true); renderer.domElement.addEventListener('mouseup',restaurarControlRevit,true); renderer.domElement.addEventListener('pointerup',restaurarControlRevit,true); renderer.domElement.addEventListener('auxclick',e=>{if(e.button===1)e.preventDefault();},true); document.addEventListener('click',e=>{if(!e.target.closest||!e.target.closest('#ctxMenu'))ocultarMenuContextual();}); window.addEventListener('keydown',onKeyRevit,true); window.addEventListener('keyup',onKeyRevit,true);");
            html.AppendLine(" scene.add(new THREE.AmbientLight(0xffffff,0.94)); const h=new THREE.HemisphereLight(0xffffff,0x7b8794,0.12); scene.add(h); const d1=new THREE.DirectionalLight(0xffffff,0.10); d1.position.set(22,30,16); scene.add(d1); const d2=new THREE.DirectionalLight(0xffffff,0.04); d2.position.set(-12,10,-18); scene.add(d2);");
            html.AppendLine(" const grid=new THREE.GridHelper(30,30,0x9ca3af,0xe5e7eb); grid.material.transparent=true; grid.material.opacity=0.32; scene.add(grid);");
            html.AppendLine(" raycaster=new THREE.Raycaster(); mouse=new THREE.Vector2(); renderer.domElement.addEventListener('click',onClick,false); renderer.domElement.addEventListener('dblclick',onDblClick,false); renderer.domElement.addEventListener('pointermove',onHoverMove,false); renderer.domElement.addEventListener('pointermove',actualizarSnapMedicion,false); renderer.domElement.addEventListener('pointerleave',()=>{limpiarHover();ocultarSnapMedicion();},false); window.addEventListener('resize',resize);");
            html.AppendLine(" medidasGrupo=new THREE.Group(); medidasGrupo.name='MYG_MEDICIONES'; scene.add(medidasGrupo); document.addEventListener('pointerlockchange',onPointerLockChange,false); document.addEventListener('mousemove',onMouseMovePrimeraPersona,false); window.addEventListener('blur',()=>{fpKeys={};},false);");
            html.AppendLine(" cargarOBJ(); controls.addEventListener('change',renderizar); renderizar();");
            html.AppendLine("}");
            html.AppendLine("function cargarOBJ(){try{const loader=new THREE.OBJLoader(); root=loader.parse(objTextFromB64(OBJ_B64)); preparar(root); scene.add(root); agregarSombraAmbiente(); encuadrar(); aplicarIdUrl(); programarBordesGlobales(); toast('Dashboard listo. Elementos: <b>'+n(relaciones.length)+'</b> | Tablas: <b>'+n(schedules.length)+'</b> | OBJ optimizado + bordes + sombra ambiental'); renderizar();}catch(e){toast('<b>Error cargando OBJ:</b><br>'+esc(e));}}");
            html.AppendLine("function preparar(obj){meshesModelo=[]; obj.traverse(o=>{if(o.isMesh){const rel=porMesh[getMeshName(o)]||{}; if(o.geometry){o.geometry.computeVertexNormals(); o.geometry.computeBoundingBox();} let color=(rel.ColorHex||colorMaterial(o.material)||'#B4B4B4'); const solid=new THREE.MeshLambertMaterial({color:new THREE.Color(color),side:THREE.DoubleSide}); solid.polygonOffset=true; solid.polygonOffsetFactor=1; solid.polygonOffsetUnits=1; const ghostColor=color||'#B4B4B4'; const ghost=new THREE.MeshLambertMaterial({color:new THREE.Color(ghostColor),transparent:true,opacity:0.105,depthWrite:false,side:THREE.DoubleSide}); o.material=solid; o.userData.rel=rel; o.userData.baseColor=color; o.userData.solidMat=solid; o.userData.wireMat=ghost; o.userData.mode='solid'; o.renderOrder=1; meshesModelo.push(o);} else if(o.isLine||o.isLineSegments){const rel=porMesh[getMeshName(o)]||{}; o.userData.rel=rel; if(o.material){let c=(rel.ColorHex||colorMaterial(o.material)||'#334155'); o.material.color=new THREE.Color(c); o.material.transparent=true; o.material.opacity=0.92; o.material.depthWrite=false;} }}); pintarTabla(relaciones); actualizarVisibles();}");
            html.AppendLine("function colorMaterial(mat){try{if(mat&&mat.name&&materialColors[mat.name])return materialColors[mat.name];}catch(e){} return null;}");
            html.AppendLine("function agregarSombraAmbiente(){try{if(!root)return; const box=new THREE.Box3().setFromObject(root); if(box.isEmpty())return; const size=box.getSize(new THREE.Vector3()); const center=box.getCenter(new THREE.Vector3()); const maxDim=Math.max(size.x,size.z,1); const canvas=document.createElement('canvas'); canvas.width=512; canvas.height=512; const g=canvas.getContext('2d'); const grd=g.createRadialGradient(256,256,20,256,256,250); grd.addColorStop(0,'rgba(0,0,0,0.18)'); grd.addColorStop(0.55,'rgba(0,0,0,0.08)'); grd.addColorStop(1,'rgba(0,0,0,0)'); g.fillStyle=grd; g.fillRect(0,0,512,512); const tex=new THREE.CanvasTexture(canvas); const mat=new THREE.MeshBasicMaterial({map:tex,transparent:true,depthWrite:false}); const geo=new THREE.PlaneBufferGeometry(maxDim*1.45,maxDim*1.45); sombraAmbiente=new THREE.Mesh(geo,mat); sombraAmbiente.rotation.x=-Math.PI/2; sombraAmbiente.position.set(center.x,box.min.y-0.015,center.z); sombraAmbiente.renderOrder=-2; scene.add(sombraAmbiente);}catch(e){}}");
            html.AppendLine("function esColorMuyBlanco(hex){try{const c=new THREE.Color(hex); return c.r>0.88&&c.g>0.88&&c.b>0.88;}catch(e){return false;}}");
            html.AppendLine("function colorPorCategoria(cat){cat=String(cat||'').toLowerCase(); if(cat.includes('pilar')||cat.includes('columna'))return '#9aa3ad'; if(cat.includes('muro'))return '#b7bcc2'; if(cat.includes('suelo')||cat.includes('losa'))return '#b6c2cf'; if(cat.includes('puerta'))return '#c28f64'; if(cat.includes('ventana'))return '#7aa6c2'; if(cat.includes('barand'))return '#6b7280'; if(cat.includes('tuber')||cat.includes('conduct'))return '#f59e0b'; return '#b8c0cc';}");
            html.AppendLine("function normalizarColorRevit(hex,cat){if(!hex||esColorMuyBlanco(hex))return colorPorCategoria(cat); return hex;}");
            html.AppendLine("function getOrCreateEdge(o){if(!o||!o.geometry)return null; if(o.userData.edgeHelper)return o.userData.edgeHelper; try{const edgeGeo=new THREE.EdgesGeometry(o.geometry,36); const esWire=o.userData&&o.userData.mode==='wire'; const edgeMat=new THREE.LineBasicMaterial({color:esWire?0x94a3b8:0x000000,transparent:true,opacity:esWire?0.10:0.36,depthTest:true,depthWrite:false}); edgeMat.linecap='round'; edgeMat.linejoin='round'; const edge=new THREE.LineSegments(edgeGeo,edgeMat); edge.name=(getMeshName(o)||o.name||'mesh')+'_EDGES'; edge.userData.isEdgeHelper=true; edge.renderOrder=6; edge.frustumCulled=true; edge.visible=bordesActivos; o.userData.edgeHelper=edge; o.add(edge); return edge;}catch(e){return null;}}");
            html.AppendLine("function programarBordesGlobales(){if(!bordesActivos||!meshesModelo||!meshesModelo.length)return; edgeQueue=meshesModelo.slice(); procesarBordesLote();}");
            html.AppendLine("function procesarBordesLote(){if(!edgeQueue||!edgeQueue.length){toast('Dashboard listo. Elementos: <b>'+n(relaciones.length)+'</b> | bordes sólidos negros y alambrado tenue cargados'); renderizar(); return;} const inicio=performance.now(); let count=0; while(edgeQueue.length&&count<35&&(performance.now()-inicio)<12){const m=edgeQueue.shift(); if(m&&m.userData&&m.userData.rel)getOrCreateEdge(m); count++;} renderizar(); edgeTimer=setTimeout(procesarBordesLote,0);}");
            html.AppendLine("function setBordesVisibles(v){bordesActivos=v; if(v&&(!edgeQueue||!edgeQueue.length))programarBordesGlobales(); if(!root)return; root.traverse(o=>{if(o.userData&&o.userData.isEdgeHelper)o.visible=v;}); renderizar();}");
            html.AppendLine("function toggleBordes(){setBordesVisibles(!bordesActivos); toast('Bordes '+(bordesActivos?'activados':'desactivados'));}");
            html.AppendLine("function getMeshName(o){let p=o; while(p){if(p.name&&String(p.name).startsWith('E_'))return p.name; p=p.parent;} return o.name||'';}");
            html.AppendLine("function resize(){const c=document.getElementById('container'); camera.aspect=c.clientWidth/c.clientHeight; camera.updateProjectionMatrix(); renderer.setSize(c.clientWidth,c.clientHeight);}");
            html.AppendLine("function renderizar(){if(renderer&&scene&&camera){actualizarEscalaEtiquetasMedicion();renderer.render(scene,camera);}}");
            html.AppendLine("function meshesSeleccionables(){const arr=[]; if(!root)return arr; root.traverse(o=>{if(o.isMesh&&o.visible&&o.userData&&o.userData.rel&&o.userData.mode!=='wire')arr.push(o);}); return arr;}");
            html.AppendLine("function mouseEvent(e){const rect=renderer.domElement.getBoundingClientRect(); mouse.x=((e.clientX-rect.left)/rect.width)*2-1; mouse.y=-((e.clientY-rect.top)/rect.height)*2+1; raycaster.setFromCamera(mouse,camera); return raycaster.intersectObjects(meshesSeleccionables(),false);}");
            html.AppendLine("function mouseCentro(){mouse.x=0;mouse.y=0;raycaster.setFromCamera(mouse,camera);return raycaster.intersectObjects(meshesSeleccionables(),false);}");
            html.AppendLine("function esSeleccionActual(o){return seleccionado&&o&&getMeshName(o)===String(seleccionado.MeshName);}");
            html.AppendLine("function restaurarHoverObj(o){if(!o||!o.userData)return; if(esSeleccionActual(o))return; if(o.userData.solidMat&&o.userData.solidMat.emissive)o.userData.solidMat.emissive.setHex(0x000000); if(o.userData.edgeHelper&&o.userData.edgeHelper.material){const esWire=o.userData.mode==='wire'; o.userData.edgeHelper.material.color.setHex(esWire?0x94a3b8:0x000000); o.userData.edgeHelper.material.opacity=(esWire?0.10:0.36);}}");
            html.AppendLine("function aplicarHoverObj(o){if(!o||!o.userData)return; if(esSeleccionActual(o))return; if(o.userData.solidMat&&o.userData.solidMat.emissive)o.userData.solidMat.emissive.setHex(0x16233f); const edge=getOrCreateEdge(o); if(edge&&edge.material){edge.visible=true; edge.material.color.setHex(0x000000); edge.material.opacity=0.68;}}");
            html.AppendLine("function limpiarHover(){if(hoverObj){restaurarHoverObj(hoverObj); hoverObj=null; hoverRel=null; renderizar();}}");
            html.AppendLine("function onHoverMove(e){if(modoMedicion||modoPrimeraPersona)return; if(!renderer||!root)return; if(e.buttons&&e.buttons!==0)return; if(hoverRAF)return; hoverRAF=requestAnimationFrame(()=>{hoverRAF=null; const hits=mouseEvent(e); const obj=hits.length?hits[0].object:null; const r=obj?porMesh[getMeshName(obj)]:null; if(obj!==hoverObj){if(hoverObj)restaurarHoverObj(hoverObj); hoverObj=obj; hoverRel=r||null; if(hoverObj)aplicarHoverObj(hoverObj); renderizar();}});}");
            html.AppendLine("function onClick(e){if(e.button&&e.button!==0)return; if(modoMedicion){medirClick(e);return;} if(modoPrimeraPersona)return; const hits=mouseEvent(e); if(!hits.length)return; const obj=hits[0].object; const r=porMesh[getMeshName(obj)]; if(r)seleccionarPorRelacion(r,false,false);}");
            html.AppendLine("function onDblClick(e){if(e.button&&e.button!==0)return; if(modoMedicion||modoPrimeraPersona)return; const hits=mouseEvent(e); if(!hits.length)return; const obj=hits[0].object; const r=porMesh[getMeshName(obj)]; if(r){seleccionarPorRelacion(r,true,false); toast('Elemento abierto/enfocado: <b>'+esc(r.ElementId)+'</b>');}}");
            html.AppendLine("let shiftRevitActivo=false;");
            html.AppendLine("function onKeyRevit(e){shiftRevitActivo=!!e.shiftKey; if(modoPrimeraPersona){if(e.type==='keydown')fpKeys[e.code]=true; if(e.type==='keyup')fpKeys[e.code]=false; if(e.type==='keydown'&&(e.key==='m'||e.key==='M')){toggleMedicion(); e.preventDefault(); return;}} if(e.key==='Escape'&&e.type==='keydown'){if(modoPrimeraPersona){salirPrimeraPersona();return;} if(modoMedicion)salirMedicion(); ocultarMenuContextual(); limpiarSeleccion();}}");
            html.AppendLine("function prepararControlRevit(e){");
            html.AppendLine(" if(!controls||modoPrimeraPersona)return;");
            html.AppendLine(" const shift=(e.shiftKey===true)||(e.getModifierState&&e.getModifierState('Shift'))||shiftRevitActivo;");
            html.AppendLine(" if(e.button===1){");
            html.AppendLine("  controls.mouseButtons.LEFT=null;");
            html.AppendLine("  controls.mouseButtons.RIGHT=null;");
            html.AppendLine("  controls.mouseButtons.MIDDLE=THREE.MOUSE.PAN;");
            html.AppendLine("  controls.enableRotate=shift;");
            html.AppendLine("  controls.enablePan=true;");
            html.AppendLine("  controls.enableZoom=true;");
            html.AppendLine("  e.preventDefault();");
            html.AppendLine("  ocultarMenuContextual();");
            html.AppendLine("  return;");
            html.AppendLine(" }");
            html.AppendLine(" if(e.button===0){");
            html.AppendLine("  controls.mouseButtons.LEFT=null;");
            html.AppendLine("  controls.mouseButtons.MIDDLE=THREE.MOUSE.PAN;");
            html.AppendLine("  controls.mouseButtons.RIGHT=null;");
            html.AppendLine("  controls.enableRotate=false;");
            html.AppendLine("  controls.enablePan=true;");
            html.AppendLine("  controls.enableZoom=true;");
            html.AppendLine("  ocultarMenuContextual();");
            html.AppendLine("  return;");
            html.AppendLine(" }");
            html.AppendLine(" if(e.button===2){");
            html.AppendLine("  controls.mouseButtons.RIGHT=null;");
            html.AppendLine("  controls.enableRotate=false;");
            html.AppendLine("  controls.enablePan=false;");
            html.AppendLine("  controls.enableZoom=true;");
            html.AppendLine(" }");
            html.AppendLine("}");
            html.AppendLine("function restaurarControlRevit(e){if(!controls)return; controls.mouseButtons.LEFT=null; controls.mouseButtons.MIDDLE=THREE.MOUSE.PAN; controls.mouseButtons.RIGHT=null; controls.enableRotate=false; controls.enablePan=true; controls.enableZoom=true;}");
            html.AppendLine("function onContextMenu(e){e.preventDefault(); if(!renderer||!renderer.domElement)return; const hits=mouseEvent(e); contextRel=null; if(hits.length){const r=porMesh[getMeshName(hits[0].object)]; if(r){contextRel=r; seleccionarPorRelacion(r,false,false); document.getElementById('ctxTitle').textContent=(r.Categoria||'Elemento')+' | ID '+r.ElementId;}} else {document.getElementById('ctxTitle').textContent='Menú contextual';} const rect=document.getElementById('view').getBoundingClientRect(); const menu=document.getElementById('ctxMenu'); menu.style.display='block'; const mw=menu.offsetWidth||210; const mh=menu.offsetHeight||190; let x=e.clientX-rect.left; let y=e.clientY-rect.top; x=Math.max(8,Math.min(x,rect.width-mw-8)); y=Math.max(8,Math.min(y,rect.height-mh-8)); menu.style.left=x+'px'; menu.style.top=y+'px'; renderizar();}");
            html.AppendLine("function ocultarMenuContextual(){const m=document.getElementById('ctxMenu'); if(m)m.style.display='none';}");
            html.AppendLine("function ctxAccion(a){const r=contextRel||seleccionado; ocultarMenuContextual(); if(a==='mostrarTodo'){mostrarTodo(); return;} if(!r){toast('No hay elemento seleccionado.'); return;} if(a==='enfocar'){seleccionarPorRelacion(r,true,false); return;} if(a==='aislar'){seleccionarPorRelacion(r,false,true); return;} if(a==='copiar'){navigator.clipboard&&navigator.clipboard.writeText(String(r.ElementId)); toast('ElementId copiado: <b>'+esc(r.ElementId)+'</b>'); return;} if(a==='ocultar'){const obj=buscarObjetoPorMesh(r.MeshName); if(obj){setModoMesh(obj,'wire'); actualizarVisibles(); renderizar();}}}");
            html.AppendLine("function aplicarIdUrl(){const id=new URLSearchParams(location.search).get('id'); if(id&&porId[id])seleccionarPorRelacion(porId[id],true,true);}");
            html.AppendLine("function limpiarHighlight(){limpiarHover(); if(!root)return; root.traverse(o=>{if(o.isMesh&&o.userData&&o.userData.solidMat&&o.userData.solidMat.emissive)o.userData.solidMat.emissive.setHex(0x000000); if(o.userData&&o.userData.edgeHelper&&o.userData.edgeHelper.material){const esWire=o.userData.mode==='wire'; o.userData.edgeHelper.visible=bordesActivos; o.userData.edgeHelper.material.color.setHex(esWire?0x94a3b8:0x000000); o.userData.edgeHelper.material.opacity=(esWire?0.10:0.36);}});}");
            html.AppendLine("function seleccionarPorRelacion(r,enf,aislar){if(!r)return; limpiarHighlight(); seleccionado=r; const obj=buscarObjetoPorMesh(r.MeshName); if(obj&&obj.userData&&obj.userData.solidMat&&obj.userData.solidMat.emissive)obj.userData.solidMat.emissive.setHex(0x2447aa); const edge=obj?getOrCreateEdge(obj):null; if(edge){edge.visible=true; edge.material.color.setHex(0x000000); edge.material.opacity=0.98;} pintarProps(r); marcarFila(r.ElementId); if(obj&&enf)enfocar(obj); if(aislar){categoriaActiva=''; textoActivo=''; scheduleActiva=null; scheduleSet=new Set([String(r.ElementId)]); aplicarFiltro3D(false);} renderizar();}");
            html.AppendLine("function limpiarSeleccion(){limpiarHighlight(); seleccionado=null; contextRel=null; hoverRel=null; document.querySelectorAll('#tabla tbody tr').forEach(tr=>tr.classList.remove('sel')); document.getElementById('props').innerHTML='<span class=\"muted\">Selecciona un elemento del modelo o de la tabla.</span>'; document.getElementById('detalleRapido').innerHTML='<span class=\"muted\">Selección limpiada.</span>'; renderizar();}");
            html.AppendLine("function buscarObjetoPorMesh(mesh){let encontrado=null;if(!root)return null; root.traverse(o=>{if(!encontrado&&o.isMesh&&getMeshName(o)===mesh)encontrado=o;}); return encontrado;}");
            html.AppendLine("function pintarDashboardBase(){const res=dashboard.Resumen||{}; document.getElementById('cardElementos').textContent=n(res.TotalElementos||relaciones.length); document.getElementById('cardCategorias').textContent=n(res.TotalCategorias||0); document.getElementById('cardSchedules').textContent=n(schedules.length||0); pintarCategorias(); pintarBarras(); pintarSchedules(); actualizarPartidaTop();}");
            html.AppendLine("function pintarCategorias(){const cont=document.getElementById('catButtons'); cont.innerHTML='<button class=\"catBtn active\" onclick=\"filtrarCategoria(\\'\\')\">Todos</button>'; (dashboard.Categorias||[]).forEach(c=>{cont.innerHTML+=`<button class=\"catBtn\" onclick=\"filtrarCategoria('${String(c.Categoria).replace(/'/g,'\\\\\\'')}')\">${esc(c.Categoria)} (${n(c.Cantidad)})</button>`;});}");
            html.AppendLine("function pintarBarras(){const cont=document.getElementById('bars'); cont.innerHTML=''; const cats=dashboard.Categorias||[]; const max=Math.max(1,...cats.map(c=>c.Cantidad||0)); cats.forEach(c=>{cont.innerHTML+=`<div class=\"barItem\"><div class=\"barLabel\"><span>${esc(c.Categoria)}</span><span>${n(c.Cantidad)}</span></div><div class=\"barTrack\"><div class=\"barFill\" style=\"width:${Math.max(2,(c.Cantidad||0)*100/max)}%\"></div></div></div>`;});}");
            html.AppendLine("function pintarSchedules(){const cont=document.getElementById('scheduleList'); const q=(document.getElementById('txtBuscarSchedule')?.value||'').toLowerCase(); cont.innerHTML=''; let lista=schedules.filter(s=>!q||String(s.Nombre||'').toLowerCase().includes(q)||String(s.Codigo||'').toLowerCase().includes(q)); if(!lista.length){cont.innerHTML='<div class=\"scheduleItem muted\">No hay tablas coincidentes.</div>'; return;} lista.slice(0,250).forEach(s=>{const idx=schedules.indexOf(s); const active=scheduleActiva&&scheduleActiva.ScheduleId===s.ScheduleId?' active':''; const met=s.MetradoTotalTexto||((s.MetradoTotal||0)?Number(s.MetradoTotal).toFixed(3):''); const pu=s.PrecioUnitarioTexto||''; const parcial=s.ParcialTexto||''; let meta=`Elementos 3D asociados: ${n(s.CantidadElementos||0)}`; meta+=`<br><b>Metrado:</b> ${esc(met)} ${esc(s.Unidad||'')}`; meta+=`<br><b>P.U.:</b> ${pu?esc(pu):'<span class=\\\"muted\\\">sin precio</span>'}`; meta+=`<br><b>Parcial:</b> ${parcial?esc(parcial):'<span class=\\\"muted\\\">pendiente</span>'}`; cont.innerHTML+=`<div class=\"scheduleItem${active}\" onclick=\"seleccionarScheduleIdx(${idx})\"><div class=\"scheduleName\">${s.Codigo?'<span class=\\\"pill\\\">'+esc(s.Codigo)+'</span> ':''}${esc(s.Nombre)}</div><div class=\"scheduleMeta\">${meta}</div></div>`;});}");
            html.AppendLine("function limpiarTextoCodigo(nom,cod){nom=String(nom||''); cod=String(cod||''); if(cod&&nom.toUpperCase().startsWith(cod.toUpperCase()))return nom.substring(cod.length).replace(/^\\s*[-–:]?\\s*/,''); return nom;}");
            html.AppendLine("function formatoMetradoPartida(s){const met=s.MetradoTotalTexto||((s.MetradoTotal||0)?Number(s.MetradoTotal).toLocaleString('es-PE',{maximumFractionDigits:3}):'0'); return met+(s.Unidad?' '+s.Unidad:'');}");
            html.AppendLine("function formatoPrecioPartida(s){if(!s||!s.TienePrecio)return `<span class='muted'>sin precio</span>`; return esc(s.PrecioUnitarioTexto||Number(s.PrecioUnitario||0).toLocaleString('es-PE',{minimumFractionDigits:2,maximumFractionDigits:2}));}");
            html.AppendLine("function formatoParcialPartida(s){if(!s||!s.TienePrecio)return `<span class='muted'>pendiente</span>`; return esc(s.ParcialTexto||('S/ '+Number(s.Parcial||0).toLocaleString('es-PE',{minimumFractionDigits:2,maximumFractionDigits:2})));}");
            html.AppendLine("function actualizarPartidaTop(){const box=document.getElementById('partidaTop'); if(!box)return; if(!scheduleActiva){box.classList.remove('show'); box.innerHTML=''; return;} const s=scheduleActiva; const cod=esc(s.Codigo||'SIN CÓDIGO'); const nombre=esc(limpiarTextoCodigo(s.Nombre||'',s.Codigo||'')); const met=esc(formatoMetradoPartida(s)); const pu=formatoPrecioPartida(s); const parcial=formatoParcialPartida(s); const elems=n(s.CantidadElementos||0); const estado=s.TienePrecio?'Precio unitario cargado desde CSV':'Precio unitario no cargado'; box.innerHTML=`<div class='partidaHead'><div class='partidaCode'>${cod}</div><div class='partidaTitle'>${nombre}</div><button class='partidaClose' title='Quitar filtro de tabla' onclick='limpiarSchedule()'>×</button></div><div class='partidaGrid'><div class='partidaData'><div class='k'>Unidad</div><div class='v'>${esc(s.Unidad||'-')}</div></div><div class='partidaData'><div class='k'>Metrado total</div><div class='v'>${met}</div></div><div class='partidaData'><div class='k'>P.U.</div><div class='v money'>${pu}</div></div><div class='partidaData'><div class='k'>Parcial</div><div class='v money'>${parcial}</div></div><div class='partidaData'><div class='k'>Elementos 3D</div><div class='v'>${elems}</div></div></div><div class='partidaNote'><b>Tabla:</b> ${esc(s.Nombre||'')} · ${esc(estado)}</div>`; box.classList.add('show');}");
            html.AppendLine("function seleccionarScheduleIdx(i){scheduleActiva=schedules[i]; scheduleSet=new Set((scheduleActiva.ElementIds||[]).map(String)); categoriaActiva=''; textoActivo=''; document.getElementById('txtBuscar').value=''; aplicarFiltro3D(true); pintarSchedules(); actualizarPartidaTop();}");
            html.AppendLine("function limpiarSchedule(){scheduleActiva=null; scheduleSet=null; actualizarPartidaTop(); aplicarFiltro3D(true); pintarSchedules();}");
            html.AppendLine("function coincide(r,t){if(!r)return false; if(!t)return true; t=t.toLowerCase(); return (r.ElementId||'').toLowerCase().includes(t)||(r.Categoria||'').toLowerCase().includes(t)||(r.Nombre||'').toLowerCase().includes(t)||(r.UniqueId||'').toLowerCase().includes(t);}");
            html.AppendLine("function pasaFiltros(r){if(!r)return false; if(scheduleSet&&scheduleSet.size>0&&!scheduleSet.has(String(r.ElementId)))return false; if(categoriaActiva&&String(r.Categoria)!==categoriaActiva)return false; if(textoActivo&&!coincide(r,textoActivo))return false; return true;}");
            html.AppendLine("function setToolActivo(id,activo){const b=document.getElementById(id); if(b)b.classList.toggle('active',!!activo);}");
            html.AppendLine("function toggleMedicion(){if(modoMedicion){salirMedicion();return;} modoMedicion=true; puntosMedicion=[]; setToolActivo('toolMedir',true); setToolActivo('toolSelect',false); actualizarCursorPrimeraPersona(); toast(modoPrimeraPersona?'Modo medir en primera persona: apunta con el centro y haz clic en 2 puntos.':'Modo medir activo: acerca el cursor a un vértice y haz clic en 2 puntos.');}");
            html.AppendLine("function salirMedicion(){modoMedicion=false; puntosMedicion=[]; ocultarSnapMedicion(); setToolActivo('toolMedir',false); setToolActivo('toolSelect',true); actualizarCursorPrimeraPersona();}");
            html.AppendLine("function medirClick(e){const snap=obtenerPuntoMedicion(e,false); if(!snap){toast('Medir: selecciona un punto sobre el modelo.'); return;} const p=snap.point.clone(); puntosMedicion.push(p); crearMarcadorMedida(p,snap.snap); if(puntosMedicion.length===1){toast((snap.snap?'Vértice marcado. ':'Primer punto marcado. ')+'Selecciona el segundo punto.'); renderizar(); return;} const a=puntosMedicion[0].clone(); const b=puntosMedicion[1].clone(); puntosMedicion=[]; const dist=a.distanceTo(b); const geo=new THREE.BufferGeometry().setFromPoints([a,b]); const mat=new THREE.LineBasicMaterial({color:0xfacc15,transparent:true,opacity:0.92,depthTest:true,depthWrite:false}); const ln=new THREE.Line(geo,mat); ln.renderOrder=30; medidasGrupo.add(ln); const mid=a.clone().add(b).multiplyScalar(0.5); const sp=crearEtiquetaMedida(dist.toFixed(3)+' m'); sp.position.copy(mid); medidasGrupo.add(sp); toast('Distancia: <b>'+dist.toFixed(3)+' m</b>'); renderizar();}");
            html.AppendLine("function obtenerPuntoMedicion(e,soloSnap){const hits=modoPrimeraPersona?mouseCentro():mouseEvent(e); if(!hits.length)return null; const h=hits[0]; const s=puntoSnapVertice(h); if(s&&s.snap)return s; return soloSnap?null:{point:h.point.clone(),snap:false};}");
            html.AppendLine("function puntoSnapVertice(hit){try{if(!hit||!hit.object||!hit.object.geometry||hit.faceIndex==null)return null; const obj=hit.object; const g=obj.geometry; const pos=g.attributes&&g.attributes.position; if(!pos)return null; let ids=[]; if(g.index&&g.index.array){const ia=g.index.array; const b=hit.faceIndex*3; ids=[ia[b],ia[b+1],ia[b+2]];} else {const b=hit.faceIndex*3; ids=[b,b+1,b+2];} let best=null,bestPx=999999; ids.forEach(i=>{if(i==null||i<0||i>=pos.count)return; const v=new THREE.Vector3(pos.getX(i),pos.getY(i),pos.getZ(i)); obj.localToWorld(v); const px=distanciaPantalla(v,hit.point); if(px<bestPx){bestPx=px; best=v;}}); if(best&&bestPx<=18)return {point:best.clone(),snap:true}; return null;}catch(err){return null;}}");
            html.AppendLine("function distanciaPantalla(a,b){const c=renderer.domElement; const pa=a.clone().project(camera); const pb=b.clone().project(camera); const dx=(pa.x-pb.x)*c.clientWidth*0.5; const dy=(pa.y-pb.y)*c.clientHeight*0.5; return Math.sqrt(dx*dx+dy*dy);}");
            html.AppendLine("function actualizarSnapMedicion(e){if(!modoMedicion)return; if(!modoPrimeraPersona&&e&&e.buttons&&e.buttons!==0)return; const s=obtenerPuntoMedicion(e,true); if(s&&s.snap){if(!snapMarkerMedida){const GeoCtor=THREE.BoxBufferGeometry||THREE.BoxGeometry; const geo=new GeoCtor(0.045,0.045,0.045); const mat=new THREE.MeshBasicMaterial({color:0xffa000,depthTest:false,transparent:true,opacity:0.95}); snapMarkerMedida=new THREE.Mesh(geo,mat); snapMarkerMedida.renderOrder=80; medidasGrupo.add(snapMarkerMedida);} snapMarkerMedida.visible=true; snapMarkerMedida.position.copy(s.point); renderizar();} else ocultarSnapMedicion();}");
            html.AppendLine("function ocultarSnapMedicion(){if(snapMarkerMedida&&snapMarkerMedida.visible){snapMarkerMedida.visible=false; renderizar();}}");
            html.AppendLine("function crearMarcadorMedida(p,snap){const GeoCtor=snap?(THREE.BoxBufferGeometry||THREE.BoxGeometry):(THREE.SphereBufferGeometry||THREE.SphereGeometry); const geo=snap?new GeoCtor(0.032,0.032,0.032):new GeoCtor(0.022,10,6); const mat=new THREE.MeshBasicMaterial({color:snap?0xffa000:0xfacc15,depthTest:true}); const m=new THREE.Mesh(geo,mat); m.position.copy(p); m.renderOrder=31; medidasGrupo.add(m); objetosMedicion.push(m);}");
            html.AppendLine("function crearEtiquetaMedida(txt){const canvas=document.createElement('canvas'); canvas.width=156; canvas.height=36; const g=canvas.getContext('2d'); g.fillStyle='rgba(71,85,105,.90)'; g.fillRect(0,0,156,36); g.strokeStyle='rgba(250,204,21,.85)'; g.lineWidth=2; g.strokeRect(1,1,154,34); g.fillStyle='#ffffff'; g.font='bold 20px Segoe UI, Arial'; g.textAlign='center'; g.textBaseline='middle'; g.fillText(txt,78,20); const tex=new THREE.CanvasTexture(canvas); const mat=new THREE.SpriteMaterial({map:tex,transparent:true,depthTest:false,sizeAttenuation:true}); const sp=new THREE.Sprite(mat); sp.userData.fixedScreenLabel={w:78,h:18}; sp.renderOrder=40; etiquetasMedicion.push(sp); actualizarEscalaEtiquetaMedicion(sp); return sp;}");
            html.AppendLine("function actualizarEscalaEtiquetaMedicion(sp){try{if(!sp||!camera||!renderer||!sp.userData||!sp.userData.fixedScreenLabel)return; const px=sp.userData.fixedScreenLabel; const dist=Math.max(0.001,camera.position.distanceTo(sp.position)); let worldPerPx=0.001; if(camera.isPerspectiveCamera){worldPerPx=(2*Math.tan(THREE.MathUtils.degToRad(camera.fov*0.5))*dist)/(renderer.domElement.clientHeight||800);}else if(camera.isOrthographicCamera){worldPerPx=(camera.top-camera.bottom)/(renderer.domElement.clientHeight||800);} sp.scale.set(px.w*worldPerPx,px.h*worldPerPx,1);}catch(e){}}");
            html.AppendLine("function actualizarEscalaEtiquetasMedicion(){if(!etiquetasMedicion||!etiquetasMedicion.length)return; etiquetasMedicion.forEach(actualizarEscalaEtiquetaMedicion);}");
            html.AppendLine("function actualizarCursorPrimeraPersona(){const c=document.getElementById('fpCursor'); if(!c)return; c.style.display=modoPrimeraPersona?'block':'none'; c.classList.toggle('medir',!!modoMedicion);}");
            html.AppendLine("function limpiarMediciones(){if(medidasGrupo){while(medidasGrupo.children.length){const o=medidasGrupo.children.pop(); if(o.geometry&&o.geometry.dispose)o.geometry.dispose(); if(o.material){if(o.material.map&&o.material.map.dispose)o.material.map.dispose(); if(o.material.dispose)o.material.dispose();}} snapMarkerMedida=null;} puntosMedicion=[]; objetosMedicion=[]; etiquetasMedicion=[]; toast('Mediciones limpiadas.'); renderizar();}");
            html.AppendLine("function togglePrimeraPersona(){if(modoPrimeraPersona){salirPrimeraPersona();return;} entrarPrimeraPersona();}");
            html.AppendLine("function entrarPrimeraPersona(){if(!camera||!renderer)return; modoPrimeraPersona=true; fpKeys={}; setToolActivo('toolFP',true); setToolActivo('toolSelect',false); if(controls)controls.enabled=false; const hint=document.getElementById('fpHint'); if(hint)hint.style.display='block'; actualizarCursorPrimeraPersona(); try{renderer.domElement.requestPointerLock&&renderer.domElement.requestPointerLock();}catch(e){} fpLast=performance.now(); if(!fpLoop)fpLoop=requestAnimationFrame(actualizarPrimeraPersona); toast('Primera persona activa: WASD + mouse. Pulsa M para medir desde el centro. Esc para salir.');}");
            html.AppendLine("function salirPrimeraPersona(){modoPrimeraPersona=false; fpKeys={}; setToolActivo('toolFP',false); setToolActivo('toolSelect',true); if(controls)controls.enabled=true; const hint=document.getElementById('fpHint'); if(hint)hint.style.display='none'; actualizarCursorPrimeraPersona(); try{if(document.pointerLockElement===renderer.domElement)document.exitPointerLock();}catch(e){} if(fpLoop){cancelAnimationFrame(fpLoop); fpLoop=null;} renderizar();}");
            html.AppendLine("function onPointerLockChange(){if(modoPrimeraPersona&&document.pointerLockElement!==renderer.domElement){salirPrimeraPersona();}}");
            html.AppendLine("function onMouseMovePrimeraPersona(e){if(!modoPrimeraPersona||document.pointerLockElement!==renderer.domElement)return; const sens=0.0022; const eu=new THREE.Euler(0,0,0,'YXZ'); eu.setFromQuaternion(camera.quaternion); eu.y-=e.movementX*sens; eu.x-=e.movementY*sens; eu.x=Math.max(-Math.PI/2+0.02,Math.min(Math.PI/2-0.02,eu.x)); camera.quaternion.setFromEuler(eu); const dir=new THREE.Vector3(); camera.getWorldDirection(dir); if(controls)controls.target.copy(camera.position.clone().add(dir.multiplyScalar(10))); renderizar();}");
            html.AppendLine("function actualizarPrimeraPersona(now){if(!modoPrimeraPersona){fpLoop=null;return;} const dt=Math.min(0.05,((now||performance.now())-fpLast)/1000); fpLast=now||performance.now(); const rapido=fpKeys.ShiftLeft||fpKeys.ShiftRight; const vel=fpSpeed*(rapido?3.0:1.0); const dir=new THREE.Vector3(); camera.getWorldDirection(dir); dir.y=0; if(dir.lengthSq()<0.00001)dir.set(0,0,-1); dir.normalize(); const right=new THREE.Vector3().setFromMatrixColumn(camera.matrix,0); right.y=0; right.normalize(); let mov=new THREE.Vector3(); if(fpKeys.KeyW||fpKeys.ArrowUp)mov.add(dir); if(fpKeys.KeyS||fpKeys.ArrowDown)mov.addScaledVector(dir,-1); if(fpKeys.KeyA||fpKeys.ArrowLeft)mov.addScaledVector(right,-1); if(fpKeys.KeyD||fpKeys.ArrowRight)mov.add(right); if(fpKeys.KeyQ)mov.y-=1; if(fpKeys.KeyE)mov.y+=1; let changed=false; if(mov.lengthSq()>0){mov.normalize().multiplyScalar(vel*dt); camera.position.add(mov); const look=new THREE.Vector3(); camera.getWorldDirection(look); if(controls)controls.target.copy(camera.position.clone().add(look.multiplyScalar(10))); changed=true;} if(modoMedicion)actualizarSnapMedicion(null); if(changed)renderizar(); fpLoop=requestAnimationFrame(actualizarPrimeraPersona);}");
            html.AppendLine("function buscar(){textoActivo=document.getElementById('txtBuscar').value.trim(); let r=relaciones.find(x=>pasaFiltros(x)); if(r){seleccionarPorRelacion(r,true,false); pintarTabla(relaciones.filter(pasaFiltros));} else toast('No se encontró: '+esc(textoActivo));}");
            html.AppendLine("function aislarBusqueda(){textoActivo=document.getElementById('txtBuscar').value.trim(); aplicarFiltro3D(true);}");
            html.AppendLine("function limpiarBusqueda(){textoActivo='';document.getElementById('txtBuscar').value='';aplicarFiltro3D(true);}");
            html.AppendLine("function filtrarCategoria(cat){categoriaActiva=cat||''; scheduleActiva=null; scheduleSet=null; actualizarPartidaTop(); document.querySelectorAll('.catBtn').forEach(b=>b.classList.remove('active')); [...document.querySelectorAll('.catBtn')].find(b=>b.textContent.trim().startsWith(cat||'Todos'))?.classList.add('active'); aplicarFiltro3D(true); pintarSchedules();}");
            html.AppendLine("function setModoMesh(o,modo){if(!o||!o.isMesh||!o.userData)return; o.visible=true; o.userData.mode=modo; if(modo==='solid'){o.material=o.userData.solidMat; if(o.userData.edgeHelper){o.userData.edgeHelper.visible=bordesActivos; o.userData.edgeHelper.material.color.setHex(0x000000); o.userData.edgeHelper.material.opacity=0.36;} o.renderOrder=1;} else if(modo==='wire'){o.material=o.userData.wireMat; if(o.userData.edgeHelper){o.userData.edgeHelper.visible=bordesActivos; o.userData.edgeHelper.material.color.setHex(0x94a3b8); o.userData.edgeHelper.material.opacity=0.10;} o.renderOrder=0;} else {o.visible=false; if(o.userData.edgeHelper)o.userData.edgeHelper.visible=false;}}");
            html.AppendLine("function aplicarFiltro3D(enfocarVisibles){if(!root)return; const hayFiltro=!!(scheduleSet||categoriaActiva||textoActivo); let lista=[]; root.traverse(o=>{if(o.isMesh&&o.userData&&o.userData.rel){const r=o.userData.rel; const ok=pasaFiltros(r); if(ok){setModoMesh(o,'solid'); if(r&&!lista.includes(r))lista.push(r);} else {setModoMesh(o,modoAlambricoResto&&hayFiltro?'wire':'hidden');}}}); pintarTabla(lista); actualizarVisibles(); pintarFiltros(); if(enfocarVisibles)encuadrarVisibles(); renderizar();}");
            html.AppendLine("function actualizarVisibles(){let meshes=0,ids={}; if(root)root.traverse(o=>{if(o.isMesh&&o.visible&&o.userData&&o.userData.mode!=='wire'){meshes++; const r=o.userData.rel; if(r)ids[r.ElementId]=1;}}); document.getElementById('cardVisibles').textContent=n(Object.keys(ids).length||meshes);}");
            html.AppendLine("function pintarFiltros(){let html=''; if(scheduleActiva)html+=`<span class=\"pill\">Tabla: ${esc(scheduleActiva.Nombre)}</span>`; if(categoriaActiva)html+=`<span class=\"pill\">Categoría: ${esc(categoriaActiva)}</span>`; if(textoActivo)html+=`<span class=\"pill\">Búsqueda: ${esc(textoActivo)}</span>`; document.getElementById('filtrosActivos').innerHTML=html||'<span class=\"muted\">Sin filtros.</span>';}");
            html.AppendLine("function pintarTabla(lista){const tb=document.querySelector('#tabla tbody'); tb.innerHTML=''; const vistos={}; lista.filter(r=>{if(vistos[r.ElementId])return false; vistos[r.ElementId]=true; return true;}).slice(0,1000).forEach(r=>{tb.innerHTML+=`<tr data-id=\"${esc(r.ElementId)}\" onclick=\"seleccionarPorRelacion(porId['${esc(r.ElementId)}'],false,false)\"><td>${esc(r.ElementId)}</td><td>${esc(r.Categoria)}</td><td>${esc(r.Nombre)}</td><td>${n(r.Triangulos)}</td><td><button onclick=\"event.stopPropagation(); seleccionarPorRelacion(porId['${esc(r.ElementId)}'],false,true)\">Aislar</button></td></tr>`;}); if(lista.length>1000)tb.innerHTML+=`<tr><td colspan=\"5\" class=\"muted\">Mostrando 1000 de ${n(lista.length)} elementos. Usa filtros para reducir.</td></tr>`; if(seleccionado)marcarFila(seleccionado.ElementId);}");
            html.AppendLine("function marcarFila(id){document.querySelectorAll('#tabla tbody tr').forEach(tr=>tr.classList.toggle('sel',tr.getAttribute('data-id')==String(id)));}");
            html.AppendLine("function pintarProps(r){document.getElementById('props').innerHTML=`<div><b>ElementId:</b> ${esc(r.ElementId)}</div><div><b>Categoría:</b> ${esc(r.Categoria)}</div><div><b>Nombre:</b> ${esc(r.Nombre)}</div><div><b>Color:</b> <span class=\"pill\" style=\"border-color:${esc(r.ColorHex)}\">${esc(r.ColorHex)}</span></div><div><b>Triángulos:</b> ${n(r.Triangulos)}</div><div><b>Mesh:</b> ${esc(r.MeshName)}</div><div><b>UniqueId:</b><br><span class=\"small muted\">${esc(r.UniqueId)}</span></div>`; document.getElementById('detalleRapido').innerHTML=`<span class=\"pill\">${esc(r.Categoria)}</span><span class=\"pill\">ID ${esc(r.ElementId)}</span><br>${esc(r.Nombre)}<br><span class=\"muted small\">${esc(r.UniqueId)}</span>`;}");
            html.AppendLine("function mostrarTodo(){categoriaActiva='';textoActivo='';scheduleActiva=null;scheduleSet=null;actualizarPartidaTop();document.getElementById('txtBuscar').value=''; if(root)root.traverse(o=>{if(o.isMesh&&o.userData&&o.userData.rel)setModoMesh(o,'solid');}); document.querySelectorAll('.catBtn').forEach(b=>b.classList.remove('active')); document.querySelector('.catBtn')?.classList.add('active'); pintarTabla(relaciones); actualizarVisibles(); pintarFiltros(); pintarSchedules(); encuadrar(); renderizar();}");
            html.AppendLine("function aislarSeleccionado(){if(!seleccionado)return; scheduleActiva=null; scheduleSet=new Set([String(seleccionado.ElementId)]); categoriaActiva=''; textoActivo=''; aplicarFiltro3D(true); pintarSchedules();}");
            html.AppendLine("function enfocarSeleccionado(){if(!seleccionado)return; const obj=buscarObjetoPorMesh(seleccionado.MeshName); if(obj)enfocar(obj);}");
            html.AppendLine("function ocultarSeleccionado(){if(!seleccionado)return; const obj=buscarObjetoPorMesh(seleccionado.MeshName); if(obj){setModoMesh(obj,'wire'); actualizarVisibles(); renderizar();}}");
            html.AppendLine("function copiarId(){if(!seleccionado)return; navigator.clipboard&&navigator.clipboard.writeText(String(seleccionado.ElementId)); toast('ElementId copiado: <b>'+esc(seleccionado.ElementId)+'</b>');}");
            html.AppendLine("function capturarPNG(){try{const a=document.createElement('a'); a.href=renderer.domElement.toDataURL('image/png'); a.download='MYG_Dashboard_3D.png'; a.click();}catch(e){toast('No se pudo capturar PNG: '+esc(e));}}");
            html.AppendLine("function easeCamara(t){return t<0.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;}");
            html.AppendLine("function centroDeObjeto(obj){try{const box=new THREE.Box3().setFromObject(obj); if(box.isEmpty())return null; return box.getCenter(new THREE.Vector3());}catch(e){return null;}}");
            html.AppendLine("function establecerOrigenOrbita(obj){const c=centroDeObjeto(obj); if(!c||!controls)return; controls.target.copy(c); controls.update(); renderizar();}");
            html.AppendLine("function animarCamara(posFinal,targetFinal,nearFinal,farFinal,duracion){if(!camera||!controls)return; if(camAnim)cancelAnimationFrame(camAnim); const pos0=camera.position.clone(); const tar0=controls.target.clone(); const near0=camera.near; const far0=camera.far; const t0=performance.now(); const dur=Math.max(180,duracion||520); function paso(now){const t=Math.min(1,(now-t0)/dur); const k=easeCamara(t); camera.position.lerpVectors(pos0,posFinal,k); controls.target.lerpVectors(tar0,targetFinal,k); camera.near=near0+(nearFinal-near0)*k; camera.far=far0+(farFinal-far0)*k; camera.updateProjectionMatrix(); controls.update(); renderizar(); if(t<1){camAnim=requestAnimationFrame(paso);}else{camAnim=null; camera.position.copy(posFinal); controls.target.copy(targetFinal); camera.near=nearFinal; camera.far=farFinal; camera.updateProjectionMatrix(); controls.update(); renderizar();}} camAnim=requestAnimationFrame(paso);}");
            html.AppendLine("function vistaIso(){if(!root)return; const box=new THREE.Box3().setFromObject(root); if(box.isEmpty())return; const size=box.getSize(new THREE.Vector3()); const center=box.getCenter(new THREE.Vector3()); const maxDim=Math.max(size.x,size.y,size.z); const dist=maxDim*1.65+1; const pos=new THREE.Vector3(center.x+dist,center.y+dist,center.z+dist); animarCamara(pos,center,Math.max(dist/1000,0.01),dist*1000,520);}");
            html.AppendLine("function toggleModoAlambricoResto(){modoAlambricoResto=!modoAlambricoResto; aplicarFiltro3D(false); toast('Resto del modelo: '+(modoAlambricoResto?'alámbrico':'oculto'));}");
            html.AppendLine("function encuadrar(){if(root) enfocar(root);}");
            html.AppendLine("function encuadrarVisibles(){if(!root)return; let box=new THREE.Box3(); root.traverse(o=>{if(o.isMesh&&o.visible)box.expandByObject(o);}); enfocarBox(box);}");
            html.AppendLine("function enfocar(obj){const box=new THREE.Box3().setFromObject(obj); enfocarBox(box);}");
            html.AppendLine("function enfocarBox(box){if(!box||box.isEmpty())return; const size=box.getSize(new THREE.Vector3()); const center=box.getCenter(new THREE.Vector3()); const maxDim=Math.max(size.x,size.y,size.z); const dist=maxDim*1.8+1; let dir=camera.position.clone().sub(center); if(dir.lengthSq()<0.000001)dir=camera.position.clone().sub(controls.target); if(dir.lengthSq()<0.000001)dir=new THREE.Vector3(1,0.75,1); dir.normalize(); const pos=center.clone().add(dir.multiplyScalar(dist)); animarCamara(pos,center,Math.max(dist/1000,0.01),dist*1000,560);}");
            html.AppendLine("function toast(html){document.getElementById('toast').innerHTML=html;}");
            html.AppendLine("");
            html.AppendLine("</script>");
            html.AppendLine("</body>");
            html.AppendLine("</html>");

            return html.ToString();
        }

        private static string HtmlEscape(string value)
        {
            if (value == null)
                return "";

            return value
                .Replace("&", "&amp;")
                .Replace("<", "&lt;")
                .Replace(">", "&gt;")
                .Replace("\"", "&quot;")
                .Replace("'", "&#39;");
        }

        private static string ObtenerNombreSeguro(Autodesk.Revit.DB.Element e)
        {
            if (e == null)
                return "";

            try
            {
                if (!string.IsNullOrWhiteSpace(e.Name))
                    return e.Name;
            }
            catch
            {
            }

            return "";
        }

        private static string CrearFileUrl(string path)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(path))
                    return "";

                return new System.Uri(path).AbsoluteUri;
            }
            catch
            {
                return path ?? "";
            }
        }

        private static string Csv(params string[] values)
        {
            System.Collections.Generic.List<string> valores = new System.Collections.Generic.List<string>();

            foreach (string v in values)
                valores.Add(EscapeCsv(v));

            return string.Join(",", valores.ToArray());
        }

        private static string EscapeCsv(string value)
        {
            if (value == null)
                value = "";

            value = value.Replace("\r\n", " ").Replace("\n", " ").Replace("\r", " ");

            bool debeEscapar =
                value.Contains(",") ||
                value.Contains("\"") ||
                value.Contains("\n") ||
                value.Contains("\r");

            value = value.Replace("\"", "\"\"");

            if (debeEscapar)
                return "\"" + value + "\"";

            return value;
        }

        private static string JsonEscape(string value)
        {
            if (value == null)
                return "";

            return value
                .Replace("\\", "\\\\")
                .Replace("\"", "\\\"")
                .Replace("\r", "\\r")
                .Replace("\n", "\\n")
                .Replace("\t", "\\t");
        }

        private static string SafeNameToken(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                name = "SIN_CATEGORIA";

            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            foreach (char c in name)
            {
                if (char.IsLetterOrDigit(c))
                    sb.Append(c);
                else
                    sb.Append('_');
            }

            string resultado = sb.ToString();

            while (resultado.Contains("__"))
                resultado = resultado.Replace("__", "_");

            return resultado.Trim('_');
        }

        private static string Format(double value)
        {
            return value.ToString("0.######", CI);
        }

        private static string IdToText(Autodesk.Revit.DB.ElementId id)
        {
            return IdToLong(id).ToString(CI);
        }

        private static long IdToLong(Autodesk.Revit.DB.ElementId id)
        {
            if (id == null)
                return 0;

            try
            {
                System.Reflection.PropertyInfo prop = typeof(Autodesk.Revit.DB.ElementId).GetProperty("Value");

                if (prop != null)
                {
                    object value = prop.GetValue(id, null);

                    if (value != null)
                        return System.Convert.ToInt64(value, CI);
                }
            }
            catch
            {
            }

            try
            {
                System.Reflection.PropertyInfo prop = typeof(Autodesk.Revit.DB.ElementId).GetProperty("IntegerValue");

                if (prop != null)
                {
                    object value = prop.GetValue(id, null);

                    if (value != null)
                        return System.Convert.ToInt64(value, CI);
                }
            }
            catch
            {
            }

            return 0;
        }
    }
}
