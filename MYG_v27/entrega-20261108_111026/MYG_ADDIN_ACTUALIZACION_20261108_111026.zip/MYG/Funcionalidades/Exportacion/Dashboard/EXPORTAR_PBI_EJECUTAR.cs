﻿// =====================================
// HANDLER EXTERNO 2.7
// EXPORTAR DASHBOARD BIM LOCAL
// CSV LOCAL + DASHBOARD 3D LOCAL SIN ACC / SIN DATA EXCHANGE
// CON USING Y NAMESPACE
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace MYG_Addin
{
    public class EjecutarExportarDashboardHandler : IExternalEventHandler
    {
        private static readonly CultureInfo CI = CultureInfo.InvariantCulture;

        public UIDocument UiDoc { get; set; }

        public ExportarDashboard29.ExportarDashboardForm FormInicial { get; set; }

        public ExportarDashboard29.ExportarDataOperacion Operacion { get; set; }

        public string CarpetaBase { get; set; }
        public bool SoloVistaActiva { get; set; }
        public bool SoloCategoriasModelo { get; set; }
        public bool ExportarParametrosInstancia { get; set; }
        public bool ExportarParametrosTipo { get; set; }
        public bool IncluirElementosSinCategoria { get; set; }
        public bool ExportarVisor3D { get; set; }
        public bool HtmlVisorEmbebido { get; set; }
        public bool ExportarObjSeparado { get; set; }
        public bool UsarPreciosEnTablas { get; set; }
        public string RutaCsvPrecios { get; set; }
        public string RutaCsvPartidasDestino { get; set; }

        public EjecutarExportarDashboardHandler()
        {
            Operacion = ExportarDashboard29.ExportarDataOperacion.Ninguna;
            CarpetaBase = "";
            SoloVistaActiva = false;
            SoloCategoriasModelo = true;
            ExportarParametrosInstancia = true;
            ExportarParametrosTipo = true;
            IncluirElementosSinCategoria = false;
            ExportarVisor3D = true;
            HtmlVisorEmbebido = true;
            ExportarObjSeparado = true;
            UsarPreciosEnTablas = false;
            RutaCsvPrecios = "";
            RutaCsvPartidasDestino = "";
        }

        public string GetName()
        {
            return "MYG - Exportar Dashboard BIM Local";
        }

        public void Execute(UIApplication app)
        {
            UIDocument uidoc = UiDoc;

            if (uidoc == null)
                uidoc = app.ActiveUIDocument;

            if (uidoc == null || uidoc.Document == null)
                return;

            Document doc = uidoc.Document;

            try
            {
                if (Operacion == ExportarDashboard29.ExportarDataOperacion.Exportar)
                {
                    string reporte = ExportarData(doc);

                    if (FormInicial != null && !FormInicial.IsDisposed)
                        FormInicial.FinalizarExportacion(reporte, true);

                    return;
                }

                if (Operacion == ExportarDashboard29.ExportarDataOperacion.CrearCsvPartidas)
                {
                    string reporte = MYG_DashboardLocalHelper.CrearCsvPartidas(doc, RutaCsvPartidasDestino);

                    if (FormInicial != null && !FormInicial.IsDisposed)
                        FormInicial.FinalizarExportacion(reporte, true);

                    return;
                }
            }
            catch (Exception ex)
            {
                string mensaje = "ERROR GENERAL:\r\n" + ex.Message + "\r\n\r\n" + ex.ToString();

                if (FormInicial != null && !FormInicial.IsDisposed)
                    FormInicial.FinalizarExportacion(mensaje, false);
            }
            finally
            {
                Operacion = ExportarDashboard29.ExportarDataOperacion.Ninguna;
            }
        }

        private string ExportarData(Document doc)
        {
            DateTime inicio = DateTime.Now;

            string carpetaExportacion = ObtenerCarpetaExportacion(doc);
            Directory.CreateDirectory(carpetaExportacion);

            string pathElementos = Path.Combine(carpetaExportacion, "Fact_Elementos.csv");
            string pathParametros = Path.Combine(carpetaExportacion, "Fact_Parametros.csv");
            string pathCategorias = Path.Combine(carpetaExportacion, "Dim_Categorias.csv");
            string pathReadme = Path.Combine(carpetaExportacion, "README_EXPORTACION.txt");

            List<string> csvElementos = new List<string>();
            List<string> csvParametros = new List<string>();

            Dictionary<long, CategoriaResumen> categorias = new Dictionary<long, CategoriaResumen>();

            csvElementos.Add(Csv(
                "Modelo",
                "RutaModelo",
                "ElementId",
                "UniqueId",
                "CategoriaId",
                "Categoria",
                "Familia",
                "TipoId",
                "Tipo",
                "Nombre",
                "Nivel",
                "FaseCreacion",
                "Volumen_m3",
                "Area_m2",
                "Longitud_m",
                "X_m",
                "Y_m",
                "Z_m"));

            csvParametros.Add(Csv(
                "Modelo",
                "ElementId",
                "UniqueId",
                "Origen",
                "Parametro",
                "ValorTexto",
                "ValorInterno",
                "ValorElementoId",
                "ValorElementoNombre",
                "StorageType",
                "EsSoloLectura"));

            IEnumerable<Element> elementos = ObtenerElementosBase(doc);

            int revisados = 0;
            int exportados = 0;
            int omitidos = 0;
            int parametrosExportados = 0;

            foreach (Element e in elementos)
            {
                revisados++;

                try
                {
                    if (!EsElementoExportable(e))
                    {
                        omitidos++;
                        continue;
                    }

                    ElementType tipo = ObtenerTipoElemento(doc, e);

                    string modelo = doc.Title ?? "";
                    string rutaModelo = ObtenerRutaModelo(doc);
                    string elementId = IdToText(e.Id);
                    string uniqueId = e.UniqueId ?? "";

                    Category categoriaObj = e.Category;
                    string categoria = categoriaObj != null ? categoriaObj.Name : "";
                    long categoriaId = categoriaObj != null ? IdToLong(categoriaObj.Id) : 0;

                    string familia = ObtenerFamilia(e, tipo);
                    string tipoId = tipo != null ? IdToText(tipo.Id) : "";
                    string tipoNombre = tipo != null ? tipo.Name : "";
                    string nombre = ObtenerNombreSeguro(e);
                    string nivel = ObtenerNivel(doc, e);
                    string faseCreacion = ObtenerFaseCreacion(doc, e);

                    string volumen = ObtenerParametroDoubleConvertido(
                        e,
                        BuiltInParameter.HOST_VOLUME_COMPUTED,
                        UnitTypeId.CubicMeters);

                    string area = ObtenerParametroDoubleConvertido(
                        e,
                        BuiltInParameter.HOST_AREA_COMPUTED,
                        UnitTypeId.SquareMeters);

                    string longitud = ObtenerLongitud(e);

                    XYZ centro = ObtenerCentroElemento(e);
                    string x = "";
                    string y = "";
                    string z = "";

                    if (centro != null)
                    {
                        x = Format(UnitUtils.ConvertFromInternalUnits(centro.X, UnitTypeId.Meters));
                        y = Format(UnitUtils.ConvertFromInternalUnits(centro.Y, UnitTypeId.Meters));
                        z = Format(UnitUtils.ConvertFromInternalUnits(centro.Z, UnitTypeId.Meters));
                    }

                    csvElementos.Add(Csv(
                        modelo,
                        rutaModelo,
                        elementId,
                        uniqueId,
                        categoriaId.ToString(CI),
                        categoria,
                        familia,
                        tipoId,
                        tipoNombre,
                        nombre,
                        nivel,
                        faseCreacion,
                        volumen,
                        area,
                        longitud,
                        x,
                        y,
                        z));

                    if (categoriaId != 0)
                    {
                        if (!categorias.ContainsKey(categoriaId))
                        {
                            categorias[categoriaId] = new CategoriaResumen()
                            {
                                CategoriaId = categoriaId,
                                Categoria = categoria,
                                Cantidad = 0
                            };
                        }

                        categorias[categoriaId].Cantidad++;
                    }

                    if (ExportarParametrosInstancia)
                    {
                        parametrosExportados += ExportarParametrosDeElemento(
                            doc,
                            csvParametros,
                            modelo,
                            e,
                            e,
                            elementId,
                            uniqueId,
                            "Instancia");
                    }

                    if (ExportarParametrosTipo && tipo != null)
                    {
                        parametrosExportados += ExportarParametrosDeElemento(
                            doc,
                            csvParametros,
                            modelo,
                            tipo,
                            e,
                            elementId,
                            uniqueId,
                            "Tipo");
                    }

                    exportados++;
                }
                catch
                {
                    omitidos++;
                }
            }

            List<string> csvCategorias = new List<string>();
            csvCategorias.Add(Csv("CategoriaId", "Categoria", "Cantidad"));

            foreach (CategoriaResumen resumen in categorias.Values.OrderBy(x => x.Categoria))
            {
                csvCategorias.Add(Csv(
                    resumen.CategoriaId.ToString(CI),
                    resumen.Categoria,
                    resumen.Cantidad.ToString(CI)));
            }

            File.WriteAllLines(pathElementos, csvElementos, new UTF8Encoding(true));
            File.WriteAllLines(pathParametros, csvParametros, new UTF8Encoding(true));
            File.WriteAllLines(pathCategorias, csvCategorias, new UTF8Encoding(true));

            MYG_DashboardLocalHelper.ExportResult visorResult = null;

            if (ExportarVisor3D)
            {
                visorResult = MYG_DashboardLocalHelper.Exportar(
                    doc,
                    carpetaExportacion,
                    SoloVistaActiva,
                    SoloCategoriasModelo,
                    IncluirElementosSinCategoria,
                    HtmlVisorEmbebido,
                    ExportarObjSeparado,
                    UsarPreciosEnTablas,
                    RutaCsvPrecios);
            }

            File.WriteAllText(pathReadme, CrearReadme(doc, inicio, DateTime.Now, revisados, exportados, omitidos, parametrosExportados, carpetaExportacion, visorResult), new UTF8Encoding(true));

            StringBuilder reporte = new StringBuilder();

            reporte.AppendLine("EXPORTACIÓN DE DASHBOARD TERMINADA");
            reporte.AppendLine("----------------------------------------");
            reporte.AppendLine("Modelo: " + (doc.Title ?? ""));
            reporte.AppendLine("Elementos revisados: " + revisados.ToString());
            reporte.AppendLine("Elementos exportados: " + exportados.ToString());
            reporte.AppendLine("Elementos omitidos: " + omitidos.ToString());
            reporte.AppendLine("Parámetros exportados: " + parametrosExportados.ToString());

            if (visorResult != null)
            {
                reporte.AppendLine("Elementos con geometría 3D: " + visorResult.ElementosConGeometria.ToString());
                reporte.AppendLine("Triángulos OBJ: " + visorResult.TotalTriangulos.ToString());
            }

            reporte.AppendLine("");
            reporte.AppendLine("Carpeta:");
            reporte.AppendLine(carpetaExportacion);
            reporte.AppendLine("");
            reporte.AppendLine("Archivos:");
            reporte.AppendLine("- Fact_Elementos.csv");
            reporte.AppendLine("- Fact_Parametros.csv");
            reporte.AppendLine("- Dim_Categorias.csv");

            if (visorResult != null)
            {
                reporte.AppendLine("- Dim_Visor.csv");
                reporte.AppendLine("- Viewer/index.html");
                reporte.AppendLine("- Viewer/modelo.obj");
                reporte.AppendLine("- Viewer/modelo.mtl");
                reporte.AppendLine("- Viewer/relaciones.json");
                reporte.AppendLine("- Viewer/dashboard_data.json");

                if (UsarPreciosEnTablas)
                {
                    reporte.AppendLine("");
                    reporte.AppendLine("Precios en tablas:");
                    reporte.AppendLine(string.IsNullOrWhiteSpace(RutaCsvPrecios) ? "No se indicó CSV de precios." : RutaCsvPrecios);
                }
            }

            reporte.AppendLine("- README_EXPORTACION.txt");

            return reporte.ToString();
        }

        private IEnumerable<Element> ObtenerElementosBase(Document doc)
        {
            FilteredElementCollector collector;

            if (SoloVistaActiva && doc.ActiveView != null)
            {
                collector = new FilteredElementCollector(doc, doc.ActiveView.Id);
            }
            else
            {
                collector = new FilteredElementCollector(doc);
            }

            return collector
                .WhereElementIsNotElementType()
                .ToElements();
        }

        private bool EsElementoExportable(Element e)
        {
            if (e == null)
                return false;

            if (e.ViewSpecific)
                return false;

            if (e is ElementType)
                return false;

            if (e is RevitLinkInstance)
                return false;

            if (e is ImportInstance)
                return false;

            Category categoria = e.Category;

            if (categoria == null)
                return IncluirElementosSinCategoria;

            if (SoloCategoriasModelo && categoria.CategoryType != CategoryType.Model)
                return false;

            string nombreCategoria = categoria.Name ?? "";

            if (nombreCategoria.Equals("Cámaras", StringComparison.OrdinalIgnoreCase))
                return false;

            return true;
        }

        private ElementType ObtenerTipoElemento(Document doc, Element e)
        {
            if (doc == null || e == null)
                return null;

            try
            {
                ElementId typeId = e.GetTypeId();

                if (typeId == null || typeId == ElementId.InvalidElementId)
                    return null;

                return doc.GetElement(typeId) as ElementType;
            }
            catch
            {
                return null;
            }
        }

        private string ObtenerFamilia(Element e, ElementType tipo)
        {
            try
            {
                FamilyInstance fi = e as FamilyInstance;

                if (fi != null && fi.Symbol != null && fi.Symbol.Family != null)
                    return fi.Symbol.Family.Name ?? "";
            }
            catch
            {
            }

            try
            {
                if (tipo != null)
                {
                    Parameter p = tipo.get_Parameter(BuiltInParameter.SYMBOL_FAMILY_NAME_PARAM);

                    if (p != null)
                    {
                        string valor = p.AsString();

                        if (!string.IsNullOrWhiteSpace(valor))
                            return valor;
                    }
                }
            }
            catch
            {
            }

            try
            {
                if (e != null && e.Category != null)
                    return e.Category.Name ?? "";
            }
            catch
            {
            }

            return "";
        }

        private string ObtenerNivel(Document doc, Element e)
        {
            ElementId levelId = ElementId.InvalidElementId;

            try
            {
                levelId = e.LevelId;
            }
            catch
            {
                levelId = ElementId.InvalidElementId;
            }

            if (levelId == null || levelId == ElementId.InvalidElementId)
            {
                BuiltInParameter[] parametrosNivel = new BuiltInParameter[]
                {
                    BuiltInParameter.FAMILY_LEVEL_PARAM,
                    BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM,
                    BuiltInParameter.SCHEDULE_LEVEL_PARAM,
                    BuiltInParameter.WALL_BASE_CONSTRAINT,
                    BuiltInParameter.STAIRS_BASE_LEVEL_PARAM,
                    BuiltInParameter.ROOF_CONSTRAINT_LEVEL_PARAM,
                    BuiltInParameter.RBS_START_LEVEL_PARAM
                };

                foreach (BuiltInParameter bip in parametrosNivel)
                {
                    try
                    {
                        Parameter p = e.get_Parameter(bip);

                        if (p != null && p.StorageType == StorageType.ElementId)
                        {
                            ElementId id = p.AsElementId();

                            if (id != null && id != ElementId.InvalidElementId)
                            {
                                levelId = id;
                                break;
                            }
                        }
                    }
                    catch
                    {
                    }
                }
            }

            if (levelId != null && levelId != ElementId.InvalidElementId)
            {
                Element nivel = doc.GetElement(levelId);

                if (nivel != null)
                    return nivel.Name ?? "";
            }

            return "";
        }

        private string ObtenerFaseCreacion(Document doc, Element e)
        {
            try
            {
                ElementId faseId = e.CreatedPhaseId;

                if (faseId != null && faseId != ElementId.InvalidElementId)
                {
                    Element fase = doc.GetElement(faseId);

                    if (fase != null)
                        return fase.Name ?? "";
                }
            }
            catch
            {
            }

            return "";
        }

        private string ObtenerParametroDoubleConvertido(
            Element e,
            BuiltInParameter bip,
            ForgeTypeId unitTypeId)
        {
            try
            {
                Parameter p = e.get_Parameter(bip);

                if (p == null || !p.HasValue || p.StorageType != StorageType.Double)
                    return "";

                double valorInterno = p.AsDouble();
                double convertido = UnitUtils.ConvertFromInternalUnits(valorInterno, unitTypeId);

                return Format(convertido);
            }
            catch
            {
                return "";
            }
        }

        private string ObtenerLongitud(Element e)
        {
            try
            {
                Parameter p = e.get_Parameter(BuiltInParameter.CURVE_ELEM_LENGTH);

                if (p != null && p.HasValue && p.StorageType == StorageType.Double)
                {
                    double metros = UnitUtils.ConvertFromInternalUnits(p.AsDouble(), UnitTypeId.Meters);
                    return Format(metros);
                }
            }
            catch
            {
            }

            try
            {
                LocationCurve lc = e.Location as LocationCurve;

                if (lc != null && lc.Curve != null)
                {
                    double metros = UnitUtils.ConvertFromInternalUnits(lc.Curve.Length, UnitTypeId.Meters);
                    return Format(metros);
                }
            }
            catch
            {
            }

            return "";
        }

        private XYZ ObtenerCentroElemento(Element e)
        {
            try
            {
                LocationPoint lp = e.Location as LocationPoint;

                if (lp != null)
                    return lp.Point;
            }
            catch
            {
            }

            try
            {
                LocationCurve lc = e.Location as LocationCurve;

                if (lc != null && lc.Curve != null)
                    return lc.Curve.Evaluate(0.5, true);
            }
            catch
            {
            }

            try
            {
                BoundingBoxXYZ bb = e.get_BoundingBox(null);

                if (bb != null)
                    return (bb.Min + bb.Max) * 0.5;
            }
            catch
            {
            }

            return null;
        }

        private int ExportarParametrosDeElemento(
            Document doc,
            List<string> csv,
            string modelo,
            Element elementoParametros,
            Element elementoBase,
            string elementId,
            string uniqueId,
            string origen)
        {
            if (elementoParametros == null || csv == null)
                return 0;

            int contador = 0;

            foreach (Parameter p in elementoParametros.Parameters)
            {
                try
                {
                    if (p == null || p.Definition == null)
                        continue;

                    string nombreParametro = p.Definition.Name ?? "";

                    if (string.IsNullOrWhiteSpace(nombreParametro))
                        continue;

                    string valorTexto = ObtenerValorTextoParametro(p);
                    string valorInterno = ObtenerValorInternoParametro(p);
                    string valorElementoId = "";
                    string valorElementoNombre = "";

                    if (p.StorageType == StorageType.ElementId)
                    {
                        ElementId valorId = p.AsElementId();
                        valorElementoId = IdToText(valorId);
                        valorElementoNombre = ObtenerNombreElementoPorId(doc, valorId);
                    }

                    string storage = p.StorageType.ToString();
                    string soloLectura = p.IsReadOnly ? "SI" : "NO";

                    csv.Add(Csv(
                        modelo,
                        elementId,
                        uniqueId,
                        origen,
                        nombreParametro,
                        valorTexto,
                        valorInterno,
                        valorElementoId,
                        valorElementoNombre,
                        storage,
                        soloLectura));

                    contador++;
                }
                catch
                {
                }
            }

            return contador;
        }

        private string ObtenerValorTextoParametro(Parameter p)
        {
            try
            {
                if (p == null || !p.HasValue)
                    return "";

                if (p.StorageType == StorageType.String)
                    return p.AsString() ?? "";

                if (p.StorageType == StorageType.Integer)
                    return p.AsInteger().ToString(CI);

                if (p.StorageType == StorageType.Double)
                {
                    string valueString = p.AsValueString();

                    if (!string.IsNullOrWhiteSpace(valueString))
                        return valueString;

                    return p.AsDouble().ToString("G17", CI);
                }

                if (p.StorageType == StorageType.ElementId)
                    return IdToText(p.AsElementId());

                return "";
            }
            catch
            {
                return "";
            }
        }

        private string ObtenerValorInternoParametro(Parameter p)
        {
            try
            {
                if (p == null || !p.HasValue)
                    return "";

                if (p.StorageType == StorageType.Double)
                    return p.AsDouble().ToString("G17", CI);

                if (p.StorageType == StorageType.Integer)
                    return p.AsInteger().ToString(CI);

                if (p.StorageType == StorageType.ElementId)
                    return IdToText(p.AsElementId());

                if (p.StorageType == StorageType.String)
                    return p.AsString() ?? "";

                return "";
            }
            catch
            {
                return "";
            }
        }

        private string ObtenerNombreElementoPorId(Document doc, ElementId id)
        {
            try
            {
                if (doc == null || id == null || id == ElementId.InvalidElementId)
                    return "";

                Element e = doc.GetElement(id);

                if (e == null)
                    return "";

                return ObtenerNombreSeguro(e);
            }
            catch
            {
                return "";
            }
        }

        private string ObtenerNombreSeguro(Element e)
        {
            if (e == null)
                return "";

            try
            {
                ParameterElement pe = e as ParameterElement;

                if (pe != null)
                {
                    Definition def = pe.GetDefinition();

                    if (def != null && !string.IsNullOrWhiteSpace(def.Name))
                        return def.Name;
                }
            }
            catch
            {
            }

            try
            {
                if (!string.IsNullOrWhiteSpace(e.Name))
                    return e.Name;
            }
            catch
            {
            }

            return "";
        }

        private string ObtenerRutaModelo(Document doc)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(doc.PathName))
                    return doc.PathName;
            }
            catch
            {
            }

            return "";
        }

        private string ObtenerCarpetaExportacion(Document doc)
        {
            string baseFolder = CarpetaBase;

            if (string.IsNullOrWhiteSpace(baseFolder))
            {
                string escritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                baseFolder = Path.Combine(escritorio, "MYG_DASHBOARD_EXPORT");
            }

            string nombreModelo = SafeFileName(doc.Title);
            string fecha = DateTime.Now.ToString("yyyyMMdd_HHmmss");

            return Path.Combine(baseFolder, nombreModelo + "_" + fecha);
        }

        private string CrearReadme(
            Document doc,
            DateTime inicio,
            DateTime fin,
            int revisados,
            int exportados,
            int omitidos,
            int parametrosExportados,
            string carpetaExportacion,
            MYG_DashboardLocalHelper.ExportResult visorResult)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("MYG - EXPORTADOR DATA POWER BI LOCAL");
            sb.AppendLine("====================================");
            sb.AppendLine("Modelo: " + (doc.Title ?? ""));
            sb.AppendLine("Ruta modelo: " + ObtenerRutaModelo(doc));
            sb.AppendLine("Inicio: " + inicio.ToString("yyyy-MM-dd HH:mm:ss"));
            sb.AppendLine("Fin: " + fin.ToString("yyyy-MM-dd HH:mm:ss"));
            sb.AppendLine("Carpeta: " + carpetaExportacion);
            sb.AppendLine("");
            sb.AppendLine("Opciones:");
            sb.AppendLine("Solo vista activa: " + (SoloVistaActiva ? "SI" : "NO"));
            sb.AppendLine("Solo categorías de modelo: " + (SoloCategoriasModelo ? "SI" : "NO"));
            sb.AppendLine("Parámetros instancia: " + (ExportarParametrosInstancia ? "SI" : "NO"));
            sb.AppendLine("Parámetros tipo: " + (ExportarParametrosTipo ? "SI" : "NO"));
            sb.AppendLine("Incluir sin categoría: " + (IncluirElementosSinCategoria ? "SI" : "NO"));
            sb.AppendLine("Exportar dashboard 3D local: " + (ExportarVisor3D ? "SI" : "NO"));
            sb.AppendLine("HTML dashboard embebido: " + (HtmlVisorEmbebido ? "SI" : "NO"));
            sb.AppendLine("OBJ separado: " + (ExportarObjSeparado ? "SI" : "NO"));
            sb.AppendLine("");
            sb.AppendLine("Resultado:");
            sb.AppendLine("Elementos revisados: " + revisados.ToString());
            sb.AppendLine("Elementos exportados: " + exportados.ToString());
            sb.AppendLine("Elementos omitidos: " + omitidos.ToString());
            sb.AppendLine("Parámetros exportados: " + parametrosExportados.ToString());

            if (visorResult != null)
            {
                sb.AppendLine("Elementos con geometría 3D: " + visorResult.ElementosConGeometria.ToString());
                sb.AppendLine("Triángulos OBJ: " + visorResult.TotalTriangulos.ToString());
                sb.AppendLine("Viewer URL: " + visorResult.ViewerUrl);
            }

            sb.AppendLine("");
            sb.AppendLine("Archivos:");
            sb.AppendLine("Fact_Elementos.csv");
            sb.AppendLine("Fact_Parametros.csv");
            sb.AppendLine("Dim_Categorias.csv");

            if (visorResult != null)
            {
                sb.AppendLine("Dim_Visor.csv");
                sb.AppendLine("Viewer/index.html");
                sb.AppendLine("Viewer/modelo.obj");
                sb.AppendLine("Viewer/modelo.mtl");
                sb.AppendLine("Viewer/relaciones.json");
            }

            return sb.ToString();
        }

        private static string Csv(params string[] values)
        {
            return string.Join(",", values.Select(EscapeCsv));
        }

        private static string EscapeCsv(string value)
        {
            if (value == null)
                value = "";

            value = value.Replace("\r\n", " ").Replace("\n", " ").Replace("\r", " ");

            bool debeEscapar =
                value.Contains(",") ||
                value.Contains("\"") ||
                value.Contains("\n") ||
                value.Contains("\r");

            value = value.Replace("\"", "\"\"");

            if (debeEscapar)
                return "\"" + value + "\"";

            return value;
        }

        private static string Format(double value)
        {
            return value.ToString("0.######", CI);
        }

        private static string SafeFileName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                name = "Modelo_Revit";

            foreach (char c in Path.GetInvalidFileNameChars())
                name = name.Replace(c, '_');

            return name;
        }

        private static string IdToText(ElementId id)
        {
            if (id == null)
                return "";

            return IdToLong(id).ToString(CI);
        }

        private static long IdToLong(ElementId id)
        {
            if (id == null)
                return 0;

            try
            {
                System.Reflection.PropertyInfo prop = typeof(ElementId).GetProperty("Value");

                if (prop != null)
                {
                    object value = prop.GetValue(id, null);

                    if (value != null)
                        return Convert.ToInt64(value, CI);
                }
            }
            catch
            {
            }

            try
            {
                System.Reflection.PropertyInfo prop = typeof(ElementId).GetProperty("IntegerValue");

                if (prop != null)
                {
                    object value = prop.GetValue(id, null);

                    if (value != null)
                        return Convert.ToInt64(value, CI);
                }
            }
            catch
            {
            }

            return 0;
        }

        private class CategoriaResumen
        {
            public long CategoriaId { get; set; }
            public string Categoria { get; set; }
            public int Cantidad { get; set; }
        }
    }
}
