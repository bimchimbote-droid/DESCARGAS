using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{











    //---------------------------------------------------------
    // COMANDO 5 - EXPORTAR DWG / PDF
    // MODIFICADO: EXPORTA PLANOS SELECCIONADOS DESDE LISTA
    // DWG CON CONFIGURACIÓN INTERNA MYG
    //---------------------------------------------------------

    [Transaction(TransactionMode.Manual)]
    public class ExportDWGCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            UIDocument uidoc = commandData.Application.ActiveUIDocument;

            if (uidoc == null)
                return Result.Cancelled;

            Document doc = uidoc.Document;

            try
            {
                //------------------------------------------
                // ABRIR VENTANA
                //------------------------------------------

                ExportDWGForm form = new ExportDWGForm(doc);

                if (form.ShowDialog() != WinForms.DialogResult.OK)
                    return Result.Cancelled;

                string folder = form.ExportPath;
                bool exportDWG = form.ExportDWG;

                //------------------------------------------
                // OBTENER PLANOS SELECCIONADOS
                //------------------------------------------

                List<ElementId> sheetIds = form.PlanosSeleccionadosElementIds;

                if (sheetIds == null || sheetIds.Count == 0)
                {
                    TaskDialog.Show("Exportación", "No se seleccionó ningún plano para exportar.");
                    return Result.Cancelled;
                }

                List<ViewSheet> sheets = sheetIds
                    .Select(id => doc.GetElement(id))
                    .OfType<ViewSheet>()
                    .Where(x => !x.IsTemplate && !x.IsPlaceholder)
                    .OrderBy(x => x.SheetNumber)
                    .ThenBy(x => x.Name)
                    .ToList();

                if (sheets.Count == 0)
                {
                    TaskDialog.Show("Exportación", "No se encontraron planos válidos para exportar.");
                    return Result.Cancelled;
                }

                //------------------------------------------
                // OPCIONES PDF
                //------------------------------------------

                PDFExportOptions pdfOptions = new PDFExportOptions();

                pdfOptions.HideCropBoundaries = true;
                pdfOptions.HideScopeBoxes = true;
                pdfOptions.HideReferencePlane = true;
                pdfOptions.HideUnreferencedViewTags = true;
                pdfOptions.MaskCoincidentLines = true;
                pdfOptions.PaperFormat = ExportPaperFormat.Default;

                //------------------------------------------
                // OPCIONES DWG INTERNAS MYG
                //------------------------------------------

                DWGExportOptions dwgOptions = null;

                if (exportDWG)
                {
                    dwgOptions = CrearOpcionesDWGInternasMYG();
                }

                //------------------------------------------
                // EXPORTAR
                //------------------------------------------

                int exportadosPDF = 0;
                int exportadosDWG = 0;
                int errores = 0;

                foreach (ViewSheet sheet in sheets)
                {
                    try
                    {
                        string fileName = LimpiarNombreArchivo(sheet.SheetNumber + " - " + sheet.Name);

                        //----------------------------------
                        // EXPORTAR PDF
                        //----------------------------------

                        pdfOptions.FileName = fileName;

                        List<ElementId> pdfSheets = new List<ElementId>();
                        pdfSheets.Add(sheet.Id);

                        bool pdfOk = doc.Export(folder, pdfSheets, pdfOptions);

                        if (pdfOk)
                            exportadosPDF++;

                        //----------------------------------
                        // EXPORTAR DWG
                        //----------------------------------

                        if (exportDWG && dwgOptions != null)
                        {
                            List<ElementId> views = new List<ElementId>();
                            views.Add(sheet.Id);

                            bool dwgOk = doc.Export(folder, fileName, views, dwgOptions);

                            if (dwgOk)
                                exportadosDWG++;
                        }
                    }
                    catch
                    {
                        errores++;
                    }
                }

                //------------------------------------------
                // MENSAJE FINAL
                //------------------------------------------

                string mensaje =
                    "Exportación finalizada.\n\n" +
                    "PDF exportados: " + exportadosPDF.ToString();

                if (exportDWG)
                    mensaje += "\nDWG exportados: " + exportadosDWG.ToString();

                if (errores > 0)
                    mensaje += "\n\nPlanos con error: " + errores.ToString();

                TaskDialog.Show("Exportación", mensaje);

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.ToString();
                TaskDialog.Show("Error al exportar", ex.Message);
                return Result.Failed;
            }
        }

        //------------------------------------------
        // CONFIGURACIÓN DWG INTERNA MYG
        //------------------------------------------

        private static DWGExportOptions CrearOpcionesDWGInternasMYG()
        {
            DWGExportOptions dwgOptions = new DWGExportOptions();

            // CAPAS:
            // Equivale a usar la norma AIA.
            dwgOptions.LayerMapping = "AIA";

            // CAPAS - PROPIEDADES:
            // Equivale a:
            // "Exportar propiedades de categoría BYLAYER
            // y modificaciones BYENTITY".
            dwgOptions.PropOverrides = PropOverrideMode.ByEntity;

            // COLORES:
            // Equivale a:
            // "Especificado en vista (Color verdadero - valores RGB)".
            dwgOptions.Colors = ExportColorMode.TrueColorPerView;

            // UNIDADES:
            // Equivale a unidad DWG en metros.
            dwgOptions.TargetUnit = ExportUnit.Meter;

            // COORDENADAS:
            // false = no usa coordenadas compartidas.
            // Se trabaja con el origen interno / origen del proyecto.
            dwgOptions.SharedCoords = false;

            // VISTAS EN PLANO:
            // Mantiene la lógica de tu código original.
            dwgOptions.MergedViews = true;

            return dwgOptions;
        }

        //------------------------------------------
        // LIMPIAR NOMBRE DE ARCHIVO
        //------------------------------------------

        private static string LimpiarNombreArchivo(string nombre)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                return "Plano";

            foreach (char c in System.IO.Path.GetInvalidFileNameChars())
            {
                nombre = nombre.Replace(c, '_');
            }

            return nombre.Trim();
        }
    }

}
