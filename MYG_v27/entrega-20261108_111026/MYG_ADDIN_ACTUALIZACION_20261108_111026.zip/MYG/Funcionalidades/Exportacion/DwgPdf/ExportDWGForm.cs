using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{








    // =======================================
    // VENTANA EMERGENTE 5 (EXPORTAR DWG / PDF)
    // MODIFICADA: LISTA DE PLANOS + DWG INTERNO MYG
    // =======================================
    public class ExportDWGForm : WinForms.Form
    {
        public string ExportPath { get; private set; }

        // PDF se exporta siempre.
        // Este check controla si también se exporta DWG.
        public bool ExportDWG => chkDWG.Checked;

        public List<string> PlanosSeleccionadosIds
        {
            get
            {
                return todosLosPlanos
                    .Where(x => idsSeleccionados.Contains(x.UniqueId))
                    .Select(x => x.UniqueId)
                    .ToList();
            }
        }

        public List<ElementId> PlanosSeleccionadosElementIds
        {
            get
            {
                return todosLosPlanos
                    .Where(x => idsSeleccionados.Contains(x.UniqueId))
                    .Select(x => x.Id)
                    .ToList();
            }
        }

        WinForms.TextBox txtRuta;
        WinForms.TextBox txtBuscarPlano;

        WinForms.Button btnBuscar;
        WinForms.Button btnEjecutar;
        WinForms.Button btnSeleccionarTodo;
        WinForms.Button btnDeseleccionarTodo;

        WinForms.CheckBox chkDWG;
        WinForms.ListView chkListaPlanos;

        private List<PlanoItem> todosLosPlanos = new List<PlanoItem>();
        private HashSet<string> idsSeleccionados = new HashSet<string>();

        private bool actualizandoChecks = false;
        private bool aplicarCheckMultiple = false;
        private List<WinForms.ListViewItem> itemsParaCheckMultiple = new List<WinForms.ListViewItem>();

        private class PlanoItem
        {
            public ElementId Id { get; set; }
            public string Name { get; set; }
            public string SheetNumber { get; set; }
            public string UniqueId { get; set; }
            public string DisplayName { get; set; }

            public override string ToString()
            {
                return DisplayName;
            }
        }

        public ExportDWGForm(Document doc)
        {
            this.Text = "📤 Exportar planos";
            this.Width = 500;
            this.Height = 590;
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new Drawing.Font("Segoe UI", 9F);

            // ===== AUTOR =====
            var lblAutor = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                Left = 20,
                Top = 10,
                Width = 430,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.Gray
            };

            //--------------------------------
            // RUTA EXPORTACIÓN
            //--------------------------------

            var lblRuta = new WinForms.Label()
            {
                Text = "01. CARPETA DE EXPORTACIÓN",
                Left = 20,
                Top = 40,
                Width = 250,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(25, 40, 76)
            };

            txtRuta = new WinForms.TextBox()
            {
                Left = 20,
                Top = 65,
                Width = 320,
                ReadOnly = true,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                BackColor = Drawing.Color.White
            };

            btnBuscar = CrearBotonSecundario(350, 63);
            btnBuscar.Click += BtnBuscar_Click;

            //--------------------------------
            // EXPORTAR DWG
            //--------------------------------

            chkDWG = new WinForms.CheckBox()
            {
                Text = "Exportar también en DWG",
                Left = 20,
                Top = 105,
                Width = 250,
                Checked = true,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(25, 40, 76)
            };

            //--------------------------------
            // TEXTO CONFIGURACIÓN INTERNA
            //--------------------------------

            var lblConfigInterna = new WinForms.Label()
            {
                Text = "Configuración DWG interna: MYG | AIA | Color por vista | Metro | Origen interno",
                Left = 20,
                Top = 130,
                Width = 430,
                Height = 20,
                Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Regular),
                ForeColor = Drawing.Color.Gray
            };

            //--------------------------------
            // PLANOS A EXPORTAR
            //--------------------------------

            var lblPlanos = new WinForms.Label()
            {
                Text = "02. PLANOS A EXPORTAR",
                Left = 20,
                Top = 165,
                Width = 250,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(25, 40, 76)
            };

            txtBuscarPlano = new WinForms.TextBox()
            {
                Left = 20,
                Top = 190,
                Width = 430,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                BackColor = Drawing.Color.White
            };

            txtBuscarPlano.TextChanged += TxtBuscarPlano_TextChanged;

            btnSeleccionarTodo = new WinForms.Button()
            {
                Text = "Seleccionar todo",
                Left = 20,
                Top = 225,
                Width = 210,
                Height = 30,
                BackColor = Drawing.Color.FromArgb(240, 240, 240),
                ForeColor = Drawing.Color.FromArgb(30, 30, 30),
                FlatStyle = WinForms.FlatStyle.Flat,
                Cursor = WinForms.Cursors.Hand
            };

            btnSeleccionarTodo.FlatAppearance.BorderSize = 1;
            btnSeleccionarTodo.FlatAppearance.BorderColor = Drawing.Color.FromArgb(200, 200, 200);
            btnSeleccionarTodo.Click += BtnSeleccionarTodo_Click;

            btnDeseleccionarTodo = new WinForms.Button()
            {
                Text = "Deseleccionar todo",
                Left = 240,
                Top = 225,
                Width = 210,
                Height = 30,
                BackColor = Drawing.Color.FromArgb(240, 240, 240),
                ForeColor = Drawing.Color.FromArgb(30, 30, 30),
                FlatStyle = WinForms.FlatStyle.Flat,
                Cursor = WinForms.Cursors.Hand
            };

            btnDeseleccionarTodo.FlatAppearance.BorderSize = 1;
            btnDeseleccionarTodo.FlatAppearance.BorderColor = Drawing.Color.FromArgb(200, 200, 200);
            btnDeseleccionarTodo.Click += BtnDeseleccionarTodo_Click;

            chkListaPlanos = new WinForms.ListView()
            {
                Left = 20,
                Top = 265,
                Width = 430,
                Height = 210,
                CheckBoxes = true,
                FullRowSelect = true,
                MultiSelect = true,
                View = WinForms.View.Details,
                HeaderStyle = WinForms.ColumnHeaderStyle.None,
                HideSelection = false,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                BackColor = Drawing.Color.White,
                Font = new Drawing.Font("Segoe UI", 8.5F)
            };

            chkListaPlanos.Columns.Add("Plano", 405);

            chkListaPlanos.ItemChecked += ChkListaPlanos_ItemChecked;
            chkListaPlanos.MouseDown += ChkListaPlanos_MouseDown;

            //--------------------------------
            // LINEA
            //--------------------------------

            var linea = new WinForms.Label()
            {
                Left = 20,
                Top = 495,
                Width = 430,
                Height = 1,
                BackColor = Drawing.Color.FromArgb(220, 220, 220)
            };

            //--------------------------------
            // BOTON EJECUTAR
            //--------------------------------

            btnEjecutar = new WinForms.Button()
            {
                Text = "EJECUTAR",
                Left = 20,
                Top = 515,
                Width = 430,
                Height = 40,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 10F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnEjecutar.FlatAppearance.BorderSize = 0;

            btnEjecutar.MouseEnter += (s, e) => btnEjecutar.BackColor = Drawing.Color.FromArgb(0, 100, 190);
            btnEjecutar.MouseLeave += (s, e) => btnEjecutar.BackColor = Drawing.Color.FromArgb(0, 120, 215);
            btnEjecutar.MouseDown += (s, e) => btnEjecutar.BackColor = Drawing.Color.FromArgb(0, 80, 160);
            btnEjecutar.MouseUp += (s, e) => btnEjecutar.BackColor = Drawing.Color.FromArgb(0, 100, 190);

            btnEjecutar.Click += BtnEjecutar_Click;

            this.AcceptButton = btnEjecutar;

            //--------------------------------
            // AGREGAR CONTROLES
            //--------------------------------

            Controls.Add(lblAutor);

            Controls.Add(lblRuta);
            Controls.Add(txtRuta);
            Controls.Add(btnBuscar);

            Controls.Add(chkDWG);
            Controls.Add(lblConfigInterna);

            Controls.Add(lblPlanos);
            Controls.Add(txtBuscarPlano);
            Controls.Add(btnSeleccionarTodo);
            Controls.Add(btnDeseleccionarTodo);
            Controls.Add(chkListaPlanos);

            Controls.Add(linea);
            Controls.Add(btnEjecutar);

            //--------------------------------
            // CARGAR PLANOS
            //--------------------------------

            CargarPlanosDelProyecto(doc);
            CargarListaFiltrada("");
        }

        // =======================================
        // METODOS VISUALES
        // =======================================

        private WinForms.Button CrearBotonSecundario(int left, int top)
        {
            var btn = new WinForms.Button()
            {
                Text = "Examinar",
                Left = left,
                Top = top,
                Width = 100,
                Height = 28,
                BackColor = Drawing.Color.White,
                ForeColor = Drawing.Color.FromArgb(30, 30, 30),
                FlatStyle = WinForms.FlatStyle.Flat,
                Cursor = WinForms.Cursors.Hand
            };

            btn.FlatAppearance.BorderSize = 1;
            btn.FlatAppearance.BorderColor = Drawing.Color.FromArgb(200, 200, 200);

            btn.MouseEnter += (s, e) => btn.BackColor = Drawing.Color.FromArgb(240, 240, 240);
            btn.MouseLeave += (s, e) => btn.BackColor = Drawing.Color.White;
            btn.MouseDown += (s, e) => btn.BackColor = Drawing.Color.FromArgb(225, 225, 225);
            btn.MouseUp += (s, e) => btn.BackColor = Drawing.Color.FromArgb(240, 240, 240);

            return btn;
        }

        // =======================================
        // CARGA DE PLANOS DEL PROYECTO
        // =======================================

        private void CargarPlanosDelProyecto(Document doc)
        {
            todosLosPlanos = new FilteredElementCollector(doc)
                .OfClass(typeof(ViewSheet))
                .Cast<ViewSheet>()
                .Where(x => !x.IsTemplate && !x.IsPlaceholder)
                .OrderBy(x => x.SheetNumber)
                .ThenBy(x => x.Name)
                .Select(x => new PlanoItem()
                {
                    Id = x.Id,
                    Name = x.Name ?? "",
                    SheetNumber = x.SheetNumber ?? "",
                    UniqueId = x.UniqueId,
                    DisplayName =
                        (string.IsNullOrWhiteSpace(x.SheetNumber) ? "(Sin número)" : x.SheetNumber)
                        + " - "
                        + (x.Name ?? "")
                })
                .ToList();

            // Por defecto se seleccionan todos los planos.
            idsSeleccionados = new HashSet<string>(
                todosLosPlanos.Select(x => x.UniqueId)
            );
        }

        private void CargarListaFiltrada(string filtro)
        {
            string texto = filtro == null ? "" : filtro.Trim().ToLower();

            var lista = todosLosPlanos
                .Where(x =>
                    string.IsNullOrEmpty(texto) ||
                    (x.DisplayName ?? "").ToLower().Contains(texto) ||
                    (x.Name ?? "").ToLower().Contains(texto) ||
                    (x.SheetNumber ?? "").ToLower().Contains(texto))
                .ToList();

            actualizandoChecks = true;

            chkListaPlanos.BeginUpdate();
            chkListaPlanos.Items.Clear();

            foreach (var item in lista)
            {
                WinForms.ListViewItem lvi = new WinForms.ListViewItem(item.DisplayName);
                lvi.Tag = item;
                lvi.Checked = idsSeleccionados.Contains(item.UniqueId);

                chkListaPlanos.Items.Add(lvi);
            }

            chkListaPlanos.EndUpdate();

            actualizandoChecks = false;
        }

        // =======================================
        // EVENTOS
        // =======================================

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            var dialog = new WinForms.FolderBrowserDialog();

            if (dialog.ShowDialog() == WinForms.DialogResult.OK)
            {
                ExportPath = dialog.SelectedPath;
                txtRuta.Text = ExportPath;
            }
        }

        private void TxtBuscarPlano_TextChanged(object sender, EventArgs e)
        {
            CargarListaFiltrada(txtBuscarPlano.Text);
        }

        private void ChkListaPlanos_MouseDown(object sender, WinForms.MouseEventArgs e)
        {
            WinForms.ListViewHitTestInfo hit = chkListaPlanos.HitTest(e.Location);

            if (hit == null || hit.Item == null) return;

            bool clicEnCheck =
                (hit.Location & WinForms.ListViewHitTestLocations.StateImage)
                == WinForms.ListViewHitTestLocations.StateImage;

            if (!clicEnCheck) return;

            aplicarCheckMultiple = false;
            itemsParaCheckMultiple.Clear();

            if (chkListaPlanos.SelectedItems.Count <= 1) return;

            foreach (WinForms.ListViewItem itemSeleccionado in chkListaPlanos.SelectedItems)
            {
                itemsParaCheckMultiple.Add(itemSeleccionado);
            }

            if (!itemsParaCheckMultiple.Contains(hit.Item))
            {
                itemsParaCheckMultiple.Add(hit.Item);
            }

            aplicarCheckMultiple = true;
        }

        private void ChkListaPlanos_ItemChecked(object sender, WinForms.ItemCheckedEventArgs e)
        {
            if (actualizandoChecks) return;

            PlanoItem item = e.Item.Tag as PlanoItem;

            if (item == null) return;

            ActualizarEstadoPlano(item, e.Item.Checked);

            if (!aplicarCheckMultiple) return;

            bool nuevoEstado = e.Item.Checked;

            this.BeginInvoke(new Action(() =>
            {
                actualizandoChecks = true;

                foreach (WinForms.ListViewItem itemSeleccionado in itemsParaCheckMultiple)
                {
                    if (itemSeleccionado == null) continue;

                    itemSeleccionado.Checked = nuevoEstado;

                    PlanoItem plano = itemSeleccionado.Tag as PlanoItem;

                    if (plano == null) continue;

                    ActualizarEstadoPlano(plano, nuevoEstado);
                }

                e.Item.Checked = nuevoEstado;
                ActualizarEstadoPlano(item, nuevoEstado);

                actualizandoChecks = false;

                aplicarCheckMultiple = false;
                itemsParaCheckMultiple.Clear();
            }));
        }

        private void ActualizarEstadoPlano(PlanoItem item, bool seleccionado)
        {
            if (item == null) return;

            if (seleccionado)
            {
                if (!idsSeleccionados.Contains(item.UniqueId))
                    idsSeleccionados.Add(item.UniqueId);
            }
            else
            {
                if (idsSeleccionados.Contains(item.UniqueId))
                    idsSeleccionados.Remove(item.UniqueId);
            }
        }

        private void BtnSeleccionarTodo_Click(object sender, EventArgs e)
        {
            actualizandoChecks = true;

            chkListaPlanos.BeginUpdate();

            foreach (WinForms.ListViewItem lvi in chkListaPlanos.Items)
            {
                PlanoItem item = lvi.Tag as PlanoItem;

                if (item == null) continue;

                ActualizarEstadoPlano(item, true);
                lvi.Checked = true;
            }

            chkListaPlanos.EndUpdate();

            actualizandoChecks = false;
        }

        private void BtnDeseleccionarTodo_Click(object sender, EventArgs e)
        {
            idsSeleccionados.Clear();

            actualizandoChecks = true;

            chkListaPlanos.BeginUpdate();

            foreach (WinForms.ListViewItem lvi in chkListaPlanos.Items)
            {
                lvi.Checked = false;
            }

            chkListaPlanos.EndUpdate();

            actualizandoChecks = false;
        }

        private void BtnEjecutar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ExportPath))
            {
                WinForms.MessageBox.Show("Selecciona una carpeta de exportación");
                return;
            }

            if (PlanosSeleccionadosElementIds.Count == 0)
            {
                WinForms.MessageBox.Show("Selecciona al menos un plano para exportar");
                return;
            }

            this.DialogResult = WinForms.DialogResult.OK;
        }
    }

}
