using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =======================================
    // COMANDO LOGIN
    // =======================================
    [Transaction(TransactionMode.Manual)]
    public class MYG_LoginCommand : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            if (global::MYG_Addin.MYG_ControlAccesoComandos.RequiereIngresoAutomatico())
            {
                return global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar()
                    ? Autodesk.Revit.UI.Result.Succeeded
                    : Autodesk.Revit.UI.Result.Cancelled;
            }

            if (MYG_Sesion.Logueado)
            {
                TaskDialog.Show(
                    "MYG LICENCIA",
                    "La sesión ya se encuentra iniciada.");

                return Result.Succeeded;
            }

            using (LoginForm form = new LoginForm())
            {
                if (form.ShowDialog() != WinForms.DialogResult.OK)
                    return Result.Cancelled;

                MYG_Sesion.IniciarSesion();

                MYG_RibbonControl.HabilitarBotones(true);

                TaskDialog.Show(
                    "MYG LICENCIA",
                    form.MensajeLogin);

                return Result.Succeeded;
            }
        }
    }

}
