using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =======================================
    // VENTANA DE LOGIN - MYG CON LOGO
    // LOGIN ASÍNCRONO PARA EVITAR CONGELAMIENTO
    // =======================================
    public class LoginForm : WinForms.Form
    {
        private WinForms.TextBox txtUsuario;
        private WinForms.TextBox txtClave;
        private WinForms.Button btnLogin;
        private WinForms.Button btnCancelar;
        private WinForms.Button btnCerrar;
        private WinForms.Button btnMinimizar;
        private WinForms.PictureBox picLogo;
        private Drawing.Image logoImage;

        private bool dragging = false;
        private Drawing.Point dragCursorPoint;
        private Drawing.Point dragFormPoint;

        private readonly Drawing.Color ColorFondo = Drawing.Color.FromArgb(18, 18, 18);
        private readonly Drawing.Color ColorPanel = Drawing.Color.FromArgb(30, 30, 30);
        private readonly Drawing.Color ColorCaja = Drawing.Color.FromArgb(42, 42, 42);
        private readonly Drawing.Color ColorTexto = Drawing.Color.FromArgb(235, 235, 235);
        private readonly Drawing.Color ColorSuave = Drawing.Color.FromArgb(165, 165, 165);
        private readonly Drawing.Color ColorAzul = Drawing.Color.FromArgb(0, 145, 210);
        private readonly Drawing.Color ColorAzulHover = Drawing.Color.FromArgb(0, 165, 235);
        private readonly Drawing.Color ColorGrisBoton = Drawing.Color.FromArgb(70, 70, 70);
        private readonly Drawing.Color ColorGrisBotonHover = Drawing.Color.FromArgb(90, 90, 90);

        private class ResultadoLogin
        {
            public bool Ok { get; set; }
            public string Mensaje { get; set; }
        }

        public string Usuario
        {
            get { return txtUsuario.Text.Trim(); }
        }

        public string Clave
        {
            get { return txtClave.Text.Trim(); }
        }

        public string MensajeLogin { get; private set; } = "";
        public bool LoginCorrecto { get; private set; } = false;

        public LoginForm()
        {
            this.Text = "MYG LOGIN";
            this.Width = 560;
            this.Height = 390;
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ShowIcon = false;
            this.BackColor = ColorFondo;
            this.DoubleBuffered = true;

            this.MouseDown += Mover_MouseDown;
            this.MouseMove += Mover_MouseMove;
            this.MouseUp += Mover_MouseUp;

            // =======================================
            // BARRA SUPERIOR
            // =======================================
            WinForms.Panel barraSuperior = new WinForms.Panel();
            barraSuperior.Left = 0;
            barraSuperior.Top = 0;
            barraSuperior.Width = this.Width;
            barraSuperior.Height = 42;
            barraSuperior.BackColor = Drawing.Color.FromArgb(15, 15, 15);
            barraSuperior.MouseDown += Mover_MouseDown;
            barraSuperior.MouseMove += Mover_MouseMove;
            barraSuperior.MouseUp += Mover_MouseUp;
            this.Controls.Add(barraSuperior);

            WinForms.Label lblBarra = new WinForms.Label();
            lblBarra.Text = "MYG LOGIN";
            lblBarra.Left = 16;
            lblBarra.Top = 0;
            lblBarra.Width = 200;
            lblBarra.Height = 42;
            lblBarra.TextAlign = Drawing.ContentAlignment.MiddleLeft;
            lblBarra.ForeColor = ColorSuave;
            lblBarra.Font = new Drawing.Font("Segoe UI", 9, Drawing.FontStyle.Regular);
            lblBarra.BackColor = Drawing.Color.Transparent;
            lblBarra.MouseDown += Mover_MouseDown;
            lblBarra.MouseMove += Mover_MouseMove;
            lblBarra.MouseUp += Mover_MouseUp;
            barraSuperior.Controls.Add(lblBarra);

            btnMinimizar = new WinForms.Button();
            btnMinimizar.Text = "—";
            btnMinimizar.Left = this.Width - 82;
            btnMinimizar.Top = 7;
            btnMinimizar.Width = 30;
            btnMinimizar.Height = 28;
            btnMinimizar.FlatStyle = WinForms.FlatStyle.Flat;
            btnMinimizar.FlatAppearance.BorderSize = 0;
            btnMinimizar.BackColor = Drawing.Color.FromArgb(40, 40, 40);
            btnMinimizar.ForeColor = ColorSuave;
            btnMinimizar.Font = new Drawing.Font("Segoe UI", 10, Drawing.FontStyle.Bold);
            btnMinimizar.Cursor = WinForms.Cursors.Hand;
            btnMinimizar.Click += BtnMinimizar_Click;
            btnMinimizar.MouseEnter += (s, e) => btnMinimizar.BackColor = Drawing.Color.FromArgb(55, 55, 55);
            btnMinimizar.MouseLeave += (s, e) => btnMinimizar.BackColor = Drawing.Color.FromArgb(40, 40, 40);
            barraSuperior.Controls.Add(btnMinimizar);

            btnCerrar = new WinForms.Button();
            btnCerrar.Text = "×";
            btnCerrar.Left = this.Width - 45;
            btnCerrar.Top = 7;
            btnCerrar.Width = 30;
            btnCerrar.Height = 28;
            btnCerrar.FlatStyle = WinForms.FlatStyle.Flat;
            btnCerrar.FlatAppearance.BorderSize = 0;
            btnCerrar.BackColor = Drawing.Color.FromArgb(40, 40, 40);
            btnCerrar.ForeColor = ColorSuave;
            btnCerrar.Font = new Drawing.Font("Segoe UI", 12, Drawing.FontStyle.Bold);
            btnCerrar.Cursor = WinForms.Cursors.Hand;
            btnCerrar.Click += BtnCancelar_Click;
            btnCerrar.MouseEnter += (s, e) => btnCerrar.BackColor = Drawing.Color.FromArgb(160, 45, 45);
            btnCerrar.MouseLeave += (s, e) => btnCerrar.BackColor = Drawing.Color.FromArgb(40, 40, 40);
            barraSuperior.Controls.Add(btnCerrar);

            // =======================================
            // PANEL CENTRAL
            // =======================================
            WinForms.Panel panel = new WinForms.Panel();
            panel.Left = 35;
            panel.Top = 60;
            panel.Width = 490;
            panel.Height = 295;
            panel.BackColor = ColorPanel;
            panel.Paint += Panel_Paint;
            this.Controls.Add(panel);

            // =======================================
            // LOGO MYG
            // =======================================
            picLogo = new WinForms.PictureBox();
            picLogo.Left = 95;
            picLogo.Top = 18;
            picLogo.Width = 300;
            picLogo.Height = 58;
            picLogo.BackColor = Drawing.Color.Transparent;
            picLogo.SizeMode = WinForms.PictureBoxSizeMode.Zoom;
            picLogo.Image = CargarLogoMYG();
            panel.Controls.Add(picLogo);

            if (picLogo.Image == null)
            {
                WinForms.Label lblTituloRespaldo = new WinForms.Label();
                lblTituloRespaldo.Text = "MYG LOGIN";
                lblTituloRespaldo.Left = 0;
                lblTituloRespaldo.Top = 20;
                lblTituloRespaldo.Width = panel.Width;
                lblTituloRespaldo.Height = 45;
                lblTituloRespaldo.TextAlign = Drawing.ContentAlignment.MiddleCenter;
                lblTituloRespaldo.ForeColor = ColorTexto;
                lblTituloRespaldo.Font = new Drawing.Font("Segoe UI", 19, Drawing.FontStyle.Bold);
                lblTituloRespaldo.BackColor = Drawing.Color.Transparent;
                panel.Controls.Add(lblTituloRespaldo);
                lblTituloRespaldo.BringToFront();
            }

            WinForms.Label lblSubtitulo = new WinForms.Label();
            lblSubtitulo.Text = "Ingrese sus credenciales para habilitar las herramientas";
            lblSubtitulo.Left = 0;
            lblSubtitulo.Top = 82;
            lblSubtitulo.Width = panel.Width;
            lblSubtitulo.Height = 25;
            lblSubtitulo.TextAlign = Drawing.ContentAlignment.MiddleCenter;
            lblSubtitulo.ForeColor = ColorSuave;
            lblSubtitulo.Font = new Drawing.Font("Segoe UI", 9, Drawing.FontStyle.Regular);
            lblSubtitulo.BackColor = Drawing.Color.Transparent;
            panel.Controls.Add(lblSubtitulo);

            // =======================================
            // USUARIO
            // =======================================
            WinForms.Label lblUsuario = new WinForms.Label();
            lblUsuario.Text = "USUARIO";
            lblUsuario.Left = 65;
            lblUsuario.Top = 122;
            lblUsuario.Width = 120;
            lblUsuario.Height = 20;
            lblUsuario.ForeColor = ColorTexto;
            lblUsuario.Font = new Drawing.Font("Segoe UI", 8, Drawing.FontStyle.Bold);
            lblUsuario.BackColor = Drawing.Color.Transparent;
            panel.Controls.Add(lblUsuario);

            txtUsuario = new WinForms.TextBox();
            txtUsuario.Left = 65;
            txtUsuario.Top = 145;
            txtUsuario.Width = 360;
            txtUsuario.Height = 28;
            txtUsuario.BorderStyle = WinForms.BorderStyle.FixedSingle;
            txtUsuario.BackColor = ColorCaja;
            txtUsuario.ForeColor = ColorTexto;
            txtUsuario.Font = new Drawing.Font("Segoe UI", 10, Drawing.FontStyle.Regular);
            panel.Controls.Add(txtUsuario);

            // =======================================
            // CONTRASEÑA
            // =======================================
            WinForms.Label lblClave = new WinForms.Label();
            lblClave.Text = "CONTRASEÑA";
            lblClave.Left = 65;
            lblClave.Top = 180;
            lblClave.Width = 120;
            lblClave.Height = 20;
            lblClave.ForeColor = ColorTexto;
            lblClave.Font = new Drawing.Font("Segoe UI", 8, Drawing.FontStyle.Bold);
            lblClave.BackColor = Drawing.Color.Transparent;
            panel.Controls.Add(lblClave);

            txtClave = new WinForms.TextBox();
            txtClave.Left = 65;
            txtClave.Top = 203;
            txtClave.Width = 360;
            txtClave.Height = 28;
            txtClave.BorderStyle = WinForms.BorderStyle.FixedSingle;
            txtClave.BackColor = ColorCaja;
            txtClave.ForeColor = ColorTexto;
            txtClave.Font = new Drawing.Font("Segoe UI", 10, Drawing.FontStyle.Regular);
            txtClave.UseSystemPasswordChar = true;
            panel.Controls.Add(txtClave);

            // =======================================
            // BOTONES
            // =======================================
            btnLogin = new WinForms.Button();
            btnLogin.Text = "ACCEDER";
            btnLogin.Left = 175;
            btnLogin.Top = 250;
            btnLogin.Width = 120;
            btnLogin.Height = 34;
            btnLogin.FlatStyle = WinForms.FlatStyle.Flat;
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.BackColor = ColorAzul;
            btnLogin.ForeColor = Drawing.Color.White;
            btnLogin.Font = new Drawing.Font("Segoe UI", 9, Drawing.FontStyle.Bold);
            btnLogin.Cursor = WinForms.Cursors.Hand;
            btnLogin.Click += BtnLogin_Click;
            btnLogin.MouseEnter += (s, e) =>
            {
                if (btnLogin.Enabled)
                    btnLogin.BackColor = ColorAzulHover;
            };
            btnLogin.MouseLeave += (s, e) =>
            {
                if (btnLogin.Enabled)
                    btnLogin.BackColor = ColorAzul;
            };
            panel.Controls.Add(btnLogin);

            btnCancelar = new WinForms.Button();
            btnCancelar.Text = "CANCELAR";
            btnCancelar.Left = 305;
            btnCancelar.Top = 250;
            btnCancelar.Width = 120;
            btnCancelar.Height = 34;
            btnCancelar.FlatStyle = WinForms.FlatStyle.Flat;
            btnCancelar.FlatAppearance.BorderSize = 0;
            btnCancelar.BackColor = ColorGrisBoton;
            btnCancelar.ForeColor = Drawing.Color.White;
            btnCancelar.Font = new Drawing.Font("Segoe UI", 9, Drawing.FontStyle.Bold);
            btnCancelar.Cursor = WinForms.Cursors.Hand;
            btnCancelar.Click += BtnCancelar_Click;
            btnCancelar.MouseEnter += (s, e) =>
            {
                if (btnCancelar.Enabled)
                    btnCancelar.BackColor = ColorGrisBotonHover;
            };
            btnCancelar.MouseLeave += (s, e) =>
            {
                if (btnCancelar.Enabled)
                    btnCancelar.BackColor = ColorGrisBoton;
            };
            panel.Controls.Add(btnCancelar);

            this.AcceptButton = btnLogin;
            this.CancelButton = btnCancelar;

            txtUsuario.Focus();
        }

        // =======================================
        // CARGAR LOGO DESDE CARPETA DEL ADDIN
        // =======================================
        private Drawing.Image CargarLogoMYG()
        {
            try
            {
                string assemblyPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                string folder = System.IO.Path.GetDirectoryName(assemblyPath);

                string[] posiblesRutas = new string[]
                {
                System.IO.Path.Combine(folder, "iconos", "logo_myg_login.png"),
                System.IO.Path.Combine(folder, "logo_myg_login.png"),
                System.IO.Path.Combine(
                    System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonApplicationData),
                    "Autodesk",
                    "Revit",
                    "Addins",
                    "2027",
                    "MYG",
                    "iconos",
                    "logo_myg_login.png")
                };

                foreach (string ruta in posiblesRutas)
                {
                    if (System.IO.File.Exists(ruta))
                    {
                        using (Drawing.Image imgTemporal = Drawing.Image.FromFile(ruta))
                        {
                            logoImage = new Drawing.Bitmap(imgTemporal);
                            return logoImage;
                        }
                    }
                }
            }
            catch
            {
                return null;
            }

            return null;
        }

        // =======================================
        // BORDE SUTIL DEL PANEL
        // =======================================
        private void Panel_Paint(object sender, WinForms.PaintEventArgs e)
        {
            WinForms.Panel p = sender as WinForms.Panel;

            if (p == null) return;

            using (Drawing.Pen pen = new Drawing.Pen(Drawing.Color.FromArgb(45, 45, 45), 1))
            {
                e.Graphics.DrawRectangle(
                    pen,
                    0,
                    0,
                    p.Width - 1,
                    p.Height - 1);
            }

            using (Drawing.Pen penAzul = new Drawing.Pen(Drawing.Color.FromArgb(0, 145, 210), 2))
            {
                e.Graphics.DrawLine(
                    penAzul,
                    65,
                    105,
                    p.Width - 65,
                    105);
            }
        }

        // =======================================
        // LOGIN ASÍNCRONO
        // =======================================
        private async void BtnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsuario.Text))
            {
                WinForms.MessageBox.Show(
                    "Ingrese el usuario.",
                    "MYG LOGIN",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtClave.Text))
            {
                WinForms.MessageBox.Show(
                    "Ingrese la contraseña.",
                    "MYG LOGIN",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Warning);
                return;
            }

            string usuario = txtUsuario.Text.Trim();
            string clave = txtClave.Text.Trim();

            btnLogin.Enabled = false;
            btnCancelar.Enabled = false;
            btnCerrar.Enabled = false;
            btnMinimizar.Enabled = false;
            txtUsuario.Enabled = false;
            txtClave.Enabled = false;

            string textoOriginal = btnLogin.Text;

            btnLogin.Text = "VALIDANDO...";
            btnLogin.BackColor = Drawing.Color.FromArgb(0, 100, 150);
            this.Cursor = WinForms.Cursors.WaitCursor;

            try
            {
                ResultadoLogin resultado =
                    await System.Threading.Tasks.Task.Run(() =>
                    {
                        string mensajeTemporal;

                        bool ok = LicenciaManager.Login(
                            usuario,
                            clave,
                            out mensajeTemporal);

                        return new ResultadoLogin()
                        {
                            Ok = ok,
                            Mensaje = mensajeTemporal
                        };
                    });

                MensajeLogin = resultado.Mensaje;
                LoginCorrecto = resultado.Ok;

                if (!resultado.Ok)
                {
                    WinForms.MessageBox.Show(
                        MensajeLogin,
                        "MYG LICENCIA",
                        WinForms.MessageBoxButtons.OK,
                        WinForms.MessageBoxIcon.Warning);

                    return;
                }

                this.DialogResult = WinForms.DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MensajeLogin = "Error verificando licencia.\nVerifique su conexión a internet.";

                WinForms.MessageBox.Show(
                    MensajeLogin + "\n\nDetalle: " + ex.Message,
                    "MYG LICENCIA",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Error);
            }
            finally
            {
                if (!this.IsDisposed)
                {
                    btnLogin.Enabled = true;
                    btnCancelar.Enabled = true;
                    btnCerrar.Enabled = true;
                    btnMinimizar.Enabled = true;
                    txtUsuario.Enabled = true;
                    txtClave.Enabled = true;

                    btnLogin.Text = textoOriginal;
                    btnLogin.BackColor = ColorAzul;
                    this.Cursor = WinForms.Cursors.Default;
                }
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = WinForms.DialogResult.Cancel;
            this.Close();
        }

        private void BtnMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = WinForms.FormWindowState.Minimized;
        }

        private void Mover_MouseDown(object sender, WinForms.MouseEventArgs e)
        {
            if (e.Button == WinForms.MouseButtons.Left)
            {
                dragging = true;
                dragCursorPoint = WinForms.Cursor.Position;
                dragFormPoint = this.Location;
            }
        }

        private void Mover_MouseMove(object sender, WinForms.MouseEventArgs e)
        {
            if (dragging)
            {
                Drawing.Point diff = Drawing.Point.Subtract(
                    WinForms.Cursor.Position,
                    new Drawing.Size(dragCursorPoint));

                this.Location = Drawing.Point.Add(
                    dragFormPoint,
                    new Drawing.Size(diff));
            }
        }

        private void Mover_MouseUp(object sender, WinForms.MouseEventArgs e)
        {
            dragging = false;
        }

        protected override void OnFormClosed(WinForms.FormClosedEventArgs e)
        {
            if (picLogo != null)
                picLogo.Image = null;

            if (logoImage != null)
            {
                logoImage.Dispose();
                logoImage = null;
            }

            base.OnFormClosed(e);
        }
    }

}
