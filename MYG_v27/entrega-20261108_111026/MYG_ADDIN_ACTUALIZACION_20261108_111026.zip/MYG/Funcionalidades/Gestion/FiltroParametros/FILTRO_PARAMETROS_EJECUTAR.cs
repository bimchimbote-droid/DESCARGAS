﻿// =====================================
// HANDLER EXTERNO 2.8 - FILTRO DE VISTA POR PARÁMETROS
// CON USING Y NAMESPACE
// REVIT 2027
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace MYG_Addin
{
    public class ColorearParametroExternalEventHandler :
        IExternalEventHandler
    {
        private class ElementoVinculadoAnalizable
        {
            public Document DocumentoVinculado;
            public Element Elemento;
            public ElementId VinculoInstanciaId;
        }

        private class ItemLeyendaVG
        {
            public string Nombre;
            public int Rojo;
            public int Verde;
            public int Azul;

            public List<string> ValoresColumnas =
                new List<string>();
        }

        public UIDocument UiDoc;
        public ColorearParametro28.ColorearParametroForm FormInicial;

        public ColorearParametro28.ColorearParametroOperacion Operacion =
            ColorearParametro28.ColorearParametroOperacion.Ninguna;

        public bool IncluirParametrosTipo = true;
        public bool SoloCategoriasModelo = true;
        public bool IncluirSinValor = true;
        public bool LimitarCategorias = false;

        public List<long> CategoriasSeleccionadas =
            new List<long>();
        public int Transparencia = 0;

        public ColorearParametro28.ParametroDisponible ParametroSeleccionado;

        public string ClaveColorSolicitada = "";
        public int RojoSolicitado = 128;
        public int VerdeSolicitado = 128;
        public int AzulSolicitado = 128;
        public string NombreVistaPermanenteSolicitado = "";

        public List<long> FiltrosVGSeleccionados =
            new List<long>();

        public List<ColorearParametro28.ParametroDisponible>
            ParametrosColumnasVG =
                new List<
                    ColorearParametro28.ParametroDisponible>();

        public bool LimpiarNombresFiltrosMYG =
            true;

        public List<string> ClavesValoresSolicitados =
            new List<string>();

        private ElementId vistaSesionId = ElementId.InvalidElementId;
        private ElementId vistaFiltrosVGId = ElementId.InvalidElementId;
        private bool modoPropiedadesTemporalesPropio;
        private bool aislamientoTemporalPropio;
        private bool vistaPersistenteActual;

        private Dictionary<string, List<ElementId>> gruposActuales =
            new Dictionary<string, List<ElementId>>(
                StringComparer.OrdinalIgnoreCase);

        private string tituloColumnaLeyendaPersonalizado =
            "";

        private string nombreBaseVistaLeyendaPersonalizado =
            "";

        private List<ElementId> filtrosCreadosSesion =
            new List<ElementId>();

        private Dictionary<string, List<ElementId>>
            filtrosPorValorActuales =
                new Dictionary<string, List<ElementId>>(
                    StringComparer.OrdinalIgnoreCase);

        private Dictionary<string, int[]>
            coloresPorValorActuales =
                new Dictionary<string, int[]>(
                    StringComparer.OrdinalIgnoreCase);

        private List<ElementoVinculadoAnalizable>
            elementosVinculadosActuales =
                new List<ElementoVinculadoAnalizable>();

        private Dictionary<string, int>
            cantidadesVinculadasPorValorActuales =
                new Dictionary<string, int>(
                    StringComparer.OrdinalIgnoreCase);

        private Dictionary<string, Parameter>
            parametrosMuestraVinculadosPorValorActuales =
                new Dictionary<string, Parameter>(
                    StringComparer.OrdinalIgnoreCase);

        private Dictionary<string, List<ElementId>>
            vinculosPorValorActuales =
                new Dictionary<string, List<ElementId>>(
                    StringComparer.OrdinalIgnoreCase);

        private static readonly CultureInfo CI =
            CultureInfo.InvariantCulture;

        private static readonly byte[][] PALETA =
        {
            new byte[] { 31, 119, 180 },
            new byte[] { 255, 127, 14 },
            new byte[] { 44, 160, 44 },
            new byte[] { 214, 39, 40 },
            new byte[] { 148, 103, 189 },
            new byte[] { 140, 86, 75 },
            new byte[] { 227, 119, 194 },
            new byte[] { 127, 127, 127 },
            new byte[] { 188, 189, 34 },
            new byte[] { 23, 190, 207 },
            new byte[] { 0, 114, 178 },
            new byte[] { 230, 159, 0 },
            new byte[] { 0, 158, 115 },
            new byte[] { 213, 94, 0 },
            new byte[] { 204, 121, 167 },
            new byte[] { 86, 180, 233 },
            new byte[] { 240, 228, 66 },
            new byte[] { 102, 166, 30 },
            new byte[] { 231, 41, 138 },
            new byte[] { 166, 118, 29 },
            new byte[] { 117, 112, 179 },
            new byte[] { 27, 158, 119 },
            new byte[] { 217, 95, 14 },
            new byte[] { 128, 128, 128 },
            new byte[] { 53, 151, 143 },
            new byte[] { 232, 183, 78 },
            new byte[] { 109, 104, 181 },
            new byte[] { 231, 111, 81 },
            new byte[] { 42, 157, 143 },
            new byte[] { 244, 162, 97 },
            new byte[] { 38, 70, 83 },
            new byte[] { 233, 196, 106 }
        };

        public void Execute(UIApplication app)
        {
            ColorearParametro28.ColorearParametroOperacion operacionActual =
                Operacion;

            Operacion =
                ColorearParametro28.ColorearParametroOperacion.Ninguna;

            try
            {
                if (operacionActual ==
                    ColorearParametro28.ColorearParametroOperacion.Ninguna)
                {
                    return;
                }

                UIDocument uidoc = ObtenerUiDocument(app, operacionActual);
                Document doc = uidoc != null ? uidoc.Document : null;

                if (doc == null || !doc.IsValidObject)
                {
                    throw new InvalidOperationException(
                        "El documento asociado a la ventana ya no está disponible.");
                }

                switch (operacionActual)
                {
                    case ColorearParametro28.ColorearParametroOperacion
                        .CargarParametros:

                        EjecutarCargaParametros(doc);
                        break;

                    case ColorearParametro28.ColorearParametroOperacion
                        .AplicarColores:

                        EjecutarAplicarColores(doc);
                        break;

                    case ColorearParametro28.ColorearParametroOperacion
                        .SeleccionarFilas:

                        EjecutarSeleccion(uidoc, doc);
                        break;

                    case ColorearParametro28.ColorearParametroOperacion
                        .AislarMarcados:

                        EjecutarAislar(doc);
                        break;

                    case ColorearParametro28.ColorearParametroOperacion
                        .MostrarTodos:

                        EjecutarMostrarTodos(doc);
                        break;

                    case ColorearParametro28.ColorearParametroOperacion
                        .Restaurar:

                        EjecutarRestaurar(doc, false);
                        break;

                    case ColorearParametro28.ColorearParametroOperacion
                        .RestaurarYCerrar:

                        EjecutarRestaurar(doc, true);
                        break;

                    case ColorearParametro28.ColorearParametroOperacion
                        .ActualizarColor:

                        EjecutarActualizarColor(doc);
                        break;

                    case ColorearParametro28.ColorearParametroOperacion
                        .CrearVistaPermanente:

                        EjecutarCrearVistaPermanente(
                            uidoc,
                            doc);
                        break;

                    case ColorearParametro28.ColorearParametroOperacion
                        .CargarCategorias:

                        EjecutarCargaCategorias(doc);
                        break;

                    case ColorearParametro28.ColorearParametroOperacion
                        .CrearLeyenda:

                        EjecutarCrearLeyenda(
                            uidoc,
                            doc);
                        break;

                    case ColorearParametro28.ColorearParametroOperacion
                        .CargarFiltrosVG:

                        EjecutarCargaFiltrosVG(
                            uidoc,
                            doc);
                        break;

                    case ColorearParametro28.ColorearParametroOperacion
                        .CrearLeyendaVG:

                        EjecutarCrearLeyendaVG(
                            uidoc,
                            doc);
                        break;
                }
            }
            catch (Exception ex)
            {
                string texto = "ERROR: " + ex.Message;

                if (operacionActual ==
                    ColorearParametro28.ColorearParametroOperacion
                        .RestaurarYCerrar)
                {
                    if (FormInicial != null)
                        FormInicial.PermitirCierreTrasError(texto);
                }
                else
                {
                    if (FormInicial != null)
                        FormInicial.FinalizarOperacion(texto, true);
                }
            }
        }

        public string GetName()
        {
            return "MYG - Filtro de Vista por Parámetros";
        }

        private UIDocument ObtenerUiDocument(
            UIApplication app,
            ColorearParametro28.ColorearParametroOperacion operacionActual)
        {
            UIDocument uidocGuardado = UiDoc;
            UIDocument uidocActivo =
                app != null ? app.ActiveUIDocument : null;

            bool esRestauracion =
                operacionActual ==
                    ColorearParametro28.ColorearParametroOperacion.Restaurar ||
                operacionActual ==
                    ColorearParametro28.ColorearParametroOperacion
                        .RestaurarYCerrar;

            if (esRestauracion)
            {
                if (uidocGuardado != null &&
                    uidocGuardado.Document != null &&
                    uidocGuardado.Document.IsValidObject)
                {
                    return uidocGuardado;
                }

                return uidocActivo;
            }

            if (uidocActivo == null || uidocActivo.Document == null)
            {
                throw new InvalidOperationException(
                    "No hay un documento activo en Revit.");
            }

            if (uidocGuardado != null &&
                uidocGuardado.Document != null &&
                uidocGuardado.Document.IsValidObject &&
                !uidocActivo.Document.Equals(uidocGuardado.Document))
            {
                throw new InvalidOperationException(
                    "La ventana pertenece a otro documento. " +
                    "Vuelve al documento original o cierra esta ventana.");
            }

            UiDoc = uidocActivo;
            return uidocActivo;
        }

        private void EjecutarCargaParametros(Document doc)
        {
            View3D vista = ObtenerVista3DActiva(doc);

            List<Element> elementos =
                ObtenerElementosAnalizables(doc, vista);

            List<ElementoVinculadoAnalizable> elementosVinculados =
                ObtenerElementosVinculadosAnalizables(
                    doc,
                    vista);

            List<ColorearParametro28.ParametroDisponible> parametros =
                ObtenerParametrosDisponibles(
                    doc,
                    elementos,
                    elementosVinculados,
                    IncluirParametrosTipo);

            int totalElementos =
                elementos.Count +
                elementosVinculados.Count;

            if (FormInicial != null)
            {
                FormInicial.CargarParametrosEnVentana(
                    parametros,
                    vista.Name,
                    totalElementos);
            }
        }

        private void EjecutarCargaCategorias(
            Document doc)
        {
            if (ParametroSeleccionado == null ||
                string.IsNullOrWhiteSpace(
                    ParametroSeleccionado.Clave))
            {
                throw new InvalidOperationException(
                    "Selecciona un parámetro válido antes de cargar categorías.");
            }

            View3D vista =
                ObtenerVista3DActiva(doc);

            List<Element> elementos =
                ObtenerElementosAnalizables(
                    doc,
                    vista);

            elementosVinculadosActuales =
                ObtenerElementosVinculadosAnalizables(
                    doc,
                    vista);

            ElementId parametroId;
            StorageType storageType;

            List<ElementId> categoriasFiltrables =
                ObtenerCategoriasFiltrables(
                    doc,
                    elementos,
                    ParametroSeleccionado,
                    out parametroId,
                    out storageType);

            List<ColorearParametro28.CategoriaDisponible> categorias =
                CrearCategoriasDisponibles(
                    doc,
                    elementos,
                    elementosVinculadosActuales,
                    ParametroSeleccionado,
                    categoriasFiltrables);

            if (FormInicial != null)
            {
                FormInicial.CargarCategoriasEnVentana(
                    categorias,
                    ParametroSeleccionado.Clave);
            }
        }

        private void EjecutarAplicarColores(Document doc)
        {
            if (ParametroSeleccionado == null ||
                string.IsNullOrWhiteSpace(ParametroSeleccionado.Clave))
            {
                throw new InvalidOperationException(
                    "No se recibió un parámetro válido.");
            }

            View3D vista = ObtenerVista3DActiva(doc);

            List<Element> elementos =
                ObtenerElementosAnalizables(doc, vista);

            elementosVinculadosActuales =
                ObtenerElementosVinculadosAnalizables(
                    doc,
                    vista);

            cantidadesVinculadasPorValorActuales =
                new Dictionary<string, int>(
                    StringComparer.OrdinalIgnoreCase);

            parametrosMuestraVinculadosPorValorActuales =
                new Dictionary<string, Parameter>(
                    StringComparer.OrdinalIgnoreCase);

            vinculosPorValorActuales =
                new Dictionary<string, List<ElementId>>(
                    StringComparer.OrdinalIgnoreCase);

            Dictionary<string, List<ElementId>> grupos =
                AgruparElementosPorValor(
                    doc,
                    elementos,
                    ParametroSeleccionado,
                    IncluirSinValor);

            AgregarValoresVinculadosAGrupos(
                elementosVinculadosActuales,
                ParametroSeleccionado,
                IncluirSinValor,
                grupos);

            if (grupos.Count == 0)
            {
                throw new InvalidOperationException(
                    "El parámetro seleccionado no tiene valores filtrables " +
                    "en los elementos visibles del anfitrión ni de sus vínculos.");
            }

            List<ColorearParametro28.LeyendaValor> leyenda =
                CrearLeyenda(grupos);

            ElementId patronSolidoId =
                ObtenerPatronSolido(doc);

            if (patronSolidoId == ElementId.InvalidElementId)
            {
                throw new InvalidOperationException(
                    "No se encontró el patrón de relleno sólido del proyecto.");
            }

            bool vistaActualEsPropia =
                modoPropiedadesTemporalesPropio &&
                vistaSesionId != ElementId.InvalidElementId &&
                vistaSesionId == vista.Id;

            if (vista.IsTemporaryViewPropertiesModeEnabled() &&
                !vistaActualEsPropia)
            {
                throw new InvalidOperationException(
                    "La vista ya tiene activadas Propiedades de vista temporales " +
                    "por otra operación. Restáuralas primero.");
            }

            if (!vista.IsTemporaryViewPropertiesModeEnabled() &&
                !vista.CanEnableTemporaryViewPropertiesMode())
            {
                throw new InvalidOperationException(
                    "Revit no permite activar Propiedades de vista temporales " +
                    "en el estado actual de la vista.");
            }

            int cantidadFiltros = 0;

            filtrosPorValorActuales =
                new Dictionary<string, List<ElementId>>(
                    StringComparer.OrdinalIgnoreCase);

            coloresPorValorActuales =
                new Dictionary<string, int[]>(
                    StringComparer.OrdinalIgnoreCase);

            using (Transaction tx =
                new Transaction(
                    doc,
                    "MYG - Crear filtros de vista por parámetro"))
            {
                tx.Start();

                LimpiarSesionTemporalDentroDeTransaccion(doc);

                bool modoActivado =
                    vista.EnableTemporaryViewPropertiesMode(vista.Id);

                if (!modoActivado)
                {
                    throw new InvalidOperationException(
                        "No se pudo activar Propiedades de vista temporales.");
                }

                cantidadFiltros =
                    CrearFiltrosVisibilityGraphics(
                        doc,
                        vista,
                        elementos,
                        grupos,
                        leyenda,
                        ParametroSeleccionado,
                        patronSolidoId);

                if (cantidadFiltros == 0)
                {
                    throw new InvalidOperationException(
                        "Revit no pudo crear filtros de Visibilidad/Gráficos " +
                        "para el parámetro seleccionado. Verifica que el parámetro " +
                        "sea filtrable en las categorías analizadas.");
                }

                tx.Commit();
            }

            vistaSesionId = vista.Id;
            modoPropiedadesTemporalesPropio = true;
            aislamientoTemporalPropio = false;
            vistaPersistenteActual = false;
            gruposActuales = grupos;

            int totalAnalizados =
                leyenda.Sum(x =>
                    x == null ? 0 : x.Cantidad);

            if (FormInicial != null)
            {
                FormInicial.CargarLeyendaEnVentana(
                    leyenda,
                    ParametroSeleccionado.NombreParametro +
                    "  |  Filtros VG: " +
                    cantidadFiltros.ToString(CI),
                    totalAnalizados);
            }
        }

        private void EjecutarActualizarColor(
            Document doc)
        {
            if (string.IsNullOrWhiteSpace(
                ClaveColorSolicitada))
            {
                throw new InvalidOperationException(
                    "No se recibió el valor cuyo color debe actualizarse.");
            }

            View3D vista =
                ObtenerVistaSesionActiva(doc);

            List<ElementId> filtrosValor;

            bool encontradosEnMemoria =
                filtrosPorValorActuales.TryGetValue(
                    ClaveColorSolicitada,
                    out filtrosValor) &&
                filtrosValor != null &&
                filtrosValor.Count > 0;

            if (!encontradosEnMemoria)
            {
                filtrosValor =
                    BuscarFiltrosDelValorEnVista(
                        doc,
                        vista,
                        ClaveColorSolicitada);

                if (filtrosValor.Count > 0)
                {
                    filtrosPorValorActuales[
                        ClaveColorSolicitada] =
                            new List<ElementId>(
                                filtrosValor);
                }
            }

            if (filtrosValor == null ||
                filtrosValor.Count == 0)
            {
                throw new InvalidOperationException(
                    "No se localizaron en la vista los filtros del valor '" +
                    ClaveColorSolicitada +
                    "'. Pulsa CREAR FILTROS nuevamente y vuelve a intentarlo.");
            }

            int rojo = LimitarRgb(RojoSolicitado);
            int verde = LimitarRgb(VerdeSolicitado);
            int azul = LimitarRgb(AzulSolicitado);

            ElementId patronSolidoId =
                ObtenerPatronSolido(doc);

            if (patronSolidoId ==
                ElementId.InvalidElementId)
            {
                throw new InvalidOperationException(
                    "No se encontró el patrón de relleno sólido.");
            }

            Autodesk.Revit.DB.Color color =
                new Autodesk.Revit.DB.Color(
                    Convert.ToByte(rojo),
                    Convert.ToByte(verde),
                    Convert.ToByte(azul));

            using (Transaction tx =
                new Transaction(
                    doc,
                    "MYG - Actualizar color RGB del filtro"))
            {
                tx.Start();

                using (OverrideGraphicSettings ogs =
                    CrearOverrideGrafico(
                        color,
                        patronSolidoId,
                        Transparencia))
                {
                    foreach (ElementId filtroId
                        in filtrosValor)
                    {
                        if (filtroId == null ||
                            filtroId ==
                                ElementId.InvalidElementId)
                        {
                            continue;
                        }

                        Element filtro =
                            doc.GetElement(filtroId);

                        if (filtro == null ||
                            !filtro.IsValidObject)
                        {
                            continue;
                        }

                        bool agregado =
                            vista.GetFilters()
                                .Any(x =>
                                    x != null &&
                                    x.Value ==
                                        filtroId.Value);

                        if (!agregado)
                            continue;

                        vista.SetFilterOverrides(
                            filtroId,
                            ogs);
                    }
                }

                tx.Commit();
            }

            coloresPorValorActuales[
                ClaveColorSolicitada] =
                    new int[]
                    {
                        rojo,
                        verde,
                        azul
                    };

            if (FormInicial != null)
            {
                FormInicial.NotificarColorActualizado(
                    ClaveColorSolicitada,
                    rojo,
                    verde,
                    azul);
            }
        }

        private void EjecutarCrearVistaPermanente(
            UIDocument uidoc,
            Document doc)
        {
            View3D vistaOrigen =
                ObtenerVistaSesionActiva(doc);

            if (!vistaOrigen.CanViewBeDuplicated(
                ViewDuplicateOption.Duplicate))
            {
                throw new InvalidOperationException(
                    "La vista 3D actual no puede duplicarse.");
            }

            if (filtrosPorValorActuales == null ||
                filtrosPorValorActuales.Count == 0)
            {
                throw new InvalidOperationException(
                    "Primero debes crear filtros en la vista.");
            }

            ElementId patronSolidoId =
                ObtenerPatronSolido(doc);

            if (patronSolidoId ==
                ElementId.InvalidElementId)
            {
                throw new InvalidOperationException(
                    "No se encontró el patrón de relleno sólido.");
            }

            ElementId nuevaVistaId =
                ElementId.InvalidElementId;

            string nombreVistaFinal = "";

            using (Transaction tx =
                new Transaction(
                    doc,
                    "MYG - Crear vista permanente por parámetro"))
            {
                tx.Start();

                //-------------------------------------------------
                // 1. RESTAURAR PRIMERO LA VISTA ORIGINAL
                //
                // Es importante hacer esto ANTES de duplicarla.
                // Si se duplica mientras está activo el modo de
                // Propiedades de vista temporal, la nueva vista
                // también puede conservar ese modo.
                //-------------------------------------------------

                if (aislamientoTemporalPropio &&
                    vistaOrigen
                        .IsTemporaryHideIsolateActive())
                {
                    vistaOrigen.DisableTemporaryViewMode(
                        TemporaryViewMode
                            .TemporaryHideIsolate);
                }

                if (modoPropiedadesTemporalesPropio &&
                    vistaOrigen
                        .IsTemporaryViewPropertiesModeEnabled())
                {
                    bool modoDesactivado =
                        vistaOrigen
                            .EnableTemporaryViewPropertiesMode(
                                ElementId.InvalidElementId);

                    if (!modoDesactivado &&
                        vistaOrigen
                            .IsTemporaryViewPropertiesModeEnabled())
                    {
                        throw new InvalidOperationException(
                            "No se pudo desactivar el modo de " +
                            "Propiedades de vista temporal antes " +
                            "de crear la vista permanente.");
                    }
                }

                doc.Regenerate();

                //-------------------------------------------------
                // 2. DUPLICAR LA VISTA YA RESTAURADA
                //-------------------------------------------------

                nuevaVistaId =
                    vistaOrigen.Duplicate(
                        ViewDuplicateOption.Duplicate);

                View3D nuevaVista =
                    doc.GetElement(
                        nuevaVistaId) as View3D;

                if (nuevaVista == null)
                {
                    throw new InvalidOperationException(
                        "Revit no pudo crear la nueva vista 3D.");
                }

                //-------------------------------------------------
                // SEGURIDAD:
                // La vista nueva nunca debe conservar un modo
                // temporal.
                //-------------------------------------------------

                if (nuevaVista
                    .IsTemporaryHideIsolateActive())
                {
                    nuevaVista.DisableTemporaryViewMode(
                        TemporaryViewMode
                            .TemporaryHideIsolate);
                }

                if (nuevaVista
                    .IsTemporaryViewPropertiesModeEnabled())
                {
                    bool temporalDesactivado =
                        nuevaVista
                            .EnableTemporaryViewPropertiesMode(
                                ElementId.InvalidElementId);

                    if (!temporalDesactivado &&
                        nuevaVista
                            .IsTemporaryViewPropertiesModeEnabled())
                    {
                        throw new InvalidOperationException(
                            "La vista duplicada continúa en modo " +
                            "temporal y no pudo convertirse en " +
                            "una vista permanente.");
                    }
                }

                //-------------------------------------------------
                // 3. ASIGNAR NOMBRE ÚNICO
                //-------------------------------------------------

                nombreVistaFinal =
                    CrearNombreVistaUnico(
                        doc,
                        NombreVistaPermanenteSolicitado);

                nuevaVista.Name =
                    nombreVistaFinal;

                //-------------------------------------------------
                // 4. AGREGAR FILTROS A LA NUEVA VISTA
                //
                // En este punto la vista NO está en modo temporal,
                // por lo que AddFilter y SetFilterOverrides quedan
                // guardados permanentemente en la vista.
                //-------------------------------------------------

                HashSet<long> filtrosYaAgregados =
                    new HashSet<long>();

                foreach (ElementId idExistente
                    in nuevaVista.GetFilters())
                {
                    if (idExistente != null)
                    {
                        filtrosYaAgregados.Add(
                            idExistente.Value);
                    }
                }

                foreach (
                    KeyValuePair<string, List<ElementId>>
                    grupoFiltro
                    in filtrosPorValorActuales)
                {
                    int[] rgb;

                    if (!coloresPorValorActuales.TryGetValue(
                        grupoFiltro.Key,
                        out rgb) ||
                        rgb == null ||
                        rgb.Length < 3)
                    {
                        rgb =
                            new int[]
                            {
                                128,
                                128,
                                128
                            };
                    }

                    Autodesk.Revit.DB.Color color =
                        new Autodesk.Revit.DB.Color(
                            Convert.ToByte(
                                LimitarRgb(rgb[0])),
                            Convert.ToByte(
                                LimitarRgb(rgb[1])),
                            Convert.ToByte(
                                LimitarRgb(rgb[2])));

                    using (OverrideGraphicSettings ogs =
                        CrearOverrideGrafico(
                            color,
                            patronSolidoId,
                            Transparencia))
                    {
                        foreach (ElementId filtroId
                            in grupoFiltro.Value)
                        {
                            if (filtroId == null ||
                                filtroId ==
                                    ElementId.InvalidElementId)
                            {
                                continue;
                            }

                            ParameterFilterElement filtro =
                                doc.GetElement(
                                    filtroId)
                                    as ParameterFilterElement;

                            if (filtro == null ||
                                !filtro.IsValidObject)
                            {
                                continue;
                            }

                            if (!filtrosYaAgregados.Contains(
                                filtroId.Value))
                            {
                                nuevaVista.AddFilter(
                                    filtroId);

                                filtrosYaAgregados.Add(
                                    filtroId.Value);
                            }

                            nuevaVista.SetFilterVisibility(
                                filtroId,
                                true);

                            nuevaVista.SetFilterOverrides(
                                filtroId,
                                ogs);

                            //-------------------------------------------------
                            // CONVERTIR NOMBRE TEMPORAL EN PERMANENTE
                            //-------------------------------------------------

                            string nuevoNombreFiltro =
                                CrearNombreFiltroPermanente(
                                    doc,
                                    nombreVistaFinal,
                                    grupoFiltro.Key,
                                    filtro.Name);

                            filtro.Name =
                                nuevoNombreFiltro;
                        }
                    }
                }

                doc.Regenerate();

                //-------------------------------------------------
                // 5. VERIFICACIÓN FINAL
                //-------------------------------------------------

                if (nuevaVista
                    .IsTemporaryViewPropertiesModeEnabled())
                {
                    throw new InvalidOperationException(
                        "La vista fue creada, pero Revit informa " +
                        "que todavía está en modo temporal.");
                }

                tx.Commit();
            }

            //-------------------------------------------------
            // LOS FILTROS AHORA SON PERMANENTES.
            // No deben eliminarse cuando se cierre la ventana.
            //-------------------------------------------------

            filtrosCreadosSesion =
                new List<ElementId>();

            vistaSesionId =
                nuevaVistaId;

            modoPropiedadesTemporalesPropio = false;
            aislamientoTemporalPropio = false;
            vistaPersistenteActual = true;

            View3D vistaCreada =
                doc.GetElement(
                    nuevaVistaId) as View3D;

            if (vistaCreada == null)
            {
                throw new InvalidOperationException(
                    "La vista se creó, pero no pudo activarse.");
            }

            //-------------------------------------------------
            // ACTIVAR LA VISTA PERMANENTE
            //-------------------------------------------------

            uidoc.ActiveView =
                vistaCreada;

            if (FormInicial != null)
            {
                FormInicial
                    .NotificarVistaPermanenteCreada(
                        nombreVistaFinal);
            }
        }

        private List<ElementId>
            BuscarFiltrosDelValorEnVista(
                Document doc,
                View vista,
                string claveValor)
        {
            List<ElementId> resultado =
                new List<ElementId>();

            if (doc == null ||
                vista == null ||
                string.IsNullOrWhiteSpace(
                    claveValor))
            {
                return resultado;
            }

            string valorLimpio =
                LimpiarNombreFiltro(
                    claveValor);

            string parametroLimpio = "";

            if (ParametroSeleccionado != null)
            {
                parametroLimpio =
                    LimpiarNombreFiltro(
                        ParametroSeleccionado
                            .NombreParametro);
            }

            string prefijoTemporal =
                "MYG_TMP_FVP_" +
                IdToText(vista.Id) +
                "_";

            string prefijoEsperado =
                prefijoTemporal +
                parametroLimpio +
                "_" +
                valorLimpio;

            HashSet<long> encontrados =
                new HashSet<long>();

            ICollection<ElementId> filtrosVista =
                vista.GetFilters();

            if (filtrosVista == null)
                return resultado;

            foreach (ElementId filtroId
                in filtrosVista)
            {
                if (filtroId == null ||
                    filtroId ==
                        ElementId.InvalidElementId)
                {
                    continue;
                }

                ParameterFilterElement filtro =
                    doc.GetElement(
                        filtroId)
                        as ParameterFilterElement;

                if (filtro == null ||
                    !filtro.IsValidObject)
                {
                    continue;
                }

                string nombre =
                    filtro.Name ?? "";

                bool coincide = false;

                if (!string.IsNullOrWhiteSpace(
                    prefijoEsperado))
                {
                    coincide =
                        nombre.Equals(
                            prefijoEsperado,
                            StringComparison.OrdinalIgnoreCase) ||
                        nombre.StartsWith(
                            prefijoEsperado + "_G",
                            StringComparison.OrdinalIgnoreCase) ||
                        nombre.StartsWith(
                            prefijoEsperado + "_",
                            StringComparison.OrdinalIgnoreCase);
                }

                if (!coincide &&
                    nombre.StartsWith(
                        prefijoTemporal,
                        StringComparison.OrdinalIgnoreCase))
                {
                    string nombreSinPrefijo =
                        nombre.Substring(
                            prefijoTemporal.Length);

                    bool contieneParametro =
                        string.IsNullOrWhiteSpace(
                            parametroLimpio) ||
                        nombreSinPrefijo.StartsWith(
                            parametroLimpio + "_",
                            StringComparison.OrdinalIgnoreCase);

                    bool contieneValor =
                        nombreSinPrefijo.IndexOf(
                            valorLimpio,
                            StringComparison.OrdinalIgnoreCase) >= 0;

                    coincide =
                        contieneParametro &&
                        contieneValor;
                }

                if (!coincide &&
                    filtrosCreadosSesion != null)
                {
                    bool perteneceSesion =
                        filtrosCreadosSesion.Any(x =>
                            x != null &&
                            x.Value ==
                                filtroId.Value);

                    if (perteneceSesion)
                    {
                        string sufijoValor =
                            "_" +
                            valorLimpio;

                        coincide =
                            nombre.EndsWith(
                                sufijoValor,
                                StringComparison.OrdinalIgnoreCase) ||
                            nombre.IndexOf(
                                sufijoValor + "_G",
                                StringComparison.OrdinalIgnoreCase) >= 0;
                    }
                }

                if (coincide &&
                    encontrados.Add(
                        filtroId.Value))
                {
                    resultado.Add(
                        filtroId);
                }
            }

            // Respaldo final:
            // si solo existe un grupo de filtros en la sesión y
            // no fue posible reconocer el nombre, usar ese grupo.
            if (resultado.Count == 0 &&
                filtrosCreadosSesion != null &&
                filtrosCreadosSesion.Count > 0 &&
                gruposActuales != null &&
                gruposActuales.Count == 1)
            {
                foreach (ElementId filtroId
                    in filtrosCreadosSesion)
                {
                    if (filtroId == null ||
                        filtroId ==
                            ElementId.InvalidElementId)
                    {
                        continue;
                    }

                    Element filtro =
                        doc.GetElement(
                            filtroId);

                    if (filtro != null &&
                        filtro.IsValidObject &&
                        encontrados.Add(
                            filtroId.Value))
                    {
                        resultado.Add(
                            filtroId);
                    }
                }
            }

            return resultado;
        }

        private int LimitarRgb(int valor)
        {
            if (valor < 0)
                return 0;

            if (valor > 255)
                return 255;

            return valor;
        }

        private string CrearNombreVistaUnico(
            Document doc,
            string nombreSolicitado)
        {
            string baseNombre =
                string.IsNullOrWhiteSpace(
                    nombreSolicitado)
                    ? "FVP - Vista por parámetros"
                    : LimpiarNombreFiltro(
                        nombreSolicitado);

            HashSet<string> nombres =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            FilteredElementCollector collector =
                new FilteredElementCollector(doc)
                    .OfClass(typeof(View));

            foreach (Element elemento
                in collector)
            {
                View vista =
                    elemento as View;

                if (vista == null)
                    continue;

                string nombre =
                    vista.Name ?? "";

                if (!string.IsNullOrWhiteSpace(nombre))
                    nombres.Add(nombre);
            }

            string candidato =
                baseNombre;

            int numero = 1;

            while (nombres.Contains(candidato))
            {
                candidato =
                    baseNombre +
                    " (" +
                    numero.ToString("00", CI) +
                    ")";

                numero++;
            }

            return candidato;
        }

        private string CrearNombreFiltroPermanente(
            Document doc,
            string nombreVista,
            string valor,
            string nombreActual)
        {
            string nombreBase =
                "MYG_FVP_" +
                LimpiarNombreFiltro(nombreVista) +
                "_" +
                LimpiarNombreFiltro(valor);

            if (nombreBase.Length > 180)
            {
                nombreBase =
                    nombreBase.Substring(
                        0,
                        180);
            }

            HashSet<string> nombres =
                ObtenerNombresFiltrosExistentes(doc);

            if (!string.IsNullOrWhiteSpace(
                nombreActual))
            {
                nombres.Remove(
                    nombreActual);
            }

            return CrearNombreFiltroUnico(
                nombreBase,
                nombres);
        }

        private void EjecutarCargaFiltrosVG(
            UIDocument uidoc,
            Document doc)
        {
            if (uidoc == null ||
                uidoc.ActiveView == null)
            {
                throw new InvalidOperationException(
                    "No hay una vista activa en Revit.");
            }

            View vista =
                uidoc.ActiveView;

            //-------------------------------------------------
            // FILTROS DE LA VISTA
            //-------------------------------------------------
            List<ElementId> idsFiltros =
                ObtenerFiltrosOrdenadosVista(
                    vista);

            List<ColorearParametro28.FiltroVGDisponible> resultado =
                new List<
                    ColorearParametro28.FiltroVGDisponible>();

            foreach (ElementId filtroId
                in idsFiltros)
            {
                if (filtroId == null ||
                    filtroId ==
                        ElementId.InvalidElementId)
                {
                    continue;
                }

                Element filtro =
                    doc.GetElement(
                        filtroId);

                if (filtro == null ||
                    !filtro.IsValidObject)
                {
                    continue;
                }

                OverrideGraphicSettings ogs = null;

                try
                {
                    ogs =
                        vista.GetFilterOverrides(
                            filtroId);
                }
                catch
                {
                    ogs = null;
                }

                Autodesk.Revit.DB.Color color =
                    ObtenerColorRepresentativoFiltroVG(
                        ogs);

                bool visible = true;

                try
                {
                    visible =
                        vista.GetFilterVisibility(
                            filtroId);
                }
                catch
                {
                    visible = true;
                }

                resultado.Add(
                    new ColorearParametro28.FiltroVGDisponible()
                    {
                        IdFiltro =
                            filtroId.Value,

                        NombreOriginal =
                            filtro.Name ?? "",

                        Rojo =
                            color != null
                                ? color.Red
                                : 128,

                        Verde =
                            color != null
                                ? color.Green
                                : 128,

                        Azul =
                            color != null
                                ? color.Blue
                                : 128,

                        Visible =
                            visible
                    });
            }

            //-------------------------------------------------
            // PARÁMETROS DISPONIBLES PARA COLUMNAS
            //
            // Se toman de los elementos visibles de la vista,
            // tanto de anfitrión como, cuando es posible,
            // de los vínculos visibles.
            //-------------------------------------------------
            List<Element> elementosHost =
                ObtenerElementosAnalizablesVistaGenerica(
                    doc,
                    vista);

            List<ElementoVinculadoAnalizable>
                elementosVinculados =
                    ObtenerElementosVinculadosVistaGenerica(
                        doc,
                        vista);

            List<ColorearParametro28.ParametroDisponible>
                parametrosDisponibles =
                    ObtenerParametrosDisponibles(
                        doc,
                        elementosHost,
                        elementosVinculados,
                        true);

            vistaFiltrosVGId =
                vista.Id;

            if (FormInicial != null)
            {
                FormInicial
                    .CargarFiltrosVGEnVentana(
                        resultado,
                        parametrosDisponibles,
                        vista.Name);
            }
        }

        private void EjecutarCrearLeyendaVG(
            UIDocument uidoc,
            Document doc)
        {
            if (FiltrosVGSeleccionados == null ||
                FiltrosVGSeleccionados.Count == 0)
            {
                throw new InvalidOperationException(
                    "No se seleccionó ningún filtro para crear la leyenda.");
            }

            if (vistaFiltrosVGId == null ||
                vistaFiltrosVGId ==
                    ElementId.InvalidElementId)
            {
                throw new InvalidOperationException(
                    "Vuelve a pulsar LEYENDA VG para leer la vista activa.");
            }

            View vistaOrigen =
                doc.GetElement(
                    vistaFiltrosVGId)
                    as View;

            if (vistaOrigen == null ||
                !vistaOrigen.IsValidObject)
            {
                throw new InvalidOperationException(
                    "La vista de origen ya no está disponible.");
            }

            //-------------------------------------------------
            // COLUMNAS SELECCIONADAS
            //-------------------------------------------------
            List<ColorearParametro28.ParametroDisponible>
                columnas =
                    ParametrosColumnasVG ??
                    new List<
                        ColorearParametro28.ParametroDisponible>();

            // Máximo 5.
            columnas =
                columnas
                    .Where(x =>
                        x != null &&
                        !string.IsNullOrWhiteSpace(
                            x.Clave))
                    .GroupBy(
                        x => x.Clave,
                        StringComparer.OrdinalIgnoreCase)
                    .Select(x =>
                        x.First())
                    .Take(5)
                    .ToList();

            //-------------------------------------------------
            // FILTROS EN EL ORDEN DE LA VISTA
            //-------------------------------------------------
            List<ElementId> filtrosEnVista =
                ObtenerFiltrosOrdenadosVista(
                    vistaOrigen);

            HashSet<long> seleccionados =
                new HashSet<long>(
                    FiltrosVGSeleccionados);

            List<ItemLeyendaVG> items =
                new List<ItemLeyendaVG>();

            foreach (ElementId filtroId
                in filtrosEnVista)
            {
                if (filtroId == null ||
                    !seleccionados.Contains(
                        filtroId.Value))
                {
                    continue;
                }

                Element filtro =
                    doc.GetElement(
                        filtroId);

                if (filtro == null ||
                    !filtro.IsValidObject)
                {
                    continue;
                }

                //-------------------------------------------------
                // COLOR
                //-------------------------------------------------
                OverrideGraphicSettings ogs = null;

                try
                {
                    ogs =
                        vistaOrigen
                            .GetFilterOverrides(
                                filtroId);
                }
                catch
                {
                    ogs = null;
                }

                Autodesk.Revit.DB.Color color =
                    ObtenerColorRepresentativoFiltroVG(
                        ogs);

                //-------------------------------------------------
                // NOMBRE MOSTRADO
                //-------------------------------------------------
                string nombre =
                    filtro.Name ?? "";

                if (LimpiarNombresFiltrosMYG)
                {
                    nombre =
                        LimpiarNombreFiltroParaLeyendaVG(
                            vistaOrigen,
                            nombre);
                }

                //-------------------------------------------------
                // ELEMENTOS QUE CUMPLEN EL FILTRO
                //-------------------------------------------------
                List<Element> elementosHost =
                    ObtenerElementosHostQueCumplenFiltroVG(
                        doc,
                        vistaOrigen,
                        filtro);

                List<ElementoVinculadoAnalizable>
                    elementosVinculados =
                        ObtenerElementosVinculadosQueCumplenFiltroVG(
                            doc,
                            vistaOrigen,
                            filtro);

                ItemLeyendaVG item =
                    new ItemLeyendaVG()
                    {
                        Nombre =
                            nombre,

                        Rojo =
                            color != null
                                ? color.Red
                                : 128,

                        Verde =
                            color != null
                                ? color.Green
                                : 128,

                        Azul =
                            color != null
                                ? color.Blue
                                : 128
                    };

                //-------------------------------------------------
                // LEER CADA PARÁMETRO ADICIONAL
                //-------------------------------------------------
                foreach (
                    ColorearParametro28.ParametroDisponible
                    columna
                    in columnas)
                {
                    string valor =
                        ObtenerValoresParametroColumnaVG(
                            elementosHost,
                            elementosVinculados,
                            columna);

                    item.ValoresColumnas.Add(
                        valor);
                }

                items.Add(
                    item);
            }

            if (items.Count == 0)
            {
                throw new InvalidOperationException(
                    "Los filtros seleccionados ya no están aplicados a la vista.");
            }

            //-------------------------------------------------
            // CREAR TABLA MULTICOLUMNA
            //-------------------------------------------------
            CrearVistaLeyendaVGMulticolumna(
                uidoc,
                doc,
                vistaOrigen,
                items,
                columnas);

            if (FormInicial != null)
            {
                FormInicial.NotificarLeyendaCreada(
                    "LEYENDA VG - " +
                    vistaOrigen.Name);
            }
        }

        //-----------------------------------------------------
        // ELEMENTOS HOST QUE CUMPLEN UN FILTRO
        //-----------------------------------------------------
        private List<Element>
            ObtenerElementosHostQueCumplenFiltroVG(
                Document doc,
                View vista,
                Element filtroElemento)
        {
            List<Element> resultado =
                new List<Element>();

            if (doc == null ||
                vista == null ||
                filtroElemento == null)
            {
                return resultado;
            }

            ParameterFilterElement filtro =
                filtroElemento
                    as ParameterFilterElement;

            if (filtro == null)
            {
                return resultado;
            }

            HashSet<long> categorias =
                new HashSet<long>();

            try
            {
                foreach (ElementId categoriaId
                    in filtro.GetCategories())
                {
                    if (categoriaId != null)
                    {
                        categorias.Add(
                            categoriaId.Value);
                    }
                }
            }
            catch
            {
            }

            try
            {
                FilteredElementCollector collector =
                    new FilteredElementCollector(
                        doc,
                        vista.Id)
                        .WhereElementIsNotElementType();

                ElementFilter reglas =
                    filtro.GetElementFilter();

                if (reglas != null)
                {
                    collector =
                        collector.WherePasses(
                            reglas);
                }

                foreach (Element e
                    in collector)
                {
                    if (e == null ||
                        !e.IsValidObject ||
                        e is RevitLinkInstance ||
                        e is ImportInstance ||
                        e.Category == null)
                    {
                        continue;
                    }

                    if (categorias.Count > 0 &&
                        !categorias.Contains(
                            e.Category.Id.Value))
                    {
                        continue;
                    }

                    resultado.Add(
                        e);
                }
            }
            catch
            {
            }

            return resultado;
        }

        //-----------------------------------------------------
        // ELEMENTOS DE VÍNCULO QUE CUMPLEN UN FILTRO
        //-----------------------------------------------------
        private List<ElementoVinculadoAnalizable>
            ObtenerElementosVinculadosQueCumplenFiltroVG(
                Document doc,
                View vista,
                Element filtroElemento)
        {
            List<ElementoVinculadoAnalizable> resultado =
                new List<ElementoVinculadoAnalizable>();

            if (doc == null ||
                vista == null ||
                filtroElemento == null)
            {
                return resultado;
            }

            ParameterFilterElement filtro =
                filtroElemento
                    as ParameterFilterElement;

            if (filtro == null)
            {
                return resultado;
            }

            HashSet<long> categorias =
                new HashSet<long>();

            try
            {
                foreach (ElementId categoriaId
                    in filtro.GetCategories())
                {
                    if (categoriaId != null)
                    {
                        categorias.Add(
                            categoriaId.Value);
                    }
                }
            }
            catch
            {
            }

            List<RevitLinkInstance> vinculos =
                new FilteredElementCollector(
                    doc,
                    vista.Id)
                    .OfClass(
                        typeof(RevitLinkInstance))
                    .Cast<RevitLinkInstance>()
                    .Where(x =>
                        x != null &&
                        x.IsValidObject)
                    .ToList();

            foreach (RevitLinkInstance vinculo
                in vinculos)
            {
                Document linkDoc = null;

                try
                {
                    linkDoc =
                        vinculo.GetLinkDocument();
                }
                catch
                {
                    linkDoc = null;
                }

                if (linkDoc == null ||
                    !linkDoc.IsValidObject)
                {
                    continue;
                }

                try
                {
                    FilteredElementCollector collector =
                        new FilteredElementCollector(
                            doc,
                            vista.Id,
                            vinculo.Id)
                            .WhereElementIsNotElementType();

                    ElementFilter reglas =
                        filtro.GetElementFilter();

                    if (reglas != null)
                    {
                        try
                        {
                            collector =
                                collector.WherePasses(
                                    reglas);
                        }
                        catch
                        {
                            // Si Revit no puede aplicar las reglas
                            // del host dentro de ese vínculo,
                            // no se inventan coincidencias.
                            continue;
                        }
                    }

                    foreach (Element e
                        in collector)
                    {
                        if (e == null ||
                            !e.IsValidObject ||
                            e.Category == null)
                        {
                            continue;
                        }

                        if (categorias.Count > 0 &&
                            !categorias.Contains(
                                e.Category.Id.Value))
                        {
                            continue;
                        }

                        resultado.Add(
                            new ElementoVinculadoAnalizable()
                            {
                                DocumentoVinculado =
                                    linkDoc,

                                Elemento =
                                    e,

                                VinculoInstanciaId =
                                    vinculo.Id
                            });
                    }
                }
                catch
                {
                }
            }

            return resultado;
        }

        //-----------------------------------------------------
        // VALORES ÚNICOS DE UN PARÁMETRO PARA UNA FILA
        //-----------------------------------------------------
        private string ObtenerValoresParametroColumnaVG(
            List<Element> elementosHost,
            List<ElementoVinculadoAnalizable> elementosVinculados,
            ColorearParametro28.ParametroDisponible descriptor)
        {
            if (descriptor == null)
                return "";

            HashSet<string> valores =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            bool tieneSinValor = false;

            //-------------------------------------------------
            // HOST
            //-------------------------------------------------
            if (elementosHost != null)
            {
                foreach (Element e
                    in elementosHost)
                {
                    if (e == null)
                        continue;

                    Document docElemento =
                        e.Document;

                    Element propietario =
                        ObtenerPropietarioParametro(
                            docElemento,
                            e,
                            descriptor);

                    Parameter p =
                        BuscarParametroPorClave(
                            propietario,
                            descriptor.Clave,
                            descriptor.EsTipo);

                    if (p == null)
                    {
                        tieneSinValor = true;
                        continue;
                    }

                    string valor =
                        ObtenerValorParametro(
                            docElemento,
                            p);

                    if (string.IsNullOrWhiteSpace(
                        valor))
                    {
                        tieneSinValor = true;
                    }
                    else
                    {
                        valores.Add(
                            valor.Trim());
                    }
                }
            }

            //-------------------------------------------------
            // VÍNCULOS
            //-------------------------------------------------
            if (elementosVinculados != null)
            {
                foreach (
                    ElementoVinculadoAnalizable info
                    in elementosVinculados)
                {
                    if (info == null ||
                        info.DocumentoVinculado == null ||
                        info.Elemento == null)
                    {
                        continue;
                    }

                    Element propietario =
                        ObtenerPropietarioParametro(
                            info.DocumentoVinculado,
                            info.Elemento,
                            descriptor);

                    Parameter p =
                        BuscarParametroPorClave(
                            propietario,
                            descriptor.Clave,
                            descriptor.EsTipo);

                    if (p == null)
                    {
                        tieneSinValor = true;
                        continue;
                    }

                    string valor =
                        ObtenerValorParametro(
                            info.DocumentoVinculado,
                            p);

                    if (string.IsNullOrWhiteSpace(
                        valor))
                    {
                        tieneSinValor = true;
                    }
                    else
                    {
                        valores.Add(
                            valor.Trim());
                    }
                }
            }

            List<string> ordenados =
                valores
                    .OrderBy(
                        x => x,
                        StringComparer.OrdinalIgnoreCase)
                    .ToList();

            if (tieneSinValor)
            {
                ordenados.Add(
                    "(Sin valor)");
            }

            if (ordenados.Count == 0)
            {
                return "(Sin valor)";
            }

            return string.Join(
                " | ",
                ordenados);
        }

        //-----------------------------------------------------
        // ELEMENTOS VISIBLES GENÉRICOS PARA LISTA DE PARÁMETROS
        //-----------------------------------------------------
        private List<Element>
            ObtenerElementosAnalizablesVistaGenerica(
                Document doc,
                View vista)
        {
            List<Element> resultado =
                new List<Element>();

            if (doc == null ||
                vista == null)
            {
                return resultado;
            }

            try
            {
                FilteredElementCollector collector =
                    new FilteredElementCollector(
                        doc,
                        vista.Id)
                        .WhereElementIsNotElementType();

                foreach (Element e
                    in collector)
                {
                    if (e == null ||
                        !e.IsValidObject ||
                        e.ViewSpecific ||
                        e is RevitLinkInstance ||
                        e is ImportInstance ||
                        e.Category == null)
                    {
                        continue;
                    }

                    if (e.Category.CategoryType !=
                        CategoryType.Model)
                    {
                        continue;
                    }

                    resultado.Add(
                        e);
                }
            }
            catch
            {
            }

            return resultado;
        }

        private List<ElementoVinculadoAnalizable>
            ObtenerElementosVinculadosVistaGenerica(
                Document doc,
                View vista)
        {
            List<ElementoVinculadoAnalizable> resultado =
                new List<ElementoVinculadoAnalizable>();

            if (doc == null ||
                vista == null)
            {
                return resultado;
            }

            List<RevitLinkInstance> vinculos =
                new List<RevitLinkInstance>();

            try
            {
                vinculos =
                    new FilteredElementCollector(
                        doc,
                        vista.Id)
                        .OfClass(
                            typeof(RevitLinkInstance))
                        .Cast<RevitLinkInstance>()
                        .Where(x =>
                            x != null &&
                            x.IsValidObject)
                        .ToList();
            }
            catch
            {
            }

            foreach (RevitLinkInstance vinculo
                in vinculos)
            {
                Document linkDoc = null;

                try
                {
                    linkDoc =
                        vinculo.GetLinkDocument();
                }
                catch
                {
                    linkDoc = null;
                }

                if (linkDoc == null ||
                    !linkDoc.IsValidObject)
                {
                    continue;
                }

                try
                {
                    FilteredElementCollector collector =
                        new FilteredElementCollector(
                            doc,
                            vista.Id,
                            vinculo.Id)
                            .WhereElementIsNotElementType();

                    foreach (Element e
                        in collector)
                    {
                        if (e == null ||
                            !e.IsValidObject ||
                            e.ViewSpecific ||
                            e.Category == null)
                        {
                            continue;
                        }

                        if (e.Category.CategoryType !=
                            CategoryType.Model)
                        {
                            continue;
                        }

                        resultado.Add(
                            new ElementoVinculadoAnalizable()
                            {
                                DocumentoVinculado =
                                    linkDoc,

                                Elemento =
                                    e,

                                VinculoInstanciaId =
                                    vinculo.Id
                            });
                    }
                }
                catch
                {
                }
            }

            return resultado;
        }

        //-----------------------------------------------------
        // CREAR VISTA DE LEYENDA MULTICOLUMNA
        //-----------------------------------------------------
        private void CrearVistaLeyendaVGMulticolumna(
            UIDocument uidoc,
            Document doc,
            View vistaOrigen,
            List<ItemLeyendaVG> items,
            List<ColorearParametro28.ParametroDisponible> columnas)
        {
            if (uidoc == null ||
                doc == null ||
                vistaOrigen == null ||
                items == null ||
                items.Count == 0)
            {
                return;
            }

            ViewFamilyType tipoVistaDibujo =
                new FilteredElementCollector(
                    doc)
                    .OfClass(
                        typeof(ViewFamilyType))
                    .Cast<ViewFamilyType>()
                    .FirstOrDefault(x =>
                        x != null &&
                        x.ViewFamily ==
                            ViewFamily.Drafting);

            if (tipoVistaDibujo == null)
            {
                throw new InvalidOperationException(
                    "No se encontró un tipo de Vista de dibujo.");
            }

            FilledRegionType tipoRegionBase =
                new FilteredElementCollector(
                    doc)
                    .OfClass(
                        typeof(FilledRegionType))
                    .Cast<FilledRegionType>()
                    .FirstOrDefault();

            if (tipoRegionBase == null)
            {
                throw new InvalidOperationException(
                    "No se encontró ningún tipo de Región rellenada.");
            }

            ElementId patronSolidoId =
                ObtenerPatronSolido(
                    doc);

            if (patronSolidoId ==
                ElementId.InvalidElementId)
            {
                throw new InvalidOperationException(
                    "No se encontró el patrón de relleno sólido.");
            }

            TextNoteType tipoTextoBase =
                null;

            ElementId tipoTextoBaseId =
                doc.GetDefaultElementTypeId(
                    ElementTypeGroup.TextNoteType);

            if (tipoTextoBaseId != null &&
                tipoTextoBaseId !=
                    ElementId.InvalidElementId)
            {
                tipoTextoBase =
                    doc.GetElement(
                        tipoTextoBaseId)
                        as TextNoteType;
            }

            if (tipoTextoBase == null)
            {
                tipoTextoBase =
                    new FilteredElementCollector(
                        doc)
                        .OfClass(
                            typeof(TextNoteType))
                        .Cast<TextNoteType>()
                        .FirstOrDefault();
            }

            if (tipoTextoBase == null)
            {
                throw new InvalidOperationException(
                    "No se encontró un tipo de texto válido.");
            }

            ViewDrafting vistaLeyenda = null;

            string nombreVistaFinal = "";

            using (Transaction tx =
                new Transaction(
                    doc,
                    "MYG - Crear leyenda VG multicolumna"))
            {
                tx.Start();

                vistaLeyenda =
                    ViewDrafting.Create(
                        doc,
                        tipoVistaDibujo.Id);

                if (vistaLeyenda == null)
                {
                    throw new InvalidOperationException(
                        "Revit no pudo crear la vista de leyenda.");
                }

                nombreVistaFinal =
                    CrearNombreVistaUnico(
                        doc,
                        "LEYENDA VG - " +
                        vistaOrigen.Name);

                vistaLeyenda.Name =
                    nombreVistaFinal;

                try
                {
                    vistaLeyenda.Scale = 1;
                }
                catch
                {
                }

                //-------------------------------------------------
                // TIPOS DE TEXTO
                //-------------------------------------------------
                TextNoteType tipoTextoTitulo =
                    ObtenerOCrearTipoTextoLeyenda(
                        doc,
                        tipoTextoBase,
                        "MYG_FVP_ArialNarrow_3mm",
                        "Arial Narrow",
                        3.0,
                        true,
                        0,
                        0,
                        64);

                TextNoteType tipoTextoContenido =
                    ObtenerOCrearTipoTextoLeyenda(
                        doc,
                        tipoTextoBase,
                        "MYG_FVP_ArialNarrow_2_5mm",
                        "Arial Narrow",
                        2.5,
                        false,
                        0,
                        0,
                        0);

                //-------------------------------------------------
                // MEDIDAS
                //-------------------------------------------------
                double mm3 =
                    UnitUtils.ConvertToInternalUnits(
                        3.0,
                        UnitTypeId.Millimeters);

                double mm4 =
                    UnitUtils.ConvertToInternalUnits(
                        4.0,
                        UnitTypeId.Millimeters);

                double mm5 =
                    UnitUtils.ConvertToInternalUnits(
                        5.0,
                        UnitTypeId.Millimeters);

                double mm6_5 =
                    UnitUtils.ConvertToInternalUnits(
                        6.5,
                        UnitTypeId.Millimeters);

                double mm8 =
                    UnitUtils.ConvertToInternalUnits(
                        8.0,
                        UnitTypeId.Millimeters);

                double mm25 =
                    UnitUtils.ConvertToInternalUnits(
                        25.0,
                        UnitTypeId.Millimeters);

                double anchoMinimo =
                    UnitUtils.ConvertToInternalUnits(
                        35.0,
                        UnitTypeId.Millimeters);

                //-------------------------------------------------
                // ENCABEZADOS
                //-------------------------------------------------
                List<string> encabezados =
                    new List<string>()
                    {
                        "FILTRO"
                    };

                foreach (
                    ColorearParametro28.ParametroDisponible
                    columna
                    in columnas)
                {
                    string encabezado =
                        columna.NombreParametro ?? "";

                    if (columna.EsTipo)
                    {
                        encabezado +=
                            " (TIPO)";
                    }

                    encabezados.Add(
                        encabezado);
                }

                //-------------------------------------------------
                // ANCHOS REALES DE CADA COLUMNA DE TEXTO
                //-------------------------------------------------
                List<double> anchosTexto =
                    new List<double>();

                for (int c = 0;
                    c < encabezados.Count;
                    c++)
                {
                    List<string> valoresColumna =
                        new List<string>();

                    foreach (ItemLeyendaVG item
                        in items)
                    {
                        if (c == 0)
                        {
                            valoresColumna.Add(
                                item.Nombre ?? "");
                        }
                        else
                        {
                            int indiceValor =
                                c - 1;

                            string valor =
                                indiceValor <
                                    item.ValoresColumnas.Count
                                    ? item.ValoresColumnas[
                                        indiceValor]
                                    : "";

                            valoresColumna.Add(
                                valor ?? "");
                        }
                    }

                    double anchoReal =
                        MedirAnchoRealTextosLeyenda(
                            doc,
                            vistaLeyenda,
                            tipoTextoTitulo.Id,
                            tipoTextoContenido.Id,
                            encabezados[c]
                                .ToUpperInvariant(),
                            valoresColumna);

                    double ancho =
                        anchoReal +
                        mm3 +
                        mm4;

                    if (ancho <
                        anchoMinimo)
                    {
                        ancho =
                            anchoMinimo;
                    }

                    anchosTexto.Add(
                        ancho);
                }

                //-------------------------------------------------
                // POSICIONES X
                //-------------------------------------------------
                List<double> limitesX =
                    new List<double>();

                double xActual = 0.0;

                limitesX.Add(
                    xActual);

                // columna símbolo
                xActual +=
                    mm25;

                limitesX.Add(
                    xActual);

                foreach (double ancho
                    in anchosTexto)
                {
                    xActual +=
                        ancho;

                    limitesX.Add(
                        xActual);
                }

                double xDerecha =
                    xActual;

                //-------------------------------------------------
                // POSICIONES Y
                //-------------------------------------------------
                double yCabeceraSuperior =
                    0.0;

                double yCabeceraInferior =
                    yCabeceraSuperior -
                    mm8;

                double yContenidoSuperior =
                    yCabeceraInferior -
                    mm3;

                double yContenidoInferior =
                    yContenidoSuperior -
                    (items.Count *
                        mm6_5);

                //-------------------------------------------------
                // CABECERA GRIS CLARO
                //-------------------------------------------------
                Autodesk.Revit.DB.Color grisClaro =
                    new Autodesk.Revit.DB.Color(
                        230,
                        230,
                        230);

                for (int c = 0;
                    c < limitesX.Count - 1;
                    c++)
                {
                    CrearRegionRectangularLeyenda(
                        doc,
                        vistaLeyenda,
                        tipoRegionBase.Id,
                        patronSolidoId,
                        limitesX[c],
                        yCabeceraSuperior,
                        limitesX[c + 1],
                        yCabeceraInferior,
                        grisClaro);
                }

                //-------------------------------------------------
                // BORDE CABECERA GROSOR 4
                //-------------------------------------------------
                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        0.0,
                        yCabeceraSuperior,
                        0.0),
                    new XYZ(
                        xDerecha,
                        yCabeceraSuperior,
                        0.0),
                    4);

                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        xDerecha,
                        yCabeceraSuperior,
                        0.0),
                    new XYZ(
                        xDerecha,
                        yCabeceraInferior,
                        0.0),
                    4);

                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        xDerecha,
                        yCabeceraInferior,
                        0.0),
                    new XYZ(
                        0.0,
                        yCabeceraInferior,
                        0.0),
                    4);

                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        0.0,
                        yCabeceraInferior,
                        0.0),
                    new XYZ(
                        0.0,
                        yCabeceraSuperior,
                        0.0),
                    4);

                //-------------------------------------------------
                // DIVISIONES CABECERA GROSOR 4
                //-------------------------------------------------
                for (int c = 1;
                    c < limitesX.Count - 1;
                    c++)
                {
                    CrearLineaDetalleLeyenda(
                        doc,
                        vistaLeyenda,
                        new XYZ(
                            limitesX[c],
                            yCabeceraSuperior,
                            0.0),
                        new XYZ(
                            limitesX[c],
                            yCabeceraInferior,
                            0.0),
                        4);
                }

                //-------------------------------------------------
                // TEXTOS CABECERA
                //-------------------------------------------------
                List<string> titulos =
                    new List<string>()
                    {
                        "SÍMBOLO"
                    };

                titulos.AddRange(
                    encabezados);

                for (int c = 0;
                    c < titulos.Count;
                    c++)
                {
                    double centroX =
                        (
                            limitesX[c] +
                            limitesX[c + 1]
                        ) /
                        2.0;

                    double centroY =
                        (
                            yCabeceraSuperior +
                            yCabeceraInferior
                        ) /
                        2.0;

                    using (TextNoteOptions opciones =
                        new TextNoteOptions(
                            tipoTextoTitulo.Id))
                    {
                        opciones.HorizontalAlignment =
                            HorizontalTextAlignment.Center;

                        TextNote titulo =
                            TextNote.Create(
                                doc,
                                vistaLeyenda.Id,
                                new XYZ(
                                    centroX,
                                    centroY,
                                    0.0),
                                titulos[c]
                                    .ToUpperInvariant(),
                                opciones);

                        if (titulo != null)
                        {
                            AplicarColorTextoLeyenda(
                                vistaLeyenda,
                                titulo.Id,
                                0,
                                0,
                                64);

                            AplicarNegritaTextNote(
                                titulo);

                            CentrarTextoVerticalmenteLeyenda(
                                doc,
                                vistaLeyenda,
                                titulo,
                                centroY);
                        }
                    }
                }

                //-------------------------------------------------
                // CONTENIDO - BORDE EXTERIOR 4
                //-------------------------------------------------
                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        0.0,
                        yContenidoSuperior,
                        0.0),
                    new XYZ(
                        xDerecha,
                        yContenidoSuperior,
                        0.0),
                    4);

                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        xDerecha,
                        yContenidoSuperior,
                        0.0),
                    new XYZ(
                        xDerecha,
                        yContenidoInferior,
                        0.0),
                    4);

                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        xDerecha,
                        yContenidoInferior,
                        0.0),
                    new XYZ(
                        0.0,
                        yContenidoInferior,
                        0.0),
                    4);

                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        0.0,
                        yContenidoInferior,
                        0.0),
                    new XYZ(
                        0.0,
                        yContenidoSuperior,
                        0.0),
                    4);

                //-------------------------------------------------
                // DIVISIONES VERTICALES INTERNAS GROSOR 1
                //-------------------------------------------------
                for (int c = 1;
                    c < limitesX.Count - 1;
                    c++)
                {
                    CrearLineaDetalleLeyenda(
                        doc,
                        vistaLeyenda,
                        new XYZ(
                            limitesX[c],
                            yContenidoSuperior,
                            0.0),
                        new XYZ(
                            limitesX[c],
                            yContenidoInferior,
                            0.0),
                        1);
                }

                //-------------------------------------------------
                // FILAS
                //-------------------------------------------------
                for (int i = 0;
                    i < items.Count;
                    i++)
                {
                    ItemLeyendaVG item =
                        items[i];

                    double yFilaSuperior =
                        yContenidoSuperior -
                        (i *
                            mm6_5);

                    double yFilaInferior =
                        yFilaSuperior -
                        mm6_5;

                    double centroY =
                        (
                            yFilaSuperior +
                            yFilaInferior
                        ) /
                        2.0;

                    //-------------------------------------------------
                    // SEPARADOR DE FILA
                    //-------------------------------------------------
                    if (i <
                        items.Count - 1)
                    {
                        CrearLineaDetalleLeyenda(
                            doc,
                            vistaLeyenda,
                            new XYZ(
                                0.0,
                                yFilaInferior,
                                0.0),
                            new XYZ(
                                xDerecha,
                                yFilaInferior,
                                0.0),
                            1);
                    }

                    //-------------------------------------------------
                    // SÍMBOLO 5 x 5 mm
                    //-------------------------------------------------
                    double centroXSimbolo =
                        (
                            limitesX[0] +
                            limitesX[1]
                        ) /
                        2.0;

                    double x1 =
                        centroXSimbolo -
                        (mm5 / 2.0);

                    double x2 =
                        centroXSimbolo +
                        (mm5 / 2.0);

                    double y1 =
                        centroY +
                        (mm5 / 2.0);

                    double y2 =
                        centroY -
                        (mm5 / 2.0);

                    CurveLoop borde =
                        new CurveLoop();

                    XYZ p1 =
                        new XYZ(
                            x1,
                            y1,
                            0.0);

                    XYZ p2 =
                        new XYZ(
                            x2,
                            y1,
                            0.0);

                    XYZ p3 =
                        new XYZ(
                            x2,
                            y2,
                            0.0);

                    XYZ p4 =
                        new XYZ(
                            x1,
                            y2,
                            0.0);

                    borde.Append(
                        Line.CreateBound(
                            p1,
                            p2));

                    borde.Append(
                        Line.CreateBound(
                            p2,
                            p3));

                    borde.Append(
                        Line.CreateBound(
                            p3,
                            p4));

                    borde.Append(
                        Line.CreateBound(
                            p4,
                            p1));

                    IList<CurveLoop> contornos =
                        new List<CurveLoop>()
                        {
                            borde
                        };

                    Autodesk.Revit.DB.Color color =
                        new Autodesk.Revit.DB.Color(
                            Convert.ToByte(
                                LimitarRgb(
                                    item.Rojo)),
                            Convert.ToByte(
                                LimitarRgb(
                                    item.Verde)),
                            Convert.ToByte(
                                LimitarRgb(
                                    item.Azul)));

                    //-------------------------------------------------
                    // TIPO NATIVO POR RGB
                    //
                    // El color queda guardado en FilledRegionType.
                    // Si duplicas o copias la leyenda, ya no depende
                    // del override gráfico de la vista.
                    //-------------------------------------------------
                    FilledRegionType tipoRegionColor =
                        ObtenerOCrearTipoRegionRellenadaLeyenda(
                            doc,
                            tipoRegionBase,
                            patronSolidoId,
                            color);

                    if (tipoRegionColor == null)
                    {
                        throw new InvalidOperationException(
                            "No se pudo crear el tipo de región rellenada para RGB " +
                            color.Red.ToString(CI) + "," +
                            color.Green.ToString(CI) + "," +
                            color.Blue.ToString(CI) + ".");
                    }

                    FilledRegion region =
                        FilledRegion.Create(
                            doc,
                            tipoRegionColor.Id,
                            vistaLeyenda.Id,
                            contornos);

                    //-------------------------------------------------
                    // VALORES DE TEXTO
                    //-------------------------------------------------
                    List<string> valoresFila =
                        new List<string>()
                        {
                            item.Nombre ?? ""
                        };

                    valoresFila.AddRange(
                        item.ValoresColumnas);

                    for (int c = 0;
                        c < valoresFila.Count;
                        c++)
                    {
                        int indiceColumnaTabla =
                            c + 1;

                        if (indiceColumnaTabla >=
                            limitesX.Count - 0)
                        {
                            break;
                        }

                        double xTexto =
                            limitesX[
                                indiceColumnaTabla] +
                            mm3;

                        using (TextNoteOptions opciones =
                            new TextNoteOptions(
                                tipoTextoContenido.Id))
                        {
                            opciones.HorizontalAlignment =
                                HorizontalTextAlignment.Left;

                            TextNote texto =
                                TextNote.Create(
                                    doc,
                                    vistaLeyenda.Id,
                                    new XYZ(
                                        xTexto,
                                        centroY,
                                        0.0),
                                    valoresFila[c] ?? "",
                                    opciones);

                            if (texto != null)
                            {
                                CentrarTextoVerticalmenteLeyenda(
                                    doc,
                                    vistaLeyenda,
                                    texto,
                                    centroY);
                            }
                        }
                    }
                }

                doc.Regenerate();
                tx.Commit();
            }

            if (vistaLeyenda == null ||
                !vistaLeyenda.IsValidObject)
            {
                throw new InvalidOperationException(
                    "La leyenda fue creada, pero no pudo recuperarse.");
            }

            uidoc.ActiveView =
                vistaLeyenda;
        }

        private List<ElementId>
            ObtenerFiltrosOrdenadosVista(
                View vista)
        {
            List<ElementId> resultado =
                new List<ElementId>();

            if (vista == null)
                return resultado;

            //-------------------------------------------------
            // Revit moderno dispone de GetOrderedFilters().
            // Se usa reflexión para mantener compatibilidad.
            //-------------------------------------------------
            try
            {
                System.Reflection.MethodInfo metodo =
                    typeof(View)
                        .GetMethod(
                            "GetOrderedFilters",
                            System.Type.EmptyTypes);

                if (metodo != null)
                {
                    object valor =
                        metodo.Invoke(
                            vista,
                            null);

                    System.Collections.Generic.IEnumerable<ElementId>
                        idsOrdenados =
                            valor as
                            System.Collections.Generic.IEnumerable<ElementId>;

                    if (idsOrdenados != null)
                    {
                        resultado.AddRange(
                            idsOrdenados);

                        return resultado;
                    }
                }
            }
            catch
            {
            }

            try
            {
                ICollection<ElementId> ids =
                    vista.GetFilters();

                if (ids != null)
                {
                    resultado.AddRange(
                        ids);
                }
            }
            catch
            {
            }

            return resultado;
        }

        private Autodesk.Revit.DB.Color
            ObtenerColorRepresentativoFiltroVG(
                OverrideGraphicSettings ogs)
        {
            if (ogs == null)
            {
                return new Autodesk.Revit.DB.Color(
                    128,
                    128,
                    128);
            }

            //-------------------------------------------------
            // PRIORIDAD:
            // 1 Superficie primer plano
            // 2 Superficie fondo
            // 3 Corte primer plano
            // 4 Corte fondo
            // 5 Línea proyección
            // 6 Línea corte
            //-------------------------------------------------
            string[] propiedadesColor =
            {
                "SurfaceForegroundPatternColor",
                "SurfaceBackgroundPatternColor",
                "CutForegroundPatternColor",
                "CutBackgroundPatternColor",
                "ProjectionLineColor",
                "CutLineColor"
            };

            foreach (string nombrePropiedad
                in propiedadesColor)
            {
                try
                {
                    System.Reflection.PropertyInfo propiedad =
                        typeof(OverrideGraphicSettings)
                            .GetProperty(
                                nombrePropiedad,
                                System.Reflection.BindingFlags
                                    .Public |
                                System.Reflection.BindingFlags
                                    .Instance);

                    if (propiedad == null)
                        continue;

                    Autodesk.Revit.DB.Color color =
                        propiedad.GetValue(
                            ogs,
                            null)
                            as Autodesk.Revit.DB.Color;

                    if (EsColorRevitValido(
                        color))
                    {
                        return color;
                    }
                }
                catch
                {
                }
            }

            return new Autodesk.Revit.DB.Color(
                128,
                128,
                128);
        }

        private bool EsColorRevitValido(
            Autodesk.Revit.DB.Color color)
        {
            if (color == null)
                return false;

            try
            {
                System.Reflection.PropertyInfo propiedad =
                    typeof(Autodesk.Revit.DB.Color)
                        .GetProperty(
                            "IsValid",
                            System.Reflection.BindingFlags
                                .Public |
                            System.Reflection.BindingFlags
                                .Instance);

                if (propiedad != null)
                {
                    object valor =
                        propiedad.GetValue(
                            color,
                            null);

                    if (valor is bool)
                    {
                        return (bool)valor;
                    }
                }
            }
            catch
            {
            }

            try
            {
                // Si se pueden leer los canales, el objeto se considera válido.
                byte r = color.Red;
                byte g = color.Green;
                byte b = color.Blue;

                return true;
            }
            catch
            {
                return false;
            }
        }

        private string LimpiarNombreFiltroParaLeyendaVG(
            View vista,
            string nombreFiltro)
        {
            if (string.IsNullOrWhiteSpace(
                nombreFiltro))
            {
                return "";
            }

            string resultado =
                nombreFiltro.Trim();

            //-------------------------------------------------
            // FILTROS PERMANENTES CREADOS POR MYG:
            // MYG_FVP_<NombreVista>_<Valor>
            //-------------------------------------------------
            const string prefijoPermanente =
                "MYG_FVP_";

            if (resultado.StartsWith(
                prefijoPermanente,
                StringComparison.OrdinalIgnoreCase))
            {
                resultado =
                    resultado.Substring(
                        prefijoPermanente.Length);

                if (vista != null)
                {
                    string nombreVistaLimpio =
                        LimpiarNombreFiltro(
                            vista.Name);

                    string prefijoVista =
                        nombreVistaLimpio +
                        "_";

                    if (resultado.StartsWith(
                        prefijoVista,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        resultado =
                            resultado.Substring(
                                prefijoVista.Length);
                    }
                }
            }

            //-------------------------------------------------
            // TEMPORALES MYG:
            // quitar solo el prefijo general para no inventar
            // dónde termina parámetro y dónde comienza valor.
            //-------------------------------------------------
            const string prefijoTemporal =
                "MYG_TMP_FVP_";

            if (resultado.StartsWith(
                prefijoTemporal,
                StringComparison.OrdinalIgnoreCase))
            {
                resultado =
                    resultado.Substring(
                        prefijoTemporal.Length);
            }

            return
                string.IsNullOrWhiteSpace(
                    resultado)
                    ? nombreFiltro.Trim()
                    : resultado.Trim();
        }

        private void EjecutarCrearLeyenda(
            UIDocument uidoc,
            Document doc)
        {
            if (ParametroSeleccionado == null ||
                string.IsNullOrWhiteSpace(
                    ParametroSeleccionado.NombreParametro))
            {
                throw new InvalidOperationException(
                    "No hay un parámetro seleccionado para crear la leyenda.");
            }

            string tituloColumnaLeyenda =
                string.IsNullOrWhiteSpace(
                    tituloColumnaLeyendaPersonalizado)
                    ? ParametroSeleccionado
                        .NombreParametro
                    : tituloColumnaLeyendaPersonalizado;

            string nombreBaseVistaLeyenda =
                string.IsNullOrWhiteSpace(
                    nombreBaseVistaLeyendaPersonalizado)
                    ? "LEYENDA FVP - " +
                        ParametroSeleccionado
                            .NombreParametro
                    : nombreBaseVistaLeyendaPersonalizado;

            if (gruposActuales == null ||
                gruposActuales.Count == 0)
            {
                throw new InvalidOperationException(
                    "Primero crea los filtros para disponer de los valores de la leyenda.");
            }

            if (coloresPorValorActuales == null ||
                coloresPorValorActuales.Count == 0)
            {
                throw new InvalidOperationException(
                    "No hay colores disponibles. Primero crea los filtros.");
            }

            ViewFamilyType tipoVistaDibujo =
                new FilteredElementCollector(doc)
                    .OfClass(typeof(ViewFamilyType))
                    .Cast<ViewFamilyType>()
                    .FirstOrDefault(x =>
                        x != null &&
                        x.ViewFamily ==
                            ViewFamily.Drafting);

            if (tipoVistaDibujo == null)
            {
                throw new InvalidOperationException(
                    "No se encontró un tipo de Vista de dibujo en el proyecto.");
            }

            FilledRegionType tipoRegionBase =
                new FilteredElementCollector(doc)
                    .OfClass(typeof(FilledRegionType))
                    .Cast<FilledRegionType>()
                    .FirstOrDefault();

            if (tipoRegionBase == null)
            {
                throw new InvalidOperationException(
                    "No se encontró ningún tipo de Región rellenada en el proyecto.");
            }

            ElementId patronSolidoId =
                ObtenerPatronSolido(doc);

            if (patronSolidoId ==
                ElementId.InvalidElementId)
            {
                throw new InvalidOperationException(
                    "No se encontró el patrón de relleno sólido.");
            }

            TextNoteType tipoTextoBase =
                null;

            ElementId tipoTextoBaseId =
                doc.GetDefaultElementTypeId(
                    ElementTypeGroup.TextNoteType);

            if (tipoTextoBaseId != null &&
                tipoTextoBaseId !=
                    ElementId.InvalidElementId)
            {
                tipoTextoBase =
                    doc.GetElement(
                        tipoTextoBaseId)
                        as TextNoteType;
            }

            if (tipoTextoBase == null)
            {
                tipoTextoBase =
                    new FilteredElementCollector(doc)
                        .OfClass(typeof(TextNoteType))
                        .Cast<TextNoteType>()
                        .FirstOrDefault();
            }

            if (tipoTextoBase == null)
            {
                throw new InvalidOperationException(
                    "No se encontró un tipo de texto válido.");
            }

            List<string> valores =
                gruposActuales.Keys
                    .Where(x =>
                        !string.IsNullOrWhiteSpace(x))
                    .OrderBy(x =>
                        x,
                        StringComparer.OrdinalIgnoreCase)
                    .ToList();

            if (valores.Count == 0)
            {
                throw new InvalidOperationException(
                    "No existen valores para dibujar en la leyenda.");
            }

            ViewDrafting vistaLeyenda = null;
            string nombreVistaLeyenda = "";

            using (Transaction tx =
                new Transaction(
                    doc,
                    "MYG - Crear tabla de leyenda de filtros"))
            {
                tx.Start();

                //-------------------------------------------------
                // CREAR VISTA DE DIBUJO
                //-------------------------------------------------
                vistaLeyenda =
                    ViewDrafting.Create(
                        doc,
                        tipoVistaDibujo.Id);

                if (vistaLeyenda == null)
                {
                    throw new InvalidOperationException(
                        "Revit no pudo crear la vista de leyenda.");
                }

                nombreVistaLeyenda =
                    CrearNombreVistaUnico(
                        doc,
                        nombreBaseVistaLeyenda);

                vistaLeyenda.Name =
                    nombreVistaLeyenda;

                try
                {
                    vistaLeyenda.Scale = 1;
                }
                catch
                {
                }

                //-------------------------------------------------
                // TIPOS DE TEXTO
                //-------------------------------------------------
                TextNoteType tipoTextoTitulo =
                    ObtenerOCrearTipoTextoLeyenda(
                        doc,
                        tipoTextoBase,
                        "MYG_FVP_ArialNarrow_3mm",
                        "Arial Narrow",
                        3.0,
                        true,
                        0,
                        0,
                        64);

                TextNoteType tipoTextoContenido =
                    ObtenerOCrearTipoTextoLeyenda(
                        doc,
                        tipoTextoBase,
                        "MYG_FVP_ArialNarrow_2_5mm",
                        "Arial Narrow",
                        2.5,
                        false,
                        0,
                        0,
                        0);

                //-------------------------------------------------
                // MEDIDAS
                //-------------------------------------------------
                double mm2_5 =
                    UnitUtils.ConvertToInternalUnits(
                        2.5,
                        UnitTypeId.Millimeters);

                double mm3 =
                    UnitUtils.ConvertToInternalUnits(
                        3.0,
                        UnitTypeId.Millimeters);

                double mm4 =
                    UnitUtils.ConvertToInternalUnits(
                        4.0,
                        UnitTypeId.Millimeters);

                double mm5 =
                    UnitUtils.ConvertToInternalUnits(
                        5.0,
                        UnitTypeId.Millimeters);

                double mm6_5 =
                    UnitUtils.ConvertToInternalUnits(
                        6.5,
                        UnitTypeId.Millimeters);

                double mm8 =
                    UnitUtils.ConvertToInternalUnits(
                        8.0,
                        UnitTypeId.Millimeters);

                double mm12 =
                    UnitUtils.ConvertToInternalUnits(
                        12.0,
                        UnitTypeId.Millimeters);

                double mm25 =
                    UnitUtils.ConvertToInternalUnits(
                        25.0,
                        UnitTypeId.Millimeters);

                //-------------------------------------------------
                // MEDIR EL ANCHO REAL DE LOS TEXTOS CON REVIT
                //
                // No se estima por longitud de cadena.
                // Se crean TextNotes temporales con los tipos reales,
                // se regenera la vista y se mide su BoundingBox.
                //-------------------------------------------------
                double anchoTextoMasLargo =
                    MedirAnchoRealTextosLeyenda(
                        doc,
                        vistaLeyenda,
                        tipoTextoTitulo.Id,
                        tipoTextoContenido.Id,
                        tituloColumnaLeyenda
                            .ToUpperInvariant(),
                        valores);

                //-------------------------------------------------
                // MARGEN:
                // texto empieza 3 mm después de la división,
                // y deja 4 mm libres al borde derecho.
                //-------------------------------------------------
                double anchoColumnaValores =
                    anchoTextoMasLargo +
                    mm3 +
                    mm4;

                //-------------------------------------------------
                // ANCHO MÍNIMO
                //-------------------------------------------------
                double anchoMinimo =
                    UnitUtils.ConvertToInternalUnits(
                        35.0,
                        UnitTypeId.Millimeters);

                if (anchoColumnaValores <
                    anchoMinimo)
                {
                    anchoColumnaValores =
                        anchoMinimo;
                }

                //-------------------------------------------------
                // GEOMETRÍA
                //-------------------------------------------------
                double xIzquierda = 0.0;

                double xDivision =
                    xIzquierda +
                    mm25;

                double xDerecha =
                    xDivision +
                    anchoColumnaValores;

                //-------------------------------------------------
                // CABECERA SEPARADA
                //-------------------------------------------------
                double yCabeceraSuperior = 0.0;

                //-------------------------------------------------
                // CABECERA MÁS COMPACTA: 8 mm
                //-------------------------------------------------
                double yCabeceraInferior =
                    yCabeceraSuperior -
                    mm8;

                //-------------------------------------------------
                // CONTENIDO SEPARADO 4 mm
                //-------------------------------------------------
                double yContenidoSuperior =
                    yCabeceraInferior -
                    mm3;

                //-------------------------------------------------
                // FILAS DE CONTENIDO MÁS COMPACTAS: 6.5 mm
                //-------------------------------------------------
                double alturaFilas =
                    valores.Count *
                    mm6_5;

                double yContenidoInferior =
                    yContenidoSuperior -
                    alturaFilas;

                //-------------------------------------------------
                // FONDO DE CABECERA:
                // GRIS CLARO
                //-------------------------------------------------
                Autodesk.Revit.DB.Color grisClaro =
                    new Autodesk.Revit.DB.Color(
                        230,
                        230,
                        230);

                CrearRegionRectangularLeyenda(
                    doc,
                    vistaLeyenda,
                    tipoRegionBase.Id,
                    patronSolidoId,
                    xIzquierda,
                    yCabeceraSuperior,
                    xDivision,
                    yCabeceraInferior,
                    grisClaro);

                CrearRegionRectangularLeyenda(
                    doc,
                    vistaLeyenda,
                    tipoRegionBase.Id,
                    patronSolidoId,
                    xDivision,
                    yCabeceraSuperior,
                    xDerecha,
                    yCabeceraInferior,
                    grisClaro);

                //-------------------------------------------------
                // CABECERA - GROSOR 4
                //-------------------------------------------------
                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        xIzquierda,
                        yCabeceraSuperior,
                        0.0),
                    new XYZ(
                        xDerecha,
                        yCabeceraSuperior,
                        0.0),
                    4);

                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        xDerecha,
                        yCabeceraSuperior,
                        0.0),
                    new XYZ(
                        xDerecha,
                        yCabeceraInferior,
                        0.0),
                    4);

                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        xDerecha,
                        yCabeceraInferior,
                        0.0),
                    new XYZ(
                        xIzquierda,
                        yCabeceraInferior,
                        0.0),
                    4);

                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        xIzquierda,
                        yCabeceraInferior,
                        0.0),
                    new XYZ(
                        xIzquierda,
                        yCabeceraSuperior,
                        0.0),
                    4);

                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        xDivision,
                        yCabeceraSuperior,
                        0.0),
                    new XYZ(
                        xDivision,
                        yCabeceraInferior,
                        0.0),
                    4);

                //-------------------------------------------------
                // COLOR DE TEXTO DE TÍTULOS:
                // RGB 0,0,64
                //-------------------------------------------------
                using (TextNoteOptions opcionesSimbolo =
                    new TextNoteOptions(
                        tipoTextoTitulo.Id))
                {
                    opcionesSimbolo.HorizontalAlignment =
                        HorizontalTextAlignment.Center;

                    TextNote tituloSimbolo =
                        TextNote.Create(
                            doc,
                            vistaLeyenda.Id,
                            new XYZ(
                                xIzquierda +
                                    (mm25 / 2.0),
                                (yCabeceraSuperior +
                                    yCabeceraInferior) /
                                    2.0,
                                0.0),
                            "SÍMBOLO",
                            opcionesSimbolo);

                    if (tituloSimbolo != null)
                    {
                        AplicarColorTextoLeyenda(
                            vistaLeyenda,
                            tituloSimbolo.Id,
                            0,
                            0,
                            64);

                        AplicarNegritaTextNote(
                            tituloSimbolo);

                        CentrarTextoVerticalmenteLeyenda(
                            doc,
                            vistaLeyenda,
                            tituloSimbolo,
                            (yCabeceraSuperior +
                                yCabeceraInferior) /
                                2.0);
                    }
                }

                using (TextNoteOptions opcionesParametro =
                    new TextNoteOptions(
                        tipoTextoTitulo.Id))
                {
                    opcionesParametro.HorizontalAlignment =
                        HorizontalTextAlignment.Center;

                    TextNote tituloParametro =
                        TextNote.Create(
                            doc,
                            vistaLeyenda.Id,
                            new XYZ(
                                xDivision +
                                    (anchoColumnaValores / 2.0),
                                (yCabeceraSuperior +
                                    yCabeceraInferior) /
                                    2.0,
                                0.0),
                            ParametroSeleccionado
                                .NombreParametro
                                .ToUpperInvariant(),
                            opcionesParametro);

                    if (tituloParametro != null)
                    {
                        AplicarColorTextoLeyenda(
                            vistaLeyenda,
                            tituloParametro.Id,
                            0,
                            0,
                            64);

                        AplicarNegritaTextNote(
                            tituloParametro);

                        CentrarTextoVerticalmenteLeyenda(
                            doc,
                            vistaLeyenda,
                            tituloParametro,
                            (yCabeceraSuperior +
                                yCabeceraInferior) /
                                2.0);
                    }
                }

                //-------------------------------------------------
                // CONTENIDO:
                // GROSOR 4 SOLO EN BORDES EXTERIORES
                //-------------------------------------------------
                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        xIzquierda,
                        yContenidoSuperior,
                        0.0),
                    new XYZ(
                        xDerecha,
                        yContenidoSuperior,
                        0.0),
                    4);

                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        xDerecha,
                        yContenidoSuperior,
                        0.0),
                    new XYZ(
                        xDerecha,
                        yContenidoInferior,
                        0.0),
                    4);

                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        xDerecha,
                        yContenidoInferior,
                        0.0),
                    new XYZ(
                        xIzquierda,
                        yContenidoInferior,
                        0.0),
                    4);

                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        xIzquierda,
                        yContenidoInferior,
                        0.0),
                    new XYZ(
                        xIzquierda,
                        yContenidoSuperior,
                        0.0),
                    4);

                //-------------------------------------------------
                // DIVISIÓN VERTICAL INTERNA - GROSOR 1
                //-------------------------------------------------
                CrearLineaDetalleLeyenda(
                    doc,
                    vistaLeyenda,
                    new XYZ(
                        xDivision,
                        yContenidoSuperior,
                        0.0),
                    new XYZ(
                        xDivision,
                        yContenidoInferior,
                        0.0),
                    1);

                //-------------------------------------------------
                // FILAS
                //-------------------------------------------------
                for (int indice = 0;
                    indice < valores.Count;
                    indice++)
                {
                    string valor =
                        valores[indice];

                    double yFilaSuperior =
                        yContenidoSuperior -
                        (indice * mm6_5);

                    double yFilaInferior =
                        yFilaSuperior -
                        mm6_5;

                    //-------------------------------------------------
                    // SEPARADOR HORIZONTAL - GROSOR 1
                    //-------------------------------------------------
                    if (indice <
                        valores.Count - 1)
                    {
                        CrearLineaDetalleLeyenda(
                            doc,
                            vistaLeyenda,
                            new XYZ(
                                xIzquierda,
                                yFilaInferior,
                                0.0),
                            new XYZ(
                                xDerecha,
                                yFilaInferior,
                                0.0),
                            1);
                    }

                    //-------------------------------------------------
                    // RGB DEL VALOR
                    //-------------------------------------------------
                    int[] rgb;

                    if (!coloresPorValorActuales
                        .TryGetValue(
                            valor,
                            out rgb) ||
                        rgb == null ||
                        rgb.Length < 3)
                    {
                        rgb =
                            new int[]
                            {
                                128,
                                128,
                                128
                            };
                    }

                    int rojo =
                        LimitarRgb(rgb[0]);

                    int verde =
                        LimitarRgb(rgb[1]);

                    int azul =
                        LimitarRgb(rgb[2]);

                    //-------------------------------------------------
                    // CUADRADO 5 x 5 mm
                    //-------------------------------------------------
                    double xCuadroIzq =
                        xIzquierda +
                        ((mm25 - mm5) /
                            2.0);

                    double xCuadroDer =
                        xCuadroIzq +
                        mm5;

                    double centroYFila =
                        (yFilaSuperior +
                            yFilaInferior) /
                        2.0;

                    double yCuadroSup =
                        centroYFila +
                        (mm5 / 2.0);

                    double yCuadroInf =
                        centroYFila -
                        (mm5 / 2.0);

                    CurveLoop bordeColor =
                        new CurveLoop();

                    XYZ p1 =
                        new XYZ(
                            xCuadroIzq,
                            yCuadroSup,
                            0.0);

                    XYZ p2 =
                        new XYZ(
                            xCuadroDer,
                            yCuadroSup,
                            0.0);

                    XYZ p3 =
                        new XYZ(
                            xCuadroDer,
                            yCuadroInf,
                            0.0);

                    XYZ p4 =
                        new XYZ(
                            xCuadroIzq,
                            yCuadroInf,
                            0.0);

                    bordeColor.Append(
                        Line.CreateBound(
                            p1,
                            p2));

                    bordeColor.Append(
                        Line.CreateBound(
                            p2,
                            p3));

                    bordeColor.Append(
                        Line.CreateBound(
                            p3,
                            p4));

                    bordeColor.Append(
                        Line.CreateBound(
                            p4,
                            p1));

                    IList<CurveLoop> contornos =
                        new List<CurveLoop>()
                        {
                            bordeColor
                        };

                    Autodesk.Revit.DB.Color color =
                        new Autodesk.Revit.DB.Color(
                            Convert.ToByte(rojo),
                            Convert.ToByte(verde),
                            Convert.ToByte(azul));

                    //-------------------------------------------------
                    // TIPO NATIVO POR RGB
                    //-------------------------------------------------
                    FilledRegionType tipoRegionColor =
                        ObtenerOCrearTipoRegionRellenadaLeyenda(
                            doc,
                            tipoRegionBase,
                            patronSolidoId,
                            color);

                    if (tipoRegionColor == null)
                    {
                        throw new InvalidOperationException(
                            "No se pudo crear el tipo de región rellenada para RGB " +
                            color.Red.ToString(CI) + "," +
                            color.Green.ToString(CI) + "," +
                            color.Blue.ToString(CI) + ".");
                    }

                    FilledRegion region =
                        FilledRegion.Create(
                            doc,
                            tipoRegionColor.Id,
                            vistaLeyenda.Id,
                            contornos);

                    //-------------------------------------------------
                    // TEXTO DE CONTENIDO:
                    // Arial Narrow 2.5 mm
                    //-------------------------------------------------
                    using (TextNoteOptions opcionesValor =
                        new TextNoteOptions(
                            tipoTextoContenido.Id))
                    {
                        opcionesValor.HorizontalAlignment =
                            HorizontalTextAlignment.Left;

                        TextNote textoValor =
                            TextNote.Create(
                                doc,
                                vistaLeyenda.Id,
                                new XYZ(
                                    xDivision +
                                        mm3,
                                    centroYFila,
                                    0.0),
                                valor,
                                opcionesValor);

                        if (textoValor != null)
                        {
                            CentrarTextoVerticalmenteLeyenda(
                                doc,
                                vistaLeyenda,
                                textoValor,
                                centroYFila);
                        }
                    }
                }

                doc.Regenerate();
                tx.Commit();
            }

            if (vistaLeyenda == null ||
                !vistaLeyenda.IsValidObject)
            {
                throw new InvalidOperationException(
                    "La leyenda fue creada, pero no pudo recuperarse.");
            }

            uidoc.ActiveView =
                vistaLeyenda;

            if (FormInicial != null)
            {
                FormInicial.NotificarLeyendaCreada(
                    nombreVistaLeyenda);
            }
        }

        private double MedirAnchoRealTextosLeyenda(
            Document doc,
            View vista,
            ElementId tipoTituloId,
            ElementId tipoContenidoId,
            string encabezado,
            List<string> valores)
        {
            if (doc == null ||
                vista == null)
            {
                return UnitUtils
                    .ConvertToInternalUnits(
                        35.0,
                        UnitTypeId.Millimeters);
            }

            List<ElementId> temporales =
                new List<ElementId>();

            double anchoMaximo = 0.0;

            try
            {
                //-------------------------------------------------
                // TÍTULO TEMPORAL
                //-------------------------------------------------
                using (TextNoteOptions opcionesTitulo =
                    new TextNoteOptions(
                        tipoTituloId))
                {
                    opcionesTitulo.HorizontalAlignment =
                        HorizontalTextAlignment.Left;

                    TextNote notaTitulo =
                        TextNote.Create(
                            doc,
                            vista.Id,
                            new XYZ(
                                0.0,
                                0.0,
                                0.0),
                            encabezado ?? "",
                            opcionesTitulo);

                    if (notaTitulo != null)
                    {
                        temporales.Add(
                            notaTitulo.Id);
                    }
                }

                //-------------------------------------------------
                // TEXTOS TEMPORALES DEL CONTENIDO
                //-------------------------------------------------
                if (valores != null)
                {
                    int indice = 1;

                    foreach (string valor
                        in valores)
                    {
                        using (TextNoteOptions opcionesValor =
                            new TextNoteOptions(
                                tipoContenidoId))
                        {
                            opcionesValor.HorizontalAlignment =
                                HorizontalTextAlignment.Left;

                            TextNote notaValor =
                                TextNote.Create(
                                    doc,
                                    vista.Id,
                                    new XYZ(
                                        0.0,
                                        -indice,
                                        0.0),
                                    valor ?? "",
                                    opcionesValor);

                            if (notaValor != null)
                            {
                                temporales.Add(
                                    notaValor.Id);
                            }
                        }

                        indice++;
                    }
                }

                //-------------------------------------------------
                // REGENERAR PARA QUE REVIT CALCULE EXTENSIONES
                //-------------------------------------------------
                doc.Regenerate();

                //-------------------------------------------------
                // MEDIR BOUNDING BOX REAL DE CADA TEXTNOTE
                //-------------------------------------------------
                foreach (ElementId id
                    in temporales)
                {
                    Element elemento =
                        doc.GetElement(id);

                    if (elemento == null)
                        continue;

                    BoundingBoxXYZ caja =
                        elemento.get_BoundingBox(
                            vista);

                    if (caja == null ||
                        caja.Min == null ||
                        caja.Max == null)
                    {
                        continue;
                    }

                    double ancho =
                        Math.Abs(
                            caja.Max.X -
                            caja.Min.X);

                    if (ancho >
                        anchoMaximo)
                    {
                        anchoMaximo =
                            ancho;
                    }
                }
            }
            finally
            {
                //-------------------------------------------------
                // ELIMINAR LOS TEXTOS TEMPORALES
                //-------------------------------------------------
                if (temporales.Count > 0)
                {
                    try
                    {
                        doc.Delete(
                            temporales);
                    }
                    catch
                    {
                        foreach (ElementId id
                            in temporales)
                        {
                            try
                            {
                                doc.Delete(id);
                            }
                            catch
                            {
                            }
                        }
                    }
                }
            }

            //-------------------------------------------------
            // RESPALDO SI ALGÚN TEXTNOTE NO ENTREGÓ BOUNDING BOX
            //-------------------------------------------------
            if (anchoMaximo <= 0.0)
            {
                double anchoMaximoMm =
                    35.0;

                if (valores != null)
                {
                    foreach (string valor
                        in valores)
                    {
                        double aproximado =
                            (valor ?? "").Length *
                            2.5 *
                            0.62;

                        if (aproximado >
                            anchoMaximoMm)
                        {
                            anchoMaximoMm =
                                aproximado;
                        }
                    }
                }

                anchoMaximo =
                    UnitUtils
                        .ConvertToInternalUnits(
                            anchoMaximoMm,
                            UnitTypeId.Millimeters);
            }

            return anchoMaximo;
        }

        private double CalcularAnchoColumnaValoresLeyenda(
            List<string> valores,
            string nombreParametro)
        {
            //-------------------------------------------------
            // Ancho mínimo para evitar columnas demasiado angostas
            //-------------------------------------------------
            double anchoMaximoMm =
                35.0;

            //-------------------------------------------------
            // Medir encabezado con 3 mm
            //-------------------------------------------------
            double anchoTituloMm =
                MedirTextoArialNarrowMm(
                    string.IsNullOrWhiteSpace(
                        nombreParametro)
                        ? "PARÁMETRO"
                        : nombreParametro
                            .ToUpperInvariant(),
                    3.0);

            if (anchoTituloMm >
                anchoMaximoMm)
            {
                anchoMaximoMm =
                    anchoTituloMm;
            }

            //-------------------------------------------------
            // Medir todos los valores con 2.5 mm
            //-------------------------------------------------
            if (valores != null)
            {
                foreach (string valor
                    in valores)
                {
                    double anchoValorMm =
                        MedirTextoArialNarrowMm(
                            valor ?? "",
                            2.5);

                    if (anchoValorMm >
                        anchoMaximoMm)
                    {
                        anchoMaximoMm =
                            anchoValorMm;
                    }
                }
            }

            //-------------------------------------------------
            // Margen horizontal:
            // 4 mm izquierda + 4 mm derecha
            //-------------------------------------------------
            anchoMaximoMm +=
                8.0;

            return UnitUtils
                .ConvertToInternalUnits(
                    anchoMaximoMm,
                    UnitTypeId.Millimeters);
        }

        private double MedirTextoArialNarrowMm(
            string texto,
            double tamanoMm)
        {
            if (string.IsNullOrEmpty(texto))
            {
                return 0.0;
            }

            try
            {
                //-------------------------------------------------
                // Revit usa altura de texto en unidades de papel.
                // Convertimos mm -> puntos para medir Arial Narrow.
                //-------------------------------------------------
                float tamanoPuntos =
                    (float)(
                        tamanoMm *
                        72.0 /
                        25.4);

                using (System.Drawing.Bitmap bitmap =
                    new System.Drawing.Bitmap(
                        10,
                        10))
                using (System.Drawing.Graphics graphics =
                    System.Drawing.Graphics
                        .FromImage(bitmap))
                using (System.Drawing.Font fuente =
                    new System.Drawing.Font(
                        "Arial Narrow",
                        tamanoPuntos,
                        System.Drawing.FontStyle.Regular,
                        System.Drawing.GraphicsUnit.Point))
                {
                    graphics.TextRenderingHint =
                        System.Drawing.Text
                            .TextRenderingHint
                            .AntiAliasGridFit;

                    System.Drawing.SizeF tamano =
                        graphics.MeasureString(
                            texto,
                            fuente,
                            10000,
                            System.Drawing.StringFormat
                                .GenericTypographic);

                    if (graphics.DpiX <= 0.0f)
                        return 0.0;

                    //-------------------------------------------------
                    // px -> mm
                    //-------------------------------------------------
                    return
                        tamano.Width /
                        graphics.DpiX *
                        25.4;
                }
            }
            catch
            {
                //-------------------------------------------------
                // Respaldo si Windows no puede medir la fuente.
                // Arial Narrow suele ocupar ~0.48 de la altura
                // por carácter en promedio.
                //-------------------------------------------------
                return
                    texto.Length *
                    tamanoMm *
                    0.48;
            }
        }

        private void CentrarTextoVerticalmenteLeyenda(
            Document doc,
            View vista,
            TextNote texto,
            double centroObjetivoY)
        {
            if (doc == null ||
                vista == null ||
                texto == null ||
                !texto.IsValidObject)
            {
                return;
            }

            try
            {
                //-------------------------------------------------
                // Revit necesita regenerar para calcular
                // correctamente las extensiones del TextNote.
                //-------------------------------------------------
                doc.Regenerate();

                BoundingBoxXYZ caja =
                    texto.get_BoundingBox(
                        vista);

                if (caja == null ||
                    caja.Min == null ||
                    caja.Max == null)
                {
                    return;
                }

                double centroActualY =
                    (caja.Min.Y +
                        caja.Max.Y) /
                    2.0;

                double desplazamientoY =
                    centroObjetivoY -
                    centroActualY;

                if (Math.Abs(
                    desplazamientoY) <
                    0.0000001)
                {
                    return;
                }

                ElementTransformUtils
                    .MoveElement(
                        doc,
                        texto.Id,
                        new XYZ(
                            0.0,
                            desplazamientoY,
                            0.0));
            }
            catch
            {
            }
        }

        private void AplicarNegritaTextNote(
            TextNote textNote)
        {
            if (textNote == null)
                return;

            try
            {
                //-------------------------------------------------
                // La API de Revit permite aplicar formato bold al
                // texto completo mediante FormattedText.
                //-------------------------------------------------
                FormattedText textoFormateado =
                    textNote.GetFormattedText();

                if (textoFormateado == null)
                    return;

                textoFormateado.SetBoldStatus(
                    true);

                textNote.SetFormattedText(
                    textoFormateado);
            }
            catch
            {
            }
        }

        private void AplicarColorTextoLeyenda(
            View vista,
            ElementId textoId,
            byte rojo,
            byte verde,
            byte azul)
        {
            if (vista == null ||
                textoId == null ||
                textoId ==
                    ElementId.InvalidElementId)
            {
                return;
            }

            Autodesk.Revit.DB.Color color =
                new Autodesk.Revit.DB.Color(
                    rojo,
                    verde,
                    azul);

            using (OverrideGraphicSettings ogs =
                new OverrideGraphicSettings())
            {
                //-------------------------------------------------
                // Para elementos de anotación como TextNote,
                // el override de línea/proyección controla
                // su color gráfico en la vista.
                //-------------------------------------------------
                ogs.SetProjectionLineColor(
                    color);

                vista.SetElementOverrides(
                    textoId,
                    ogs);
            }
        }

        private TextNoteType
            ObtenerOCrearTipoTextoLeyenda(
                Document doc,
                TextNoteType tipoBase,
                string nombreTipo,
                string nombreFuente,
                double tamanoMm,
                bool negrita,
                byte rojo,
                byte verde,
                byte azul)
        {
            if (doc == null ||
                tipoBase == null)
            {
                return tipoBase;
            }

            TextNoteType existente =
                new FilteredElementCollector(doc)
                    .OfClass(typeof(TextNoteType))
                    .Cast<TextNoteType>()
                    .FirstOrDefault(x =>
                        x != null &&
                        string.Equals(
                            x.Name,
                            nombreTipo,
                            StringComparison.OrdinalIgnoreCase));

            if (existente != null)
            {
                //-------------------------------------------------
                // IMPORTANTE:
                // Si el tipo ya existía de una ejecución anterior,
                // también se actualizan sus propiedades.
                //-------------------------------------------------
                ConfigurarTipoTextoLeyenda(
                    existente,
                    nombreFuente,
                    tamanoMm,
                    negrita,
                    rojo,
                    verde,
                    azul);

                return existente;
            }

            ElementType tipoDuplicado =
                tipoBase.Duplicate(
                    nombreTipo);

            TextNoteType nuevoTipo =
                tipoDuplicado
                    as TextNoteType;

            if (nuevoTipo != null)
            {
                ConfigurarTipoTextoLeyenda(
                    nuevoTipo,
                    nombreFuente,
                    tamanoMm,
                    negrita,
                    rojo,
                    verde,
                    azul);
            }

            return nuevoTipo ?? tipoBase;
        }

        private void ConfigurarTipoTextoLeyenda(
            TextNoteType tipoTexto,
            string nombreFuente,
            double tamanoMm,
            bool negrita,
            byte rojo,
            byte verde,
            byte azul)
        {
            if (tipoTexto == null)
                return;

            //-------------------------------------------------
            // FUENTE
            //-------------------------------------------------
            try
            {
                Parameter pFuente =
                    tipoTexto.get_Parameter(
                        BuiltInParameter.TEXT_FONT);

                if (pFuente != null &&
                    !pFuente.IsReadOnly)
                {
                    pFuente.Set(
                        nombreFuente);
                }
            }
            catch
            {
            }

            //-------------------------------------------------
            // TAMAÑO
            //-------------------------------------------------
            try
            {
                Parameter pTamano =
                    tipoTexto.get_Parameter(
                        BuiltInParameter.TEXT_SIZE);

                if (pTamano != null &&
                    !pTamano.IsReadOnly)
                {
                    double tamanoInterno =
                        UnitUtils.ConvertToInternalUnits(
                            tamanoMm,
                            UnitTypeId.Millimeters);

                    pTamano.Set(
                        tamanoInterno);
                }
            }
            catch
            {
            }

            //-------------------------------------------------
            // NEGRITA
            //
            // Antes estaba fijado a 0, por eso el checkbox
            // aparecía desmarcado en Propiedades de tipo.
            //-------------------------------------------------
            try
            {
                Parameter pBold =
                    tipoTexto.get_Parameter(
                        BuiltInParameter.TEXT_STYLE_BOLD);

                if (pBold != null &&
                    !pBold.IsReadOnly)
                {
                    pBold.Set(
                        negrita
                            ? 1
                            : 0);
                }
            }
            catch
            {
            }

            //-------------------------------------------------
            // COLOR DEL TIPO DE TEXTO
            //
            // No solo se aplica un override visual.
            // Se modifica el parámetro "Color" del TextNoteType.
            //-------------------------------------------------
            try
            {
                Parameter pColor =
                    ObtenerParametroColorTipoTexto(
                        tipoTexto);

                if (pColor != null &&
                    !pColor.IsReadOnly &&
                    pColor.StorageType ==
                        StorageType.Integer)
                {
                    int colorEntero =
                        ObtenerValorEnteroColorRevit(
                            rojo,
                            verde,
                            azul);

                    pColor.Set(
                        colorEntero);
                }
            }
            catch
            {
            }
        }

        private Parameter ObtenerParametroColorTipoTexto(
            TextNoteType tipoTexto)
        {
            if (tipoTexto == null)
                return null;

            //-------------------------------------------------
            // 1. Intentar BuiltInParameter por nombre mediante
            // reflexión para mantener compatibilidad entre
            // versiones de Revit.
            //-------------------------------------------------
            string[] posiblesBuiltIn =
            {
                "LINE_COLOR",
                "TEXT_COLOR",
                "TEXT_STYLE_COLOR"
            };

            foreach (string nombreEnum
                in posiblesBuiltIn)
            {
                try
                {
                    object valorEnum =
                        System.Enum.Parse(
                            typeof(BuiltInParameter),
                            nombreEnum,
                            false);

                    BuiltInParameter bip =
                        (BuiltInParameter)
                        valorEnum;

                    Parameter p =
                        tipoTexto.get_Parameter(
                            bip);

                    if (p != null)
                        return p;
                }
                catch
                {
                }
            }

            //-------------------------------------------------
            // 2. Buscar por nombre visible del parámetro.
            // En Revit español e inglés aparece como "Color".
            //-------------------------------------------------
            try
            {
                Parameter p =
                    tipoTexto.LookupParameter(
                        "Color");

                if (p != null)
                    return p;
            }
            catch
            {
            }

            try
            {
                Parameter p =
                    tipoTexto.LookupParameter(
                        "Colour");

                if (p != null)
                    return p;
            }
            catch
            {
            }

            //-------------------------------------------------
            // 3. Último respaldo: recorrer parámetros enteros
            // cuyo nombre contenga COLOR / COLOUR.
            //-------------------------------------------------
            try
            {
                foreach (Parameter p
                    in tipoTexto.Parameters)
                {
                    if (p == null ||
                        p.Definition == null ||
                        p.StorageType !=
                            StorageType.Integer)
                    {
                        continue;
                    }

                    string nombre =
                        p.Definition.Name ?? "";

                    if (nombre.IndexOf(
                            "COLOR",
                            StringComparison.OrdinalIgnoreCase) >= 0 ||
                        nombre.IndexOf(
                            "COLOUR",
                            StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        return p;
                    }
                }
            }
            catch
            {
            }

            return null;
        }

        private int ObtenerValorEnteroColorRevit(
            byte rojo,
            byte verde,
            byte azul)
        {
            Autodesk.Revit.DB.Color color =
                new Autodesk.Revit.DB.Color(
                    rojo,
                    verde,
                    azul);

            //-------------------------------------------------
            // Algunas versiones de Revit exponen un valor entero
            // del objeto Color. Se consulta por reflexión para no
            // depender de una versión concreta de la API.
            //-------------------------------------------------
            try
            {
                System.Reflection.PropertyInfo propiedad =
                    typeof(Autodesk.Revit.DB.Color)
                        .GetProperty(
                            "IntegerValue",
                            System.Reflection.BindingFlags
                                .Public |
                            System.Reflection.BindingFlags
                                .Instance);

                if (propiedad != null)
                {
                    object valor =
                        propiedad.GetValue(
                            color,
                            null);

                    if (valor != null)
                    {
                        return System.Convert
                            .ToInt32(valor);
                    }
                }
            }
            catch
            {
            }

            //-------------------------------------------------
            // Formato COLORREF usado por parámetros gráficos:
            // R + G*256 + B*65536
            //
            // Para RGB(0,0,64):
            // 0 + 0 + 64*65536 = 4194304
            //-------------------------------------------------
            return
                rojo |
                (verde << 8) |
                (azul << 16);
        }

        private FilledRegionType
            ObtenerOCrearTipoRegionRellenadaLeyenda(
                Document doc,
                FilledRegionType tipoBase,
                ElementId patronRellenoId,
                Autodesk.Revit.DB.Color color)
        {
            if (doc == null ||
                tipoBase == null ||
                color == null ||
                patronRellenoId == null ||
                patronRellenoId ==
                    ElementId.InvalidElementId)
            {
                return null;
            }

            string nombreTipo =
                CrearNombreTipoRegionRellenadaRGB(
                    color);

            //-------------------------------------------------
            // 1. REUTILIZAR SI YA EXISTE
            //-------------------------------------------------
            FilledRegionType existente =
                new FilteredElementCollector(
                    doc)
                    .OfClass(
                        typeof(FilledRegionType))
                    .Cast<FilledRegionType>()
                    .FirstOrDefault(x =>
                        x != null &&
                        string.Equals(
                            x.Name,
                            nombreTipo,
                            StringComparison.OrdinalIgnoreCase));

            if (existente != null)
            {
                //-------------------------------------------------
                // Si el tipo ya existía de una ejecución anterior,
                // se vuelve a configurar para garantizar que su
                // color NATIVO coincida con el nombre RGB.
                //-------------------------------------------------
                ConfigurarTipoRegionRellenadaLeyenda(
                    existente,
                    patronRellenoId,
                    color);

                return existente;
            }

            //-------------------------------------------------
            // 2. DUPLICAR UN FILLED REGION TYPE EXISTENTE
            //-------------------------------------------------
            ElementType tipoDuplicado =
                tipoBase.Duplicate(
                    nombreTipo);

            FilledRegionType nuevoTipo =
                tipoDuplicado
                    as FilledRegionType;

            if (nuevoTipo == null)
            {
                return null;
            }

            //-------------------------------------------------
            // 3. CONFIGURAR COLOR / PATRÓN EN EL TIPO MISMO
            //-------------------------------------------------
            ConfigurarTipoRegionRellenadaLeyenda(
                nuevoTipo,
                patronRellenoId,
                color);

            return nuevoTipo;
        }

        private void ConfigurarTipoRegionRellenadaLeyenda(
            FilledRegionType tipoRegion,
            ElementId patronRellenoId,
            Autodesk.Revit.DB.Color color)
        {
            if (tipoRegion == null ||
                patronRellenoId == null ||
                patronRellenoId ==
                    ElementId.InvalidElementId ||
                color == null)
            {
                return;
            }

            //-------------------------------------------------
            // PATRÓN DE PRIMER PLANO
            //-------------------------------------------------
            try
            {
                if (tipoRegion
                    .IsValidForegroundPatternId(
                        patronRellenoId))
                {
                    tipoRegion.ForegroundPatternId =
                        patronRellenoId;
                }
            }
            catch
            {
                //-------------------------------------------------
                // Respaldo para versiones donde la validación
                // pueda comportarse de forma distinta.
                //-------------------------------------------------
                try
                {
                    tipoRegion.ForegroundPatternId =
                        patronRellenoId;
                }
                catch
                {
                }
            }

            //-------------------------------------------------
            // COLOR NATIVO DEL TIPO
            //-------------------------------------------------
            try
            {
                tipoRegion.ForegroundPatternColor =
                    new Autodesk.Revit.DB.Color(
                        color.Red,
                        color.Green,
                        color.Blue);
            }
            catch
            {
            }

            //-------------------------------------------------
            // SIN PATRÓN DE FONDO.
            // El color visible se controla por el foreground.
            //-------------------------------------------------
            try
            {
                tipoRegion.BackgroundPatternId =
                    ElementId.InvalidElementId;
            }
            catch
            {
            }

            //-------------------------------------------------
            // También dejamos preparado el color de fondo por si
            // el usuario posteriormente asigna un patrón de fondo.
            //-------------------------------------------------
            try
            {
                tipoRegion.BackgroundPatternColor =
                    new Autodesk.Revit.DB.Color(
                        color.Red,
                        color.Green,
                        color.Blue);
            }
            catch
            {
            }

            //-------------------------------------------------
            // NO MÁSCARA: comportamiento de región de color.
            //-------------------------------------------------
            try
            {
                tipoRegion.IsMasking =
                    false;
            }
            catch
            {
            }

            //-------------------------------------------------
            // GROSOR NATIVO DEL CONTORNO DE LA REGIÓN.
            //-------------------------------------------------
            try
            {
                tipoRegion.LineWeight =
                    1;
            }
            catch
            {
            }
        }

        private string CrearNombreTipoRegionRellenadaRGB(
            Autodesk.Revit.DB.Color color)
        {
            if (color == null)
            {
                return
                    "MYG_FVP_SOLIDO_RGB_128_128_128";
            }

            return
                "MYG_FVP_SOLIDO_RGB_" +
                color.Red.ToString(
                    "000",
                    CI) +
                "_" +
                color.Green.ToString(
                    "000",
                    CI) +
                "_" +
                color.Blue.ToString(
                    "000",
                    CI);
        }

        private void CrearRegionRectangularLeyenda(
            Document doc,
            View vista,
            ElementId filledRegionTypeId,
            ElementId patronSolidoId,
            double xIzquierda,
            double ySuperior,
            double xDerecha,
            double yInferior,
            Autodesk.Revit.DB.Color colorRelleno)
        {
            if (doc == null ||
                vista == null ||
                filledRegionTypeId == null ||
                filledRegionTypeId ==
                    ElementId.InvalidElementId)
            {
                return;
            }

            CurveLoop borde =
                new CurveLoop();

            XYZ p1 =
                new XYZ(
                    xIzquierda,
                    ySuperior,
                    0.0);

            XYZ p2 =
                new XYZ(
                    xDerecha,
                    ySuperior,
                    0.0);

            XYZ p3 =
                new XYZ(
                    xDerecha,
                    yInferior,
                    0.0);

            XYZ p4 =
                new XYZ(
                    xIzquierda,
                    yInferior,
                    0.0);

            borde.Append(
                Line.CreateBound(
                    p1,
                    p2));

            borde.Append(
                Line.CreateBound(
                    p2,
                    p3));

            borde.Append(
                Line.CreateBound(
                    p3,
                    p4));

            borde.Append(
                Line.CreateBound(
                    p4,
                    p1));

            IList<CurveLoop> contornos =
                new List<CurveLoop>()
                {
                    borde
                };

            FilledRegionType tipoBase =
                doc.GetElement(
                    filledRegionTypeId)
                    as FilledRegionType;

            if (tipoBase == null)
                return;

            //-------------------------------------------------
            // TIPO NATIVO POR RGB TAMBIÉN PARA LA CABECERA.
            // Por ejemplo:
            // MYG_FVP_SOLIDO_RGB_230_230_230
            //-------------------------------------------------
            FilledRegionType tipoRegionColor =
                ObtenerOCrearTipoRegionRellenadaLeyenda(
                    doc,
                    tipoBase,
                    patronSolidoId,
                    colorRelleno);

            if (tipoRegionColor == null)
                return;

            FilledRegion region =
                FilledRegion.Create(
                    doc,
                    tipoRegionColor.Id,
                    vista.Id,
                    contornos);
        }

        private void CrearLineaDetalleLeyenda(
            Document doc,
            View vista,
            XYZ inicio,
            XYZ fin,
            int grosorLinea)
        {
            if (doc == null ||
                vista == null ||
                inicio == null ||
                fin == null)
            {
                return;
            }

            Line linea =
                Line.CreateBound(
                    inicio,
                    fin);

            DetailCurve curva =
                doc.Create.NewDetailCurve(
                    vista,
                    linea);

            if (curva == null)
                return;

            Autodesk.Revit.DB.Color negro =
                new Autodesk.Revit.DB.Color(
                    0,
                    0,
                    0);

            using (OverrideGraphicSettings ogs =
                new OverrideGraphicSettings())
            {
                ogs.SetProjectionLineColor(
                    negro);

                try
                {
                    ogs.SetProjectionLineWeight(
                        grosorLinea <= 0
                            ? 1
                            : grosorLinea);
                }
                catch
                {
                }

                vista.SetElementOverrides(
                    curva.Id,
                    ogs);
            }
        }

        private OverrideGraphicSettings
            CrearOverrideGraficoLeyenda(
                Autodesk.Revit.DB.Color color,
                ElementId patronSolidoId)
        {
            OverrideGraphicSettings ogs =
                new OverrideGraphicSettings();

            Autodesk.Revit.DB.Color negro =
                new Autodesk.Revit.DB.Color(
                    0,
                    0,
                    0);

            //-------------------------------------------------
            // BORDE NEGRO
            //-------------------------------------------------
            ogs.SetProjectionLineColor(
                negro);

            //-------------------------------------------------
            // RELLENO SÓLIDO CON EL RGB DEL FILTRO
            //-------------------------------------------------
            ogs.SetSurfaceForegroundPatternId(
                patronSolidoId);

            ogs.SetSurfaceForegroundPatternColor(
                color);

            ogs.SetSurfaceForegroundPatternVisible(
                true);

            ogs.SetSurfaceBackgroundPatternId(
                patronSolidoId);

            ogs.SetSurfaceBackgroundPatternColor(
                color);

            ogs.SetSurfaceBackgroundPatternVisible(
                true);

            ogs.SetSurfaceTransparency(0);
            ogs.SetHalftone(false);

            return ogs;
        }

        private void EjecutarSeleccion(
            UIDocument uidoc,
            Document doc)
        {
            View3D vista = ObtenerVistaSesionActiva(doc);

            List<ElementId> ids =
                ObtenerIdsDeClaves(ClavesValoresSolicitados);

            if (ids.Count == 0)
            {
                throw new InvalidOperationException(
                    "Las filas seleccionadas no contienen elementos.");
            }

            uidoc.Selection.SetElementIds(ids);

            try
            {
                uidoc.ShowElements(ids);
            }
            catch
            {
            }

            if (FormInicial != null)
            {
                FormInicial.FinalizarOperacion(
                    "Elementos seleccionados en Revit: " +
                    ids.Count.ToString(CI),
                    false);
            }
        }

        private void EjecutarAislar(Document doc)
        {
            View3D vista = ObtenerVistaSesionActiva(doc);

            List<ElementId> ids =
                ObtenerIdsDeClaves(ClavesValoresSolicitados);

            if (ids.Count == 0)
            {
                throw new InvalidOperationException(
                    "No hay elementos asociados a los valores marcados.");
            }

            if (vista.IsTemporaryHideIsolateActive() &&
                !aislamientoTemporalPropio)
            {
                throw new InvalidOperationException(
                    "La vista ya tiene un Aislar/Ocultar temporal creado " +
                    "fuera de esta herramienta. Restáuralo primero.");
            }

            using (Transaction tx =
                new Transaction(
                    doc,
                    "MYG - Aislar valores del parámetro"))
            {
                tx.Start();

                if (aislamientoTemporalPropio &&
                    vista.IsTemporaryHideIsolateActive())
                {
                    vista.DisableTemporaryViewMode(
                        TemporaryViewMode.TemporaryHideIsolate);
                }

                vista.IsolateElementsTemporary(ids);
                tx.Commit();
            }

            aislamientoTemporalPropio = true;

            if (FormInicial != null)
            {
                FormInicial.FinalizarOperacion(
                    "Valores marcados aislados temporalmente. Elementos: " +
                    ids.Count.ToString(CI),
                    false);
            }
        }

        private void EjecutarMostrarTodos(Document doc)
        {
            View3D vista = ObtenerVistaSesionActiva(doc);

            if (aislamientoTemporalPropio &&
                vista.IsTemporaryHideIsolateActive())
            {
                using (Transaction tx =
                    new Transaction(
                        doc,
                        "MYG - Mostrar todos los valores"))
                {
                    tx.Start();

                    vista.DisableTemporaryViewMode(
                        TemporaryViewMode.TemporaryHideIsolate);

                    tx.Commit();
                }
            }

            aislamientoTemporalPropio = false;

            if (FormInicial != null)
            {
                FormInicial.FinalizarOperacion(
                    "Se restauró la visibilidad de todos los valores.",
                    false);
            }
        }

        private void EjecutarRestaurar(
            Document doc,
            bool cerrar)
        {
            if (vistaPersistenteActual)
            {
                LimpiarDatosSesion();

                if (FormInicial != null)
                {
                    FormInicial.NotificarRestaurado(
                        "La vista permanente se conservó sin cambios.",
                        cerrar);
                }

                return;
            }

            bool habiaSesion =
                modoPropiedadesTemporalesPropio ||
                aislamientoTemporalPropio ||
                vistaSesionId != ElementId.InvalidElementId;

            if (habiaSesion)
            {
                using (Transaction tx =
                    new Transaction(
                        doc,
                        "MYG - Restaurar análisis temporal"))
                {
                    tx.Start();
                    LimpiarSesionTemporalDentroDeTransaccion(doc);
                    tx.Commit();
                }
            }

            LimpiarDatosSesion();

            if (FormInicial != null)
            {
                FormInicial.NotificarRestaurado(
                    "Vista restaurada. Se eliminaron los filtros de Visibilidad/Gráficos creados por MYG.",
                    cerrar);
            }
        }

        private View3D ObtenerVista3DActiva(Document doc)
        {
            if (doc == null)
            {
                throw new InvalidOperationException(
                    "Documento inválido.");
            }

            View3D vista = doc.ActiveView as View3D;

            if (vista == null || vista.IsTemplate)
            {
                throw new InvalidOperationException(
                    "Debes tener abierta una vista 3D válida.");
            }

            if (!vista.AreGraphicsOverridesAllowed())
            {
                throw new InvalidOperationException(
                    "La vista 3D actual no admite sobrescrituras gráficas.");
            }

            return vista;
        }

        private View3D ObtenerVistaSesionActiva(Document doc)
        {
            if (vistaSesionId == ElementId.InvalidElementId)
            {
                throw new InvalidOperationException(
                    "Primero aplica un análisis por parámetro.");
            }

            View3D vista = doc.GetElement(vistaSesionId) as View3D;

            if (vista == null || !vista.IsValidObject)
            {
                throw new InvalidOperationException(
                    "La vista donde se aplicó el análisis ya no está disponible.");
            }

            if (doc.ActiveView == null ||
                doc.ActiveView.Id != vistaSesionId)
            {
                throw new InvalidOperationException(
                    "Vuelve a la vista 3D donde se aplicaron los colores.");
            }

            return vista;
        }

        private List<Element> ObtenerElementosAnalizables(
            Document doc,
            View3D vista)
        {
            List<Element> resultado = new List<Element>();

            FilteredElementCollector collector =
                new FilteredElementCollector(doc, vista.Id)
                    .WhereElementIsNotElementType();

            foreach (Element e in collector)
            {
                if (e == null || !e.IsValidObject)
                    continue;

                if (e.ViewSpecific)
                    continue;

                if (e is RevitLinkInstance)
                    continue;

                if (e is ImportInstance)
                    continue;

                Category categoria = null;

                try
                {
                    categoria = e.Category;
                }
                catch
                {
                    categoria = null;
                }

                if (categoria == null)
                    continue;

                if (SoloCategoriasModelo &&
                    categoria.CategoryType != CategoryType.Model)
                {
                    continue;
                }

                try
                {
                    if (!vista.IsCategoryOverridable(categoria.Id))
                        continue;
                }
                catch
                {
                    continue;
                }

                try
                {
                    if (e.IsHidden(vista))
                        continue;
                }
                catch
                {
                }

                try
                {
                    if (vista.GetCategoryHidden(categoria.Id))
                        continue;
                }
                catch
                {
                }

                try
                {
                    if (vista.IsTemporaryHideIsolateActive() &&
                        !vista.IsElementVisibleInTemporaryViewMode(
                            TemporaryViewMode.TemporaryHideIsolate,
                            e.Id))
                    {
                        continue;
                    }
                }
                catch
                {
                }

                resultado.Add(e);
            }

            return resultado;
        }

        private List<ElementoVinculadoAnalizable>
            ObtenerElementosVinculadosAnalizables(
                Document doc,
                View3D vista)
        {
            List<ElementoVinculadoAnalizable> resultado =
                new List<ElementoVinculadoAnalizable>();

            if (doc == null ||
                vista == null)
            {
                return resultado;
            }

            List<RevitLinkInstance> vinculos =
                new FilteredElementCollector(
                    doc,
                    vista.Id)
                    .OfClass(typeof(RevitLinkInstance))
                    .Cast<RevitLinkInstance>()
                    .Where(x =>
                        x != null &&
                        x.IsValidObject)
                    .ToList();

            foreach (RevitLinkInstance vinculo
                in vinculos)
            {
                Document documentoVinculado = null;

                try
                {
                    documentoVinculado =
                        vinculo.GetLinkDocument();
                }
                catch
                {
                    documentoVinculado = null;
                }

                if (documentoVinculado == null ||
                    !documentoVinculado.IsValidObject)
                {
                    continue;
                }

                FilteredElementCollector collectorVinculo;

                try
                {
                    // Revit 2024+:
                    // devuelve los elementos del vínculo visibles
                    // específicamente en la vista anfitriona.
                    collectorVinculo =
                        new FilteredElementCollector(
                            doc,
                            vista.Id,
                            vinculo.Id)
                            .WhereElementIsNotElementType();
                }
                catch
                {
                    continue;
                }

                foreach (Element e in collectorVinculo)
                {
                    if (e == null ||
                        !e.IsValidObject)
                    {
                        continue;
                    }

                    if (e.ViewSpecific)
                        continue;

                    if (e is RevitLinkInstance)
                        continue;

                    if (e is ImportInstance)
                        continue;

                    Category categoria = null;

                    try
                    {
                        categoria = e.Category;
                    }
                    catch
                    {
                        categoria = null;
                    }

                    if (categoria == null)
                        continue;

                    if (SoloCategoriasModelo &&
                        categoria.CategoryType !=
                            CategoryType.Model)
                    {
                        continue;
                    }

                    resultado.Add(
                        new ElementoVinculadoAnalizable()
                        {
                            DocumentoVinculado =
                                documentoVinculado,
                            Elemento = e,
                            VinculoInstanciaId =
                                vinculo.Id
                        });
                }
            }

            return resultado;
        }

        private List<ColorearParametro28.ParametroDisponible>
            ObtenerParametrosDisponibles(
                Document doc,
                List<Element> elementos,
                List<ElementoVinculadoAnalizable> elementosVinculados,
                bool incluirTipo)
        {
            Dictionary<string, ColorearParametro28.ParametroDisponible> mapa =
                new Dictionary<
                    string,
                    ColorearParametro28.ParametroDisponible>(
                        StringComparer.OrdinalIgnoreCase);

            HashSet<string> conteosPorElemento =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            foreach (Element e in elementos)
            {
                if (e == null)
                    continue;

                AgregarParametrosElemento(
                    e,
                    false,
                    mapa,
                    conteosPorElemento,
                    e.Id,
                    "H");

                if (incluirTipo)
                {
                    ElementId tipoId = e.GetTypeId();

                    if (tipoId != null &&
                        tipoId != ElementId.InvalidElementId)
                    {
                        Element tipo =
                            e.Document.GetElement(tipoId);

                        if (tipo != null)
                        {
                            AgregarParametrosElemento(
                                tipo,
                                true,
                                mapa,
                                conteosPorElemento,
                                e.Id,
                                "H");
                        }
                    }
                }
            }

            if (elementosVinculados != null)
            {
                foreach (ElementoVinculadoAnalizable info
                    in elementosVinculados)
                {
                    if (info == null ||
                        info.Elemento == null ||
                        info.DocumentoVinculado == null)
                    {
                        continue;
                    }

                    string prefijoConteo =
                        "L|" +
                        IdToText(info.VinculoInstanciaId);

                    AgregarParametrosElemento(
                        info.Elemento,
                        false,
                        mapa,
                        conteosPorElemento,
                        info.Elemento.Id,
                        prefijoConteo);

                    if (incluirTipo)
                    {
                        ElementId tipoId =
                            info.Elemento.GetTypeId();

                        if (tipoId != null &&
                            tipoId !=
                                ElementId.InvalidElementId)
                        {
                            Element tipo =
                                info.DocumentoVinculado
                                    .GetElement(tipoId);

                            if (tipo != null)
                            {
                                AgregarParametrosElemento(
                                    tipo,
                                    true,
                                    mapa,
                                    conteosPorElemento,
                                    info.Elemento.Id,
                                    prefijoConteo);
                            }
                        }
                    }
                }
            }

            List<ColorearParametro28.ParametroDisponible> resultado =
                mapa.Values.ToList();

            foreach (ColorearParametro28.ParametroDisponible p
                in resultado)
            {
                string origen =
                    p.EsTipo
                        ? "Tipo"
                        : "Instancia";

                p.NombreVisible =
                    (p.NombreParametro ?? "") +
                    "  [" + origen + "]" +
                    "  — " +
                    p.CantidadElementos.ToString(CI) +
                    " elem.";
            }

            resultado.Sort((a, b) =>
            {
                int c = string.Compare(
                    a.NombreParametro,
                    b.NombreParametro,
                    StringComparison.OrdinalIgnoreCase);

                if (c != 0)
                    return c;

                return a.EsTipo.CompareTo(b.EsTipo);
            });

            return resultado;
        }

        private void AgregarParametrosElemento(
            Element propietarioParametros,
            bool esTipo,
            Dictionary<
                string,
                ColorearParametro28.ParametroDisponible> mapa,
            HashSet<string> conteosPorElemento,
            ElementId elementoInstanciaId = null,
            string prefijoConteo = "")
        {
            if (propietarioParametros == null)
                return;

            ElementId idParaConteo =
                elementoInstanciaId ??
                propietarioParametros.Id;

            foreach (Parameter p
                in propietarioParametros.Parameters)
            {
                if (p == null ||
                    p.Definition == null)
                {
                    continue;
                }

                string nombre =
                    p.Definition.Name ?? "";

                if (string.IsNullOrWhiteSpace(nombre))
                    continue;

                string clave =
                    CrearClaveParametro(
                        p,
                        esTipo);

                if (string.IsNullOrWhiteSpace(clave))
                    continue;

                ColorearParametro28.ParametroDisponible item;

                if (!mapa.TryGetValue(
                    clave,
                    out item))
                {
                    item =
                        new ColorearParametro28.ParametroDisponible()
                        {
                            Clave = clave,
                            NombreParametro =
                                nombre.Trim(),
                            EsTipo = esTipo,
                            CantidadElementos = 0
                        };

                    mapa.Add(
                        clave,
                        item);
                }

                string claveConteo =
                    clave + "|" +
                    (prefijoConteo ?? "") + "|" +
                    IdToText(idParaConteo);

                if (conteosPorElemento.Add(
                    claveConteo))
                {
                    item.CantidadElementos++;
                }
            }
        }

        private string CrearClaveParametro(
            Parameter p,
            bool esTipo)
        {
            if (p == null ||
                p.Definition == null)
            {
                return "";
            }

            string prefijo =
                esTipo
                    ? "T|"
                    : "I|";

            try
            {
                if (p.IsShared)
                {
                    return prefijo +
                        "G|" +
                        p.GUID
                            .ToString("D")
                            .ToUpperInvariant() +
                        "|" +
                        p.StorageType.ToString();
                }
            }
            catch
            {
            }

            try
            {
                long id = p.Id.Value;

                // Los BuiltInParameter usan ids negativos y son
                // estables entre anfitrión y documentos vinculados.
                if (id < 0)
                {
                    return prefijo +
                        "B|" +
                        id.ToString(CI) +
                        "|" +
                        p.StorageType.ToString();
                }
            }
            catch
            {
            }

            // Los parámetros de proyecto no compartidos pueden tener
            // ids positivos diferentes en cada RVT. Se comparan por
            // nombre y tipo de almacenamiento.
            string nombre =
                p.Definition.Name ?? "";

            return prefijo +
                "N|" +
                nombre.Trim().ToUpperInvariant() +
                "|" +
                p.StorageType.ToString();
        }

        private Dictionary<string, List<ElementId>>
            AgruparElementosPorValor(
                Document doc,
                List<Element> elementos,
                ColorearParametro28.ParametroDisponible descriptor,
                bool incluirSinValor)
        {
            Dictionary<string, List<ElementId>> grupos =
                new Dictionary<string, List<ElementId>>(
                    StringComparer.OrdinalIgnoreCase);

            foreach (Element e in elementos)
            {
                if (e == null)
                    continue;

                Element propietario =
                    ObtenerPropietarioParametro(
                        doc,
                        e,
                        descriptor);

                if (propietario == null)
                    continue;

                Parameter parametro =
                    BuscarParametroPorClave(
                        propietario,
                        descriptor.Clave,
                        descriptor.EsTipo);

                // Los filtros de parámetros de Revit solo pueden trabajar
                // con categorías donde el parámetro es aplicable.
                // Por eso no se crea un grupo "(Sin parámetro)".
                if (parametro == null)
                    continue;

                string valor =
                    ObtenerValorParametro(
                        doc,
                        parametro);

                if (string.IsNullOrWhiteSpace(valor))
                {
                    if (incluirSinValor)
                    {
                        AgregarAGrupo(
                            grupos,
                            "(Sin valor)",
                            e.Id);
                    }

                    continue;
                }

                AgregarAGrupo(
                    grupos,
                    valor,
                    e.Id);
            }

            return grupos;
        }

        private void AgregarValoresVinculadosAGrupos(
            List<ElementoVinculadoAnalizable> elementosVinculados,
            ColorearParametro28.ParametroDisponible descriptor,
            bool incluirSinValor,
            Dictionary<string, List<ElementId>> grupos)
        {
            if (elementosVinculados == null ||
                descriptor == null ||
                grupos == null)
            {
                return;
            }

            foreach (ElementoVinculadoAnalizable info
                in elementosVinculados)
            {
                if (info == null ||
                    info.Elemento == null ||
                    info.DocumentoVinculado == null)
                {
                    continue;
                }

                Element propietario =
                    ObtenerPropietarioParametro(
                        info.DocumentoVinculado,
                        info.Elemento,
                        descriptor);

                if (propietario == null)
                    continue;

                Parameter parametro =
                    BuscarParametroPorClave(
                        propietario,
                        descriptor.Clave,
                        descriptor.EsTipo);

                if (parametro == null)
                    continue;

                string valor =
                    ObtenerValorParametro(
                        info.DocumentoVinculado,
                        parametro);

                if (string.IsNullOrWhiteSpace(valor))
                {
                    if (!incluirSinValor)
                        continue;

                    valor = "(Sin valor)";
                }

                valor = valor.Trim();

                if (!grupos.ContainsKey(valor))
                {
                    // El grupo puede existir solo en vínculos.
                    grupos.Add(
                        valor,
                        new List<ElementId>());
                }

                int cantidadActual = 0;

                cantidadesVinculadasPorValorActuales
                    .TryGetValue(
                        valor,
                        out cantidadActual);

                cantidadesVinculadasPorValorActuales[
                    valor] =
                        cantidadActual + 1;

                if (!parametrosMuestraVinculadosPorValorActuales
                    .ContainsKey(valor))
                {
                    parametrosMuestraVinculadosPorValorActuales
                        .Add(
                            valor,
                            parametro);
                }

                List<ElementId> idsVinculos;

                if (!vinculosPorValorActuales.TryGetValue(
                    valor,
                    out idsVinculos))
                {
                    idsVinculos =
                        new List<ElementId>();

                    vinculosPorValorActuales.Add(
                        valor,
                        idsVinculos);
                }

                if (info.VinculoInstanciaId != null &&
                    info.VinculoInstanciaId !=
                        ElementId.InvalidElementId &&
                    !idsVinculos.Any(x =>
                        x != null &&
                        x.Value ==
                            info.VinculoInstanciaId.Value))
                {
                    idsVinculos.Add(
                        info.VinculoInstanciaId);
                }
            }
        }

        private Parameter BuscarParametroPorClave(
            Element propietario,
            string claveBuscada,
            bool esTipo)
        {
            if (propietario == null ||
                string.IsNullOrWhiteSpace(claveBuscada))
            {
                return null;
            }

            foreach (Parameter p in propietario.Parameters)
            {
                string clave = CrearClaveParametro(p, esTipo);

                if (string.Equals(
                    clave,
                    claveBuscada,
                    StringComparison.OrdinalIgnoreCase))
                {
                    return p;
                }
            }

            return null;
        }

        private string ObtenerValorParametro(
            Document doc,
            Parameter p)
        {
            if (p == null)
                return "";

            try
            {
                if (!p.HasValue)
                    return "";
            }
            catch
            {
            }

            string valor = "";

            try
            {
                switch (p.StorageType)
                {
                    case StorageType.String:
                        valor = p.AsString();
                        break;

                    case StorageType.Integer:
                        valor = p.AsValueString();

                        if (string.IsNullOrWhiteSpace(valor))
                            valor = p.AsInteger().ToString(CI);

                        break;

                    case StorageType.Double:
                        valor = p.AsValueString();

                        if (string.IsNullOrWhiteSpace(valor))
                        {
                            valor = p.AsDouble().ToString(
                                "0.######",
                                CI);
                        }

                        break;

                    case StorageType.ElementId:
                        ElementId id = p.AsElementId();

                        if (id == null ||
                            id == ElementId.InvalidElementId)
                        {
                            return "";
                        }

                        Element relacionado = doc.GetElement(id);

                        if (relacionado != null)
                            valor = relacionado.Name;

                        if (string.IsNullOrWhiteSpace(valor))
                            valor = p.AsValueString();

                        if (string.IsNullOrWhiteSpace(valor))
                            valor = id.Value.ToString(CI);

                        break;

                    default:
                        valor = p.AsValueString();
                        break;
                }
            }
            catch
            {
                valor = "";
            }

            if (valor == null)
                return "";

            valor = valor
                .Replace("\r", " ")
                .Replace("\n", " ")
                .Trim();

            while (valor.Contains("  "))
                valor = valor.Replace("  ", " ");

            return valor;
        }

        private void AgregarAGrupo(
            Dictionary<string, List<ElementId>> grupos,
            string valor,
            ElementId id)
        {
            if (grupos == null ||
                id == null ||
                id == ElementId.InvalidElementId)
            {
                return;
            }

            string clave = string.IsNullOrWhiteSpace(valor)
                ? "(Sin valor)"
                : valor.Trim();

            List<ElementId> ids;

            if (!grupos.TryGetValue(clave, out ids))
            {
                ids = new List<ElementId>();
                grupos.Add(clave, ids);
            }

            if (!ids.Contains(id))
                ids.Add(id);
        }

        private List<ColorearParametro28.LeyendaValor>
            CrearLeyenda(
                Dictionary<string, List<ElementId>> grupos)
        {
            List<string> valores =
                grupos.Keys.ToList();

            valores.Sort((a, b) =>
            {
                bool aSin =
                    a.StartsWith(
                        "(Sin",
                        StringComparison.OrdinalIgnoreCase);

                bool bSin =
                    b.StartsWith(
                        "(Sin",
                        StringComparison.OrdinalIgnoreCase);

                if (aSin != bSin)
                    return aSin ? 1 : -1;

                return string.Compare(
                    a,
                    b,
                    StringComparison.OrdinalIgnoreCase);
            });

            int total = 0;

            foreach (string valor
                in valores)
            {
                List<ElementId> idsHost =
                    grupos[valor];

                int cantidadHost =
                    idsHost == null
                        ? 0
                        : idsHost.Count;

                int cantidadVinculos = 0;

                cantidadesVinculadasPorValorActuales
                    .TryGetValue(
                        valor,
                        out cantidadVinculos);

                total +=
                    cantidadHost +
                    cantidadVinculos;
            }

            HashSet<string> coloresUsados =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            List<ColorearParametro28.LeyendaValor> resultado =
                new List<ColorearParametro28.LeyendaValor>();

            for (int i = 0;
                i < valores.Count;
                i++)
            {
                string valor =
                    valores[i];

                List<ElementId> idsHost =
                    grupos[valor];

                int cantidadHost =
                    idsHost == null
                        ? 0
                        : idsHost.Count;

                int cantidadVinculos = 0;

                cantidadesVinculadasPorValorActuales
                    .TryGetValue(
                        valor,
                        out cantidadVinculos);

                int cantidad =
                    cantidadHost +
                    cantidadVinculos;

                byte[] rgb =
                    ObtenerColorEstable(
                        valor,
                        coloresUsados,
                        i);

                resultado.Add(
                    new ColorearParametro28.LeyendaValor()
                    {
                        ClaveValor = valor,
                        ValorMostrado = valor,
                        Cantidad = cantidad,
                        Porcentaje = total <= 0
                            ? 0
                            : 100.0 *
                                cantidad /
                                total,
                        Rojo = rgb[0],
                        Verde = rgb[1],
                        Azul = rgb[2]
                    });
            }

            return resultado;
        }

        private byte[] ObtenerColorEstable(
            string texto,
            HashSet<string> usados,
            int indiceSecundario)
        {
            uint hash = HashFNV1a(texto ?? "");

            for (int intento = 0; intento < PALETA.Length; intento++)
            {
                int indice =
                    (int)((hash +
                        (uint)(intento * 7) +
                        (uint)indiceSecundario) %
                        (uint)PALETA.Length);

                byte[] color = PALETA[indice];

                string clave =
                    color[0].ToString(CI) + "|" +
                    color[1].ToString(CI) + "|" +
                    color[2].ToString(CI);

                if (usados.Add(clave))
                {
                    return new byte[]
                    {
                        color[0],
                        color[1],
                        color[2]
                    };
                }
            }

            double matiz = hash % 360;
            byte[] hsv = HsvARgb(
                matiz,
                0.70,
                0.88);

            usados.Add(
                hsv[0].ToString(CI) + "|" +
                hsv[1].ToString(CI) + "|" +
                hsv[2].ToString(CI));

            return hsv;
        }

        private uint HashFNV1a(string texto)
        {
            unchecked
            {
                uint hash = 2166136261;

                foreach (char c in texto)
                {
                    hash ^= c;
                    hash *= 16777619;
                }

                return hash;
            }
        }

        private byte[] HsvARgb(
            double h,
            double s,
            double v)
        {
            h = ((h % 360) + 360) % 360;

            double c = v * s;
            double x = c *
                (1 - Math.Abs((h / 60.0) % 2 - 1));
            double m = v - c;

            double r1 = 0;
            double g1 = 0;
            double b1 = 0;

            if (h < 60)
            {
                r1 = c;
                g1 = x;
            }
            else if (h < 120)
            {
                r1 = x;
                g1 = c;
            }
            else if (h < 180)
            {
                g1 = c;
                b1 = x;
            }
            else if (h < 240)
            {
                g1 = x;
                b1 = c;
            }
            else if (h < 300)
            {
                r1 = x;
                b1 = c;
            }
            else
            {
                r1 = c;
                b1 = x;
            }

            return new byte[]
            {
                Convert.ToByte(Math.Round((r1 + m) * 255)),
                Convert.ToByte(Math.Round((g1 + m) * 255)),
                Convert.ToByte(Math.Round((b1 + m) * 255))
            };
        }

        private int CrearFiltrosVisibilityGraphics(
            Document doc,
            View3D vista,
            List<Element> elementos,
            Dictionary<string, List<ElementId>> grupos,
            List<ColorearParametro28.LeyendaValor> leyenda,
            ColorearParametro28.ParametroDisponible descriptor,
            ElementId patronSolidoId)
        {
            ElementId parametroId;
            StorageType storageType;

            List<ElementId> categorias =
                ObtenerCategoriasFiltrables(
                    doc,
                    elementos,
                    descriptor,
                    out parametroId,
                    out storageType);

            if (parametroId == null ||
                parametroId == ElementId.InvalidElementId)
            {
                throw new InvalidOperationException(
                    "No se pudo determinar el identificador del parámetro.");
            }

            if (categorias.Count == 0)
            {
                throw new InvalidOperationException(
                    "El parámetro no es filtrable en ninguna de las categorías visibles.");
            }

            if (LimitarCategorias)
            {
                HashSet<long> categoriasPermitidas =
                    new HashSet<long>(
                        CategoriasSeleccionadas ??
                        new List<long>());

                if (categoriasPermitidas.Count == 0)
                {
                    throw new InvalidOperationException(
                        "No se seleccionó ninguna categoría para limitar los filtros.");
                }

                categorias =
                    categorias
                        .Where(x =>
                            x != null &&
                            categoriasPermitidas.Contains(
                                x.Value))
                        .ToList();

                if (categorias.Count == 0)
                {
                    throw new InvalidOperationException(
                        "Las categorías marcadas no son compatibles con el parámetro seleccionado.");
                }
            }

            List<List<ElementId>> conjuntosCategorias =
                CrearConjuntosCategoriasCompatibles(
                    doc,
                    categorias,
                    parametroId);

            if (conjuntosCategorias.Count == 0)
            {
                throw new InvalidOperationException(
                    "No se encontraron categorías compatibles para crear los filtros.");
            }

            HashSet<string> nombresExistentes =
                ObtenerNombresFiltrosExistentes(doc);

            int filtrosCreados = 0;

            foreach (ColorearParametro28.LeyendaValor item in leyenda)
            {
                if (item == null ||
                    string.IsNullOrWhiteSpace(item.ClaveValor))
                {
                    continue;
                }

                List<ElementId> idsGrupo;

                grupos.TryGetValue(
                    item.ClaveValor,
                    out idsGrupo);

                int cantidadHost =
                    idsGrupo == null
                        ? 0
                        : idsGrupo.Count;

                int cantidadVinculos = 0;

                cantidadesVinculadasPorValorActuales
                    .TryGetValue(
                        item.ClaveValor,
                        out cantidadVinculos);

                if (cantidadHost +
                    cantidadVinculos <= 0)
                {
                    continue;
                }

                Parameter parametroMuestra =
                    ObtenerParametroMuestraDeGrupo(
                        doc,
                        idsGrupo,
                        descriptor,
                        item.ClaveValor);

                if (parametroMuestra == null)
                    continue;

                ElementFilter filtroRegla =
                    CrearElementFilterParaValor(
                        parametroId,
                        storageType,
                        parametroMuestra,
                        item.ClaveValor);

                if (filtroRegla == null)
                    continue;

                Autodesk.Revit.DB.Color color =
                    new Autodesk.Revit.DB.Color(
                        Convert.ToByte(item.Rojo),
                        Convert.ToByte(item.Verde),
                        Convert.ToByte(item.Azul));

                using (OverrideGraphicSettings ogs =
                    CrearOverrideGrafico(
                        color,
                        patronSolidoId,
                        Transparencia))
                {
                    for (int i = 0;
                        i < conjuntosCategorias.Count;
                        i++)
                    {
                        List<ElementId> categoriasGrupo =
                            conjuntosCategorias[i];

                        if (categoriasGrupo == null ||
                            categoriasGrupo.Count == 0)
                        {
                            continue;
                        }

                        HashSet<ElementId> categoriasSet =
                            new HashSet<ElementId>(
                                categoriasGrupo);

                        bool aceptable =
                            ParameterFilterElement
                                .ElementFilterIsAcceptableForParameterFilterElement(
                                    doc,
                                    categoriasSet,
                                    filtroRegla);

                        if (!aceptable)
                            continue;

                        string nombreBase =
                            "MYG_TMP_FVP_" +
                            IdToText(vista.Id) + "_" +
                            LimpiarNombreFiltro(
                                descriptor.NombreParametro) + "_" +
                            LimpiarNombreFiltro(
                                item.ValorMostrado);

                        if (conjuntosCategorias.Count > 1)
                        {
                            nombreBase +=
                                "_G" +
                                (i + 1).ToString(CI);
                        }

                        string nombreFiltro =
                            CrearNombreFiltroUnico(
                                nombreBase,
                                nombresExistentes);

                        ParameterFilterElement filtroVista =
                            null;

                        try
                        {
                            filtroVista =
                                ParameterFilterElement.Create(
                                    doc,
                                    nombreFiltro,
                                    categoriasGrupo,
                                    filtroRegla);
                        }
                        catch (System.ArgumentException ex)
                        {
                            throw new InvalidOperationException(
                                "Revit rechazó el nombre de un filtro. " +
                                "Valor original: '" +
                                (item.ValorMostrado ?? "") +
                                "'. Nombre generado: '" +
                                (nombreFiltro ?? "") +
                                "'. Parámetro: '" +
                                (descriptor.NombreParametro ?? "") +
                                "'. Detalle Revit: " +
                                ex.Message,
                                ex);
                        }

                        vista.AddFilter(
                            filtroVista.Id);

                        vista.SetFilterVisibility(
                            filtroVista.Id,
                            true);

                        vista.SetFilterOverrides(
                            filtroVista.Id,
                            ogs);

                        filtrosCreadosSesion.Add(
                            filtroVista.Id);

                        List<ElementId> filtrosValor;

                        if (!filtrosPorValorActuales.TryGetValue(
                            item.ClaveValor,
                            out filtrosValor))
                        {
                            filtrosValor =
                                new List<ElementId>();

                            filtrosPorValorActuales.Add(
                                item.ClaveValor,
                                filtrosValor);
                        }

                        filtrosValor.Add(
                            filtroVista.Id);

                        coloresPorValorActuales[item.ClaveValor] =
                            new int[]
                            {
                                item.Rojo,
                                item.Verde,
                                item.Azul
                            };

                        filtrosCreados++;
                    }
                }
            }

            return filtrosCreados;
        }

        private List<ElementId> ObtenerCategoriasFiltrables(
            Document doc,
            List<Element> elementos,
            ColorearParametro28.ParametroDisponible descriptor,
            out ElementId parametroId,
            out StorageType storageType)
        {
            parametroId =
                ElementId.InvalidElementId;

            storageType =
                StorageType.None;

            Dictionary<long, ElementId> categoriasUnicas =
                new Dictionary<long, ElementId>();

            // Primero buscar una representación válida del parámetro
            // dentro del documento anfitrión.
            foreach (Element e in elementos)
            {
                if (e == null ||
                    e.Category == null)
                {
                    continue;
                }

                Element propietario =
                    ObtenerPropietarioParametro(
                        doc,
                        e,
                        descriptor);

                if (propietario == null)
                    continue;

                Parameter p =
                    BuscarParametroPorClave(
                        propietario,
                        descriptor.Clave,
                        descriptor.EsTipo);

                if (p == null)
                    continue;

                if (parametroId ==
                    ElementId.InvalidElementId)
                {
                    parametroId = p.Id;
                    storageType = p.StorageType;
                }

                categoriasUnicas[
                    e.Category.Id.Value] =
                        e.Category.Id;
            }

            // Si el valor solo existe en vínculos, resolver el
            // identificador equivalente dentro del anfitrión.
            if (parametroId ==
                ElementId.InvalidElementId)
            {
                parametroId =
                    ResolverParametroIdEnAnfitrion(
                        doc,
                        descriptor,
                        out storageType);
            }

            // Incorporar categorías de elementos vinculados visibles.
            if (elementosVinculadosActuales != null)
            {
                foreach (ElementoVinculadoAnalizable info
                    in elementosVinculadosActuales)
                {
                    if (info == null ||
                        info.Elemento == null ||
                        info.Elemento.Category == null ||
                        info.DocumentoVinculado == null)
                    {
                        continue;
                    }

                    Element propietario =
                        ObtenerPropietarioParametro(
                            info.DocumentoVinculado,
                            info.Elemento,
                            descriptor);

                    if (propietario == null)
                        continue;

                    Parameter p =
                        BuscarParametroPorClave(
                            propietario,
                            descriptor.Clave,
                            descriptor.EsTipo);

                    if (p == null)
                        continue;

                    if (storageType ==
                        StorageType.None)
                    {
                        storageType =
                            p.StorageType;
                    }

                    categoriasUnicas[
                        info.Elemento.Category.Id.Value] =
                            info.Elemento.Category.Id;
                }
            }

            List<ElementId> filtrables =
                new List<ElementId>();

            if (parametroId == null ||
                parametroId ==
                    ElementId.InvalidElementId)
            {
                return filtrables;
            }

            foreach (ElementId categoriaId
                in categoriasUnicas.Values)
            {
                try
                {
                    List<ElementId> unaCategoria =
                        new List<ElementId>()
                        {
                            categoriaId
                        };

                    ICollection<ElementId> parametros =
                        ParameterFilterUtilities
                            .GetFilterableParametersInCommon(
                                doc,
                                unaCategoria);

                    bool contieneParametro = false;

                    if (parametros != null)
                    {
                        foreach (ElementId idParametroFiltrable
                            in parametros)
                        {
                            if (idParametroFiltrable != null &&
                                idParametroFiltrable.Value ==
                                    parametroId.Value)
                            {
                                contieneParametro = true;
                                break;
                            }
                        }
                    }

                    if (contieneParametro)
                    {
                        filtrables.Add(
                            categoriaId);
                    }
                }
                catch
                {
                }
            }

            filtrables.Sort((a, b) =>
                a.Value.CompareTo(b.Value));

            return filtrables;
        }

        private ElementId ResolverParametroIdEnAnfitrion(
            Document doc,
            ColorearParametro28.ParametroDisponible descriptor,
            out StorageType storageType)
        {
            storageType =
                StorageType.None;

            if (doc == null ||
                descriptor == null ||
                string.IsNullOrWhiteSpace(
                    descriptor.Clave))
            {
                return ElementId.InvalidElementId;
            }

            string[] partes =
                descriptor.Clave.Split('|');

            if (partes.Length >= 4)
            {
                StorageType tipo;

                if (Enum.TryParse(
                    partes[partes.Length - 1],
                    out tipo))
                {
                    storageType = tipo;
                }
            }

            // BuiltInParameter: id negativo estable entre RVT.
            for (int i = 0;
                i < partes.Length;
                i++)
            {
                if (string.Equals(
                    partes[i],
                    "B",
                    StringComparison.OrdinalIgnoreCase) &&
                    i + 1 < partes.Length)
                {
                    long idBuiltin;

                    if (long.TryParse(
                        partes[i + 1],
                        NumberStyles.Integer,
                        CI,
                        out idBuiltin))
                    {
                        return new ElementId(
                            idBuiltin);
                    }
                }
            }

            // Parámetro compartido: buscar el mismo GUID en host.
            for (int i = 0;
                i < partes.Length;
                i++)
            {
                if (string.Equals(
                    partes[i],
                    "G",
                    StringComparison.OrdinalIgnoreCase) &&
                    i + 1 < partes.Length)
                {
                    Guid guid;

                    if (Guid.TryParse(
                        partes[i + 1],
                        out guid))
                    {
                        FilteredElementCollector sharedCollector =
                            new FilteredElementCollector(doc)
                                .OfClass(
                                    typeof(SharedParameterElement));

                        foreach (Element elemento
                            in sharedCollector)
                        {
                            SharedParameterElement shared =
                                elemento as SharedParameterElement;

                            if (shared == null)
                                continue;

                            try
                            {
                                if (shared.GuidValue ==
                                    guid)
                                {
                                    return shared.Id;
                                }
                            }
                            catch
                            {
                            }
                        }
                    }
                }
            }

            // Parámetro de proyecto no compartido:
            // buscar por nombre dentro de ParameterElement.
            string nombreBuscado =
                descriptor.NombreParametro ?? "";

            if (!string.IsNullOrWhiteSpace(
                nombreBuscado))
            {
                FilteredElementCollector parameterCollector =
                    new FilteredElementCollector(doc)
                        .OfClass(typeof(ParameterElement));

                foreach (Element elemento
                    in parameterCollector)
                {
                    ParameterElement parameterElement =
                        elemento as ParameterElement;

                    if (parameterElement == null)
                        continue;

                    if (string.Equals(
                        parameterElement.Name,
                        nombreBuscado,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        return parameterElement.Id;
                    }
                }
            }

            return ElementId.InvalidElementId;
        }

        private List<ColorearParametro28.CategoriaDisponible>
            CrearCategoriasDisponibles(
                Document doc,
                List<Element> elementosHost,
                List<ElementoVinculadoAnalizable> elementosVinculados,
                ColorearParametro28.ParametroDisponible descriptor,
                List<ElementId> categoriasFiltrables)
        {
            Dictionary<long, ColorearParametro28.CategoriaDisponible> mapa =
                new Dictionary<
                    long,
                    ColorearParametro28.CategoriaDisponible>();

            HashSet<long> permitidas =
                new HashSet<long>();

            if (categoriasFiltrables != null)
            {
                foreach (ElementId id
                    in categoriasFiltrables)
                {
                    if (id != null)
                        permitidas.Add(id.Value);
                }
            }

            if (elementosHost != null)
            {
                foreach (Element e
                    in elementosHost)
                {
                    if (e == null ||
                        e.Category == null ||
                        !permitidas.Contains(
                            e.Category.Id.Value))
                    {
                        continue;
                    }

                    Element propietario =
                        ObtenerPropietarioParametro(
                            doc,
                            e,
                            descriptor);

                    Parameter parametro =
                        BuscarParametroPorClave(
                            propietario,
                            descriptor.Clave,
                            descriptor.EsTipo);

                    if (parametro == null)
                        continue;

                    ColorearParametro28.CategoriaDisponible item =
                        ObtenerOCrearCategoriaDisponible(
                            mapa,
                            e.Category.Id.Value,
                            e.Category.Name);

                    item.CantidadAnfitrion++;
                }
            }

            if (elementosVinculados != null)
            {
                foreach (ElementoVinculadoAnalizable info
                    in elementosVinculados)
                {
                    if (info == null ||
                        info.Elemento == null ||
                        info.DocumentoVinculado == null ||
                        info.Elemento.Category == null ||
                        !permitidas.Contains(
                            info.Elemento.Category.Id.Value))
                    {
                        continue;
                    }

                    Element propietario =
                        ObtenerPropietarioParametro(
                            info.DocumentoVinculado,
                            info.Elemento,
                            descriptor);

                    Parameter parametro =
                        BuscarParametroPorClave(
                            propietario,
                            descriptor.Clave,
                            descriptor.EsTipo);

                    if (parametro == null)
                        continue;

                    ColorearParametro28.CategoriaDisponible item =
                        ObtenerOCrearCategoriaDisponible(
                            mapa,
                            info.Elemento.Category.Id.Value,
                            info.Elemento.Category.Name);

                    item.CantidadVinculos++;
                }
            }

            List<ColorearParametro28.CategoriaDisponible> resultado =
                mapa.Values
                    .Where(x =>
                        x != null &&
                        x.CantidadTotal > 0)
                    .OrderBy(x =>
                        x.NombreCategoria)
                    .ToList();

            foreach (ColorearParametro28.CategoriaDisponible item
                in resultado)
            {
                item.Seleccionada = true;
            }

            return resultado;
        }

        private ColorearParametro28.CategoriaDisponible
            ObtenerOCrearCategoriaDisponible(
                Dictionary<long, ColorearParametro28.CategoriaDisponible> mapa,
                long idCategoria,
                string nombreCategoria)
        {
            ColorearParametro28.CategoriaDisponible item;

            if (!mapa.TryGetValue(
                idCategoria,
                out item))
            {
                item =
                    new ColorearParametro28.CategoriaDisponible()
                    {
                        IdCategoria = idCategoria,
                        NombreCategoria =
                            string.IsNullOrWhiteSpace(nombreCategoria)
                                ? "Categoría " +
                                    idCategoria.ToString(CI)
                                : nombreCategoria.Trim(),
                        CantidadAnfitrion = 0,
                        CantidadVinculos = 0,
                        Seleccionada = true
                    };

                mapa.Add(
                    idCategoria,
                    item);
            }

            return item;
        }

        private List<List<ElementId>>
            CrearConjuntosCategoriasCompatibles(
                Document doc,
                List<ElementId> categorias,
                ElementId parametroId)
        {
            List<List<ElementId>> resultado =
                new List<List<ElementId>>();

            foreach (ElementId categoria in categorias)
            {
                bool agregado = false;

                foreach (List<ElementId> grupo in resultado)
                {
                    List<ElementId> candidato =
                        new List<ElementId>(grupo);

                    candidato.Add(categoria);

                    if (ParametroEsComunYFiltrable(
                        doc,
                        candidato,
                        parametroId))
                    {
                        grupo.Add(categoria);
                        agregado = true;
                        break;
                    }
                }

                if (!agregado)
                {
                    List<ElementId> nuevo =
                        new List<ElementId>()
                        {
                            categoria
                        };

                    if (ParametroEsComunYFiltrable(
                        doc,
                        nuevo,
                        parametroId))
                    {
                        resultado.Add(nuevo);
                    }
                }
            }

            return resultado;
        }

        private bool ParametroEsComunYFiltrable(
            Document doc,
            List<ElementId> categorias,
            ElementId parametroId)
        {
            if (categorias == null ||
                categorias.Count == 0 ||
                parametroId == null ||
                parametroId == ElementId.InvalidElementId)
            {
                return false;
            }

            try
            {
                ICollection<ElementId> comunes =
                    ParameterFilterUtilities
                        .GetFilterableParametersInCommon(
                            doc,
                            categorias);

                return comunes != null &&
                    comunes.Any(x =>
                        x != null &&
                        x.Value == parametroId.Value);
            }
            catch
            {
                return false;
            }
        }

        private Element ObtenerPropietarioParametro(
            Document doc,
            Element instancia,
            ColorearParametro28.ParametroDisponible descriptor)
        {
            if (doc == null ||
                instancia == null ||
                descriptor == null)
            {
                return null;
            }

            if (!descriptor.EsTipo)
                return instancia;

            ElementId tipoId =
                instancia.GetTypeId();

            if (tipoId == null ||
                tipoId == ElementId.InvalidElementId)
            {
                return null;
            }

            return doc.GetElement(tipoId);
        }

        private Parameter ObtenerParametroMuestraDeGrupo(
            Document doc,
            List<ElementId> idsGrupo,
            ColorearParametro28.ParametroDisponible descriptor,
            string claveValor)
        {
            if (doc == null ||
                descriptor == null)
            {
                return null;
            }

            if (idsGrupo != null)
            {
                foreach (ElementId id
                    in idsGrupo)
                {
                    Element instancia =
                        doc.GetElement(id);

                    if (instancia == null)
                        continue;

                    Element propietario =
                        ObtenerPropietarioParametro(
                            doc,
                            instancia,
                            descriptor);

                    Parameter p =
                        BuscarParametroPorClave(
                            propietario,
                            descriptor.Clave,
                            descriptor.EsTipo);

                    if (p != null)
                        return p;
                }
            }

            Parameter muestraVinculo;

            if (!string.IsNullOrWhiteSpace(
                claveValor) &&
                parametrosMuestraVinculadosPorValorActuales
                    .TryGetValue(
                        claveValor,
                        out muestraVinculo))
            {
                return muestraVinculo;
            }

            return null;
        }

        private ElementFilter CrearElementFilterParaValor(
            ElementId parametroId,
            StorageType storageType,
            Parameter parametroMuestra,
            string valorMostrado)
        {
            if (parametroId == null ||
                parametroId == ElementId.InvalidElementId ||
                parametroMuestra == null)
            {
                return null;
            }

            if (string.Equals(
                valorMostrado,
                "(Sin valor)",
                StringComparison.OrdinalIgnoreCase))
            {
                List<ElementFilter> condicionesSinValor =
                    new List<ElementFilter>();

                FilterRule sinValor =
                    ParameterFilterRuleFactory
                        .CreateHasNoValueParameterRule(
                            parametroId);

                condicionesSinValor.Add(
                    new ElementParameterFilter(
                        sinValor));

                if (storageType == StorageType.String)
                {
                    FilterRule vacio =
                        ParameterFilterRuleFactory
                            .CreateEqualsRule(
                                parametroId,
                                "");

                    condicionesSinValor.Add(
                        new ElementParameterFilter(
                            vacio));
                }

                if (condicionesSinValor.Count == 1)
                    return condicionesSinValor[0];

                return new LogicalOrFilter(
                    condicionesSinValor);
            }

            FilterRule regla = null;

            switch (storageType)
            {
                case StorageType.String:
                    regla =
                        ParameterFilterRuleFactory
                            .CreateEqualsRule(
                                parametroId,
                                parametroMuestra.AsString() ?? "");
                    break;

                case StorageType.Integer:
                    regla =
                        ParameterFilterRuleFactory
                            .CreateEqualsRule(
                                parametroId,
                                parametroMuestra.AsInteger());
                    break;

                case StorageType.Double:
                    double valorDouble =
                        parametroMuestra.AsDouble();

                    double tolerancia =
                        Math.Max(
                            0.000000001,
                            Math.Abs(valorDouble) *
                            0.000000001);

                    regla =
                        ParameterFilterRuleFactory
                            .CreateEqualsRule(
                                parametroId,
                                valorDouble,
                                tolerancia);
                    break;

                case StorageType.ElementId:
                    ElementId valorId =
                        parametroMuestra.AsElementId();

                    if (valorId == null ||
                        valorId == ElementId.InvalidElementId)
                    {
                        regla =
                            ParameterFilterRuleFactory
                                .CreateHasNoValueParameterRule(
                                    parametroId);
                    }
                    else
                    {
                        regla =
                            ParameterFilterRuleFactory
                                .CreateEqualsRule(
                                    parametroId,
                                    valorId);
                    }

                    break;
            }

            if (regla == null)
                return null;

            return new ElementParameterFilter(
                regla);
        }

        private HashSet<string> ObtenerNombresFiltrosExistentes(
            Document doc)
        {
            HashSet<string> resultado =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            FilteredElementCollector collector =
                new FilteredElementCollector(doc)
                    .OfClass(
                        typeof(ParameterFilterElement));

            foreach (Element e in collector)
            {
                if (e == null)
                    continue;

                string nombre = e.Name ?? "";

                if (!string.IsNullOrWhiteSpace(nombre))
                    resultado.Add(nombre);
            }

            return resultado;
        }

        private string CrearNombreFiltroUnico(
            string nombreBase,
            HashSet<string> nombresExistentes)
        {
            string baseLimpia =
                LimpiarNombreFiltro(nombreBase);

            if (string.IsNullOrWhiteSpace(baseLimpia))
                baseLimpia = "MYG_TMP_FVP";

            if (baseLimpia.Length > 180)
                baseLimpia = baseLimpia.Substring(0, 180);

            string candidato = baseLimpia;
            int numero = 1;

            while (nombresExistentes.Contains(candidato))
            {
                string sufijo =
                    "_" +
                    numero.ToString("00", CI);

                int maxBase =
                    200 - sufijo.Length;

                string baseRecortada =
                    baseLimpia.Length > maxBase
                        ? baseLimpia.Substring(0, maxBase)
                        : baseLimpia;

                candidato =
                    baseRecortada +
                    sufijo;

                numero++;
            }

            nombresExistentes.Add(candidato);
            return candidato;
        }

        private string LimpiarNombreFiltro(
            string texto)
        {
            if (string.IsNullOrWhiteSpace(
                texto))
            {
                return "";
            }

            //-------------------------------------------------
            // REVIT NO ACEPTA DETERMINADOS CARACTERES EN
            // NOMBRES DE ELEMENTOS (filtros, tipos, vistas, etc.).
            // También limpiamos separadores problemáticos y
            // caracteres de control invisibles.
            //-------------------------------------------------
            char[] prohibidos =
            {
                '\\',
                '/',
                ':',
                '{',
                '}',
                '[',
                ']',
                '|',
                ';',
                '<',
                '>',
                '?',
                '`',
                '~',
                '"'
            };

            string resultado =
                texto.Trim();

            foreach (char c
                in prohibidos)
            {
                resultado =
                    resultado.Replace(
                        c,
                        '_');
            }

            //-------------------------------------------------
            // CARACTERES DE CONTROL: tab, CR, LF, etc.
            //-------------------------------------------------
            System.Text.StringBuilder sb =
                new System.Text.StringBuilder(
                    resultado.Length);

            foreach (char c
                in resultado)
            {
                if (char.IsControl(c))
                {
                    sb.Append(' ');
                }
                else
                {
                    sb.Append(c);
                }
            }

            resultado =
                sb.ToString();

            while (resultado.Contains("  "))
            {
                resultado =
                    resultado.Replace(
                        "  ",
                        " "
                    );
            }

            while (resultado.Contains("__"))
            {
                resultado =
                    resultado.Replace(
                        "__",
                        "_"
                    );
            }

            resultado =
                resultado.Trim(
                    ' ',
                    '_',
                    '.');

            if (string.IsNullOrWhiteSpace(
                resultado))
            {
                resultado =
                    "MYG_SIN_NOMBRE";
            }

            return resultado;
        }

        private OverrideGraphicSettings CrearOverrideGrafico(
            Autodesk.Revit.DB.Color color,
            ElementId patronSolidoId,
            int transparencia)
        {
            int transparenciaFinal = transparencia;

            if (transparenciaFinal < 0)
                transparenciaFinal = 0;

            if (transparenciaFinal > 90)
                transparenciaFinal = 90;

            OverrideGraphicSettings ogs =
                new OverrideGraphicSettings();

            //-------------------------------------------------
            // LÍNEAS DE PROYECCIÓN Y CORTE: SIEMPRE NEGRAS
            //-------------------------------------------------
            Autodesk.Revit.DB.Color colorNegro =
                new Autodesk.Revit.DB.Color(
                    0,
                    0,
                    0);

            ogs.SetProjectionLineColor(
                colorNegro);

            ogs.SetCutLineColor(
                colorNegro);

            //-------------------------------------------------
            // PROYECCIÓN / SUPERFICIE
            // PATRÓN EN PRIMER PLANO
            //-------------------------------------------------
            ogs.SetSurfaceForegroundPatternId(
                patronSolidoId);

            ogs.SetSurfaceForegroundPatternColor(
                color);

            ogs.SetSurfaceForegroundPatternVisible(
                true);

            //-------------------------------------------------
            // PROYECCIÓN / SUPERFICIE
            // PATRÓN DE FONDO
            //-------------------------------------------------
            ogs.SetSurfaceBackgroundPatternId(
                patronSolidoId);

            ogs.SetSurfaceBackgroundPatternColor(
                color);

            ogs.SetSurfaceBackgroundPatternVisible(
                true);

            //-------------------------------------------------
            // CORTE
            // PATRÓN EN PRIMER PLANO
            //-------------------------------------------------
            ogs.SetCutForegroundPatternId(
                patronSolidoId);

            ogs.SetCutForegroundPatternColor(
                color);

            ogs.SetCutForegroundPatternVisible(
                true);

            //-------------------------------------------------
            // CORTE
            // PATRÓN DE FONDO
            //-------------------------------------------------
            ogs.SetCutBackgroundPatternId(
                patronSolidoId);

            ogs.SetCutBackgroundPatternColor(
                color);

            ogs.SetCutBackgroundPatternVisible(
                true);

            //-------------------------------------------------
            // TRANSPARENCIA Y TRAMADO
            //-------------------------------------------------
            ogs.SetSurfaceTransparency(
                transparenciaFinal);

            ogs.SetHalftone(false);

            return ogs;
        }

        private ElementId ObtenerPatronSolido(Document doc)
        {
            FilteredElementCollector collector =
                new FilteredElementCollector(doc)
                    .OfClass(typeof(FillPatternElement));

            foreach (Element e in collector)
            {
                FillPatternElement patron =
                    e as FillPatternElement;

                if (patron == null)
                    continue;

                try
                {
                    FillPattern fill = patron.GetFillPattern();

                    if (fill != null && fill.IsSolidFill)
                        return patron.Id;
                }
                catch
                {
                }
            }

            return ElementId.InvalidElementId;
        }

        private List<ElementId> ObtenerIdsDeClaves(
            List<string> claves)
        {
            List<ElementId> resultado =
                new List<ElementId>();

            HashSet<long> vistos =
                new HashSet<long>();

            if (claves == null)
                return resultado;

            foreach (string clave
                in claves)
            {
                if (string.IsNullOrWhiteSpace(clave))
                    continue;

                List<ElementId> idsHost;

                if (gruposActuales.TryGetValue(
                    clave,
                    out idsHost) &&
                    idsHost != null)
                {
                    foreach (ElementId id
                        in idsHost)
                    {
                        if (id == null ||
                            id ==
                                ElementId.InvalidElementId)
                        {
                            continue;
                        }

                        if (vistos.Add(id.Value))
                        {
                            resultado.Add(id);
                        }
                    }
                }

                // Los elementos internos de un vínculo no pueden
                // seleccionarse con Selection.SetElementIds del host.
                // Se selecciona la instancia del vínculo que contiene
                // los valores solicitados.
                List<ElementId> idsVinculos;

                if (vinculosPorValorActuales.TryGetValue(
                    clave,
                    out idsVinculos) &&
                    idsVinculos != null)
                {
                    foreach (ElementId idVinculo
                        in idsVinculos)
                    {
                        if (idVinculo == null ||
                            idVinculo ==
                                ElementId.InvalidElementId)
                        {
                            continue;
                        }

                        if (vistos.Add(
                            idVinculo.Value))
                        {
                            resultado.Add(
                                idVinculo);
                        }
                    }
                }
            }

            return resultado;
        }

        private void LimpiarSesionTemporalDentroDeTransaccion(
            Document doc)
        {
            if (doc == null)
                return;

            if (vistaSesionId != ElementId.InvalidElementId)
            {
                View vistaAnterior =
                    doc.GetElement(vistaSesionId) as View;

                if (vistaAnterior != null &&
                    vistaAnterior.IsValidObject)
                {
                    if (aislamientoTemporalPropio)
                    {
                        try
                        {
                            if (vistaAnterior
                                .IsTemporaryHideIsolateActive())
                            {
                                vistaAnterior.DisableTemporaryViewMode(
                                    TemporaryViewMode
                                        .TemporaryHideIsolate);
                            }
                        }
                        catch
                        {
                        }
                    }

                    if (modoPropiedadesTemporalesPropio)
                    {
                        try
                        {
                            if (vistaAnterior
                                .IsTemporaryViewPropertiesModeEnabled())
                            {
                                vistaAnterior
                                    .EnableTemporaryViewPropertiesMode(
                                        ElementId.InvalidElementId);
                            }
                        }
                        catch
                        {
                        }
                    }
                }
            }

            if (filtrosCreadosSesion != null &&
                filtrosCreadosSesion.Count > 0)
            {
                List<ElementId> filtrosValidos =
                    new List<ElementId>();

                foreach (ElementId id in filtrosCreadosSesion)
                {
                    if (id == null ||
                        id == ElementId.InvalidElementId)
                    {
                        continue;
                    }

                    Element filtro =
                        doc.GetElement(id);

                    if (filtro != null &&
                        filtro.IsValidObject)
                    {
                        filtrosValidos.Add(id);
                    }
                }

                if (filtrosValidos.Count > 0)
                {
                    try
                    {
                        doc.Delete(filtrosValidos);
                    }
                    catch
                    {
                        foreach (ElementId id in filtrosValidos)
                        {
                            try
                            {
                                doc.Delete(id);
                            }
                            catch
                            {
                            }
                        }
                    }
                }
            }
        }

        private void LimpiarDatosSesion()
        {
            vistaSesionId = ElementId.InvalidElementId;
            modoPropiedadesTemporalesPropio = false;
            aislamientoTemporalPropio = false;
            vistaPersistenteActual = false;

            gruposActuales =
                new Dictionary<string, List<ElementId>>(
                    StringComparer.OrdinalIgnoreCase);

            filtrosCreadosSesion =
                new List<ElementId>();

            filtrosPorValorActuales =
                new Dictionary<string, List<ElementId>>(
                    StringComparer.OrdinalIgnoreCase);

            coloresPorValorActuales =
                new Dictionary<string, int[]>(
                    StringComparer.OrdinalIgnoreCase);

            elementosVinculadosActuales =
                new List<ElementoVinculadoAnalizable>();

            cantidadesVinculadasPorValorActuales =
                new Dictionary<string, int>(
                    StringComparer.OrdinalIgnoreCase);

            parametrosMuestraVinculadosPorValorActuales =
                new Dictionary<string, Parameter>(
                    StringComparer.OrdinalIgnoreCase);

            vinculosPorValorActuales =
                new Dictionary<string, List<ElementId>>(
                    StringComparer.OrdinalIgnoreCase);

            ClaveColorSolicitada = "";
            NombreVistaPermanenteSolicitado = "";

            FiltrosVGSeleccionados =
                new List<long>();

            ParametrosColumnasVG =
                new List<
                    ColorearParametro28.ParametroDisponible>();

            vistaFiltrosVGId =
                ElementId.InvalidElementId;

            tituloColumnaLeyendaPersonalizado =
                "";

            nombreBaseVistaLeyendaPersonalizado =
                "";

            LimitarCategorias = false;
            CategoriasSeleccionadas =
                new List<long>();

            ClavesValoresSolicitados =
                new List<string>();
        }

        private string IdToText(ElementId id)
        {
            if (id == null)
                return "";

            return id.Value.ToString(CI);
        }
    }
}
