using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // COMANDO 2.8 - FILTRO DE VISTA POR PARÁMETROS
    // SIN USING NI NAMESPACE
    // IMPORTANTE: PEGAR DENTRO DEL MISMO NAMESPACE DE TU MYGCommand.cs
    // =====================================

    [Autodesk.Revit.Attributes.Transaction(
        Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class ColorearParametroCommand :
        Autodesk.Revit.UI.IExternalCommand
    {
        private static ColorearParametro28.ColorearParametroForm formActiva;

        public Autodesk.Revit.UI.Result Execute(
            Autodesk.Revit.UI.ExternalCommandData commandData,
            ref string message,
            Autodesk.Revit.DB.ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            Autodesk.Revit.UI.UIDocument uidoc =
                commandData.Application.ActiveUIDocument;

            if (uidoc == null || uidoc.Document == null)
            {
                message = "No hay un documento activo.";
                return Autodesk.Revit.UI.Result.Failed;
            }

            Autodesk.Revit.DB.View3D vista3D =
                uidoc.Document.ActiveView as Autodesk.Revit.DB.View3D;

            if (vista3D == null || vista3D.IsTemplate)
            {
                Autodesk.Revit.UI.TaskDialog.Show(
                    "MYG - Filtro de Vista por Parámetros",
                    "Debes abrir una vista 3D válida antes de ejecutar el botón 2.8.");

                return Autodesk.Revit.UI.Result.Cancelled;
            }

            if (formActiva != null && !formActiva.IsDisposed)
            {
                formActiva.Show();
                formActiva.BringToFront();
                formActiva.Activate();

                return Autodesk.Revit.UI.Result.Succeeded;
            }

            ColorearParametro28.ColorearParametroForm form =
                new ColorearParametro28.ColorearParametroForm();

            global::MYG_Addin.ColorearParametroExternalEventHandler handler =
                new global::MYG_Addin.ColorearParametroExternalEventHandler();

            handler.UiDoc = uidoc;
            handler.FormInicial = form;

            Autodesk.Revit.UI.ExternalEvent evento =
                Autodesk.Revit.UI.ExternalEvent.Create(handler);

            form.EjecutarEvent = evento;
            form.Handler = handler;

            form.FormClosed += (s, e) =>
            {
                formActiva = null;
            };

            formActiva = form;
            form.Show();

            return Autodesk.Revit.UI.Result.Succeeded;
        }
    }

}
