using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // VENTANA 2.8 - FILTRO DE VISTA POR PARÁMETROS
    // FILTROS DE VISIBILITY/GRAPHICS + LEYENDA INTERACTIVA
    // SIN USING NI NAMESPACE
    // IMPORTANTE: PEGAR DENTRO DEL MISMO NAMESPACE DE TU MYGCommand.cs
    // =====================================

    public static class ColorearParametro28
    {
        public enum ColorearParametroOperacion
        {
            Ninguna = 0,
            CargarParametros = 1,
            AplicarColores = 2,
            SeleccionarFilas = 3,
            AislarMarcados = 4,
            MostrarTodos = 5,
            Restaurar = 6,
            RestaurarYCerrar = 7,
            ActualizarColor = 8,
            CrearVistaPermanente = 9,
            CargarCategorias = 10,
            CrearLeyenda = 11,
            CargarFiltrosVG = 12,
            CrearLeyendaVG = 13
        }

        public sealed class ParametroDisponible
        {
            public string Clave { get; set; }
            public string NombreParametro { get; set; }
            public string NombreVisible { get; set; }
            public bool EsTipo { get; set; }
            public int CantidadElementos { get; set; }

            public override string ToString()
            {
                if (!string.IsNullOrWhiteSpace(NombreVisible))
                    return NombreVisible;

                return NombreParametro ?? "";
            }
        }

        public sealed class CategoriaDisponible
        {
            public long IdCategoria { get; set; }
            public string NombreCategoria { get; set; }
            public int CantidadAnfitrion { get; set; }
            public int CantidadVinculos { get; set; }
            public bool Seleccionada { get; set; }

            public int CantidadTotal
            {
                get
                {
                    return CantidadAnfitrion +
                        CantidadVinculos;
                }
            }

            public override string ToString()
            {
                return
                    (NombreCategoria ?? "") +
                    "  |  Anfitrión: " +
                    CantidadAnfitrion.ToString() +
                    "  |  Vínculos: " +
                    CantidadVinculos.ToString() +
                    "  |  Total: " +
                    CantidadTotal.ToString();
            }
        }

        public sealed class FiltroVGDisponible
        {
            public long IdFiltro { get; set; }
            public string NombreOriginal { get; set; }
            public int Rojo { get; set; }
            public int Verde { get; set; }
            public int Azul { get; set; }
            public bool Visible { get; set; }

            public override string ToString()
            {
                return
                    (NombreOriginal ?? "") +
                    "   |   RGB: " +
                    Rojo.ToString() + ", " +
                    Verde.ToString() + ", " +
                    Azul.ToString() +
                    (Visible
                        ? ""
                        : "   |   Visibilidad desactivada");
            }
        }

        public sealed class LeyendaValor
        {
            public string ClaveValor { get; set; }
            public string ValorMostrado { get; set; }
            public int Cantidad { get; set; }
            public double Porcentaje { get; set; }
            public int Rojo { get; set; }
            public int Verde { get; set; }
            public int Azul { get; set; }
        }


        public static class VentanaRgbNativeMethods
        {
            private static readonly System.IntPtr HWND_TOPMOST =
                new System.IntPtr(-1);

            private const uint SWP_NOSIZE = 0x0001;
            private const uint SWP_NOMOVE = 0x0002;
            private const uint SWP_SHOWWINDOW = 0x0040;

            [System.Runtime.InteropServices.DllImport(
                "user32.dll",
                SetLastError = true)]
            private static extern bool SetWindowPos(
                System.IntPtr hWnd,
                System.IntPtr hWndInsertAfter,
                int x,
                int y,
                int cx,
                int cy,
                uint uFlags);

            [System.Runtime.InteropServices.DllImport(
                "user32.dll")]
            private static extern bool SetForegroundWindow(
                System.IntPtr hWnd);

            [System.Runtime.InteropServices.DllImport(
                "user32.dll")]
            private static extern bool BringWindowToTop(
                System.IntPtr hWnd);

            [System.Runtime.InteropServices.DllImport(
                "user32.dll")]
            private static extern System.IntPtr SetActiveWindow(
                System.IntPtr hWnd);

            public static void ForzarAlFrente(
                System.Windows.Forms.Form form)
            {
                if (form == null ||
                    form.IsDisposed)
                {
                    return;
                }

                try
                {
                    System.IntPtr handle = form.Handle;

                    form.TopMost = true;
                    form.BringToFront();
                    form.Activate();

                    SetWindowPos(
                        handle,
                        HWND_TOPMOST,
                        0,
                        0,
                        0,
                        0,
                        SWP_NOMOVE |
                        SWP_NOSIZE |
                        SWP_SHOWWINDOW);

                    BringWindowToTop(handle);
                    SetActiveWindow(handle);
                    SetForegroundWindow(handle);
                }
                catch
                {
                    try
                    {
                        form.TopMost = true;
                        form.BringToFront();
                        form.Activate();
                    }
                    catch
                    {
                    }
                }
            }
        }

        public class LeyendaParametrosDataGridView :
            System.Windows.Forms.DataGridView
        {
            protected override void OnMouseMove(
                System.Windows.Forms.MouseEventArgs e)
            {
                System.Windows.Forms.DataGridView.HitTestInfo hit =
                    this.HitTest(
                        e.X,
                        e.Y);

                bool sobreColor =
                    hit.RowIndex >= 0 &&
                    hit.ColumnIndex >= 0 &&
                    hit.ColumnIndex < this.Columns.Count &&
                    string.Equals(
                        this.Columns[hit.ColumnIndex].Name,
                        "Color",
                        System.StringComparison.OrdinalIgnoreCase);

                System.Windows.Forms.Cursor cursorDeseado =
                    sobreColor
                        ? System.Windows.Forms.Cursors.Hand
                        : System.Windows.Forms.Cursors.Default;

                this.Cursor = cursorDeseado;
                System.Windows.Forms.Cursor.Current = cursorDeseado;

                base.OnMouseMove(e);
            }

            protected override void OnMouseLeave(
                System.EventArgs e)
            {
                this.Cursor =
                    System.Windows.Forms.Cursors.Default;

                System.Windows.Forms.Cursor.Current =
                    System.Windows.Forms.Cursors.Default;

                base.OnMouseLeave(e);
            }

            protected override void OnCellMouseEnter(
                System.Windows.Forms.DataGridViewCellEventArgs e)
            {
                if (e.RowIndex >= 0 &&
                    e.ColumnIndex >= 0 &&
                    e.ColumnIndex < this.Columns.Count &&
                    string.Equals(
                        this.Columns[e.ColumnIndex].Name,
                        "Color",
                        System.StringComparison.OrdinalIgnoreCase))
                {
                    this.Cursor =
                        System.Windows.Forms.Cursors.Hand;

                    System.Windows.Forms.Cursor.Current =
                        System.Windows.Forms.Cursors.Hand;
                }
                else
                {
                    this.Cursor =
                        System.Windows.Forms.Cursors.Default;
                }

                base.OnCellMouseEnter(e);
            }

            protected override void OnCellMouseLeave(
                System.Windows.Forms.DataGridViewCellEventArgs e)
            {
                this.Cursor =
                    System.Windows.Forms.Cursors.Default;

                base.OnCellMouseLeave(e);
            }
        }

        public class SelectorColorRgbForm :
            System.Windows.Forms.Form
        {
            private System.Windows.Forms.NumericUpDown nudR;
            private System.Windows.Forms.NumericUpDown nudG;
            private System.Windows.Forms.NumericUpDown nudB;
            private System.Windows.Forms.Panel pnlVistaPrevia;
            private System.Windows.Forms.Button btnColorVisual;
            private System.Windows.Forms.Button btnAceptar;
            private System.Windows.Forms.Button btnCancelar;

            public int Rojo
            {
                get { return System.Convert.ToInt32(nudR.Value); }
            }

            public int Verde
            {
                get { return System.Convert.ToInt32(nudG.Value); }
            }

            public int Azul
            {
                get { return System.Convert.ToInt32(nudB.Value); }
            }

            public SelectorColorRgbForm(
                int rojo,
                int verde,
                int azul)
            {
                this.Text = "Editar color RGB";
                this.ClientSize =
                    new System.Drawing.Size(390, 245);
                this.StartPosition =
                    System.Windows.Forms.FormStartPosition.CenterParent;
                this.FormBorderStyle =
                    System.Windows.Forms.FormBorderStyle.FixedDialog;
                this.MaximizeBox = false;
                this.MinimizeBox = false;
                this.ShowInTaskbar = false;
                this.TopMost = true;
                this.BackColor =
                    System.Drawing.Color.FromArgb(245, 247, 250);
                this.Font =
                    new System.Drawing.Font("Segoe UI", 9F);

                System.Windows.Forms.Label lblTitulo =
                    new System.Windows.Forms.Label()
                    {
                        Text = "EDITAR COLOR DEL FILTRO",
                        Left = 20,
                        Top = 18,
                        Width = 350,
                        Height = 25,
                        Font = new System.Drawing.Font(
                            "Segoe UI",
                            10F,
                            System.Drawing.FontStyle.Bold)
                    };

                System.Windows.Forms.Label lblR =
                    CrearEtiqueta("R:", 20, 62);

                System.Windows.Forms.Label lblG =
                    CrearEtiqueta("G:", 135, 62);

                System.Windows.Forms.Label lblB =
                    CrearEtiqueta("B:", 250, 62);

                nudR = CrearNumeroColor(
                    50,
                    59,
                    Limitar(rojo));

                nudG = CrearNumeroColor(
                    165,
                    59,
                    Limitar(verde));

                nudB = CrearNumeroColor(
                    280,
                    59,
                    Limitar(azul));

                pnlVistaPrevia =
                    new System.Windows.Forms.Panel()
                    {
                        Left = 20,
                        Top = 105,
                        Width = 165,
                        Height = 55,
                        BorderStyle =
                            System.Windows.Forms.BorderStyle.FixedSingle
                    };

                btnColorVisual = CrearBoton(
                    "SELECCIONAR VISUALMENTE",
                    200,
                    115,
                    170,
                    System.Drawing.Color.FromArgb(
                        70,
                        100,
                        140));

                btnAceptar = CrearBoton(
                    "ACEPTAR",
                    135,
                    190,
                    110,
                    System.Drawing.Color.FromArgb(
                        22,
                        120,
                        90));

                btnCancelar = CrearBoton(
                    "CANCELAR",
                    260,
                    190,
                    110,
                    System.Drawing.Color.FromArgb(
                        80,
                        80,
                        80));

                btnAceptar.DialogResult =
                    System.Windows.Forms.DialogResult.OK;

                btnCancelar.DialogResult =
                    System.Windows.Forms.DialogResult.Cancel;

                this.AcceptButton = btnAceptar;
                this.CancelButton = btnCancelar;

                nudR.ValueChanged += (s, e) =>
                {
                    ActualizarVistaPrevia();
                };

                nudG.ValueChanged += (s, e) =>
                {
                    ActualizarVistaPrevia();
                };

                nudB.ValueChanged += (s, e) =>
                {
                    ActualizarVistaPrevia();
                };

                btnColorVisual.Click += (s, e) =>
                {
                    AbrirSelectorVisual();
                };

                Controls.Add(lblTitulo);
                Controls.Add(lblR);
                Controls.Add(lblG);
                Controls.Add(lblB);
                Controls.Add(nudR);
                Controls.Add(nudG);
                Controls.Add(nudB);
                Controls.Add(pnlVistaPrevia);
                Controls.Add(btnColorVisual);
                Controls.Add(btnAceptar);
                Controls.Add(btnCancelar);

                this.Shown += (s, e) =>
                {
                    this.BeginInvoke(new System.Action(() =>
                    {
                        VentanaRgbNativeMethods.ForzarAlFrente(
                            this);

                        nudR.Focus();
                    }));
                };

                this.Activated += (s, e) =>
                {
                    VentanaRgbNativeMethods.ForzarAlFrente(
                        this);
                };

                ActualizarVistaPrevia();
            }

            private System.Windows.Forms.Label CrearEtiqueta(
                string texto,
                int left,
                int top)
            {
                return new System.Windows.Forms.Label()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = 28,
                    Height = 25,
                    Font = new System.Drawing.Font(
                        "Segoe UI",
                        9F,
                        System.Drawing.FontStyle.Bold)
                };
            }

            private System.Windows.Forms.NumericUpDown
                CrearNumeroColor(
                    int left,
                    int top,
                    int valor)
            {
                return new System.Windows.Forms.NumericUpDown()
                {
                    Left = left,
                    Top = top,
                    Width = 70,
                    Height = 26,
                    Minimum = 0,
                    Maximum = 255,
                    Value = valor,
                    TextAlign =
                        System.Windows.Forms.HorizontalAlignment.Center
                };
            }

            private System.Windows.Forms.Button CrearBoton(
                string texto,
                int left,
                int top,
                int width,
                System.Drawing.Color color)
            {
                System.Windows.Forms.Button boton =
                    new System.Windows.Forms.Button()
                    {
                        Text = texto,
                        Left = left,
                        Top = top,
                        Width = width,
                        Height = 34,
                        BackColor = color,
                        ForeColor =
                            System.Drawing.Color.White,
                        FlatStyle =
                            System.Windows.Forms.FlatStyle.Flat,
                        Font = new System.Drawing.Font(
                            "Segoe UI",
                            8.2F,
                            System.Drawing.FontStyle.Bold),
                        Cursor =
                            System.Windows.Forms.Cursors.Hand
                    };

                boton.FlatAppearance.BorderSize = 0;
                return boton;
            }

            private void AbrirSelectorVisual()
            {
                using (System.Windows.Forms.ColorDialog dialog =
                    new System.Windows.Forms.ColorDialog())
                {
                    dialog.FullOpen = true;
                    dialog.AnyColor = true;
                    dialog.SolidColorOnly = false;
                    dialog.Color =
                        System.Drawing.Color.FromArgb(
                            Rojo,
                            Verde,
                            Azul);

                    if (dialog.ShowDialog(this) ==
                        System.Windows.Forms.DialogResult.OK)
                    {
                        nudR.Value = dialog.Color.R;
                        nudG.Value = dialog.Color.G;
                        nudB.Value = dialog.Color.B;
                    }
                }
            }

            private void ActualizarVistaPrevia()
            {
                pnlVistaPrevia.BackColor =
                    System.Drawing.Color.FromArgb(
                        Rojo,
                        Verde,
                        Azul);
            }

            private int Limitar(int valor)
            {
                if (valor < 0)
                    return 0;

                if (valor > 255)
                    return 255;

                return valor;
            }
        }

        public class NombreVistaPermanenteForm :
            System.Windows.Forms.Form
        {
            private System.Windows.Forms.TextBox txtNombre;
            private System.Windows.Forms.Button btnCrear;
            private System.Windows.Forms.Button btnCancelar;

            public string NombreVista
            {
                get
                {
                    return txtNombre.Text == null
                        ? ""
                        : txtNombre.Text.Trim();
                }
            }

            public NombreVistaPermanenteForm(
                string nombreSugerido)
            {
                this.Text = "Crear vista permanente";
                this.ClientSize =
                    new System.Drawing.Size(500, 190);
                this.StartPosition =
                    System.Windows.Forms.FormStartPosition.CenterParent;
                this.FormBorderStyle =
                    System.Windows.Forms.FormBorderStyle.FixedDialog;
                this.MaximizeBox = false;
                this.MinimizeBox = false;
                this.ShowInTaskbar = false;
                this.TopMost = true;
                this.BackColor =
                    System.Drawing.Color.FromArgb(245, 247, 250);
                this.Font =
                    new System.Drawing.Font("Segoe UI", 9F);

                System.Windows.Forms.Label lblTitulo =
                    new System.Windows.Forms.Label()
                    {
                        Text = "CREAR VISTA 3D PERMANENTE",
                        Left = 20,
                        Top = 18,
                        Width = 450,
                        Height = 25,
                        Font = new System.Drawing.Font(
                            "Segoe UI",
                            10F,
                            System.Drawing.FontStyle.Bold)
                    };

                System.Windows.Forms.Label lblInfo =
                    new System.Windows.Forms.Label()
                    {
                        Text =
                            "La nueva vista conservará los filtros y colores aunque cierres la ventana.",
                        Left = 20,
                        Top = 48,
                        Width = 450,
                        Height = 35,
                        ForeColor =
                            System.Drawing.Color.FromArgb(
                                75,
                                75,
                                75)
                    };

                System.Windows.Forms.Label lblNombre =
                    new System.Windows.Forms.Label()
                    {
                        Text = "Nombre de la nueva vista:",
                        Left = 20,
                        Top = 88,
                        Width = 210,
                        Height = 22
                    };

                txtNombre =
                    new System.Windows.Forms.TextBox()
                    {
                        Left = 20,
                        Top = 112,
                        Width = 455,
                        Height = 26,
                        Text = nombreSugerido ?? "",
                        BorderStyle =
                            System.Windows.Forms.BorderStyle.FixedSingle
                    };

                btnCrear = CrearBoton(
                    "CREAR VISTA",
                    240,
                    148,
                    110,
                    System.Drawing.Color.FromArgb(
                        0,
                        120,
                        215));

                btnCancelar = CrearBoton(
                    "CANCELAR",
                    365,
                    148,
                    110,
                    System.Drawing.Color.FromArgb(
                        80,
                        80,
                        80));

                btnCrear.DialogResult =
                    System.Windows.Forms.DialogResult.OK;

                btnCancelar.DialogResult =
                    System.Windows.Forms.DialogResult.Cancel;

                this.AcceptButton = btnCrear;
                this.CancelButton = btnCancelar;

                this.FormClosing += (s, e) =>
                {
                    if (this.DialogResult ==
                            System.Windows.Forms.DialogResult.OK &&
                        string.IsNullOrWhiteSpace(NombreVista))
                    {
                        e.Cancel = true;

                        System.Windows.Forms.MessageBox.Show(
                            this,
                            "Escribe un nombre para la nueva vista.",
                            "MYG - Crear vista",
                            System.Windows.Forms.MessageBoxButtons.OK,
                            System.Windows.Forms.MessageBoxIcon.Warning);
                    }
                };

                Controls.Add(lblTitulo);
                Controls.Add(lblInfo);
                Controls.Add(lblNombre);
                Controls.Add(txtNombre);
                Controls.Add(btnCrear);
                Controls.Add(btnCancelar);

                this.Shown += (s, e) =>
                {
                    this.BeginInvoke(
                        new System.Action(() =>
                        {
                            VentanaRgbNativeMethods
                                .ForzarAlFrente(this);

                            txtNombre.Focus();
                            txtNombre.SelectAll();
                        }));
                };

                this.Activated += (s, e) =>
                {
                    VentanaRgbNativeMethods
                        .ForzarAlFrente(this);
                };
            }

            private System.Windows.Forms.Button CrearBoton(
                string texto,
                int left,
                int top,
                int width,
                System.Drawing.Color color)
            {
                System.Windows.Forms.Button boton =
                    new System.Windows.Forms.Button()
                    {
                        Text = texto,
                        Left = left,
                        Top = top,
                        Width = width,
                        Height = 32,
                        BackColor = color,
                        ForeColor =
                            System.Drawing.Color.White,
                        FlatStyle =
                            System.Windows.Forms.FlatStyle.Flat,
                        Font = new System.Drawing.Font(
                            "Segoe UI",
                            8.2F,
                            System.Drawing.FontStyle.Bold),
                        Cursor =
                            System.Windows.Forms.Cursors.Hand
                    };

                boton.FlatAppearance.BorderSize = 0;
                return boton;
            }
        }

        public class SeleccionarCategoriasForm :
            System.Windows.Forms.Form
        {
            private System.Windows.Forms.TextBox txtBuscar;
            private System.Windows.Forms.CheckedListBox clbCategorias;
            private System.Windows.Forms.Label lblResumen;
            private System.Windows.Forms.Button btnTodas;
            private System.Windows.Forms.Button btnNinguna;
            private System.Windows.Forms.Button btnAceptar;
            private System.Windows.Forms.Button btnCancelar;

            private System.Collections.Generic.List<CategoriaDisponible>
                categoriasTodas;

            private System.Collections.Generic.HashSet<long>
                idsSeleccionados;

            private bool actualizandoLista;

            public SeleccionarCategoriasForm(
                System.Collections.Generic.List<CategoriaDisponible> categorias,
                System.Collections.Generic.IEnumerable<long> seleccionadas)
            {
                this.Text = "Seleccionar categorías";
                this.ClientSize =
                    new System.Drawing.Size(660, 520);
                this.StartPosition =
                    System.Windows.Forms.FormStartPosition.CenterParent;
                this.FormBorderStyle =
                    System.Windows.Forms.FormBorderStyle.FixedDialog;
                this.MaximizeBox = false;
                this.MinimizeBox = false;
                this.ShowInTaskbar = false;
                this.TopMost = true;
                this.BackColor =
                    System.Drawing.Color.FromArgb(245, 247, 250);
                this.Font =
                    new System.Drawing.Font("Segoe UI", 9F);

                categoriasTodas =
                    categorias ??
                    new System.Collections.Generic.List<CategoriaDisponible>();

                idsSeleccionados =
                    new System.Collections.Generic.HashSet<long>();

                if (seleccionadas != null)
                {
                    foreach (long id in seleccionadas)
                        idsSeleccionados.Add(id);
                }

                System.Windows.Forms.Label lblTitulo =
                    new System.Windows.Forms.Label()
                    {
                        Text = "CATEGORÍAS COMPATIBLES CON EL PARÁMETRO",
                        Left = 20,
                        Top = 16,
                        Width = 610,
                        Height = 24,
                        Font = new System.Drawing.Font(
                            "Segoe UI",
                            10F,
                            System.Drawing.FontStyle.Bold)
                    };

                System.Windows.Forms.Label lblBuscar =
                    new System.Windows.Forms.Label()
                    {
                        Text = "Buscar categoría:",
                        Left = 20,
                        Top = 50,
                        Width = 130,
                        Height = 24
                    };

                txtBuscar =
                    new System.Windows.Forms.TextBox()
                    {
                        Left = 150,
                        Top = 47,
                        Width = 485,
                        Height = 26,
                        BorderStyle =
                            System.Windows.Forms.BorderStyle.FixedSingle
                    };

                clbCategorias =
                    new System.Windows.Forms.CheckedListBox()
                    {
                        Left = 20,
                        Top = 85,
                        Width = 615,
                        Height = 350,
                        CheckOnClick = true,
                        IntegralHeight = false,
                        BorderStyle =
                            System.Windows.Forms.BorderStyle.FixedSingle
                    };

                lblResumen =
                    new System.Windows.Forms.Label()
                    {
                        Text = "",
                        Left = 20,
                        Top = 442,
                        Width = 300,
                        Height = 24,
                        ForeColor =
                            System.Drawing.Color.FromArgb(70, 70, 70)
                    };

                btnTodas = CrearBoton(
                    "TODAS COMPATIBLES",
                    20,
                    475,
                    155,
                    System.Drawing.Color.FromArgb(70, 105, 145));

                btnNinguna = CrearBoton(
                    "NINGUNA",
                    185,
                    475,
                    105,
                    System.Drawing.Color.FromArgb(100, 100, 100));

                btnAceptar = CrearBoton(
                    "ACEPTAR",
                    410,
                    475,
                    105,
                    System.Drawing.Color.FromArgb(22, 120, 90));

                btnCancelar = CrearBoton(
                    "CANCELAR",
                    525,
                    475,
                    110,
                    System.Drawing.Color.FromArgb(80, 80, 80));

                btnAceptar.DialogResult =
                    System.Windows.Forms.DialogResult.OK;

                btnCancelar.DialogResult =
                    System.Windows.Forms.DialogResult.Cancel;

                this.AcceptButton = btnAceptar;
                this.CancelButton = btnCancelar;

                txtBuscar.TextChanged += (s, e) =>
                {
                    GuardarChecksVisibles();
                    RefrescarLista();
                };

                clbCategorias.ItemCheck += (s, e) =>
                {
                    if (actualizandoLista)
                        return;

                    CategoriaDisponible categoria =
                        clbCategorias.Items[e.Index]
                            as CategoriaDisponible;

                    if (categoria == null)
                        return;

                    this.BeginInvoke(new System.Action(() =>
                    {
                        if (e.NewValue ==
                            System.Windows.Forms.CheckState.Checked)
                        {
                            idsSeleccionados.Add(
                                categoria.IdCategoria);
                        }
                        else
                        {
                            idsSeleccionados.Remove(
                                categoria.IdCategoria);
                        }

                        ActualizarResumen();
                    }));
                };

                btnTodas.Click += (s, e) =>
                {
                    idsSeleccionados.Clear();

                    foreach (CategoriaDisponible categoria
                        in categoriasTodas)
                    {
                        if (categoria != null)
                            idsSeleccionados.Add(
                                categoria.IdCategoria);
                    }

                    RefrescarLista();
                };

                btnNinguna.Click += (s, e) =>
                {
                    idsSeleccionados.Clear();
                    RefrescarLista();
                };

                Controls.Add(lblTitulo);
                Controls.Add(lblBuscar);
                Controls.Add(txtBuscar);
                Controls.Add(clbCategorias);
                Controls.Add(lblResumen);
                Controls.Add(btnTodas);
                Controls.Add(btnNinguna);
                Controls.Add(btnAceptar);
                Controls.Add(btnCancelar);

                this.Shown += (s, e) =>
                {
                    RefrescarLista();

                    this.BeginInvoke(new System.Action(() =>
                    {
                        VentanaRgbNativeMethods
                            .ForzarAlFrente(this);

                        txtBuscar.Focus();
                    }));
                };

                this.Activated += (s, e) =>
                {
                    VentanaRgbNativeMethods
                        .ForzarAlFrente(this);
                };
            }

            public System.Collections.Generic.List<long>
                ObtenerIdsSeleccionados()
            {
                GuardarChecksVisibles();

                return idsSeleccionados
                    .OrderBy(x => x)
                    .ToList();
            }

            private void RefrescarLista()
            {
                string filtro =
                    txtBuscar.Text == null
                        ? ""
                        : txtBuscar.Text.Trim();

                actualizandoLista = true;

                try
                {
                    clbCategorias.BeginUpdate();
                    clbCategorias.Items.Clear();

                    foreach (CategoriaDisponible categoria
                        in categoriasTodas)
                    {
                        if (categoria == null)
                            continue;

                        string texto =
                            categoria.ToString();

                        if (!string.IsNullOrWhiteSpace(filtro) &&
                            texto.IndexOf(
                                filtro,
                                System.StringComparison.OrdinalIgnoreCase) < 0)
                        {
                            continue;
                        }

                        int indice =
                            clbCategorias.Items.Add(
                                categoria);

                        clbCategorias.SetItemChecked(
                            indice,
                            idsSeleccionados.Contains(
                                categoria.IdCategoria));
                    }

                    clbCategorias.EndUpdate();
                }
                finally
                {
                    actualizandoLista = false;
                }

                ActualizarResumen();
            }

            private void GuardarChecksVisibles()
            {
                if (actualizandoLista)
                    return;

                for (int i = 0;
                    i < clbCategorias.Items.Count;
                    i++)
                {
                    CategoriaDisponible categoria =
                        clbCategorias.Items[i]
                            as CategoriaDisponible;

                    if (categoria == null)
                        continue;

                    if (clbCategorias.GetItemChecked(i))
                    {
                        idsSeleccionados.Add(
                            categoria.IdCategoria);
                    }
                    else
                    {
                        idsSeleccionados.Remove(
                            categoria.IdCategoria);
                    }
                }
            }

            private void ActualizarResumen()
            {
                lblResumen.Text =
                    "Seleccionadas: " +
                    idsSeleccionados.Count.ToString() +
                    " de " +
                    categoriasTodas.Count.ToString();
            }

            private System.Windows.Forms.Button CrearBoton(
                string texto,
                int left,
                int top,
                int width,
                System.Drawing.Color color)
            {
                System.Windows.Forms.Button boton =
                    new System.Windows.Forms.Button()
                    {
                        Text = texto,
                        Left = left,
                        Top = top,
                        Width = width,
                        Height = 32,
                        BackColor = color,
                        ForeColor =
                            System.Drawing.Color.White,
                        FlatStyle =
                            System.Windows.Forms.FlatStyle.Flat,
                        Font = new System.Drawing.Font(
                            "Segoe UI",
                            8.1F,
                            System.Drawing.FontStyle.Bold),
                        Cursor =
                            System.Windows.Forms.Cursors.Hand
                    };

                boton.FlatAppearance.BorderSize = 0;
                return boton;
            }
        }

        public class SeleccionarFiltrosVGForm :
            System.Windows.Forms.Form
        {
            private System.Windows.Forms.TextBox txtBuscar;
            private System.Windows.Forms.CheckedListBox clbFiltros;
            private System.Windows.Forms.CheckBox chkLimpiarNombresMYG;
            private System.Windows.Forms.Label lblVista;
            private System.Windows.Forms.Label lblResumen;
            private System.Windows.Forms.Button btnTodos;
            private System.Windows.Forms.Button btnNinguno;
            private System.Windows.Forms.Button btnCrear;
            private System.Windows.Forms.Button btnCancelar;

            private System.Windows.Forms.GroupBox grpColumnas;
            private System.Windows.Forms.Panel pnlColumnas;
            private System.Windows.Forms.Button btnAgregarColumna;
            private System.Windows.Forms.Label lblColumnasAyuda;

            private System.Collections.Generic.List<
                System.Windows.Forms.ComboBox>
                combosColumnas =
                    new System.Collections.Generic.List<
                        System.Windows.Forms.ComboBox>();

            private System.Collections.Generic.List<
                System.Windows.Forms.Button>
                botonesQuitarColumnas =
                    new System.Collections.Generic.List<
                        System.Windows.Forms.Button>();

            private System.Collections.Generic.List<FiltroVGDisponible>
                filtrosTodos;

            private System.Collections.Generic.List<ParametroDisponible>
                parametrosTodos;

            private System.Collections.Generic.HashSet<long>
                idsSeleccionados;

            private bool actualizandoLista;
            private bool actualizandoComboParametros;

            private const int MAX_COLUMNAS_PARAMETROS = 5;

            public bool LimpiarNombresMYG
            {
                get
                {
                    return chkLimpiarNombresMYG.Checked;
                }
            }

            public SeleccionarFiltrosVGForm(
                System.Collections.Generic.List<FiltroVGDisponible> filtros,
                System.Collections.Generic.List<ParametroDisponible> parametros,
                string nombreVista)
            {
                this.Text =
                    "Leyenda de filtros de Visibilidad/Gráficos";

                this.ClientSize =
                    new System.Drawing.Size(
                        820,
                        760);

                this.StartPosition =
                    System.Windows.Forms.FormStartPosition.CenterParent;

                this.FormBorderStyle =
                    System.Windows.Forms.FormBorderStyle.FixedDialog;

                this.MaximizeBox = false;
                this.MinimizeBox = false;
                this.ShowInTaskbar = false;
                this.TopMost = true;

                this.BackColor =
                    System.Drawing.Color.FromArgb(
                        245,
                        247,
                        250);

                this.Font =
                    new System.Drawing.Font(
                        "Segoe UI",
                        9F);

                filtrosTodos =
                    filtros ??
                    new System.Collections.Generic.List<
                        FiltroVGDisponible>();

                parametrosTodos =
                    parametros ??
                    new System.Collections.Generic.List<
                        ParametroDisponible>();

                idsSeleccionados =
                    new System.Collections.Generic.HashSet<long>();

                //-------------------------------------------------
                // POR DEFECTO: TODOS LOS FILTROS
                //-------------------------------------------------
                foreach (FiltroVGDisponible filtro
                    in filtrosTodos)
                {
                    if (filtro != null)
                    {
                        idsSeleccionados.Add(
                            filtro.IdFiltro);
                    }
                }

                //-------------------------------------------------
                // TÍTULO
                //-------------------------------------------------
                System.Windows.Forms.Label lblTitulo =
                    new System.Windows.Forms.Label()
                    {
                        Text =
                            "FILTROS Y COLUMNAS DE LA LEYENDA",
                        Left = 20,
                        Top = 14,
                        Width = 760,
                        Height = 24,
                        Font = new System.Drawing.Font(
                            "Segoe UI",
                            10F,
                            System.Drawing.FontStyle.Bold)
                    };

                lblVista =
                    new System.Windows.Forms.Label()
                    {
                        Text =
                            "Vista activa: " +
                            (nombreVista ?? ""),
                        Left = 20,
                        Top = 41,
                        Width = 770,
                        Height = 23,
                        ForeColor =
                            System.Drawing.Color.FromArgb(
                                70,
                                70,
                                70)
                    };

                //-------------------------------------------------
                // BUSCAR FILTRO
                //-------------------------------------------------
                System.Windows.Forms.Label lblBuscar =
                    new System.Windows.Forms.Label()
                    {
                        Text = "Buscar filtro:",
                        Left = 20,
                        Top = 73,
                        Width = 100,
                        Height = 23
                    };

                txtBuscar =
                    new System.Windows.Forms.TextBox()
                    {
                        Left = 120,
                        Top = 70,
                        Width = 670,
                        Height = 27,
                        BorderStyle =
                            System.Windows.Forms.BorderStyle.FixedSingle
                    };

                clbFiltros =
                    new System.Windows.Forms.CheckedListBox()
                    {
                        Left = 20,
                        Top = 107,
                        Width = 770,
                        Height = 230,
                        CheckOnClick = true,
                        IntegralHeight = false,
                        BorderStyle =
                            System.Windows.Forms.BorderStyle.FixedSingle
                    };

                //-------------------------------------------------
                // OPCIONES FILTROS
                //-------------------------------------------------
                chkLimpiarNombresMYG =
                    new System.Windows.Forms.CheckBox()
                    {
                        Text =
                            "Limpiar prefijos MYG en el nombre mostrado",
                        Left = 20,
                        Top = 344,
                        Width = 390,
                        Height = 24,
                        Checked = true
                    };

                lblResumen =
                    new System.Windows.Forms.Label()
                    {
                        Text = "",
                        Left = 510,
                        Top = 344,
                        Width = 280,
                        Height = 24,
                        TextAlign =
                            System.Drawing.ContentAlignment.MiddleRight,
                        ForeColor =
                            System.Drawing.Color.FromArgb(
                                70,
                                70,
                                70)
                    };

                btnTodos =
                    CrearBoton(
                        "TODOS",
                        20,
                        375,
                        105,
                        System.Drawing.Color.FromArgb(
                            70,
                            105,
                            145));

                btnNinguno =
                    CrearBoton(
                        "NINGUNO",
                        135,
                        375,
                        105,
                        System.Drawing.Color.FromArgb(
                            100,
                            100,
                            100));

                //-------------------------------------------------
                // COLUMNAS ADICIONALES
                //-------------------------------------------------
                grpColumnas =
                    new System.Windows.Forms.GroupBox()
                    {
                        Text =
                            "Columnas adicionales de parámetros",
                        Left = 20,
                        Top = 420,
                        Width = 770,
                        Height = 245
                    };

                System.Windows.Forms.Label lblColumnaFija =
                    new System.Windows.Forms.Label()
                    {
                        Text =
                            "Columnas fijas: SÍMBOLO | FILTRO",
                        Left = 15,
                        Top = 25,
                        Width = 300,
                        Height = 22,
                        Font = new System.Drawing.Font(
                            "Segoe UI",
                            8.5F,
                            System.Drawing.FontStyle.Bold)
                    };

                lblColumnasAyuda =
                    new System.Windows.Forms.Label()
                    {
                        Text =
                            "Agrega hasta 5 parámetros. Escribe dentro del desplegable para buscar.",
                        Left = 330,
                        Top = 25,
                        Width = 420,
                        Height = 22,
                        TextAlign =
                            System.Drawing.ContentAlignment.MiddleRight,
                        ForeColor =
                            System.Drawing.Color.FromArgb(
                                80,
                                80,
                                80)
                    };

                pnlColumnas =
                    new System.Windows.Forms.Panel()
                    {
                        Left = 15,
                        Top = 52,
                        Width = 740,
                        Height = 145,
                        AutoScroll = true,
                        BorderStyle =
                            System.Windows.Forms.BorderStyle.FixedSingle
                    };

                btnAgregarColumna =
                    CrearBoton(
                        "+ AGREGAR COLUMNA",
                        15,
                        204,
                        170,
                        System.Drawing.Color.FromArgb(
                            35,
                            120,
                            115));

                grpColumnas.Controls.Add(
                    lblColumnaFija);

                grpColumnas.Controls.Add(
                    lblColumnasAyuda);

                grpColumnas.Controls.Add(
                    pnlColumnas);

                grpColumnas.Controls.Add(
                    btnAgregarColumna);

                //-------------------------------------------------
                // BOTONES FINALES
                //-------------------------------------------------
                btnCrear =
                    CrearBoton(
                        "CREAR LEYENDA",
                        535,
                        705,
                        125,
                        System.Drawing.Color.FromArgb(
                            180,
                            105,
                            20));

                btnCancelar =
                    CrearBoton(
                        "CANCELAR",
                        670,
                        705,
                        120,
                        System.Drawing.Color.FromArgb(
                            80,
                            80,
                            80));

                btnCrear.DialogResult =
                    System.Windows.Forms.DialogResult.OK;

                btnCancelar.DialogResult =
                    System.Windows.Forms.DialogResult.Cancel;

                this.AcceptButton =
                    btnCrear;

                this.CancelButton =
                    btnCancelar;

                //-------------------------------------------------
                // EVENTOS
                //-------------------------------------------------
                txtBuscar.TextChanged += (s, e) =>
                {
                    GuardarChecksVisibles();
                    RefrescarLista();
                };

                clbFiltros.ItemCheck += (s, e) =>
                {
                    if (actualizandoLista)
                        return;

                    FiltroVGDisponible filtro =
                        clbFiltros.Items[e.Index]
                            as FiltroVGDisponible;

                    if (filtro == null)
                        return;

                    this.BeginInvoke(
                        new System.Action(() =>
                        {
                            if (e.NewValue ==
                                System.Windows.Forms.CheckState.Checked)
                            {
                                idsSeleccionados.Add(
                                    filtro.IdFiltro);
                            }
                            else
                            {
                                idsSeleccionados.Remove(
                                    filtro.IdFiltro);
                            }

                            ActualizarResumen();
                        }));
                };

                btnTodos.Click += (s, e) =>
                {
                    idsSeleccionados.Clear();

                    foreach (FiltroVGDisponible filtro
                        in filtrosTodos)
                    {
                        if (filtro != null)
                        {
                            idsSeleccionados.Add(
                                filtro.IdFiltro);
                        }
                    }

                    RefrescarLista();
                };

                btnNinguno.Click += (s, e) =>
                {
                    idsSeleccionados.Clear();
                    RefrescarLista();
                };

                btnAgregarColumna.Click += (s, e) =>
                {
                    AgregarFilaParametro(null);
                };

                this.FormClosing += (s, e) =>
                {
                    if (this.DialogResult ==
                        System.Windows.Forms.DialogResult.OK)
                    {
                        GuardarChecksVisibles();

                        if (idsSeleccionados.Count == 0)
                        {
                            e.Cancel = true;

                            System.Windows.Forms.MessageBox.Show(
                                this,
                                "Selecciona al menos un filtro.",
                                "MYG - Leyenda VG",
                                System.Windows.Forms.MessageBoxButtons.OK,
                                System.Windows.Forms.MessageBoxIcon.Warning);

                            return;
                        }

                        //-------------------------------------------------
                        // NO PERMITIR PARÁMETROS REPETIDOS
                        //-------------------------------------------------
                        System.Collections.Generic.List<
                            ParametroDisponible>
                            parametrosSeleccionados =
                                ObtenerParametrosColumnasSeleccionados();

                        System.Collections.Generic.HashSet<string>
                            claves =
                                new System.Collections.Generic.HashSet<string>(
                                    System.StringComparer.OrdinalIgnoreCase);

                        foreach (ParametroDisponible parametro
                            in parametrosSeleccionados)
                        {
                            if (parametro == null)
                                continue;

                            if (!claves.Add(
                                parametro.Clave ?? ""))
                            {
                                e.Cancel = true;

                                System.Windows.Forms.MessageBox.Show(
                                    this,
                                    "No repitas el mismo parámetro en dos columnas.",
                                    "MYG - Leyenda VG",
                                    System.Windows.Forms.MessageBoxButtons.OK,
                                    System.Windows.Forms.MessageBoxIcon.Warning);

                                return;
                            }
                        }
                    }
                };

                //-------------------------------------------------
                // CONTROLES
                //-------------------------------------------------
                Controls.Add(lblTitulo);
                Controls.Add(lblVista);
                Controls.Add(lblBuscar);
                Controls.Add(txtBuscar);
                Controls.Add(clbFiltros);
                Controls.Add(chkLimpiarNombresMYG);
                Controls.Add(lblResumen);
                Controls.Add(btnTodos);
                Controls.Add(btnNinguno);
                Controls.Add(grpColumnas);
                Controls.Add(btnCrear);
                Controls.Add(btnCancelar);

                //-------------------------------------------------
                // UNA FILA VACÍA INICIAL PARA INVITAR A AGREGAR
                // UN SEGUNDO PARÁMETRO.
                //-------------------------------------------------
                if (parametrosTodos.Count > 0)
                {
                    AgregarFilaParametro(
                        null);
                }

                this.Shown += (s, e) =>
                {
                    RefrescarLista();

                    this.BeginInvoke(
                        new System.Action(() =>
                        {
                            VentanaRgbNativeMethods
                                .ForzarAlFrente(this);

                            txtBuscar.Focus();
                        }));
                };

                this.Activated += (s, e) =>
                {
                    VentanaRgbNativeMethods
                        .ForzarAlFrente(this);
                };
            }

            //-----------------------------------------------------
            // FILTROS SELECCIONADOS
            //-----------------------------------------------------
            public System.Collections.Generic.List<long>
                ObtenerIdsSeleccionados()
            {
                GuardarChecksVisibles();

                return idsSeleccionados
                    .OrderBy(x => x)
                    .ToList();
            }

            //-----------------------------------------------------
            // PARÁMETROS SELECCIONADOS COMO COLUMNAS
            //-----------------------------------------------------
            public System.Collections.Generic.List<
                ParametroDisponible>
                ObtenerParametrosColumnasSeleccionados()
            {
                System.Collections.Generic.List<
                    ParametroDisponible>
                    resultado =
                        new System.Collections.Generic.List<
                            ParametroDisponible>();

                System.Collections.Generic.HashSet<string>
                    vistos =
                        new System.Collections.Generic.HashSet<string>(
                            System.StringComparer.OrdinalIgnoreCase);

                foreach (System.Windows.Forms.ComboBox combo
                    in combosColumnas)
                {
                    if (combo == null)
                        continue;

                    ParametroDisponible parametro =
                        combo.SelectedItem
                            as ParametroDisponible;

                    if (parametro == null)
                    {
                        string texto =
                            combo.Text == null
                                ? ""
                                : combo.Text.Trim();

                        if (!string.IsNullOrWhiteSpace(
                            texto))
                        {
                            parametro =
                                parametrosTodos
                                    .FirstOrDefault(x =>
                                        x != null &&
                                        (
                                            string.Equals(
                                                x.ToString(),
                                                texto,
                                                System.StringComparison.OrdinalIgnoreCase) ||
                                            string.Equals(
                                                x.NombreParametro,
                                                texto,
                                                System.StringComparison.OrdinalIgnoreCase)
                                        ));
                        }
                    }

                    if (parametro == null ||
                        string.IsNullOrWhiteSpace(
                            parametro.Clave))
                    {
                        continue;
                    }

                    if (vistos.Add(
                        parametro.Clave))
                    {
                        resultado.Add(
                            parametro);
                    }
                }

                return resultado;
            }

            //-----------------------------------------------------
            // CREAR FILA DE PARÁMETRO
            //-----------------------------------------------------
            private void AgregarFilaParametro(
                ParametroDisponible seleccionado)
            {
                if (combosColumnas.Count >=
                    MAX_COLUMNAS_PARAMETROS)
                {
                    System.Windows.Forms.MessageBox.Show(
                        this,
                        "Puedes agregar como máximo 5 parámetros adicionales.",
                        "MYG - Leyenda VG",
                        System.Windows.Forms.MessageBoxButtons.OK,
                        System.Windows.Forms.MessageBoxIcon.Information);

                    return;
                }

                int indiceFila =
                    combosColumnas.Count;

                System.Windows.Forms.Label lbl =
                    new System.Windows.Forms.Label()
                    {
                        Text =
                            "Parámetro " +
                            (indiceFila + 1).ToString() +
                            ":",
                        Left = 10,
                        Top =
                            9 +
                            (indiceFila * 37),
                        Width = 90,
                        Height = 25,
                        TextAlign =
                            System.Drawing.ContentAlignment.MiddleLeft
                    };

                System.Windows.Forms.ComboBox cmb =
                    new System.Windows.Forms.ComboBox()
                    {
                        Left = 100,
                        Top =
                            7 +
                            (indiceFila * 37),
                        Width = 560,
                        Height = 27,
                        DropDownStyle =
                            System.Windows.Forms.ComboBoxStyle.DropDown,
                        IntegralHeight = false,
                        MaxDropDownItems = 15
                    };

                System.Windows.Forms.Button btnMenos =
                    new System.Windows.Forms.Button()
                    {
                        Text = "−",
                        Left = 668,
                        Top =
                            6 +
                            (indiceFila * 37),
                        Width = 42,
                        Height = 29,
                        FlatStyle =
                            System.Windows.Forms.FlatStyle.Flat,
                        BackColor =
                            System.Drawing.Color.FromArgb(
                                105,
                                105,
                                105),
                        ForeColor =
                            System.Drawing.Color.White,
                        Font = new System.Drawing.Font(
                            "Segoe UI",
                            12F,
                            System.Drawing.FontStyle.Bold),
                        Cursor =
                            System.Windows.Forms.Cursors.Hand
                    };

                btnMenos.FlatAppearance.BorderSize = 0;

                cmb.Tag =
                    lbl;

                btnMenos.Tag =
                    cmb;

                ConfigurarComboParametro(
                    cmb);

                if (seleccionado != null)
                {
                    SeleccionarParametroCombo(
                        cmb,
                        seleccionado);
                }

                btnMenos.Click += (s, e) =>
                {
                    System.Windows.Forms.Button boton =
                        s as System.Windows.Forms.Button;

                    if (boton == null)
                        return;

                    System.Windows.Forms.ComboBox combo =
                        boton.Tag
                            as System.Windows.Forms.ComboBox;

                    if (combo == null)
                        return;

                    QuitarFilaParametro(
                        combo);
                };

                combosColumnas.Add(
                    cmb);

                botonesQuitarColumnas.Add(
                    btnMenos);

                pnlColumnas.Controls.Add(
                    lbl);

                pnlColumnas.Controls.Add(
                    cmb);

                pnlColumnas.Controls.Add(
                    btnMenos);

                ReorganizarFilasParametros();

                btnAgregarColumna.Enabled =
                    combosColumnas.Count <
                    MAX_COLUMNAS_PARAMETROS;
            }

            private void QuitarFilaParametro(
                System.Windows.Forms.ComboBox combo)
            {
                if (combo == null)
                    return;

                int indice =
                    combosColumnas.IndexOf(
                        combo);

                if (indice < 0)
                    return;

                System.Windows.Forms.Label lbl =
                    combo.Tag
                        as System.Windows.Forms.Label;

                System.Windows.Forms.Button boton =
                    indice <
                        botonesQuitarColumnas.Count
                        ? botonesQuitarColumnas[
                            indice]
                        : null;

                if (lbl != null)
                {
                    pnlColumnas.Controls.Remove(
                        lbl);

                    lbl.Dispose();
                }

                pnlColumnas.Controls.Remove(
                    combo);

                combo.Dispose();

                if (boton != null)
                {
                    pnlColumnas.Controls.Remove(
                        boton);

                    boton.Dispose();
                }

                combosColumnas.RemoveAt(
                    indice);

                if (indice <
                    botonesQuitarColumnas.Count)
                {
                    botonesQuitarColumnas.RemoveAt(
                        indice);
                }

                ReorganizarFilasParametros();

                btnAgregarColumna.Enabled =
                    combosColumnas.Count <
                    MAX_COLUMNAS_PARAMETROS;
            }

            private void ReorganizarFilasParametros()
            {
                for (int i = 0;
                    i < combosColumnas.Count;
                    i++)
                {
                    System.Windows.Forms.ComboBox cmb =
                        combosColumnas[i];

                    if (cmb == null)
                        continue;

                    System.Windows.Forms.Label lbl =
                        cmb.Tag
                            as System.Windows.Forms.Label;

                    if (lbl != null)
                    {
                        lbl.Text =
                            "Parámetro " +
                            (i + 1).ToString() +
                            ":";

                        lbl.Top =
                            9 +
                            (i * 37);
                    }

                    cmb.Top =
                        7 +
                        (i * 37);

                    if (i <
                        botonesQuitarColumnas.Count &&
                        botonesQuitarColumnas[i] != null)
                    {
                        botonesQuitarColumnas[i].Top =
                            6 +
                            (i * 37);

                        botonesQuitarColumnas[i].Tag =
                            cmb;
                    }
                }
            }

            //-----------------------------------------------------
            // COMBO BUSCABLE POR CONTENIDO
            //-----------------------------------------------------
            private void ConfigurarComboParametro(
                System.Windows.Forms.ComboBox combo)
            {
                if (combo == null)
                    return;

                RefrescarItemsComboParametro(
                    combo,
                    "",
                    false);

                combo.TextUpdate += (s, e) =>
                {
                    if (actualizandoComboParametros)
                        return;

                    System.Windows.Forms.ComboBox cmb =
                        s as System.Windows.Forms.ComboBox;

                    if (cmb == null)
                        return;

                    string texto =
                        cmb.Text ?? "";

                    RefrescarItemsComboParametro(
                        cmb,
                        texto,
                        true);
                };

                combo.DropDown += (s, e) =>
                {
                    System.Windows.Forms.ComboBox cmb =
                        s as System.Windows.Forms.ComboBox;

                    if (cmb == null)
                        return;

                    if (cmb.Items.Count == 0)
                    {
                        RefrescarItemsComboParametro(
                            cmb,
                            cmb.Text ?? "",
                            false);
                    }
                };
            }

            private void RefrescarItemsComboParametro(
                System.Windows.Forms.ComboBox combo,
                string texto,
                bool abrir)
            {
                if (combo == null)
                    return;

                string busqueda =
                    texto == null
                        ? ""
                        : texto.Trim();

                ParametroDisponible seleccionado =
                    combo.SelectedItem
                        as ParametroDisponible;

                System.Collections.Generic.List<
                    ParametroDisponible>
                    coincidencias =
                        parametrosTodos
                            .Where(x =>
                                x != null &&
                                (
                                    string.IsNullOrWhiteSpace(
                                        busqueda) ||
                                    x.ToString().IndexOf(
                                        busqueda,
                                        System.StringComparison.OrdinalIgnoreCase) >= 0
                                ))
                            .Take(250)
                            .ToList();

                actualizandoComboParametros = true;

                try
                {
                    combo.BeginUpdate();
                    combo.Items.Clear();

                    foreach (ParametroDisponible item
                        in coincidencias)
                    {
                        combo.Items.Add(
                            item);
                    }

                    combo.EndUpdate();

                    combo.Text =
                        texto ?? "";

                    combo.SelectionStart =
                        combo.Text.Length;

                    combo.SelectionLength = 0;

                    if (abrir &&
                        combo.Focused &&
                        coincidencias.Count > 0)
                    {
                        combo.DroppedDown = true;

                        combo.SelectionStart =
                            combo.Text.Length;

                        combo.SelectionLength = 0;
                    }

                    if (seleccionado != null &&
                        string.IsNullOrWhiteSpace(
                            texto))
                    {
                        SeleccionarParametroCombo(
                            combo,
                            seleccionado);
                    }
                }
                finally
                {
                    actualizandoComboParametros = false;
                }
            }

            private void SeleccionarParametroCombo(
                System.Windows.Forms.ComboBox combo,
                ParametroDisponible parametro)
            {
                if (combo == null ||
                    parametro == null)
                {
                    return;
                }

                actualizandoComboParametros = true;

                try
                {
                    if (!combo.Items.Contains(
                        parametro))
                    {
                        combo.Items.Add(
                            parametro);
                    }

                    combo.SelectedItem =
                        parametro;
                }
                finally
                {
                    actualizandoComboParametros = false;
                }
            }

            //-----------------------------------------------------
            // FILTRO DE LISTA DE FILTROS
            //-----------------------------------------------------
            private void RefrescarLista()
            {
                string filtroTexto =
                    txtBuscar.Text == null
                        ? ""
                        : txtBuscar.Text.Trim();

                actualizandoLista = true;

                try
                {
                    clbFiltros.BeginUpdate();
                    clbFiltros.Items.Clear();

                    foreach (FiltroVGDisponible filtro
                        in filtrosTodos)
                    {
                        if (filtro == null)
                            continue;

                        string texto =
                            filtro.ToString();

                        if (!string.IsNullOrWhiteSpace(
                                filtroTexto) &&
                            texto.IndexOf(
                                filtroTexto,
                                System.StringComparison.OrdinalIgnoreCase) < 0)
                        {
                            continue;
                        }

                        int indice =
                            clbFiltros.Items.Add(
                                filtro);

                        clbFiltros.SetItemChecked(
                            indice,
                            idsSeleccionados.Contains(
                                filtro.IdFiltro));
                    }

                    clbFiltros.EndUpdate();
                }
                finally
                {
                    actualizandoLista = false;
                }

                ActualizarResumen();
            }

            private void GuardarChecksVisibles()
            {
                if (actualizandoLista)
                    return;

                for (int i = 0;
                    i < clbFiltros.Items.Count;
                    i++)
                {
                    FiltroVGDisponible filtro =
                        clbFiltros.Items[i]
                            as FiltroVGDisponible;

                    if (filtro == null)
                        continue;

                    if (clbFiltros.GetItemChecked(i))
                    {
                        idsSeleccionados.Add(
                            filtro.IdFiltro);
                    }
                    else
                    {
                        idsSeleccionados.Remove(
                            filtro.IdFiltro);
                    }
                }
            }

            private void ActualizarResumen()
            {
                lblResumen.Text =
                    "Seleccionados: " +
                    idsSeleccionados.Count.ToString() +
                    " de " +
                    filtrosTodos.Count.ToString();
            }

            private System.Windows.Forms.Button CrearBoton(
                string texto,
                int left,
                int top,
                int width,
                System.Drawing.Color color)
            {
                System.Windows.Forms.Button boton =
                    new System.Windows.Forms.Button()
                    {
                        Text = texto,
                        Left = left,
                        Top = top,
                        Width = width,
                        Height = 32,
                        BackColor = color,
                        ForeColor =
                            System.Drawing.Color.White,
                        FlatStyle =
                            System.Windows.Forms.FlatStyle.Flat,
                        Font = new System.Drawing.Font(
                            "Segoe UI",
                            8.1F,
                            System.Drawing.FontStyle.Bold),
                        Cursor =
                            System.Windows.Forms.Cursors.Hand
                    };

                boton.FlatAppearance.BorderSize = 0;

                return boton;
            }
        }

        public class ColorearParametroForm : System.Windows.Forms.Form
        {
            private System.Windows.Forms.ComboBox cmbParametro;
            private System.Windows.Forms.CheckBox chkParametrosTipo;
            private System.Windows.Forms.CheckBox chkSoloCategoriasModelo;
            private System.Windows.Forms.CheckBox chkIncluirSinValor;
            private System.Windows.Forms.CheckBox chkLimitarCategorias;
            private System.Windows.Forms.Button btnSeleccionarCategorias;
            private System.Windows.Forms.Label lblCategoriasSeleccionadas;
            private System.Windows.Forms.NumericUpDown nudTransparencia;

            private System.Windows.Forms.Button btnActualizarParametros;
            private System.Windows.Forms.Button btnAplicar;
            private System.Windows.Forms.Button btnCrearVista;
            private System.Windows.Forms.Button btnCrearLeyenda;
            private System.Windows.Forms.Button btnLeyendaVG;
            private System.Windows.Forms.Button btnSeleccionar;
            private System.Windows.Forms.Button btnMostrarMarcados;
            private System.Windows.Forms.Button btnMostrarTodos;
            private System.Windows.Forms.Button btnMarcarTodos;
            private System.Windows.Forms.Button btnDesmarcarTodos;
            private System.Windows.Forms.Button btnRestaurar;
            private System.Windows.Forms.Button btnCerrar;

            private LeyendaParametrosDataGridView dgvLeyenda;
            private System.Windows.Forms.Label lblVista;
            private System.Windows.Forms.Label lblResumen;
            private System.Windows.Forms.Label lblEstado;

            private System.Collections.Generic.List<ParametroDisponible> parametrosTodos =
                new System.Collections.Generic.List<ParametroDisponible>();

            private System.Collections.Generic.List<CategoriaDisponible>
                categoriasDisponiblesTodas =
                    new System.Collections.Generic.List<CategoriaDisponible>();

            private System.Collections.Generic.HashSet<long>
                categoriasSeleccionadas =
                    new System.Collections.Generic.HashSet<long>();

            private string claveParametroCategorias =
                "";

            private bool abrirSelectorCategoriasDespuesCarga;

            private System.Collections.Generic.List<FiltroVGDisponible>
                filtrosVGDisponibles =
                    new System.Collections.Generic.List<FiltroVGDisponible>();

            private System.Collections.Generic.List<ParametroDisponible>
                parametrosVGDisponibles =
                    new System.Collections.Generic.List<ParametroDisponible>();

            private string nombreVistaFiltrosVG =
                "";

            private bool permitirCierre;
            private bool cierreSolicitado;
            private bool actualizandoComboParametros;
            private bool sesionTemporalActiva;
            private bool editorColorAbierto;

            public Autodesk.Revit.UI.ExternalEvent EjecutarEvent;
            public global::MYG_Addin.ColorearParametroExternalEventHandler Handler;

            public ColorearParametroForm()
            {
                this.Text = "🎨 Filtro de Vista por Parámetros";
                this.ClientSize = new System.Drawing.Size(860, 770);
                this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
                this.MaximizeBox = false;
                this.MinimizeBox = true;
                this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
                this.Font = new System.Drawing.Font("Segoe UI", 9F);
                this.TopMost = true;

                permitirCierre = false;
                cierreSolicitado = false;

                System.Windows.Forms.Label lblAutor = new System.Windows.Forms.Label()
                {
                    Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                    Left = 20,
                    Top = 10,
                    Width = 800,
                    Height = 20,
                    Font = new System.Drawing.Font(
                        "Segoe UI",
                        8.5F,
                        System.Drawing.FontStyle.Bold),
                    ForeColor = System.Drawing.Color.Gray
                };

                System.Windows.Forms.Label lblTitulo = new System.Windows.Forms.Label()
                {
                    Text = "PANEL 2 - BOTÓN 2.8 | FILTRO DE VISTA POR PARÁMETROS",
                    Left = 20,
                    Top = 38,
                    Width = 810,
                    Height = 24,
                    Font = new System.Drawing.Font(
                        "Segoe UI",
                        10F,
                        System.Drawing.FontStyle.Bold),
                    ForeColor = System.Drawing.Color.FromArgb(45, 45, 45)
                };

                System.Windows.Forms.Label lblDescripcion = new System.Windows.Forms.Label()
                {
                    Text =
                        "Busca parámetros escribiendo directamente en el desplegable y crea filtros reales en " +
                        "Visibilidad/Gráficos para colorear sus valores. Al restaurar, elimina los filtros creados por MYG.",
                    Left = 20,
                    Top = 66,
                    Width = 810,
                    Height = 40,
                    ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
                };

                System.Windows.Forms.GroupBox grpConfiguracion = new System.Windows.Forms.GroupBox()
                {
                    Text = "Configuración del análisis",
                    Left = 20,
                    Top = 110,
                    Width = 820,
                    Height = 220,
                    ForeColor = System.Drawing.Color.FromArgb(55, 55, 55)
                };

                System.Windows.Forms.Label lblParametro = new System.Windows.Forms.Label()
                {
                    Text = "Parámetro (escribe para buscar):",
                    Left = 15,
                    Top = 27,
                    Width = 220,
                    Height = 22
                };

                cmbParametro = new System.Windows.Forms.ComboBox()
                {
                    Left = 235,
                    Top = 23,
                    Width = 565,
                    Height = 26,
                    DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown,
                    AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None,
                    AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None,
                    IntegralHeight = false,
                    MaxDropDownItems = 18
                };

                chkParametrosTipo = new System.Windows.Forms.CheckBox()
                {
                    Text = "Incluir parámetros de tipo",
                    Left = 15,
                    Top = 62,
                    Width = 230,
                    Height = 24,
                    Checked = true
                };

                chkSoloCategoriasModelo = new System.Windows.Forms.CheckBox()
                {
                    Text = "Solo categorías de modelo",
                    Left = 260,
                    Top = 62,
                    Width = 230,
                    Height = 24,
                    Checked = true
                };

                chkIncluirSinValor = new System.Windows.Forms.CheckBox()
                {
                    Text = "Incluir elementos sin valor",
                    Left = 505,
                    Top = 62,
                    Width = 295,
                    Height = 24,
                    Checked = true
                };

                chkLimitarCategorias = new System.Windows.Forms.CheckBox()
                {
                    Text = "Limitar a categorías seleccionadas",
                    Left = 15,
                    Top = 96,
                    Width = 245,
                    Height = 24,
                    Checked = false
                };

                btnSeleccionarCategorias = CrearBoton(
                    "SELECCIONAR CATEGORÍAS...",
                    265,
                    92,
                    225,
                    System.Drawing.Color.FromArgb(70, 105, 145));

                btnSeleccionarCategorias.Height = 30;
                btnSeleccionarCategorias.Enabled = false;

                lblCategoriasSeleccionadas =
                    new System.Windows.Forms.Label()
                    {
                        Text = "Todas las categorías compatibles",
                        Left = 500,
                        Top = 132,
                        Width = 300,
                        Height = 22,
                        TextAlign =
                            System.Drawing.ContentAlignment.MiddleRight,
                        ForeColor =
                            System.Drawing.Color.FromArgb(80, 80, 80)
                    };

                System.Windows.Forms.Label lblTransparencia = new System.Windows.Forms.Label()
                {
                    Text = "Transparencia de color:",
                    Left = 15,
                    Top = 135,
                    Width = 170,
                    Height = 22
                };

                nudTransparencia = new System.Windows.Forms.NumericUpDown()
                {
                    Left = 185,
                    Top = 97,
                    Width = 70,
                    Height = 25,
                    Minimum = 0,
                    Maximum = 90,
                    Increment = 5,
                    Value = 0,
                    TextAlign = System.Windows.Forms.HorizontalAlignment.Center
                };

                System.Windows.Forms.Label lblPorcentaje = new System.Windows.Forms.Label()
                {
                    Text = "%",
                    Left = 260,
                    Top = 135,
                    Width = 25,
                    Height = 22
                };

                btnActualizarParametros = CrearBoton(
                    "ACTUALIZAR",
                    15,
                    170,
                    120,
                    System.Drawing.Color.FromArgb(90, 90, 90));

                btnAplicar = CrearBoton(
                    "CREAR FILTROS",
                    145,
                    170,
                    125,
                    System.Drawing.Color.FromArgb(0, 120, 215));

                btnCrearVista = CrearBoton(
                    "CREAR VISTA",
                    280,
                    170,
                    115,
                    System.Drawing.Color.FromArgb(120, 75, 170));

                btnCrearLeyenda = CrearBoton(
                    "CREAR LEYENDA",
                    405,
                    170,
                    130,
                    System.Drawing.Color.FromArgb(180, 105, 20));

                btnLeyendaVG = CrearBoton(
                    "LEYENDA VG",
                    545,
                    170,
                    120,
                    System.Drawing.Color.FromArgb(35, 120, 115));

                lblVista = new System.Windows.Forms.Label()
                {
                    Text = "Vista 3D: pendiente",
                    Left = 675,
                    Top = 173,
                    Width = 125,
                    Height = 22,
                    TextAlign = System.Drawing.ContentAlignment.MiddleRight,
                    ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
                };

                grpConfiguracion.Controls.Add(lblParametro);
                grpConfiguracion.Controls.Add(cmbParametro);
                grpConfiguracion.Controls.Add(chkParametrosTipo);
                grpConfiguracion.Controls.Add(chkSoloCategoriasModelo);
                grpConfiguracion.Controls.Add(chkIncluirSinValor);
                grpConfiguracion.Controls.Add(chkLimitarCategorias);
                grpConfiguracion.Controls.Add(btnSeleccionarCategorias);
                grpConfiguracion.Controls.Add(lblCategoriasSeleccionadas);
                grpConfiguracion.Controls.Add(lblTransparencia);
                grpConfiguracion.Controls.Add(nudTransparencia);
                grpConfiguracion.Controls.Add(lblPorcentaje);
                grpConfiguracion.Controls.Add(btnActualizarParametros);
                grpConfiguracion.Controls.Add(btnAplicar);
                grpConfiguracion.Controls.Add(btnCrearVista);
                grpConfiguracion.Controls.Add(btnCrearLeyenda);
                grpConfiguracion.Controls.Add(btnLeyendaVG);
                grpConfiguracion.Controls.Add(lblVista);

                System.Windows.Forms.Label lblLeyenda = new System.Windows.Forms.Label()
                {
                    Text = "LEYENDA DE VALORES",
                    Left = 20,
                    Top = 342,
                    Width = 300,
                    Height = 22,
                    Font = new System.Drawing.Font(
                        "Segoe UI",
                        9F,
                        System.Drawing.FontStyle.Bold),
                    ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
                };

                lblResumen = new System.Windows.Forms.Label()
                {
                    Text = "Todavía no se ha aplicado ningún análisis.",
                    Left = 325,
                    Top = 342,
                    Width = 515,
                    Height = 22,
                    TextAlign = System.Drawing.ContentAlignment.MiddleRight,
                    ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
                };

                dgvLeyenda = new LeyendaParametrosDataGridView()
                {
                    Left = 20,
                    Top = 368,
                    Width = 820,
                    Height = 260,
                    AllowUserToAddRows = false,
                    AllowUserToDeleteRows = false,
                    AllowUserToResizeRows = false,
                    MultiSelect = true,
                    ReadOnly = false,
                    RowHeadersVisible = false,
                    SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect,
                    BackgroundColor = System.Drawing.Color.White,
                    BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                    AutoGenerateColumns = false,
                    ShowCellToolTips = true
                };

                System.Windows.Forms.DataGridViewCheckBoxColumn colMostrar =
                    new System.Windows.Forms.DataGridViewCheckBoxColumn()
                    {
                        Name = "Mostrar",
                        HeaderText = "Mostrar",
                        Width = 65,
                        ReadOnly = false,
                        TrueValue = true,
                        FalseValue = false
                    };

                System.Windows.Forms.DataGridViewButtonColumn colColor =
                    new System.Windows.Forms.DataGridViewButtonColumn()
                    {
                        Name = "Color",
                        HeaderText = "Color",
                        Width = 105,
                        ReadOnly = true,
                        FlatStyle = System.Windows.Forms.FlatStyle.Popup,
                        UseColumnTextForButtonValue = false,
                        SortMode =
                            System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
                    };

                colColor.DefaultCellStyle.Alignment =
                    System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;

                colColor.DefaultCellStyle.Font =
                    new System.Drawing.Font(
                        "Segoe UI",
                        8F,
                        System.Drawing.FontStyle.Bold);

                System.Windows.Forms.DataGridViewTextBoxColumn colValor =
                    new System.Windows.Forms.DataGridViewTextBoxColumn()
                    {
                        Name = "Valor",
                        HeaderText = "Valor del parámetro",
                        Width = 435,
                        ReadOnly = true
                    };

                System.Windows.Forms.DataGridViewTextBoxColumn colCantidad =
                    new System.Windows.Forms.DataGridViewTextBoxColumn()
                    {
                        Name = "Cantidad",
                        HeaderText = "Cantidad",
                        Width = 90,
                        ReadOnly = true
                    };

                System.Windows.Forms.DataGridViewTextBoxColumn colPorcentaje =
                    new System.Windows.Forms.DataGridViewTextBoxColumn()
                    {
                        Name = "Porcentaje",
                        HeaderText = "%",
                        Width = 85,
                        ReadOnly = true
                    };

                dgvLeyenda.Columns.Add(colMostrar);
                dgvLeyenda.Columns.Add(colColor);
                dgvLeyenda.Columns.Add(colValor);
                dgvLeyenda.Columns.Add(colCantidad);
                dgvLeyenda.Columns.Add(colPorcentaje);

                btnSeleccionar = CrearBoton(
                    "SELECCIONAR FILAS",
                    20,
                    620,
                    160,
                    System.Drawing.Color.FromArgb(45, 105, 170));

                btnMostrarMarcados = CrearBoton(
                    "MOSTRAR MARCADOS",
                    190,
                    620,
                    165,
                    System.Drawing.Color.FromArgb(22, 120, 90));

                btnMostrarTodos = CrearBoton(
                    "MOSTRAR TODOS",
                    365,
                    620,
                    135,
                    System.Drawing.Color.FromArgb(90, 90, 90));

                btnMarcarTodos = CrearBoton(
                    "MARCAR",
                    510,
                    620,
                    90,
                    System.Drawing.Color.FromArgb(105, 105, 105));

                btnDesmarcarTodos = CrearBoton(
                    "DESMARCAR",
                    610,
                    620,
                    105,
                    System.Drawing.Color.FromArgb(105, 105, 105));

                btnRestaurar = CrearBoton(
                    "RESTAURAR",
                    725,
                    620,
                    115,
                    System.Drawing.Color.FromArgb(180, 85, 30));

                btnCerrar = CrearBoton(
                    "CERRAR",
                    725,
                    665,
                    115,
                    System.Drawing.Color.FromArgb(70, 70, 70));

                lblEstado = new System.Windows.Forms.Label()
                {
                    Text = "Abre una vista 3D y espera la carga de parámetros.",
                    Left = 20,
                    Top = 690,
                    Width = 690,
                    Height = 32,
                    ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
                };

                Controls.Add(lblAutor);
                Controls.Add(lblTitulo);
                Controls.Add(lblDescripcion);
                Controls.Add(grpConfiguracion);
                Controls.Add(lblLeyenda);
                Controls.Add(lblResumen);
                Controls.Add(dgvLeyenda);
                Controls.Add(btnSeleccionar);
                Controls.Add(btnMostrarMarcados);
                Controls.Add(btnMostrarTodos);
                Controls.Add(btnMarcarTodos);
                Controls.Add(btnDesmarcarTodos);
                Controls.Add(btnRestaurar);
                Controls.Add(btnCerrar);
                Controls.Add(lblEstado);

                cmbParametro.TextUpdate += (s, e) =>
                {
                    FiltrarParametrosMientrasEscribe();
                };

                cmbParametro.KeyDown += (s, e) =>
                {
                    if (e.KeyCode == System.Windows.Forms.Keys.Enter)
                    {
                        ParametroDisponible encontrado =
                            ResolverParametroSeleccionado();

                        if (encontrado != null)
                        {
                            SeleccionarParametroEnCombo(encontrado);
                            cmbParametro.DroppedDown = false;
                            InvalidarCategorias();

                            if (chkLimitarCategorias.Checked)
                                SolicitarCargaCategorias(false);

                            e.Handled = true;
                            e.SuppressKeyPress = true;
                        }
                    }
                };

                cmbParametro.SelectionChangeCommitted += (s, e) =>
                {
                    InvalidarCategorias();

                    if (chkLimitarCategorias.Checked)
                        SolicitarCargaCategorias(false);
                };

                chkParametrosTipo.CheckedChanged += (s, e) =>
                {
                    InvalidarCategorias();
                    SolicitarCargaParametros();
                };

                chkSoloCategoriasModelo.CheckedChanged += (s, e) =>
                {
                    InvalidarCategorias();
                    SolicitarCargaParametros();
                };

                chkLimitarCategorias.CheckedChanged += (s, e) =>
                {
                    btnSeleccionarCategorias.Enabled =
                        chkLimitarCategorias.Checked;

                    if (chkLimitarCategorias.Checked)
                    {
                        SolicitarCargaCategorias(true);
                    }
                    else
                    {
                        lblCategoriasSeleccionadas.Text =
                            "Todas las categorías compatibles";
                    }
                };

                btnSeleccionarCategorias.Click += (s, e) =>
                {
                    AbrirSelectorCategorias();
                };

                btnActualizarParametros.Click += (s, e) =>
                {
                    SolicitarCargaParametros();
                };

                btnAplicar.Click += (s, e) =>
                {
                    SolicitarAplicarColores();
                };

                btnCrearVista.Click += (s, e) =>
                {
                    SolicitarCrearVistaPermanente();
                };

                btnCrearLeyenda.Click += (s, e) =>
                {
                    SolicitarCrearLeyenda();
                };

                btnLeyendaVG.Click += (s, e) =>
                {
                    SolicitarCargarFiltrosVG();
                };

                btnSeleccionar.Click += (s, e) =>
                {
                    SolicitarSeleccionFilas();
                };

                btnMostrarMarcados.Click += (s, e) =>
                {
                    SolicitarAislarMarcados();
                };

                btnMostrarTodos.Click += (s, e) =>
                {
                    SolicitarMostrarTodos();
                };

                btnMarcarTodos.Click += (s, e) =>
                {
                    MarcarTodasLasFilas(true);
                };

                btnDesmarcarTodos.Click += (s, e) =>
                {
                    MarcarTodasLasFilas(false);
                };

                btnRestaurar.Click += (s, e) =>
                {
                    SolicitarRestaurar(false);
                };

                btnCerrar.Click += (s, e) =>
                {
                    this.Close();
                };

                dgvLeyenda.CellMouseDown += (s, e) =>
                {
                    if (e.Button !=
                            System.Windows.Forms.MouseButtons.Left ||
                        e.RowIndex < 0 ||
                        e.ColumnIndex < 0 ||
                        e.ColumnIndex >= dgvLeyenda.Columns.Count ||
                        !string.Equals(
                            dgvLeyenda.Columns[e.ColumnIndex].Name,
                            "Color",
                            System.StringComparison.OrdinalIgnoreCase))
                    {
                        return;
                    }

                    dgvLeyenda.Cursor =
                        System.Windows.Forms.Cursors.Hand;

                    System.Windows.Forms.Cursor.Current =
                        System.Windows.Forms.Cursors.Hand;

                    ProgramarAperturaEditorRgb(
                        e.RowIndex);
                };

                dgvLeyenda.CellToolTipTextNeeded += (s, e) =>
                {
                    if (e.RowIndex >= 0 &&
                        e.ColumnIndex >= 0 &&
                        e.ColumnIndex < dgvLeyenda.Columns.Count &&
                        string.Equals(
                            dgvLeyenda.Columns[e.ColumnIndex].Name,
                            "Color",
                            System.StringComparison.OrdinalIgnoreCase))
                    {
                        e.ToolTipText =
                            "Haz clic para cambiar el color RGB";
                    }
                };

                dgvLeyenda.CurrentCellDirtyStateChanged += (s, e) =>
                {
                    if (dgvLeyenda.IsCurrentCellDirty)
                    {
                        dgvLeyenda.CommitEdit(
                            System.Windows.Forms.DataGridViewDataErrorContexts.Commit);
                    }
                };

                this.Shown += (s, e) =>
                {
                    SolicitarCargaParametros();
                };

                this.FormClosing += ColorearParametroForm_FormClosing;

                ActualizarHabilitacion(false);
            }

            private System.Windows.Forms.Button CrearBoton(
                string texto,
                int left,
                int top,
                int width,
                System.Drawing.Color color)
            {
                System.Windows.Forms.Button boton = new System.Windows.Forms.Button()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 34,
                    BackColor = color,
                    ForeColor = System.Drawing.Color.White,
                    FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                    Font = new System.Drawing.Font(
                        "Segoe UI",
                        8.3F,
                        System.Drawing.FontStyle.Bold),
                    Cursor = System.Windows.Forms.Cursors.Hand
                };

                boton.FlatAppearance.BorderSize = 0;
                return boton;
            }

            private void ColorearParametroForm_FormClosing(
                object sender,
                System.Windows.Forms.FormClosingEventArgs e)
            {
                if (permitirCierre)
                    return;

                if (!sesionTemporalActiva)
                {
                    permitirCierre = true;
                    return;
                }

                if (EjecutarEvent == null || Handler == null)
                {
                    permitirCierre = true;
                    return;
                }

                e.Cancel = true;

                if (cierreSolicitado)
                    return;

                cierreSolicitado = true;
                MostrarEstado("Restaurando la vista temporal antes de cerrar...", false);
                SolicitarRestaurar(true);
            }

            private void SolicitarCargaParametros()
            {
                InvalidarCategorias();

                if (EjecutarEvent == null || Handler == null)
                {
                    MostrarEstado("ERROR: No se pudo inicializar el evento externo.", true);
                    return;
                }

                Handler.FormInicial = this;
                Handler.IncluirParametrosTipo = chkParametrosTipo.Checked;
                Handler.SoloCategoriasModelo = chkSoloCategoriasModelo.Checked;
                Handler.Operacion = ColorearParametroOperacion.CargarParametros;

                SetProcesando(true, "Analizando elementos visibles y parámetros...");
                EjecutarEvent.Raise();
            }

            private void SolicitarCargaCategorias(
                bool abrirSelector)
            {
                ParametroDisponible parametro =
                    ResolverParametroSeleccionado();

                if (parametro == null)
                {
                    if (abrirSelector)
                    {
                        MostrarEstado(
                            "Selecciona primero un parámetro válido.",
                            true);
                    }

                    return;
                }

                if (EjecutarEvent == null ||
                    Handler == null)
                {
                    MostrarEstado(
                        "ERROR: No se pudo inicializar el evento externo.",
                        true);

                    return;
                }

                abrirSelectorCategoriasDespuesCarga =
                    abrirSelector;

                Handler.FormInicial = this;
                Handler.ParametroSeleccionado =
                    parametro;
                Handler.IncluirParametrosTipo =
                    chkParametrosTipo.Checked;
                Handler.SoloCategoriasModelo =
                    chkSoloCategoriasModelo.Checked;
                Handler.Operacion =
                    ColorearParametroOperacion
                        .CargarCategorias;

                SetProcesando(
                    true,
                    "Analizando categorías compatibles del anfitrión y vínculos...");

                EjecutarEvent.Raise();
            }

            private void AbrirSelectorCategorias()
            {
                if (!chkLimitarCategorias.Checked)
                    return;

                ParametroDisponible parametro =
                    ResolverParametroSeleccionado();

                if (parametro == null)
                {
                    MostrarEstado(
                        "Selecciona primero un parámetro válido.",
                        true);

                    return;
                }

                if (categoriasDisponiblesTodas.Count == 0 ||
                    !string.Equals(
                        claveParametroCategorias,
                        parametro.Clave,
                        System.StringComparison.OrdinalIgnoreCase))
                {
                    SolicitarCargaCategorias(true);
                    return;
                }

                MostrarSelectorCategorias();
            }

            private void MostrarSelectorCategorias()
            {
                using (SeleccionarCategoriasForm form =
                    new SeleccionarCategoriasForm(
                        categoriasDisponiblesTodas,
                        categoriasSeleccionadas))
                {
                    bool topMostPrincipal =
                        this.TopMost;

                    try
                    {
                        this.TopMost = false;
                        form.TopMost = true;
                        form.Owner = this;
                        form.StartPosition =
                            System.Windows.Forms.FormStartPosition.Manual;

                        form.Location =
                            new System.Drawing.Point(
                                this.Left +
                                    ((this.Width - form.Width) / 2),
                                this.Top +
                                    ((this.Height - form.Height) / 2));

                        VentanaRgbNativeMethods
                            .ForzarAlFrente(form);

                        if (form.ShowDialog(this) !=
                            System.Windows.Forms.DialogResult.OK)
                        {
                            return;
                        }

                        categoriasSeleccionadas =
                            new System.Collections.Generic.HashSet<long>(
                                form.ObtenerIdsSeleccionados());

                        foreach (CategoriaDisponible categoria
                            in categoriasDisponiblesTodas)
                        {
                            if (categoria != null)
                            {
                                categoria.Seleccionada =
                                    categoriasSeleccionadas.Contains(
                                        categoria.IdCategoria);
                            }
                        }

                        ActualizarResumenCategorias();
                    }
                    finally
                    {
                        this.TopMost =
                            topMostPrincipal;

                        VentanaRgbNativeMethods
                            .ForzarAlFrente(this);
                    }
                }
            }

            private void InvalidarCategorias()
            {
                categoriasDisponiblesTodas =
                    new System.Collections.Generic.List<CategoriaDisponible>();

                categoriasSeleccionadas =
                    new System.Collections.Generic.HashSet<long>();

                claveParametroCategorias = "";

                lblCategoriasSeleccionadas.Text =
                    chkLimitarCategorias != null &&
                    chkLimitarCategorias.Checked
                        ? "Pendiente de seleccionar"
                        : "Todas las categorías compatibles";
            }

            private void ActualizarResumenCategorias()
            {
                if (!chkLimitarCategorias.Checked)
                {
                    lblCategoriasSeleccionadas.Text =
                        "Todas las categorías compatibles";

                    return;
                }

                lblCategoriasSeleccionadas.Text =
                    categoriasSeleccionadas.Count.ToString() +
                    " de " +
                    categoriasDisponiblesTodas.Count.ToString() +
                    " categorías";
            }

            private System.Collections.Generic.List<long>
                ObtenerCategoriasSeleccionadas()
            {
                return categoriasSeleccionadas
                    .OrderBy(x => x)
                    .ToList();
            }

            private void SolicitarAplicarColores()
            {
                ParametroDisponible parametro =
                    ResolverParametroSeleccionado();

                if (parametro == null)
                {
                    MostrarEstado(
                        "Escribe y selecciona un único parámetro de la lista antes de aplicar los filtros.",
                        true);
                    return;
                }

                SeleccionarParametroEnCombo(parametro);

                if (chkLimitarCategorias.Checked &&
                    categoriasSeleccionadas.Count == 0)
                {
                    MostrarEstado(
                        "Marca al menos una categoría compatible.",
                        true);

                    AbrirSelectorCategorias();
                    return;
                }

                if (EjecutarEvent == null || Handler == null)
                {
                    MostrarEstado("ERROR: No se pudo inicializar el evento externo.", true);
                    return;
                }

                Handler.FormInicial = this;
                Handler.ParametroSeleccionado = parametro;
                Handler.IncluirSinValor = chkIncluirSinValor.Checked;
                Handler.IncluirParametrosTipo = chkParametrosTipo.Checked;
                Handler.SoloCategoriasModelo = chkSoloCategoriasModelo.Checked;
                Handler.LimitarCategorias =
                    chkLimitarCategorias.Checked;
                Handler.CategoriasSeleccionadas =
                    ObtenerCategoriasSeleccionadas();
                Handler.Transparencia = System.Convert.ToInt32(nudTransparencia.Value);
                Handler.Operacion = ColorearParametroOperacion.AplicarColores;

                SetProcesando(true, "Creando filtros en Visibilidad/Gráficos y aplicando colores...");
                EjecutarEvent.Raise();
            }

            private void ProgramarAperturaEditorRgb(
                int indiceFila)
            {
                if (editorColorAbierto)
                    return;

                editorColorAbierto = true;

                this.BeginInvoke(new System.Action(() =>
                {
                    try
                    {
                        AbrirEditorRgbFila(
                            indiceFila);
                    }
                    finally
                    {
                        editorColorAbierto = false;

                        if (!this.IsDisposed)
                        {
                            this.BringToFront();
                            this.Activate();
                        }
                    }
                }));
            }

            private void AbrirEditorRgbFila(int indiceFila)
            {
                if (indiceFila < 0 ||
                    indiceFila >= dgvLeyenda.Rows.Count)
                {
                    return;
                }

                System.Windows.Forms.DataGridViewRow fila =
                    dgvLeyenda.Rows[indiceFila];

                string clave = fila.Tag as string;

                if (string.IsNullOrWhiteSpace(clave))
                    return;

                int[] rgb =
                    fila.Cells["Color"].Tag as int[];

                int rojo = rgb != null && rgb.Length > 0
                    ? rgb[0]
                    : 128;

                int verde = rgb != null && rgb.Length > 1
                    ? rgb[1]
                    : 128;

                int azul = rgb != null && rgb.Length > 2
                    ? rgb[2]
                    : 128;

                using (SelectorColorRgbForm form =
                    new SelectorColorRgbForm(
                        rojo,
                        verde,
                        azul))
                {
                    bool topMostPrincipal =
                        this.TopMost;

                    try
                    {
                        this.TopMost = false;

                        form.ShowInTaskbar = false;
                        form.TopMost = true;
                        form.Owner = this;
                        form.StartPosition =
                            System.Windows.Forms.FormStartPosition.Manual;

                        int left =
                            this.Left +
                            ((this.Width - form.Width) / 2);

                        int top =
                            this.Top +
                            ((this.Height - form.Height) / 2);

                        form.Location =
                            new System.Drawing.Point(
                                left,
                                top);

                        form.Shown += (s, e) =>
                        {
                            form.BeginInvoke(
                                new System.Action(() =>
                                {
                                    VentanaRgbNativeMethods
                                        .ForzarAlFrente(form);
                                }));
                        };

                        VentanaRgbNativeMethods
                            .ForzarAlFrente(form);

                        if (form.ShowDialog(this) !=
                            System.Windows.Forms.DialogResult.OK)
                        {
                            return;
                        }
                    }
                    finally
                    {
                        this.TopMost =
                            topMostPrincipal;

                        VentanaRgbNativeMethods
                            .ForzarAlFrente(this);
                    }

                    if (EjecutarEvent == null ||
                        Handler == null)
                    {
                        MostrarEstado(
                            "ERROR: No se pudo inicializar el evento externo.",
                            true);

                        return;
                    }

                    Handler.FormInicial = this;
                    Handler.ClaveColorSolicitada = clave;
                    Handler.RojoSolicitado = form.Rojo;
                    Handler.VerdeSolicitado = form.Verde;
                    Handler.AzulSolicitado = form.Azul;
                    Handler.Operacion =
                        ColorearParametroOperacion.ActualizarColor;

                    SetProcesando(
                        true,
                        "Actualizando RGB del filtro seleccionado...");

                    EjecutarEvent.Raise();
                }
            }

            private void SolicitarCrearVistaPermanente()
            {
                if (dgvLeyenda.Rows.Count == 0)
                {
                    MostrarEstado(
                        "Primero crea los filtros de la vista.",
                        true);

                    return;
                }

                if (EjecutarEvent == null ||
                    Handler == null)
                {
                    MostrarEstado(
                        "ERROR: No se pudo inicializar el evento externo.",
                        true);

                    return;
                }

                ParametroDisponible parametro =
                    ResolverParametroSeleccionado();

                string nombreParametro =
                    parametro != null
                        ? parametro.NombreParametro
                        : "Parámetro";

                string nombreSugerido =
                    "FVP - " + nombreParametro;

                string nombreVistaConfirmado = "";

                using (NombreVistaPermanenteForm form =
                    new NombreVistaPermanenteForm(
                        nombreSugerido))
                {
                    bool topMostPrincipal =
                        this.TopMost;

                    System.Windows.Forms.DialogResult resultado =
                        System.Windows.Forms.DialogResult.Cancel;

                    try
                    {
                        //-------------------------------------------------
                        // EVITAR QUE LA VENTANA PRINCIPAL TAPE AL DIÁLOGO
                        //-------------------------------------------------
                        this.TopMost = false;

                        form.ShowInTaskbar = false;
                        form.TopMost = true;
                        form.Owner = this;
                        form.StartPosition =
                            System.Windows.Forms.FormStartPosition.Manual;

                        //-------------------------------------------------
                        // CENTRAR EL DIÁLOGO SOBRE LA VENTANA PRINCIPAL
                        //-------------------------------------------------
                        int left =
                            this.Left +
                            ((this.Width - form.Width) / 2);

                        int top =
                            this.Top +
                            ((this.Height - form.Height) / 2);

                        form.Location =
                            new System.Drawing.Point(
                                left,
                                top);

                        //-------------------------------------------------
                        // FORZAR EL DIÁLOGO POR ENCIMA DE REVIT
                        //-------------------------------------------------
                        form.Shown += (s, e) =>
                        {
                            form.BeginInvoke(
                                new System.Action(() =>
                                {
                                    VentanaRgbNativeMethods
                                        .ForzarAlFrente(form);
                                }));
                        };

                        VentanaRgbNativeMethods
                            .ForzarAlFrente(form);

                        resultado =
                            form.ShowDialog(this);

                        if (resultado ==
                            System.Windows.Forms.DialogResult.OK)
                        {
                            nombreVistaConfirmado =
                                form.NombreVista;
                        }
                    }
                    finally
                    {
                        //-------------------------------------------------
                        // RECUPERAR LA VENTANA PRINCIPAL
                        //-------------------------------------------------
                        this.TopMost =
                            topMostPrincipal;

                        VentanaRgbNativeMethods
                            .ForzarAlFrente(this);
                    }

                    if (resultado !=
                        System.Windows.Forms.DialogResult.OK)
                    {
                        MostrarEstado(
                            "Creación de vista cancelada.",
                            false);

                        return;
                    }
                }

                if (string.IsNullOrWhiteSpace(
                    nombreVistaConfirmado))
                {
                    MostrarEstado(
                        "No se recibió un nombre válido para la vista.",
                        true);

                    return;
                }

                Handler.FormInicial = this;
                Handler.NombreVistaPermanenteSolicitado =
                    nombreVistaConfirmado;

                Handler.Operacion =
                    ColorearParametroOperacion
                        .CrearVistaPermanente;

                SetProcesando(
                    true,
                    "Creando vista 3D permanente con filtros y colores...");

                EjecutarEvent.Raise();
            }

            private void SolicitarCrearLeyenda()
            {
                ParametroDisponible parametro =
                    ResolverParametroSeleccionado();

                if (parametro == null)
                {
                    MostrarEstado(
                        "Selecciona un parámetro antes de crear la leyenda.",
                        true);

                    return;
                }

                if (dgvLeyenda.Rows.Count == 0)
                {
                    MostrarEstado(
                        "Primero crea los filtros para generar los valores y colores de la leyenda.",
                        true);

                    return;
                }

                if (EjecutarEvent == null ||
                    Handler == null)
                {
                    MostrarEstado(
                        "ERROR: No se pudo inicializar el evento externo.",
                        true);

                    return;
                }

                Handler.FormInicial = this;
                Handler.ParametroSeleccionado =
                    parametro;

                Handler.Operacion =
                    ColorearParametroOperacion
                        .CrearLeyenda;

                SetProcesando(
                    true,
                    "Creando leyenda permanente con cuadrados de color...");

                EjecutarEvent.Raise();
            }

            private void SolicitarCargarFiltrosVG()
            {
                if (EjecutarEvent == null ||
                    Handler == null)
                {
                    MostrarEstado(
                        "ERROR: No se pudo inicializar el evento externo.",
                        true);

                    return;
                }

                Handler.FormInicial = this;
                Handler.Operacion =
                    ColorearParametroOperacion
                        .CargarFiltrosVG;

                SetProcesando(
                    true,
                    "Leyendo los filtros de Visibilidad/Gráficos de la vista activa...");

                EjecutarEvent.Raise();
            }

            private void MostrarSelectorFiltrosVG()
            {
                if (filtrosVGDisponibles == null ||
                    filtrosVGDisponibles.Count == 0)
                {
                    MostrarEstado(
                        "La vista activa no tiene filtros aplicados en Visibilidad/Gráficos.",
                        true);

                    return;
                }

                using (SeleccionarFiltrosVGForm form =
                    new SeleccionarFiltrosVGForm(
                        filtrosVGDisponibles,
                        parametrosVGDisponibles,
                        nombreVistaFiltrosVG))
                {
                    bool topMostPrincipal =
                        this.TopMost;

                    System.Windows.Forms.DialogResult resultado =
                        System.Windows.Forms.DialogResult.Cancel;

                    try
                    {
                        this.TopMost = false;

                        form.TopMost = true;
                        form.Owner = this;
                        form.StartPosition =
                            System.Windows.Forms.FormStartPosition.Manual;

                        form.Location =
                            new System.Drawing.Point(
                                this.Left +
                                    ((this.Width - form.Width) / 2),
                                this.Top +
                                    ((this.Height - form.Height) / 2));

                        VentanaRgbNativeMethods
                            .ForzarAlFrente(form);

                        resultado =
                            form.ShowDialog(this);

                        if (resultado !=
                            System.Windows.Forms.DialogResult.OK)
                        {
                            MostrarEstado(
                                "Creación de leyenda VG cancelada.",
                                false);

                            return;
                        }

                        if (EjecutarEvent == null ||
                            Handler == null)
                        {
                            MostrarEstado(
                                "ERROR: No se pudo inicializar el evento externo.",
                                true);

                            return;
                        }

                        Handler.FormInicial = this;
                        Handler.FiltrosVGSeleccionados =
                            form.ObtenerIdsSeleccionados();

                        Handler.ParametrosColumnasVG =
                            form.ObtenerParametrosColumnasSeleccionados();

                        Handler.LimpiarNombresFiltrosMYG =
                            form.LimpiarNombresMYG;

                        Handler.Operacion =
                            ColorearParametroOperacion
                                .CrearLeyendaVG;

                        SetProcesando(
                            true,
                            "Creando leyenda de los filtros VG seleccionados...");

                        EjecutarEvent.Raise();
                    }
                    finally
                    {
                        this.TopMost =
                            topMostPrincipal;

                        VentanaRgbNativeMethods
                            .ForzarAlFrente(this);
                    }
                }
            }

            private void SolicitarSeleccionFilas()
            {
                System.Collections.Generic.List<string> claves =
                    ObtenerClavesFilasSeleccionadas();

                if (claves.Count == 0)
                {
                    MostrarEstado("Selecciona una o más filas de la leyenda.", true);
                    return;
                }

                Handler.ClavesValoresSolicitados = claves;
                Handler.Operacion = ColorearParametroOperacion.SeleccionarFilas;

                SetProcesando(true, "Seleccionando elementos en Revit...");
                EjecutarEvent.Raise();
            }

            private void SolicitarAislarMarcados()
            {
                System.Collections.Generic.List<string> claves =
                    ObtenerClavesMarcadas();

                if (claves.Count == 0)
                {
                    MostrarEstado("Marca al menos un valor de la leyenda.", true);
                    return;
                }

                Handler.ClavesValoresSolicitados = claves;
                Handler.Operacion = ColorearParametroOperacion.AislarMarcados;

                SetProcesando(true, "Aislando temporalmente los valores marcados...");
                EjecutarEvent.Raise();
            }

            private void SolicitarMostrarTodos()
            {
                if (EjecutarEvent == null || Handler == null)
                    return;

                Handler.Operacion = ColorearParametroOperacion.MostrarTodos;
                SetProcesando(true, "Restaurando la visibilidad de todos los valores...");
                EjecutarEvent.Raise();
            }

            private void SolicitarRestaurar(bool cerrarDespues)
            {
                if (EjecutarEvent == null || Handler == null)
                {
                    if (cerrarDespues)
                    {
                        permitirCierre = true;
                        this.Close();
                    }

                    return;
                }

                Handler.Operacion = cerrarDespues
                    ? ColorearParametroOperacion.RestaurarYCerrar
                    : ColorearParametroOperacion.Restaurar;

                SetProcesando(true, "Restaurando propiedades temporales de la vista...");
                EjecutarEvent.Raise();
            }

            private System.Collections.Generic.List<string>
                ObtenerClavesFilasSeleccionadas()
            {
                System.Collections.Generic.List<string> resultado =
                    new System.Collections.Generic.List<string>();

                foreach (System.Windows.Forms.DataGridViewRow fila
                    in dgvLeyenda.SelectedRows)
                {
                    string clave = fila.Tag as string;

                    if (!string.IsNullOrWhiteSpace(clave) &&
                        !resultado.Contains(clave))
                    {
                        resultado.Add(clave);
                    }
                }

                return resultado;
            }

            private System.Collections.Generic.List<string> ObtenerClavesMarcadas()
            {
                System.Collections.Generic.List<string> resultado =
                    new System.Collections.Generic.List<string>();

                foreach (System.Windows.Forms.DataGridViewRow fila in dgvLeyenda.Rows)
                {
                    bool marcado = false;

                    if (fila.Cells["Mostrar"].Value != null)
                    {
                        bool.TryParse(
                            fila.Cells["Mostrar"].Value.ToString(),
                            out marcado);
                    }

                    string clave = fila.Tag as string;

                    if (marcado &&
                        !string.IsNullOrWhiteSpace(clave) &&
                        !resultado.Contains(clave))
                    {
                        resultado.Add(clave);
                    }
                }

                return resultado;
            }

            private void MarcarTodasLasFilas(bool marcado)
            {
                foreach (System.Windows.Forms.DataGridViewRow fila in dgvLeyenda.Rows)
                    fila.Cells["Mostrar"].Value = marcado;
            }

            private void FiltrarParametrosMientrasEscribe()
            {
                if (actualizandoComboParametros)
                    return;

                string textoEscrito = cmbParametro.Text ?? "";
                int posicionCursor = cmbParametro.SelectionStart;

                RefrescarListaCombo(
                    textoEscrito,
                    true,
                    false);

                actualizandoComboParametros = true;

                try
                {
                    cmbParametro.Text = textoEscrito;

                    if (posicionCursor < 0)
                        posicionCursor = textoEscrito.Length;

                    if (posicionCursor > textoEscrito.Length)
                        posicionCursor = textoEscrito.Length;

                    cmbParametro.SelectionStart = posicionCursor;
                    cmbParametro.SelectionLength = 0;

                    if (cmbParametro.Items.Count > 0)
                        cmbParametro.DroppedDown = true;
                }
                finally
                {
                    actualizandoComboParametros = false;
                }
            }

            private void RefrescarListaCombo(
                string filtro,
                bool conservarTexto,
                bool seleccionarPrimero)
            {
                string textoFiltro = filtro == null
                    ? ""
                    : filtro.Trim();

                System.Collections.Generic.List<ParametroDisponible> filtrados =
                    new System.Collections.Generic.List<ParametroDisponible>();

                foreach (ParametroDisponible p in parametrosTodos)
                {
                    if (p == null)
                        continue;

                    string texto = p.ToString();

                    if (string.IsNullOrWhiteSpace(textoFiltro) ||
                        texto.IndexOf(
                            textoFiltro,
                            System.StringComparison.OrdinalIgnoreCase) >= 0 ||
                        (p.NombreParametro ?? "").IndexOf(
                            textoFiltro,
                            System.StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        filtrados.Add(p);
                    }
                }

                actualizandoComboParametros = true;

                try
                {
                    string textoAnterior = cmbParametro.Text ?? "";

                    cmbParametro.BeginUpdate();
                    cmbParametro.Items.Clear();

                    foreach (ParametroDisponible p in filtrados)
                        cmbParametro.Items.Add(p);

                    if (seleccionarPrimero && cmbParametro.Items.Count > 0)
                    {
                        cmbParametro.SelectedIndex = 0;
                    }
                    else if (conservarTexto)
                    {
                        cmbParametro.SelectedIndex = -1;
                        cmbParametro.Text = textoAnterior;
                        cmbParametro.SelectionStart = cmbParametro.Text.Length;
                        cmbParametro.SelectionLength = 0;
                    }

                    cmbParametro.EndUpdate();
                }
                finally
                {
                    actualizandoComboParametros = false;
                }
            }

            private ParametroDisponible ResolverParametroSeleccionado()
            {
                ParametroDisponible seleccionado =
                    cmbParametro.SelectedItem as ParametroDisponible;

                if (seleccionado != null)
                    return seleccionado;

                string texto = cmbParametro.Text == null
                    ? ""
                    : cmbParametro.Text.Trim();

                if (string.IsNullOrWhiteSpace(texto))
                    return null;

                ParametroDisponible exacto = null;
                System.Collections.Generic.List<ParametroDisponible> coincidencias =
                    new System.Collections.Generic.List<ParametroDisponible>();

                foreach (ParametroDisponible p in parametrosTodos)
                {
                    if (p == null)
                        continue;

                    if (string.Equals(
                        p.ToString(),
                        texto,
                        System.StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(
                        p.NombreParametro ?? "",
                        texto,
                        System.StringComparison.OrdinalIgnoreCase))
                    {
                        exacto = p;
                        break;
                    }

                    if (p.ToString().IndexOf(
                        texto,
                        System.StringComparison.OrdinalIgnoreCase) >= 0 ||
                        (p.NombreParametro ?? "").IndexOf(
                        texto,
                        System.StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        coincidencias.Add(p);
                    }
                }

                if (exacto != null)
                    return exacto;

                if (coincidencias.Count == 1)
                    return coincidencias[0];

                return null;
            }

            private void SeleccionarParametroEnCombo(
                ParametroDisponible parametro)
            {
                if (parametro == null)
                    return;

                actualizandoComboParametros = true;

                try
                {
                    if (!cmbParametro.Items.Contains(parametro))
                    {
                        cmbParametro.Items.Clear();
                        cmbParametro.Items.Add(parametro);
                    }

                    cmbParametro.SelectedItem = parametro;
                    cmbParametro.Text = parametro.ToString();
                    cmbParametro.SelectionStart = cmbParametro.Text.Length;
                    cmbParametro.SelectionLength = 0;
                }
                finally
                {
                    actualizandoComboParametros = false;
                }
            }

            private void ActualizarHabilitacion(bool hayParametros)
            {
                cmbParametro.Enabled = hayParametros;
                btnAplicar.Enabled = hayParametros;
                chkLimitarCategorias.Enabled = hayParametros;
                btnSeleccionarCategorias.Enabled =
                    hayParametros &&
                    chkLimitarCategorias.Checked;

                bool hayLeyenda = dgvLeyenda.Rows.Count > 0;

                btnCrearVista.Enabled = hayLeyenda;
                btnCrearLeyenda.Enabled = hayLeyenda;
                btnLeyendaVG.Enabled = true;

                btnSeleccionar.Enabled = hayLeyenda;
                btnMostrarMarcados.Enabled = hayLeyenda;
                btnMostrarTodos.Enabled = hayLeyenda;
                btnMarcarTodos.Enabled = hayLeyenda;
                btnDesmarcarTodos.Enabled = hayLeyenda;
                btnRestaurar.Enabled = true;
            }

            private void SetProcesando(bool procesando, string texto)
            {
                btnActualizarParametros.Enabled = !procesando;
                chkLimitarCategorias.Enabled =
                    !procesando &&
                    cmbParametro.Items.Count > 0;
                btnSeleccionarCategorias.Enabled =
                    !procesando &&
                    cmbParametro.Items.Count > 0 &&
                    chkLimitarCategorias.Checked;
                btnAplicar.Enabled = !procesando && cmbParametro.Items.Count > 0;
                btnCrearVista.Enabled = !procesando && dgvLeyenda.Rows.Count > 0;
                btnCrearLeyenda.Enabled = !procesando && dgvLeyenda.Rows.Count > 0;
                btnLeyendaVG.Enabled = !procesando;
                btnSeleccionar.Enabled = !procesando && dgvLeyenda.Rows.Count > 0;
                btnMostrarMarcados.Enabled = !procesando && dgvLeyenda.Rows.Count > 0;
                btnMostrarTodos.Enabled = !procesando && dgvLeyenda.Rows.Count > 0;
                btnMarcarTodos.Enabled = !procesando && dgvLeyenda.Rows.Count > 0;
                btnDesmarcarTodos.Enabled = !procesando && dgvLeyenda.Rows.Count > 0;
                btnRestaurar.Enabled = !procesando;
                btnCerrar.Enabled = !procesando || cierreSolicitado;

                MostrarEstado(texto, false);
            }

            public void CargarParametrosEnVentana(
                System.Collections.Generic.List<ParametroDisponible> parametros,
                string nombreVista,
                int totalElementos)
            {
                if (this.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() =>
                    {
                        CargarParametrosEnVentana(
                            parametros,
                            nombreVista,
                            totalElementos);
                    }));

                    return;
                }

                parametrosTodos = parametros ??
                    new System.Collections.Generic.List<ParametroDisponible>();

                RefrescarListaCombo(
                    "",
                    false,
                    true);

                lblVista.Text =
                    "Vista 3D: " + (nombreVista ?? "") +
                    "  |  Elementos: " + totalElementos.ToString();

                lblResumen.Text =
                    "Parámetros disponibles: " +
                    parametrosTodos.Count.ToString();

                SetProcesando(false, parametrosTodos.Count > 0
                    ? "Escribe en el desplegable, selecciona un parámetro y pulsa CREAR FILTROS."
                    : "No se encontraron parámetros en los elementos visibles.");

                ActualizarHabilitacion(parametrosTodos.Count > 0);
            }

            public void CargarFiltrosVGEnVentana(
                System.Collections.Generic.List<FiltroVGDisponible> filtros,
                System.Collections.Generic.List<ParametroDisponible> parametros,
                string nombreVista)
            {
                if (this.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(
                        new System.Action(() =>
                        {
                            CargarFiltrosVGEnVentana(
                                filtros,
                                parametros,
                                nombreVista);
                        }));

                    return;
                }

                filtrosVGDisponibles =
                    filtros ??
                    new System.Collections.Generic.List<
                        FiltroVGDisponible>();

                parametrosVGDisponibles =
                    parametros ??
                    new System.Collections.Generic.List<
                        ParametroDisponible>();

                nombreVistaFiltrosVG =
                    nombreVista ?? "";

                SetProcesando(
                    false,
                    filtrosVGDisponibles.Count > 0
                        ? "Filtros VG cargados. Selecciona filtros y columnas."
                        : "La vista activa no tiene filtros aplicados.");

                if (filtrosVGDisponibles.Count > 0)
                {
                    MostrarSelectorFiltrosVG();
                }
            }

            public void CargarCategoriasEnVentana(
                System.Collections.Generic.List<CategoriaDisponible> categorias,
                string claveParametro)
            {
                if (this.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() =>
                    {
                        CargarCategoriasEnVentana(
                            categorias,
                            claveParametro);
                    }));

                    return;
                }

                categoriasDisponiblesTodas =
                    categorias ??
                    new System.Collections.Generic.List<CategoriaDisponible>();

                claveParametroCategorias =
                    claveParametro ?? "";

                // Por defecto se marcan todas las categorías compatibles.
                categoriasSeleccionadas =
                    new System.Collections.Generic.HashSet<long>();

                foreach (CategoriaDisponible categoria
                    in categoriasDisponiblesTodas)
                {
                    if (categoria == null)
                        continue;

                    categoria.Seleccionada = true;

                    categoriasSeleccionadas.Add(
                        categoria.IdCategoria);
                }

                ActualizarResumenCategorias();

                SetProcesando(
                    false,
                    categoriasDisponiblesTodas.Count > 0
                        ? "Categorías compatibles cargadas. Puedes limitar o crear filtros."
                        : "No se encontraron categorías compatibles con el parámetro.");

                ActualizarHabilitacion(
                    cmbParametro.Items.Count > 0);

                bool abrir =
                    abrirSelectorCategoriasDespuesCarga;

                abrirSelectorCategoriasDespuesCarga =
                    false;

                if (abrir &&
                    categoriasDisponiblesTodas.Count > 0)
                {
                    MostrarSelectorCategorias();
                }
            }

            public void CargarLeyendaEnVentana(
                System.Collections.Generic.List<LeyendaValor> leyenda,
                string nombreParametro,
                int totalElementosColoreados)
            {
                if (this.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() =>
                    {
                        CargarLeyendaEnVentana(
                            leyenda,
                            nombreParametro,
                            totalElementosColoreados);
                    }));

                    return;
                }

                dgvLeyenda.Rows.Clear();

                if (leyenda != null)
                {
                    foreach (LeyendaValor item in leyenda)
                    {
                        if (item == null)
                            continue;

                        int indice = dgvLeyenda.Rows.Add(
                            true,
                            "",
                            item.ValorMostrado ?? "",
                            item.Cantidad.ToString(),
                            item.Porcentaje.ToString("0.0") + " %");

                        System.Windows.Forms.DataGridViewRow fila =
                            dgvLeyenda.Rows[indice];

                        fila.Tag = item.ClaveValor;

                        System.Drawing.Color color =
                            System.Drawing.Color.FromArgb(
                                LimitarColor(item.Rojo),
                                LimitarColor(item.Verde),
                                LimitarColor(item.Azul));

                        fila.Cells["Color"].Value =
                            "";

                        fila.Cells["Color"].Tag =
                            new int[]
                            {
                            LimitarColor(item.Rojo),
                            LimitarColor(item.Verde),
                            LimitarColor(item.Azul)
                            };

                        fila.Cells["Color"].ToolTipText =
                            "Haz clic para cambiar el color RGB: " +
                            LimitarColor(item.Rojo).ToString() + ", " +
                            LimitarColor(item.Verde).ToString() + ", " +
                            LimitarColor(item.Azul).ToString();

                        System.Drawing.Color colorTexto =
                            ObtenerColorTextoContraste(
                                color);

                        fila.Cells["Color"].Style.BackColor = color;
                        fila.Cells["Color"].Style.SelectionBackColor = color;
                        fila.Cells["Color"].Style.ForeColor = colorTexto;
                        fila.Cells["Color"].Style.SelectionForeColor = colorTexto;
                    }
                }

                sesionTemporalActiva = true;

                lblResumen.Text =
                    "Parámetro: " + (nombreParametro ?? "") +
                    "  |  Valores: " + dgvLeyenda.Rows.Count.ToString() +
                    "  |  Elementos coloreados: " +
                    totalElementosColoreados.ToString();

                SetProcesando(
                    false,
                    "Filtros creados en Visibilidad/Gráficos. Puedes abrir VG y revisar la pestaña Filtros.");

                ActualizarHabilitacion(cmbParametro.Items.Count > 0);
            }

            private System.Drawing.Color
                ObtenerColorTextoContraste(
                    System.Drawing.Color fondo)
            {
                double luminancia =
                    (0.299 * fondo.R) +
                    (0.587 * fondo.G) +
                    (0.114 * fondo.B);

                return luminancia >= 150
                    ? System.Drawing.Color.Black
                    : System.Drawing.Color.White;
            }

            private int LimitarColor(int valor)
            {
                if (valor < 0)
                    return 0;

                if (valor > 255)
                    return 255;

                return valor;
            }

            public void NotificarColorActualizado(
                string claveValor,
                int rojo,
                int verde,
                int azul)
            {
                if (this.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() =>
                    {
                        NotificarColorActualizado(
                            claveValor,
                            rojo,
                            verde,
                            azul);
                    }));

                    return;
                }

                foreach (System.Windows.Forms.DataGridViewRow fila
                    in dgvLeyenda.Rows)
                {
                    string claveFila = fila.Tag as string;

                    if (!string.Equals(
                        claveFila,
                        claveValor,
                        System.StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    System.Drawing.Color color =
                        System.Drawing.Color.FromArgb(
                            LimitarColor(rojo),
                            LimitarColor(verde),
                            LimitarColor(azul));

                    fila.Cells["Color"].Value =
                        "";

                    fila.Cells["Color"].Tag =
                        new int[]
                        {
                        LimitarColor(rojo),
                        LimitarColor(verde),
                        LimitarColor(azul)
                        };

                    fila.Cells["Color"].ToolTipText =
                        "Haz clic para cambiar el color RGB: " +
                        LimitarColor(rojo).ToString() + ", " +
                        LimitarColor(verde).ToString() + ", " +
                        LimitarColor(azul).ToString();

                    System.Drawing.Color colorTexto =
                        ObtenerColorTextoContraste(
                            color);

                    fila.Cells["Color"].Style.BackColor = color;
                    fila.Cells["Color"].Style.SelectionBackColor = color;
                    fila.Cells["Color"].Style.ForeColor = colorTexto;
                    fila.Cells["Color"].Style.SelectionForeColor = colorTexto;

                    break;
                }

                SetProcesando(
                    false,
                    "Color RGB actualizado en los filtros de Visibilidad/Gráficos.");

                ActualizarHabilitacion(
                    cmbParametro.Items.Count > 0);
            }

            public void NotificarLeyendaCreada(
                string nombreVistaLeyenda)
            {
                if (this.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() =>
                    {
                        NotificarLeyendaCreada(
                            nombreVistaLeyenda);
                    }));

                    return;
                }

                SetProcesando(
                    false,
                    "Leyenda creada: " +
                    (nombreVistaLeyenda ?? ""));

                ActualizarHabilitacion(
                    cmbParametro.Items.Count > 0);
            }

            public void NotificarVistaPermanenteCreada(
                string nombreVista)
            {
                if (this.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() =>
                    {
                        NotificarVistaPermanenteCreada(
                            nombreVista);
                    }));

                    return;
                }

                sesionTemporalActiva = false;
                cierreSolicitado = false;

                lblVista.Text =
                    "Vista creada: " +
                    (nombreVista ?? "");

                SetProcesando(
                    false,
                    "Vista permanente creada. Los filtros y colores se conservarán al cerrar.");

                ActualizarHabilitacion(
                    cmbParametro.Items.Count > 0);
            }

            public void FinalizarOperacion(
                string texto,
                bool esError)
            {
                if (this.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() =>
                    {
                        FinalizarOperacion(texto, esError);
                    }));

                    return;
                }

                SetProcesando(false, texto);
                MostrarEstado(texto, esError);
                ActualizarHabilitacion(cmbParametro.Items.Count > 0);
            }

            public void NotificarRestaurado(
                string texto,
                bool cerrar)
            {
                if (this.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() =>
                    {
                        NotificarRestaurado(texto, cerrar);
                    }));

                    return;
                }

                sesionTemporalActiva = false;
                dgvLeyenda.Rows.Clear();
                lblResumen.Text = "La vista fue restaurada.";
                SetProcesando(false, texto);
                ActualizarHabilitacion(cmbParametro.Items.Count > 0);

                if (cerrar)
                {
                    permitirCierre = true;
                    this.Close();
                }
            }

            public void PermitirCierreTrasError(string texto)
            {
                if (this.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() =>
                    {
                        PermitirCierreTrasError(texto);
                    }));

                    return;
                }

                MostrarEstado(texto, true);
                permitirCierre = true;
                this.Close();
            }

            public void MostrarEstado(
                string texto,
                bool esError)
            {
                if (lblEstado == null || lblEstado.IsDisposed)
                    return;

                if (lblEstado.InvokeRequired)
                {
                    lblEstado.BeginInvoke(new System.Action(() =>
                    {
                        MostrarEstado(texto, esError);
                    }));

                    return;
                }

                lblEstado.Text = texto ?? "";
                lblEstado.ForeColor = esError
                    ? System.Drawing.Color.Firebrick
                    : System.Drawing.Color.FromArgb(70, 70, 70);
            }
        }
    }

}
