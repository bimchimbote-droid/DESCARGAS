using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // VENTANA - ELEMENTOS NO TABULADOS
    // =====================================
    public class ElementosNoTabuladosForm : System.Windows.Forms.Form
    {
        System.Windows.Forms.CheckBox chkFiltro;
        public System.Windows.Forms.ComboBox cmbCategorias;

        System.Windows.Forms.TextBox txtBuscarTabla;
        System.Windows.Forms.ListView chkListaTablas;

        System.Windows.Forms.Button btnSeleccionarTodo;
        System.Windows.Forms.Button btnDeseleccionarTodo;

        System.Windows.Forms.DataGridView dgvResultados;
        System.Windows.Forms.Label lblCantidad;

        System.Windows.Forms.Button btnEjecutar;
        public System.Windows.Forms.Button btnSeleccionar;

        public Autodesk.Revit.UI.ExternalEvent EjecutarEvent;
        public EjecutarElementosNoTabuladosHandler EjecutarHandler;

        public Autodesk.Revit.UI.ExternalEvent SeleccionarEvent;
        public SeleccionarElementosNoTabuladosHandler SeleccionarHandler;

        public System.Collections.Generic.List<string> categoriasOriginales =
            new System.Collections.Generic.List<string>();

        public System.Collections.Generic.List<Autodesk.Revit.DB.ElementId> IdsResultado =
            new System.Collections.Generic.List<Autodesk.Revit.DB.ElementId>();

        private System.Collections.Generic.List<TablaItem> todasLasTablas =
            new System.Collections.Generic.List<TablaItem>();

        private System.Collections.Generic.HashSet<string> idsSeleccionados =
            new System.Collections.Generic.HashSet<string>();

        private bool actualizandoChecks = false;
        private bool aplicarCheckMultiple = false;

        private System.Collections.Generic.List<System.Windows.Forms.ListViewItem> itemsParaCheckMultiple =
            new System.Collections.Generic.List<System.Windows.Forms.ListViewItem>();

        private bool borrarTextoCombo = false;

        public bool AplicarFiltro
        {
            get { return chkFiltro.Checked; }
        }

        public string CategoriaSeleccionada
        {
            get { return cmbCategorias.Text; }
        }

        public System.Collections.Generic.List<string> TablasSeleccionadasIds
        {
            get
            {
                System.Collections.Generic.List<string> lista =
                    new System.Collections.Generic.List<string>();

                foreach (TablaItem item in todasLasTablas)
                {
                    if (idsSeleccionados.Contains(item.UniqueId))
                    {
                        lista.Add(item.UniqueId);
                    }
                }

                return lista;
            }
        }

        private class TablaItem
        {
            public string Name { get; set; }
            public string UniqueId { get; set; }

            public override string ToString()
            {
                return Name;
            }
        }

        public ElementosNoTabuladosForm(Autodesk.Revit.DB.Document doc)
        {
            this.Text = "📋 Elementos No Tabulados";
            this.Width = 980;
            this.Height = 760;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;

            // ===== AUTOR =====
            System.Windows.Forms.Label lblAutor = new System.Windows.Forms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                Left = 20,
                Top = 8,
                Width = 500,
                Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.Gray
            };

            // ===== TÍTULO =====
            System.Windows.Forms.Label lblTitulo = new System.Windows.Forms.Label()
            {
                Text = "REVISIÓN DE ELEMENTOS FUERA DE TABLAS DE PLANIFICACIÓN",
                Left = 20,
                Top = 35,
                Width = 900,
                Height = 25,
                Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(40, 40, 40)
            };

            // =====================================================
            // FILTRO POR CATEGORÍA
            // =====================================================

            chkFiltro = new System.Windows.Forms.CheckBox()
            {
                Text = "Aplicar filtro por categoría",
                Left = 20,
                Top = 70,
                Width = 220
            };

            cmbCategorias = new System.Windows.Forms.ComboBox()
            {
                Left = 250,
                Top = 68,
                Width = 360,
                DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown,
                Enabled = false,
                MaxDropDownItems = 8,
                IntegralHeight = false
            };

            cmbCategorias.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            cmbCategorias.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;

            cmbCategorias.Enter += (s, e) =>
            {
                cmbCategorias.SelectAll();
                borrarTextoCombo = true;
            };

            cmbCategorias.MouseClick += (s, e) =>
            {
                cmbCategorias.SelectAll();
                borrarTextoCombo = true;
            };

            cmbCategorias.KeyDown += (s, e) =>
            {
                if (borrarTextoCombo && !char.IsControl((char)e.KeyCode))
                {
                    cmbCategorias.SelectedIndex = -1;
                    cmbCategorias.Text = "";
                    borrarTextoCombo = false;
                }
            };

            cmbCategorias.KeyUp += (s, e) =>
            {
                if (e.KeyCode == System.Windows.Forms.Keys.Up ||
                    e.KeyCode == System.Windows.Forms.Keys.Down)
                {
                    return;
                }

                string texto = cmbCategorias.Text;

                System.Collections.Generic.List<string> filtrados =
                    new System.Collections.Generic.List<string>();

                if (string.IsNullOrWhiteSpace(texto))
                {
                    foreach (string cat in categoriasOriginales)
                    {
                        filtrados.Add(cat);
                    }
                }
                else
                {
                    foreach (string cat in categoriasOriginales)
                    {
                        if (cat.IndexOf(texto, System.StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            filtrados.Add(cat);
                        }
                    }
                }

                cmbCategorias.BeginUpdate();
                cmbCategorias.Items.Clear();

                if (filtrados.Count > 0)
                {
                    cmbCategorias.Items.AddRange(filtrados.ToArray());
                    cmbCategorias.DroppedDown = true;
                }
                else
                {
                    cmbCategorias.DroppedDown = false;
                }

                cmbCategorias.EndUpdate();

                cmbCategorias.SelectionStart = cmbCategorias.Text.Length;
                cmbCategorias.SelectionLength = 0;
            };

            chkFiltro.CheckedChanged += (s, e) =>
            {
                cmbCategorias.Enabled = chkFiltro.Checked;
            };

            // =====================================================
            // LISTA DE TABLAS DE PLANIFICACIÓN
            // =====================================================

            System.Windows.Forms.Label lblTablas = new System.Windows.Forms.Label()
            {
                Text = "01. TABLAS DE PLANIFICACIÓN A EVALUAR",
                Left = 20,
                Top = 110,
                Width = 430,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            txtBuscarTabla = new System.Windows.Forms.TextBox()
            {
                Left = 20,
                Top = 135,
                Width = 430,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                BackColor = System.Drawing.Color.FromArgb(250, 250, 250)
            };

            txtBuscarTabla.TextChanged += TxtBuscarTabla_TextChanged;

            btnSeleccionarTodo = new System.Windows.Forms.Button()
            {
                Text = "Seleccionar todo",
                Left = 20,
                Top = 170,
                Width = 210,
                Height = 30,
                BackColor = System.Drawing.Color.FromArgb(240, 240, 240),
                ForeColor = System.Drawing.Color.FromArgb(30, 30, 30),
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Cursor = System.Windows.Forms.Cursors.Hand
            };

            btnSeleccionarTodo.FlatAppearance.BorderSize = 1;
            btnSeleccionarTodo.FlatAppearance.BorderColor =
                System.Drawing.Color.FromArgb(200, 200, 200);

            btnSeleccionarTodo.Click += BtnSeleccionarTodo_Click;

            btnDeseleccionarTodo = new System.Windows.Forms.Button()
            {
                Text = "Deseleccionar todo",
                Left = 240,
                Top = 170,
                Width = 210,
                Height = 30,
                BackColor = System.Drawing.Color.FromArgb(240, 240, 240),
                ForeColor = System.Drawing.Color.FromArgb(30, 30, 30),
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Cursor = System.Windows.Forms.Cursors.Hand
            };

            btnDeseleccionarTodo.FlatAppearance.BorderSize = 1;
            btnDeseleccionarTodo.FlatAppearance.BorderColor =
                System.Drawing.Color.FromArgb(200, 200, 200);

            btnDeseleccionarTodo.Click += BtnDeseleccionarTodo_Click;

            chkListaTablas = new System.Windows.Forms.ListView()
            {
                Left = 20,
                Top = 210,
                Width = 430,
                Height = 395,
                CheckBoxes = true,
                FullRowSelect = true,
                MultiSelect = true,
                View = System.Windows.Forms.View.Details,
                HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None,
                HideSelection = false,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                BackColor = System.Drawing.Color.FromArgb(250, 250, 250),
                Font = new System.Drawing.Font("Segoe UI", 8.5F)
            };

            chkListaTablas.Columns.Add("Tabla", 405);

            chkListaTablas.ItemChecked += ChkListaTablas_ItemChecked;
            chkListaTablas.MouseDown += ChkListaTablas_MouseDown;

            // =====================================================
            // BOTÓN EJECUTAR
            // =====================================================

            btnEjecutar = new System.Windows.Forms.Button()
            {
                Text = "EJECUTAR REVISIÓN",
                Width = 430,
                Height = 40,
                Left = 20,
                Top = 620,
                BackColor = System.Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = System.Drawing.Color.White,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold),
                Cursor = System.Windows.Forms.Cursors.Hand
            };

            btnEjecutar.FlatAppearance.BorderSize = 0;

            btnEjecutar.MouseEnter += (s, e) =>
                btnEjecutar.BackColor = System.Drawing.Color.FromArgb(0, 100, 190);

            btnEjecutar.MouseLeave += (s, e) =>
                btnEjecutar.BackColor = System.Drawing.Color.FromArgb(0, 120, 215);

            btnEjecutar.MouseDown += (s, e) =>
                btnEjecutar.BackColor = System.Drawing.Color.FromArgb(0, 80, 160);

            btnEjecutar.MouseUp += (s, e) =>
                btnEjecutar.BackColor = System.Drawing.Color.FromArgb(0, 100, 190);

            btnEjecutar.Click += BtnEjecutar_Click;

            // =====================================================
            // GRILLA DE RESULTADOS
            // =====================================================

            System.Windows.Forms.Label lblResultados = new System.Windows.Forms.Label()
            {
                Text = "02. ELEMENTOS QUE NO APARECEN EN LAS TABLAS SELECCIONADAS",
                Left = 480,
                Top = 110,
                Width = 460,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            dgvResultados = new System.Windows.Forms.DataGridView()
            {
                Left = 480,
                Top = 135,
                Width = 460,
                Height = 470,
                BackgroundColor = System.Drawing.Color.White,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = true,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
            };

            dgvResultados.Columns.Add("N", "N°");
            dgvResultados.Columns.Add("Id", "ID");
            dgvResultados.Columns.Add("Categoria", "Categoría");
            dgvResultados.Columns.Add("Familia", "Familia");
            dgvResultados.Columns.Add("Tipo", "Tipo");
            dgvResultados.Columns.Add("Nombre", "Nombre");

            dgvResultados.Columns["N"].Width = 45;
            dgvResultados.Columns["Id"].Width = 75;

            lblCantidad = new System.Windows.Forms.Label()
            {
                Text = "Elementos encontrados: 0",
                Left = 480,
                Top = 620,
                Width = 400,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            btnSeleccionar = new System.Windows.Forms.Button()
            {
                Text = "SELECCIONAR ELEMENTOS EN REVIT",
                Width = 460,
                Height = 40,
                Left = 480,
                Top = 650,
                BackColor = System.Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = System.Drawing.Color.White,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold),
                Cursor = System.Windows.Forms.Cursors.Hand,
                Enabled = false
            };

            btnSeleccionar.FlatAppearance.BorderSize = 0;

            btnSeleccionar.Click += (s, e) =>
            {
                SeleccionarEvent?.Raise();
            };

            // =====================================================
            // AGREGAR CONTROLES
            // =====================================================

            Controls.Add(lblAutor);
            Controls.Add(lblTitulo);

            Controls.Add(chkFiltro);
            Controls.Add(cmbCategorias);

            Controls.Add(lblTablas);
            Controls.Add(txtBuscarTabla);
            Controls.Add(btnSeleccionarTodo);
            Controls.Add(btnDeseleccionarTodo);
            Controls.Add(chkListaTablas);
            Controls.Add(btnEjecutar);

            Controls.Add(lblResultados);
            Controls.Add(dgvResultados);
            Controls.Add(lblCantidad);
            Controls.Add(btnSeleccionar);

            CargarTablasDelProyecto(doc);
            CargarListaFiltrada("");
        }

        // =====================================================
        // CARGAR RESULTADOS EN GRILLA
        // =====================================================

        public void CargarResultados(System.Collections.Generic.List<ElementoNoTabuladoInfo> elementos)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new System.Action(() => CargarResultados(elementos)));
                return;
            }

            dgvResultados.Rows.Clear();
            IdsResultado.Clear();

            int contador = 1;

            foreach (ElementoNoTabuladoInfo item in elementos)
            {
                dgvResultados.Rows.Add(
                    contador,
                    item.IdTexto,
                    item.Categoria,
                    item.Familia,
                    item.Tipo,
                    item.Nombre);

                IdsResultado.Add(item.ElementId);
                contador++;
            }

            lblCantidad.Text = "Elementos encontrados: " + IdsResultado.Count;
            btnSeleccionar.Enabled = IdsResultado.Count > 0;
        }

        // =====================================================
        // CARGAR TABLAS DEL PROYECTO
        // =====================================================

        private void CargarTablasDelProyecto(Autodesk.Revit.DB.Document doc)
        {
            todasLasTablas.Clear();

            Autodesk.Revit.DB.FilteredElementCollector collector =
                new Autodesk.Revit.DB.FilteredElementCollector(doc)
                .OfClass(typeof(Autodesk.Revit.DB.ViewSchedule));

            foreach (Autodesk.Revit.DB.Element elem in collector)
            {
                Autodesk.Revit.DB.ViewSchedule vs =
                    elem as Autodesk.Revit.DB.ViewSchedule;

                if (vs == null)
                    continue;

                if (vs.IsTemplate)
                    continue;

                todasLasTablas.Add(new TablaItem()
                {
                    Name = vs.Name,
                    UniqueId = vs.UniqueId
                });
            }

            todasLasTablas.Sort((a, b) =>
                string.Compare(a.Name, b.Name, System.StringComparison.OrdinalIgnoreCase));

            idsSeleccionados.Clear();

            foreach (TablaItem item in todasLasTablas)
            {
                idsSeleccionados.Add(item.UniqueId);
            }
        }

        private void CargarListaFiltrada(string filtro)
        {
            string texto = filtro == null ? "" : filtro.Trim().ToLower();

            actualizandoChecks = true;

            chkListaTablas.BeginUpdate();
            chkListaTablas.Items.Clear();

            foreach (TablaItem item in todasLasTablas)
            {
                bool mostrar =
                    string.IsNullOrEmpty(texto) ||
                    item.Name.ToLower().Contains(texto);

                if (!mostrar)
                    continue;

                System.Windows.Forms.ListViewItem lvi =
                    new System.Windows.Forms.ListViewItem(item.Name);

                lvi.Tag = item;
                lvi.Checked = idsSeleccionados.Contains(item.UniqueId);

                chkListaTablas.Items.Add(lvi);
            }

            chkListaTablas.EndUpdate();

            actualizandoChecks = false;
        }

        // =====================================================
        // EVENTOS
        // =====================================================

        private void TxtBuscarTabla_TextChanged(object sender, System.EventArgs e)
        {
            CargarListaFiltrada(txtBuscarTabla.Text);
        }

        private void BtnEjecutar_Click(object sender, System.EventArgs e)
        {
            if (chkFiltro.Checked && string.IsNullOrWhiteSpace(cmbCategorias.Text))
            {
                System.Windows.Forms.MessageBox.Show(
                    "Debe seleccionar o escribir una categoría para aplicar el filtro.",
                    "MYG",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Warning);

                return;
            }

            if (TablasSeleccionadasIds.Count == 0)
            {
                System.Windows.Forms.MessageBox.Show(
                    "Seleccione al menos una tabla de planificación para evaluar.",
                    "MYG",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Warning);

                return;
            }

            EjecutarEvent?.Raise();
        }

        private void ChkListaTablas_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            System.Windows.Forms.ListViewHitTestInfo hit =
                chkListaTablas.HitTest(e.Location);

            if (hit == null || hit.Item == null)
                return;

            bool clicEnCheck =
                (hit.Location & System.Windows.Forms.ListViewHitTestLocations.StateImage)
                == System.Windows.Forms.ListViewHitTestLocations.StateImage;

            if (!clicEnCheck)
                return;

            aplicarCheckMultiple = false;
            itemsParaCheckMultiple.Clear();

            if (chkListaTablas.SelectedItems.Count <= 1)
                return;

            foreach (System.Windows.Forms.ListViewItem itemSeleccionado in chkListaTablas.SelectedItems)
            {
                itemsParaCheckMultiple.Add(itemSeleccionado);
            }

            if (!itemsParaCheckMultiple.Contains(hit.Item))
            {
                itemsParaCheckMultiple.Add(hit.Item);
            }

            aplicarCheckMultiple = true;
        }

        private void ChkListaTablas_ItemChecked(
            object sender,
            System.Windows.Forms.ItemCheckedEventArgs e)
        {
            if (actualizandoChecks)
                return;

            TablaItem item = e.Item.Tag as TablaItem;

            if (item == null)
                return;

            ActualizarEstadoTabla(item, e.Item.Checked);

            if (!aplicarCheckMultiple)
                return;

            bool nuevoEstado = e.Item.Checked;

            this.BeginInvoke(new System.Action(() =>
            {
                actualizandoChecks = true;

                foreach (System.Windows.Forms.ListViewItem itemSeleccionado in itemsParaCheckMultiple)
                {
                    if (itemSeleccionado == null)
                        continue;

                    itemSeleccionado.Checked = nuevoEstado;

                    TablaItem tabla = itemSeleccionado.Tag as TablaItem;

                    if (tabla == null)
                        continue;

                    ActualizarEstadoTabla(tabla, nuevoEstado);
                }

                e.Item.Checked = nuevoEstado;
                ActualizarEstadoTabla(item, nuevoEstado);

                actualizandoChecks = false;

                aplicarCheckMultiple = false;
                itemsParaCheckMultiple.Clear();
            }));
        }

        private void ActualizarEstadoTabla(TablaItem item, bool seleccionado)
        {
            if (item == null)
                return;

            if (seleccionado)
            {
                if (!idsSeleccionados.Contains(item.UniqueId))
                    idsSeleccionados.Add(item.UniqueId);
            }
            else
            {
                if (idsSeleccionados.Contains(item.UniqueId))
                    idsSeleccionados.Remove(item.UniqueId);
            }
        }

        private void BtnSeleccionarTodo_Click(object sender, System.EventArgs e)
        {
            actualizandoChecks = true;

            chkListaTablas.BeginUpdate();

            foreach (System.Windows.Forms.ListViewItem lvi in chkListaTablas.Items)
            {
                TablaItem item = lvi.Tag as TablaItem;

                if (item == null)
                    continue;

                if (!idsSeleccionados.Contains(item.UniqueId))
                    idsSeleccionados.Add(item.UniqueId);

                lvi.Checked = true;
            }

            chkListaTablas.EndUpdate();

            actualizandoChecks = false;
        }

        private void BtnDeseleccionarTodo_Click(object sender, System.EventArgs e)
        {
            actualizandoChecks = true;

            chkListaTablas.BeginUpdate();

            foreach (System.Windows.Forms.ListViewItem lvi in chkListaTablas.Items)
            {
                TablaItem item = lvi.Tag as TablaItem;

                if (item == null)
                    continue;

                if (idsSeleccionados.Contains(item.UniqueId))
                    idsSeleccionados.Remove(item.UniqueId);

                lvi.Checked = false;
            }

            chkListaTablas.EndUpdate();

            actualizandoChecks = false;
        }
    }

}
