using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================================
    // COMANDO - ELEMENTOS NO TABULADOS
    // =====================================================

    [Transaction(TransactionMode.Manual)]
    public class ElementosNoTabuladosCommand : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            UIDocument uidoc = commandData.Application.ActiveUIDocument;
            Document doc = uidoc.Document;

            try
            {
                //-------------------------------------------------
                // MOSTRAR VENTANA
                //-------------------------------------------------

                ElementosNoTabuladosForm form = new ElementosNoTabuladosForm(doc);

                // ===== LLENAR COMBO DE CATEGORÍAS =====
                List<string> categorias = doc.Settings.Categories
                    .Cast<Category>()
                    .Where(c => c.CategoryType == CategoryType.Model)
                    .OrderBy(c => c.Name)
                    .Select(c => c.Name)
                    .ToList();

                form.cmbCategorias.Items.AddRange(categorias.ToArray());
                form.categoriasOriginales = categorias;

                // ===== HANDLER EJECUTAR =====
                EjecutarElementosNoTabuladosHandler ejecutarHandler =
                    new EjecutarElementosNoTabuladosHandler();

                ejecutarHandler.UiDoc = uidoc;
                ejecutarHandler.Form = form;

                ExternalEvent ejecutarEvent = ExternalEvent.Create(ejecutarHandler);

                form.EjecutarHandler = ejecutarHandler;
                form.EjecutarEvent = ejecutarEvent;

                // ===== HANDLER SELECCIONAR =====
                SeleccionarElementosNoTabuladosHandler seleccionarHandler =
                    new SeleccionarElementosNoTabuladosHandler();

                seleccionarHandler.UiDoc = uidoc;
                seleccionarHandler.Form = form;

                ExternalEvent seleccionarEvent = ExternalEvent.Create(seleccionarHandler);

                form.SeleccionarHandler = seleccionarHandler;
                form.SeleccionarEvent = seleccionarEvent;

                // ===== MOSTRAR =====
                form.Show();

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                TaskDialog.Show("MYG - Error", ex.ToString());
                return Result.Failed;
            }
        }
    }

}
