﻿using System;
using System.Collections.Generic;
using System.Linq;

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace MYG_Addin
{
    // =====================================================
    // HANDLER - EJECUTAR ELEMENTOS NO TABULADOS
    // =====================================================

    public class EjecutarElementosNoTabuladosHandler : IExternalEventHandler
    {
        public UIDocument UiDoc { get; set; }
        public ElementosNoTabuladosForm Form { get; set; }

        public void Execute(UIApplication app)
        {
            UIDocument uidoc = UiDoc;
            Document doc = uidoc.Document;

            try
            {
                bool aplicarFiltro = Form.AplicarFiltro;
                string categoriaFiltro = Form.CategoriaSeleccionada;

                List<string> idsTablasSeleccionadas = Form.TablasSeleccionadasIds;

                if (idsTablasSeleccionadas == null || idsTablasSeleccionadas.Count == 0)
                {
                    TaskDialog.Show(
                        "MYG",
                        "Debe seleccionar al menos una tabla de planificación para evaluar.");

                    return;
                }

                HashSet<string> setIdsTablasSeleccionadas =
                    new HashSet<string>(idsTablasSeleccionadas);

                // ============================================================
                // 1. OBTENER TODOS LOS ELEMENTOS MODELABLES DEL PROYECTO
                // ============================================================

                List<Element> todosLosElementosModelo =
                    new FilteredElementCollector(doc)
                    .WhereElementIsNotElementType()
                    .Where(e => EsElementoModeloValido(e))
                    .Where(e =>
                        !aplicarFiltro ||
                        (
                            e.Category != null &&
                            string.Equals(
                                e.Category.Name,
                                categoriaFiltro,
                                StringComparison.OrdinalIgnoreCase)
                        ))
                    .ToList();

                HashSet<ElementId> idsTodosLosElementosModelo =
                    new HashSet<ElementId>(
                        todosLosElementosModelo.Select(e => e.Id));

                // ============================================================
                // 2. OBTENER SOLO LAS TABLAS SELECCIONADAS
                // ============================================================

                List<ViewSchedule> tablas =
                    new FilteredElementCollector(doc)
                    .OfClass(typeof(ViewSchedule))
                    .Cast<ViewSchedule>()
                    .Where(vs => !vs.IsTemplate)
                    .Where(vs => setIdsTablasSeleccionadas.Contains(vs.UniqueId))
                    .ToList();

                // ============================================================
                // 3. OBTENER ELEMENTOS QUE SÍ APARECEN EN LAS TABLAS ELEGIDAS
                // ============================================================

                HashSet<ElementId> idsElementosEnTablas = new HashSet<ElementId>();

                foreach (ViewSchedule tabla in tablas)
                {
                    try
                    {
                        IList<Element> elementosDeTabla =
                            new FilteredElementCollector(doc, tabla.Id)
                            .WhereElementIsNotElementType()
                            .Where(e => EsElementoModeloValido(e))
                            .ToList();

                        foreach (Element e in elementosDeTabla)
                        {
                            idsElementosEnTablas.Add(e.Id);
                        }
                    }
                    catch
                    {
                        // Algunas tablas especiales pueden fallar con collector directo.
                        // Se omiten para que la revisión general no se detenga.
                    }
                }

                // ============================================================
                // 4. COMPARAR:
                // ELEMENTOS QUE NO ESTÁN EN LAS TABLAS SELECCIONADAS
                // ============================================================

                List<Element> elementosNoTabulados =
                    todosLosElementosModelo
                    .Where(e => !idsElementosEnTablas.Contains(e.Id))
                    .OrderBy(e => e.Category != null ? e.Category.Name : "")
                    .ThenBy(e => ObtenerNombreSeguro(e))
                    .ToList();

                // ============================================================
                // 5. PREPARAR LISTA PARA LA VENTANA
                // ============================================================

                List<ElementoNoTabuladoInfo> lista =
                    new List<ElementoNoTabuladoInfo>();

                foreach (Element e in elementosNoTabulados)
                {
                    Element tipoElem = null;

                    try
                    {
                        ElementId typeId = e.GetTypeId();

                        if (typeId != null && typeId != ElementId.InvalidElementId)
                            tipoElem = doc.GetElement(typeId);
                    }
                    catch
                    {
                        tipoElem = null;
                    }

                    string categoria = e.Category != null ? e.Category.Name : "";
                    string nombre = ObtenerNombreSeguro(e);
                    string tipo = tipoElem != null ? ObtenerNombreSeguro(tipoElem) : "";
                    string familia = ObtenerFamiliaSeguro(e, tipoElem);

                    lista.Add(new ElementoNoTabuladoInfo()
                    {
                        ElementId = e.Id,
                        IdTexto = ObtenerIdTexto(e.Id),
                        Categoria = categoria,
                        Familia = familia,
                        Tipo = tipo,
                        Nombre = nombre
                    });
                }

                Form.CargarResultados(lista);

                TaskDialog.Show(
                    "MYG - Elementos No Tabulados",
                    "Revisión finalizada.\n\n" +
                    "Elementos modelables evaluados: " + idsTodosLosElementosModelo.Count + "\n" +
                    "Tablas seleccionadas evaluadas: " + tablas.Count + "\n" +
                    "Elementos encontrados en tablas seleccionadas: " + idsElementosEnTablas.Count + "\n" +
                    "Elementos NO encontrados en tablas seleccionadas: " + lista.Count + "\n\n" +
                    "La lista ha sido cargada en la ventana."
                );
            }
            catch (Exception ex)
            {
                TaskDialog.Show("MYG - Error", ex.ToString());
            }
        }

        public string GetName()
        {
            return "EjecutarElementosNoTabuladosHandler";
        }

        // ============================================================
        // FILTRO DE ELEMENTOS MODELABLES
        // ============================================================

        private bool EsElementoModeloValido(Element e)
        {
            if (e == null)
                return false;

            if (e.Id == ElementId.InvalidElementId)
                return false;

            if (e.Category == null)
                return false;

            if (e.Category.CategoryType != CategoryType.Model)
                return false;

            if (e is View)
                return false;

            if (e is Level)
                return false;

            if (e is Grid)
                return false;

            if (e is RevitLinkInstance)
                return false;

            return true;
        }

        private string ObtenerNombreSeguro(Element e)
        {
            if (e == null)
                return "";

            try
            {
                return e.Name ?? "";
            }
            catch
            {
                return "";
            }
        }

        private string ObtenerFamiliaSeguro(Element e, Element tipoElem)
        {
            try
            {
                FamilyInstance fi = e as FamilyInstance;

                if (fi != null && fi.Symbol != null && fi.Symbol.Family != null)
                    return fi.Symbol.Family.Name;

                if (tipoElem != null)
                {
                    Parameter p =
                        tipoElem.get_Parameter(BuiltInParameter.SYMBOL_FAMILY_NAME_PARAM);

                    if (p != null && p.HasValue)
                        return p.AsString();
                }
            }
            catch
            {
            }

            return "";
        }

        private string ObtenerIdTexto(ElementId id)
        {
            if (id == null)
                return "";

            try
            {
                return id.Value.ToString();
            }
            catch
            {
                return id.ToString();
            }
        }
    }

    // =====================================================
    // HANDLER - SELECCIONAR ELEMENTOS NO TABULADOS
    // =====================================================

    public class SeleccionarElementosNoTabuladosHandler : IExternalEventHandler
    {
        public UIDocument UiDoc { get; set; }
        public ElementosNoTabuladosForm Form { get; set; }

        public void Execute(UIApplication app)
        {
            UIDocument uidoc = UiDoc;

            try
            {
                if (Form == null ||
                    Form.IdsResultado == null ||
                    Form.IdsResultado.Count == 0)
                {
                    TaskDialog.Show(
                        "MYG",
                        "No hay elementos para seleccionar.\n\nPrimero ejecute la revisión.");

                    return;
                }

                uidoc.Selection.SetElementIds(Form.IdsResultado);

                TaskDialog.Show(
                    "MYG - Selección",
                    "Se seleccionaron " + Form.IdsResultado.Count + " elementos en Revit.");
            }
            catch (Exception ex)
            {
                TaskDialog.Show("MYG - Error", ex.ToString());
            }
        }

        public string GetName()
        {
            return "SeleccionarElementosNoTabuladosHandler";
        }
    }

    // =====================================================
    // CLASE AUXILIAR - INFO ELEMENTO NO TABULADO
    // =====================================================

    public class ElementoNoTabuladoInfo
    {
        public ElementId ElementId { get; set; }
        public string IdTexto { get; set; }
        public string Categoria { get; set; }
        public string Familia { get; set; }
        public string Tipo { get; set; }
        public string Nombre { get; set; }
    }
}