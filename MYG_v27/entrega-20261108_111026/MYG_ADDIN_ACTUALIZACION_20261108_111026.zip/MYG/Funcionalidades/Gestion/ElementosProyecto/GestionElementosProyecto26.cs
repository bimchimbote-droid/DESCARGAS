using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // VENTANA 2.6 - GESTIONAR ELEMENTOS DEL PROYECTO
    // =====================================

    public static class GestionElementosProyecto26
    {
        public enum GestionProyectoTipo
        {
            ParametrosProyecto = 1,
            PlantillasVista = 2,
            Filtros = 3
        }

        public enum GestionProyectoOperacion
        {
            Ninguna = 0,
            AbrirVentana = 1,
            EliminarSeleccionados = 2
        }

        public class GestionProyectoItem
        {
            public long IdValor { get; set; }
            public string Nombre { get; set; }
            public string Detalle { get; set; }

            public override string ToString()
            {
                if (string.IsNullOrWhiteSpace(Detalle))
                    return Nombre;

                return Nombre + "   |   " + Detalle;
            }
        }

        public static class GestionProyectoDataHelper
        {
            public static string ObtenerTitulo(GestionProyectoTipo tipo)
            {
                if (tipo == GestionProyectoTipo.ParametrosProyecto)
                    return "Parámetros de Proyecto";

                if (tipo == GestionProyectoTipo.PlantillasVista)
                    return "Plantillas de Vistas";

                if (tipo == GestionProyectoTipo.Filtros)
                    return "Filtros";

                return "Elementos";
            }

            public static string ObtenerTituloOperacion(GestionProyectoTipo tipo)
            {
                if (tipo == GestionProyectoTipo.ParametrosProyecto)
                    return "GESTIONAR PARÁMETROS DE PROYECTO";

                if (tipo == GestionProyectoTipo.PlantillasVista)
                    return "GESTIONAR PLANTILLAS DE VISTAS";

                if (tipo == GestionProyectoTipo.Filtros)
                    return "GESTIONAR FILTROS";

                return "GESTIONAR ELEMENTOS";
            }

            public static System.Collections.Generic.List<GestionProyectoItem> ObtenerItems(
                Autodesk.Revit.DB.Document doc,
                GestionProyectoTipo tipo)
            {
                if (tipo == GestionProyectoTipo.ParametrosProyecto)
                    return ObtenerParametrosProyecto(doc);

                if (tipo == GestionProyectoTipo.PlantillasVista)
                    return ObtenerPlantillasVista(doc);

                if (tipo == GestionProyectoTipo.Filtros)
                    return ObtenerFiltros(doc);

                return new System.Collections.Generic.List<GestionProyectoItem>();
            }

            private static System.Collections.Generic.List<GestionProyectoItem> ObtenerParametrosProyecto(
    Autodesk.Revit.DB.Document doc)
            {
                System.Collections.Generic.List<GestionProyectoItem> lista =
                    new System.Collections.Generic.List<GestionProyectoItem>();

                if (doc == null)
                    return lista;

                /*
                 * IMPORTANTE:
                 * No usar FilteredElementCollector.OfClass(ParameterElement),
                 * porque eso también puede listar parámetros compartidos existentes
                 * por familias cargadas en el proyecto.
                 *
                 * doc.ParameterBindings solo contiene parámetros realmente vinculados
                 * como PARÁMETROS DE PROYECTO.
                 */

                Autodesk.Revit.DB.BindingMap bindingMap = null;

                try
                {
                    bindingMap = doc.ParameterBindings;
                }
                catch
                {
                    bindingMap = null;
                }

                if (bindingMap == null)
                    return lista;

                System.Collections.Generic.HashSet<long> idsAgregados =
                    new System.Collections.Generic.HashSet<long>();

                Autodesk.Revit.DB.DefinitionBindingMapIterator iterador =
                    bindingMap.ForwardIterator();

                iterador.Reset();

                while (iterador.MoveNext())
                {
                    Autodesk.Revit.DB.Definition def = iterador.Key;

                    Autodesk.Revit.DB.Binding binding =
                        iterador.Current as Autodesk.Revit.DB.Binding;

                    if (def == null || binding == null)
                        continue;

                    if (string.IsNullOrWhiteSpace(def.Name))
                        continue;

                    Autodesk.Revit.DB.ParameterElement pe = null;

                    // Obtener el ElementId real del parámetro de proyecto
                    try
                    {
                        Autodesk.Revit.DB.InternalDefinition internalDef =
                            def as Autodesk.Revit.DB.InternalDefinition;

                        if (internalDef != null)
                        {
                            Autodesk.Revit.DB.ElementId idDef = internalDef.Id;

                            if (idDef != null && idDef.Value > 0)
                            {
                                pe = doc.GetElement(idDef) as Autodesk.Revit.DB.ParameterElement;
                            }
                        }
                    }
                    catch
                    {
                        pe = null;
                    }

                    // Respaldo para parámetros compartidos vinculados al proyecto
                    if (pe == null)
                    {
                        try
                        {
                            Autodesk.Revit.DB.ExternalDefinition externalDef =
                                def as Autodesk.Revit.DB.ExternalDefinition;

                            if (externalDef != null)
                            {
                                Autodesk.Revit.DB.SharedParameterElement sp =
                                    Autodesk.Revit.DB.SharedParameterElement.Lookup(
                                        doc,
                                        externalDef.GUID);

                                if (sp != null)
                                    pe = sp;
                            }
                        }
                        catch
                        {
                            pe = null;
                        }
                    }

                    if (pe == null)
                        continue;

                    // Seguridad: omitir parámetros globales
                    if (pe is Autodesk.Revit.DB.GlobalParameter)
                        continue;

                    long idValor = pe.Id.Value;

                    if (idsAgregados.Contains(idValor))
                        continue;

                    idsAgregados.Add(idValor);

                    string detalle = "ID: " + idValor.ToString();

                    if (pe is Autodesk.Revit.DB.SharedParameterElement)
                        detalle += " | Compartido";
                    else
                        detalle += " | Proyecto";

                    if (binding is Autodesk.Revit.DB.InstanceBinding)
                        detalle += " | Instancia";
                    else if (binding is Autodesk.Revit.DB.TypeBinding)
                        detalle += " | Tipo";

                    try
                    {
                        Autodesk.Revit.DB.ElementBinding elementBinding =
                            binding as Autodesk.Revit.DB.ElementBinding;

                        if (elementBinding != null &&
                            elementBinding.Categories != null &&
                            elementBinding.Categories.Size > 0)
                        {
                            detalle += " | Categorías: " + elementBinding.Categories.Size.ToString();
                        }
                    }
                    catch
                    {
                    }

                    lista.Add(new GestionProyectoItem()
                    {
                        IdValor = idValor,
                        Nombre = def.Name,
                        Detalle = detalle
                    });
                }

                OrdenarLista(lista);
                return lista;
            }

            private static System.Collections.Generic.List<GestionProyectoItem> ObtenerPlantillasVista(
                Autodesk.Revit.DB.Document doc)
            {
                System.Collections.Generic.List<GestionProyectoItem> lista =
                    new System.Collections.Generic.List<GestionProyectoItem>();

                if (doc == null)
                    return lista;

                Autodesk.Revit.DB.FilteredElementCollector collector =
                    new Autodesk.Revit.DB.FilteredElementCollector(doc)
                        .OfClass(typeof(Autodesk.Revit.DB.View));

                foreach (Autodesk.Revit.DB.Element elem in collector)
                {
                    Autodesk.Revit.DB.View v = elem as Autodesk.Revit.DB.View;

                    if (v == null)
                        continue;

                    if (!v.IsTemplate)
                        continue;

                    string detalle =
                        "ID: " + v.Id.Value.ToString() +
                        " | Tipo: " + v.ViewType.ToString();

                    lista.Add(new GestionProyectoItem()
                    {
                        IdValor = v.Id.Value,
                        Nombre = v.Name,
                        Detalle = detalle
                    });
                }

                OrdenarLista(lista);
                return lista;
            }

            private static System.Collections.Generic.List<GestionProyectoItem> ObtenerFiltros(
                Autodesk.Revit.DB.Document doc)
            {
                System.Collections.Generic.List<GestionProyectoItem> lista =
                    new System.Collections.Generic.List<GestionProyectoItem>();

                if (doc == null)
                    return lista;

                Autodesk.Revit.DB.FilteredElementCollector collector =
                    new Autodesk.Revit.DB.FilteredElementCollector(doc)
                        .OfClass(typeof(Autodesk.Revit.DB.ParameterFilterElement));

                foreach (Autodesk.Revit.DB.Element elem in collector)
                {
                    Autodesk.Revit.DB.ParameterFilterElement filtro =
                        elem as Autodesk.Revit.DB.ParameterFilterElement;

                    if (filtro == null)
                        continue;

                    string detalle = "ID: " + filtro.Id.Value.ToString();

                    try
                    {
                        System.Collections.Generic.ICollection<Autodesk.Revit.DB.ElementId> categorias =
                            filtro.GetCategories();

                        if (categorias != null && categorias.Count > 0)
                            detalle += " | Categorías: " + categorias.Count.ToString();
                    }
                    catch
                    {
                    }

                    lista.Add(new GestionProyectoItem()
                    {
                        IdValor = filtro.Id.Value,
                        Nombre = filtro.Name,
                        Detalle = detalle
                    });
                }

                OrdenarLista(lista);
                return lista;
            }

            private static void OrdenarLista(System.Collections.Generic.List<GestionProyectoItem> lista)
            {
                if (lista == null)
                    return;

                lista.Sort((a, b) =>
                {
                    string nombreA = a == null || a.Nombre == null ? "" : a.Nombre;
                    string nombreB = b == null || b.Nombre == null ? "" : b.Nombre;

                    int compararNombre = string.Compare(
                        nombreA,
                        nombreB,
                        System.StringComparison.CurrentCultureIgnoreCase);

                    if (compararNombre != 0)
                        return compararNombre;

                    long idA = a == null ? 0 : a.IdValor;
                    long idB = b == null ? 0 : b.IdValor;

                    return idA.CompareTo(idB);
                });
            }
        }

        public class GestionElementosProyectoInicioForm : WinForms.Form
        {
            private WinForms.Button btnParametros;
            private WinForms.Button btnPlantillas;
            private WinForms.Button btnFiltros;
            private WinForms.Label lblEstado;

            public Autodesk.Revit.UI.ExternalEvent EjecutarEvent;
            public EjecutarGestionElementosProyectoHandler Handler;

            public GestionElementosProyectoInicioForm()
            {
                this.Text = "🧩 Gestión del Proyecto";
                this.Width = 440;
                this.Height = 330;
                this.StartPosition = WinForms.FormStartPosition.CenterScreen;
                this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
                this.MaximizeBox = false;
                this.MinimizeBox = true;
                this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
                this.Font = new Drawing.Font("Segoe UI", 9F);
                this.TopMost = true;

                WinForms.Label lblAutor = new WinForms.Label()
                {
                    Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                    Left = 20,
                    Top = 10,
                    Width = 390,
                    Height = 20,
                    Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.Gray
                };

                WinForms.Label lblTitulo = new WinForms.Label()
                {
                    Text = "PANEL 2 - BOTÓN 2.6 | GESTIÓN DEL PROYECTO",
                    Left = 20,
                    Top = 42,
                    Width = 390,
                    Height = 24,
                    Font = new Drawing.Font("Segoe UI", 9.5F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(50, 50, 50)
                };

                WinForms.Label lblDescripcion = new WinForms.Label()
                {
                    Text = "Selecciona qué deseas gestionar. Cada opción abrirá una lista con checks para eliminar los elementos seleccionados.",
                    Left = 20,
                    Top = 70,
                    Width = 380,
                    Height = 45,
                    ForeColor = Drawing.Color.FromArgb(80, 80, 80)
                };

                btnParametros = CrearBotonMenu(
                    "1. GESTIONAR PARÁMETROS DE PROYECTO",
                    20,
                    125,
                    Drawing.Color.FromArgb(0, 120, 215));

                btnPlantillas = CrearBotonMenu(
                    "2. GESTIONAR PLANTILLAS DE VISTAS",
                    20,
                    170,
                    Drawing.Color.FromArgb(90, 90, 90));

                btnFiltros = CrearBotonMenu(
                    "3. GESTIONAR FILTROS",
                    20,
                    215,
                    Drawing.Color.FromArgb(90, 90, 90));

                lblEstado = new WinForms.Label()
                {
                    Text = "Listo.",
                    Left = 20,
                    Top = 265,
                    Width = 390,
                    Height = 20,
                    ForeColor = Drawing.Color.FromArgb(80, 80, 80)
                };

                btnParametros.Click += (s, e) =>
                {
                    SolicitarAbrir(GestionProyectoTipo.ParametrosProyecto);
                };

                btnPlantillas.Click += (s, e) =>
                {
                    SolicitarAbrir(GestionProyectoTipo.PlantillasVista);
                };

                btnFiltros.Click += (s, e) =>
                {
                    SolicitarAbrir(GestionProyectoTipo.Filtros);
                };

                Controls.Add(lblAutor);
                Controls.Add(lblTitulo);
                Controls.Add(lblDescripcion);
                Controls.Add(btnParametros);
                Controls.Add(btnPlantillas);
                Controls.Add(btnFiltros);
                Controls.Add(lblEstado);
            }

            private WinForms.Button CrearBotonMenu(
                string texto,
                int left,
                int top,
                Drawing.Color color)
            {
                WinForms.Button boton = new WinForms.Button()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = 380,
                    Height = 36,
                    BackColor = color,
                    ForeColor = Drawing.Color.White,
                    FlatStyle = WinForms.FlatStyle.Flat,
                    Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                    Cursor = WinForms.Cursors.Hand,
                    TextAlign = Drawing.ContentAlignment.MiddleLeft
                };

                boton.FlatAppearance.BorderSize = 0;
                boton.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(0, 100, 190);
                boton.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(0, 84, 160);

                return boton;
            }

            private void SolicitarAbrir(GestionProyectoTipo tipo)
            {
                if (EjecutarEvent == null || Handler == null)
                {
                    MostrarEstado("No se pudo inicializar el evento externo.");
                    return;
                }

                MostrarEstado("Cargando " + GestionProyectoDataHelper.ObtenerTitulo(tipo).ToLower() + "...");

                Handler.FormInicial = this;
                Handler.FormLista = null;
                Handler.Tipo = tipo;
                Handler.Operacion = GestionProyectoOperacion.AbrirVentana;
                Handler.IdsSeleccionados = new System.Collections.Generic.List<long>();

                EjecutarEvent.Raise();
            }

            public void AbrirVentanaLista(
                GestionProyectoTipo tipo,
                System.Collections.Generic.List<GestionProyectoItem> items)
            {
                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() =>
                    {
                        AbrirVentanaLista(tipo, items);
                    }));

                    return;
                }

                if (items == null)
                    items = new System.Collections.Generic.List<GestionProyectoItem>();

                MostrarEstado("Se cargaron " + items.Count.ToString() + " elementos.");

                GestionElementosProyectoListaForm form =
                    new GestionElementosProyectoListaForm(tipo, items);

                form.EjecutarEvent = EjecutarEvent;
                form.Handler = Handler;

                form.Show(this);
            }

            public void MostrarEstado(string texto)
            {
                if (lblEstado == null || lblEstado.IsDisposed)
                    return;

                if (lblEstado.InvokeRequired)
                {
                    lblEstado.BeginInvoke(new System.Action(() =>
                    {
                        MostrarEstado(texto);
                    }));

                    return;
                }

                lblEstado.Text = texto;
            }
        }

        public class GestionElementosProyectoListaForm : WinForms.Form
        {
            private WinForms.TextBox txtBuscar;
            private WinForms.CheckedListBox chkLista;
            private WinForms.Button btnSeleccionarTodo;
            private WinForms.Button btnDeseleccionarTodo;
            private WinForms.Button btnEliminar;
            private WinForms.Button btnCerrar;
            private WinForms.RichTextBox txtResultado;
            private WinForms.Label lblContador;

            private System.Collections.Generic.List<GestionProyectoItem> itemsOriginales =
                new System.Collections.Generic.List<GestionProyectoItem>();

            private System.Collections.Generic.HashSet<long> idsMarcados =
                new System.Collections.Generic.HashSet<long>();

            private bool actualizandoLista = false;

            public GestionProyectoTipo Tipo { get; private set; }

            public Autodesk.Revit.UI.ExternalEvent EjecutarEvent;
            public EjecutarGestionElementosProyectoHandler Handler;

            public GestionElementosProyectoListaForm(
                GestionProyectoTipo tipo,
                System.Collections.Generic.List<GestionProyectoItem> items)
            {
                Tipo = tipo;

                if (items != null)
                    itemsOriginales = items;

                this.Text = "🗑️ " + GestionProyectoDataHelper.ObtenerTitulo(tipo);
                this.Width = 760;
                this.Height = 640;
                this.StartPosition = WinForms.FormStartPosition.CenterScreen;
                this.FormBorderStyle = WinForms.FormBorderStyle.Sizable;
                this.MinimumSize = new Drawing.Size(680, 540);
                this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
                this.Font = new Drawing.Font("Segoe UI", 9F);
                this.TopMost = true;

                WinForms.Label lblAutor = new WinForms.Label()
                {
                    Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                    Left = 20,
                    Top = 10,
                    Width = 650,
                    Height = 20,
                    Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.Gray,
                    Anchor = WinForms.AnchorStyles.Top | WinForms.AnchorStyles.Left | WinForms.AnchorStyles.Right
                };

                WinForms.Label lblTitulo = new WinForms.Label()
                {
                    Text = GestionProyectoDataHelper.ObtenerTituloOperacion(tipo),
                    Left = 20,
                    Top = 40,
                    Width = 690,
                    Height = 24,
                    Font = new Drawing.Font("Segoe UI", 10F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(50, 50, 50),
                    Anchor = WinForms.AnchorStyles.Top | WinForms.AnchorStyles.Left | WinForms.AnchorStyles.Right
                };

                WinForms.Label lblBuscar = new WinForms.Label()
                {
                    Text = "Buscar:",
                    Left = 20,
                    Top = 76,
                    Width = 70,
                    Height = 22,
                    ForeColor = Drawing.Color.FromArgb(50, 50, 50)
                };

                txtBuscar = new WinForms.TextBox()
                {
                    Left = 85,
                    Top = 74,
                    Width = 475,
                    Height = 24,
                    BorderStyle = WinForms.BorderStyle.FixedSingle,
                    Anchor = WinForms.AnchorStyles.Top | WinForms.AnchorStyles.Left | WinForms.AnchorStyles.Right
                };

                lblContador = new WinForms.Label()
                {
                    Text = "",
                    Left = 570,
                    Top = 77,
                    Width = 155,
                    Height = 22,
                    TextAlign = Drawing.ContentAlignment.MiddleRight,
                    ForeColor = Drawing.Color.FromArgb(80, 80, 80),
                    Anchor = WinForms.AnchorStyles.Top | WinForms.AnchorStyles.Right
                };

                chkLista = new WinForms.CheckedListBox()
                {
                    Left = 20,
                    Top = 110,
                    Width = 705,
                    Height = 300,
                    CheckOnClick = true,
                    BorderStyle = WinForms.BorderStyle.FixedSingle,
                    HorizontalScrollbar = true,
                    Anchor = WinForms.AnchorStyles.Top | WinForms.AnchorStyles.Bottom | WinForms.AnchorStyles.Left | WinForms.AnchorStyles.Right
                };

                btnSeleccionarTodo = CrearBotonAccion(
                    "SELECCIONAR TODO",
                    20,
                    425,
                    150,
                    Drawing.Color.FromArgb(90, 90, 90));

                btnDeseleccionarTodo = CrearBotonAccion(
                    "DESELECCIONAR TODO",
                    180,
                    425,
                    165,
                    Drawing.Color.FromArgb(90, 90, 90));

                btnEliminar = CrearBotonAccion(
                    "ELIMINAR SELECCIONADO",
                    355,
                    425,
                    185,
                    Drawing.Color.FromArgb(190, 55, 45));

                btnCerrar = CrearBotonAccion(
                    "CERRAR",
                    550,
                    425,
                    175,
                    Drawing.Color.FromArgb(70, 70, 70));

                btnSeleccionarTodo.Anchor = WinForms.AnchorStyles.Bottom | WinForms.AnchorStyles.Left;
                btnDeseleccionarTodo.Anchor = WinForms.AnchorStyles.Bottom | WinForms.AnchorStyles.Left;
                btnEliminar.Anchor = WinForms.AnchorStyles.Bottom | WinForms.AnchorStyles.Left;
                btnCerrar.Anchor = WinForms.AnchorStyles.Bottom | WinForms.AnchorStyles.Right;

                WinForms.Label lblResultado = new WinForms.Label()
                {
                    Text = "RESULTADO",
                    Left = 20,
                    Top = 475,
                    Width = 705,
                    Height = 18,
                    Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(50, 50, 50),
                    Anchor = WinForms.AnchorStyles.Bottom | WinForms.AnchorStyles.Left | WinForms.AnchorStyles.Right
                };

                txtResultado = new WinForms.RichTextBox()
                {
                    Left = 20,
                    Top = 495,
                    Width = 705,
                    Height = 80,
                    Multiline = true,
                    ScrollBars = WinForms.RichTextBoxScrollBars.Vertical,
                    ReadOnly = true,
                    BorderStyle = WinForms.BorderStyle.FixedSingle,
                    BackColor = Drawing.Color.White,
                    Font = new Drawing.Font("Consolas", 8.5F),
                    WordWrap = false,
                    Anchor = WinForms.AnchorStyles.Bottom | WinForms.AnchorStyles.Left | WinForms.AnchorStyles.Right
                };

                txtBuscar.TextChanged += (s, e) =>
                {
                    AplicarFiltro();
                };

                chkLista.ItemCheck += (s, e) =>
                {
                    if (actualizandoLista)
                        return;

                    GestionProyectoItem item = chkLista.Items[e.Index] as GestionProyectoItem;

                    if (item == null)
                        return;

                    if (e.NewValue == WinForms.CheckState.Checked)
                        idsMarcados.Add(item.IdValor);
                    else
                        idsMarcados.Remove(item.IdValor);

                    this.BeginInvoke(new System.Action(() =>
                    {
                        ActualizarContador();
                    }));
                };

                btnSeleccionarTodo.Click += (s, e) =>
                {
                    SeleccionarTodoVisible();
                };

                btnDeseleccionarTodo.Click += (s, e) =>
                {
                    DeseleccionarTodoVisible();
                };

                btnEliminar.Click += (s, e) =>
                {
                    EliminarSeleccionados();
                };

                btnCerrar.Click += (s, e) =>
                {
                    this.Close();
                };

                Controls.Add(lblAutor);
                Controls.Add(lblTitulo);
                Controls.Add(lblBuscar);
                Controls.Add(txtBuscar);
                Controls.Add(lblContador);
                Controls.Add(chkLista);
                Controls.Add(btnSeleccionarTodo);
                Controls.Add(btnDeseleccionarTodo);
                Controls.Add(btnEliminar);
                Controls.Add(btnCerrar);
                Controls.Add(lblResultado);
                Controls.Add(txtResultado);

                AplicarFiltro();
                MostrarResultado("Elementos cargados: " + itemsOriginales.Count.ToString());
            }

            private WinForms.Button CrearBotonAccion(
                string texto,
                int left,
                int top,
                int width,
                Drawing.Color color)
            {
                WinForms.Button boton = new WinForms.Button()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 34,
                    BackColor = color,
                    ForeColor = Drawing.Color.White,
                    FlatStyle = WinForms.FlatStyle.Flat,
                    Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                    Cursor = WinForms.Cursors.Hand
                };

                boton.FlatAppearance.BorderSize = 0;

                return boton;
            }

            private void AplicarFiltro()
            {
                SincronizarMarcadosDesdeLista();

                string filtro = "";

                if (txtBuscar != null && txtBuscar.Text != null)
                    filtro = txtBuscar.Text.Trim();

                actualizandoLista = true;

                chkLista.Items.Clear();

                foreach (GestionProyectoItem item in itemsOriginales)
                {
                    if (item == null)
                        continue;

                    bool mostrar = true;

                    if (!string.IsNullOrWhiteSpace(filtro))
                    {
                        string textoBuscar = filtro.ToUpperInvariant();

                        string nombre = item.Nombre ?? "";
                        string detalle = item.Detalle ?? "";

                        mostrar =
                            nombre.ToUpperInvariant().Contains(textoBuscar) ||
                            detalle.ToUpperInvariant().Contains(textoBuscar);
                    }

                    if (!mostrar)
                        continue;

                    int index = chkLista.Items.Add(item);
                    chkLista.SetItemChecked(index, idsMarcados.Contains(item.IdValor));
                }

                actualizandoLista = false;

                ActualizarContador();
            }

            private void SincronizarMarcadosDesdeLista()
            {
                if (chkLista == null)
                    return;

                for (int i = 0; i < chkLista.Items.Count; i++)
                {
                    GestionProyectoItem item = chkLista.Items[i] as GestionProyectoItem;

                    if (item == null)
                        continue;

                    if (chkLista.GetItemChecked(i))
                        idsMarcados.Add(item.IdValor);
                    else
                        idsMarcados.Remove(item.IdValor);
                }
            }

            private void SeleccionarTodoVisible()
            {
                actualizandoLista = true;

                for (int i = 0; i < chkLista.Items.Count; i++)
                {
                    GestionProyectoItem item = chkLista.Items[i] as GestionProyectoItem;

                    if (item == null)
                        continue;

                    idsMarcados.Add(item.IdValor);
                    chkLista.SetItemChecked(i, true);
                }

                actualizandoLista = false;

                ActualizarContador();
                MostrarResultado("Seleccionados visibles: " + chkLista.Items.Count.ToString());
            }

            private void DeseleccionarTodoVisible()
            {
                actualizandoLista = true;

                for (int i = 0; i < chkLista.Items.Count; i++)
                {
                    GestionProyectoItem item = chkLista.Items[i] as GestionProyectoItem;

                    if (item == null)
                        continue;

                    idsMarcados.Remove(item.IdValor);
                    chkLista.SetItemChecked(i, false);
                }

                actualizandoLista = false;

                ActualizarContador();
                MostrarResultado("Se deseleccionaron los elementos visibles.");
            }

            private void EliminarSeleccionados()
            {
                SincronizarMarcadosDesdeLista();

                System.Collections.Generic.List<long> ids =
                    new System.Collections.Generic.List<long>(idsMarcados);

                if (ids.Count == 0)
                {
                    MostrarResultado("No hay elementos seleccionados para eliminar.");
                    return;
                }

                string nombreTipo = GestionProyectoDataHelper.ObtenerTitulo(Tipo).ToLower();

                WinForms.DialogResult respuesta = WinForms.MessageBox.Show(
                    "Se eliminarán " + ids.Count.ToString() + " elemento(s) de " + nombreTipo + ".\r\n\r\n" +
                    "Esta acción modificará el proyecto actual y no se podrá revertir desde esta ventana.\r\n\r\n" +
                    "¿Deseas continuar?",
                    "Confirmar eliminación",
                    WinForms.MessageBoxButtons.YesNo,
                    WinForms.MessageBoxIcon.Warning);

                if (respuesta != WinForms.DialogResult.Yes)
                    return;

                if (EjecutarEvent == null || Handler == null)
                {
                    MostrarResultado("No se pudo inicializar el evento externo.");
                    return;
                }

                Handler.FormLista = this;
                Handler.FormInicial = null;
                Handler.Tipo = Tipo;
                Handler.Operacion = GestionProyectoOperacion.EliminarSeleccionados;
                Handler.IdsSeleccionados = ids;

                MostrarResultado("Eliminando elementos seleccionados...");

                EjecutarEvent.Raise();
            }

            public void ActualizarItems(
                System.Collections.Generic.List<GestionProyectoItem> nuevosItems,
                string resultado)
            {
                if (this.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() =>
                    {
                        ActualizarItems(nuevosItems, resultado);
                    }));

                    return;
                }

                idsMarcados.Clear();

                if (nuevosItems == null)
                    itemsOriginales = new System.Collections.Generic.List<GestionProyectoItem>();
                else
                    itemsOriginales = nuevosItems;

                AplicarFiltro();
                MostrarResultado(resultado);
            }

            public void MostrarResultado(string texto)
            {
                if (txtResultado == null || txtResultado.IsDisposed)
                    return;

                if (txtResultado.InvokeRequired)
                {
                    txtResultado.BeginInvoke(new System.Action(() =>
                    {
                        MostrarResultado(texto);
                    }));

                    return;
                }

                txtResultado.Clear();

                if (string.IsNullOrWhiteSpace(texto))
                    return;

                string[] lineas = texto.Replace("\r\n", "\n").Split('\n');

                foreach (string linea in lineas)
                {
                    if (linea.ToUpperInvariant().Contains("ERROR"))
                    {
                        txtResultado.SelectionColor = Drawing.Color.Red;
                        txtResultado.SelectionFont = new Drawing.Font("Consolas", 8.5F, Drawing.FontStyle.Bold);
                    }
                    else if (linea.ToUpperInvariant().Contains("ELIMINADO"))
                    {
                        txtResultado.SelectionColor = Drawing.Color.FromArgb(30, 120, 30);
                        txtResultado.SelectionFont = new Drawing.Font("Consolas", 8.5F, Drawing.FontStyle.Regular);
                    }
                    else
                    {
                        txtResultado.SelectionColor = Drawing.Color.FromArgb(50, 50, 50);
                        txtResultado.SelectionFont = new Drawing.Font("Consolas", 8.5F, Drawing.FontStyle.Bold);
                    }

                    txtResultado.AppendText(linea + System.Environment.NewLine);
                }

                txtResultado.SelectionStart = 0;
                txtResultado.ScrollToCaret();
            }

            private void ActualizarContador()
            {
                if (lblContador == null || lblContador.IsDisposed)
                    return;

                int visibles = 0;

                if (chkLista != null)
                    visibles = chkLista.Items.Count;

                lblContador.Text =
                    "Visibles: " + visibles.ToString() +
                    " | Marcados: " + idsMarcados.Count.ToString();
            }
        }
    }

}
