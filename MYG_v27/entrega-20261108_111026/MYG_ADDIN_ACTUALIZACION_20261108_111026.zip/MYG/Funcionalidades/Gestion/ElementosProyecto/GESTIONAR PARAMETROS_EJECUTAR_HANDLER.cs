﻿// =====================================
// HANDLER EXTERNO 2.6
// GESTIONAR ELEMENTOS DEL PROYECTO
// PARÁMETROS DE PROYECTO / PLANTILLAS DE VISTA / FILTROS
// CON USING Y NAMESPACE
// ACTUALIZADO PARA USAR LA VENTANA CONTENEDORA GestionElementosProyecto26
// CORRECCIÓN: View totalmente calificado como Autodesk.Revit.DB.View
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MYG_Addin
{
    public class EjecutarGestionElementosProyectoHandler : IExternalEventHandler
    {
        public UIDocument UiDoc { get; set; }

        public GestionElementosProyecto26.GestionElementosProyectoInicioForm FormInicial { get; set; }
        public GestionElementosProyecto26.GestionElementosProyectoListaForm FormLista { get; set; }

        public GestionElementosProyecto26.GestionProyectoTipo Tipo { get; set; }
        public GestionElementosProyecto26.GestionProyectoOperacion Operacion { get; set; }

        public List<long> IdsSeleccionados { get; set; }

        public EjecutarGestionElementosProyectoHandler()
        {
            Operacion = GestionElementosProyecto26.GestionProyectoOperacion.Ninguna;
            IdsSeleccionados = new List<long>();
        }

        public string GetName()
        {
            return "MYG - Gestionar elementos del proyecto";
        }

        public void Execute(UIApplication app)
        {
            UIDocument uidoc = UiDoc;

            if (uidoc == null)
                uidoc = app.ActiveUIDocument;

            if (uidoc == null || uidoc.Document == null)
                return;

            Document doc = uidoc.Document;

            try
            {
                if (Operacion == GestionElementosProyecto26.GestionProyectoOperacion.AbrirVentana)
                {
                    AbrirVentana(doc);
                    return;
                }

                if (Operacion == GestionElementosProyecto26.GestionProyectoOperacion.EliminarSeleccionados)
                {
                    EliminarSeleccionados(doc);
                    return;
                }
            }
            catch (Exception ex)
            {
                string mensaje = "ERROR GENERAL:\r\n" + ex.Message;

                if (FormLista != null && !FormLista.IsDisposed)
                    FormLista.MostrarResultado(mensaje);
                else if (FormInicial != null && !FormInicial.IsDisposed)
                    FormInicial.MostrarEstado(mensaje);
            }
            finally
            {
                Operacion = GestionElementosProyecto26.GestionProyectoOperacion.Ninguna;
            }
        }

        private void AbrirVentana(Document doc)
        {
            List<GestionElementosProyecto26.GestionProyectoItem> items =
                GestionElementosProyecto26.GestionProyectoDataHelper.ObtenerItems(doc, Tipo);

            if (FormInicial != null && !FormInicial.IsDisposed)
            {
                FormInicial.AbrirVentanaLista(Tipo, items);
            }
        }

        private void EliminarSeleccionados(Document doc)
        {
            if (IdsSeleccionados == null || IdsSeleccionados.Count == 0)
            {
                MostrarEnLista("No hay elementos seleccionados para eliminar.");
                return;
            }

            int eliminados = 0;
            int omitidos = 0;
            int errores = 0;

            StringBuilder reporte = new StringBuilder();

            reporte.AppendLine("PROCESO DE ELIMINACIÓN");
            reporte.AppendLine("----------------------------------------");
            reporte.AppendLine("Tipo: " + GestionElementosProyecto26.GestionProyectoDataHelper.ObtenerTitulo(Tipo));
            reporte.AppendLine("Seleccionados: " + IdsSeleccionados.Count.ToString());
            reporte.AppendLine("");

            using (Transaction trans = new Transaction(doc, "MYG - Eliminar " + GestionElementosProyecto26.GestionProyectoDataHelper.ObtenerTitulo(Tipo)))
            {
                trans.Start();

                foreach (long idValor in IdsSeleccionados.Distinct())
                {
                    ElementId id = new ElementId(idValor);

                    Element elemento = doc.GetElement(id);

                    if (elemento == null)
                    {
                        omitidos++;
                        reporte.AppendLine("OMITIDO: ID " + idValor.ToString() + " no existe en el proyecto.");
                        continue;
                    }

                    string nombreElemento = ObtenerNombreElemento(elemento);

                    try
                    {
                        if (!EsElementoValidoParaTipo(elemento, Tipo))
                        {
                            omitidos++;
                            reporte.AppendLine("OMITIDO: " + nombreElemento + " no corresponde al tipo seleccionado.");
                            continue;
                        }

                        doc.Delete(id);

                        eliminados++;
                        reporte.AppendLine("ELIMINADO: " + nombreElemento + " | ID: " + idValor.ToString());
                    }
                    catch (Exception exDelete)
                    {
                        errores++;
                        reporte.AppendLine(
                            "ERROR: " + nombreElemento +
                            " | ID: " + idValor.ToString() +
                            " | " + exDelete.Message);
                    }
                }

                trans.Commit();
            }

            reporte.AppendLine("");
            reporte.AppendLine("----------------------------------------");
            reporte.AppendLine("Eliminados: " + eliminados.ToString());
            reporte.AppendLine("Omitidos: " + omitidos.ToString());
            reporte.AppendLine("Errores: " + errores.ToString());

            List<GestionElementosProyecto26.GestionProyectoItem> itemsActualizados =
                GestionElementosProyecto26.GestionProyectoDataHelper.ObtenerItems(doc, Tipo);

            if (FormLista != null && !FormLista.IsDisposed)
            {
                FormLista.ActualizarItems(
                    itemsActualizados,
                    reporte.ToString());
            }
        }

        private bool EsElementoValidoParaTipo(
            Element elemento,
            GestionElementosProyecto26.GestionProyectoTipo tipo)
        {
            if (elemento == null)
                return false;

            if (tipo == GestionElementosProyecto26.GestionProyectoTipo.ParametrosProyecto)
            {
                ParameterElement pe = elemento as ParameterElement;

                if (pe == null)
                    return false;

                if (pe is GlobalParameter)
                    return false;

                return true;
            }

            if (tipo == GestionElementosProyecto26.GestionProyectoTipo.PlantillasVista)
            {
                Autodesk.Revit.DB.View vista = elemento as Autodesk.Revit.DB.View;

                if (vista == null)
                    return false;

                return vista.IsTemplate;
            }

            if (tipo == GestionElementosProyecto26.GestionProyectoTipo.Filtros)
            {
                return elemento is ParameterFilterElement;
            }

            return false;
        }

        private string ObtenerNombreElemento(Element elemento)
        {
            if (elemento == null)
                return "(SIN ELEMENTO)";

            try
            {
                ParameterElement pe = elemento as ParameterElement;

                if (pe != null)
                {
                    Definition def = pe.GetDefinition();

                    if (def != null && !string.IsNullOrWhiteSpace(def.Name))
                        return def.Name;
                }
            }
            catch
            {
            }

            try
            {
                if (!string.IsNullOrWhiteSpace(elemento.Name))
                    return elemento.Name;
            }
            catch
            {
            }

            return "(SIN NOMBRE)";
        }

        private void MostrarEnLista(string texto)
        {
            if (FormLista != null && !FormLista.IsDisposed)
                FormLista.MostrarResultado(texto);
        }
    }
}
