using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{



    // =====================================
    // VENTANA 3.2 - COPIAR PARÁMETROS DE HABITACIÓN A ELEMENTOS
    // HASTA 5 PARES ORIGEN -> DESTINO
    // TODOS LOS DESPLEGABLES EDITABLES + BÚSQUEDA EN TIEMPO REAL
    // FORMATO DE TEXTO: PREDETERMINADO / TIPO ORACIÓN / MAYÚSCULA
    // SIN VENTANAS EMERGENTES EN OPERACIONES CORRECTAS
    // SIN USING NI NAMESPACE
    // IMPORTANTE: PEGAR DENTRO DEL MISMO NAMESPACE DE TU MYGCommand.cs
    // =====================================

    public static class AsignarHabitacionParametro29
    {
        public enum AsignarHabitacionOperacion
        {
            Ninguna = 0,
            CargarCategorias = 1,
            CargarTipos = 2,
            SeleccionarElementos = 3,
            AsignarHabitaciones = 4
        }

        public enum FormatoTextoCopiado
        {
            Predeterminado = 0,
            TipoOracion = 1,
            Mayuscula = 2
        }

        public sealed class CategoriaDisponible
        {
            public long IdCategoria { get; set; }
            public string NombreCategoria { get; set; }
            public int CantidadElementos { get; set; }

            public override string ToString()
            {
                return (NombreCategoria ?? "") + "  |  " +
                    CantidadElementos.ToString() + " elem.";
            }
        }

        public sealed class TipoDisponible
        {
            public long IdTipo { get; set; }
            public string NombreFamilia { get; set; }
            public string NombreTipo { get; set; }
            public int CantidadElementos { get; set; }

            public override string ToString()
            {
                string familia = string.IsNullOrWhiteSpace(NombreFamilia)
                    ? ""
                    : NombreFamilia.Trim();

                string tipo = string.IsNullOrWhiteSpace(NombreTipo)
                    ? "(Sin nombre de tipo)"
                    : NombreTipo.Trim();

                string texto = string.IsNullOrWhiteSpace(familia)
                    ? tipo
                    : familia + " : " + tipo;

                return texto + "  |  " + CantidadElementos.ToString() + " elem.";
            }
        }

        // Parámetros ORIGEN: pertenecen a las habitaciones detectadas.
        public sealed class ParametroHabitacionDisponible
        {
            public string Clave { get; set; }
            public string NombreParametro { get; set; }
            public string TipoStorage { get; set; }
            public string TipoDato { get; set; }
            public int CantidadHabitaciones { get; set; }

            public override string ToString()
            {
                return (NombreParametro ?? "") + "  |  " +
                    (TipoDato ?? "") + "  |  " +
                    CantidadHabitaciones.ToString() + " hab.";
            }
        }

        // Parámetros DESTINO: pertenecen a los elementos seleccionados.
        public sealed class ParametroInstanciaDisponible
        {
            public string Clave { get; set; }
            public string NombreParametro { get; set; }
            public string TipoStorage { get; set; }
            public string TipoDato { get; set; }
            public int CantidadElementos { get; set; }
            public int CantidadEscribibles { get; set; }
            public bool EsEscribible { get; set; }

            // Se conserva para compatibilidad con versiones anteriores.
            public bool AdmiteTexto { get; set; }

            public override string ToString()
            {
                string estado = EsEscribible
                    ? "Escribible: " + CantidadEscribibles.ToString() + "/" + CantidadElementos.ToString()
                    : "Solo lectura";

                return (NombreParametro ?? "") + "  |  " +
                    (TipoDato ?? "") + "  |  " + estado;
            }
        }

        public sealed class AsignacionParametro
        {
            public string OrigenClave { get; set; }
            public string OrigenNombre { get; set; }
            public string OrigenStorage { get; set; }

            public string DestinoClave { get; set; }
            public string DestinoNombre { get; set; }
            public string DestinoStorage { get; set; }
        }

        public sealed class ResultadoElemento
        {
            public long ElementId { get; set; }
            public string Categoria { get; set; }
            public string Tipo { get; set; }
            public string Habitacion { get; set; }
            public string Estado { get; set; }
        }

        public class AsignarHabitacionParametroForm :
            System.Windows.Forms.Form
        {
            private sealed class FilaMapeoUI
            {
                public int Numero;
                public System.Windows.Forms.Panel Panel;
                public System.Windows.Forms.Label LabelNumero;
                public System.Windows.Forms.ComboBox ComboOrigen;
                public System.Windows.Forms.Label Flecha;
                public System.Windows.Forms.ComboBox ComboDestino;
            }

            public Autodesk.Revit.UI.ExternalEvent EjecutarEvent;
            public MYG_Addin.AsignarHabitacionParametroExternalEventHandler Handler;

            private System.Windows.Forms.ComboBox cmbCategoria;
            private System.Windows.Forms.CheckBox chkFiltrarTipo;
            private System.Windows.Forms.ComboBox cmbTipo;
            private System.Windows.Forms.Button btnSeleccionar;
            private System.Windows.Forms.Button btnAgregarFila;
            private System.Windows.Forms.Button btnQuitarFila;
            private System.Windows.Forms.Panel pnlMapeos;
            private System.Windows.Forms.Button btnAsignar;
            private System.Windows.Forms.Button btnCerrar;
            private System.Windows.Forms.Label lblSeleccion;
            private System.Windows.Forms.Label lblEstado;
            private System.Windows.Forms.DataGridView dgvElementos;
            private System.Windows.Forms.ProgressBar barraTrabajo;

            private System.Windows.Forms.CheckBox chkFormatoPredeterminado;
            private System.Windows.Forms.CheckBox chkFormatoOracion;
            private System.Windows.Forms.CheckBox chkFormatoMayuscula;

            private bool cargandoControles;
            private bool operacionPendiente;
            private bool cambiandoFormatoTexto;
            private int cantidadSeleccionada;

            private System.Collections.Generic.List<CategoriaDisponible> categoriasTodas =
                new System.Collections.Generic.List<CategoriaDisponible>();

            private System.Collections.Generic.List<TipoDisponible> tiposTodos =
                new System.Collections.Generic.List<TipoDisponible>();

            private System.Collections.Generic.List<ParametroHabitacionDisponible> parametrosHabitacionTodos =
                new System.Collections.Generic.List<ParametroHabitacionDisponible>();

            private System.Collections.Generic.List<ParametroInstanciaDisponible> parametrosDestinoTodos =
                new System.Collections.Generic.List<ParametroInstanciaDisponible>();

            private System.Collections.Generic.List<FilaMapeoUI> filasMapeo =
                new System.Collections.Generic.List<FilaMapeoUI>();

            private const int MAX_FILAS = 5;

            public AsignarHabitacionParametroForm()
            {
                this.Text = "MYG - Copiar Parámetros de Habitación a Elementos";
                this.ClientSize = new System.Drawing.Size(960, 890);
                this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
                this.MaximizeBox = false;
                this.MinimizeBox = false;
                this.ShowInTaskbar = true;
                this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
                this.Font = new System.Drawing.Font("Segoe UI", 9F);

                CrearInterfaz();
                ConectarEventos();
                ActualizarEstadoControles();
            }

            private void CrearInterfaz()
            {
                System.Windows.Forms.Label lblTitulo = new System.Windows.Forms.Label()
                {
                    Text = "COPIAR PARÁMETROS DE HABITACIÓN A ELEMENTOS",
                    Left = 22,
                    Top = 18,
                    Width = 900,
                    Height = 28,
                    Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold)
                };

                System.Windows.Forms.Label lblAyuda = new System.Windows.Forms.Label()
                {
                    Text = "1) Busca categoría.  2) Opcionalmente filtra por tipo.  " +
                           "3) Selecciona elementos.  4) Define hasta 5 pares Habitación → Elemento y copia.",
                    Left = 22,
                    Top = 48,
                    Width = 900,
                    Height = 32,
                    ForeColor = System.Drawing.Color.FromArgb(75, 75, 75)
                };

                System.Windows.Forms.GroupBox grpFiltro = new System.Windows.Forms.GroupBox()
                {
                    Text = "1. FILTRO DE SELECCIÓN",
                    Left = 20,
                    Top = 84,
                    Width = 920,
                    Height = 175,
                    Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold)
                };

                System.Windows.Forms.Label lblCategoria = new System.Windows.Forms.Label()
                {
                    Text = "Categoría:",
                    Left = 18,
                    Top = 32,
                    Width = 110,
                    Height = 23,
                    Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular)
                };

                cmbCategoria = CrearComboBuscable(132, 28, 750);

                chkFiltrarTipo = new System.Windows.Forms.CheckBox()
                {
                    Text = "Filtrar por tipo de la categoría seleccionada",
                    Left = 18,
                    Top = 70,
                    Width = 330,
                    Height = 24,
                    Checked = false,
                    Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular)
                };

                cmbTipo = CrearComboBuscable(365, 67, 517);
                cmbTipo.Enabled = false;

                btnSeleccionar = CrearBoton(
                    "SELECCIONAR ELEMENTOS EN REVIT",
                    18,
                    112,
                    330,
                    System.Drawing.Color.FromArgb(0, 120, 215));

                lblSeleccion = new System.Windows.Forms.Label()
                {
                    Text = "0 elementos seleccionados",
                    Left = 365,
                    Top = 120,
                    Width = 517,
                    Height = 25,
                    ForeColor = System.Drawing.Color.FromArgb(65, 65, 65),
                    Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular)
                };

                grpFiltro.Controls.Add(lblCategoria);
                grpFiltro.Controls.Add(cmbCategoria);
                grpFiltro.Controls.Add(chkFiltrarTipo);
                grpFiltro.Controls.Add(cmbTipo);
                grpFiltro.Controls.Add(btnSeleccionar);
                grpFiltro.Controls.Add(lblSeleccion);

                System.Windows.Forms.GroupBox grpMapeo = new System.Windows.Forms.GroupBox()
                {
                    Text = "2. COPIA DE VALORES DE PARÁMETRO A PARÁMETRO",
                    Left = 20,
                    Top = 270,
                    Width = 920,
                    Height = 255,
                    Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold)
                };

                System.Windows.Forms.Label lblOrigen = new System.Windows.Forms.Label()
                {
                    Text = "PARÁMETRO ORIGEN (HABITACIÓN)",
                    Left = 50,
                    Top = 28,
                    Width = 360,
                    Height = 22,
                    Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold)
                };

                System.Windows.Forms.Label lblDestino = new System.Windows.Forms.Label()
                {
                    Text = "PARÁMETRO DESTINO (ELEMENTO)",
                    Left = 475,
                    Top = 28,
                    Width = 330,
                    Height = 22,
                    Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold)
                };

                btnAgregarFila = CrearBotonCuadrado("+", 830, 22, System.Drawing.Color.FromArgb(22, 120, 90));
                btnQuitarFila = CrearBotonCuadrado("−", 870, 22, System.Drawing.Color.FromArgb(110, 110, 110));

                pnlMapeos = new System.Windows.Forms.Panel()
                {
                    Left = 12,
                    Top = 54,
                    Width = 894,
                    Height = 186,
                    AutoScroll = false,
                    BackColor = System.Drawing.Color.Transparent
                };

                grpMapeo.Controls.Add(lblOrigen);
                grpMapeo.Controls.Add(lblDestino);
                grpMapeo.Controls.Add(btnAgregarFila);
                grpMapeo.Controls.Add(btnQuitarFila);
                grpMapeo.Controls.Add(pnlMapeos);

                System.Windows.Forms.GroupBox grpFormato = new System.Windows.Forms.GroupBox()
                {
                    Text = "3. FORMATO DEL TEXTO COPIADO",
                    Left = 20,
                    Top = 532,
                    Width = 920,
                    Height = 66,
                    Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold)
                };

                chkFormatoPredeterminado = new System.Windows.Forms.CheckBox()
                {
                    Text = "Predeterminado",
                    Left = 22,
                    Top = 27,
                    Width = 170,
                    Height = 24,
                    Checked = true,
                    Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular)
                };

                chkFormatoOracion = new System.Windows.Forms.CheckBox()
                {
                    Text = "Tipo oración",
                    Left = 230,
                    Top = 27,
                    Width = 170,
                    Height = 24,
                    Checked = false,
                    Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular)
                };

                chkFormatoMayuscula = new System.Windows.Forms.CheckBox()
                {
                    Text = "MAYÚSCULA",
                    Left = 438,
                    Top = 27,
                    Width = 170,
                    Height = 24,
                    Checked = false,
                    Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular)
                };

                System.Windows.Forms.Label lblFormatoAyuda = new System.Windows.Forms.Label()
                {
                    Text = "Predeterminado conserva exactamente el texto de la habitación.",
                    Left = 620,
                    Top = 28,
                    Width = 280,
                    Height = 22,
                    ForeColor = System.Drawing.Color.FromArgb(90, 90, 90),
                    Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular)
                };

                grpFormato.Controls.Add(chkFormatoPredeterminado);
                grpFormato.Controls.Add(chkFormatoOracion);
                grpFormato.Controls.Add(chkFormatoMayuscula);
                grpFormato.Controls.Add(lblFormatoAyuda);

                System.Windows.Forms.GroupBox grpVista = new System.Windows.Forms.GroupBox()
                {
                    Text = "4. HABITACIÓN DETECTADA POR ELEMENTO",
                    Left = 20,
                    Top = 608,
                    Width = 920,
                    Height = 210,
                    Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold)
                };

                dgvElementos = new System.Windows.Forms.DataGridView()
                {
                    Left = 16,
                    Top = 28,
                    Width = 888,
                    Height = 165,
                    ReadOnly = true,
                    AllowUserToAddRows = false,
                    AllowUserToDeleteRows = false,
                    AllowUserToResizeRows = false,
                    MultiSelect = false,
                    SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect,
                    AutoGenerateColumns = false,
                    RowHeadersVisible = false,
                    BackgroundColor = System.Drawing.Color.White,
                    BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
                };

                dgvElementos.Columns.Add(CrearColumnaTexto("ElementId", "ElementId", 95));
                dgvElementos.Columns.Add(CrearColumnaTexto("Categoria", "Categoría", 180));
                dgvElementos.Columns.Add(CrearColumnaTexto("Tipo", "Tipo", 215));
                dgvElementos.Columns.Add(CrearColumnaTexto("Habitacion", "Habitación", 220));
                dgvElementos.Columns.Add(CrearColumnaTexto("Estado", "Estado", 165));

                grpVista.Controls.Add(dgvElementos);

                barraTrabajo = new System.Windows.Forms.ProgressBar()
                {
                    Left = 20,
                    Top = 830,
                    Width = 920,
                    Height = 6,
                    Style = System.Windows.Forms.ProgressBarStyle.Marquee,
                    MarqueeAnimationSpeed = 25,
                    Visible = false
                };

                lblEstado = new System.Windows.Forms.Label()
                {
                    Text = "Cargando categorías...",
                    Left = 20,
                    Top = 846,
                    Width = 555,
                    Height = 34,
                    ForeColor = System.Drawing.Color.FromArgb(65, 65, 65)
                };

                btnAsignar = CrearBoton(
                    "COPIAR PARÁMETROS",
                    610,
                    842,
                    195,
                    System.Drawing.Color.FromArgb(22, 120, 90));

                btnCerrar = CrearBoton(
                    "CERRAR",
                    820,
                    842,
                    120,
                    System.Drawing.Color.FromArgb(80, 80, 80));

                this.Controls.Add(lblTitulo);
                this.Controls.Add(lblAyuda);
                this.Controls.Add(grpFiltro);
                this.Controls.Add(grpMapeo);
                this.Controls.Add(grpFormato);
                this.Controls.Add(grpVista);
                this.Controls.Add(barraTrabajo);
                this.Controls.Add(lblEstado);
                this.Controls.Add(btnAsignar);
                this.Controls.Add(btnCerrar);

                // La primera fila se crea al final, cuando todos los controles ya existen.
                AgregarFilaMapeo();
            }

            private System.Windows.Forms.ComboBox CrearComboBuscable(
                int left,
                int top,
                int width)
            {
                return new System.Windows.Forms.ComboBox()
                {
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 28,
                    DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown,
                    AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None,
                    AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None,
                    IntegralHeight = false,
                    MaxDropDownItems = 18,
                    Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular)
                };
            }

            private System.Windows.Forms.Button CrearBoton(
                string texto,
                int left,
                int top,
                int width,
                System.Drawing.Color color)
            {
                System.Windows.Forms.Button boton = new System.Windows.Forms.Button()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 34,
                    BackColor = color,
                    ForeColor = System.Drawing.Color.White,
                    FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                    Font = new System.Drawing.Font("Segoe UI", 8.6F, System.Drawing.FontStyle.Bold),
                    Cursor = System.Windows.Forms.Cursors.Hand
                };

                boton.FlatAppearance.BorderSize = 0;
                return boton;
            }

            private System.Windows.Forms.Button CrearBotonCuadrado(
                string texto,
                int left,
                int top,
                System.Drawing.Color color)
            {
                System.Windows.Forms.Button boton = new System.Windows.Forms.Button()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = 34,
                    Height = 28,
                    BackColor = color,
                    ForeColor = System.Drawing.Color.White,
                    FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                    Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold),
                    Cursor = System.Windows.Forms.Cursors.Hand,
                    TabStop = false
                };

                boton.FlatAppearance.BorderSize = 0;
                return boton;
            }

            private System.Windows.Forms.DataGridViewTextBoxColumn CrearColumnaTexto(
                string nombre,
                string titulo,
                int ancho)
            {
                return new System.Windows.Forms.DataGridViewTextBoxColumn()
                {
                    Name = nombre,
                    HeaderText = titulo,
                    DataPropertyName = nombre,
                    Width = ancho,
                    SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
                };
            }

            private void AgregarFilaMapeo()
            {
                if (filasMapeo.Count >= MAX_FILAS)
                {
                    MostrarValidacion("El máximo es de 5 pares de parámetros.");
                    return;
                }

                int numero = filasMapeo.Count + 1;
                int top = (numero - 1) * 34;

                FilaMapeoUI fila = new FilaMapeoUI();
                fila.Numero = numero;
                fila.Panel = new System.Windows.Forms.Panel()
                {
                    Left = 0,
                    Top = top,
                    Width = 880,
                    Height = 32,
                    BackColor = System.Drawing.Color.Transparent
                };

                fila.LabelNumero = new System.Windows.Forms.Label()
                {
                    Text = numero.ToString() + ".",
                    Left = 3,
                    Top = 6,
                    Width = 28,
                    Height = 22,
                    TextAlign = System.Drawing.ContentAlignment.MiddleRight
                };

                fila.ComboOrigen = CrearComboBuscable(38, 2, 370);
                fila.Flecha = new System.Windows.Forms.Label()
                {
                    Text = "→",
                    Left = 418,
                    Top = 4,
                    Width = 28,
                    Height = 24,
                    Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold),
                    TextAlign = System.Drawing.ContentAlignment.MiddleCenter
                };
                fila.ComboDestino = CrearComboBuscable(455, 2, 410);

                ConectarEventosComboOrigen(fila);
                ConectarEventosComboDestino(fila);

                fila.Panel.Controls.Add(fila.LabelNumero);
                fila.Panel.Controls.Add(fila.ComboOrigen);
                fila.Panel.Controls.Add(fila.Flecha);
                fila.Panel.Controls.Add(fila.ComboDestino);

                pnlMapeos.Controls.Add(fila.Panel);
                filasMapeo.Add(fila);

                CargarListaOrigenEnCombo(fila.ComboOrigen, "");
                CargarListaDestinoEnCombo(fila.ComboDestino, "");
                ActualizarEstadoControles();
            }

            private void QuitarFilaMapeo()
            {
                if (filasMapeo.Count <= 1)
                {
                    FilaMapeoUI unica = filasMapeo.Count == 1 ? filasMapeo[0] : null;
                    if (unica != null)
                    {
                        cargandoControles = true;
                        try
                        {
                            unica.ComboOrigen.SelectedIndex = -1;
                            unica.ComboOrigen.Text = "";
                            unica.ComboDestino.SelectedIndex = -1;
                            unica.ComboDestino.Text = "";
                        }
                        finally
                        {
                            cargandoControles = false;
                        }
                    }

                    MostrarValidacion("Debe existir al menos una fila de copia.");
                    ActualizarEstadoControles();
                    return;
                }

                FilaMapeoUI ultima = filasMapeo[filasMapeo.Count - 1];
                pnlMapeos.Controls.Remove(ultima.Panel);
                ultima.Panel.Dispose();
                filasMapeo.RemoveAt(filasMapeo.Count - 1);
                ActualizarEstadoControles();
            }

            private void ConectarEventos()
            {
                this.Shown += (s, e) =>
                {
                    SolicitarOperacion(
                        AsignarHabitacionOperacion.CargarCategorias,
                        "Cargando categorías del proyecto...");
                };

                cmbCategoria.TextUpdate += (s, e) =>
                {
                    if (!cargandoControles)
                        FiltrarCategoriasMientrasEscribe();
                };

                cmbCategoria.DropDown += (s, e) =>
                {
                    if (!cargandoControles && string.IsNullOrWhiteSpace(cmbCategoria.Text))
                        CargarListaCategoriasEnCombo("");
                };

                cmbCategoria.KeyDown += (s, e) =>
                {
                    if (e.KeyCode == System.Windows.Forms.Keys.Escape)
                    {
                        CargarListaCategoriasEnCombo("");
                        cmbCategoria.DroppedDown = false;
                        e.Handled = true;
                        e.SuppressKeyPress = true;
                        return;
                    }

                    if (e.KeyCode == System.Windows.Forms.Keys.Enter)
                    {
                        CategoriaDisponible categoria = ObtenerCategoriaActual();
                        if (categoria == null)
                        {
                            MostrarValidacion("Escribe o selecciona una categoría válida.");
                        }
                        else
                        {
                            ConfirmarCategoriaEnCombo(categoria);
                            LimpiarSeleccionYMapeos();
                            if (chkFiltrarTipo.Checked)
                                SolicitarCargaTipos();
                            else
                                ActualizarEstadoControles();
                        }

                        e.Handled = true;
                        e.SuppressKeyPress = true;
                    }
                };

                cmbCategoria.SelectedIndexChanged += (s, e) =>
                {
                    if (cargandoControles)
                        return;

                    CategoriaDisponible categoria = cmbCategoria.SelectedItem as CategoriaDisponible;
                    if (categoria == null)
                        return;

                    LimpiarSeleccionYMapeos();
                    if (chkFiltrarTipo.Checked)
                        SolicitarCargaTipos();
                    else
                    {
                        tiposTodos.Clear();
                        LimpiarCombo(cmbTipo);
                        ActualizarEstadoControles();
                    }
                };

                chkFiltrarTipo.CheckedChanged += (s, e) =>
                {
                    if (cargandoControles)
                        return;

                    LimpiarSeleccionYMapeos();
                    cmbTipo.Enabled = chkFiltrarTipo.Checked;

                    if (chkFiltrarTipo.Checked)
                        SolicitarCargaTipos();
                    else
                    {
                        tiposTodos.Clear();
                        LimpiarCombo(cmbTipo);
                        MostrarValidacion("Filtro por tipo apagado: se permite cualquier tipo de la categoría.");
                        ActualizarEstadoControles();
                    }
                };

                cmbTipo.TextUpdate += (s, e) =>
                {
                    if (!cargandoControles && chkFiltrarTipo.Checked)
                        FiltrarTiposMientrasEscribe();
                };

                cmbTipo.DropDown += (s, e) =>
                {
                    if (!cargandoControles && chkFiltrarTipo.Checked &&
                        string.IsNullOrWhiteSpace(cmbTipo.Text))
                    {
                        CargarListaTiposEnCombo("");
                    }
                };

                cmbTipo.KeyDown += (s, e) =>
                {
                    if (!chkFiltrarTipo.Checked)
                        return;

                    if (e.KeyCode == System.Windows.Forms.Keys.Escape)
                    {
                        CargarListaTiposEnCombo("");
                        cmbTipo.DroppedDown = false;
                        e.Handled = true;
                        e.SuppressKeyPress = true;
                        return;
                    }

                    if (e.KeyCode == System.Windows.Forms.Keys.Enter)
                    {
                        TipoDisponible tipo = ObtenerTipoActual();
                        if (tipo == null)
                            MostrarValidacion("Escribe o selecciona un tipo válido.");
                        else
                        {
                            ConfirmarTipoEnCombo(tipo);
                            LimpiarSeleccionYMapeos();
                            ActualizarEstadoControles();
                        }

                        e.Handled = true;
                        e.SuppressKeyPress = true;
                    }
                };

                cmbTipo.SelectedIndexChanged += (s, e) =>
                {
                    if (cargandoControles)
                        return;

                    if (cmbTipo.SelectedItem is TipoDisponible)
                    {
                        LimpiarSeleccionYMapeos();
                        ActualizarEstadoControles();
                    }
                };

                chkFormatoPredeterminado.CheckedChanged += (s, e) =>
                {
                    GestionarCambioFormato(chkFormatoPredeterminado);
                };

                chkFormatoOracion.CheckedChanged += (s, e) =>
                {
                    GestionarCambioFormato(chkFormatoOracion);
                };

                chkFormatoMayuscula.CheckedChanged += (s, e) =>
                {
                    GestionarCambioFormato(chkFormatoMayuscula);
                };

                btnSeleccionar.Click += (s, e) =>
                {
                    CategoriaDisponible categoria = ObtenerCategoriaActual();
                    if (categoria == null)
                    {
                        MostrarValidacion("Selecciona o escribe una categoría válida.");
                        return;
                    }

                    TipoDisponible tipo = ObtenerTipoActual();
                    if (chkFiltrarTipo.Checked && tipo == null)
                    {
                        MostrarValidacion("El filtro por tipo está activado. Selecciona o escribe un tipo válido.");
                        return;
                    }

                    Handler.CategoriaIdSeleccionada = categoria.IdCategoria;
                    Handler.FiltrarPorTipo = chkFiltrarTipo.Checked;
                    Handler.TipoIdSeleccionado = chkFiltrarTipo.Checked && tipo != null
                        ? tipo.IdTipo
                        : long.MinValue;

                    SolicitarOperacion(
                        AsignarHabitacionOperacion.SeleccionarElementos,
                        "Selecciona los elementos en Revit y pulsa Finalizar.");
                };

                btnAgregarFila.Click += (s, e) =>
                {
                    if (!operacionPendiente)
                        AgregarFilaMapeo();
                };

                btnQuitarFila.Click += (s, e) =>
                {
                    if (!operacionPendiente)
                        QuitarFilaMapeo();
                };

                btnAsignar.Click += (s, e) =>
                {
                    if (cantidadSeleccionada <= 0)
                    {
                        MostrarValidacion("Primero selecciona uno o más elementos en Revit.");
                        return;
                    }

                    System.Collections.Generic.List<AsignacionParametro> asignaciones =
                        ObtenerAsignacionesValidas(true);

                    if (asignaciones.Count == 0)
                        return;

                    Handler.Asignaciones = asignaciones;
                    Handler.FormatoTexto = ObtenerFormatoTextoSeleccionado();

                    SolicitarOperacion(
                        AsignarHabitacionOperacion.AsignarHabitaciones,
                        "Copiando valores de parámetros de habitación a elementos...");
                };

                btnCerrar.Click += (s, e) =>
                {
                    if (!operacionPendiente)
                        this.Close();
                };

                this.FormClosing += (s, e) =>
                {
                    if (operacionPendiente)
                    {
                        e.Cancel = true;
                        MostrarValidacion("Espera a que termine la operación actual antes de cerrar la ventana.");
                    }
                };
            }

            private void GestionarCambioFormato(System.Windows.Forms.CheckBox seleccionado)
            {
                if (cambiandoFormatoTexto || seleccionado == null)
                    return;

                cambiandoFormatoTexto = true;
                try
                {
                    if (seleccionado.Checked)
                    {
                        if (!object.ReferenceEquals(seleccionado, chkFormatoPredeterminado))
                            chkFormatoPredeterminado.Checked = false;

                        if (!object.ReferenceEquals(seleccionado, chkFormatoOracion))
                            chkFormatoOracion.Checked = false;

                        if (!object.ReferenceEquals(seleccionado, chkFormatoMayuscula))
                            chkFormatoMayuscula.Checked = false;
                    }
                    else if (!chkFormatoPredeterminado.Checked &&
                             !chkFormatoOracion.Checked &&
                             !chkFormatoMayuscula.Checked)
                    {
                        // Siempre debe quedar una opción activa.
                        chkFormatoPredeterminado.Checked = true;
                    }
                }
                finally
                {
                    cambiandoFormatoTexto = false;
                }

                ActualizarEstadoControles();
            }

            private FormatoTextoCopiado ObtenerFormatoTextoSeleccionado()
            {
                if (chkFormatoMayuscula != null && chkFormatoMayuscula.Checked)
                    return FormatoTextoCopiado.Mayuscula;

                if (chkFormatoOracion != null && chkFormatoOracion.Checked)
                    return FormatoTextoCopiado.TipoOracion;

                return FormatoTextoCopiado.Predeterminado;
            }

            private void ConectarEventosComboOrigen(FilaMapeoUI fila)
            {
                fila.ComboOrigen.TextUpdate += (s, e) =>
                {
                    if (!cargandoControles)
                        FiltrarOrigenMientrasEscribe(fila.ComboOrigen);
                };

                fila.ComboOrigen.DropDown += (s, e) =>
                {
                    if (!cargandoControles && string.IsNullOrWhiteSpace(fila.ComboOrigen.Text))
                        CargarListaOrigenEnCombo(fila.ComboOrigen, "");
                };

                fila.ComboOrigen.KeyDown += (s, e) =>
                {
                    if (e.KeyCode == System.Windows.Forms.Keys.Escape)
                    {
                        CargarListaOrigenEnCombo(fila.ComboOrigen, "");
                        fila.ComboOrigen.DroppedDown = false;
                        e.Handled = true;
                        e.SuppressKeyPress = true;
                        return;
                    }

                    if (e.KeyCode == System.Windows.Forms.Keys.Enter)
                    {
                        ParametroHabitacionDisponible p = ObtenerOrigenActual(fila.ComboOrigen);
                        if (p == null)
                            MostrarValidacion("Fila " + fila.Numero.ToString() + ": origen no válido.");
                        else
                            ConfirmarOrigenEnCombo(fila.ComboOrigen, p);

                        ActualizarEstadoControles();
                        e.Handled = true;
                        e.SuppressKeyPress = true;
                    }
                };

                fila.ComboOrigen.SelectedIndexChanged += (s, e) =>
                {
                    if (!cargandoControles)
                        ActualizarEstadoControles();
                };
            }

            private void ConectarEventosComboDestino(FilaMapeoUI fila)
            {
                fila.ComboDestino.TextUpdate += (s, e) =>
                {
                    if (!cargandoControles)
                        FiltrarDestinoMientrasEscribe(fila.ComboDestino);
                };

                fila.ComboDestino.DropDown += (s, e) =>
                {
                    if (!cargandoControles && string.IsNullOrWhiteSpace(fila.ComboDestino.Text))
                        CargarListaDestinoEnCombo(fila.ComboDestino, "");
                };

                fila.ComboDestino.KeyDown += (s, e) =>
                {
                    if (e.KeyCode == System.Windows.Forms.Keys.Escape)
                    {
                        CargarListaDestinoEnCombo(fila.ComboDestino, "");
                        fila.ComboDestino.DroppedDown = false;
                        e.Handled = true;
                        e.SuppressKeyPress = true;
                        return;
                    }

                    if (e.KeyCode == System.Windows.Forms.Keys.Enter)
                    {
                        ParametroInstanciaDisponible p = ObtenerDestinoActual(fila.ComboDestino);
                        if (p == null)
                            MostrarValidacion("Fila " + fila.Numero.ToString() + ": destino no válido.");
                        else if (!p.EsEscribible)
                            MostrarValidacion("Fila " + fila.Numero.ToString() + ": el parámetro destino es de solo lectura.");
                        else
                            ConfirmarDestinoEnCombo(fila.ComboDestino, p);

                        ActualizarEstadoControles();
                        e.Handled = true;
                        e.SuppressKeyPress = true;
                    }
                };

                fila.ComboDestino.SelectedIndexChanged += (s, e) =>
                {
                    if (!cargandoControles)
                        ActualizarEstadoControles();
                };
            }

            private System.Collections.Generic.List<AsignacionParametro> ObtenerAsignacionesValidas(
                bool mostrarMensajes)
            {
                System.Collections.Generic.List<AsignacionParametro> resultado =
                    new System.Collections.Generic.List<AsignacionParametro>();

                System.Collections.Generic.HashSet<string> destinosUsados =
                    new System.Collections.Generic.HashSet<string>(System.StringComparer.OrdinalIgnoreCase);

                foreach (FilaMapeoUI fila in filasMapeo)
                {
                    ParametroHabitacionDisponible origen = ObtenerOrigenActual(fila.ComboOrigen);
                    ParametroInstanciaDisponible destino = ObtenerDestinoActual(fila.ComboDestino);

                    bool filaVacia =
                        string.IsNullOrWhiteSpace(fila.ComboOrigen.Text) &&
                        string.IsNullOrWhiteSpace(fila.ComboDestino.Text);

                    if (filaVacia)
                        continue;

                    if (origen == null)
                    {
                        if (mostrarMensajes)
                            MostrarValidacion("Fila " + fila.Numero.ToString() + ": selecciona un parámetro origen válido.");
                        return new System.Collections.Generic.List<AsignacionParametro>();
                    }

                    if (destino == null)
                    {
                        if (mostrarMensajes)
                            MostrarValidacion("Fila " + fila.Numero.ToString() + ": selecciona un parámetro destino válido.");
                        return new System.Collections.Generic.List<AsignacionParametro>();
                    }

                    if (!destino.EsEscribible)
                    {
                        if (mostrarMensajes)
                            MostrarValidacion("Fila " + fila.Numero.ToString() + ": el parámetro destino es de solo lectura.");
                        return new System.Collections.Generic.List<AsignacionParametro>();
                    }

                    string claveDestino = destino.Clave ?? destino.NombreParametro ?? "";
                    if (!destinosUsados.Add(claveDestino))
                    {
                        if (mostrarMensajes)
                            MostrarValidacion("El parámetro destino '" + (destino.NombreParametro ?? "") + "' está repetido en más de una fila.");
                        return new System.Collections.Generic.List<AsignacionParametro>();
                    }

                    resultado.Add(new AsignacionParametro()
                    {
                        OrigenClave = origen.Clave,
                        OrigenNombre = origen.NombreParametro,
                        OrigenStorage = origen.TipoStorage,
                        DestinoClave = destino.Clave,
                        DestinoNombre = destino.NombreParametro,
                        DestinoStorage = destino.TipoStorage
                    });
                }

                if (mostrarMensajes && resultado.Count == 0)
                {
                    MostrarValidacion("Define al menos un par Parámetro origen → Parámetro destino.");
                }

                return resultado;
            }

            private CategoriaDisponible ObtenerCategoriaActual()
            {
                if (cmbCategoria == null)
                    return null;

                CategoriaDisponible seleccionado = cmbCategoria.SelectedItem as CategoriaDisponible;
                if (seleccionado != null)
                    return seleccionado;

                return BuscarCategoriaPorTexto(cmbCategoria.Text == null ? "" : cmbCategoria.Text.Trim());
            }

            private TipoDisponible ObtenerTipoActual()
            {
                if (!chkFiltrarTipo.Checked || cmbTipo == null)
                    return null;

                TipoDisponible seleccionado = cmbTipo.SelectedItem as TipoDisponible;
                if (seleccionado != null)
                    return seleccionado;

                return BuscarTipoPorTexto(cmbTipo.Text == null ? "" : cmbTipo.Text.Trim());
            }

            private ParametroHabitacionDisponible ObtenerOrigenActual(System.Windows.Forms.ComboBox combo)
            {
                if (combo == null)
                    return null;

                ParametroHabitacionDisponible seleccionado = combo.SelectedItem as ParametroHabitacionDisponible;
                if (seleccionado != null)
                    return seleccionado;

                return BuscarOrigenPorTexto(combo.Text == null ? "" : combo.Text.Trim());
            }

            private ParametroInstanciaDisponible ObtenerDestinoActual(System.Windows.Forms.ComboBox combo)
            {
                if (combo == null)
                    return null;

                ParametroInstanciaDisponible seleccionado = combo.SelectedItem as ParametroInstanciaDisponible;
                if (seleccionado != null)
                    return seleccionado;

                return BuscarDestinoPorTexto(combo.Text == null ? "" : combo.Text.Trim());
            }

            private CategoriaDisponible BuscarCategoriaPorTexto(string texto)
            {
                if (string.IsNullOrWhiteSpace(texto))
                    return null;

                CategoriaDisponible unica = null;
                int coincidencias = 0;

                foreach (CategoriaDisponible item in categoriasTodas)
                {
                    if (item == null)
                        continue;

                    if (EsCoincidenciaExacta(texto, item.NombreCategoria, item.ToString()))
                        return item;

                    if (CoincideBusqueda(texto, (item.NombreCategoria ?? "") + " " + item.ToString()))
                    {
                        unica = item;
                        coincidencias++;
                    }
                }

                return coincidencias == 1 ? unica : null;
            }

            private TipoDisponible BuscarTipoPorTexto(string texto)
            {
                if (string.IsNullOrWhiteSpace(texto))
                    return null;

                TipoDisponible unica = null;
                int coincidencias = 0;

                foreach (TipoDisponible item in tiposTodos)
                {
                    if (item == null)
                        continue;

                    string natural = (item.NombreFamilia ?? "") + " : " + (item.NombreTipo ?? "");
                    if (EsCoincidenciaExacta(texto, natural, item.NombreTipo, item.ToString()))
                        return item;

                    if (CoincideBusqueda(texto, natural + " " + item.ToString()))
                    {
                        unica = item;
                        coincidencias++;
                    }
                }

                return coincidencias == 1 ? unica : null;
            }

            private ParametroHabitacionDisponible BuscarOrigenPorTexto(string texto)
            {
                if (string.IsNullOrWhiteSpace(texto))
                    return null;

                ParametroHabitacionDisponible unica = null;
                int coincidencias = 0;

                foreach (ParametroHabitacionDisponible item in parametrosHabitacionTodos)
                {
                    if (item == null)
                        continue;

                    if (EsCoincidenciaExacta(texto, item.NombreParametro, item.ToString()))
                        return item;

                    if (CoincideBusqueda(texto,
                        (item.NombreParametro ?? "") + " " +
                        (item.TipoDato ?? "") + " " + item.ToString()))
                    {
                        unica = item;
                        coincidencias++;
                    }
                }

                return coincidencias == 1 ? unica : null;
            }

            private ParametroInstanciaDisponible BuscarDestinoPorTexto(string texto)
            {
                if (string.IsNullOrWhiteSpace(texto))
                    return null;

                ParametroInstanciaDisponible unica = null;
                int coincidencias = 0;

                foreach (ParametroInstanciaDisponible item in parametrosDestinoTodos)
                {
                    if (item == null)
                        continue;

                    if (EsCoincidenciaExacta(texto, item.NombreParametro, item.ToString()))
                        return item;

                    if (CoincideBusqueda(texto,
                        (item.NombreParametro ?? "") + " " +
                        (item.TipoDato ?? "") + " " + item.ToString()))
                    {
                        unica = item;
                        coincidencias++;
                    }
                }

                return coincidencias == 1 ? unica : null;
            }

            private bool EsCoincidenciaExacta(string texto, params string[] opciones)
            {
                if (string.IsNullOrWhiteSpace(texto) || opciones == null)
                    return false;

                foreach (string opcion in opciones)
                {
                    if (string.Equals(
                        texto.Trim(),
                        (opcion ?? "").Trim(),
                        System.StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }

                return false;
            }

            private bool CoincideBusqueda(string consulta, string texto)
            {
                if (string.IsNullOrWhiteSpace(consulta))
                    return true;

                string baseTexto = (texto ?? "").ToUpperInvariant();
                string[] palabras = consulta.Trim().ToUpperInvariant().Split(
                    new char[] { ' ' },
                    System.StringSplitOptions.RemoveEmptyEntries);

                foreach (string palabra in palabras)
                {
                    if (baseTexto.IndexOf(palabra, System.StringComparison.OrdinalIgnoreCase) < 0)
                        return false;
                }

                return true;
            }

            private void FiltrarCategoriasMientrasEscribe()
            {
                string texto = cmbCategoria.Text == null ? "" : cmbCategoria.Text;
                System.Collections.Generic.List<CategoriaDisponible> filtrados =
                    new System.Collections.Generic.List<CategoriaDisponible>();

                foreach (CategoriaDisponible item in categoriasTodas)
                {
                    if (item != null && CoincideBusqueda(texto,
                        (item.NombreCategoria ?? "") + " " + item.ToString()))
                    {
                        filtrados.Add(item);
                    }
                }

                ReemplazarItemsCombo(cmbCategoria, filtrados, texto);
                MostrarResultadoBusqueda(cmbCategoria, filtrados.Count, "categoría");
            }

            private void FiltrarTiposMientrasEscribe()
            {
                string texto = cmbTipo.Text == null ? "" : cmbTipo.Text;
                System.Collections.Generic.List<TipoDisponible> filtrados =
                    new System.Collections.Generic.List<TipoDisponible>();

                foreach (TipoDisponible item in tiposTodos)
                {
                    if (item != null && CoincideBusqueda(texto,
                        (item.NombreFamilia ?? "") + " " +
                        (item.NombreTipo ?? "") + " " + item.ToString()))
                    {
                        filtrados.Add(item);
                    }
                }

                ReemplazarItemsCombo(cmbTipo, filtrados, texto);
                MostrarResultadoBusqueda(cmbTipo, filtrados.Count, "tipo");
            }

            private void FiltrarOrigenMientrasEscribe(System.Windows.Forms.ComboBox combo)
            {
                string texto = combo.Text == null ? "" : combo.Text;
                System.Collections.Generic.List<ParametroHabitacionDisponible> filtrados =
                    new System.Collections.Generic.List<ParametroHabitacionDisponible>();

                foreach (ParametroHabitacionDisponible item in parametrosHabitacionTodos)
                {
                    if (item != null && CoincideBusqueda(texto,
                        (item.NombreParametro ?? "") + " " +
                        (item.TipoDato ?? "") + " " + item.ToString()))
                    {
                        filtrados.Add(item);
                    }
                }

                ReemplazarItemsCombo(combo, filtrados, texto);
                MostrarResultadoBusqueda(combo, filtrados.Count, "parámetro origen");
            }

            private void FiltrarDestinoMientrasEscribe(System.Windows.Forms.ComboBox combo)
            {
                string texto = combo.Text == null ? "" : combo.Text;
                System.Collections.Generic.List<ParametroInstanciaDisponible> filtrados =
                    new System.Collections.Generic.List<ParametroInstanciaDisponible>();

                foreach (ParametroInstanciaDisponible item in parametrosDestinoTodos)
                {
                    if (item != null && CoincideBusqueda(texto,
                        (item.NombreParametro ?? "") + " " +
                        (item.TipoDato ?? "") + " " + item.ToString()))
                    {
                        filtrados.Add(item);
                    }
                }

                ReemplazarItemsCombo(combo, filtrados, texto);
                MostrarResultadoBusqueda(combo, filtrados.Count, "parámetro destino");
            }

            private void CargarListaCategoriasEnCombo(string texto)
            {
                ReemplazarItemsCombo(cmbCategoria, categoriasTodas, texto ?? "");
            }

            private void CargarListaTiposEnCombo(string texto)
            {
                ReemplazarItemsCombo(cmbTipo, tiposTodos, texto ?? "");
            }

            private void CargarListaOrigenEnCombo(System.Windows.Forms.ComboBox combo, string texto)
            {
                ReemplazarItemsCombo(combo, parametrosHabitacionTodos, texto ?? "");
            }

            private void CargarListaDestinoEnCombo(System.Windows.Forms.ComboBox combo, string texto)
            {
                ReemplazarItemsCombo(combo, parametrosDestinoTodos, texto ?? "");
            }

            private void ReemplazarItemsCombo<T>(
                System.Windows.Forms.ComboBox combo,
                System.Collections.Generic.IEnumerable<T> items,
                string texto)
            {
                if (combo == null)
                    return;

                cargandoControles = true;
                try
                {
                    combo.BeginUpdate();
                    combo.DataSource = null;
                    combo.Items.Clear();

                    if (items != null)
                    {
                        foreach (T item in items)
                        {
                            if (item != null)
                                combo.Items.Add(item);
                        }
                    }

                    combo.SelectedIndex = -1;
                    combo.Text = texto ?? "";
                    combo.SelectionStart = combo.Text.Length;
                    combo.SelectionLength = 0;
                }
                finally
                {
                    try
                    {
                        combo.EndUpdate();
                    }
                    catch
                    {
                    }

                    cargandoControles = false;
                }
            }

            private void MostrarResultadoBusqueda(
                System.Windows.Forms.ComboBox combo,
                int cantidad,
                string nombre)
            {
                if (cantidad > 0)
                {
                    try
                    {
                        combo.DroppedDown = true;
                        combo.SelectionStart = combo.Text.Length;
                    }
                    catch
                    {
                    }

                    MostrarValidacion(cantidad.ToString() + " " + nombre + "(s) coinciden con la búsqueda.");
                }
                else
                {
                    MostrarValidacion("No hay " + nombre + "s que coincidan con la búsqueda.");
                }
            }

            private void ConfirmarCategoriaEnCombo(CategoriaDisponible item)
            {
                ConfirmarItemCombo(cmbCategoria, item, item == null ? "" : item.NombreCategoria);
            }

            private void ConfirmarTipoEnCombo(TipoDisponible item)
            {
                string texto = item == null
                    ? ""
                    : (string.IsNullOrWhiteSpace(item.NombreFamilia)
                        ? item.NombreTipo
                        : item.NombreFamilia + " : " + item.NombreTipo);

                ConfirmarItemCombo(cmbTipo, item, texto);
            }

            private void ConfirmarOrigenEnCombo(
                System.Windows.Forms.ComboBox combo,
                ParametroHabitacionDisponible item)
            {
                ConfirmarItemCombo(combo, item, item == null ? "" : item.NombreParametro);
            }

            private void ConfirmarDestinoEnCombo(
                System.Windows.Forms.ComboBox combo,
                ParametroInstanciaDisponible item)
            {
                ConfirmarItemCombo(combo, item, item == null ? "" : item.NombreParametro);
            }

            private void ConfirmarItemCombo(
                System.Windows.Forms.ComboBox combo,
                object item,
                string textoVisible)
            {
                if (combo == null || item == null)
                    return;

                cargandoControles = true;
                try
                {
                    combo.DroppedDown = false;
                    combo.DataSource = null;
                    combo.Items.Clear();
                    combo.Items.Add(item);
                    combo.SelectedItem = item;
                    combo.Text = textoVisible ?? item.ToString();
                    combo.SelectionStart = combo.Text.Length;
                }
                finally
                {
                    cargandoControles = false;
                }
            }

            private void LimpiarCombo(System.Windows.Forms.ComboBox combo)
            {
                if (combo == null)
                    return;

                cargandoControles = true;
                try
                {
                    combo.DataSource = null;
                    combo.Items.Clear();
                    combo.SelectedIndex = -1;
                    combo.Text = "";
                }
                finally
                {
                    cargandoControles = false;
                }
            }

            private void LimpiarSeleccionYMapeos()
            {
                cantidadSeleccionada = 0;
                lblSeleccion.Text = "0 elementos seleccionados";
                dgvElementos.DataSource = null;
                parametrosHabitacionTodos.Clear();
                parametrosDestinoTodos.Clear();

                foreach (FilaMapeoUI fila in filasMapeo)
                {
                    LimpiarCombo(fila.ComboOrigen);
                    LimpiarCombo(fila.ComboDestino);
                }

                if (Handler != null)
                {
                    Handler.ElementosSeleccionados =
                        new System.Collections.Generic.List<Autodesk.Revit.DB.ElementId>();
                    Handler.Asignaciones =
                        new System.Collections.Generic.List<AsignacionParametro>();
                }
            }

            private void SolicitarCargaTipos()
            {
                CategoriaDisponible categoria = ObtenerCategoriaActual();
                if (categoria == null)
                {
                    tiposTodos.Clear();
                    LimpiarCombo(cmbTipo);
                    ActualizarEstadoControles();
                    return;
                }

                Handler.CategoriaIdSeleccionada = categoria.IdCategoria;
                SolicitarOperacion(
                    AsignarHabitacionOperacion.CargarTipos,
                    "Cargando tipos de la categoría...");
            }

            private void SolicitarOperacion(
                AsignarHabitacionOperacion operacion,
                string estado)
            {
                if (operacionPendiente)
                    return;

                if (Handler == null || EjecutarEvent == null)
                {
                    MostrarError("La ventana no está conectada al ExternalEvent de Revit.");
                    return;
                }

                operacionPendiente = true;
                Handler.Operacion = operacion;
                lblEstado.Text = estado ?? "Procesando...";
                lblEstado.ForeColor = System.Drawing.Color.FromArgb(65, 65, 65);
                barraTrabajo.Visible = true;
                ActualizarEstadoControles();

                try
                {
                    EjecutarEvent.Raise();
                }
                catch (System.Exception ex)
                {
                    operacionPendiente = false;
                    barraTrabajo.Visible = false;
                    lblEstado.Text = "ERROR: " + ex.Message;
                    lblEstado.ForeColor = System.Drawing.Color.FromArgb(180, 35, 35);
                    ActualizarEstadoControles();
                    MostrarError("ERROR: " + ex.Message);
                }
            }

            public void CargarCategoriasEnVentana(
                System.Collections.Generic.List<CategoriaDisponible> categorias)
            {
                EjecutarEnUI(() =>
                {
                    categoriasTodas = categorias ??
                        new System.Collections.Generic.List<CategoriaDisponible>();

                    CargarListaCategoriasEnCombo("");
                    cmbCategoria.SelectedIndex = -1;
                    cmbCategoria.Text = "";

                    tiposTodos.Clear();
                    LimpiarCombo(cmbTipo);
                    LimpiarSeleccionYMapeos();

                    FinalizarOperacionInterna(
                        "Categorías cargadas. Escribe para buscar o abre el desplegable.",
                        false);
                });
            }

            public void CargarTiposEnVentana(
                System.Collections.Generic.List<TipoDisponible> tipos)
            {
                EjecutarEnUI(() =>
                {
                    tiposTodos = tipos ?? new System.Collections.Generic.List<TipoDisponible>();
                    CargarListaTiposEnCombo("");
                    cmbTipo.SelectedIndex = -1;
                    cmbTipo.Text = "";

                    FinalizarOperacionInterna(
                        tiposTodos.Count > 0
                            ? "Tipos cargados. Escribe para buscar el tipo."
                            : "La categoría seleccionada no tiene tipos disponibles.",
                        false);
                });
            }

            public void CargarSeleccionEnVentana(
                System.Collections.Generic.List<ParametroHabitacionDisponible> parametrosOrigen,
                System.Collections.Generic.List<ParametroInstanciaDisponible> parametrosDestino,
                System.Collections.Generic.List<ResultadoElemento> resultados)
            {
                EjecutarEnUI(() =>
                {
                    parametrosHabitacionTodos = parametrosOrigen ??
                        new System.Collections.Generic.List<ParametroHabitacionDisponible>();

                    parametrosDestinoTodos = parametrosDestino ??
                        new System.Collections.Generic.List<ParametroInstanciaDisponible>();

                    foreach (FilaMapeoUI fila in filasMapeo)
                    {
                        CargarListaOrigenEnCombo(fila.ComboOrigen, "");
                        fila.ComboOrigen.SelectedIndex = -1;
                        fila.ComboOrigen.Text = "";

                        CargarListaDestinoEnCombo(fila.ComboDestino, "");
                        fila.ComboDestino.SelectedIndex = -1;
                        fila.ComboDestino.Text = "";
                    }

                    // Mantiene la funcionalidad anterior como ayuda: en la primera fila
                    // intenta proponer "Nombre" como origen, pero NO elige destino automáticamente.
                    if (filasMapeo.Count > 0)
                    {
                        ParametroHabitacionDisponible nombre = BuscarOrigenPorTexto("Nombre");
                        if (nombre == null)
                            nombre = BuscarOrigenPorTexto("Name");

                        if (nombre != null)
                            ConfirmarOrigenEnCombo(filasMapeo[0].ComboOrigen, nombre);
                    }

                    dgvElementos.DataSource = null;
                    dgvElementos.DataSource = resultados ??
                        new System.Collections.Generic.List<ResultadoElemento>();

                    cantidadSeleccionada = resultados == null ? 0 : resultados.Count;
                    lblSeleccion.Text = cantidadSeleccionada.ToString() +
                        (cantidadSeleccionada == 1 ? " elemento seleccionado" : " elementos seleccionados");

                    int conHabitacion = 0;
                    int sinHabitacion = 0;
                    if (resultados != null)
                    {
                        foreach (ResultadoElemento item in resultados)
                        {
                            if (item == null)
                                continue;

                            if (string.IsNullOrWhiteSpace(item.Habitacion))
                                sinHabitacion++;
                            else
                                conHabitacion++;
                        }
                    }

                    FinalizarOperacionInterna(
                        "Selección cargada. Habitaciones: " + conHabitacion.ToString() +
                        " detectadas / " + sinHabitacion.ToString() + " sin detectar. " +
                        "Origen: " + parametrosHabitacionTodos.Count.ToString() +
                        " parámetros únicos | Destino: " + parametrosDestinoTodos.Count.ToString() +
                        " parámetros únicos.",
                        false);
                });
            }

            public void FinalizarAsignacion(
                string mensaje,
                System.Collections.Generic.List<ResultadoElemento> resultadosActualizados)
            {
                EjecutarEnUI(() =>
                {
                    if (resultadosActualizados != null)
                    {
                        dgvElementos.DataSource = null;
                        dgvElementos.DataSource = resultadosActualizados;
                    }

                    // Sin MessageBox de éxito.
                    FinalizarOperacionInterna(
                        mensaje ?? "Copia terminada.",
                        false);
                });
            }

            public void FinalizarOperacion(string mensaje, bool esError)
            {
                EjecutarEnUI(() =>
                {
                    FinalizarOperacionInterna(mensaje, esError);

                    // Ventana emergente SOLO cuando hay error real.
                    if (esError)
                        MostrarError(mensaje ?? "Error desconocido.");
                });
            }

            private void FinalizarOperacionInterna(string mensaje, bool esError)
            {
                operacionPendiente = false;
                barraTrabajo.Visible = false;
                lblEstado.Text = mensaje ?? "";
                lblEstado.ForeColor = esError
                    ? System.Drawing.Color.FromArgb(180, 35, 35)
                    : System.Drawing.Color.FromArgb(65, 65, 65);
                ActualizarEstadoControles();
            }

            private void ActualizarEstadoControles()
            {
                bool categoriaValida = ObtenerCategoriaActual() != null;
                bool tipoValido = !chkFiltrarTipo.Checked || ObtenerTipoActual() != null;

                cmbCategoria.Enabled = !operacionPendiente;
                chkFiltrarTipo.Enabled = !operacionPendiente;
                cmbTipo.Enabled = !operacionPendiente && chkFiltrarTipo.Checked;

                if (chkFormatoPredeterminado != null)
                    chkFormatoPredeterminado.Enabled = !operacionPendiente;
                if (chkFormatoOracion != null)
                    chkFormatoOracion.Enabled = !operacionPendiente;
                if (chkFormatoMayuscula != null)
                    chkFormatoMayuscula.Enabled = !operacionPendiente;

                btnSeleccionar.Enabled =
                    !operacionPendiente && categoriaValida && tipoValido;

                btnAgregarFila.Enabled =
                    !operacionPendiente && cantidadSeleccionada > 0 && filasMapeo.Count < MAX_FILAS;

                btnQuitarFila.Enabled =
                    !operacionPendiente && cantidadSeleccionada > 0;

                foreach (FilaMapeoUI fila in filasMapeo)
                {
                    fila.ComboOrigen.Enabled = !operacionPendiente && cantidadSeleccionada > 0;
                    fila.ComboDestino.Enabled = !operacionPendiente && cantidadSeleccionada > 0;
                }

                bool hayMapeoValido = false;
                if (cantidadSeleccionada > 0)
                {
                    foreach (FilaMapeoUI fila in filasMapeo)
                    {
                        ParametroHabitacionDisponible origen = ObtenerOrigenActual(fila.ComboOrigen);
                        ParametroInstanciaDisponible destino = ObtenerDestinoActual(fila.ComboDestino);
                        if (origen != null && destino != null && destino.EsEscribible)
                        {
                            hayMapeoValido = true;
                            break;
                        }
                    }
                }

                btnAsignar.Enabled = !operacionPendiente && cantidadSeleccionada > 0 && hayMapeoValido;
                btnCerrar.Enabled = !operacionPendiente;
            }

            private void MostrarValidacion(string mensaje)
            {
                if (lblEstado == null)
                    return;

                lblEstado.Text = mensaje ?? "";
                lblEstado.ForeColor = System.Drawing.Color.FromArgb(95, 95, 95);
            }

            private void MostrarError(string mensaje)
            {
                System.Windows.Forms.MessageBox.Show(
                    this,
                    mensaje ?? "",
                    "MYG - Copiar Parámetros de Habitación",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Error);
            }

            private void EjecutarEnUI(System.Action accion)
            {
                if (this.IsDisposed || accion == null)
                    return;

                if (this.InvokeRequired)
                {
                    try
                    {
                        this.BeginInvoke(accion);
                    }
                    catch
                    {
                    }
                    return;
                }

                accion();
            }
        }
    }

}
