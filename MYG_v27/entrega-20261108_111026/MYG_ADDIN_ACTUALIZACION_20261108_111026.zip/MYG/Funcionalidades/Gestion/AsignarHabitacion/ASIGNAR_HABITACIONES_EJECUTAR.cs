﻿// =====================================
// HANDLER EXTERNO 3.2 OPTIMIZADO - COPIAR PARÁMETROS DE HABITACIÓN A ELEMENTOS
// HASTA 5 PARES ORIGEN -> DESTINO
// DETECCIÓN RÁPIDA + CACHÉ + FALLBACK CERCANA EN Z + TODOS LOS PARÁMETROS HOMÓNIMOS
// FORMATO DE TEXTO: PREDETERMINADO / TIPO ORACIÓN / MAYÚSCULA
// CON USING Y NAMESPACE
// REVIT 2027
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace MYG_Addin
{
    public class AsignarHabitacionParametroExternalEventHandler :
        IExternalEventHandler
    {
        private sealed class FiltroSeleccionCategoriaTipo :
            ISelectionFilter
        {
            private readonly long categoriaId;
            private readonly bool filtrarTipo;
            private readonly long tipoId;

            public FiltroSeleccionCategoriaTipo(
                long categoriaId,
                bool filtrarTipo,
                long tipoId)
            {
                this.categoriaId = categoriaId;
                this.filtrarTipo = filtrarTipo;
                this.tipoId = tipoId;
            }

            public bool AllowElement(Element elem)
            {
                if (elem == null || elem.Category == null)
                    return false;

                if (elem.Category.Id.Value != categoriaId)
                    return false;

                if (!filtrarTipo)
                    return true;

                ElementId idTipo = elem.GetTypeId();
                if (idTipo == null || idTipo == ElementId.InvalidElementId)
                    return false;

                return idTipo.Value == tipoId;
            }

            public bool AllowReference(Reference reference, XYZ position)
            {
                return true;
            }
        }

        private sealed class AcumuladorDestino
        {
            public AsignarHabitacionParametro29.ParametroInstanciaDisponible Item;
            public HashSet<long> ElementosConParametro = new HashSet<long>();
            public HashSet<long> ElementosEscribibles = new HashSet<long>();
            public HashSet<string> TiposStorage =
                new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        }

        private sealed class AcumuladorOrigen
        {
            public AsignarHabitacionParametro29.ParametroHabitacionDisponible Item;
            public HashSet<string> HabitacionesConParametro =
                new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            public HashSet<string> TiposStorage =
                new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        }

        private sealed class ConjuntoHabitacionesVinculo
        {
            public RevitLinkInstance Instancia;
            public Document Documento;
            public Transform HostAVinculo;
            public string NombreVinculo;
            public List<Room> Habitaciones = new List<Room>();
            public List<RoomInfoEspacial> IndiceHabitaciones =
                new List<RoomInfoEspacial>();
        }

        // V3.1: la caja de cada Room se calcula UNA sola vez.
        // Después, la gran mayoría de rooms se descarta con comparaciones numéricas
        // antes de llamar a Room.IsPointInRoom(), que es mucho más costoso.
        private sealed class RoomInfoEspacial
        {
            public Room Habitacion;
            public double MinX;
            public double MaxX;
            public double MinY;
            public double MaxY;
            public double MinZ;
            public double MaxZ;
        }

        private sealed class RoomDetectado
        {
            public Document Documento;
            public Room Habitacion;
            public string Origen;
            public string Clave;
        }

        private sealed class DeteccionHabitacion
        {
            public List<RoomDetectado> Habitaciones = new List<RoomDetectado>();
            public string Nombre = "";
            public string Origen = "";

            public bool Encontrada
            {
                get { return Habitaciones != null && Habitaciones.Count > 0; }
            }
        }

        // V3.0: candidato para la búsqueda de la habitación más cercana
        // verticalmente cuando el elemento no está físicamente dentro de un Room.
        private sealed class CandidatoHabitacionVertical
        {
            public RoomDetectado RoomDetectado;
            public XYZ PuntoInterior;
            public double DistanciaVertical = double.MaxValue;
            public double DeltaZ = 0.0;
            public int IndicePunto = -1;
        }

        private sealed class ValorParametroOrigen
        {
            public StorageType StorageType;
            public string Texto = "";
            public int Entero;
            public double Doble;
            public ElementId ElementIdValor = ElementId.InvalidElementId;
            public Document DocumentoOrigen;
            public string ClaveInterna = "";
        }

        private sealed class ResultadoEscritura
        {
            public bool Correcto;
            public bool EsError;
            public string Motivo = "";
        }

        public UIDocument UiDoc;
        public AsignarHabitacionParametro29.AsignarHabitacionParametroForm
            FormInicial;

        public AsignarHabitacionParametro29.AsignarHabitacionOperacion
            Operacion =
                AsignarHabitacionParametro29.AsignarHabitacionOperacion.Ninguna;

        public long CategoriaIdSeleccionada = long.MinValue;
        public bool FiltrarPorTipo = false;
        public long TipoIdSeleccionado = long.MinValue;

        public List<ElementId> ElementosSeleccionados =
            new List<ElementId>();

        // V3.1: caché de detecciones. Al pulsar COPIAR PARÁMETROS ya NO se
        // vuelve a recorrer habitaciones/vínculos si la selección es la misma.
        private Document _documentoCacheDetecciones = null;
        private Dictionary<long, DeteccionHabitacion> _cacheDetecciones =
            new Dictionary<long, DeteccionHabitacion>();
        private HashSet<long> _cacheIdsElementos = new HashSet<long>();

        public List<AsignarHabitacionParametro29.AsignacionParametro>
            Asignaciones =
                new List<AsignarHabitacionParametro29.AsignacionParametro>();

        // V3.2: formato aplicado solamente cuando el parámetro destino es Texto.
        public AsignarHabitacionParametro29.FormatoTextoCopiado FormatoTexto =
            AsignarHabitacionParametro29.FormatoTextoCopiado.Predeterminado;

        // Se conserva por compatibilidad con versiones anteriores del formulario.
        public AsignarHabitacionParametro29.ParametroInstanciaDisponible
            ParametroSeleccionado;

        public void Execute(UIApplication app)
        {
            AsignarHabitacionParametro29.AsignarHabitacionOperacion operacionActual =
                Operacion;

            Operacion =
                AsignarHabitacionParametro29.AsignarHabitacionOperacion.Ninguna;

            try
            {
                if (operacionActual ==
                    AsignarHabitacionParametro29.AsignarHabitacionOperacion.Ninguna)
                {
                    return;
                }

                UIDocument uidoc = ObtenerUiDocument(app);
                Document doc = uidoc.Document;

                switch (operacionActual)
                {
                    case AsignarHabitacionParametro29.AsignarHabitacionOperacion.CargarCategorias:
                        EjecutarCargaCategorias(doc);
                        break;

                    case AsignarHabitacionParametro29.AsignarHabitacionOperacion.CargarTipos:
                        EjecutarCargaTipos(doc);
                        break;

                    case AsignarHabitacionParametro29.AsignarHabitacionOperacion.SeleccionarElementos:
                        EjecutarSeleccionElementos(uidoc, doc);
                        break;

                    case AsignarHabitacionParametro29.AsignarHabitacionOperacion.AsignarHabitaciones:
                        EjecutarAsignacion(doc);
                        break;
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                if (FormInicial != null)
                {
                    FormInicial.FinalizarOperacion(
                        "Selección cancelada. No se modificó el modelo.",
                        false);
                }
            }
            catch (Exception ex)
            {
                if (FormInicial != null)
                {
                    FormInicial.FinalizarOperacion(
                        "ERROR: " + ex.Message,
                        true);
                }
            }
        }

        public string GetName()
        {
            return "MYG - Copiar Parámetros de Habitación a Elementos";
        }

        private UIDocument ObtenerUiDocument(UIApplication app)
        {
            UIDocument activo = app != null ? app.ActiveUIDocument : null;

            if (activo == null || activo.Document == null)
            {
                throw new InvalidOperationException(
                    "No hay un documento activo en Revit.");
            }

            if (UiDoc != null &&
                UiDoc.Document != null &&
                UiDoc.Document.IsValidObject &&
                !activo.Document.Equals(UiDoc.Document))
            {
                throw new InvalidOperationException(
                    "La ventana pertenece a otro documento de Revit. " +
                    "Vuelve al documento donde abriste la herramienta o cierra la ventana.");
            }

            UiDoc = activo;
            return activo;
        }

        private void EjecutarCargaCategorias(Document doc)
        {
            Dictionary<long, AsignarHabitacionParametro29.CategoriaDisponible> mapa =
                new Dictionary<long, AsignarHabitacionParametro29.CategoriaDisponible>();

            FilteredElementCollector collector =
                new FilteredElementCollector(doc).WhereElementIsNotElementType();

            foreach (Element e in collector)
            {
                if (!EsElementoSeleccionableDeModelo(e))
                    continue;

                long idCategoria = e.Category.Id.Value;

                AsignarHabitacionParametro29.CategoriaDisponible item;
                if (!mapa.TryGetValue(idCategoria, out item))
                {
                    item = new AsignarHabitacionParametro29.CategoriaDisponible()
                    {
                        IdCategoria = idCategoria,
                        NombreCategoria = e.Category.Name,
                        CantidadElementos = 0
                    };

                    mapa.Add(idCategoria, item);
                }

                item.CantidadElementos++;
            }

            List<AsignarHabitacionParametro29.CategoriaDisponible> categorias =
                mapa.Values
                    .Where(x => x != null)
                    .OrderBy(x => x.NombreCategoria)
                    .ToList();

            if (categorias.Count == 0)
            {
                throw new InvalidOperationException(
                    "No se encontraron categorías de modelo con elementos de instancia.");
            }

            if (FormInicial != null)
                FormInicial.CargarCategoriasEnVentana(categorias);
        }

        private void EjecutarCargaTipos(Document doc)
        {
            if (CategoriaIdSeleccionada == long.MinValue)
            {
                throw new InvalidOperationException(
                    "No se recibió una categoría válida.");
            }

            Dictionary<long, AsignarHabitacionParametro29.TipoDisponible> mapa =
                new Dictionary<long, AsignarHabitacionParametro29.TipoDisponible>();

            IEnumerable<Element> elementos =
                new FilteredElementCollector(doc)
                    .WhereElementIsNotElementType()
                    .Where(e =>
                        e != null &&
                        e.Category != null &&
                        e.Category.Id.Value == CategoriaIdSeleccionada);

            foreach (Element e in elementos)
            {
                ElementId idTipo = e.GetTypeId();
                if (idTipo == null || idTipo == ElementId.InvalidElementId)
                    continue;

                long id = idTipo.Value;
                AsignarHabitacionParametro29.TipoDisponible item;

                if (!mapa.TryGetValue(id, out item))
                {
                    Element tipo = doc.GetElement(idTipo);
                    string familia;
                    string nombreTipo;
                    ObtenerNombresTipo(tipo, out familia, out nombreTipo);

                    item = new AsignarHabitacionParametro29.TipoDisponible()
                    {
                        IdTipo = id,
                        NombreFamilia = familia,
                        NombreTipo = nombreTipo,
                        CantidadElementos = 0
                    };

                    mapa.Add(id, item);
                }

                item.CantidadElementos++;
            }

            List<AsignarHabitacionParametro29.TipoDisponible> tipos =
                mapa.Values
                    .Where(x => x != null)
                    .OrderBy(x => x.NombreFamilia)
                    .ThenBy(x => x.NombreTipo)
                    .ToList();

            if (FormInicial != null)
                FormInicial.CargarTiposEnVentana(tipos);
        }

        private void EjecutarSeleccionElementos(
            UIDocument uidoc,
            Document doc)
        {
            if (CategoriaIdSeleccionada == long.MinValue)
            {
                throw new InvalidOperationException(
                    "Selecciona una categoría válida antes de seleccionar elementos.");
            }

            if (FiltrarPorTipo && TipoIdSeleccionado == long.MinValue)
            {
                throw new InvalidOperationException(
                    "El filtro por tipo está activado pero no se recibió un tipo válido.");
            }

            FiltroSeleccionCategoriaTipo filtro =
                new FiltroSeleccionCategoriaTipo(
                    CategoriaIdSeleccionada,
                    FiltrarPorTipo,
                    TipoIdSeleccionado);

            string mensaje = FiltrarPorTipo
                ? "Selecciona uno o más elementos del tipo elegido y pulsa Finalizar."
                : "Selecciona uno o más elementos de la categoría elegida y pulsa Finalizar.";

            IList<Reference> referencias =
                uidoc.Selection.PickObjects(
                    ObjectType.Element,
                    filtro,
                    mensaje);

            List<ElementId> ids = referencias == null
                ? new List<ElementId>()
                : referencias
                    .Where(x => x != null)
                    .Select(x => x.ElementId)
                    .Where(x => x != null && x != ElementId.InvalidElementId)
                    .GroupBy(x => x.Value)
                    .Select(x => x.First())
                    .ToList();

            if (ids.Count == 0)
            {
                throw new InvalidOperationException(
                    "No se seleccionó ningún elemento válido.");
            }

            ElementosSeleccionados = ids;
            Asignaciones = new List<AsignarHabitacionParametro29.AsignacionParametro>();
            ParametroSeleccionado = null;

            uidoc.Selection.SetElementIds(ids);

            List<Element> elementos = ids
                .Select(id => doc.GetElement(id))
                .Where(e => e != null && e.IsValidObject)
                .ToList();

            List<Room> habitacionesHost = ObtenerHabitacionesValidas(doc);
            List<ConjuntoHabitacionesVinculo> habitacionesVinculadas =
                ObtenerHabitacionesVinculadasValidas(doc);

            Dictionary<long, DeteccionHabitacion> detecciones =
                DetectarHabitacionesPorElemento(
                    doc,
                    elementos,
                    habitacionesHost,
                    habitacionesVinculadas);

            GuardarCacheDetecciones(doc, elementos, detecciones);

            List<AsignarHabitacionParametro29.ParametroHabitacionDisponible>
                parametrosOrigen =
                    ObtenerParametrosHabitacionesDetectadas(detecciones);

            List<AsignarHabitacionParametro29.ParametroInstanciaDisponible>
                parametrosDestino =
                    ObtenerParametrosDestino(elementos);

            List<AsignarHabitacionParametro29.ResultadoElemento> resultados =
                CrearResultadosElementos(
                    doc,
                    elementos,
                    detecciones,
                    null);

            if (FormInicial != null)
            {
                FormInicial.CargarSeleccionEnVentana(
                    parametrosOrigen,
                    parametrosDestino,
                    resultados);
            }
        }

        private void EjecutarAsignacion(Document doc)
        {
            if (ElementosSeleccionados == null || ElementosSeleccionados.Count == 0)
            {
                throw new InvalidOperationException(
                    "No hay elementos seleccionados para procesar.");
            }

            List<AsignarHabitacionParametro29.AsignacionParametro> pares =
                (Asignaciones ?? new List<AsignarHabitacionParametro29.AsignacionParametro>())
                    .Where(x =>
                        x != null &&
                        !string.IsNullOrWhiteSpace(x.OrigenNombre) &&
                        !string.IsNullOrWhiteSpace(x.DestinoNombre))
                    .Take(5)
                    .ToList();

            if (pares.Count == 0)
            {
                throw new InvalidOperationException(
                    "Define al menos un par Parámetro origen → Parámetro destino.");
            }

            List<Element> elementos = ElementosSeleccionados
                .Select(id => doc.GetElement(id))
                .Where(e => e != null && e.IsValidObject)
                .ToList();

            if (elementos.Count == 0)
            {
                throw new InvalidOperationException(
                    "Los elementos seleccionados ya no están disponibles.");
            }

            Dictionary<long, DeteccionHabitacion> detecciones;

            // La detección ya se hizo al terminar la selección. Reutilizarla evita
            // repetir el proceso más pesado cuando el usuario pulsa COPIAR PARÁMETROS.
            if (!TryObtenerDeteccionesDesdeCache(doc, elementos, out detecciones))
            {
                List<Room> habitacionesHost = ObtenerHabitacionesValidas(doc);
                List<ConjuntoHabitacionesVinculo> habitacionesVinculadas =
                    ObtenerHabitacionesVinculadasValidas(doc);

                detecciones =
                    DetectarHabitacionesPorElemento(
                        doc,
                        elementos,
                        habitacionesHost,
                        habitacionesVinculadas);

                GuardarCacheDetecciones(doc, elementos, detecciones);
            }

            Dictionary<long, string> estados = new Dictionary<long, string>();

            int copiasCorrectas = 0;
            int omitidas = 0;
            int errores = 0;
            int elementosSinHabitacion = 0;

            using (Transaction tx =
                new Transaction(
                    doc,
                    "MYG - Copiar parámetros de habitación a elementos"))
            {
                tx.Start();

                foreach (Element elemento in elementos)
                {
                    DeteccionHabitacion deteccion;
                    detecciones.TryGetValue(elemento.Id.Value, out deteccion);

                    if (deteccion == null || !deteccion.Encontrada)
                    {
                        elementosSinHabitacion++;
                        omitidas += pares.Count;
                        estados[elemento.Id.Value] =
                            "Sin habitación | 0/" + pares.Count.ToString() + " copiados";
                        continue;
                    }

                    int okElemento = 0;
                    int omitidasElemento = 0;
                    int erroresElemento = 0;

                    foreach (AsignarHabitacionParametro29.AsignacionParametro par in pares)
                    {
                        ResultadoEscritura resultado =
                            CopiarParametro(
                                doc,
                                elemento,
                                deteccion,
                                par);

                        if (resultado.Correcto)
                        {
                            copiasCorrectas++;
                            okElemento++;
                        }
                        else if (resultado.EsError)
                        {
                            errores++;
                            erroresElemento++;
                        }
                        else
                        {
                            omitidas++;
                            omitidasElemento++;
                        }
                    }

                    string estado = okElemento.ToString() + "/" +
                        pares.Count.ToString() + " copiados";

                    if (omitidasElemento > 0)
                        estado += " | " + omitidasElemento.ToString() + " omit.";

                    if (erroresElemento > 0)
                        estado += " | " + erroresElemento.ToString() + " error(es)";

                    if (!string.IsNullOrWhiteSpace(deteccion.Origen))
                        estado += " | " + deteccion.Origen;

                    estados[elemento.Id.Value] = estado;
                }

                tx.Commit();
            }

            List<AsignarHabitacionParametro29.ResultadoElemento> resultados =
                CrearResultadosElementos(
                    doc,
                    elementos,
                    detecciones,
                    estados);

            string mensajeFinal =
                "Proceso terminado | Elementos: " + elementos.Count.ToString() +
                " | Pares: " + pares.Count.ToString() +
                " | Copias correctas: " + copiasCorrectas.ToString() +
                " | Omitidas: " + omitidas.ToString() +
                " | Sin habitación: " + elementosSinHabitacion.ToString() +
                " | Errores: " + errores.ToString();

            if (FormInicial != null)
            {
                FormInicial.FinalizarAsignacion(
                    mensajeFinal,
                    resultados);

                if (errores > 0)
                {
                    FormInicial.FinalizarOperacion(
                        "ERROR: Se produjeron " + errores.ToString() +
                        " error(es) de escritura. Revisa la columna Estado.",
                        true);
                }
            }
        }

        private ResultadoEscritura CopiarParametro(
            Document docHost,
            Element elemento,
            DeteccionHabitacion deteccion,
            AsignarHabitacionParametro29.AsignacionParametro par)
        {
            ResultadoEscritura resultado = new ResultadoEscritura();

            try
            {
                // V3.1: ya no se usa un único Parameter. Si Revit muestra dos o más
                // parámetros con el mismo nombre, se intentará escribir en TODOS los
                // homónimos que sean escribibles y compatibles.
                List<Parameter> destinos = BuscarParametrosDestino(elemento, par);

                if (destinos.Count == 0)
                {
                    resultado.Motivo = "Sin parámetro destino";
                    return resultado;
                }

                List<Parameter> escribibles = destinos
                    .Where(x => x != null && !x.IsReadOnly)
                    .ToList();

                if (escribibles.Count == 0)
                {
                    resultado.Motivo = "Destino(s) solo lectura";
                    return resultado;
                }

                List<ValorParametroOrigen> valores =
                    ObtenerValoresOrigen(deteccion, par);

                if (valores.Count == 0)
                {
                    resultado.Motivo = "Sin valor origen";
                    return resultado;
                }

                List<string> textosTodos = valores
                    .Select(x => x == null ? "" : x.Texto ?? "")
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToList();

                List<string> textosNoVacios = textosTodos
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .ToList();

                string textoFinal = textosNoVacios.Count > 0
                    ? string.Join(" | ", textosNoVacios)
                    : "";

                // El formato se aplica al valor final de texto, justo antes de escribirlo.
                // No altera parámetros Integer, Double ni ElementId.
                string textoFinalFormateado = AplicarFormatoTexto(textoFinal);

                List<ValorParametroOrigen> unicos = valores
                    .Where(x => x != null)
                    .GroupBy(x => x.ClaveInterna ?? "", StringComparer.OrdinalIgnoreCase)
                    .Select(x => x.First())
                    .ToList();

                int escritos = 0;
                int incompatibles = 0;
                int rechazados = 0;

                foreach (Parameter destino in escribibles)
                {
                    if (destino == null)
                        continue;

                    bool establecido = false;
                    bool compatible = true;

                    if (destino.StorageType == StorageType.String)
                    {
                        establecido = destino.Set(textoFinalFormateado);
                    }
                    else
                    {
                        // Para destinos no texto seguimos exigiendo un único valor
                        // inequívoco entre las habitaciones detectadas.
                        if (unicos.Count != 1)
                        {
                            compatible = false;
                        }
                        else
                        {
                            ValorParametroOrigen valor = unicos[0];

                            if (destino.StorageType == StorageType.Integer &&
                                valor.StorageType == StorageType.Integer)
                            {
                                establecido = destino.Set(valor.Entero);
                            }
                            else if (destino.StorageType == StorageType.Double &&
                                     valor.StorageType == StorageType.Double)
                            {
                                establecido = destino.Set(valor.Doble);
                            }
                            else if (destino.StorageType == StorageType.ElementId &&
                                     valor.StorageType == StorageType.ElementId)
                            {
                                // Un ElementId perteneciente a un RVT vinculado no puede
                                // escribirse directamente como ElementId dentro del host.
                                if (valor.DocumentoOrigen == null ||
                                    !valor.DocumentoOrigen.Equals(docHost))
                                {
                                    compatible = false;
                                }
                                else
                                {
                                    establecido = destino.Set(valor.ElementIdValor);
                                }
                            }
                            else
                            {
                                compatible = false;
                            }
                        }
                    }

                    if (!compatible)
                        incompatibles++;
                    else if (establecido)
                        escritos++;
                    else
                        rechazados++;
                }

                if (escritos > 0)
                {
                    resultado.Correcto = true;
                    resultado.EsError = false;
                    resultado.Motivo =
                        "OK | " + escritos.ToString() + "/" +
                        escribibles.Count.ToString() +
                        " parámetro(s) homónimo(s) escritos";
                    return resultado;
                }

                resultado.Correcto = false;
                resultado.EsError = rechazados > 0;

                if (incompatibles == escribibles.Count)
                    resultado.Motivo = "Todos los destinos homónimos son incompatibles";
                else if (rechazados > 0)
                    resultado.Motivo = "Revit rechazó el/los valor(es)";
                else
                    resultado.Motivo = "No se pudo escribir ningún destino homónimo";

                return resultado;
            }
            catch (Exception ex)
            {
                resultado.Correcto = false;
                resultado.EsError = true;
                resultado.Motivo = ex.Message;
                return resultado;
            }
        }

        private string AplicarFormatoTexto(string texto)
        {
            string valor = texto ?? "";

            switch (FormatoTexto)
            {
                case AsignarHabitacionParametro29.FormatoTextoCopiado.Mayuscula:
                    return valor.ToUpper(CultureInfo.CurrentCulture);

                case AsignarHabitacionParametro29.FormatoTextoCopiado.TipoOracion:
                    return ConvertirATipoOracion(valor);

                case AsignarHabitacionParametro29.FormatoTextoCopiado.Predeterminado:
                default:
                    return valor;
            }
        }

        private string ConvertirATipoOracion(string texto)
        {
            if (string.IsNullOrEmpty(texto))
                return texto ?? "";

            // Si se detectaron varias habitaciones y quedaron concatenadas con " | ",
            // cada nombre se trata como una oración independiente.
            string[] partes = texto.Split(
                new string[] { " | " },
                StringSplitOptions.None);

            for (int i = 0; i < partes.Length; i++)
                partes[i] = ConvertirSegmentoATipoOracion(partes[i]);

            return string.Join(" | ", partes);
        }

        private string ConvertirSegmentoATipoOracion(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return texto ?? "";

            CultureInfo cultura = CultureInfo.CurrentCulture;
            string minuscula = texto.ToLower(cultura);
            char[] caracteres = minuscula.ToCharArray();

            // Primera letra visible en mayúscula; el resto queda en minúscula.
            for (int i = 0; i < caracteres.Length; i++)
            {
                if (!char.IsLetter(caracteres[i]))
                    continue;

                caracteres[i] = char.ToUpper(caracteres[i], cultura);
                break;
            }

            return new string(caracteres);
        }

        private List<Parameter> BuscarParametrosDestino(
            Element elemento,
            AsignarHabitacionParametro29.AsignacionParametro par)
        {
            List<Parameter> resultado = new List<Parameter>();

            if (elemento == null || par == null ||
                string.IsNullOrWhiteSpace(par.DestinoNombre))
            {
                return resultado;
            }

            string nombreBuscado = par.DestinoNombre.Trim();

            foreach (Parameter p in elemento.Parameters)
            {
                if (p == null || p.Definition == null)
                    continue;

                string nombre = (p.Definition.Name ?? "").Trim();
                if (!string.Equals(
                    nombre,
                    nombreBuscado,
                    StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                // NO deduplicar por nombre: precisamente queremos todos los parámetros
                // distintos que Revit muestra con ese mismo nombre.
                resultado.Add(p);
            }

            return resultado;
        }

        private List<ValorParametroOrigen> ObtenerValoresOrigen(
            DeteccionHabitacion deteccion,
            AsignarHabitacionParametro29.AsignacionParametro par)
        {
            List<ValorParametroOrigen> resultado =
                new List<ValorParametroOrigen>();

            if (deteccion == null ||
                deteccion.Habitaciones == null ||
                par == null ||
                string.IsNullOrWhiteSpace(par.OrigenNombre))
            {
                return resultado;
            }

            foreach (RoomDetectado rd in deteccion.Habitaciones)
            {
                if (rd == null || rd.Habitacion == null)
                    continue;

                Parameter p = BuscarParametroHabitacion(rd.Habitacion, par);
                if (p == null)
                    continue;

                ValorParametroOrigen valor =
                    LeerValorParametroOrigen(rd.Documento, p);

                if (valor != null)
                    resultado.Add(valor);
            }

            return resultado;
        }

        private Parameter BuscarParametroHabitacion(
            Room room,
            AsignarHabitacionParametro29.AsignacionParametro par)
        {
            if (room == null || par == null ||
                string.IsNullOrWhiteSpace(par.OrigenNombre))
            {
                return null;
            }

            Parameter primero = null;

            foreach (Parameter p in room.Parameters)
            {
                if (p == null || p.Definition == null)
                    continue;

                if (!string.Equals(
                    (p.Definition.Name ?? "").Trim(),
                    par.OrigenNombre.Trim(),
                    StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                if (primero == null)
                    primero = p;

                if (!string.IsNullOrWhiteSpace(par.OrigenStorage) &&
                    !string.Equals(par.OrigenStorage, "Mixed", StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(
                        p.StorageType.ToString(),
                        par.OrigenStorage,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return p;
                }
            }

            return primero;
        }

        private ValorParametroOrigen LeerValorParametroOrigen(
            Document docOrigen,
            Parameter p)
        {
            if (p == null)
                return null;

            ValorParametroOrigen valor = new ValorParametroOrigen();
            valor.StorageType = p.StorageType;
            valor.DocumentoOrigen = docOrigen;

            try
            {
                switch (p.StorageType)
                {
                    case StorageType.String:
                        valor.Texto = p.AsString() ?? "";
                        valor.ClaveInterna = "S|" + valor.Texto;
                        break;

                    case StorageType.Integer:
                        valor.Entero = p.AsInteger();
                        valor.Texto = ObtenerTextoMostradoParametro(docOrigen, p);
                        valor.ClaveInterna = "I|" + valor.Entero.ToString(CultureInfo.InvariantCulture);
                        break;

                    case StorageType.Double:
                        valor.Doble = p.AsDouble();
                        valor.Texto = ObtenerTextoMostradoParametro(docOrigen, p);
                        valor.ClaveInterna = "D|" + valor.Doble.ToString("R", CultureInfo.InvariantCulture);
                        break;

                    case StorageType.ElementId:
                        valor.ElementIdValor = p.AsElementId();
                        valor.Texto = ObtenerTextoMostradoParametro(docOrigen, p);
                        valor.ClaveInterna = "E|" +
                            (valor.ElementIdValor == null
                                ? ""
                                : valor.ElementIdValor.Value.ToString(CultureInfo.InvariantCulture));
                        break;

                    case StorageType.None:
                    default:
                        return null;
                }
            }
            catch
            {
                return null;
            }

            return valor;
        }

        private string ObtenerTextoMostradoParametro(
            Document doc,
            Parameter p)
        {
            if (p == null)
                return "";

            try
            {
                if (p.StorageType == StorageType.String)
                    return p.AsString() ?? "";

                string valorFormateado = p.AsValueString();
                if (!string.IsNullOrWhiteSpace(valorFormateado))
                    return valorFormateado.Trim();
            }
            catch
            {
            }

            try
            {
                if (p.StorageType == StorageType.Integer)
                    return p.AsInteger().ToString(CultureInfo.InvariantCulture);

                if (p.StorageType == StorageType.Double)
                    return p.AsDouble().ToString(CultureInfo.InvariantCulture);

                if (p.StorageType == StorageType.ElementId)
                {
                    ElementId id = p.AsElementId();
                    if (id == null || id == ElementId.InvalidElementId)
                        return "";

                    if (doc != null && doc.IsValidObject)
                    {
                        Element refElement = doc.GetElement(id);
                        if (refElement != null)
                        {
                            try
                            {
                                if (!string.IsNullOrWhiteSpace(refElement.Name))
                                    return refElement.Name.Trim();
                            }
                            catch
                            {
                            }
                        }
                    }

                    return id.Value.ToString(CultureInfo.InvariantCulture);
                }
            }
            catch
            {
            }

            return "";
        }

        private List<AsignarHabitacionParametro29.ParametroInstanciaDisponible>
            ObtenerParametrosDestino(List<Element> elementos)
        {
            Dictionary<string, AcumuladorDestino> mapa =
                new Dictionary<string, AcumuladorDestino>(StringComparer.OrdinalIgnoreCase);

            if (elementos == null)
                return new List<AsignarHabitacionParametro29.ParametroInstanciaDisponible>();

            foreach (Element e in elementos)
            {
                if (e == null || !e.IsValidObject)
                    continue;

                foreach (Parameter p in e.Parameters)
                {
                    if (p == null || p.Definition == null)
                        continue;

                    string nombre = (p.Definition.Name ?? "").Trim();
                    if (string.IsNullOrWhiteSpace(nombre))
                        continue;

                    // DEDUPLICACIÓN solicitada: un solo registro por nombre,
                    // aunque se repita entre elementos/categorías.
                    string clave = NormalizarNombreParametro(nombre);

                    AcumuladorDestino acumulador;
                    if (!mapa.TryGetValue(clave, out acumulador))
                    {
                        acumulador = new AcumuladorDestino();
                        acumulador.Item =
                            new AsignarHabitacionParametro29.ParametroInstanciaDisponible()
                            {
                                Clave = clave,
                                NombreParametro = nombre,
                                TipoStorage = p.StorageType.ToString(),
                                TipoDato = ObtenerNombreStorageType(p.StorageType),
                                CantidadElementos = 0,
                                CantidadEscribibles = 0,
                                EsEscribible = false,
                                AdmiteTexto = false
                            };

                        mapa.Add(clave, acumulador);
                    }

                    acumulador.TiposStorage.Add(p.StorageType.ToString());

                    if (acumulador.ElementosConParametro.Add(e.Id.Value))
                        acumulador.Item.CantidadElementos++;

                    if (!p.IsReadOnly && acumulador.ElementosEscribibles.Add(e.Id.Value))
                    {
                        acumulador.Item.CantidadEscribibles++;
                        acumulador.Item.EsEscribible = true;
                    }

                    if (!p.IsReadOnly && p.StorageType == StorageType.String)
                        acumulador.Item.AdmiteTexto = true;
                }
            }

            foreach (AcumuladorDestino acumulador in mapa.Values)
            {
                if (acumulador == null || acumulador.Item == null)
                    continue;

                if (acumulador.TiposStorage.Count > 1)
                {
                    acumulador.Item.TipoStorage = "Mixed";
                    acumulador.Item.TipoDato = "Mixto";
                }
            }

            return mapa.Values
                .Where(x => x != null && x.Item != null)
                .Select(x => x.Item)
                .OrderByDescending(x => x.EsEscribible)
                .ThenBy(x => x.NombreParametro)
                .ToList();
        }

        private List<AsignarHabitacionParametro29.ParametroHabitacionDisponible>
            ObtenerParametrosHabitacionesDetectadas(
                Dictionary<long, DeteccionHabitacion> detecciones)
        {
            Dictionary<string, AcumuladorOrigen> mapa =
                new Dictionary<string, AcumuladorOrigen>(StringComparer.OrdinalIgnoreCase);

            if (detecciones == null)
                return new List<AsignarHabitacionParametro29.ParametroHabitacionDisponible>();

            Dictionary<string, RoomDetectado> roomsUnicos =
                new Dictionary<string, RoomDetectado>(StringComparer.OrdinalIgnoreCase);

            foreach (DeteccionHabitacion deteccion in detecciones.Values)
            {
                if (deteccion == null || deteccion.Habitaciones == null)
                    continue;

                foreach (RoomDetectado rd in deteccion.Habitaciones)
                {
                    if (rd == null || rd.Habitacion == null ||
                        string.IsNullOrWhiteSpace(rd.Clave))
                    {
                        continue;
                    }

                    if (!roomsUnicos.ContainsKey(rd.Clave))
                        roomsUnicos.Add(rd.Clave, rd);
                }
            }

            foreach (RoomDetectado rd in roomsUnicos.Values)
            {
                Room room = rd.Habitacion;
                if (room == null || !room.IsValidObject)
                    continue;

                foreach (Parameter p in room.Parameters)
                {
                    if (p == null || p.Definition == null)
                        continue;

                    string nombre = (p.Definition.Name ?? "").Trim();
                    if (string.IsNullOrWhiteSpace(nombre))
                        continue;

                    // DEDUPLICACIÓN: un origen por nombre, incluso entre rooms
                    // del anfitrión y de diferentes vínculos.
                    string clave = NormalizarNombreParametro(nombre);

                    AcumuladorOrigen acumulador;
                    if (!mapa.TryGetValue(clave, out acumulador))
                    {
                        acumulador = new AcumuladorOrigen();
                        acumulador.Item =
                            new AsignarHabitacionParametro29.ParametroHabitacionDisponible()
                            {
                                Clave = clave,
                                NombreParametro = nombre,
                                TipoStorage = p.StorageType.ToString(),
                                TipoDato = ObtenerNombreStorageType(p.StorageType),
                                CantidadHabitaciones = 0
                            };

                        mapa.Add(clave, acumulador);
                    }

                    acumulador.TiposStorage.Add(p.StorageType.ToString());

                    if (acumulador.HabitacionesConParametro.Add(rd.Clave))
                        acumulador.Item.CantidadHabitaciones++;
                }
            }

            foreach (AcumuladorOrigen acumulador in mapa.Values)
            {
                if (acumulador == null || acumulador.Item == null)
                    continue;

                if (acumulador.TiposStorage.Count > 1)
                {
                    acumulador.Item.TipoStorage = "Mixed";
                    acumulador.Item.TipoDato = "Mixto";
                }
            }

            return mapa.Values
                .Where(x => x != null && x.Item != null)
                .Select(x => x.Item)
                .OrderBy(x => x.NombreParametro)
                .ToList();
        }

        private string NormalizarNombreParametro(string nombre)
        {
            return (nombre ?? "").Trim().ToUpperInvariant();
        }

        private void GuardarCacheDetecciones(
            Document doc,
            List<Element> elementos,
            Dictionary<long, DeteccionHabitacion> detecciones)
        {
            _documentoCacheDetecciones = doc;
            _cacheDetecciones = detecciones ??
                new Dictionary<long, DeteccionHabitacion>();

            _cacheIdsElementos = new HashSet<long>(
                (elementos ?? new List<Element>())
                    .Where(x => x != null && x.IsValidObject)
                    .Select(x => x.Id.Value));
        }

        private bool TryObtenerDeteccionesDesdeCache(
            Document doc,
            List<Element> elementos,
            out Dictionary<long, DeteccionHabitacion> detecciones)
        {
            detecciones = null;

            if (doc == null ||
                _documentoCacheDetecciones == null ||
                !_documentoCacheDetecciones.Equals(doc) ||
                _cacheDetecciones == null ||
                _cacheIdsElementos == null)
            {
                return false;
            }

            List<long> ids = (elementos ?? new List<Element>())
                .Where(x => x != null && x.IsValidObject)
                .Select(x => x.Id.Value)
                .Distinct()
                .ToList();

            if (ids.Count == 0 || ids.Count != _cacheIdsElementos.Count)
                return false;

            foreach (long id in ids)
            {
                if (!_cacheIdsElementos.Contains(id) ||
                    !_cacheDetecciones.ContainsKey(id))
                {
                    return false;
                }
            }

            detecciones = _cacheDetecciones;
            return true;
        }

        private Dictionary<long, DeteccionHabitacion>
            DetectarHabitacionesPorElemento(
                Document doc,
                List<Element> elementos,
                List<Room> habitacionesHost,
                List<ConjuntoHabitacionesVinculo> habitacionesVinculadas)
        {
            Dictionary<long, DeteccionHabitacion> resultado =
                new Dictionary<long, DeteccionHabitacion>();

            if (elementos == null)
                return resultado;

            // V3.1: calcular las cajas de los Rooms del host UNA sola vez para toda
            // la selección, no una vez por punto y por elemento.
            List<RoomInfoEspacial> indiceHost =
                CrearIndiceHabitaciones(habitacionesHost);

            foreach (Element e in elementos)
            {
                if (e == null)
                    continue;

                resultado[e.Id.Value] =
                    ObtenerHabitacionElemento(
                        doc,
                        e,
                        indiceHost,
                        habitacionesVinculadas);
            }

            return resultado;
        }

        private List<AsignarHabitacionParametro29.ResultadoElemento>
            CrearResultadosElementos(
                Document doc,
                List<Element> elementos,
                Dictionary<long, DeteccionHabitacion> detecciones,
                Dictionary<long, string> estadosAsignacion)
        {
            List<AsignarHabitacionParametro29.ResultadoElemento> resultado =
                new List<AsignarHabitacionParametro29.ResultadoElemento>();

            if (elementos == null)
                return resultado;

            foreach (Element e in elementos)
            {
                if (e == null || !e.IsValidObject)
                    continue;

                DeteccionHabitacion deteccion = null;
                if (detecciones != null)
                    detecciones.TryGetValue(e.Id.Value, out deteccion);

                string habitacion = deteccion == null ? "" : deteccion.Nombre ?? "";
                string categoria = e.Category == null ? "" : e.Category.Name ?? "";
                string tipo = ObtenerNombreTipoElemento(doc, e);

                string estado = "";
                if (estadosAsignacion != null)
                    estadosAsignacion.TryGetValue(e.Id.Value, out estado);

                if (string.IsNullOrWhiteSpace(estado))
                {
                    if (string.IsNullOrWhiteSpace(habitacion))
                        estado = "Sin habitación detectada";
                    else if (deteccion != null && !string.IsNullOrWhiteSpace(deteccion.Origen))
                        estado = "OK | " + deteccion.Origen;
                    else
                        estado = "OK";
                }

                resultado.Add(
                    new AsignarHabitacionParametro29.ResultadoElemento()
                    {
                        ElementId = e.Id.Value,
                        Categoria = categoria,
                        Tipo = tipo,
                        Habitacion = habitacion,
                        Estado = estado
                    });
            }

            return resultado;
        }

        private bool EsElementoSeleccionableDeModelo(Element e)
        {
            if (e == null || !e.IsValidObject || e.Category == null)
                return false;

            if (e is ElementType || e is View)
                return false;

            try
            {
                if (e.Category.CategoryType != CategoryType.Model)
                    return false;
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void ObtenerNombresTipo(
            Element tipo,
            out string familia,
            out string nombreTipo)
        {
            familia = "";
            nombreTipo = "";

            if (tipo == null)
            {
                nombreTipo = "(Tipo no disponible)";
                return;
            }

            try
            {
                FamilySymbol simbolo = tipo as FamilySymbol;
                if (simbolo != null && simbolo.Family != null)
                    familia = simbolo.Family.Name ?? "";
            }
            catch
            {
                familia = "";
            }

            try
            {
                nombreTipo = tipo.Name ?? "";
            }
            catch
            {
                nombreTipo = "";
            }

            if (string.IsNullOrWhiteSpace(familia) && tipo.Category != null)
                familia = tipo.Category.Name ?? "";

            if (string.IsNullOrWhiteSpace(nombreTipo))
                nombreTipo = "(Sin nombre de tipo)";
        }

        private string ObtenerNombreTipoElemento(Document doc, Element e)
        {
            if (doc == null || e == null)
                return "";

            ElementId idTipo = e.GetTypeId();
            if (idTipo == null || idTipo == ElementId.InvalidElementId)
                return "(Sin tipo)";

            Element tipo = doc.GetElement(idTipo);
            string familia;
            string nombreTipo;
            ObtenerNombresTipo(tipo, out familia, out nombreTipo);

            if (string.IsNullOrWhiteSpace(familia))
                return nombreTipo ?? "";

            return familia + " : " + (nombreTipo ?? "");
        }

        private string ObtenerNombreStorageType(StorageType storageType)
        {
            switch (storageType)
            {
                case StorageType.String:
                    return "Texto";
                case StorageType.Integer:
                    return "Entero";
                case StorageType.Double:
                    return "Número";
                case StorageType.ElementId:
                    return "ElementId";
                case StorageType.None:
                default:
                    return "Sin dato";
            }
        }

        private List<Room> ObtenerHabitacionesValidas(Document doc)
        {
            if (doc == null || !doc.IsValidObject)
                return new List<Room>();

            return new FilteredElementCollector(doc)
                .OfCategory(BuiltInCategory.OST_Rooms)
                .WhereElementIsNotElementType()
                .Cast<Room>()
                .Where(r =>
                {
                    if (r == null || !r.IsValidObject)
                        return false;

                    try
                    {
                        return r.Area > 0.000001;
                    }
                    catch
                    {
                        return false;
                    }
                })
                .ToList();
        }

        private List<ConjuntoHabitacionesVinculo>
            ObtenerHabitacionesVinculadasValidas(Document doc)
        {
            List<ConjuntoHabitacionesVinculo> resultado =
                new List<ConjuntoHabitacionesVinculo>();

            if (doc == null || !doc.IsValidObject)
                return resultado;

            List<RevitLinkInstance> vinculos =
                new FilteredElementCollector(doc)
                    .OfClass(typeof(RevitLinkInstance))
                    .Cast<RevitLinkInstance>()
                    .Where(x => x != null && x.IsValidObject)
                    .ToList();

            // Si un mismo RVT está insertado varias veces, reutilizamos habitaciones
            // e índice espacial; no volvemos a recolectar ni calcular sus cajas.
            Dictionary<Document, List<Room>> roomsPorDocumento =
                new Dictionary<Document, List<Room>>();
            Dictionary<Document, List<RoomInfoEspacial>> indicePorDocumento =
                new Dictionary<Document, List<RoomInfoEspacial>>();

            foreach (RevitLinkInstance vinculo in vinculos)
            {
                Document docVinculo = null;
                try
                {
                    docVinculo = vinculo.GetLinkDocument();
                }
                catch
                {
                    docVinculo = null;
                }

                if (docVinculo == null || !docVinculo.IsValidObject)
                    continue;

                List<Room> habitaciones;
                List<RoomInfoEspacial> indiceHabitaciones;

                if (!roomsPorDocumento.TryGetValue(docVinculo, out habitaciones))
                {
                    habitaciones = ObtenerHabitacionesValidas(docVinculo);
                    roomsPorDocumento[docVinculo] = habitaciones;

                    indiceHabitaciones = CrearIndiceHabitaciones(habitaciones);
                    indicePorDocumento[docVinculo] = indiceHabitaciones;
                }
                else if (!indicePorDocumento.TryGetValue(
                    docVinculo,
                    out indiceHabitaciones))
                {
                    indiceHabitaciones = CrearIndiceHabitaciones(habitaciones);
                    indicePorDocumento[docVinculo] = indiceHabitaciones;
                }

                if (habitaciones.Count == 0)
                    continue;

                Transform vinculoAHost = null;
                try
                {
                    vinculoAHost = vinculo.GetTotalTransform();
                }
                catch
                {
                    try
                    {
                        vinculoAHost = vinculo.GetTransform();
                    }
                    catch
                    {
                        vinculoAHost = null;
                    }
                }

                if (vinculoAHost == null)
                    continue;

                Transform hostAVinculo = null;
                try
                {
                    hostAVinculo = vinculoAHost.Inverse;
                }
                catch
                {
                    hostAVinculo = null;
                }

                if (hostAVinculo == null)
                    continue;

                string nombreVinculo = "";
                try
                {
                    nombreVinculo = vinculo.Name ?? "";
                }
                catch
                {
                    nombreVinculo = "";
                }

                if (string.IsNullOrWhiteSpace(nombreVinculo))
                {
                    try
                    {
                        nombreVinculo = docVinculo.Title ?? "";
                    }
                    catch
                    {
                        nombreVinculo = "";
                    }
                }

                resultado.Add(
                    new ConjuntoHabitacionesVinculo()
                    {
                        Instancia = vinculo,
                        Documento = docVinculo,
                        HostAVinculo = hostAVinculo,
                        NombreVinculo = string.IsNullOrWhiteSpace(nombreVinculo)
                            ? "Vínculo RVT"
                            : nombreVinculo.Trim(),
                        Habitaciones = habitaciones,
                        IndiceHabitaciones = indiceHabitaciones ??
                            new List<RoomInfoEspacial>()
                    });
            }

            return resultado;
        }

        private DeteccionHabitacion ObtenerHabitacionElemento(
            Document doc,
            Element e,
            List<RoomInfoEspacial> indiceHost,
            List<ConjuntoHabitacionesVinculo> habitacionesVinculadas)
        {
            DeteccionHabitacion vacio = new DeteccionHabitacion();
            if (doc == null || e == null)
                return vacio;

            Room propio = e as Room;
            if (propio != null)
            {
                RoomDetectado rd = CrearRoomDetectado(
                    doc,
                    propio,
                    "Anfitrión",
                    "H");
                if (rd != null)
                    return CrearDeteccionDesdeRooms(new List<RoomDetectado>() { rd });
            }

            FamilyInstance fi = e as FamilyInstance;
            if (fi != null)
            {
                List<RoomDetectado> directos = new List<RoomDetectado>();

                Room roomDirecto = ObtenerRoomDirecto(fi);
                if (roomDirecto != null)
                {
                    RoomDetectado rd = CrearRoomDetectado(
                        doc,
                        roomDirecto,
                        "Anfitrión",
                        "H");
                    AgregarRoomDetectadoUnico(directos, rd);
                }

                foreach (Room roomLado in ObtenerRoomsLados(fi))
                {
                    RoomDetectado rd = CrearRoomDetectado(
                        doc,
                        roomLado,
                        "Anfitrión",
                        "H");
                    AgregarRoomDetectadoUnico(directos, rd);
                }

                if (directos.Count > 0)
                    return CrearDeteccionDesdeRooms(directos);
            }

            List<XYZ> puntos = ObtenerPuntosPruebaElemento(e);

            // Primero prueba físicamente, pero usando el índice por BoundingBox para
            // no ejecutar IsPointInRoom() contra todos los Rooms del proyecto.
            List<RoomDetectado> roomsHost =
                BuscarHabitacionesHostEnPuntos(
                    doc,
                    indiceHost,
                    puntos);

            if (roomsHost.Count > 0)
                return CrearDeteccionDesdeRooms(roomsHost);

            List<RoomDetectado> roomsLinks =
                BuscarHabitacionesVinculadasEnPuntos(
                    puntos,
                    habitacionesVinculadas);

            if (roomsLinks.Count > 0)
                return CrearDeteccionDesdeRooms(roomsLinks);

            // Si no hay intersección física, se mantiene el mismo XY y únicamente
            // se busca la habitación más próxima hacia arriba/abajo en Z.
            RoomDetectado roomCercanoZ = BuscarHabitacionMasCercanaEnZ(
                doc,
                puntos,
                indiceHost,
                habitacionesVinculadas);

            if (roomCercanoZ != null)
            {
                return CrearDeteccionDesdeRooms(
                    new List<RoomDetectado>() { roomCercanoZ });
            }

            return vacio;
        }

        private RoomDetectado BuscarHabitacionMasCercanaEnZ(
            Document docHost,
            List<XYZ> puntosHost,
            List<RoomInfoEspacial> indiceHost,
            List<ConjuntoHabitacionesVinculo> habitacionesVinculadas)
        {
            if (docHost == null || puntosHost == null || puntosHost.Count == 0)
                return null;

            CandidatoHabitacionVertical mejor = null;

            CandidatoHabitacionVertical candidatoHost =
                BuscarCandidatoVerticalEnIndice(
                    docHost,
                    indiceHost,
                    puntosHost,
                    "Anfitrión",
                    "H");

            if (candidatoHost != null && candidatoHost.RoomDetectado != null)
                mejor = candidatoHost;

            if (habitacionesVinculadas != null)
            {
                foreach (ConjuntoHabitacionesVinculo conjunto in habitacionesVinculadas)
                {
                    if (conjunto == null ||
                        conjunto.Documento == null ||
                        !conjunto.Documento.IsValidObject ||
                        conjunto.HostAVinculo == null ||
                        conjunto.IndiceHabitaciones == null ||
                        conjunto.IndiceHabitaciones.Count == 0)
                    {
                        continue;
                    }

                    Transform vinculoAHost = null;
                    try
                    {
                        vinculoAHost = conjunto.HostAVinculo.Inverse;
                    }
                    catch
                    {
                        vinculoAHost = null;
                    }

                    if (vinculoAHost == null)
                        continue;

                    List<XYZ> puntosVinculo = new List<XYZ>();
                    List<int> indicesOriginales = new List<int>();

                    for (int i = 0; i < puntosHost.Count; i++)
                    {
                        XYZ puntoHost = puntosHost[i];
                        if (puntoHost == null)
                            continue;

                        try
                        {
                            XYZ p = conjunto.HostAVinculo.OfPoint(puntoHost);
                            if (p != null)
                            {
                                puntosVinculo.Add(p);
                                indicesOriginales.Add(i);
                            }
                        }
                        catch
                        {
                        }
                    }

                    if (puntosVinculo.Count == 0)
                        continue;

                    string idLink = conjunto.Instancia == null
                        ? "LINK"
                        : conjunto.Instancia.Id.Value.ToString(CultureInfo.InvariantCulture);

                    CandidatoHabitacionVertical candidato =
                        BuscarCandidatoVerticalEnIndice(
                            conjunto.Documento,
                            conjunto.IndiceHabitaciones,
                            puntosVinculo,
                            "Vínculo: " + (conjunto.NombreVinculo ?? "RVT"),
                            "L" + idLink);

                    if (candidato == null ||
                        candidato.RoomDetectado == null ||
                        candidato.PuntoInterior == null ||
                        candidato.IndicePunto < 0 ||
                        candidato.IndicePunto >= indicesOriginales.Count)
                    {
                        continue;
                    }

                    int indiceHostOriginal = indicesOriginales[candidato.IndicePunto];
                    if (indiceHostOriginal < 0 || indiceHostOriginal >= puntosHost.Count)
                        continue;

                    XYZ puntoReferenciaHost = puntosHost[indiceHostOriginal];
                    XYZ puntoInteriorHost = null;

                    try
                    {
                        puntoInteriorHost = vinculoAHost.OfPoint(candidato.PuntoInterior);
                    }
                    catch
                    {
                        puntoInteriorHost = null;
                    }

                    if (puntoInteriorHost == null || puntoReferenciaHost == null)
                        continue;

                    double deltaZHost = puntoInteriorHost.Z - puntoReferenciaHost.Z;
                    double distanciaHost = Math.Abs(deltaZHost);

                    if (mejor == null ||
                        distanciaHost < mejor.DistanciaVertical - 0.000001)
                    {
                        candidato.PuntoInterior = puntoInteriorHost;
                        candidato.DeltaZ = deltaZHost;
                        candidato.DistanciaVertical = distanciaHost;
                        mejor = candidato;
                    }
                }
            }

            if (mejor == null || mejor.RoomDetectado == null)
                return null;

            string direccion;
            if (mejor.DeltaZ > 0.000001)
                direccion = "↑ arriba";
            else if (mejor.DeltaZ < -0.000001)
                direccion = "↓ abajo";
            else
                direccion = "≈ misma cota";

            double distanciaMetros;
            try
            {
                distanciaMetros = UnitUtils.ConvertFromInternalUnits(
                    mejor.DistanciaVertical,
                    UnitTypeId.Meters);
            }
            catch
            {
                distanciaMetros = mejor.DistanciaVertical * 0.3048;
            }

            mejor.RoomDetectado.Origen =
                (mejor.RoomDetectado.Origen ?? "") +
                " | Cercana Z " + direccion +
                " | " + distanciaMetros.ToString("0.###", CultureInfo.InvariantCulture) + " m";

            return mejor.RoomDetectado;
        }

        private CandidatoHabitacionVertical BuscarCandidatoVerticalEnIndice(
            Document doc,
            List<RoomInfoEspacial> indiceHabitaciones,
            List<XYZ> puntos,
            string origen,
            string prefijoClave)
        {
            if (doc == null ||
                indiceHabitaciones == null ||
                puntos == null ||
                puntos.Count == 0)
            {
                return null;
            }

            CandidatoHabitacionVertical mejor = null;
            const double toleranciaXY = 0.05; // pies (~15 mm)

            // Importante: Room exterior, Point interior. La caja del Room se obtuvo
            // una sola vez al construir el índice.
            foreach (RoomInfoEspacial info in indiceHabitaciones)
            {
                if (info == null || info.Habitacion == null ||
                    !info.Habitacion.IsValidObject)
                {
                    continue;
                }

                double altura = info.MaxZ - info.MinZ;
                if (altura <= 0.000001)
                    continue;

                double margen = Math.Min(0.01, altura * 0.05);
                if (margen < 0.0001)
                    margen = altura * 0.25;

                double zInteriorMin = info.MinZ + margen;
                double zInteriorMax = info.MaxZ - margen;

                if (zInteriorMax < zInteriorMin)
                {
                    zInteriorMin = (info.MinZ + info.MaxZ) * 0.5;
                    zInteriorMax = zInteriorMin;
                }

                for (int i = 0; i < puntos.Count; i++)
                {
                    XYZ punto = puntos[i];
                    if (punto == null)
                        continue;

                    // Descarte extremadamente barato por XY.
                    if (punto.X < info.MinX - toleranciaXY ||
                        punto.X > info.MaxX + toleranciaXY ||
                        punto.Y < info.MinY - toleranciaXY ||
                        punto.Y > info.MaxY + toleranciaXY)
                    {
                        continue;
                    }

                    double zPrueba;
                    if (punto.Z < zInteriorMin)
                        zPrueba = zInteriorMin;
                    else if (punto.Z > zInteriorMax)
                        zPrueba = zInteriorMax;
                    else
                        zPrueba = punto.Z;

                    double distancia = Math.Abs(zPrueba - punto.Z);

                    // Si ya tenemos algo mejor, ni siquiera llamamos a IsPointInRoom.
                    if (mejor != null &&
                        distancia >= mejor.DistanciaVertical - 0.000001)
                    {
                        continue;
                    }

                    XYZ puntoPrueba = new XYZ(punto.X, punto.Y, zPrueba);

                    bool dentro = false;
                    try
                    {
                        dentro = info.Habitacion.IsPointInRoom(puntoPrueba);
                    }
                    catch
                    {
                        dentro = false;
                    }

                    if (!dentro)
                        continue;

                    RoomDetectado rd = CrearRoomDetectado(
                        doc,
                        info.Habitacion,
                        origen,
                        prefijoClave);

                    if (rd == null)
                        continue;

                    mejor = new CandidatoHabitacionVertical()
                    {
                        RoomDetectado = rd,
                        PuntoInterior = puntoPrueba,
                        DistanciaVertical = distancia,
                        DeltaZ = zPrueba - punto.Z,
                        IndicePunto = i
                    };

                    if (distancia <= 0.000001)
                        return mejor;
                }
            }

            return mejor;
        }

        private List<RoomInfoEspacial> CrearIndiceHabitaciones(List<Room> habitaciones)
        {
            List<RoomInfoEspacial> resultado = new List<RoomInfoEspacial>();

            if (habitaciones == null)
                return resultado;

            foreach (Room room in habitaciones)
            {
                if (room == null || !room.IsValidObject)
                    continue;

                RoomInfoEspacial info;
                if (TryCrearRoomInfoEspacial(room, out info) && info != null)
                    resultado.Add(info);
            }

            return resultado;
        }

        private bool TryCrearRoomInfoEspacial(
            Room room,
            out RoomInfoEspacial info)
        {
            info = null;

            if (room == null || !room.IsValidObject)
                return false;

            BoundingBoxXYZ bb = null;
            try
            {
                bb = room.get_BoundingBox(null);
            }
            catch
            {
                bb = null;
            }

            if (bb == null || bb.Min == null || bb.Max == null)
                return false;

            Transform t = bb.Transform ?? Transform.Identity;
            XYZ min = bb.Min;
            XYZ max = bb.Max;

            double minX = double.MaxValue;
            double maxX = double.MinValue;
            double minY = double.MaxValue;
            double maxY = double.MinValue;
            double minZ = double.MaxValue;
            double maxZ = double.MinValue;

            XYZ[] esquinas = new XYZ[]
            {
                new XYZ(min.X, min.Y, min.Z),
                new XYZ(min.X, min.Y, max.Z),
                new XYZ(min.X, max.Y, min.Z),
                new XYZ(min.X, max.Y, max.Z),
                new XYZ(max.X, min.Y, min.Z),
                new XYZ(max.X, min.Y, max.Z),
                new XYZ(max.X, max.Y, min.Z),
                new XYZ(max.X, max.Y, max.Z)
            };

            foreach (XYZ esquinaLocal in esquinas)
            {
                XYZ esquina;
                try
                {
                    esquina = t.OfPoint(esquinaLocal);
                }
                catch
                {
                    esquina = esquinaLocal;
                }

                if (esquina == null)
                    continue;

                minX = Math.Min(minX, esquina.X);
                maxX = Math.Max(maxX, esquina.X);
                minY = Math.Min(minY, esquina.Y);
                maxY = Math.Max(maxY, esquina.Y);
                minZ = Math.Min(minZ, esquina.Z);
                maxZ = Math.Max(maxZ, esquina.Z);
            }

            if (minX == double.MaxValue ||
                minY == double.MaxValue ||
                minZ == double.MaxValue)
            {
                return false;
            }

            info = new RoomInfoEspacial()
            {
                Habitacion = room,
                MinX = minX,
                MaxX = maxX,
                MinY = minY,
                MaxY = maxY,
                MinZ = minZ,
                MaxZ = maxZ
            };

            return true;
        }

        private RoomDetectado CrearRoomDetectado(
            Document doc,
            Room room,
            string origen,
            string prefijoClave)
        {
            if (doc == null || room == null || !room.IsValidObject)
                return null;

            return new RoomDetectado()
            {
                Documento = doc,
                Habitacion = room,
                Origen = origen ?? "",
                Clave = (prefijoClave ?? "") + ":" +
                    room.Id.Value.ToString(CultureInfo.InvariantCulture)
            };
        }

        private void AgregarRoomDetectadoUnico(
            List<RoomDetectado> lista,
            RoomDetectado item)
        {
            if (lista == null || item == null || string.IsNullOrWhiteSpace(item.Clave))
                return;

            if (!lista.Any(x =>
                x != null &&
                string.Equals(
                    x.Clave,
                    item.Clave,
                    StringComparison.OrdinalIgnoreCase)))
            {
                lista.Add(item);
            }
        }

        private DeteccionHabitacion CrearDeteccionDesdeRooms(
            List<RoomDetectado> rooms)
        {
            DeteccionHabitacion resultado = new DeteccionHabitacion();
            if (rooms == null)
                return resultado;

            foreach (RoomDetectado rd in rooms)
                AgregarRoomDetectadoUnico(resultado.Habitaciones, rd);

            List<string> nombres = resultado.Habitaciones
                .Select(x => x == null ? "" : LimpiarNombreRoom(x.Habitacion))
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(x => x)
                .ToList();

            resultado.Nombre = string.Join(" | ", nombres);

            List<string> origenes = resultado.Habitaciones
                .Select(x => x == null ? "" : x.Origen ?? "")
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            if (origenes.Count == 1)
                resultado.Origen = origenes[0];
            else if (origenes.Count > 1)
                resultado.Origen = string.Join(", ", origenes);

            return resultado;
        }

        private List<RoomDetectado> BuscarHabitacionesHostEnPuntos(
            Document doc,
            List<RoomInfoEspacial> indiceHabitaciones,
            List<XYZ> puntos)
        {
            List<RoomDetectado> resultado = new List<RoomDetectado>();

            if (doc == null || indiceHabitaciones == null || puntos == null)
                return resultado;

            foreach (XYZ punto in puntos)
            {
                Room room = BuscarRoomEnPunto(indiceHabitaciones, punto);
                if (room == null)
                    continue;

                RoomDetectado rd = CrearRoomDetectado(
                    doc,
                    room,
                    "Anfitrión",
                    "H");
                AgregarRoomDetectadoUnico(resultado, rd);
            }

            return resultado;
        }

        private List<RoomDetectado> BuscarHabitacionesVinculadasEnPuntos(
            List<XYZ> puntosHost,
            List<ConjuntoHabitacionesVinculo> conjuntos)
        {
            List<RoomDetectado> resultado = new List<RoomDetectado>();

            if (puntosHost == null || conjuntos == null)
                return resultado;

            foreach (ConjuntoHabitacionesVinculo conjunto in conjuntos)
            {
                if (conjunto == null ||
                    conjunto.Documento == null ||
                    !conjunto.Documento.IsValidObject ||
                    conjunto.HostAVinculo == null ||
                    conjunto.IndiceHabitaciones == null ||
                    conjunto.IndiceHabitaciones.Count == 0)
                {
                    continue;
                }

                string idLink = conjunto.Instancia == null
                    ? "LINK"
                    : conjunto.Instancia.Id.Value.ToString(CultureInfo.InvariantCulture);

                foreach (XYZ puntoHost in puntosHost)
                {
                    if (puntoHost == null)
                        continue;

                    XYZ puntoVinculo = null;
                    try
                    {
                        puntoVinculo = conjunto.HostAVinculo.OfPoint(puntoHost);
                    }
                    catch
                    {
                        puntoVinculo = null;
                    }

                    if (puntoVinculo == null)
                        continue;

                    Room room = BuscarRoomEnPunto(
                        conjunto.IndiceHabitaciones,
                        puntoVinculo);

                    if (room == null)
                        continue;

                    RoomDetectado rd = CrearRoomDetectado(
                        conjunto.Documento,
                        room,
                        "Vínculo: " + (conjunto.NombreVinculo ?? "RVT"),
                        "L" + idLink);

                    AgregarRoomDetectadoUnico(resultado, rd);
                }
            }

            return resultado;
        }

        private Room BuscarRoomEnPunto(
            List<RoomInfoEspacial> indiceHabitaciones,
            XYZ punto)
        {
            if (indiceHabitaciones == null || punto == null)
                return null;

            const double tolerancia = 0.02; // pies (~6 mm)

            foreach (RoomInfoEspacial info in indiceHabitaciones)
            {
                if (info == null || info.Habitacion == null ||
                    !info.Habitacion.IsValidObject)
                {
                    continue;
                }

                // Descartar por BoundingBox ANTES del costoso IsPointInRoom().
                if (punto.X < info.MinX - tolerancia ||
                    punto.X > info.MaxX + tolerancia ||
                    punto.Y < info.MinY - tolerancia ||
                    punto.Y > info.MaxY + tolerancia ||
                    punto.Z < info.MinZ - tolerancia ||
                    punto.Z > info.MaxZ + tolerancia)
                {
                    continue;
                }

                try
                {
                    if (info.Habitacion.IsPointInRoom(punto))
                        return info.Habitacion;
                }
                catch
                {
                }
            }

            return null;
        }

        private Room ObtenerRoomDirecto(FamilyInstance fi)
        {
            if (fi == null)
                return null;

            try
            {
                Room r = fi.Room;
                if (r != null && r.IsValidObject)
                    return r;
            }
            catch
            {
            }

            return null;
        }

        private List<Room> ObtenerRoomsLados(FamilyInstance fi)
        {
            List<Room> resultado = new List<Room>();
            HashSet<long> ids = new HashSet<long>();

            if (fi == null)
                return resultado;

            try
            {
                Room r = fi.ToRoom;
                if (r != null && r.IsValidObject && ids.Add(r.Id.Value))
                    resultado.Add(r);
            }
            catch
            {
            }

            try
            {
                Room r = fi.FromRoom;
                if (r != null && r.IsValidObject && ids.Add(r.Id.Value))
                    resultado.Add(r);
            }
            catch
            {
            }

            return resultado;
        }

        private string LimpiarNombreRoom(Room room)
        {
            if (room == null)
                return "";

            try
            {
                return string.IsNullOrWhiteSpace(room.Name)
                    ? ""
                    : room.Name.Trim();
            }
            catch
            {
                return "";
            }
        }

        private List<XYZ> ObtenerPuntosPruebaElemento(Element e)
        {
            List<XYZ> puntos = new List<XYZ>();
            if (e == null)
                return puntos;

            bool tieneUbicacion = false;

            try
            {
                LocationPoint lp = e.Location as LocationPoint;
                if (lp != null && lp.Point != null)
                {
                    AgregarPuntoSiValido(puntos, lp.Point);
                    tieneUbicacion = true;
                }
            }
            catch
            {
            }

            try
            {
                LocationCurve lc = e.Location as LocationCurve;
                if (lc != null && lc.Curve != null)
                {
                    // V3.1: 3 muestras son suficientes para la búsqueda inicial.
                    // Antes eran 5 y luego cada una generaba muchos offsets adicionales.
                    double[] parametros = { 0.15, 0.50, 0.85 };
                    foreach (double t in parametros)
                    {
                        try
                        {
                            AgregarPuntoSiValido(
                                puntos,
                                lc.Curve.Evaluate(t, true));
                        }
                        catch
                        {
                        }
                    }

                    tieneUbicacion = true;

                    Wall wall = e as Wall;
                    if (wall != null)
                    {
                        try
                        {
                            XYZ p0 = lc.Curve.GetEndPoint(0);
                            XYZ p1 = lc.Curve.GetEndPoint(1);
                            XYZ dir = p1 - p0;
                            XYZ dirXY = new XYZ(dir.X, dir.Y, 0.0);

                            if (dirXY.GetLength() > 0.000001)
                            {
                                dirXY = dirXY.Normalize();
                                XYZ normal = new XYZ(-dirXY.Y, dirXY.X, 0.0);
                                double desplazamiento = Math.Max(
                                    0.10,
                                    wall.Width * 0.5 + 0.05);
                                XYZ medio = lc.Curve.Evaluate(0.50, true);

                                AgregarPuntoSiValido(
                                    puntos,
                                    medio + normal * desplazamiento);
                                AgregarPuntoSiValido(
                                    puntos,
                                    medio - normal * desplazamiento);
                            }
                        }
                        catch
                        {
                        }
                    }
                }
            }
            catch
            {
            }

            // Para suelos/techos y otros elementos sin Location útil, un centroide del
            // sólido suele representar mucho mejor el elemento que el centro de su caja.
            if (!tieneUbicacion)
            {
                XYZ centroide = ObtenerCentroideGeometrico(e);
                if (centroide != null)
                {
                    AgregarPuntoSiValido(puntos, centroide);
                    AgregarOffsetsXYCentro(puntos, centroide);
                }
            }

            try
            {
                BoundingBoxXYZ bb = e.get_BoundingBox(null);
                if (bb != null)
                {
                    XYZ min = bb.Min;
                    XYZ max = bb.Max;
                    XYZ centroLocal = new XYZ(
                        (min.X + max.X) * 0.5,
                        (min.Y + max.Y) * 0.5,
                        (min.Z + max.Z) * 0.5);

                    XYZ centro = bb.Transform != null
                        ? bb.Transform.OfPoint(centroLocal)
                        : centroLocal;

                    AgregarPuntoSiValido(puntos, centro);

                    // Dos puntos muy útiles para suelos/falsos pisos: apenas por encima
                    // de la cara superior y apenas por debajo de la inferior.
                    const double dz = 0.05; // pies (~15 mm)

                    XYZ arribaLocal = new XYZ(
                        centroLocal.X,
                        centroLocal.Y,
                        max.Z + dz);

                    XYZ abajoLocal = new XYZ(
                        centroLocal.X,
                        centroLocal.Y,
                        min.Z - dz);

                    AgregarPuntoSiValido(
                        puntos,
                        bb.Transform != null
                            ? bb.Transform.OfPoint(arribaLocal)
                            : arribaLocal);

                    AgregarPuntoSiValido(
                        puntos,
                        bb.Transform != null
                            ? bb.Transform.OfPoint(abajoLocal)
                            : abajoLocal);

                    // Solo expandimos alrededor del centro UNA vez. En V3.0 se hacía
                    // alrededor de hasta 12 puntos y eso multiplicaba las búsquedas.
                    AgregarOffsetsXYCentro(puntos, centro);
                }
            }
            catch
            {
            }

            return puntos;
        }

        private void AgregarOffsetsXYCentro(List<XYZ> puntos, XYZ centro)
        {
            if (puntos == null || centro == null)
                return;

            double[] offsets = { 0.10, 0.30 };
            foreach (double d in offsets)
            {
                AgregarPuntoSiValido(puntos, centro + new XYZ(d, 0, 0));
                AgregarPuntoSiValido(puntos, centro - new XYZ(d, 0, 0));
                AgregarPuntoSiValido(puntos, centro + new XYZ(0, d, 0));
                AgregarPuntoSiValido(puntos, centro - new XYZ(0, d, 0));
            }
        }

        private XYZ ObtenerCentroideGeometrico(Element e)
        {
            if (e == null)
                return null;

            try
            {
                Options opciones = new Options();
                opciones.ComputeReferences = false;
                opciones.IncludeNonVisibleObjects = false;
                opciones.DetailLevel = ViewDetailLevel.Coarse;

                GeometryElement geometria = e.get_Geometry(opciones);
                if (geometria == null)
                    return null;

                Solid mejor = null;
                double mayorVolumen = 0.0;

                foreach (GeometryObject obj in geometria)
                {
                    Solid solid = obj as Solid;
                    if (solid == null || solid.Faces == null || solid.Faces.Size == 0)
                        continue;

                    double volumen = 0.0;
                    try
                    {
                        volumen = solid.Volume;
                    }
                    catch
                    {
                        volumen = 0.0;
                    }

                    if (volumen > mayorVolumen)
                    {
                        mayorVolumen = volumen;
                        mejor = solid;
                    }
                }

                if (mejor != null)
                {
                    try
                    {
                        return mejor.ComputeCentroid();
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }

            return null;
        }

        private void AgregarPuntoSiValido(List<XYZ> puntos, XYZ punto)
        {
            if (puntos == null || punto == null)
                return;

            bool repetido = puntos.Any(x =>
                x != null && x.DistanceTo(punto) < 0.00001);

            if (!repetido)
                puntos.Add(punto);
        }
    }
}
