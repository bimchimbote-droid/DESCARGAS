﻿// =====================================
// VENTANA - TOMACORRIENTES DESDE BLOQUES CAD - BOTON 54
// REPLANTEO: SELECCIONAR HABITACIONES + NIVEL BASE + ALTURA
// SIN USING / SIN NAMESPACE
// =====================================

public class CrearTomacorrientesDesdeBloquesCad54Form : System.Windows.Forms.Form
{
    public enum CrearTomacorrientesDesdeBloquesCadAccion
    {
        Ninguna,
        SeleccionarCad,
        SeleccionarHabitaciones,
        CrearTomacorrientes
    }

    public class HabitacionSeleccionadaTomacorrienteMYG
    {
        public bool EsDeVinculo { get; set; }
        public Autodesk.Revit.DB.ElementId LinkInstanceId { get; set; }
        public Autodesk.Revit.DB.ElementId ElementoEspacialId { get; set; }
        public string Nombre { get; set; }
    }

    private class NivelComboItemMYG
    {
        public Autodesk.Revit.DB.ElementId Id { get; set; }
        public string Nombre { get; set; }
        public double Elevacion { get; set; }

        public override string ToString()
        {
            return Nombre;
        }
    }

    private Autodesk.Revit.UI.UIDocument _uidoc;
    private Autodesk.Revit.DB.Document _doc;

    private System.Windows.Forms.Label lblCadSeleccionado;
    private System.Windows.Forms.Label lblHabitacionesSeleccionadas;

    private System.Windows.Forms.TextBox txtRutaExcel;
    private System.Windows.Forms.ComboBox cmbNivelBase;
    private System.Windows.Forms.NumericUpDown nudAlturaM;
    private System.Windows.Forms.RichTextBox txtResultado;

    private System.Windows.Forms.Button btnSeleccionarCad;
    private System.Windows.Forms.Button btnBuscarExcel;
    private System.Windows.Forms.Button btnSeleccionarHabitaciones;
    private System.Windows.Forms.Button btnCrearTomacorrientes;

    public Autodesk.Revit.UI.ExternalEvent EjecutarEvent;
    public EjecutarCrearTomacorrientesDesdeBloquesCad54Handler Handler;

    public Autodesk.Revit.DB.ElementId CadSeleccionadoId { get; set; }

    public System.Collections.Generic.List<HabitacionSeleccionadaTomacorrienteMYG> HabitacionesSeleccionadas { get; private set; }

    public string RutaExcelActual
    {
        get
        {
            if (txtRutaExcel == null)
                return "";

            return txtRutaExcel.Text == null ? "" : txtRutaExcel.Text.Trim();
        }
    }

    public Autodesk.Revit.DB.ElementId NivelBaseSeleccionadoId
    {
        get
        {
            if (cmbNivelBase == null || cmbNivelBase.SelectedItem == null)
                return Autodesk.Revit.DB.ElementId.InvalidElementId;

            NivelComboItemMYG item = cmbNivelBase.SelectedItem as NivelComboItemMYG;

            if (item == null || item.Id == null)
                return Autodesk.Revit.DB.ElementId.InvalidElementId;

            return item.Id;
        }
    }

    public double AlturaSobreNivelM
    {
        get
        {
            if (nudAlturaM == null)
                return 0.40;

            return (double)nudAlturaM.Value;
        }
    }

    public CrearTomacorrientesDesdeBloquesCad54Form(Autodesk.Revit.UI.UIDocument uidoc)
    {
        _uidoc = uidoc;
        _doc = uidoc.Document;

        CadSeleccionadoId = Autodesk.Revit.DB.ElementId.InvalidElementId;
        HabitacionesSeleccionadas = new System.Collections.Generic.List<HabitacionSeleccionadaTomacorrienteMYG>();

        this.Text = "Tomacorrientes desde CAD";
        this.Width = 760;
        this.Height = 620;
        this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
        this.TopLevel = false;
        this.ShowInTaskbar = false;
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.Dock = System.Windows.Forms.DockStyle.Fill;
        this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
        this.Font = new System.Drawing.Font("Segoe UI", 9F);
        this.TopMost = false;
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;

        InicializarComponentes();
        CargarNiveles();
    }

    private void InicializarComponentes()
    {
        System.Windows.Forms.Label lblAutor = CrearLabelBase(
            "Creado por: Ing. Marlon Yacila  |  MEP - Tomacorrientes desde bloques CAD",
            20,
            10,
            700,
            20);

        lblAutor.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold);
        lblAutor.ForeColor = System.Drawing.Color.Gray;

        System.Windows.Forms.Label lblTituloCad = CrearTitulo("01. SELECCIONAR VÍNCULO / IMPORTACIÓN CAD", 20, 42, 700);

        System.Windows.Forms.Label lblInfoCad = CrearLabelBase(
            "Selecciona el CAD vinculado/importado. El DWG debe estar abierto en AutoCAD o Civil 3D para leer los bloques.",
            20,
            68,
            700,
            34);

        btnSeleccionarCad = CrearBoton(
            "SELECCIONAR CAD",
            20,
            110,
            180,
            System.Drawing.Color.FromArgb(90, 90, 90));

        btnSeleccionarCad.Click += (s, e) =>
        {
            if (Handler == null)
                return;

            Handler.Accion = CrearTomacorrientesDesdeBloquesCadAccion.SeleccionarCad;
            EjecutarEvent?.Raise();
        };

        lblCadSeleccionado = CrearLabelBase(
            "CAD seleccionado: Ninguno",
            220,
            108,
            500,
            45);

        System.Windows.Forms.Label lblTituloExcel = CrearTitulo("02. EXCEL DE MATRIZ", 20, 165, 700);

        System.Windows.Forms.Label lblFormato = CrearLabelBase(
            "Formato requerido: Columna A = Nombre de bloque CAD | Columna B = Nombre de tipo de familia Revit",
            20,
            190,
            700,
            22);

        txtRutaExcel = new System.Windows.Forms.TextBox()
        {
            Left = 20,
            Top = 217,
            Width = 570,
            Height = 25,
            BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        };

        btnBuscarExcel = CrearBoton(
            "BUSCAR...",
            605,
            215,
            105,
            System.Drawing.Color.FromArgb(120, 120, 120));

        btnBuscarExcel.Height = 29;
        btnBuscarExcel.Click += (s, e) => SeleccionarRutaExcelExistente();

        System.Windows.Forms.Label lblTituloParametros = CrearTitulo("03. PARÁMETROS DE UBICACIÓN EN MURO", 20, 263, 700);

        System.Windows.Forms.Label lblNivel = CrearLabelBase(
            "Nivel base para crear altura:",
            20,
            293,
            180,
            22);

        cmbNivelBase = new System.Windows.Forms.ComboBox()
        {
            Left = 210,
            Top = 290,
            Width = 245,
            Height = 26,
            DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList,
            IntegralHeight = false,
            DropDownHeight = 180
        };

        System.Windows.Forms.Label lblAltura = CrearLabelBase(
            "Altura sobre nivel (m):",
            470,
            293,
            145,
            22);

        nudAlturaM = new System.Windows.Forms.NumericUpDown()
        {
            Left = 620,
            Top = 290,
            Width = 85,
            Height = 24,
            DecimalPlaces = 3,
            Increment = 0.050M,
            Minimum = 0.000M,
            Maximum = 3.000M,
            Value = 0.400M
        };

        btnSeleccionarHabitaciones = CrearBoton(
            "SELECCIONAR HABITACIONES",
            20,
            330,
            230,
            System.Drawing.Color.FromArgb(90, 90, 90));

        btnSeleccionarHabitaciones.Click += (s, e) =>
        {
            if (Handler == null)
                return;

            Handler.Accion = CrearTomacorrientesDesdeBloquesCadAccion.SeleccionarHabitaciones;
            EjecutarEvent?.Raise();
        };

        lblHabitacionesSeleccionadas = CrearLabelBase(
            "Habitaciones seleccionadas: 0",
            270,
            328,
            440,
            40);

        System.Windows.Forms.Label lblNota = CrearLabelBase(
            "Flujo replanteado: bloque CAD → habitación seleccionada → proyección al contorno → cara vertical más cercana → familia por cara mirando hacia adentro.",
            20,
            382,
            700,
            38);

        System.Windows.Forms.Label lblTituloResultado = CrearTitulo("04. RESULTADO", 20, 430, 700);

        txtResultado = new System.Windows.Forms.RichTextBox()
        {
            Left = 20,
            Top = 460,
            Width = 690,
            Height = 70,
            ReadOnly = true,
            BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
            BackColor = System.Drawing.Color.White,
            Font = new System.Drawing.Font("Consolas", 8.5F),
            WordWrap = false,
            ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        };

        btnCrearTomacorrientes = CrearBoton(
            "CREAR TOMACORRIENTES DESDE CAD",
            215,
            548,
            330,
            System.Drawing.Color.FromArgb(0, 120, 215));

        btnCrearTomacorrientes.Height = 42;

        btnCrearTomacorrientes.Click += (s, e) =>
        {
            if (CadSeleccionadoId == Autodesk.Revit.DB.ElementId.InvalidElementId)
            {
                MostrarResultado("Debe seleccionar un vínculo/importación CAD.");
                return;
            }

            if (string.IsNullOrWhiteSpace(RutaExcelActual))
            {
                MostrarResultado("Debe seleccionar un archivo Excel.");
                return;
            }

            if (!System.IO.File.Exists(RutaExcelActual))
            {
                MostrarResultado("No existe el Excel indicado.");
                return;
            }

            if (NivelBaseSeleccionadoId == Autodesk.Revit.DB.ElementId.InvalidElementId)
            {
                MostrarResultado("Debe seleccionar un nivel base.");
                return;
            }

            if (HabitacionesSeleccionadas == null || HabitacionesSeleccionadas.Count == 0)
            {
                MostrarResultado("Debe seleccionar habitaciones/espacios a evaluar.");
                return;
            }

            if (Handler == null)
                return;

            Handler.Accion = CrearTomacorrientesDesdeBloquesCadAccion.CrearTomacorrientes;
            EjecutarEvent?.Raise();
        };

        this.Controls.Add(lblAutor);
        this.Controls.Add(lblTituloCad);
        this.Controls.Add(lblInfoCad);
        this.Controls.Add(btnSeleccionarCad);
        this.Controls.Add(lblCadSeleccionado);
        this.Controls.Add(lblTituloExcel);
        this.Controls.Add(lblFormato);
        this.Controls.Add(txtRutaExcel);
        this.Controls.Add(btnBuscarExcel);
        this.Controls.Add(lblTituloParametros);
        this.Controls.Add(lblNivel);
        this.Controls.Add(cmbNivelBase);
        this.Controls.Add(lblAltura);
        this.Controls.Add(nudAlturaM);
        this.Controls.Add(btnSeleccionarHabitaciones);
        this.Controls.Add(lblHabitacionesSeleccionadas);
        this.Controls.Add(lblNota);
        this.Controls.Add(lblTituloResultado);
        this.Controls.Add(txtResultado);
        this.Controls.Add(btnCrearTomacorrientes);

        MostrarResultado("Seleccione CAD, Excel, nivel, habitaciones y luego cree los tomacorrientes.");
    }

    private void CargarNiveles()
    {
        if (_doc == null || cmbNivelBase == null)
            return;

        try
        {
            cmbNivelBase.Items.Clear();

            System.Collections.Generic.List<Autodesk.Revit.DB.Level> niveles =
                new System.Collections.Generic.List<Autodesk.Revit.DB.Level>();

            Autodesk.Revit.DB.FilteredElementCollector collector =
                new Autodesk.Revit.DB.FilteredElementCollector(_doc);

            collector.OfClass(typeof(Autodesk.Revit.DB.Level));

            foreach (Autodesk.Revit.DB.Element e in collector)
            {
                Autodesk.Revit.DB.Level nivel = e as Autodesk.Revit.DB.Level;

                if (nivel != null)
                    niveles.Add(nivel);
            }

            niveles.Sort(delegate (Autodesk.Revit.DB.Level a, Autodesk.Revit.DB.Level b)
            {
                if (a == null && b == null)
                    return 0;

                if (a == null)
                    return -1;

                if (b == null)
                    return 1;

                return a.Elevation.CompareTo(b.Elevation);
            });

            foreach (Autodesk.Revit.DB.Level nivel in niveles)
            {
                NivelComboItemMYG item = new NivelComboItemMYG();
                item.Id = nivel.Id;
                item.Nombre = nivel.Name;
                item.Elevacion = nivel.Elevation;

                cmbNivelBase.Items.Add(item);
            }

            Autodesk.Revit.DB.ElementId nivelActivoId = Autodesk.Revit.DB.ElementId.InvalidElementId;

            try
            {
                if (_doc.ActiveView != null && _doc.ActiveView.GenLevel != null)
                    nivelActivoId = _doc.ActiveView.GenLevel.Id;
            }
            catch
            {
                nivelActivoId = Autodesk.Revit.DB.ElementId.InvalidElementId;
            }

            int indice = 0;

            if (nivelActivoId != Autodesk.Revit.DB.ElementId.InvalidElementId)
            {
                for (int i = 0; i < cmbNivelBase.Items.Count; i++)
                {
                    NivelComboItemMYG item = cmbNivelBase.Items[i] as NivelComboItemMYG;

                    if (item != null && item.Id == nivelActivoId)
                    {
                        indice = i;
                        break;
                    }
                }
            }

            if (cmbNivelBase.Items.Count > 0)
                cmbNivelBase.SelectedIndex = indice;
        }
        catch
        {
        }
    }

    private System.Windows.Forms.Label CrearTitulo(string texto, int left, int top, int width)
    {
        System.Windows.Forms.Label lbl = CrearLabelBase(texto, left, top, width, 22);
        lbl.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
        lbl.ForeColor = System.Drawing.Color.FromArgb(50, 50, 50);
        return lbl;
    }

    private System.Windows.Forms.Label CrearLabelBase(string texto, int left, int top, int width, int height)
    {
        return new System.Windows.Forms.Label()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = height,
            ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
        };
    }

    private System.Windows.Forms.Button CrearBoton(string texto, int left, int top, int width, System.Drawing.Color color)
    {
        System.Windows.Forms.Button boton = new System.Windows.Forms.Button()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 34,
            BackColor = color,
            ForeColor = System.Drawing.Color.White,
            FlatStyle = System.Windows.Forms.FlatStyle.Flat,
            Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
            Cursor = System.Windows.Forms.Cursors.Hand
        };

        boton.FlatAppearance.BorderSize = 0;
        boton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(
            System.Math.Max(color.R - 15, 0),
            System.Math.Max(color.G - 15, 0),
            System.Math.Max(color.B - 15, 0));

        return boton;
    }

    private void SeleccionarRutaExcelExistente()
    {
        using (System.Windows.Forms.OpenFileDialog dialog = new System.Windows.Forms.OpenFileDialog())
        {
            dialog.Title = "Seleccionar Excel de matriz CAD - Familia";
            dialog.Filter = "Archivo Excel (*.xlsx)|*.xlsx";
            dialog.RestoreDirectory = true;
            dialog.Multiselect = false;

            System.Windows.Forms.DialogResult resultado = dialog.ShowDialog(this);

            if (resultado != System.Windows.Forms.DialogResult.OK)
                return;

            EstablecerRutaExcel(dialog.FileName);
        }
    }

    public void EstablecerRutaExcel(string ruta)
    {
        if (txtRutaExcel == null)
            return;

        txtRutaExcel.Text = ruta ?? "";
    }

    public void ActualizarCadSeleccionado(Autodesk.Revit.DB.ImportInstance cad)
    {
        if (cad == null)
        {
            CadSeleccionadoId = Autodesk.Revit.DB.ElementId.InvalidElementId;

            if (lblCadSeleccionado != null)
                lblCadSeleccionado.Text = "CAD seleccionado: Ninguno";

            MostrarResultado("No se seleccionó ningún CAD válido.");
            return;
        }

        CadSeleccionadoId = cad.Id;

        string nombre = "";

        try
        {
            nombre = cad.Name;
        }
        catch
        {
            nombre = "";
        }

        if (string.IsNullOrWhiteSpace(nombre))
            nombre = "ImportInstance " + cad.Id.Value.ToString();

        if (lblCadSeleccionado != null)
        {
            lblCadSeleccionado.Text =
                "CAD seleccionado:\r\n" +
                nombre + " | ID: " + cad.Id.Value.ToString();
        }

        MostrarResultado("CAD seleccionado correctamente.");
    }

    public void ActualizarHabitacionesSeleccionadas(System.Collections.Generic.List<HabitacionSeleccionadaTomacorrienteMYG> habitaciones)
    {
        HabitacionesSeleccionadas = habitaciones ?? new System.Collections.Generic.List<HabitacionSeleccionadaTomacorrienteMYG>();

        if (lblHabitacionesSeleccionadas != null)
        {
            string resumen = "Habitaciones seleccionadas: " + HabitacionesSeleccionadas.Count.ToString();

            if (HabitacionesSeleccionadas.Count > 0)
            {
                int vinculadas = 0;

                foreach (HabitacionSeleccionadaTomacorrienteMYG h in HabitacionesSeleccionadas)
                {
                    if (h != null && h.EsDeVinculo)
                        vinculadas++;
                }

                int nativas = HabitacionesSeleccionadas.Count - vinculadas;

                resumen += " | Nativas: " + nativas.ToString() + " | Vínculo: " + vinculadas.ToString();
            }

            lblHabitacionesSeleccionadas.Text = resumen;
        }

        MostrarResultado("Habitaciones/espacios seleccionados: " + HabitacionesSeleccionadas.Count.ToString());
    }

    public void MostrarResultado(string texto)
    {
        if (txtResultado == null || txtResultado.IsDisposed)
            return;

        if (this.InvokeRequired)
        {
            this.BeginInvoke(new System.Action(() => MostrarResultado(texto)));
            return;
        }

        txtResultado.Clear();

        string t = texto ?? "";

        if (t.StartsWith("ERROR", System.StringComparison.OrdinalIgnoreCase) ||
            t.StartsWith("Debe", System.StringComparison.OrdinalIgnoreCase) ||
            t.StartsWith("No se", System.StringComparison.OrdinalIgnoreCase) ||
            t.StartsWith("Selección cancelada", System.StringComparison.OrdinalIgnoreCase))
        {
            txtResultado.SelectionColor = System.Drawing.Color.FromArgb(190, 40, 40);
        }
        else
        {
            txtResultado.SelectionColor = System.Drawing.Color.FromArgb(50, 50, 50);
        }

        txtResultado.AppendText(t);
        txtResultado.SelectionStart = 0;
        txtResultado.ScrollToCaret();
    }

    public void OcultarTemporalmenteParaSeleccion()
    {
        try
        {
            System.Windows.Forms.Form padre = this.FindForm();

            if (padre != null)
                padre.Hide();
            else
                this.Hide();
        }
        catch
        {
        }
    }

    public void MostrarLuegoDeSeleccion()
    {
        try
        {
            System.Windows.Forms.Form padre = this.FindForm();

            if (padre != null && !padre.IsDisposed)
            {
                padre.Show();
                padre.Activate();
                padre.TopMost = true;
            }
            else if (!this.IsDisposed)
            {
                this.Show();
                this.Activate();
            }
        }
        catch
        {
        }
    }
}
