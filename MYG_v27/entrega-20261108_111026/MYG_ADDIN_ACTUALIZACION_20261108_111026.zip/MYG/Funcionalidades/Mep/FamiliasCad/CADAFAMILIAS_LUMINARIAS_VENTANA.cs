﻿// =====================================
// VENTANA - CAD BLOQUES A FAMILIAS HORIZONTALES - BOTON 54
// SUBVENTANA EMBEBIBLE EN MAIN 5.4
// SIN USING / SIN NAMESPACE
// =====================================

public class CrearFamiliasDesdeBloquesCad54Form : System.Windows.Forms.Form
{
    public enum CrearFamiliasDesdeBloquesCadAccion
    {
        Ninguna,
        SeleccionarCad,
        CrearFamilias
    }

    private Autodesk.Revit.UI.UIDocument _uidoc;
    private Autodesk.Revit.DB.Document _doc;

    private System.Windows.Forms.Label lblCadSeleccionado;
    private System.Windows.Forms.Label lblRutaExcel;
    private System.Windows.Forms.Label lblSuperficie;
    private System.Windows.Forms.RichTextBox txtResultado;

    private System.Windows.Forms.TextBox txtRutaExcel;
    private System.Windows.Forms.ComboBox cmbSuperficie;

    private System.Windows.Forms.Button btnSeleccionarCad;
    private System.Windows.Forms.Button btnBuscarExcel;
    private System.Windows.Forms.Button btnCrearFamilias;

    public Autodesk.Revit.UI.ExternalEvent EjecutarEvent;
    public EjecutarCrearFamiliasDesdeBloquesCad54Handler Handler;

    public Autodesk.Revit.DB.ElementId CadSeleccionadoId { get; set; }

    public string RutaExcelActual
    {
        get
        {
            if (txtRutaExcel == null)
                return "";

            return txtRutaExcel.Text == null ? "" : txtRutaExcel.Text.Trim();
        }
    }

    public bool BuscarSuperficieSuperior
    {
        get
        {
            if (cmbSuperficie == null || cmbSuperficie.SelectedItem == null)
                return true;

            string valor = cmbSuperficie.SelectedItem.ToString();

            if (string.IsNullOrWhiteSpace(valor))
                return true;

            return valor.ToUpper().Contains("SUPERIOR");
        }
    }

    public CrearFamiliasDesdeBloquesCad54Form(Autodesk.Revit.UI.UIDocument uidoc)
    {
        _uidoc = uidoc;
        _doc = uidoc.Document;

        CadSeleccionadoId = Autodesk.Revit.DB.ElementId.InvalidElementId;

        this.Text = "Luminarias desde CAD";
        this.Width = 760;
        this.Height = 620;
        this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
        this.TopLevel = false;
        this.ShowInTaskbar = false;
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.Dock = System.Windows.Forms.DockStyle.Fill;
        this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
        this.Font = new System.Drawing.Font("Segoe UI", 9F);
        this.TopMost = false;
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;

        InicializarComponentes();
    }

    private void InicializarComponentes()
    {
        System.Windows.Forms.Label lblAutor = CrearLabelBase(
            "Creado por: Ing. Marlon Yacila  |  MEP - Luminarias desde bloques CAD",
            20,
            10,
            700,
            20);

        lblAutor.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold);
        lblAutor.ForeColor = System.Drawing.Color.Gray;

        System.Windows.Forms.Label lblTituloCad = CrearTitulo("01. SELECCIONAR VÍNCULO / IMPORTACIÓN CAD", 20, 42, 700);

        System.Windows.Forms.Label lblInfoCad = CrearLabelBase(
            "Selecciona el CAD vinculado/importado. El DWG debe estar abierto en AutoCAD o Civil 3D para leer los bloques reales.",
            20,
            68,
            700,
            34);

        btnSeleccionarCad = CrearBoton(
            "SELECCIONAR CAD",
            20,
            110,
            180,
            System.Drawing.Color.FromArgb(90, 90, 90));

        btnSeleccionarCad.Click += (s, e) =>
        {
            if (Handler == null)
                return;

            Handler.Accion = CrearFamiliasDesdeBloquesCadAccion.SeleccionarCad;
            EjecutarEvent?.Raise();
        };

        lblCadSeleccionado = CrearLabelBase(
            "CAD seleccionado: Ninguno",
            220,
            108,
            500,
            45);

        System.Windows.Forms.Label lblTituloExcel = CrearTitulo("02. EXCEL DE MATRIZ", 20, 170, 700);

        lblRutaExcel = CrearLabelBase(
            "Formato requerido: Columna A = Nombre de bloque CAD | Columna B = Nombre de tipo de familia Revit",
            20,
            196,
            700,
            22);

        txtRutaExcel = new System.Windows.Forms.TextBox()
        {
            Left = 20,
            Top = 225,
            Width = 570,
            Height = 25,
            BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        };

        btnBuscarExcel = CrearBoton(
            "BUSCAR...",
            605,
            223,
            105,
            System.Drawing.Color.FromArgb(120, 120, 120));

        btnBuscarExcel.Height = 29;
        btnBuscarExcel.Click += (s, e) => SeleccionarRutaExcelExistente();

        System.Windows.Forms.Label lblTituloSuperficie = CrearTitulo("03. SUPERFICIE DONDE SE CREARÁ LA FAMILIA", 20, 282, 700);

        lblSuperficie = CrearLabelBase(
            "Para luminarias se busca la cara horizontal más próxima hacia arriba o hacia abajo respecto al bloque CAD.",
            20,
            308,
            700,
            22);

        cmbSuperficie = new System.Windows.Forms.ComboBox()
        {
            Left = 20,
            Top = 337,
            Width = 320,
            Height = 26,
            DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList,
            IntegralHeight = false,
            DropDownHeight = 80
        };

        cmbSuperficie.Items.Add("SUPERIOR - Cara más cercana hacia arriba");
        cmbSuperficie.Items.Add("INFERIOR - Cara más cercana hacia abajo");
        cmbSuperficie.SelectedIndex = 0;

        System.Windows.Forms.Label lblNota = CrearLabelBase(
            "El tipo de familia indicado en Excel debe existir cargado en el proyecto. La familia debe ser por cara / face-based.",
            20,
            375,
            700,
            34);

        System.Windows.Forms.Label lblTituloResultado = CrearTitulo("04. RESULTADO", 20, 430, 700);

        txtResultado = new System.Windows.Forms.RichTextBox()
        {
            Left = 20,
            Top = 460,
            Width = 690,
            Height = 70,
            ReadOnly = true,
            BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
            BackColor = System.Drawing.Color.White,
            Font = new System.Drawing.Font("Consolas", 8.5F),
            WordWrap = false,
            ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        };

        btnCrearFamilias = CrearBoton(
            "CREAR LUMINARIAS DESDE CAD",
            230,
            548,
            300,
            System.Drawing.Color.FromArgb(0, 120, 215));

        btnCrearFamilias.Height = 42;

        btnCrearFamilias.Click += (s, e) =>
        {
            if (CadSeleccionadoId == Autodesk.Revit.DB.ElementId.InvalidElementId)
            {
                MostrarResultado("Debe seleccionar un vínculo/importación CAD.");
                return;
            }

            if (string.IsNullOrWhiteSpace(RutaExcelActual))
            {
                MostrarResultado("Debe seleccionar un archivo Excel.");
                return;
            }

            if (!System.IO.File.Exists(RutaExcelActual))
            {
                MostrarResultado("No existe el Excel indicado.");
                return;
            }

            if (Handler == null)
                return;

            Handler.Accion = CrearFamiliasDesdeBloquesCadAccion.CrearFamilias;
            EjecutarEvent?.Raise();
        };

        this.Controls.Add(lblAutor);
        this.Controls.Add(lblTituloCad);
        this.Controls.Add(lblInfoCad);
        this.Controls.Add(btnSeleccionarCad);
        this.Controls.Add(lblCadSeleccionado);
        this.Controls.Add(lblTituloExcel);
        this.Controls.Add(lblRutaExcel);
        this.Controls.Add(txtRutaExcel);
        this.Controls.Add(btnBuscarExcel);
        this.Controls.Add(lblTituloSuperficie);
        this.Controls.Add(lblSuperficie);
        this.Controls.Add(cmbSuperficie);
        this.Controls.Add(lblNota);
        this.Controls.Add(lblTituloResultado);
        this.Controls.Add(txtResultado);
        this.Controls.Add(btnCrearFamilias);

        MostrarResultado("Seleccione CAD, Excel y luego cree las luminarias desde bloques CAD.");
    }

    private System.Windows.Forms.Label CrearTitulo(string texto, int left, int top, int width)
    {
        System.Windows.Forms.Label lbl = CrearLabelBase(texto, left, top, width, 22);
        lbl.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
        lbl.ForeColor = System.Drawing.Color.FromArgb(50, 50, 50);
        return lbl;
    }

    private System.Windows.Forms.Label CrearLabelBase(string texto, int left, int top, int width, int height)
    {
        return new System.Windows.Forms.Label()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = height,
            ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
        };
    }

    private System.Windows.Forms.Button CrearBoton(string texto, int left, int top, int width, System.Drawing.Color color)
    {
        System.Windows.Forms.Button boton = new System.Windows.Forms.Button()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 34,
            BackColor = color,
            ForeColor = System.Drawing.Color.White,
            FlatStyle = System.Windows.Forms.FlatStyle.Flat,
            Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
            Cursor = System.Windows.Forms.Cursors.Hand
        };

        boton.FlatAppearance.BorderSize = 0;
        boton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(
            System.Math.Max(color.R - 15, 0),
            System.Math.Max(color.G - 15, 0),
            System.Math.Max(color.B - 15, 0));

        return boton;
    }

    private void SeleccionarRutaExcelExistente()
    {
        using (System.Windows.Forms.OpenFileDialog dialog = new System.Windows.Forms.OpenFileDialog())
        {
            dialog.Title = "Seleccionar Excel de matriz CAD - Familia";
            dialog.Filter = "Archivo Excel (*.xlsx)|*.xlsx";
            dialog.RestoreDirectory = true;
            dialog.Multiselect = false;

            System.Windows.Forms.DialogResult resultado = dialog.ShowDialog(this);

            if (resultado != System.Windows.Forms.DialogResult.OK)
                return;

            EstablecerRutaExcel(dialog.FileName);
        }
    }

    public void EstablecerRutaExcel(string ruta)
    {
        if (txtRutaExcel == null)
            return;

        txtRutaExcel.Text = ruta ?? "";
    }

    public void ActualizarCadSeleccionado(Autodesk.Revit.DB.ImportInstance cad)
    {
        if (cad == null)
        {
            CadSeleccionadoId = Autodesk.Revit.DB.ElementId.InvalidElementId;

            if (lblCadSeleccionado != null)
                lblCadSeleccionado.Text = "CAD seleccionado: Ninguno";

            MostrarResultado("No se seleccionó ningún CAD válido.");
            return;
        }

        CadSeleccionadoId = cad.Id;

        string nombre = "";

        try
        {
            nombre = cad.Name;
        }
        catch
        {
            nombre = "";
        }

        if (string.IsNullOrWhiteSpace(nombre))
            nombre = "ImportInstance " + cad.Id.Value.ToString();

        if (lblCadSeleccionado != null)
        {
            lblCadSeleccionado.Text =
                "CAD seleccionado:\r\n" +
                nombre + " | ID: " + cad.Id.Value.ToString();
        }

        MostrarResultado("CAD seleccionado correctamente.");
    }

    public void MostrarResultado(string texto)
    {
        if (txtResultado == null || txtResultado.IsDisposed)
            return;

        if (this.InvokeRequired)
        {
            this.BeginInvoke(new System.Action(() => MostrarResultado(texto)));
            return;
        }

        txtResultado.Clear();

        string t = texto ?? "";

        if (t.StartsWith("ERROR", System.StringComparison.OrdinalIgnoreCase) ||
            t.StartsWith("Debe", System.StringComparison.OrdinalIgnoreCase) ||
            t.StartsWith("No se", System.StringComparison.OrdinalIgnoreCase) ||
            t.StartsWith("Selección cancelada", System.StringComparison.OrdinalIgnoreCase))
        {
            txtResultado.SelectionColor = System.Drawing.Color.FromArgb(190, 40, 40);
        }
        else
        {
            txtResultado.SelectionColor = System.Drawing.Color.FromArgb(50, 50, 50);
        }

        txtResultado.AppendText(t);
        txtResultado.SelectionStart = 0;
        txtResultado.ScrollToCaret();
    }

    public void OcultarTemporalmenteParaSeleccion()
    {
        try
        {
            System.Windows.Forms.Form padre = this.FindForm();

            if (padre != null)
                padre.Hide();
            else
                this.Hide();
        }
        catch
        {
        }
    }

    public void MostrarLuegoDeSeleccion()
    {
        try
        {
            System.Windows.Forms.Form padre = this.FindForm();

            if (padre != null && !padre.IsDisposed)
            {
                padre.Show();
                padre.Activate();
                padre.TopMost = true;
            }
            else if (!this.IsDisposed)
            {
                this.Show();
                this.Activate();
            }
        }
        catch
        {
        }
    }

    private void InitializeComponent()
    {
            this.SuspendLayout();
            // 
            // CrearFamiliasDesdeBloquesCad54Form
            // 
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Name = "CrearFamiliasDesdeBloquesCad54Form";
            this.Load += new System.EventHandler(this.CrearFamiliasDesdeBloquesCad54Form_Load);
            this.ResumeLayout(false);

    }

    private void CrearFamiliasDesdeBloquesCad54Form_Load(object sender, System.EventArgs e)
    {

    }
}
