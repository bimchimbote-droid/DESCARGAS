﻿// =====================================
// HANDLER EXTERNO - CREAR FAMILIAS DESDE BLOQUES CAD - BOTON 54
// REVIT 2027
// CAD LINK / IMPORTINSTANCE + EXCEL 2 COLUMNAS + FAMILIAS POR CARA + CENTER REFERENCE PLANES
// CON USING
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;

public class EjecutarCrearFamiliasDesdeBloquesCad54Handler : IExternalEventHandler
{
    public UIDocument UiDoc { get; set; }
    public CrearFamiliasDesdeBloquesCad54Form Form { get; set; }

    public CrearFamiliasDesdeBloquesCad54Form.CrearFamiliasDesdeBloquesCadAccion Accion { get; set; } =
        CrearFamiliasDesdeBloquesCad54Form.CrearFamiliasDesdeBloquesCadAccion.Ninguna;

    private string _ultimoDiagnosticoLecturaCad = "";

    public string GetName()
    {
        return "MYG - Crear familias desde bloques CAD";
    }

    public void Execute(UIApplication app)
    {
        if (UiDoc == null || UiDoc.Document == null)
            return;

        if (Form == null || Form.IsDisposed)
            return;

        try
        {
            if (Accion == CrearFamiliasDesdeBloquesCad54Form.CrearFamiliasDesdeBloquesCadAccion.SeleccionarCad)
            {
                SeleccionarCad();
                return;
            }

            if (Accion == CrearFamiliasDesdeBloquesCad54Form.CrearFamiliasDesdeBloquesCadAccion.CrearFamilias)
            {
                CrearFamiliasDesdeCadYExcel();
                return;
            }
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            MostrarEnVentana("Selección cancelada.");
        }
        catch (Exception ex)
        {
            MostrarEnVentana("ERROR:\r\n" + ex.Message);
        }
        finally
        {
            Accion = CrearFamiliasDesdeBloquesCad54Form.CrearFamiliasDesdeBloquesCadAccion.Ninguna;
        }
    }

    // =========================================================
    // SELECCIONAR CAD
    // =========================================================

    private void SeleccionarCad()
    {
        Document doc = UiDoc.Document;

        try
        {
            Form.OcultarTemporalmenteParaSeleccion();

            Reference referencia = UiDoc.Selection.PickObject(
                ObjectType.Element,
                new FiltroSeleccionCadImportInstanceMYG(),
                "Seleccione un vínculo/importación CAD");

            if (referencia == null)
                return;

            ImportInstance cad = doc.GetElement(referencia.ElementId) as ImportInstance;

            if (cad == null)
            {
                MostrarEnVentana("El elemento seleccionado no es un vínculo/importación CAD.");
                return;
            }

            Form.ActualizarCadSeleccionado(cad);
        }
        finally
        {
            Form.MostrarLuegoDeSeleccion();
        }
    }

    // =========================================================
    // PROCESO PRINCIPAL
    // =========================================================

    private void CrearFamiliasDesdeCadYExcel()
    {
        Document doc = UiDoc.Document;

        if (doc == null)
            return;

        ElementId cadId = Form.CadSeleccionadoId;

        if (cadId == null || cadId == ElementId.InvalidElementId)
        {
            MostrarEnVentana("Debe seleccionar un vínculo/importación CAD.");
            return;
        }

        ImportInstance cad = doc.GetElement(cadId) as ImportInstance;

        if (cad == null)
        {
            MostrarEnVentana("No se encontró el CAD seleccionado.");
            return;
        }

        string rutaExcel = Form.RutaExcelActual;

        if (string.IsNullOrWhiteSpace(rutaExcel) || !File.Exists(rutaExcel))
        {
            MostrarEnVentana("Debe seleccionar un Excel válido.");
            return;
        }

        bool buscarSuperior = Form.BuscarSuperficieSuperior;

        Dictionary<string, MapeoBloqueFamiliaMYG> matriz =
            LeerMatrizBloqueFamiliaDesdeExcel(rutaExcel);

        if (matriz == null || matriz.Count == 0)
        {
            MostrarEnVentana("No se encontraron datos válidos en el Excel. Use Columna A = bloque CAD y Columna B = tipo de familia.");
            return;
        }

        List<BloqueCadMYG> bloquesCad =
            ObtenerBloquesCadDesdeImportInstance(doc, cad, matriz);

        if (bloquesCad == null)
            bloquesCad = new List<BloqueCadMYG>();

        if (bloquesCad.Count == 0)
        {
            string detalleLectura = string.IsNullOrWhiteSpace(_ultimoDiagnosticoLecturaCad)
                ? "No hubo detalle adicional de lectura CAD."
                : _ultimoDiagnosticoLecturaCad;

            MostrarEnVentana(
                "No se detectaron bloques CAD que coincidan con el Excel.\r\n\r\n" +
                "Posibles causas:\r\n" +
                "1. El nombre del bloque en Excel no coincide exactamente.\r\n" +
                "2. El CAD fue explotado o aplanado.\r\n" +
                "3. No se pudo leer el DWG por AutoCAD COM ni por ObjectDBX.\r\n\r\n" +
                "Detalle:\r\n" + detalleLectura + "\r\n\r\n" +
                "Se canceló la creación para evitar familias superpuestas en el origen del CAD.");
            return;
        }

        string errorPuntosBloques = ValidarPuntosBloquesCad(bloquesCad);

        if (!string.IsNullOrWhiteSpace(errorPuntosBloques))
        {
            MostrarEnVentana(errorPuntosBloques);
            return;
        }

        Dictionary<string, FamilySymbol> tiposFamilia =
            ObtenerTiposFamiliaPorNombre(doc);

        if (tiposFamilia == null || tiposFamilia.Count == 0)
        {
            MostrarEnVentana("No se encontraron tipos de familia cargados en el proyecto.");
            return;
        }

        BoundingBoxXYZ bbBloques = ObtenerBoundingBoxBloques(bloquesCad);

        List<CaraCandidataMYG> carasCandidatas =
            ObtenerCarasCandidatasDelModelo(doc, bbBloques);

        if (carasCandidatas == null || carasCandidatas.Count == 0)
        {
            MostrarEnVentana("No se encontraron caras candidatas en el modelo para alojar las familias.");
            return;
        }

        // IMPORTANTE V5:
        // El punto de inserción de NewFamilyInstance se amarra al ORIGEN real de la familia.
        // Si los planos Center (Left/Right) y Center (Front/Back) no definen el origen,
        // Revit puede colocar la familia corrida hacia un costado.
        // Por eso calculamos, antes de abrir la transacción, el desfase local desde el origen
        // de cada familia hasta el cruce de sus planos de referencia CENTER.
        Dictionary<ElementId, XYZ> offsetCentroPlanosPorTipo =
            PrepararOffsetsCentroPlanosReferencia(doc, bloquesCad, matriz, tiposFamilia);

        int creadas = 0;
        int omitidasSinTipo = 0;
        int omitidasSinCara = 0;
        int omitidasError = 0;

        List<ElementId> idsCreados = new List<ElementId>();
        List<string> errores = new List<string>();

        using (Transaction tx = new Transaction(doc, "MYG - Crear familias desde bloques CAD"))
        {
            tx.Start();

            foreach (BloqueCadMYG bloque in bloquesCad)
            {
                if (bloque == null)
                    continue;

                string claveBloque = NormalizarClave(bloque.NombreBloque);

                if (!matriz.ContainsKey(claveBloque))
                    continue;

                MapeoBloqueFamiliaMYG mapeo = matriz[claveBloque];

                if (mapeo == null || string.IsNullOrWhiteSpace(mapeo.NombreTipoFamilia))
                    continue;

                FamilySymbol tipo = BuscarFamilySymbol(tiposFamilia, mapeo.NombreTipoFamilia);

                if (tipo == null)
                {
                    omitidasSinTipo++;
                    continue;
                }

                CaraObjetivoMYG caraObjetivo =
                    BuscarCaraMasProxima(bloque.PuntoInsercion, carasCandidatas, buscarSuperior);

                if (caraObjetivo == null || caraObjetivo.Referencia == null)
                {
                    omitidasSinCara++;
                    continue;
                }

                try
                {
                    if (!tipo.IsActive)
                    {
                        tipo.Activate();
                        doc.Regenerate();
                    }

                    XYZ direccionReferencia =
                        ObtenerDireccionReferenciaSobreCara(bloque.DireccionX, caraObjetivo.Normal);

                    FamilyInstance instancia = doc.Create.NewFamilyInstance(
                        caraObjetivo.Referencia,
                        caraObjetivo.PuntoEnCara,
                        direccionReferencia,
                        tipo);

                    if (instancia != null)
                    {
                        XYZ offsetCentroLocal = ObtenerOffsetCentroLocalDesdeCache(
                            offsetCentroPlanosPorTipo,
                            tipo.Id);

                        try
                        {
                            doc.Regenerate();
                        }
                        catch
                        {
                        }

                        AlinearCrucePlanosCenterConPuntoObjetivo(
                            doc,
                            instancia,
                            offsetCentroLocal,
                            caraObjetivo.PuntoEnCara,
                            caraObjetivo.Normal);

                        creadas++;
                        idsCreados.Add(instancia.Id);

                        AsignarTextoParametroSiExiste(instancia, "GEN_OrigenCAD", bloque.NombreBloque);
                        AsignarTextoParametroSiExiste(instancia, "GEN_BloqueCAD", bloque.NombreBloque);
                        AsignarTextoParametroSiExiste(instancia, "GEN_FuenteLecturaCAD", bloque.FuenteLectura);
                        AsignarTextoParametroSiExiste(instancia, "Comments", "Creado desde bloque CAD: " + bloque.NombreBloque);
                        AsignarTextoParametroSiExiste(instancia, "Comentarios", "Creado desde bloque CAD: " + bloque.NombreBloque);
                    }
                }
                catch (Exception ex)
                {
                    omitidasError++;

                    if (errores.Count < 10)
                    {
                        errores.Add(
                            bloque.NombreBloque + " -> " +
                            mapeo.NombreTipoFamilia + " | " +
                            ex.Message);
                    }
                }
            }

            tx.Commit();
        }

        if (idsCreados.Count > 0)
        {
            try
            {
                UiDoc.Selection.SetElementIds(idsCreados);
            }
            catch
            {
            }
        }

        string mensaje =
            "Proceso terminado.\r\n" +
            "Bloques CAD coincidentes: " + bloquesCad.Count.ToString() + "\r\n" +
            "Familias creadas: " + creadas.ToString() + "\r\n" +
            "Omitidas sin tipo de familia: " + omitidasSinTipo.ToString() + "\r\n" +
            "Omitidas sin cara " + (buscarSuperior ? "superior" : "inferior") + ": " + omitidasSinCara.ToString() + "\r\n" +
            "Omitidas por error: " + omitidasError.ToString();

        if (errores.Count > 0)
        {
            mensaje += "\r\n\r\nPrimeros errores:\r\n";

            foreach (string error in errores)
                mensaje += "- " + error + "\r\n";
        }

        MostrarEnVentana(mensaje);
    }

    // =========================================================
    // LEER EXCEL
    // =========================================================

    private Dictionary<string, MapeoBloqueFamiliaMYG> LeerMatrizBloqueFamiliaDesdeExcel(string rutaExcel)
    {
        Dictionary<string, MapeoBloqueFamiliaMYG> resultado =
            new Dictionary<string, MapeoBloqueFamiliaMYG>();

        if (string.IsNullOrWhiteSpace(rutaExcel) || !File.Exists(rutaExcel))
            return resultado;

        ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;

        FileInfo archivo = new FileInfo(rutaExcel);

        using (ExcelPackage package = new ExcelPackage(archivo))
        {
            ExcelWorksheet ws = null;

            foreach (ExcelWorksheet hoja in package.Workbook.Worksheets)
            {
                if (hoja != null)
                {
                    ws = hoja;
                    break;
                }
            }

            if (ws == null || ws.Dimension == null)
                return resultado;

            int filaInicio = ws.Dimension.Start.Row;
            int filaFin = ws.Dimension.End.Row;

            for (int fila = filaInicio; fila <= filaFin; fila++)
            {
                string nombreBloque = ObtenerTextoCelda(ws, fila, 1);
                string nombreTipoFamilia = ObtenerTextoCelda(ws, fila, 2);

                if (string.IsNullOrWhiteSpace(nombreBloque) ||
                    string.IsNullOrWhiteSpace(nombreTipoFamilia))
                {
                    continue;
                }

                string bloqueNormalizado = NormalizarClave(nombreBloque);
                string tipoNormalizado = NormalizarClave(nombreTipoFamilia);

                bool pareceEncabezado =
                    bloqueNormalizado.Contains("BLOQUE") &&
                    (tipoNormalizado.Contains("FAMILIA") || tipoNormalizado.Contains("TIPO"));

                if (pareceEncabezado)
                    continue;

                if (resultado.ContainsKey(bloqueNormalizado))
                    continue;

                MapeoBloqueFamiliaMYG item = new MapeoBloqueFamiliaMYG();
                item.NombreBloque = nombreBloque.Trim();
                item.NombreTipoFamilia = nombreTipoFamilia.Trim();

                resultado.Add(bloqueNormalizado, item);
            }
        }

        return resultado;
    }

    private string ObtenerTextoCelda(ExcelWorksheet ws, int fila, int columna)
    {
        if (ws == null)
            return "";

        try
        {
            object valor = ws.Cells[fila, columna].Value;

            if (valor == null)
                return "";

            return valor.ToString().Trim();
        }
        catch
        {
            return "";
        }
    }

    // =========================================================
    // OBTENER BLOQUES CAD
    // =========================================================

    private List<BloqueCadMYG> ObtenerBloquesCadDesdeImportInstance(
    Document doc,
    ImportInstance cad,
    Dictionary<string, MapeoBloqueFamiliaMYG> matriz)
    {
        List<BloqueCadMYG> resultado = new List<BloqueCadMYG>();

        _ultimoDiagnosticoLecturaCad = "";

        if (doc == null || cad == null || matriz == null || matriz.Count == 0)
            return resultado;

        // 01) Primero intenta leer desde AutoCAD/Civil 3D si el DWG ya está abierto.
        // Esta ruta es la más estable cuando el usuario tiene el DWG abierto, porque lee
        // BlockReference.EffectiveName, InsertionPoint y Rotation reales.
        resultado = ObtenerBloquesCadDesdeAutoCadCom(doc, cad, matriz);

        if (resultado != null && resultado.Count > 0)
            return resultado;

        // 02) Si AutoCAD no está abierto o el DWG no está abierto ahí, intenta ObjectDBX.
        // ObjectDBX permite abrir el DWG en memoria y leer bloques sin mostrar AutoCAD.
        resultado = ObtenerBloquesCadDesdeObjectDbx(doc, cad, matriz);

        if (resultado != null && resultado.Count > 0)
            return resultado;

        // IMPORTANTE:
        // Se desactiva el fallback anterior por GeometryInstance de Revit para CREAR familias.
        // Ese fallback puede devolver el mismo Transform.Origin para varios bloques y provocar
        // que todas las familias se creen superpuestas en el origen del CAD.
        return new List<BloqueCadMYG>();
    }



    // =========================================================
    // FALLBACK: RECORRER GEOMETRÍA CAD DESDE REVIT
    // =========================================================

    private void RecorrerGeometriaCadParaBloques(
        Document doc,
        GeometryElement geo,
        Transform transformAcumulado,
        Dictionary<string, MapeoBloqueFamiliaMYG> matriz,
        List<BloqueCadMYG> resultado,
        int profundidad)
    {
        if (doc == null || geo == null || matriz == null || resultado == null)
            return;

        if (profundidad > 20)
            return;

        foreach (GeometryObject obj in geo)
        {
            if (obj == null)
                continue;

            GeometryInstance gi = obj as GeometryInstance;

            if (gi == null)
                continue;

            Transform transformActual = transformAcumulado;

            try
            {
                if (gi.Transform != null)
                    transformActual = transformAcumulado.Multiply(gi.Transform);
            }
            catch
            {
                transformActual = transformAcumulado;
            }

            string nombreBloque = ObtenerNombreBloqueDesdeGeometryInstance(doc, gi);

            if (!string.IsNullOrWhiteSpace(nombreBloque))
            {
                string clave = NormalizarClave(nombreBloque);

                if (matriz.ContainsKey(clave))
                {
                    BloqueCadMYG bloque = new BloqueCadMYG();
                    bloque.NombreBloque = matriz[clave].NombreBloque;
                    bloque.PuntoInsercion = ObtenerCentroGeometryInstanceCad(gi, transformActual);
                    bloque.Transform = transformActual;
                    bloque.FuenteLectura = "Fallback Revit Geometry - NO USAR PARA CREAR";

                    try
                    {
                        bloque.DireccionX = transformActual.BasisX.Normalize();
                    }
                    catch
                    {
                        bloque.DireccionX = XYZ.BasisX;
                    }

                    resultado.Add(bloque);
                }
            }

            GeometryElement geoInstancia = null;

            try
            {
                geoInstancia = gi.GetInstanceGeometry();
            }
            catch
            {
                geoInstancia = null;
            }

            if (geoInstancia != null)
            {
                RecorrerGeometriaCadParaBloques(
                    doc,
                    geoInstancia,
                    transformActual,
                    matriz,
                    resultado,
                    profundidad + 1);
            }

            GeometryElement geoSimbolo = null;

            try
            {
                geoSimbolo = gi.GetSymbolGeometry();
            }
            catch
            {
                geoSimbolo = null;
            }

            if (geoSimbolo != null)
            {
                string nombrePorCapa = ObtenerNombreProbableDesdeGraphicsStyle(doc, geoSimbolo);

                if (!string.IsNullOrWhiteSpace(nombrePorCapa))
                {
                    string claveCapa = NormalizarClave(nombrePorCapa);

                    if (matriz.ContainsKey(claveCapa))
                    {
                        bool yaExisteEnPunto = false;

                        foreach (BloqueCadMYG b in resultado)
                        {
                            if (b == null || b.PuntoInsercion == null)
                                continue;

                            if (NormalizarClave(b.NombreBloque) == claveCapa &&
                                b.PuntoInsercion.DistanceTo(transformActual.Origin) < 0.001)
                            {
                                yaExisteEnPunto = true;
                                break;
                            }
                        }

                        if (!yaExisteEnPunto)
                        {
                            BloqueCadMYG bloque = new BloqueCadMYG();
                            bloque.NombreBloque = matriz[claveCapa].NombreBloque;
                            bloque.PuntoInsercion = ObtenerCentroGeometryInstanceCad(gi, transformActual);
                            bloque.Transform = transformActual;
                            bloque.FuenteLectura = "Fallback Revit Geometry - NO USAR PARA CREAR";

                            try
                            {
                                bloque.DireccionX = transformActual.BasisX.Normalize();
                            }
                            catch
                            {
                                bloque.DireccionX = XYZ.BasisX;
                            }

                            resultado.Add(bloque);
                        }
                    }
                }
            }
        }
    }

    private XYZ ObtenerCentroGeometryInstanceCad(GeometryInstance gi, Transform transformAcumulado)
    {
        if (gi == null)
        {
            if (transformAcumulado != null)
                return transformAcumulado.Origin;

            return XYZ.Zero;
        }

        Transform tr = transformAcumulado;

        if (tr == null)
            tr = Transform.Identity;

        try
        {
            GeometryElement geoSimbolo = gi.GetSymbolGeometry();

            if (geoSimbolo != null)
            {
                BoundingBoxXYZ bb = geoSimbolo.GetBoundingBox();

                if (bb != null && bb.Min != null && bb.Max != null)
                {
                    XYZ centroLocal = new XYZ(
                        (bb.Min.X + bb.Max.X) / 2.0,
                        (bb.Min.Y + bb.Max.Y) / 2.0,
                        (bb.Min.Z + bb.Max.Z) / 2.0);

                    return tr.OfPoint(centroLocal);
                }
            }
        }
        catch
        {
        }

        try
        {
            return tr.Origin;
        }
        catch
        {
            return XYZ.Zero;
        }
    }

    private string ObtenerNombreBloqueDesdeGeometryInstance(Document doc, GeometryInstance gi)
    {
        if (gi == null)
            return "";

        List<string> candidatos = new List<string>();

        try
        {
            string texto = gi.ToString();

            if (!string.IsNullOrWhiteSpace(texto))
                candidatos.Add(texto);
        }
        catch
        {
        }

        try
        {
            object symbolObj = ObtenerValorPropiedadPorReflexion(gi, "Symbol");
            string nombre = ObtenerNombreDesdeObjeto(doc, symbolObj);

            if (!string.IsNullOrWhiteSpace(nombre))
                candidatos.Add(nombre);
        }
        catch
        {
        }

        try
        {
            object symbolIdObj = ObtenerValorPropiedadPorReflexion(gi, "SymbolId");
            ElementId id = symbolIdObj as ElementId;

            if (id != null && id != ElementId.InvalidElementId)
            {
                Element elem = doc.GetElement(id);

                if (elem != null && !string.IsNullOrWhiteSpace(elem.Name))
                    candidatos.Add(elem.Name);
            }
        }
        catch
        {
        }

        try
        {
            object idObj = ObtenerValorPropiedadPorReflexion(gi, "Id");
            ElementId id = idObj as ElementId;

            if (id != null && id != ElementId.InvalidElementId)
            {
                Element elem = doc.GetElement(id);

                if (elem != null && !string.IsNullOrWhiteSpace(elem.Name))
                    candidatos.Add(elem.Name);
            }
        }
        catch
        {
        }

        foreach (string candidato in candidatos)
        {
            string limpio = LimpiarNombreBloqueCad(candidato);

            if (!string.IsNullOrWhiteSpace(limpio))
                return limpio;
        }

        return "";
    }

    private object ObtenerValorPropiedadPorReflexion(object obj, string nombrePropiedad)
    {
        if (obj == null || string.IsNullOrWhiteSpace(nombrePropiedad))
            return null;

        try
        {
            PropertyInfo prop = obj.GetType().GetProperty(
                nombrePropiedad,
                BindingFlags.Public | BindingFlags.Instance);

            if (prop == null)
                return null;

            return prop.GetValue(obj, null);
        }
        catch
        {
            return null;
        }
    }

    private string ObtenerNombreDesdeObjeto(Document doc, object obj)
    {
        if (obj == null)
            return "";

        Element elem = obj as Element;

        if (elem != null)
        {
            try
            {
                return elem.Name;
            }
            catch
            {
                return "";
            }
        }

        ElementId id = obj as ElementId;

        if (id != null && doc != null && id != ElementId.InvalidElementId)
        {
            try
            {
                Element e = doc.GetElement(id);

                if (e != null)
                    return e.Name;
            }
            catch
            {
            }
        }

        try
        {
            object nombreObj = ObtenerValorPropiedadPorReflexion(obj, "Name");

            if (nombreObj != null)
                return nombreObj.ToString();
        }
        catch
        {
        }

        try
        {
            return obj.ToString();
        }
        catch
        {
            return "";
        }
    }

    private string ObtenerNombreProbableDesdeGraphicsStyle(Document doc, GeometryElement geo)
    {
        if (doc == null || geo == null)
            return "";

        foreach (GeometryObject obj in geo)
        {
            if (obj == null)
                continue;

            GeometryInstance gi = obj as GeometryInstance;

            if (gi != null)
            {
                GeometryElement interno = null;

                try
                {
                    interno = gi.GetInstanceGeometry();
                }
                catch
                {
                    interno = null;
                }

                string valorInterno = ObtenerNombreProbableDesdeGraphicsStyle(doc, interno);

                if (!string.IsNullOrWhiteSpace(valorInterno))
                    return valorInterno;
            }

            try
            {
                if (obj.GraphicsStyleId != null && obj.GraphicsStyleId != ElementId.InvalidElementId)
                {
                    GraphicsStyle gs = doc.GetElement(obj.GraphicsStyleId) as GraphicsStyle;

                    if (gs != null &&
                        gs.GraphicsStyleCategory != null &&
                        !string.IsNullOrWhiteSpace(gs.GraphicsStyleCategory.Name))
                    {
                        return gs.GraphicsStyleCategory.Name;
                    }
                }
            }
            catch
            {
            }
        }

        return "";
    }

    private string LimpiarNombreBloqueCad(string texto)
    {
        if (string.IsNullOrWhiteSpace(texto))
            return "";

        string limpio = texto.Trim();

        limpio = limpio.Replace("Autodesk.Revit.DB.", "");
        limpio = limpio.Replace("GeometryInstance", "");
        limpio = limpio.Replace("Instance", "");
        limpio = limpio.Replace("Symbol", "");
        limpio = limpio.Replace(":", " ");
        limpio = limpio.Replace(";", " ");
        limpio = limpio.Replace("{", " ");
        limpio = limpio.Replace("}", " ");
        limpio = limpio.Trim();

        return limpio;
    }

    // =========================================================
    // LECTURA REAL DEL DWG CON AUTOCAD COM
    // =========================================================

    private List<BloqueCadMYG> ObtenerBloquesCadDesdeAutoCadCom(
    Document doc,
    ImportInstance cad,
    Dictionary<string, MapeoBloqueFamiliaMYG> matriz)
    {
        List<BloqueCadMYG> resultado = new List<BloqueCadMYG>();

        if (doc == null || cad == null || matriz == null || matriz.Count == 0)
            return resultado;

        string rutaCad = ObtenerRutaCadDesdeImportInstance(doc, cad);

        if (string.IsNullOrWhiteSpace(rutaCad) || !File.Exists(rutaCad))
        {
            _ultimoDiagnosticoLecturaCad += "AutoCAD COM: no se pudo obtener una ruta DWG válida desde el CAD seleccionado.\r\n";
            return resultado;
        }

        object acadApp = null;
        object acadDoc = null;
        bool documentoAbiertoPorCodigo = false;

        try
        {
            acadApp = ObtenerAplicacionAutoCadCom();

            if (acadApp == null)
            {
                _ultimoDiagnosticoLecturaCad += "AutoCAD COM: no se encontró AutoCAD/Civil 3D abierto.\r\n";
                return resultado;
            }

            acadDoc = AbrirDocumentoAutoCad(acadApp, rutaCad, out documentoAbiertoPorCodigo);

            if (acadDoc == null)
            {
                _ultimoDiagnosticoLecturaCad += "AutoCAD COM: AutoCAD está abierto, pero no se encontró abierto el mismo DWG vinculado/importado.\r\n";
                return resultado;
            }

            resultado = LeerBloquesDesdeDocumentoCadCom(acadDoc, cad, matriz, "AutoCAD COM - Propiedades");

            if (resultado == null)
                resultado = new List<BloqueCadMYG>();

            // IMPORTANTE V8:
            // En algunos equipos, AutoCAD normal puede devolver InsertionPoint repetido
            // aunque Civil 3D sí lea bien el mismo DWG. Cuando eso ocurre, se intenta
            // una segunda lectura ejecutando AutoLISP en el DWG abierto, usando el dato
            // DXF grupo 10 del INSERT, que suele ser más estable que la propiedad COM.
            if (resultado.Count == 0 || PuntosBloquesSospechosos(resultado))
            {
                if (resultado.Count == 0)
                {
                    _ultimoDiagnosticoLecturaCad +=
                        "AutoCAD COM: no encontró bloques coincidentes por propiedades. Se intentará lectura AutoLISP/DXF.\r\n";
                }
                else
                {
                    _ultimoDiagnosticoLecturaCad +=
                        "AutoCAD COM: detectó puntos repetidos/sospechosos. Se intentará lectura AutoLISP/DXF para evitar superposición.\r\n";
                }

                List<BloqueCadMYG> resultadoLisp =
                    LeerBloquesDesdeAutoCadConLispCsv(acadDoc, cad, matriz);

                if (resultadoLisp != null && resultadoLisp.Count > 0 && !PuntosBloquesSospechosos(resultadoLisp))
                {
                    resultado = resultadoLisp;
                    _ultimoDiagnosticoLecturaCad +=
                        "AutoLISP/DXF: lectura aceptada. Se usarán estos puntos para crear las familias.\r\n";
                }
                else if (resultadoLisp != null && resultadoLisp.Count > 0)
                {
                    _ultimoDiagnosticoLecturaCad +=
                        "AutoLISP/DXF: también devolvió puntos sospechosos. Se mantiene la validación final para cancelar y evitar superposición.\r\n";
                    resultado = resultadoLisp;
                }
                else
                {
                    _ultimoDiagnosticoLecturaCad +=
                        "AutoLISP/DXF: no devolvió bloques coincidentes.\r\n";
                }
            }

            if (resultado.Count == 0)
                _ultimoDiagnosticoLecturaCad += "AutoCAD COM: el DWG se leyó, pero no hubo BlockReference que coincida con el Excel.\r\n";
        }
        catch (Exception ex)
        {
            _ultimoDiagnosticoLecturaCad += "AutoCAD COM: error al leer bloques. " + ex.Message + "\r\n";
        }
        finally
        {
            if (documentoAbiertoPorCodigo && acadDoc != null)
            {
                try
                {
                    InvocarMetodoCom(acadDoc, "Close", new object[] { false });
                }
                catch
                {
                }
            }
        }

        return resultado;
    }

    private List<BloqueCadMYG> ObtenerBloquesCadDesdeObjectDbx(
        Document doc,
        ImportInstance cad,
        Dictionary<string, MapeoBloqueFamiliaMYG> matriz)
    {
        List<BloqueCadMYG> resultado = new List<BloqueCadMYG>();

        if (doc == null || cad == null || matriz == null || matriz.Count == 0)
            return resultado;

        string rutaCad = ObtenerRutaCadDesdeImportInstance(doc, cad);

        if (string.IsNullOrWhiteSpace(rutaCad) || !File.Exists(rutaCad))
        {
            _ultimoDiagnosticoLecturaCad += "ObjectDBX: no se pudo obtener una ruta DWG válida desde el CAD seleccionado.\r\n";
            return resultado;
        }

        object dbxDoc = null;

        try
        {
            dbxDoc = CrearDocumentoObjectDbx();

            if (dbxDoc == null)
            {
                _ultimoDiagnosticoLecturaCad += "ObjectDBX: no se pudo crear AxDbDocument. Verifique que AutoCAD/Civil 3D esté instalado en esa laptop.\r\n";
                return resultado;
            }

            object abierto = InvocarMetodoCom(dbxDoc, "Open", new object[] { rutaCad });

            // Algunas versiones devuelven null aunque abren correctamente, por eso no se valida "abierto".
            resultado = LeerBloquesDesdeDocumentoCadCom(dbxDoc, cad, matriz, "ObjectDBX");

            if (resultado == null)
                resultado = new List<BloqueCadMYG>();

            if (resultado.Count == 0)
                _ultimoDiagnosticoLecturaCad += "ObjectDBX: el DWG se abrió, pero no hubo BlockReference que coincida con el Excel.\r\n";
        }
        catch (Exception ex)
        {
            _ultimoDiagnosticoLecturaCad += "ObjectDBX: error al abrir/leer el DWG. " + ex.Message + "\r\n";
        }
        finally
        {
            if (dbxDoc != null)
            {
                try
                {
                    InvocarMetodoCom(dbxDoc, "Close", null);
                }
                catch
                {
                }

                try
                {
                    if (Marshal.IsComObject(dbxDoc))
                        Marshal.FinalReleaseComObject(dbxDoc);
                }
                catch
                {
                }
            }
        }

        return resultado;
    }

    private object CrearDocumentoObjectDbx()
    {
        string[] progIds = new string[]
        {
            "ObjectDBX.AxDbDocument.25",
            "ObjectDBX.AxDbDocument.24.3",
            "ObjectDBX.AxDbDocument.24.2",
            "ObjectDBX.AxDbDocument.24.1",
            "ObjectDBX.AxDbDocument.24",
            "ObjectDBX.AxDbDocument.23",
            "ObjectDBX.AxDbDocument.22",
            "ObjectDBX.AxDbDocument"
        };

        foreach (string progId in progIds)
        {
            try
            {
                Type tipo = Type.GetTypeFromProgID(progId);

                if (tipo == null)
                    continue;

                object obj = Activator.CreateInstance(tipo);

                if (obj != null)
                    return obj;
            }
            catch
            {
            }
        }

        return null;
    }

    private List<BloqueCadMYG> LeerBloquesDesdeDocumentoCadCom(
        object documentoCad,
        ImportInstance cad,
        Dictionary<string, MapeoBloqueFamiliaMYG> matriz,
        string fuenteLectura)
    {
        List<BloqueCadMYG> resultado = new List<BloqueCadMYG>();

        if (documentoCad == null || cad == null || matriz == null || matriz.Count == 0)
            return resultado;

        double factorUnidadCadAPies = ObtenerFactorUnidadCadAPies(documentoCad);

        Transform transformCad = Transform.Identity;

        try
        {
            transformCad = cad.GetTransform();
        }
        catch
        {
            transformCad = Transform.Identity;
        }

        object modelSpace = ObtenerPropiedadCom(documentoCad, "ModelSpace");

        if (modelSpace == null)
            return resultado;

        foreach (object entidad in (System.Collections.IEnumerable)modelSpace)
        {
            if (entidad == null)
                continue;

            string objectName = ObtenerTextoPropiedadCom(entidad, "ObjectName");

            if (string.IsNullOrWhiteSpace(objectName))
                objectName = ObtenerTextoPropiedadCom(entidad, "EntityName");

            if (string.IsNullOrWhiteSpace(objectName))
                continue;

            string objectNameNorm = NormalizarClave(objectName);

            if (!objectNameNorm.Contains("BLOCKREFERENCE") &&
                !objectNameNorm.Contains("INSERT") &&
                !objectNameNorm.Contains("MINSERT"))
            {
                continue;
            }

            string nombreBloqueReal = ObtenerTextoPropiedadCom(entidad, "EffectiveName");

            if (string.IsNullOrWhiteSpace(nombreBloqueReal))
                nombreBloqueReal = ObtenerTextoPropiedadCom(entidad, "Name");

            if (string.IsNullOrWhiteSpace(nombreBloqueReal))
                continue;

            string claveBloque = NormalizarClave(nombreBloqueReal);

            if (!matriz.ContainsKey(claveBloque))
                continue;

            double[] puntoCad = ObtenerPuntoPropiedadCom(entidad, "InsertionPoint");

            if (puntoCad == null || puntoCad.Length < 2)
                continue;

            // IMPORTANTE V7:
            // Se usa SIEMPRE el InsertionPoint real del BlockReference.
            // No se reemplaza por el centro del BoundingBox, porque en AutoCAD normal
            // algunos DWG/Civil Objects/proxies pueden devolver BoundingBox incorrecto
            // y provocar que todos los bloques caigan en un solo punto.
            double xCad = puntoCad[0];
            double yCad = puntoCad[1];
            double zCad = 0.0;

            if (puntoCad.Length >= 3)
                zCad = puntoCad[2];

            double x = xCad * factorUnidadCadAPies;
            double y = yCad * factorUnidadCadAPies;
            double z = zCad * factorUnidadCadAPies;

            XYZ puntoEnSimboloCad = new XYZ(x, y, z);
            XYZ puntoEnRevit = puntoEnSimboloCad;

            try
            {
                puntoEnRevit = transformCad.OfPoint(puntoEnSimboloCad);
            }
            catch
            {
                puntoEnRevit = puntoEnSimboloCad;
            }

            double rotacion = ObtenerDoublePropiedadCom(entidad, "Rotation", 0.0);

            XYZ direccionCad = new XYZ(Math.Cos(rotacion), Math.Sin(rotacion), 0.0);
            XYZ direccionRevit = direccionCad;

            try
            {
                direccionRevit = transformCad.OfVector(direccionCad);
            }
            catch
            {
                direccionRevit = direccionCad;
            }

            try
            {
                if (direccionRevit.GetLength() > 0.000001)
                    direccionRevit = direccionRevit.Normalize();
                else
                    direccionRevit = XYZ.BasisX;
            }
            catch
            {
                direccionRevit = XYZ.BasisX;
            }

            BloqueCadMYG bloque = new BloqueCadMYG();
            bloque.NombreBloque = matriz[claveBloque].NombreBloque;
            bloque.PuntoInsercion = puntoEnRevit;
            bloque.DireccionX = direccionRevit;
            bloque.Transform = transformCad;
            bloque.FuenteLectura = fuenteLectura ?? "CAD COM";

            resultado.Add(bloque);
        }

        return resultado;
    }



    // =========================================================
    // LECTURA ALTERNATIVA AUTOCAD NORMAL: AUTOLISP / DXF GRUPO 10
    // =========================================================

    private List<BloqueCadMYG> LeerBloquesDesdeAutoCadConLispCsv(
        object acadDoc,
        ImportInstance cad,
        Dictionary<string, MapeoBloqueFamiliaMYG> matriz)
    {
        List<BloqueCadMYG> resultado = new List<BloqueCadMYG>();

        if (acadDoc == null || cad == null || matriz == null || matriz.Count == 0)
            return resultado;

        string rutaLisp = "";
        string rutaCsv = "";
        object valorSecureLoad = null;
        object valorCmdEcho = null;
        bool cambioSecureLoad = false;
        bool cambioCmdEcho = false;

        try
        {
            rutaLisp = CrearArchivoLispExportadorBloques54();

            if (string.IsNullOrWhiteSpace(rutaLisp) || !File.Exists(rutaLisp))
            {
                _ultimoDiagnosticoLecturaCad += "AutoLISP/DXF: no se pudo crear el archivo LSP temporal.\r\n";
                return resultado;
            }

            rutaCsv = Path.Combine(
                Path.GetTempPath(),
                "MYG_BloquesCAD54_" + Guid.NewGuid().ToString("N") + ".txt");

            try
            {
                if (File.Exists(rutaCsv))
                    File.Delete(rutaCsv);
            }
            catch
            {
            }

            try
            {
                valorSecureLoad = InvocarMetodoCom(acadDoc, "GetVariable", new object[] { "SECURELOAD" });
                InvocarMetodoCom(acadDoc, "SetVariable", new object[] { "SECURELOAD", 0 });
                cambioSecureLoad = true;
            }
            catch
            {
            }

            try
            {
                valorCmdEcho = InvocarMetodoCom(acadDoc, "GetVariable", new object[] { "CMDECHO" });
                InvocarMetodoCom(acadDoc, "SetVariable", new object[] { "CMDECHO", 0 });
                cambioCmdEcho = true;
            }
            catch
            {
            }

            try
            {
                InvocarMetodoCom(acadDoc, "Activate", null);
            }
            catch
            {
            }

            string comando =
                "(load \"" + RutaParaAutoLisp(rutaLisp) + "\")\n" +
                "(MYG_EXPORT_BLOCKS54 \"" + RutaParaAutoLisp(rutaCsv) + "\")\n";

            object envio = InvocarMetodoCom(acadDoc, "SendCommand", new object[] { comando });

            bool archivoGenerado = false;

            for (int i = 0; i < 150; i++)
            {
                try
                {
                    if (File.Exists(rutaCsv))
                    {
                        archivoGenerado = true;

                        FileInfo fi = new FileInfo(rutaCsv);

                        // Si ya tiene contenido, esperamos un poco más y salimos.
                        if (fi.Length > 0)
                        {
                            System.Threading.Thread.Sleep(150);
                            break;
                        }
                    }
                }
                catch
                {
                }

                System.Threading.Thread.Sleep(100);
            }

            if (!archivoGenerado || !File.Exists(rutaCsv))
            {
                _ultimoDiagnosticoLecturaCad +=
                    "AutoLISP/DXF: AutoCAD no generó el archivo temporal. " +
                    "Verifique que AutoLISP esté permitido y que AutoCAD no esté esperando confirmación en la línea de comandos.\r\n";

                return resultado;
            }

            resultado = LeerBloquesDesdeCsvLispExportado54(
                rutaCsv,
                cad,
                acadDoc,
                matriz);

            if (resultado == null)
                resultado = new List<BloqueCadMYG>();

            _ultimoDiagnosticoLecturaCad +=
                "AutoLISP/DXF: bloques coincidentes leídos = " + resultado.Count.ToString() + ".\r\n";
        }
        catch (Exception ex)
        {
            _ultimoDiagnosticoLecturaCad +=
                "AutoLISP/DXF: error al exportar/leer bloques desde AutoCAD. " + ex.Message + "\r\n";
        }
        finally
        {
            if (cambioSecureLoad && valorSecureLoad != null)
            {
                try
                {
                    InvocarMetodoCom(acadDoc, "SetVariable", new object[] { "SECURELOAD", valorSecureLoad });
                }
                catch
                {
                }
            }

            if (cambioCmdEcho && valorCmdEcho != null)
            {
                try
                {
                    InvocarMetodoCom(acadDoc, "SetVariable", new object[] { "CMDECHO", valorCmdEcho });
                }
                catch
                {
                }
            }

            try
            {
                if (!string.IsNullOrWhiteSpace(rutaLisp) && File.Exists(rutaLisp))
                    File.Delete(rutaLisp);
            }
            catch
            {
            }

            try
            {
                if (!string.IsNullOrWhiteSpace(rutaCsv) && File.Exists(rutaCsv))
                    File.Delete(rutaCsv);
            }
            catch
            {
            }
        }

        return resultado;
    }

    private string CrearArchivoLispExportadorBloques54()
    {
        string ruta = Path.Combine(
            Path.GetTempPath(),
            "MYG_ExportBlocks54_" + Guid.NewGuid().ToString("N") + ".lsp");

        string lisp =
@"(vl-load-com)
(defun MYG54_N2S (v)
  (if v
    (rtos v 2 16)
    ""0""
  )
)
(defun MYG54_CLEAN (s)
  (if (null s)
    (setq s """")
  )
  (setq s (vl-princ-to-string s))
  (setq s (vl-string-translate ""|"" ""_"" s))
  s
)
(defun MYG54_EFFNAME (obj ed / nm)
  (setq nm """")
  (if (vlax-property-available-p obj 'EffectiveName)
    (setq nm (vla-get-EffectiveName obj))
  )
  (if (= nm """")
    (if (vlax-property-available-p obj 'Name)
      (setq nm (vla-get-Name obj))
    )
  )
  (if (= nm """")
    (setq nm (cdr (assoc 2 ed)))
  )
  nm
)
(defun MYG_EXPORT_BLOCKS54 (ruta / doc ms f obj on en ed nm p rot z)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setq ms (vla-get-ModelSpace doc))
  (setq f (open ruta ""w""))
  (if f
    (progn
      (vlax-for obj ms
        (setq on (strcase (vla-get-ObjectName obj)))
        (if (or (wcmatch on ""*BLOCKREFERENCE*"") (wcmatch on ""*MINSERT*"") (wcmatch on ""*INSERT*""))
          (progn
            (setq en (vlax-vla-object->ename obj))
            (setq ed (entget en))
            (setq nm (MYG54_EFFNAME obj ed))
            (setq p (cdr (assoc 10 ed)))
            (setq rot (cdr (assoc 50 ed)))
            (if (null rot)
              (setq rot 0.0)
            )
            (if (and nm p)
              (progn
                (setq z 0.0)
                (if (caddr p)
                  (setq z (caddr p))
                )
                (write-line
                  (strcat
                    (MYG54_CLEAN nm) ""|""
                    (MYG54_N2S (car p)) ""|""
                    (MYG54_N2S (cadr p)) ""|""
                    (MYG54_N2S z) ""|""
                    (MYG54_N2S rot)
                  )
                  f
                )
              )
            )
          )
        )
      )
      (close f)
    )
  )
  (princ)
)
(princ)
";

        File.WriteAllText(ruta, lisp, System.Text.Encoding.ASCII);

        return ruta;
    }

    private List<BloqueCadMYG> LeerBloquesDesdeCsvLispExportado54(
        string rutaCsv,
        ImportInstance cad,
        object documentoCad,
        Dictionary<string, MapeoBloqueFamiliaMYG> matriz)
    {
        List<BloqueCadMYG> resultado = new List<BloqueCadMYG>();

        if (string.IsNullOrWhiteSpace(rutaCsv) || !File.Exists(rutaCsv))
            return resultado;

        if (cad == null || documentoCad == null || matriz == null || matriz.Count == 0)
            return resultado;

        double factorUnidadCadAPies = ObtenerFactorUnidadCadAPies(documentoCad);

        Transform transformCad = Transform.Identity;

        try
        {
            transformCad = cad.GetTransform();
        }
        catch
        {
            transformCad = Transform.Identity;
        }

        string[] lineas = null;

        try
        {
            lineas = File.ReadAllLines(rutaCsv);
        }
        catch
        {
            lineas = null;
        }

        if (lineas == null || lineas.Length == 0)
            return resultado;

        foreach (string linea in lineas)
        {
            if (string.IsNullOrWhiteSpace(linea))
                continue;

            string[] partes = linea.Split('|');

            if (partes == null || partes.Length < 5)
                continue;

            string nombreBloqueReal = partes[0];

            if (string.IsNullOrWhiteSpace(nombreBloqueReal))
                continue;

            string claveBloque = NormalizarClave(nombreBloqueReal);

            if (!matriz.ContainsKey(claveBloque))
                continue;

            double xCad = ConvertirTextoDoubleFlexible(partes[1], 0.0);
            double yCad = ConvertirTextoDoubleFlexible(partes[2], 0.0);
            double zCad = ConvertirTextoDoubleFlexible(partes[3], 0.0);
            double rotacion = ConvertirTextoDoubleFlexible(partes[4], 0.0);

            double x = xCad * factorUnidadCadAPies;
            double y = yCad * factorUnidadCadAPies;
            double z = zCad * factorUnidadCadAPies;

            XYZ puntoEnSimboloCad = new XYZ(x, y, z);
            XYZ puntoEnRevit = puntoEnSimboloCad;

            try
            {
                puntoEnRevit = transformCad.OfPoint(puntoEnSimboloCad);
            }
            catch
            {
                puntoEnRevit = puntoEnSimboloCad;
            }

            XYZ direccionCad = new XYZ(Math.Cos(rotacion), Math.Sin(rotacion), 0.0);
            XYZ direccionRevit = direccionCad;

            try
            {
                direccionRevit = transformCad.OfVector(direccionCad);
            }
            catch
            {
                direccionRevit = direccionCad;
            }

            try
            {
                if (direccionRevit.GetLength() > 0.000001)
                    direccionRevit = direccionRevit.Normalize();
                else
                    direccionRevit = XYZ.BasisX;
            }
            catch
            {
                direccionRevit = XYZ.BasisX;
            }

            BloqueCadMYG bloque = new BloqueCadMYG();
            bloque.NombreBloque = matriz[claveBloque].NombreBloque;
            bloque.PuntoInsercion = puntoEnRevit;
            bloque.DireccionX = direccionRevit;
            bloque.Transform = transformCad;
            bloque.FuenteLectura = "AutoLISP/DXF grupo 10";

            resultado.Add(bloque);
        }

        return resultado;
    }

    private string RutaParaAutoLisp(string ruta)
    {
        if (string.IsNullOrWhiteSpace(ruta))
            return "";

        string r = ruta.Replace("\\", "/");
        r = r.Replace("\"", "");

        return r;
    }

    private double ConvertirTextoDoubleFlexible(string texto, double valorDefecto)
    {
        if (string.IsNullOrWhiteSpace(texto))
            return valorDefecto;

        double valor = valorDefecto;

        if (double.TryParse(
            texto.Trim(),
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture,
            out valor))
        {
            return valor;
        }

        if (double.TryParse(texto.Trim(), out valor))
            return valor;

        return valorDefecto;
    }


    private string ObtenerRutaCadDesdeImportInstance(Document doc, ImportInstance cad)
    {
        if (doc == null || cad == null)
            return "";

        try
        {
            ElementId typeId = cad.GetTypeId();

            if (typeId == null || typeId == ElementId.InvalidElementId)
                return "";

            ExternalFileReference referencia = ExternalFileUtils.GetExternalFileReference(doc, typeId);

            if (referencia == null)
                return "";

            ModelPath path = referencia.GetAbsolutePath();

            if (path == null)
                return "";

            string ruta = ModelPathUtils.ConvertModelPathToUserVisiblePath(path);

            if (!string.IsNullOrWhiteSpace(ruta) && File.Exists(ruta))
                return ruta;
        }
        catch
        {
        }

        return "";
    }

    private object ObtenerAplicacionAutoCadCom()
    {
        // IMPORTANTE V3:
        // NO se usa Activator.CreateInstance porque eso intenta abrir AutoCAD/Civil 3D
        // desde Revit y puede provocar el error:
        // "FATAL ERROR: ASC initialization failed".
        // Esta versión solo se conecta a un AutoCAD/Civil 3D que ya esté abierto.

        string[] progIds = new string[]
        {
            "AutoCAD.Application",
            "AutoCAD.Application.25",
            "AutoCAD.Application.24.3",
            "AutoCAD.Application.24.2",
            "AutoCAD.Application.24.1",
            "AutoCAD.Application.24"
        };

        foreach (string progId in progIds)
        {
            object app = ObtenerObjetoComActivo(progId);

            if (app != null)
                return app;
        }

        return null;
    }

    private object ObtenerObjetoComActivo(string progId)
    {
        if (string.IsNullOrWhiteSpace(progId))
            return null;

        try
        {
            Guid clsid;
            int hr = CLSIDFromProgID(progId, out clsid);

            if (hr != 0 || clsid == Guid.Empty)
                return null;

            object obj;
            GetActiveObject(ref clsid, IntPtr.Zero, out obj);

            return obj;
        }
        catch
        {
            return null;
        }
    }

    [DllImport("ole32.dll", CharSet = CharSet.Unicode)]
    private static extern int CLSIDFromProgID(string progId, out Guid clsid);

    [DllImport("oleaut32.dll", PreserveSig = false)]
    private static extern void GetActiveObject(
        ref Guid rclsid,
        IntPtr pvReserved,
        [MarshalAs(UnmanagedType.IUnknown)] out object ppunk);

    private object AbrirDocumentoAutoCad(
        object acadApp,
        string rutaCad,
        out bool documentoAbiertoPorCodigo)
    {
        // IMPORTANTE V3:
        // Este método ya NO abre archivos DWG desde Revit.
        // Solo busca el DWG si ya está abierto en AutoCAD/Civil 3D.
        // Así evitamos que Revit quede congelado o que AutoCAD muestre
        // "ASC initialization failed" al intentar arrancar en segundo plano.

        documentoAbiertoPorCodigo = false;

        if (acadApp == null || string.IsNullOrWhiteSpace(rutaCad))
            return null;

        object documentos = ObtenerPropiedadCom(acadApp, "Documents");

        if (documentos == null)
            return null;

        try
        {
            foreach (object docCad in (System.Collections.IEnumerable)documentos)
            {
                if (docCad == null)
                    continue;

                string nombreCompleto = ObtenerTextoPropiedadCom(docCad, "FullName");

                if (string.IsNullOrWhiteSpace(nombreCompleto))
                    continue;

                if (RutasCadCoinciden(nombreCompleto, rutaCad))
                    return docCad;
            }
        }
        catch
        {
        }

        try
        {
            object activo = ObtenerPropiedadCom(acadApp, "ActiveDocument");

            if (activo != null)
            {
                string nombreCompletoActivo = ObtenerTextoPropiedadCom(activo, "FullName");

                if (RutasCadCoinciden(nombreCompletoActivo, rutaCad))
                    return activo;
            }
        }
        catch
        {
        }

        return null;
    }

    private bool RutasCadCoinciden(string rutaA, string rutaB)
    {
        if (string.IsNullOrWhiteSpace(rutaA) || string.IsNullOrWhiteSpace(rutaB))
            return false;

        try
        {
            string a = Path.GetFullPath(rutaA).Trim();
            string b = Path.GetFullPath(rutaB).Trim();

            return string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
        }
        catch
        {
        }

        // No comparar solo por nombre de archivo.
        // Si hay dos DWG con el mismo nombre en rutas distintas, se puede leer el archivo incorrecto
        // y terminar creando familias en coordenadas equivocadas.
        return false;
    }


    private double ObtenerFactorUnidadCadAPies(object acadDoc)
    {
        // INSUNITS AutoCAD:
        // 0 Unitless, 1 Inches, 2 Feet, 3 Miles, 4 Millimeters, 5 Centimeters,
        // 6 Meters, 7 Kilometers, 8 Microinches, 9 Mils, 10 Yards, etc.
        int insunits = 0;

        try
        {
            object valor = InvocarMetodoCom(acadDoc, "GetVariable", new object[] { "INSUNITS" });

            if (valor != null)
                insunits = Convert.ToInt32(valor);
        }
        catch
        {
            insunits = 0;
        }

        switch (insunits)
        {
            case 1: return 1.0 / 12.0;              // inches -> feet
            case 2: return 1.0;                     // feet -> feet
            case 4: return 0.003280839895013123;    // mm -> feet
            case 5: return 0.03280839895013123;     // cm -> feet
            case 6: return 3.280839895013123;       // m -> feet
            case 7: return 3280.839895013123;       // km -> feet
            case 10: return 3.0;                    // yards -> feet
            default: return 1.0;                    // unitless: se respeta el valor tal como está
        }
    }

    private object ObtenerPropiedadCom(object obj, string nombrePropiedad)
    {
        if (obj == null || string.IsNullOrWhiteSpace(nombrePropiedad))
            return null;

        try
        {
            return obj.GetType().InvokeMember(
                nombrePropiedad,
                BindingFlags.GetProperty,
                null,
                obj,
                null);
        }
        catch
        {
            return null;
        }
    }

    private void AsignarPropiedadCom(object obj, string nombrePropiedad, object valor)
    {
        if (obj == null || string.IsNullOrWhiteSpace(nombrePropiedad))
            return;

        try
        {
            obj.GetType().InvokeMember(
                nombrePropiedad,
                BindingFlags.SetProperty,
                null,
                obj,
                new object[] { valor });
        }
        catch
        {
        }
    }

    private object InvocarMetodoCom(object obj, string nombreMetodo, object[] argumentos)
    {
        if (obj == null || string.IsNullOrWhiteSpace(nombreMetodo))
            return null;

        try
        {
            return obj.GetType().InvokeMember(
                nombreMetodo,
                BindingFlags.InvokeMethod,
                null,
                obj,
                argumentos);
        }
        catch
        {
            return null;
        }
    }

    private string ObtenerTextoPropiedadCom(object obj, string nombrePropiedad)
    {
        object valor = ObtenerPropiedadCom(obj, nombrePropiedad);

        if (valor == null)
            return "";

        try
        {
            return valor.ToString().Trim();
        }
        catch
        {
            return "";
        }
    }

    private double ObtenerDoublePropiedadCom(object obj, string nombrePropiedad, double valorDefecto)
    {
        object valor = ObtenerPropiedadCom(obj, nombrePropiedad);

        if (valor == null)
            return valorDefecto;

        try
        {
            return Convert.ToDouble(valor, System.Globalization.CultureInfo.InvariantCulture);
        }
        catch
        {
            try
            {
                return Convert.ToDouble(valor);
            }
            catch
            {
                return valorDefecto;
            }
        }
    }

    private double[] ObtenerPuntoPropiedadCom(object obj, string nombrePropiedad)
    {
        object valor = ObtenerPropiedadCom(obj, nombrePropiedad);

        if (valor == null)
            return null;

        try
        {
            Array arr = valor as Array;

            if (arr != null && arr.Length >= 2)
            {
                List<double> puntos = new List<double>();

                foreach (object item in arr)
                    puntos.Add(Convert.ToDouble(item, System.Globalization.CultureInfo.InvariantCulture));

                return puntos.ToArray();
            }
        }
        catch
        {
        }

        try
        {
            object xObj = valor.GetType().InvokeMember("0", BindingFlags.GetProperty, null, valor, null);
            object yObj = valor.GetType().InvokeMember("1", BindingFlags.GetProperty, null, valor, null);
            object zObj = valor.GetType().InvokeMember("2", BindingFlags.GetProperty, null, valor, null);

            double x = Convert.ToDouble(xObj, System.Globalization.CultureInfo.InvariantCulture);
            double y = Convert.ToDouble(yObj, System.Globalization.CultureInfo.InvariantCulture);
            double z = Convert.ToDouble(zObj, System.Globalization.CultureInfo.InvariantCulture);

            return new double[] { x, y, z };
        }
        catch
        {
        }

        return null;
    }

    private double[] ObtenerCentroBoundingBoxEntidadCom(object entidad)
    {
        if (entidad == null)
            return null;

        double[] min = null;
        double[] max = null;

        // IMPORTANTE V6:
        // El InsertionPoint del bloque CAD puede estar en una esquina o en un costado.
        // Para que la familia caiga en el cruce de sus planos Center, primero buscamos
        // el centro real del BlockReference usando su BoundingBox. Si AutoCAD no entrega
        // el BoundingBox del bloque, se explota temporalmente una copia/resultado del bloque,
        // se calcula el BoundingBox combinado y luego se eliminan esos objetos temporales.
        bool tieneBoundingBox = ObtenerBoundingBoxEntidadCom(entidad, out min, out max);

        if (!tieneBoundingBox)
            tieneBoundingBox = ObtenerBoundingBoxEntidadComPorExplosionTemporal(entidad, out min, out max);

        if (!tieneBoundingBox)
            return null;

        if (min == null || max == null || min.Length < 2 || max.Length < 2)
            return null;

        double x = (min[0] + max[0]) / 2.0;
        double y = (min[1] + max[1]) / 2.0;
        double z = 0.0;

        if (min.Length >= 3 && max.Length >= 3)
            z = (min[2] + max[2]) / 2.0;

        return new double[] { x, y, z };
    }

    private bool ObtenerBoundingBoxEntidadCom(object entidad, out double[] min, out double[] max)
    {
        min = null;
        max = null;

        if (entidad == null)
            return false;

        // Intento 01: llamada COM normal con argumentos ref/out.
        try
        {
            object[] argumentos = new object[] { null, null };

            entidad.GetType().InvokeMember(
                "GetBoundingBox",
                BindingFlags.InvokeMethod,
                null,
                entidad,
                argumentos);

            min = ConvertirVariantPuntoADoubleArray(argumentos[0]);
            max = ConvertirVariantPuntoADoubleArray(argumentos[1]);

            if (BoundingBoxComValido(min, max))
                return true;
        }
        catch
        {
        }

        // Intento 02: llamada COM con ParameterModifier. En algunas versiones de AutoCAD
        // la reflexión necesita marcar ambos argumentos como salida.
        try
        {
            object[] argumentos = new object[] { null, null };

            ParameterModifier modificador = new ParameterModifier(2);
            modificador[0] = true;
            modificador[1] = true;

            entidad.GetType().InvokeMember(
                "GetBoundingBox",
                BindingFlags.InvokeMethod,
                null,
                entidad,
                argumentos,
                new ParameterModifier[] { modificador },
                null,
                null);

            min = ConvertirVariantPuntoADoubleArray(argumentos[0]);
            max = ConvertirVariantPuntoADoubleArray(argumentos[1]);

            if (BoundingBoxComValido(min, max))
                return true;
        }
        catch
        {
        }

        return false;
    }

    private bool ObtenerBoundingBoxEntidadComPorExplosionTemporal(object entidad, out double[] min, out double[] max)
    {
        min = null;
        max = null;

        if (entidad == null)
            return false;

        object resultadoExplosion = null;
        List<object> objetosTemporales = new List<object>();

        try
        {
            resultadoExplosion = InvocarMetodoCom(entidad, "Explode", null);

            if (resultadoExplosion == null)
                return false;

            Array arr = resultadoExplosion as Array;

            if (arr != null)
            {
                foreach (object obj in arr)
                {
                    if (obj != null)
                        objetosTemporales.Add(obj);
                }
            }
            else
            {
                System.Collections.IEnumerable enumerable = resultadoExplosion as System.Collections.IEnumerable;

                if (enumerable != null)
                {
                    foreach (object obj in enumerable)
                    {
                        if (obj != null)
                            objetosTemporales.Add(obj);
                    }
                }
                else
                {
                    objetosTemporales.Add(resultadoExplosion);
                }
            }

            if (objetosTemporales.Count == 0)
                return false;

            bool hayBb = false;
            double minX = double.MaxValue;
            double minY = double.MaxValue;
            double minZ = double.MaxValue;
            double maxX = double.MinValue;
            double maxY = double.MinValue;
            double maxZ = double.MinValue;

            foreach (object objTemp in objetosTemporales)
            {
                if (objTemp == null)
                    continue;

                double[] minObj = null;
                double[] maxObj = null;

                if (!ObtenerBoundingBoxEntidadCom(objTemp, out minObj, out maxObj))
                    continue;

                if (!BoundingBoxComValido(minObj, maxObj))
                    continue;

                hayBb = true;

                minX = Math.Min(minX, minObj[0]);
                minY = Math.Min(minY, minObj[1]);
                maxX = Math.Max(maxX, maxObj[0]);
                maxY = Math.Max(maxY, maxObj[1]);

                double minObjZ = 0.0;
                double maxObjZ = 0.0;

                if (minObj.Length >= 3)
                    minObjZ = minObj[2];

                if (maxObj.Length >= 3)
                    maxObjZ = maxObj[2];

                minZ = Math.Min(minZ, minObjZ);
                maxZ = Math.Max(maxZ, maxObjZ);
            }

            if (!hayBb)
                return false;

            min = new double[] { minX, minY, minZ };
            max = new double[] { maxX, maxY, maxZ };

            return true;
        }
        catch
        {
            return false;
        }
        finally
        {
            // AutoCAD COM crea entidades reales al explotar. Se eliminan de inmediato
            // para no modificar visualmente el DWG abierto.
            foreach (object objTemp in objetosTemporales)
            {
                if (objTemp == null)
                    continue;

                try
                {
                    InvocarMetodoCom(objTemp, "Delete", null);
                }
                catch
                {
                }
            }
        }
    }

    private bool BoundingBoxComValido(double[] min, double[] max)
    {
        if (min == null || max == null)
            return false;

        if (min.Length < 2 || max.Length < 2)
            return false;

        try
        {
            if (double.IsNaN(min[0]) || double.IsNaN(min[1]) ||
                double.IsNaN(max[0]) || double.IsNaN(max[1]))
            {
                return false;
            }

            if (double.IsInfinity(min[0]) || double.IsInfinity(min[1]) ||
                double.IsInfinity(max[0]) || double.IsInfinity(max[1]))
            {
                return false;
            }

            if (Math.Abs(max[0] - min[0]) < 0.000000001 &&
                Math.Abs(max[1] - min[1]) < 0.000000001)
            {
                return false;
            }
        }
        catch
        {
            return false;
        }

        return true;
    }

    private double[] ConvertirVariantPuntoADoubleArray(object valor)
    {
        if (valor == null)
            return null;

        try
        {
            Array arr = valor as Array;

            if (arr != null && arr.Length >= 2)
            {
                List<double> puntos = new List<double>();

                foreach (object item in arr)
                    puntos.Add(Convert.ToDouble(item, System.Globalization.CultureInfo.InvariantCulture));

                return puntos.ToArray();
            }
        }
        catch
        {
        }

        try
        {
            object xObj = valor.GetType().InvokeMember("0", BindingFlags.GetProperty, null, valor, null);
            object yObj = valor.GetType().InvokeMember("1", BindingFlags.GetProperty, null, valor, null);
            object zObj = null;

            try
            {
                zObj = valor.GetType().InvokeMember("2", BindingFlags.GetProperty, null, valor, null);
            }
            catch
            {
                zObj = 0.0;
            }

            double x = Convert.ToDouble(xObj, System.Globalization.CultureInfo.InvariantCulture);
            double y = Convert.ToDouble(yObj, System.Globalization.CultureInfo.InvariantCulture);
            double z = Convert.ToDouble(zObj, System.Globalization.CultureInfo.InvariantCulture);

            return new double[] { x, y, z };
        }
        catch
        {
        }

        return null;
    }


    // =========================================================
    // TIPOS DE FAMILIA
    // =========================================================

    private Dictionary<string, FamilySymbol> ObtenerTiposFamiliaPorNombre(Document doc)
    {
        Dictionary<string, FamilySymbol> resultado = new Dictionary<string, FamilySymbol>();

        if (doc == null)
            return resultado;

        FilteredElementCollector collector = new FilteredElementCollector(doc);
        collector.OfClass(typeof(FamilySymbol));
        collector.WhereElementIsElementType();

        foreach (Element e in collector)
        {
            FamilySymbol symbol = e as FamilySymbol;

            if (symbol == null)
                continue;

            string nombreTipo = "";

            try
            {
                nombreTipo = symbol.Name;
            }
            catch
            {
                nombreTipo = "";
            }

            string nombreFamilia = "";

            try
            {
                if (symbol.Family != null)
                    nombreFamilia = symbol.Family.Name;
            }
            catch
            {
                nombreFamilia = "";
            }

            AgregarTipoFamiliaADiccionario(resultado, nombreTipo, symbol);

            if (!string.IsNullOrWhiteSpace(nombreFamilia) &&
                !string.IsNullOrWhiteSpace(nombreTipo))
            {
                AgregarTipoFamiliaADiccionario(resultado, nombreFamilia + " : " + nombreTipo, symbol);
                AgregarTipoFamiliaADiccionario(resultado, nombreFamilia + ":" + nombreTipo, symbol);
                AgregarTipoFamiliaADiccionario(resultado, nombreFamilia + " - " + nombreTipo, symbol);
                AgregarTipoFamiliaADiccionario(resultado, nombreFamilia + "-" + nombreTipo, symbol);
                AgregarTipoFamiliaADiccionario(resultado, nombreFamilia + "|" + nombreTipo, symbol);
            }
        }

        return resultado;
    }

    private void AgregarTipoFamiliaADiccionario(
        Dictionary<string, FamilySymbol> diccionario,
        string nombre,
        FamilySymbol symbol)
    {
        if (diccionario == null || symbol == null || string.IsNullOrWhiteSpace(nombre))
            return;

        string clave = NormalizarClave(nombre);

        if (string.IsNullOrWhiteSpace(clave))
            return;

        if (!diccionario.ContainsKey(clave))
            diccionario.Add(clave, symbol);
    }

    private FamilySymbol BuscarFamilySymbol(
        Dictionary<string, FamilySymbol> tiposFamilia,
        string nombreTipo)
    {
        if (tiposFamilia == null || string.IsNullOrWhiteSpace(nombreTipo))
            return null;

        string clave = NormalizarClave(nombreTipo);

        if (tiposFamilia.ContainsKey(clave))
            return tiposFamilia[clave];

        return null;
    }

    // =========================================================
    // CARAS CANDIDATAS DEL MODELO
    // =========================================================

    private List<CaraCandidataMYG> ObtenerCarasCandidatasDelModelo(
        Document doc,
        BoundingBoxXYZ bbBloques)
    {
        List<CaraCandidataMYG> resultado = new List<CaraCandidataMYG>();

        if (doc == null)
            return resultado;

        BuiltInCategory[] categorias = ObtenerCategoriasCandidatasParaAlojamiento();

        Options opciones = new Options();
        opciones.ComputeReferences = true;
        opciones.IncludeNonVisibleObjects = false;
        opciones.DetailLevel = ViewDetailLevel.Fine;

        ElementMulticategoryFilter filtroCategorias =
            new ElementMulticategoryFilter(categorias.ToList());

        ElementFilter filtroBbHost = CrearFiltroBoundingBoxExpandido(bbBloques, MetrosAPies(3.00));

        // 1) Caras del modelo activo.
        FilteredElementCollector collectorHost = new FilteredElementCollector(doc);
        collectorHost.WhereElementIsNotElementType();
        collectorHost.WherePasses(filtroCategorias);

        if (filtroBbHost != null)
            collectorHost.WherePasses(filtroBbHost);

        foreach (Element elemento in collectorHost)
        {
            if (elemento == null)
                continue;

            GeometryElement geo = null;

            try
            {
                geo = elemento.get_Geometry(opciones);
            }
            catch
            {
                geo = null;
            }

            if (geo == null)
                continue;

            ExtraerCarasPlanarCandidatas(
                elemento,
                geo,
                resultado,
                0,
                null,
                Transform.Identity,
                Transform.Identity,
                false);
        }

        // 2) Caras de vínculos Revit.
        // IMPORTANTE:
        // Las caras que se ven en pantalla pueden pertenecer a un RevitLinkInstance.
        // Para alojar una familia face-based sobre una cara de vínculo se necesita:
        // - Leer la geometría en el documento vinculado.
        // - Transformar puntos/normales al documento principal.
        // - Convertir la Reference con CreateLinkReference(linkInstance).
        FilteredElementCollector collectorLinks = new FilteredElementCollector(doc);
        collectorLinks.OfClass(typeof(RevitLinkInstance));
        collectorLinks.WhereElementIsNotElementType();

        foreach (Element eLink in collectorLinks)
        {
            RevitLinkInstance linkInstance = eLink as RevitLinkInstance;

            if (linkInstance == null)
                continue;

            Document linkDoc = null;

            try
            {
                linkDoc = linkInstance.GetLinkDocument();
            }
            catch
            {
                linkDoc = null;
            }

            if (linkDoc == null)
                continue;

            Transform transformLinkAHost = Transform.Identity;
            Transform transformHostALink = Transform.Identity;

            try
            {
                transformLinkAHost = linkInstance.GetTotalTransform();

                if (transformLinkAHost == null)
                    transformLinkAHost = Transform.Identity;

                transformHostALink = transformLinkAHost.Inverse;

                if (transformHostALink == null)
                    transformHostALink = Transform.Identity;
            }
            catch
            {
                transformLinkAHost = Transform.Identity;
                transformHostALink = Transform.Identity;
            }

            ElementMulticategoryFilter filtroCategoriasLink =
                new ElementMulticategoryFilter(categorias.ToList());

            ElementFilter filtroBbLink =
                CrearFiltroBoundingBoxExpandidoTransformado(
                    bbBloques,
                    MetrosAPies(3.00),
                    transformHostALink);

            FilteredElementCollector collectorLinkDoc = new FilteredElementCollector(linkDoc);
            collectorLinkDoc.WhereElementIsNotElementType();
            collectorLinkDoc.WherePasses(filtroCategoriasLink);

            if (filtroBbLink != null)
                collectorLinkDoc.WherePasses(filtroBbLink);

            foreach (Element elementoLink in collectorLinkDoc)
            {
                if (elementoLink == null)
                    continue;

                GeometryElement geoLink = null;

                try
                {
                    geoLink = elementoLink.get_Geometry(opciones);
                }
                catch
                {
                    geoLink = null;
                }

                if (geoLink == null)
                    continue;

                ExtraerCarasPlanarCandidatas(
                    elementoLink,
                    geoLink,
                    resultado,
                    0,
                    linkInstance,
                    transformLinkAHost,
                    transformHostALink,
                    true);
            }
        }

        return resultado;
    }

    private BuiltInCategory[] ObtenerCategoriasCandidatasParaAlojamiento()
    {
        return new BuiltInCategory[]
        {
            BuiltInCategory.OST_Floors,
            BuiltInCategory.OST_Ceilings,
            BuiltInCategory.OST_Roofs,
            BuiltInCategory.OST_Walls,
            BuiltInCategory.OST_GenericModel,
            BuiltInCategory.OST_StructuralFraming,
            BuiltInCategory.OST_StructuralFoundation,
            BuiltInCategory.OST_StructuralColumns,
            BuiltInCategory.OST_Columns
        };
    }

    private ElementFilter CrearFiltroBoundingBoxExpandido(BoundingBoxXYZ bb, double margen)
    {
        return CrearFiltroBoundingBoxExpandidoTransformado(
            bb,
            margen,
            Transform.Identity);
    }

    private ElementFilter CrearFiltroBoundingBoxExpandidoTransformado(
        BoundingBoxXYZ bb,
        double margen,
        Transform transformHostADocumentoBusqueda)
    {
        if (bb == null)
            return null;

        try
        {
            Transform tr = transformHostADocumentoBusqueda;

            if (tr == null)
                tr = Transform.Identity;

            List<XYZ> puntos = new List<XYZ>();

            puntos.Add(new XYZ(bb.Min.X, bb.Min.Y, bb.Min.Z));
            puntos.Add(new XYZ(bb.Min.X, bb.Min.Y, bb.Max.Z));
            puntos.Add(new XYZ(bb.Min.X, bb.Max.Y, bb.Min.Z));
            puntos.Add(new XYZ(bb.Min.X, bb.Max.Y, bb.Max.Z));
            puntos.Add(new XYZ(bb.Max.X, bb.Min.Y, bb.Min.Z));
            puntos.Add(new XYZ(bb.Max.X, bb.Min.Y, bb.Max.Z));
            puntos.Add(new XYZ(bb.Max.X, bb.Max.Y, bb.Min.Z));
            puntos.Add(new XYZ(bb.Max.X, bb.Max.Y, bb.Max.Z));

            double minX = double.MaxValue;
            double minY = double.MaxValue;
            double maxX = double.MinValue;
            double maxY = double.MinValue;

            foreach (XYZ pHost in puntos)
            {
                XYZ p = pHost;

                try
                {
                    p = tr.OfPoint(pHost);
                }
                catch
                {
                    p = pHost;
                }

                minX = Math.Min(minX, p.X);
                minY = Math.Min(minY, p.Y);
                maxX = Math.Max(maxX, p.X);
                maxY = Math.Max(maxY, p.Y);
            }

            if (minX == double.MaxValue || minY == double.MaxValue)
                return null;

            XYZ min = new XYZ(
                minX - margen,
                minY - margen,
                -30000.0);

            XYZ max = new XYZ(
                maxX + margen,
                maxY + margen,
                30000.0);

            Outline outline = new Outline(min, max);

            return new BoundingBoxIntersectsFilter(outline);
        }
        catch
        {
            return null;
        }
    }

    private void ExtraerCarasPlanarCandidatas(
        Element elemento,
        GeometryElement geo,
        List<CaraCandidataMYG> resultado,
        int profundidad,
        RevitLinkInstance linkInstance,
        Transform transformOrigenAHost,
        Transform transformHostAOrigen,
        bool esDeVinculo)
    {
        if (elemento == null || geo == null || resultado == null)
            return;

        if (profundidad > 10)
            return;

        if (transformOrigenAHost == null)
            transformOrigenAHost = Transform.Identity;

        if (transformHostAOrigen == null)
            transformHostAOrigen = Transform.Identity;

        foreach (GeometryObject obj in geo)
        {
            if (obj == null)
                continue;

            Solid solid = obj as Solid;

            if (solid != null && solid.Faces != null && solid.Faces.Size > 0)
            {
                foreach (Face face in solid.Faces)
                {
                    PlanarFace pf = face as PlanarFace;

                    if (pf == null)
                        continue;

                    if (pf.Reference == null)
                        continue;

                    XYZ normalOrigen = null;
                    XYZ origenOrigen = null;

                    try
                    {
                        normalOrigen = pf.FaceNormal;
                        origenOrigen = pf.Origin;
                    }
                    catch
                    {
                        normalOrigen = null;
                        origenOrigen = null;
                    }

                    if (normalOrigen == null || origenOrigen == null)
                        continue;

                    XYZ normalHost = normalOrigen;
                    XYZ origenHost = origenOrigen;

                    try
                    {
                        normalHost = transformOrigenAHost.OfVector(normalOrigen);
                        origenHost = transformOrigenAHost.OfPoint(origenOrigen);
                    }
                    catch
                    {
                        normalHost = normalOrigen;
                        origenHost = origenOrigen;
                    }

                    try
                    {
                        if (normalHost.GetLength() > 0.000001)
                            normalHost = normalHost.Normalize();
                    }
                    catch
                    {
                    }

                    if (normalHost == null || origenHost == null)
                        continue;

                    // Evita caras totalmente verticales. Se aceptan horizontales e inclinadas.
                    // Esto se evalúa en coordenadas del documento principal para que los vínculos funcionen bien.
                    if (Math.Abs(normalHost.Z) < 0.05)
                        continue;

                    Reference referenciaFinal = pf.Reference;

                    if (esDeVinculo)
                    {
                        if (linkInstance == null)
                            continue;

                        try
                        {
                            referenciaFinal = pf.Reference.CreateLinkReference(linkInstance);
                        }
                        catch
                        {
                            referenciaFinal = null;
                        }

                        if (referenciaFinal == null)
                            continue;
                    }

                    CaraCandidataMYG item = new CaraCandidataMYG();
                    item.ElementoId = elemento.Id;
                    item.LinkInstanceId = esDeVinculo && linkInstance != null ? linkInstance.Id : ElementId.InvalidElementId;
                    item.Face = pf;
                    item.Referencia = referenciaFinal;
                    item.Normal = normalHost;
                    item.Origen = origenHost;
                    item.EsDeVinculo = esDeVinculo;
                    item.TransformOrigenAHost = transformOrigenAHost;
                    item.TransformHostAOrigen = transformHostAOrigen;

                    resultado.Add(item);
                }
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi != null)
            {
                GeometryElement geoInstancia = null;

                try
                {
                    geoInstancia = gi.GetInstanceGeometry();
                }
                catch
                {
                    geoInstancia = null;
                }

                if (geoInstancia != null)
                {
                    ExtraerCarasPlanarCandidatas(
                        elemento,
                        geoInstancia,
                        resultado,
                        profundidad + 1,
                        linkInstance,
                        transformOrigenAHost,
                        transformHostAOrigen,
                        esDeVinculo);
                }
            }
        }
    }

    private CaraObjetivoMYG BuscarCaraMasProxima(
        XYZ puntoBloque,
        List<CaraCandidataMYG> caras,
        bool buscarSuperior)
    {
        if (puntoBloque == null || caras == null || caras.Count == 0)
            return null;

        CaraObjetivoMYG mejor = null;
        double mejorDistancia = double.MaxValue;

        foreach (CaraCandidataMYG cara in caras)
        {
            if (cara == null || cara.Face == null || cara.Referencia == null)
                continue;

            CaraObjetivoMYG evaluada =
                EvaluarInterseccionVerticalConCara(puntoBloque, cara, buscarSuperior);

            if (evaluada == null)
                continue;

            if (evaluada.DistanciaVertical < mejorDistancia)
            {
                mejorDistancia = evaluada.DistanciaVertical;
                mejor = evaluada;
            }
        }

        return mejor;
    }

    private CaraObjetivoMYG EvaluarInterseccionVerticalConCara(
        XYZ puntoBloque,
        CaraCandidataMYG cara,
        bool buscarSuperior)
    {
        if (puntoBloque == null || cara == null || cara.Face == null)
            return null;

        XYZ normal = cara.Normal;
        XYZ origen = cara.Origen;

        if (normal == null || origen == null)
            return null;

        if (Math.Abs(normal.Z) < 0.000001)
            return null;

        double zCara =
            origen.Z -
            (
                normal.X * (puntoBloque.X - origen.X) +
                normal.Y * (puntoBloque.Y - origen.Y)
            ) / normal.Z;

        double dz = zCara - puntoBloque.Z;
        double tolerancia = MetrosAPies(0.03);

        if (buscarSuperior)
        {
            if (dz < -tolerancia)
                return null;
        }
        else
        {
            if (dz > tolerancia)
                return null;
        }

        XYZ puntoEnPlanoHost = new XYZ(
            puntoBloque.X,
            puntoBloque.Y,
            zCara);

        XYZ puntoParaProyectar = puntoEnPlanoHost;

        if (cara.EsDeVinculo && cara.TransformHostAOrigen != null)
        {
            try
            {
                puntoParaProyectar = cara.TransformHostAOrigen.OfPoint(puntoEnPlanoHost);
            }
            catch
            {
                puntoParaProyectar = puntoEnPlanoHost;
            }
        }

        IntersectionResult proyeccion = null;

        try
        {
            proyeccion = cara.Face.Project(puntoParaProyectar);
        }
        catch
        {
            proyeccion = null;
        }

        if (proyeccion == null)
            return null;

        XYZ puntoProyectadoOrigen = null;
        UV uv = null;

        try
        {
            puntoProyectadoOrigen = proyeccion.XYZPoint;
            uv = proyeccion.UVPoint;
        }
        catch
        {
            puntoProyectadoOrigen = null;
            uv = null;
        }

        if (puntoProyectadoOrigen == null || uv == null)
            return null;

        XYZ puntoProyectadoHost = puntoProyectadoOrigen;

        if (cara.EsDeVinculo && cara.TransformOrigenAHost != null)
        {
            try
            {
                puntoProyectadoHost = cara.TransformOrigenAHost.OfPoint(puntoProyectadoOrigen);
            }
            catch
            {
                puntoProyectadoHost = puntoProyectadoOrigen;
            }
        }

        double distanciaAlPlano = puntoProyectadoHost.DistanceTo(puntoEnPlanoHost);

        if (distanciaAlPlano > MetrosAPies(0.02))
            return null;

        bool dentroCara = false;

        try
        {
            dentroCara = cara.Face.IsInside(uv);
        }
        catch
        {
            dentroCara = true;
        }

        if (!dentroCara)
            return null;

        CaraObjetivoMYG objetivo = new CaraObjetivoMYG();
        objetivo.Referencia = cara.Referencia;
        objetivo.PuntoEnCara = puntoProyectadoHost;
        objetivo.Normal = normal;
        objetivo.ElementoId = cara.ElementoId;
        objetivo.LinkInstanceId = cara.LinkInstanceId;
        objetivo.EsDeVinculo = cara.EsDeVinculo;
        objetivo.DistanciaVertical = Math.Abs(dz);

        return objetivo;
    }


    private bool PuntosBloquesSospechosos(List<BloqueCadMYG> bloques)
    {
        if (bloques == null || bloques.Count <= 1)
            return false;

        Dictionary<string, int> conteoPorPunto = new Dictionary<string, int>();

        foreach (BloqueCadMYG b in bloques)
        {
            if (b == null || b.PuntoInsercion == null)
                continue;

            string clave = CrearClavePuntoXYZ(b.PuntoInsercion, 0.005);

            if (!conteoPorPunto.ContainsKey(clave))
                conteoPorPunto.Add(clave, 0);

            conteoPorPunto[clave]++;
        }

        if (conteoPorPunto.Count == 0)
            return true;

        int maxRepetidos = conteoPorPunto.Values.Max();
        int limiteMayor = Math.Max(5, (int)Math.Ceiling(bloques.Count * 0.80));

        if (conteoPorPunto.Count == 1)
            return true;

        if (maxRepetidos >= limiteMayor)
            return true;

        return false;
    }

    private string ValidarPuntosBloquesCad(List<BloqueCadMYG> bloques)
    {
        if (bloques == null || bloques.Count <= 1)
            return "";

        Dictionary<string, int> conteoPorPunto = new Dictionary<string, int>();

        foreach (BloqueCadMYG b in bloques)
        {
            if (b == null || b.PuntoInsercion == null)
                continue;

            string clave = CrearClavePuntoXYZ(b.PuntoInsercion, 0.005);

            if (!conteoPorPunto.ContainsKey(clave))
                conteoPorPunto.Add(clave, 0);

            conteoPorPunto[clave]++;
        }

        if (conteoPorPunto.Count == 0)
        {
            return
                "ERROR:\r\n" +
                "No se pudieron validar los puntos de inserción de los bloques CAD.";
        }

        int maxRepetidos = conteoPorPunto.Values.Max();
        int limiteMayor = Math.Max(5, (int)Math.Ceiling(bloques.Count * 0.80));

        string fuente = "";

        try
        {
            fuente = bloques
                .Where(x => x != null && !string.IsNullOrWhiteSpace(x.FuenteLectura))
                .Select(x => x.FuenteLectura)
                .FirstOrDefault();
        }
        catch
        {
            fuente = "";
        }

        if (string.IsNullOrWhiteSpace(fuente))
            fuente = "No identificada";

        if (conteoPorPunto.Count == 1)
        {
            return
                "ERROR:\r\n" +
                "Todos los bloques CAD detectados tienen el mismo punto de inserción.\r\n\r\n" +
                "Esto normalmente ocurre cuando no se pudo leer correctamente el DWG y se devolvió el origen del CAD para todos los bloques.\r\n\r\n" +
                "Fuente de lectura: " + fuente + "\r\n" +
                "Bloques detectados: " + bloques.Count.ToString() + "\r\n\r\n" +
                "Se canceló la creación para evitar familias superpuestas.";
        }

        if (maxRepetidos >= limiteMayor)
        {
            return
                "ERROR:\r\n" +
                "La mayoría de bloques CAD detectados caen en el mismo punto.\r\n\r\n" +
                "Bloques detectados: " + bloques.Count.ToString() + "\r\n" +
                "Mayor repetición de un punto: " + maxRepetidos.ToString() + "\r\n" +
                "Fuente de lectura: " + fuente + "\r\n\r\n" +
                "Se canceló la creación para evitar familias superpuestas.";
        }

        return "";
    }

    private string CrearClavePuntoXYZ(XYZ p, double toleranciaPies)
    {
        if (p == null)
            return "NULL";

        if (toleranciaPies <= 0.0000001)
            toleranciaPies = 0.005;

        long x = (long)Math.Round(p.X / toleranciaPies);
        long y = (long)Math.Round(p.Y / toleranciaPies);
        long z = (long)Math.Round(p.Z / toleranciaPies);

        return x.ToString() + "|" + y.ToString() + "|" + z.ToString();
    }

    private BoundingBoxXYZ ObtenerBoundingBoxBloques(List<BloqueCadMYG> bloques)
    {
        BoundingBoxXYZ bb = new BoundingBoxXYZ();

        if (bloques == null || bloques.Count == 0)
        {
            bb.Min = new XYZ(-1, -1, -1);
            bb.Max = new XYZ(1, 1, 1);
            return bb;
        }

        double minX = double.MaxValue;
        double minY = double.MaxValue;
        double minZ = double.MaxValue;

        double maxX = double.MinValue;
        double maxY = double.MinValue;
        double maxZ = double.MinValue;

        foreach (BloqueCadMYG bloque in bloques)
        {
            if (bloque == null || bloque.PuntoInsercion == null)
                continue;

            XYZ p = bloque.PuntoInsercion;

            minX = Math.Min(minX, p.X);
            minY = Math.Min(minY, p.Y);
            minZ = Math.Min(minZ, p.Z);

            maxX = Math.Max(maxX, p.X);
            maxY = Math.Max(maxY, p.Y);
            maxZ = Math.Max(maxZ, p.Z);
        }

        if (minX == double.MaxValue)
        {
            bb.Min = new XYZ(-1, -1, -1);
            bb.Max = new XYZ(1, 1, 1);
            return bb;
        }

        bb.Min = new XYZ(minX, minY, minZ);
        bb.Max = new XYZ(maxX, maxY, maxZ);

        return bb;
    }


    // =========================================================
    // ALINEAR FAMILIA AL CRUCE DE PLANOS DE REFERENCIA CENTER
    // =========================================================

    private Dictionary<ElementId, XYZ> PrepararOffsetsCentroPlanosReferencia(
        Document doc,
        List<BloqueCadMYG> bloquesCad,
        Dictionary<string, MapeoBloqueFamiliaMYG> matriz,
        Dictionary<string, FamilySymbol> tiposFamilia)
    {
        Dictionary<ElementId, XYZ> resultado = new Dictionary<ElementId, XYZ>();

        if (doc == null || bloquesCad == null || matriz == null || tiposFamilia == null)
            return resultado;

        foreach (BloqueCadMYG bloque in bloquesCad)
        {
            if (bloque == null)
                continue;

            string claveBloque = NormalizarClave(bloque.NombreBloque);

            if (!matriz.ContainsKey(claveBloque))
                continue;

            MapeoBloqueFamiliaMYG mapeo = matriz[claveBloque];

            if (mapeo == null || string.IsNullOrWhiteSpace(mapeo.NombreTipoFamilia))
                continue;

            FamilySymbol tipo = BuscarFamilySymbol(tiposFamilia, mapeo.NombreTipoFamilia);

            if (tipo == null || tipo.Id == null || tipo.Id == ElementId.InvalidElementId)
                continue;

            if (resultado.ContainsKey(tipo.Id))
                continue;

            XYZ offsetCentro = ObtenerOffsetLocalCrucePlanosCenter(doc, tipo);

            if (offsetCentro == null)
                offsetCentro = new XYZ(0.0, 0.0, 0.0);

            resultado.Add(tipo.Id, offsetCentro);
        }

        return resultado;
    }

    private XYZ ObtenerOffsetCentroLocalDesdeCache(
        Dictionary<ElementId, XYZ> cache,
        ElementId tipoId)
    {
        if (cache == null || tipoId == null || tipoId == ElementId.InvalidElementId)
            return new XYZ(0.0, 0.0, 0.0);

        if (cache.ContainsKey(tipoId) && cache[tipoId] != null)
            return cache[tipoId];

        return new XYZ(0.0, 0.0, 0.0);
    }

    private XYZ ObtenerOffsetLocalCrucePlanosCenter(Document doc, FamilySymbol tipo)
    {
        if (doc == null || tipo == null || tipo.Family == null)
            return new XYZ(0.0, 0.0, 0.0);

        // No se puede usar EditFamily con el documento del proyecto en modo modificable.
        // Este método se llama antes de iniciar la transacción principal.
        if (doc.IsModifiable)
            return new XYZ(0.0, 0.0, 0.0);

        Document familyDoc = null;

        try
        {
            familyDoc = doc.EditFamily(tipo.Family);

            if (familyDoc == null)
                return new XYZ(0.0, 0.0, 0.0);

            ReferencePlane planoLeftRight = null;
            ReferencePlane planoFrontBack = null;

            FilteredElementCollector collector = new FilteredElementCollector(familyDoc);
            collector.OfClass(typeof(ReferencePlane));

            foreach (Element e in collector)
            {
                ReferencePlane rp = e as ReferencePlane;

                if (rp == null)
                    continue;

                string nombre = "";

                try
                {
                    nombre = rp.Name;
                }
                catch
                {
                    nombre = "";
                }

                string clave = NormalizarClave(nombre);

                if (string.IsNullOrWhiteSpace(clave))
                    continue;

                if (EsPlanoReferenciaCenterLeftRight(clave))
                    planoLeftRight = rp;

                if (EsPlanoReferenciaCenterFrontBack(clave))
                    planoFrontBack = rp;
            }

            if (planoLeftRight != null && planoFrontBack != null)
            {
                XYZ centro = ObtenerInterseccionPlanosReferenciaEnNivelCero(
                    planoLeftRight,
                    planoFrontBack);

                if (centro != null)
                    return centro;
            }
        }
        catch
        {
        }
        finally
        {
            if (familyDoc != null)
            {
                try
                {
                    familyDoc.Close(false);
                }
                catch
                {
                }
            }
        }

        return new XYZ(0.0, 0.0, 0.0);
    }

    private bool EsPlanoReferenciaCenterLeftRight(string clave)
    {
        if (string.IsNullOrWhiteSpace(clave))
            return false;

        bool esCentro =
            clave.Contains("CENTER") ||
            clave.Contains("CENTRE") ||
            clave.Contains("CENTRO");

        bool esLeftRight =
            clave.Contains("LEFT") ||
            clave.Contains("RIGHT") ||
            clave.Contains("IZQUIERDA") ||
            clave.Contains("DERECHA");

        return esCentro && esLeftRight;
    }

    private bool EsPlanoReferenciaCenterFrontBack(string clave)
    {
        if (string.IsNullOrWhiteSpace(clave))
            return false;

        bool esCentro =
            clave.Contains("CENTER") ||
            clave.Contains("CENTRE") ||
            clave.Contains("CENTRO");

        bool esFrontBack =
            clave.Contains("FRONT") ||
            clave.Contains("BACK") ||
            clave.Contains("FRENTE") ||
            clave.Contains("ATRAS") ||
            clave.Contains("POSTERIOR") ||
            clave.Contains("DELANTE") ||
            clave.Contains("DETRAS");

        return esCentro && esFrontBack;
    }

    private XYZ ObtenerInterseccionPlanosReferenciaEnNivelCero(
        ReferencePlane planoA,
        ReferencePlane planoB)
    {
        if (planoA == null || planoB == null)
            return null;

        try
        {
            Plane pa = planoA.GetPlane();
            Plane pb = planoB.GetPlane();

            if (pa == null || pb == null)
                return null;

            XYZ na = pa.Normal;
            XYZ nb = pb.Normal;
            XYZ oa = pa.Origin;
            XYZ ob = pb.Origin;

            if (na == null || nb == null || oa == null || ob == null)
                return null;

            // Intersección de dos planos verticales con el plano Z = 0 del editor de familia.
            // na.X * x + na.Y * y = na · oa
            // nb.X * x + nb.Y * y = nb · ob
            double a1 = na.X;
            double b1 = na.Y;
            double c1 = na.DotProduct(oa);

            double a2 = nb.X;
            double b2 = nb.Y;
            double c2 = nb.DotProduct(ob);

            double det = a1 * b2 - a2 * b1;

            if (Math.Abs(det) < 0.000000001)
                return null;

            double x = (c1 * b2 - c2 * b1) / det;
            double y = (a1 * c2 - a2 * c1) / det;

            return new XYZ(x, y, 0.0);
        }
        catch
        {
            return null;
        }
    }

    private void AlinearCrucePlanosCenterConPuntoObjetivo(
        Document doc,
        FamilyInstance instancia,
        XYZ offsetCentroLocal,
        XYZ puntoObjetivo,
        XYZ normalCara)
    {
        if (doc == null || instancia == null || offsetCentroLocal == null || puntoObjetivo == null)
            return;

        try
        {
            if (offsetCentroLocal.GetLength() < 0.000000001)
                return;
        }
        catch
        {
            return;
        }

        try
        {
            Transform tr = instancia.GetTransform();

            if (tr == null)
                return;

            XYZ offsetModelo = tr.OfVector(offsetCentroLocal);

            // El movimiento debe ser sobre la misma cara de alojamiento.
            // Por eso quitamos cualquier componente perpendicular a la cara.
            if (normalCara != null)
            {
                try
                {
                    XYZ n = normalCara.Normalize();
                    offsetModelo = offsetModelo - n.Multiply(offsetModelo.DotProduct(n));
                }
                catch
                {
                }
            }

            if (offsetModelo == null || offsetModelo.GetLength() < 0.000000001)
                return;

            // Si el cruce CENTER queda en P + offsetModelo, movemos la familia -offsetModelo
            // para que dicho cruce coincida exactamente con puntoObjetivo.
            ElementTransformUtils.MoveElement(
                doc,
                instancia.Id,
                offsetModelo.Negate());
        }
        catch
        {
        }
    }

    // =========================================================
    // DIRECCIÓN / PARÁMETROS
    // =========================================================

    private XYZ ObtenerDireccionReferenciaSobreCara(XYZ direccionCad, XYZ normalCara)
    {
        if (normalCara == null)
            normalCara = XYZ.BasisZ;

        XYZ dir = direccionCad;

        if (dir == null || dir.GetLength() < 0.000001)
            dir = XYZ.BasisX;

        try
        {
            normalCara = normalCara.Normalize();
        }
        catch
        {
            normalCara = XYZ.BasisZ;
        }

        XYZ proyectada = dir - normalCara.Multiply(dir.DotProduct(normalCara));

        if (proyectada.GetLength() < 0.000001)
        {
            dir = XYZ.BasisX;
            proyectada = dir - normalCara.Multiply(dir.DotProduct(normalCara));
        }

        if (proyectada.GetLength() < 0.000001)
        {
            dir = XYZ.BasisY;
            proyectada = dir - normalCara.Multiply(dir.DotProduct(normalCara));
        }

        try
        {
            return proyectada.Normalize();
        }
        catch
        {
            return XYZ.BasisX;
        }
    }

    private void AsignarTextoParametroSiExiste(Element elemento, string nombreParametro, string valor)
    {
        if (elemento == null || string.IsNullOrWhiteSpace(nombreParametro))
            return;

        try
        {
            Parameter p = elemento.LookupParameter(nombreParametro);

            if (p == null || p.IsReadOnly)
                return;

            if (p.StorageType == StorageType.String)
                p.Set(valor ?? "");
        }
        catch
        {
        }
    }

    // =========================================================
    // UTILIDADES
    // =========================================================

    private string NormalizarClave(string texto)
    {
        if (string.IsNullOrWhiteSpace(texto))
            return "";

        string limpio = texto.Trim().ToUpperInvariant();

        limpio = limpio.Replace("Á", "A");
        limpio = limpio.Replace("É", "E");
        limpio = limpio.Replace("Í", "I");
        limpio = limpio.Replace("Ó", "O");
        limpio = limpio.Replace("Ú", "U");
        limpio = limpio.Replace("Ü", "U");
        limpio = limpio.Replace("Ñ", "N");

        limpio = limpio.Replace("\r", " ");
        limpio = limpio.Replace("\n", " ");
        limpio = limpio.Replace("\t", " ");

        while (limpio.Contains("  "))
            limpio = limpio.Replace("  ", " ");

        return limpio.Trim();
    }

    private double MetrosAPies(double metros)
    {
        return metros / 0.3048;
    }

    private void MostrarEnVentana(string mensaje)
    {
        try
        {
            if (Form != null && !Form.IsDisposed)
                Form.MostrarResultado(mensaje);
        }
        catch
        {
        }
    }


    // =========================================================
    // CLASES INTERNAS
    // =========================================================

    private class MapeoBloqueFamiliaMYG
    {
        public string NombreBloque { get; set; }
        public string NombreTipoFamilia { get; set; }
    }

    private class BloqueCadMYG
    {
        public string NombreBloque { get; set; }
        public XYZ PuntoInsercion { get; set; }
        public XYZ DireccionX { get; set; }
        public Transform Transform { get; set; }
        public string FuenteLectura { get; set; }
    }

    private class CaraCandidataMYG
    {
        public ElementId ElementoId { get; set; }
        public ElementId LinkInstanceId { get; set; }
        public PlanarFace Face { get; set; }
        public Reference Referencia { get; set; }
        public XYZ Normal { get; set; }
        public XYZ Origen { get; set; }
        public bool EsDeVinculo { get; set; }
        public Transform TransformOrigenAHost { get; set; }
        public Transform TransformHostAOrigen { get; set; }
    }

    private class CaraObjetivoMYG
    {
        public ElementId ElementoId { get; set; }
        public ElementId LinkInstanceId { get; set; }
        public Reference Referencia { get; set; }
        public XYZ PuntoEnCara { get; set; }
        public XYZ Normal { get; set; }
        public bool EsDeVinculo { get; set; }
        public double DistanciaVertical { get; set; }
    }

    private class FiltroSeleccionCadImportInstanceMYG : ISelectionFilter
    {
        public bool AllowElement(Element elem)
        {
            if (elem == null)
                return false;

            return elem is ImportInstance;
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            return false;
        }
    }
}
