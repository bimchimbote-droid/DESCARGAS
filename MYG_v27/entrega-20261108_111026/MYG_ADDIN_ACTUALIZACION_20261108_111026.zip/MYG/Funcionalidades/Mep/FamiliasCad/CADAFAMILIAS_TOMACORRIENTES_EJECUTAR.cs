﻿// =====================================
// HANDLER EXTERNO - TOMACORRIENTES DESDE BLOQUES CAD - BOTON 54
// REVIT 2027
// REPLANTEO: CAD + EXCEL + HABITACIONES SELECCIONADAS + NIVEL BASE + RAYCAST A CARA DE MURO
// CON USING / SIN NAMESPACE
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using MYG_Addin;

public class EjecutarCrearTomacorrientesDesdeBloquesCad54Handler : IExternalEventHandler
{
    public UIDocument UiDoc { get; set; }
    public CrearTomacorrientesDesdeBloquesCad54Form Form { get; set; }

    public CrearTomacorrientesDesdeBloquesCad54Form.CrearTomacorrientesDesdeBloquesCadAccion Accion { get; set; } =
        CrearTomacorrientesDesdeBloquesCad54Form.CrearTomacorrientesDesdeBloquesCadAccion.Ninguna;

    private string _ultimoDiagnosticoLecturaCad = "";

    public string GetName()
    {
        return "MYG - Crear tomacorrientes desde bloques CAD";
    }

    public void Execute(UIApplication app)
    {
        if (UiDoc == null || UiDoc.Document == null)
            return;

        if (Form == null || Form.IsDisposed)
            return;

        try
        {
            if (Accion == CrearTomacorrientesDesdeBloquesCad54Form.CrearTomacorrientesDesdeBloquesCadAccion.SeleccionarCad)
            {
                SeleccionarCad();
                return;
            }

            if (Accion == CrearTomacorrientesDesdeBloquesCad54Form.CrearTomacorrientesDesdeBloquesCadAccion.SeleccionarHabitaciones)
            {
                SeleccionarHabitaciones();
                return;
            }

            if (Accion == CrearTomacorrientesDesdeBloquesCad54Form.CrearTomacorrientesDesdeBloquesCadAccion.CrearTomacorrientes)
            {
                CrearTomacorrientesDesdeCadYExcel();
                return;
            }
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            MostrarEnVentana("Selección cancelada.");
        }
        catch (Exception ex)
        {
            MostrarEnVentana("ERROR:\r\n" + ex.Message);
        }
        finally
        {
            Accion = CrearTomacorrientesDesdeBloquesCad54Form.CrearTomacorrientesDesdeBloquesCadAccion.Ninguna;
        }
    }

    // =========================================================
    // SELECCIÓN DE CAD
    // =========================================================

    private void SeleccionarCad()
    {
        Document doc = UiDoc.Document;

        try
        {
            Form.OcultarTemporalmenteParaSeleccion();

            Reference referencia = UiDoc.Selection.PickObject(
                ObjectType.Element,
                new FiltroSeleccionCadImportInstanceMYG(),
                "Seleccione un vínculo/importación CAD");

            if (referencia == null)
                return;

            ImportInstance cad = doc.GetElement(referencia.ElementId) as ImportInstance;

            if (cad == null)
            {
                MostrarEnVentana("El elemento seleccionado no es un vínculo/importación CAD.");
                return;
            }

            Form.ActualizarCadSeleccionado(cad);
        }
        finally
        {
            Form.MostrarLuegoDeSeleccion();
        }
    }

    // =========================================================
    // SELECCIÓN DE HABITACIONES / ESPACIOS
    // =========================================================

    private void SeleccionarHabitaciones()
    {
        Document doc = UiDoc.Document;

        List<CrearTomacorrientesDesdeBloquesCad54Form.HabitacionSeleccionadaTomacorrienteMYG> seleccionadas =
            new List<CrearTomacorrientesDesdeBloquesCad54Form.HabitacionSeleccionadaTomacorrienteMYG>();

        try
        {
            Form.OcultarTemporalmenteParaSeleccion();

            TaskDialog.Show(
                "MYG - Selección de habitaciones",
                "Primero selecciona HABITACIONES/ESPACIOS de VÍNCULOS REVIT.\r\n" +
                "Usa TAB si necesitas entrar al vínculo.\r\n\r\n" +
                "Presiona ESC cuando termines o si no hay habitaciones vinculadas.");

            try
            {
                IList<Reference> refsLink = UiDoc.Selection.PickObjects(
                    ObjectType.LinkedElement,
                    new FiltroSeleccionRoomSpaceVinculoMYG(doc),
                    "Seleccione habitaciones/espacios en vínculos. ESC para continuar.");

                if (refsLink != null)
                {
                    foreach (Reference r in refsLink)
                    {
                        if (r == null)
                            continue;

                        ElementId linkId = r.ElementId;
                        ElementId linkedId = r.LinkedElementId;

                        if (linkId == null || linkId == ElementId.InvalidElementId ||
                            linkedId == null || linkedId == ElementId.InvalidElementId)
                        {
                            continue;
                        }

                        RevitLinkInstance link = doc.GetElement(linkId) as RevitLinkInstance;

                        if (link == null)
                            continue;

                        Document linkDoc = link.GetLinkDocument();

                        if (linkDoc == null)
                            continue;

                        Element elem = linkDoc.GetElement(linkedId);

                        if (!EsRoomOSpace(elem))
                            continue;

                        AgregarHabitacionSeleccionada(
                            seleccionadas,
                            true,
                            linkId,
                            linkedId,
                            ObtenerNombreElementoEspacial(elem, true));
                    }
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                // El usuario terminó la selección de vínculos. Continuamos con nativas.
            }

            TaskDialog.Show(
                "MYG - Selección de habitaciones",
                "Ahora selecciona HABITACIONES/ESPACIOS NATIVOS, si existen.\r\n\r\n" +
                "Presiona ESC para terminar.");

            try
            {
                IList<Reference> refsHost = UiDoc.Selection.PickObjects(
                    ObjectType.Element,
                    new FiltroSeleccionRoomSpaceNativoMYG(),
                    "Seleccione habitaciones/espacios nativos. ESC para terminar.");

                if (refsHost != null)
                {
                    foreach (Reference r in refsHost)
                    {
                        if (r == null)
                            continue;

                        ElementId id = r.ElementId;

                        if (id == null || id == ElementId.InvalidElementId)
                            continue;

                        Element elem = doc.GetElement(id);

                        if (!EsRoomOSpace(elem))
                            continue;

                        AgregarHabitacionSeleccionada(
                            seleccionadas,
                            false,
                            ElementId.InvalidElementId,
                            id,
                            ObtenerNombreElementoEspacial(elem, false));
                    }
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                // El usuario terminó la selección.
            }

            if (seleccionadas.Count == 0)
            {
                MostrarEnVentana("No se seleccionaron habitaciones/espacios.");
                return;
            }

            Form.ActualizarHabitacionesSeleccionadas(seleccionadas);
        }
        finally
        {
            Form.MostrarLuegoDeSeleccion();
        }
    }

    private void AgregarHabitacionSeleccionada(
        List<CrearTomacorrientesDesdeBloquesCad54Form.HabitacionSeleccionadaTomacorrienteMYG> lista,
        bool esDeVinculo,
        ElementId linkId,
        ElementId elementoId,
        string nombre)
    {
        if (lista == null || elementoId == null || elementoId == ElementId.InvalidElementId)
            return;

        bool existe = lista.Any(x =>
            x != null &&
            x.EsDeVinculo == esDeVinculo &&
            x.ElementoEspacialId == elementoId &&
            ((x.LinkInstanceId == null && linkId == null) ||
             (x.LinkInstanceId != null && linkId != null && x.LinkInstanceId == linkId)));

        if (existe)
            return;

        CrearTomacorrientesDesdeBloquesCad54Form.HabitacionSeleccionadaTomacorrienteMYG item =
            new CrearTomacorrientesDesdeBloquesCad54Form.HabitacionSeleccionadaTomacorrienteMYG();

        item.EsDeVinculo = esDeVinculo;
        item.LinkInstanceId = linkId == null ? ElementId.InvalidElementId : linkId;
        item.ElementoEspacialId = elementoId;
        item.Nombre = nombre ?? "";

        lista.Add(item);
    }

    // =========================================================
    // PROCESO PRINCIPAL
    // =========================================================

    private void CrearTomacorrientesDesdeCadYExcel()
    {
        Document doc = UiDoc.Document;

        if (doc == null)
            return;

        _ultimoDiagnosticoLecturaCad = "";

        ElementId cadId = Form.CadSeleccionadoId;

        if (cadId == null || cadId == ElementId.InvalidElementId)
        {
            MostrarEnVentana("Debe seleccionar un vínculo/importación CAD.");
            return;
        }

        ImportInstance cad = doc.GetElement(cadId) as ImportInstance;

        if (cad == null)
        {
            MostrarEnVentana("No se encontró el CAD seleccionado.");
            return;
        }

        string rutaExcel = Form.RutaExcelActual;

        if (string.IsNullOrWhiteSpace(rutaExcel) || !File.Exists(rutaExcel))
        {
            MostrarEnVentana("Debe seleccionar un Excel válido.");
            return;
        }

        ElementId nivelBaseId = Form.NivelBaseSeleccionadoId;

        if (nivelBaseId == null || nivelBaseId == ElementId.InvalidElementId)
        {
            MostrarEnVentana("Debe seleccionar un nivel base.");
            return;
        }

        Level nivelBase = doc.GetElement(nivelBaseId) as Level;

        if (nivelBase == null)
        {
            MostrarEnVentana("No se encontró el nivel base seleccionado.");
            return;
        }

        if (Form.HabitacionesSeleccionadas == null || Form.HabitacionesSeleccionadas.Count == 0)
        {
            MostrarEnVentana("Debe seleccionar habitaciones/espacios a evaluar.");
            return;
        }

        double alturaSobreNivelM = Form.AlturaSobreNivelM;
        double alturaSobreNivelFt = MetrosAPies(alturaSobreNivelM);
        double zObjetivoHost = nivelBase.Elevation + alturaSobreNivelFt;

        Dictionary<string, MapeoBloqueFamiliaMYG> matriz =
            LeerMatrizBloqueFamiliaDesdeExcel(rutaExcel);

        if (matriz == null || matriz.Count == 0)
        {
            MostrarEnVentana("No se encontraron datos válidos en el Excel. Use Columna A = bloque CAD y Columna B = tipo de familia.");
            return;
        }

        List<BloqueCadMYG> bloquesCad =
            ObtenerBloquesCadDesdeImportInstance(doc, cad, matriz);

        if (bloquesCad == null)
            bloquesCad = new List<BloqueCadMYG>();

        if (bloquesCad.Count == 0)
        {
            MostrarEnVentana(
                "No se detectaron bloques CAD que coincidan con el Excel.\r\n\r\n" +
                "Detalle:\r\n" + _ultimoDiagnosticoLecturaCad);
            return;
        }

        string errorPuntosBloques = ValidarPuntosBloquesCad(bloquesCad);

        if (!string.IsNullOrWhiteSpace(errorPuntosBloques))
        {
            MostrarEnVentana(errorPuntosBloques);
            return;
        }

        Dictionary<string, FamilySymbol> tiposFamilia =
            ObtenerTiposFamiliaPorNombre(doc);

        if (tiposFamilia == null || tiposFamilia.Count == 0)
        {
            MostrarEnVentana("No se encontraron tipos de familia cargados en el proyecto.");
            return;
        }

        List<HabitacionCandidataMYG> habitaciones =
            ConstruirHabitacionesDesdeSeleccion(doc, Form.HabitacionesSeleccionadas);

        if (habitaciones == null || habitaciones.Count == 0)
        {
            MostrarEnVentana("No se pudieron resolver las habitaciones/espacios seleccionados. Verifica que los vínculos sigan cargados.");
            return;
        }

        _ultimoDiagnosticoLecturaCad +=
            "Habitaciones/espacios evaluados por selección: " + habitaciones.Count.ToString() + ".\r\n" +
            "Nivel base seleccionado: " + nivelBase.Name +
            " | Elevación ft=" + nivelBase.Elevation.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture) +
            " | Altura m=" + alturaSobreNivelM.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture) + ".\r\n";

        int creadas = 0;
        int omitidasSinTipo = 0;
        int omitidasSinHabitacion = 0;
        int omitidasSinMuro = 0;
        int omitidasSinCara = 0;
        int omitidasError = 0;

        List<ElementId> idsCreados = new List<ElementId>();
        List<string> errores = new List<string>();

        using (Transaction tx = new Transaction(doc, "MYG - Crear tomacorrientes desde bloques CAD"))
        {
            tx.Start();

            foreach (BloqueCadMYG bloque in bloquesCad)
            {
                if (bloque == null)
                    continue;

                string claveBloque = NormalizarClave(bloque.NombreBloque);

                if (!matriz.ContainsKey(claveBloque))
                    continue;

                MapeoBloqueFamiliaMYG mapeo = matriz[claveBloque];

                if (mapeo == null || string.IsNullOrWhiteSpace(mapeo.NombreTipoFamilia))
                    continue;

                FamilySymbol tipo = BuscarFamilySymbol(tiposFamilia, mapeo.NombreTipoFamilia);

                if (tipo == null)
                {
                    omitidasSinTipo++;
                    continue;
                }

                // IMPORTANTE V17:
                // Para tomacorrientes en muro usamos SIEMPRE el punto de inserción/origen 0,0,0 del bloque CAD.
                // Antes se usaba el centro del BoundingBox del bloque y por eso muchos símbolos quedaban mal evaluados.
                XYZ puntoBusquedaBloque = bloque.PuntoInsercionSeguro();

                SegmentoHabitacionMYG segmento =
                    BuscarSegmentoMuroMasCercanoEnHabitacionesSeleccionadas(habitaciones, puntoBusquedaBloque);

                if (segmento == null || segmento.Habitacion == null || segmento.Habitacion.ElementoEspacial == null)
                {
                    omitidasSinHabitacion++;
                    continue;
                }

                if (segmento.Muro == null)
                {
                    omitidasSinMuro++;
                    continue;
                }

                XYZ direccionInteriorHost = ObtenerDireccionInteriorHost(segmento);

                if (direccionInteriorHost == null || direccionInteriorHost.GetLength() < 0.000001)
                {
                    omitidasSinCara++;
                    continue;
                }

                // Punto real de creación:
                // X/Y desde el origen del bloque CAD + Z desde el nivel base seleccionado y altura indicada.
                // Desde este punto se lanzan rayos horizontales para encontrar la cara vertical más próxima.
                XYZ puntoObjetivoHost = new XYZ(puntoBusquedaBloque.X, puntoBusquedaBloque.Y, zObjetivoHost);

                CaraMuroObjetivoMYG caraObjetivo =
                    BuscarCaraVerticalDesdeOrigenBloque(doc, segmento, puntoObjetivoHost, direccionInteriorHost);

                if (caraObjetivo == null || caraObjetivo.Referencia == null)
                {
                    omitidasSinCara++;
                    continue;
                }

                try
                {
                    if (!tipo.IsActive)
                    {
                        tipo.Activate();
                        doc.Regenerate();
                    }

                    XYZ direccionReferencia =
                        ObtenerDireccionReferenciaSobreCara(XYZ.BasisZ, caraObjetivo.NormalInterior);

                    FamilyInstance instancia = doc.Create.NewFamilyInstance(
                        caraObjetivo.Referencia,
                        caraObjetivo.PuntoEnCara,
                        direccionReferencia,
                        tipo);

                    if (instancia != null)
                    {
                        creadas++;
                        idsCreados.Add(instancia.Id);

                        IntentarAsignarNivelYDesfaseTomacorriente(instancia, nivelBase, alturaSobreNivelFt);
                        OrientarFamiliaHaciaInterior(instancia, caraObjetivo.NormalInterior);

                        AsignarTextoParametroSiExiste(instancia, "GEN_OrigenCAD", bloque.NombreBloque);
                        AsignarTextoParametroSiExiste(instancia, "GEN_BloqueCAD", bloque.NombreBloque);
                        AsignarTextoParametroSiExiste(instancia, "GEN_FuenteLecturaCAD", bloque.FuenteLectura);
                        AsignarTextoParametroSiExiste(instancia, "ARQ_Ubicación", ObtenerNombreElementoEspacial(segmento.Habitacion.ElementoEspacial, segmento.Habitacion.EsDeVinculo));
                        AsignarTextoParametroSiExiste(instancia, "Comments", "Creado desde bloque CAD: " + bloque.NombreBloque);
                        AsignarTextoParametroSiExiste(instancia, "Comentarios", "Creado desde bloque CAD: " + bloque.NombreBloque);
                    }
                }
                catch (Exception ex)
                {
                    omitidasError++;

                    if (errores.Count < 15)
                    {
                        errores.Add(
                            bloque.NombreBloque + " -> " +
                            mapeo.NombreTipoFamilia + " | " +
                            ex.Message);
                    }
                }
            }

            tx.Commit();
        }

        if (idsCreados.Count > 0)
        {
            try
            {
                UiDoc.Selection.SetElementIds(idsCreados);
            }
            catch
            {
            }
        }

        string mensaje =
            "Proceso terminado.\r\n" +
            "Fuente lectura CAD: " + ObtenerFuenteLecturaResumen(bloquesCad) + "\r\n" +
            "Bloques CAD coincidentes: " + bloquesCad.Count.ToString() + "\r\n" +
            "Bloques por patrón Excel: " + ObtenerResumenBloquesPorPatron(bloquesCad) + "\r\n" +
            "Habitaciones/espacios seleccionados evaluados: " + habitaciones.Count.ToString() + "\r\n" +
            "Nivel base: " + nivelBase.Name + "\r\n" +
            "Tomacorrientes creados: " + creadas.ToString() + "\r\n" +
            "Omitidos sin tipo de familia: " + omitidasSinTipo.ToString() + "\r\n" +
            "Omitidos sin habitación/contorno seleccionado: " + omitidasSinHabitacion.ToString() + "\r\n" +
            "Omitidos sin muro de contorno: " + omitidasSinMuro.ToString() + "\r\n" +
            "Omitidos sin cara vertical: " + omitidasSinCara.ToString() + "\r\n" +
            "Omitidos por error: " + omitidasError.ToString();

        if (!string.IsNullOrWhiteSpace(_ultimoDiagnosticoLecturaCad))
            mensaje += "\r\n\r\nDiagnóstico CAD:\r\n" + _ultimoDiagnosticoLecturaCad;

        if (errores.Count > 0)
        {
            mensaje += "\r\n\r\nPrimeros errores:\r\n";

            foreach (string error in errores)
                mensaje += "- " + error + "\r\n";
        }

        MostrarEnVentana(mensaje);
    }

    // =========================================================
    // CONSTRUIR HABITACIONES SELECCIONADAS
    // =========================================================

    private List<HabitacionCandidataMYG> ConstruirHabitacionesDesdeSeleccion(
        Document docHost,
        List<CrearTomacorrientesDesdeBloquesCad54Form.HabitacionSeleccionadaTomacorrienteMYG> seleccion)
    {
        List<HabitacionCandidataMYG> resultado = new List<HabitacionCandidataMYG>();

        if (docHost == null || seleccion == null || seleccion.Count == 0)
            return resultado;

        foreach (CrearTomacorrientesDesdeBloquesCad54Form.HabitacionSeleccionadaTomacorrienteMYG s in seleccion)
        {
            if (s == null || s.ElementoEspacialId == null || s.ElementoEspacialId == ElementId.InvalidElementId)
                continue;

            try
            {
                if (s.EsDeVinculo)
                {
                    RevitLinkInstance link = docHost.GetElement(s.LinkInstanceId) as RevitLinkInstance;

                    if (link == null)
                        continue;

                    Document linkDoc = link.GetLinkDocument();

                    if (linkDoc == null)
                        continue;

                    SpatialElement se = linkDoc.GetElement(s.ElementoEspacialId) as SpatialElement;

                    if (!EsRoomOSpace(se))
                        continue;

                    Transform linkAHost = link.GetTotalTransform();

                    if (linkAHost == null)
                        linkAHost = Transform.Identity;

                    HabitacionCandidataMYG h = new HabitacionCandidataMYG();
                    h.Documento = linkDoc;
                    h.ElementoEspacial = se;
                    h.EsDeVinculo = true;
                    h.LinkInstance = link;
                    h.TransformDocAHost = linkAHost;
                    h.TransformHostADoc = linkAHost.Inverse;

                    resultado.Add(h);
                }
                else
                {
                    SpatialElement se = docHost.GetElement(s.ElementoEspacialId) as SpatialElement;

                    if (!EsRoomOSpace(se))
                        continue;

                    HabitacionCandidataMYG h = new HabitacionCandidataMYG();
                    h.Documento = docHost;
                    h.ElementoEspacial = se;
                    h.EsDeVinculo = false;
                    h.LinkInstance = null;
                    h.TransformDocAHost = Transform.Identity;
                    h.TransformHostADoc = Transform.Identity;

                    resultado.Add(h);
                }
            }
            catch
            {
            }
        }

        return resultado;
    }

    // =========================================================
    // ROOM / SPACE + CONTORNO
    // =========================================================

    private SegmentoHabitacionMYG BuscarSegmentoMuroMasCercanoEnHabitacionesSeleccionadas(
        List<HabitacionCandidataMYG> habitaciones,
        XYZ puntoBloqueHost)
    {
        if (habitaciones == null || habitaciones.Count == 0 || puntoBloqueHost == null)
            return null;

        SegmentoHabitacionMYG mejor = null;
        double mejorDistancia = double.MaxValue;

        foreach (HabitacionCandidataMYG h in habitaciones)
        {
            if (h == null || h.ElementoEspacial == null || h.Documento == null)
                continue;

            SegmentoHabitacionMYG candidato =
                BuscarSegmentoMuroMasCercanoDeHabitacion(h, puntoBloqueHost);

            if (candidato == null || candidato.Muro == null)
                continue;

            double penalizacion = 0.0;

            try
            {
                XYZ puntoLocal = TransformarPuntoHostADocumento(h, puntoBloqueHost);
                double z = ObtenerElevacionElementoEspacial(h.ElementoEspacial) + MetrosAPies(1.00);
                XYZ pTest = new XYZ(puntoLocal.X, puntoLocal.Y, z);

                if (!PuntoDentroDeElementoEspacial(h, pTest))
                    penalizacion = MetrosAPies(0.10);
            }
            catch
            {
                penalizacion = 0.0;
            }

            double d = candidato.Distancia + penalizacion;

            if (d < mejorDistancia)
            {
                mejorDistancia = d;
                mejor = candidato;
            }
        }

        return mejor;
    }

    private SegmentoHabitacionMYG BuscarSegmentoMuroMasCercanoDeHabitacion(
        HabitacionCandidataMYG habitacion,
        XYZ puntoBloqueHost)
    {
        if (habitacion == null || habitacion.ElementoEspacial == null || habitacion.Documento == null || puntoBloqueHost == null)
            return null;

        IList<IList<BoundarySegment>> loops = ObtenerLoopsHabitacion(habitacion.ElementoEspacial);

        if (loops == null)
            return null;

        XYZ puntoBloqueLocal = TransformarPuntoHostADocumento(habitacion, puntoBloqueHost);

        SegmentoHabitacionMYG mejor = null;
        double mejorDistancia = double.MaxValue;

        foreach (IList<BoundarySegment> loop in loops)
        {
            if (loop == null)
                continue;

            foreach (BoundarySegment seg in loop)
            {
                if (seg == null)
                    continue;

                Curve curva = null;

                try
                {
                    curva = seg.GetCurve();
                }
                catch
                {
                    curva = null;
                }

                if (curva == null)
                    continue;

                Wall muro = null;

                try
                {
                    muro = habitacion.Documento.GetElement(seg.ElementId) as Wall;
                }
                catch
                {
                    muro = null;
                }

                if (muro == null)
                    continue;

                XYZ cercanoLocal = ObtenerPuntoMasCercanoEnCurva(curva, puntoBloqueLocal);

                if (cercanoLocal == null)
                    continue;

                XYZ cercanoHost = TransformarPuntoDocumentoAHost(habitacion, cercanoLocal);
                double distancia = DistanciaXY(cercanoHost, puntoBloqueHost);

                if (distancia < mejorDistancia)
                {
                    mejorDistancia = distancia;

                    SegmentoHabitacionMYG s = new SegmentoHabitacionMYG();
                    s.Habitacion = habitacion;
                    s.DocumentoMuro = habitacion.Documento;
                    s.EsDeVinculo = habitacion.EsDeVinculo;
                    s.LinkInstance = habitacion.LinkInstance;
                    s.TransformDocAHost = habitacion.TransformDocAHost;
                    s.TransformHostADoc = habitacion.TransformHostADoc;
                    s.Muro = muro;
                    s.Curva = curva;
                    s.PuntoMasCercanoLocal = cercanoLocal;
                    s.PuntoMasCercanoHost = cercanoHost;
                    s.Distancia = distancia;

                    mejor = s;
                }
            }
        }

        return mejor;
    }

    private IList<IList<BoundarySegment>> ObtenerLoopsHabitacion(SpatialElement elementoEspacial)
    {
        if (elementoEspacial == null)
            return null;

        try
        {
            SpatialElementBoundaryOptions opciones = new SpatialElementBoundaryOptions();
            opciones.SpatialElementBoundaryLocation = SpatialElementBoundaryLocation.Finish;

            return elementoEspacial.GetBoundarySegments(opciones);
        }
        catch
        {
            try
            {
                SpatialElementBoundaryOptions opciones = new SpatialElementBoundaryOptions();
                return elementoEspacial.GetBoundarySegments(opciones);
            }
            catch
            {
                return null;
            }
        }
    }

    private XYZ ObtenerDireccionInteriorHost(SegmentoHabitacionMYG segmento)
    {
        if (segmento == null || segmento.Habitacion == null || segmento.Curva == null || segmento.PuntoMasCercanoLocal == null)
            return null;

        XYZ p = segmento.PuntoMasCercanoLocal;
        XYZ interiorLocal = null;

        try
        {
            XYZ a = segmento.Curva.GetEndPoint(0);
            XYZ b = segmento.Curva.GetEndPoint(1);

            XYZ t = new XYZ(b.X - a.X, b.Y - a.Y, 0.0);

            if (t.GetLength() < 0.000001)
                return null;

            t = t.Normalize();

            XYZ n1 = new XYZ(-t.Y, t.X, 0.0);
            XYZ n2 = new XYZ(t.Y, -t.X, 0.0);

            double z = ObtenerElevacionElementoEspacial(segmento.Habitacion.ElementoEspacial) + MetrosAPies(1.00);
            double prueba = MetrosAPies(0.20);

            XYZ p1 = new XYZ(p.X + n1.X * prueba, p.Y + n1.Y * prueba, z);
            XYZ p2 = new XYZ(p.X + n2.X * prueba, p.Y + n2.Y * prueba, z);

            if (PuntoDentroDeElementoEspacial(segmento.Habitacion, p1))
                interiorLocal = n1;
            else if (PuntoDentroDeElementoEspacial(segmento.Habitacion, p2))
                interiorLocal = n2;
        }
        catch
        {
            interiorLocal = null;
        }

        if (interiorLocal == null || interiorLocal.GetLength() < 0.000001)
        {
            try
            {
                LocationPoint lp = segmento.Habitacion.ElementoEspacial.Location as LocationPoint;

                if (lp != null && lp.Point != null)
                {
                    XYZ v = new XYZ(lp.Point.X - p.X, lp.Point.Y - p.Y, 0.0);

                    if (v.GetLength() > 0.000001)
                        interiorLocal = v.Normalize();
                }
            }
            catch
            {
                interiorLocal = null;
            }
        }

        if (interiorLocal == null || interiorLocal.GetLength() < 0.000001)
            return null;

        XYZ interiorHost = TransformarVectorDocumentoAHost(segmento.Habitacion, interiorLocal);

        try
        {
            interiorHost = new XYZ(interiorHost.X, interiorHost.Y, 0.0).Normalize();
        }
        catch
        {
            return null;
        }

        return interiorHost;
    }


    // =========================================================
    // BUSCAR CARA VERTICAL DESDE ORIGEN DEL BLOQUE CAD
    // =========================================================

    private CaraMuroObjetivoMYG BuscarCaraVerticalDesdeOrigenBloque(
        Document docHost,
        SegmentoHabitacionMYG segmento,
        XYZ puntoOrigenBloqueEnAlturaHost,
        XYZ direccionInteriorHost)
    {
        if (docHost == null || segmento == null || segmento.Muro == null || puntoOrigenBloqueEnAlturaHost == null)
            return null;

        // 1) Método principal: rayos radiales desde el origen 0,0,0 del bloque CAD elevado a la altura indicada.
        CaraMuroObjetivoMYG porRayosRadiales =
            BuscarCaraVerticalMasCercanaPorRayosDesdePunto(docHost, segmento, puntoOrigenBloqueEnAlturaHost, direccionInteriorHost);

        if (porRayosRadiales != null && porRayosRadiales.Referencia != null)
            return porRayosRadiales;

        // 2) Respaldo: lógica anterior, usando la dirección interior del contorno.
        if (direccionInteriorHost != null && direccionInteriorHost.GetLength() > 0.000001)
        {
            CaraMuroObjetivoMYG respaldo =
                BuscarCaraVerticalMasCercanaPorRaycast(docHost, segmento, puntoOrigenBloqueEnAlturaHost, direccionInteriorHost);

            if (respaldo != null && respaldo.Referencia != null)
                return respaldo;
        }

        try
        {
            _ultimoDiagnosticoLecturaCad +=
                "Sin cara vertical desde origen CAD: MuroId=" + segmento.Muro.Id.Value.ToString() +
                " | Vinculo=" + (segmento.EsDeVinculo ? "SI" : "NO") +
                " | DistBloqueContorno=" + PiesAMetros(segmento.Distancia).ToString("0.###", System.Globalization.CultureInfo.InvariantCulture) + "m.\r\n";
        }
        catch
        {
        }

        return null;
    }

    private CaraMuroObjetivoMYG BuscarCaraVerticalMasCercanaPorRayosDesdePunto(
        Document docHost,
        SegmentoHabitacionMYG segmento,
        XYZ puntoOrigenBloqueEnAlturaHost,
        XYZ direccionInteriorHost)
    {
        if (docHost == null || segmento == null || segmento.Muro == null || puntoOrigenBloqueEnAlturaHost == null)
            return null;

        View3D vista3D = ObtenerVista3DParaReferenceIntersector(docHost);

        if (vista3D == null)
            return null;

        List<ReferenceIntersector> intersectors = CrearIntersectorsParaMuros(docHost, vista3D, segmento.EsDeVinculo);

        if (intersectors == null || intersectors.Count == 0)
            return null;

        List<XYZ> direcciones = CrearDireccionesRaycastDesdeOrigen(puntoOrigenBloqueEnAlturaHost, segmento, direccionInteriorHost);

        if (direcciones == null || direcciones.Count == 0)
            return null;

        double[] retrocesos = new double[]
        {
            MetrosAPies(0.00),
            MetrosAPies(0.02),
            MetrosAPies(0.05),
            MetrosAPies(0.10),
            MetrosAPies(0.20)
        };

        Reference mejorReferencia = null;
        XYZ mejorPunto = null;
        XYZ mejorDireccionRayo = null;
        double mejorDistancia = double.MaxValue;

        foreach (XYZ dir in direcciones)
        {
            if (dir == null || dir.GetLength() < 0.000001)
                continue;

            XYZ direccionRayo = null;

            try
            {
                direccionRayo = new XYZ(dir.X, dir.Y, 0.0).Normalize();
            }
            catch
            {
                direccionRayo = null;
            }

            if (direccionRayo == null || direccionRayo.GetLength() < 0.000001)
                continue;

            foreach (double retroceso in retrocesos)
            {
                XYZ origenRayo = puntoOrigenBloqueEnAlturaHost - direccionRayo.Multiply(retroceso);

                foreach (ReferenceIntersector intersector in intersectors)
                {
                    if (intersector == null)
                        continue;

                    IList<ReferenceWithContext> encontrados = null;

                    try
                    {
                        encontrados = intersector.Find(origenRayo, direccionRayo);
                    }
                    catch
                    {
                        encontrados = null;
                    }

                    if (encontrados == null || encontrados.Count == 0)
                        continue;

                    foreach (ReferenceWithContext rwc in encontrados)
                    {
                        if (rwc == null)
                            continue;

                        Reference referencia = null;

                        try
                        {
                            referencia = rwc.GetReference();
                        }
                        catch
                        {
                            referencia = null;
                        }

                        if (referencia == null)
                            continue;

                        if (!ReferenciaCorrespondeAlMuro(segmento, referencia))
                            continue;

                        double prox = double.MaxValue;

                        try
                        {
                            prox = rwc.Proximity;
                        }
                        catch
                        {
                            prox = 0.0;
                        }

                        if (prox < -0.000001 || prox > MetrosAPies(3.00))
                            continue;

                        XYZ puntoHit = null;

                        try
                        {
                            puntoHit = referencia.GlobalPoint;
                        }
                        catch
                        {
                            puntoHit = null;
                        }

                        if (puntoHit == null)
                            puntoHit = origenRayo + direccionRayo.Multiply(prox);

                        double distanciaReal = DistanciaXY(puntoHit, puntoOrigenBloqueEnAlturaHost);

                        // Evitar falsos positivos muy lejanos cuando el bloque ya está casi pegado al contorno.
                        if (distanciaReal > MetrosAPies(3.00))
                            continue;

                        if (distanciaReal < mejorDistancia)
                        {
                            mejorDistancia = distanciaReal;
                            mejorReferencia = referencia;
                            mejorPunto = puntoHit;
                            mejorDireccionRayo = direccionRayo;
                        }
                    }
                }
            }
        }

        if (mejorReferencia == null || mejorPunto == null || mejorDireccionRayo == null)
            return null;

        XYZ normalInterior = null;

        try
        {
            // El rayo va desde el origen del bloque hacia el muro.
            // La dirección hacia adentro de la habitación es la opuesta al rayo que impactó la cara.
            normalInterior = mejorDireccionRayo.Negate().Normalize();
        }
        catch
        {
            normalInterior = direccionInteriorHost;
        }

        if (normalInterior == null || normalInterior.GetLength() < 0.000001)
            normalInterior = XYZ.BasisY;

        CaraMuroObjetivoMYG resultado = new CaraMuroObjetivoMYG();
        resultado.Referencia = mejorReferencia;
        resultado.PuntoEnCara = mejorPunto;
        resultado.NormalInterior = normalInterior;
        resultado.MuroId = segmento.Muro.Id;
        resultado.LinkInstanceId = segmento.LinkInstance == null ? ElementId.InvalidElementId : segmento.LinkInstance.Id;
        resultado.EsDeVinculo = segmento.EsDeVinculo;
        resultado.Distancia = mejorDistancia;

        return resultado;
    }

    private List<ReferenceIntersector> CrearIntersectorsParaMuros(
        Document docHost,
        View3D vista3D,
        bool buscarEnVinculo)
    {
        List<ReferenceIntersector> resultado = new List<ReferenceIntersector>();

        if (docHost == null || vista3D == null)
            return resultado;

        List<ElementFilter> filtros = new List<ElementFilter>();

        // Para vínculos, algunas versiones de Revit devuelven la referencia si el filtro apunta al LinkInstance,
        // y otras cuando el filtro apunta a Wall con FindReferencesInRevitLinks = true.
        // Por eso se prueban ambos filtros.
        if (buscarEnVinculo)
        {
            filtros.Add(new ElementClassFilter(typeof(RevitLinkInstance)));
            filtros.Add(new ElementClassFilter(typeof(Wall)));
        }
        else
        {
            filtros.Add(new ElementClassFilter(typeof(Wall)));
        }

        foreach (ElementFilter filtro in filtros)
        {
            try
            {
                ReferenceIntersector intersector = new ReferenceIntersector(
                    filtro,
                    FindReferenceTarget.Face,
                    vista3D);

                intersector.FindReferencesInRevitLinks = true;
                resultado.Add(intersector);
            }
            catch
            {
            }
        }

        return resultado;
    }

    private List<XYZ> CrearDireccionesRaycastDesdeOrigen(
        XYZ puntoOrigenBloqueEnAlturaHost,
        SegmentoHabitacionMYG segmento,
        XYZ direccionInteriorHost)
    {
        List<XYZ> resultado = new List<XYZ>();

        if (puntoOrigenBloqueEnAlturaHost == null)
            return resultado;

        // Dirección más importante: desde el origen del bloque hacia el punto de contorno más cercano.
        if (segmento != null && segmento.PuntoMasCercanoHost != null)
        {
            try
            {
                XYZ haciaContorno = new XYZ(
                    segmento.PuntoMasCercanoHost.X - puntoOrigenBloqueEnAlturaHost.X,
                    segmento.PuntoMasCercanoHost.Y - puntoOrigenBloqueEnAlturaHost.Y,
                    0.0);

                if (haciaContorno.GetLength() > MetrosAPies(0.001))
                    AgregarDireccionUnica(resultado, haciaContorno.Normalize());
            }
            catch
            {
            }
        }

        // Direcciones derivadas de la habitación: hacia muro y hacia interior.
        if (direccionInteriorHost != null)
        {
            try
            {
                XYZ interior = new XYZ(direccionInteriorHost.X, direccionInteriorHost.Y, 0.0).Normalize();
                AgregarDireccionUnica(resultado, interior.Negate());
                AgregarDireccionUnica(resultado, interior);
                AgregarDireccionUnica(resultado, new XYZ(-interior.Y, interior.X, 0.0));
                AgregarDireccionUnica(resultado, new XYZ(interior.Y, -interior.X, 0.0));
            }
            catch
            {
            }
        }

        // Barrido radial de respaldo. Esto permite encontrar la cara vertical más próxima aunque
        // el origen del bloque esté exactamente sobre el muro o el contorno tenga una tolerancia rara.
        int divisiones = 32;

        for (int i = 0; i < divisiones; i++)
        {
            double ang = (2.0 * Math.PI * i) / divisiones;
            XYZ dir = new XYZ(Math.Cos(ang), Math.Sin(ang), 0.0);
            AgregarDireccionUnica(resultado, dir);
        }

        return resultado;
    }

    private void AgregarDireccionUnica(List<XYZ> lista, XYZ direccion)
    {
        if (lista == null || direccion == null)
            return;

        XYZ dir = null;

        try
        {
            dir = new XYZ(direccion.X, direccion.Y, 0.0).Normalize();
        }
        catch
        {
            dir = null;
        }

        if (dir == null || dir.GetLength() < 0.000001)
            return;

        foreach (XYZ existente in lista)
        {
            if (existente == null)
                continue;

            try
            {
                if (Math.Abs(existente.DotProduct(dir)) > 0.999)
                    return;
            }
            catch
            {
            }
        }

        lista.Add(dir);
    }

    // =========================================================
    // BUSCAR CARA VERTICAL POR RAYCAST
    // =========================================================

    private CaraMuroObjetivoMYG BuscarCaraVerticalMasCercanaPorRaycast(
        Document docHost,
        SegmentoHabitacionMYG segmento,
        XYZ puntoObjetivoHost,
        XYZ direccionInteriorHost)
    {
        if (docHost == null || segmento == null || segmento.Muro == null || puntoObjetivoHost == null || direccionInteriorHost == null)
            return null;

        try
        {
            direccionInteriorHost = new XYZ(direccionInteriorHost.X, direccionInteriorHost.Y, 0.0).Normalize();
        }
        catch
        {
            return null;
        }

        CaraMuroObjetivoMYG porRayo =
            BuscarCaraPorReferenceIntersector(docHost, segmento, puntoObjetivoHost, direccionInteriorHost);

        if (porRayo != null && porRayo.Referencia != null)
            return porRayo;

        CaraMuroObjetivoMYG porSideFaces =
            BuscarCaraPorSideFaces(docHost, segmento, puntoObjetivoHost, direccionInteriorHost);

        if (porSideFaces != null && porSideFaces.Referencia != null)
            return porSideFaces;

        try
        {
            _ultimoDiagnosticoLecturaCad +=
                "Sin cara vertical: MuroId=" + segmento.Muro.Id.Value.ToString() +
                " | Vinculo=" + (segmento.EsDeVinculo ? "SI" : "NO") +
                " | DistBloqueContorno=" + PiesAMetros(segmento.Distancia).ToString("0.###", System.Globalization.CultureInfo.InvariantCulture) + "m.\r\n";
        }
        catch
        {
        }

        return null;
    }

    private CaraMuroObjetivoMYG BuscarCaraPorReferenceIntersector(
        Document docHost,
        SegmentoHabitacionMYG segmento,
        XYZ puntoObjetivoHost,
        XYZ direccionInteriorHost)
    {
        View3D vista3D = ObtenerVista3DParaReferenceIntersector(docHost);

        if (vista3D == null)
            return null;

        ReferenceIntersector intersector = null;

        try
        {
            ElementFilter filtro = null;

            if (segmento.EsDeVinculo)
                filtro = new ElementClassFilter(typeof(RevitLinkInstance));
            else
                filtro = new ElementClassFilter(typeof(Wall));

            intersector = new ReferenceIntersector(
                filtro,
                FindReferenceTarget.Face,
                vista3D);

            intersector.FindReferencesInRevitLinks = true;
        }
        catch
        {
            intersector = null;
        }

        if (intersector == null)
            return null;

        double[] offsets = new double[]
        {
            MetrosAPies(0.05),
            MetrosAPies(0.15),
            MetrosAPies(0.30),
            MetrosAPies(0.60),
            MetrosAPies(1.00),
            MetrosAPies(1.50)
        };

        Reference mejorReferencia = null;
        XYZ mejorPunto = null;
        double mejorProximidad = double.MaxValue;

        foreach (double offset in offsets)
        {
            XYZ origen = puntoObjetivoHost + direccionInteriorHost.Multiply(offset);
            XYZ direccionRayo = direccionInteriorHost.Negate();

            IList<ReferenceWithContext> encontrados = null;

            try
            {
                encontrados = intersector.Find(origen, direccionRayo);
            }
            catch
            {
                encontrados = null;
            }

            if (encontrados == null || encontrados.Count == 0)
                continue;

            foreach (ReferenceWithContext rwc in encontrados)
            {
                if (rwc == null)
                    continue;

                Reference referencia = null;

                try
                {
                    referencia = rwc.GetReference();
                }
                catch
                {
                    referencia = null;
                }

                if (referencia == null)
                    continue;

                if (!ReferenciaCorrespondeAlMuro(segmento, referencia))
                    continue;

                double prox = double.MaxValue;

                try
                {
                    prox = rwc.Proximity;
                }
                catch
                {
                    prox = offset;
                }

                if (prox < 0.0 || prox > MetrosAPies(3.00))
                    continue;

                XYZ puntoHit = null;

                try
                {
                    puntoHit = referencia.GlobalPoint;
                }
                catch
                {
                    puntoHit = null;
                }

                if (puntoHit == null)
                    puntoHit = origen + direccionRayo.Multiply(prox);

                if (prox < mejorProximidad)
                {
                    mejorProximidad = prox;
                    mejorReferencia = referencia;
                    mejorPunto = puntoHit;
                }
            }
        }

        if (mejorReferencia == null || mejorPunto == null)
            return null;

        CaraMuroObjetivoMYG resultado = new CaraMuroObjetivoMYG();
        resultado.Referencia = mejorReferencia;
        resultado.PuntoEnCara = mejorPunto;
        resultado.NormalInterior = direccionInteriorHost;
        resultado.MuroId = segmento.Muro.Id;
        resultado.LinkInstanceId = segmento.LinkInstance == null ? ElementId.InvalidElementId : segmento.LinkInstance.Id;
        resultado.EsDeVinculo = segmento.EsDeVinculo;
        resultado.Distancia = DistanciaXY(mejorPunto, puntoObjetivoHost);

        return resultado;
    }

    private CaraMuroObjetivoMYG BuscarCaraPorSideFaces(
        Document docHost,
        SegmentoHabitacionMYG segmento,
        XYZ puntoObjetivoHost,
        XYZ direccionInteriorHost)
    {
        if (docHost == null || segmento == null || segmento.Muro == null)
            return null;

        List<Reference> referencias = new List<Reference>();

        try
        {
            IList<Reference> interior = HostObjectUtils.GetSideFaces(segmento.Muro, ShellLayerType.Interior);

            if (interior != null)
                referencias.AddRange(interior);
        }
        catch
        {
        }

        try
        {
            IList<Reference> exterior = HostObjectUtils.GetSideFaces(segmento.Muro, ShellLayerType.Exterior);

            if (exterior != null)
                referencias.AddRange(exterior);
        }
        catch
        {
        }

        if (referencias.Count == 0)
            return null;

        CaraMuroObjetivoMYG mejor = null;
        double mejorDistancia = double.MaxValue;

        foreach (Reference referenciaLocal in referencias)
        {
            if (referenciaLocal == null)
                continue;

            Reference referenciaHost = referenciaLocal;

            if (segmento.EsDeVinculo && segmento.LinkInstance != null)
            {
                try
                {
                    referenciaHost = referenciaLocal.CreateLinkReference(segmento.LinkInstance);
                }
                catch
                {
                    referenciaHost = null;
                }
            }

            if (referenciaHost == null)
                continue;

            GeometryObject go = null;

            try
            {
                go = segmento.Muro.GetGeometryObjectFromReference(referenciaLocal);
            }
            catch
            {
                go = null;
            }

            Face face = go as Face;

            if (face == null)
                continue;

            XYZ puntoLocal = TransformarPuntoHostADocumento(segmento.Habitacion, puntoObjetivoHost);

            IntersectionResult proy = null;

            try
            {
                proy = face.Project(puntoLocal);
            }
            catch
            {
                proy = null;
            }

            if (proy == null || proy.XYZPoint == null)
                continue;

            XYZ puntoHost = TransformarPuntoDocumentoAHost(segmento.Habitacion, proy.XYZPoint);
            double d = DistanciaXY(puntoHost, puntoObjetivoHost);

            if (d < mejorDistancia)
            {
                mejorDistancia = d;

                CaraMuroObjetivoMYG c = new CaraMuroObjetivoMYG();
                c.Referencia = referenciaHost;
                c.PuntoEnCara = puntoHost;
                c.NormalInterior = direccionInteriorHost;
                c.MuroId = segmento.Muro.Id;
                c.LinkInstanceId = segmento.LinkInstance == null ? ElementId.InvalidElementId : segmento.LinkInstance.Id;
                c.EsDeVinculo = segmento.EsDeVinculo;
                c.Distancia = d;

                mejor = c;
            }
        }

        return mejor;
    }

    private bool ReferenciaCorrespondeAlMuro(SegmentoHabitacionMYG segmento, Reference referencia)
    {
        if (segmento == null || segmento.Muro == null || referencia == null)
            return false;

        try
        {
            if (segmento.EsDeVinculo)
            {
                bool mismoLink = segmento.LinkInstance != null &&
                                referencia.ElementId != null &&
                                referencia.ElementId == segmento.LinkInstance.Id;

                bool mismoMuroLink = referencia.LinkedElementId != null &&
                                     referencia.LinkedElementId != ElementId.InvalidElementId &&
                                     referencia.LinkedElementId == segmento.Muro.Id;

                if (mismoLink && mismoMuroLink)
                    return true;

                // Respaldo por si Revit devuelve el muro vinculado como ElementId.
                if (referencia.ElementId != null && referencia.ElementId == segmento.Muro.Id)
                    return true;

                return false;
            }
            else
            {
                return referencia.ElementId != null && referencia.ElementId == segmento.Muro.Id;
            }
        }
        catch
        {
            return false;
        }
    }

    private View3D ObtenerVista3DParaReferenceIntersector(Document doc)
    {
        if (doc == null)
            return null;

        // IMPORTANTE V18:
        // ReferenceIntersector usa la visibilidad y el section box de la vista 3D.
        // Si toma una vista 3D recortada, solo encontrará algunas caras y parecerá
        // que los demás tomacorrientes no tienen cara vertical. Por eso se prioriza
        // una vista 3D SIN caja de sección.

        try
        {
            View3D activa = doc.ActiveView as View3D;

            if (activa != null && !activa.IsTemplate && !Vista3DTieneCajaSeccionActiva(activa))
                return activa;
        }
        catch
        {
        }

        try
        {
            View3D vistaLibre = new FilteredElementCollector(doc)
                .OfClass(typeof(View3D))
                .Cast<View3D>()
                .Where(v => v != null && !v.IsTemplate && !Vista3DTieneCajaSeccionActiva(v))
                .FirstOrDefault();

            if (vistaLibre != null)
                return vistaLibre;
        }
        catch
        {
        }

        // Si todas las vistas 3D están recortadas, crear una vista temporal amplia.
        // Esto se ejecuta dentro de la transacción principal, así que Revit permite crearla.
        try
        {
            if (doc.IsModifiable)
            {
                ViewFamilyType tipo3D = new FilteredElementCollector(doc)
                    .OfClass(typeof(ViewFamilyType))
                    .Cast<ViewFamilyType>()
                    .Where(x => x != null && x.ViewFamily == ViewFamily.ThreeDimensional)
                    .FirstOrDefault();

                if (tipo3D != null)
                {
                    View3D nueva = View3D.CreateIsometric(doc, tipo3D.Id);

                    if (nueva != null)
                    {
                        try
                        {
                            nueva.Name = "MYG_TEMP_RAYCAST_CARAS_TOMAS_54";
                        }
                        catch
                        {
                        }

                        try
                        {
                            nueva.IsSectionBoxActive = false;
                        }
                        catch
                        {
                        }

                        try
                        {
                            nueva.DetailLevel = ViewDetailLevel.Fine;
                        }
                        catch
                        {
                        }

                        _ultimoDiagnosticoLecturaCad +=
                            "ReferenceIntersector: se creó/usó vista 3D temporal sin caja de sección para buscar caras verticales.\r\n";

                        return nueva;
                    }
                }
            }
        }
        catch
        {
        }

        // Último recurso: cualquier vista 3D no template.
        try
        {
            return new FilteredElementCollector(doc)
                .OfClass(typeof(View3D))
                .Cast<View3D>()
                .Where(v => v != null && !v.IsTemplate)
                .FirstOrDefault();
        }
        catch
        {
            return null;
        }
    }

    private bool Vista3DTieneCajaSeccionActiva(View3D vista)
    {
        if (vista == null)
            return true;

        try
        {
            return vista.IsSectionBoxActive;
        }
        catch
        {
            return false;
        }
    }

    // =========================================================
    // EXCEL
    // =========================================================

    private Dictionary<string, MapeoBloqueFamiliaMYG> LeerMatrizBloqueFamiliaDesdeExcel(string rutaExcel)
    {
        Dictionary<string, MapeoBloqueFamiliaMYG> resultado =
            new Dictionary<string, MapeoBloqueFamiliaMYG>();

        if (string.IsNullOrWhiteSpace(rutaExcel) || !File.Exists(rutaExcel))
            return resultado;

        ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;

        FileInfo archivo = new FileInfo(rutaExcel);

        using (ExcelPackage package = new ExcelPackage(archivo))
        {
            ExcelWorksheet ws = null;

            foreach (ExcelWorksheet hoja in package.Workbook.Worksheets)
            {
                if (hoja != null)
                {
                    ws = hoja;
                    break;
                }
            }

            if (ws == null || ws.Dimension == null)
                return resultado;

            int filaInicio = ws.Dimension.Start.Row;
            int filaFin = ws.Dimension.End.Row;

            for (int fila = filaInicio; fila <= filaFin; fila++)
            {
                string nombreBloque = ObtenerTextoCelda(ws, fila, 1);
                string nombreTipoFamilia = ObtenerTextoCelda(ws, fila, 2);

                if (string.IsNullOrWhiteSpace(nombreBloque) ||
                    string.IsNullOrWhiteSpace(nombreTipoFamilia))
                {
                    continue;
                }

                string bloqueNormalizado = NormalizarClave(nombreBloque);
                string tipoNormalizado = NormalizarClave(nombreTipoFamilia);

                bool pareceEncabezado =
                    bloqueNormalizado.Contains("BLOQUE") &&
                    (tipoNormalizado.Contains("FAMILIA") || tipoNormalizado.Contains("TIPO"));

                if (pareceEncabezado)
                    continue;

                if (resultado.ContainsKey(bloqueNormalizado))
                    continue;

                MapeoBloqueFamiliaMYG item = new MapeoBloqueFamiliaMYG();
                item.NombreBloque = nombreBloque.Trim();
                item.NombreTipoFamilia = nombreTipoFamilia.Trim();

                resultado.Add(bloqueNormalizado, item);
            }
        }

        return resultado;
    }

    private string ObtenerTextoCelda(ExcelWorksheet ws, int fila, int columna)
    {
        if (ws == null)
            return "";

        try
        {
            object valor = ws.Cells[fila, columna].Value;

            if (valor == null)
                return "";

            return valor.ToString().Trim();
        }
        catch
        {
            return "";
        }
    }

    // =========================================================
    // TIPOS DE FAMILIA
    // =========================================================

    private Dictionary<string, FamilySymbol> ObtenerTiposFamiliaPorNombre(Document doc)
    {
        Dictionary<string, FamilySymbol> resultado = new Dictionary<string, FamilySymbol>();

        if (doc == null)
            return resultado;

        FilteredElementCollector collector = new FilteredElementCollector(doc);
        collector.OfClass(typeof(FamilySymbol));
        collector.WhereElementIsElementType();

        foreach (Element e in collector)
        {
            FamilySymbol symbol = e as FamilySymbol;

            if (symbol == null)
                continue;

            string nombreTipo = "";

            try
            {
                nombreTipo = symbol.Name;
            }
            catch
            {
                nombreTipo = "";
            }

            string nombreFamilia = "";

            try
            {
                if (symbol.Family != null)
                    nombreFamilia = symbol.Family.Name;
            }
            catch
            {
                nombreFamilia = "";
            }

            AgregarTipoFamiliaADiccionario(resultado, nombreTipo, symbol);

            if (!string.IsNullOrWhiteSpace(nombreFamilia) &&
                !string.IsNullOrWhiteSpace(nombreTipo))
            {
                AgregarTipoFamiliaADiccionario(resultado, nombreFamilia + " : " + nombreTipo, symbol);
                AgregarTipoFamiliaADiccionario(resultado, nombreFamilia + ":" + nombreTipo, symbol);
                AgregarTipoFamiliaADiccionario(resultado, nombreFamilia + " - " + nombreTipo, symbol);
                AgregarTipoFamiliaADiccionario(resultado, nombreFamilia + "-" + nombreTipo, symbol);
                AgregarTipoFamiliaADiccionario(resultado, nombreFamilia + "|" + nombreTipo, symbol);
            }
        }

        return resultado;
    }

    private void AgregarTipoFamiliaADiccionario(
        Dictionary<string, FamilySymbol> diccionario,
        string nombre,
        FamilySymbol symbol)
    {
        if (diccionario == null || symbol == null || string.IsNullOrWhiteSpace(nombre))
            return;

        string clave = NormalizarClave(nombre);

        if (string.IsNullOrWhiteSpace(clave))
            return;

        if (!diccionario.ContainsKey(clave))
            diccionario.Add(clave, symbol);
    }

    private FamilySymbol BuscarFamilySymbol(
        Dictionary<string, FamilySymbol> tiposFamilia,
        string nombreTipo)
    {
        if (tiposFamilia == null || string.IsNullOrWhiteSpace(nombreTipo))
            return null;

        string clave = NormalizarClave(nombreTipo);

        if (tiposFamilia.ContainsKey(clave))
            return tiposFamilia[clave];

        return null;
    }


    // =========================================================
    // MAPEO FLEXIBLE BLOQUE CAD -> TIPO DE FAMILIA
    // =========================================================

    private MapeoBloqueFamiliaMYG BuscarMapeoParaBloqueCad(
        Dictionary<string, MapeoBloqueFamiliaMYG> matriz,
        string nombreBloqueCadReal)
    {
        if (matriz == null || matriz.Count == 0 || string.IsNullOrWhiteSpace(nombreBloqueCadReal))
            return null;

        string claveReal = NormalizarClave(nombreBloqueCadReal);

        if (string.IsNullOrWhiteSpace(claveReal))
            return null;

        // 01. Coincidencia exacta: caso ideal.
        if (matriz.ContainsKey(claveReal))
            return matriz[claveReal];

        // 02. Coincidencia flexible: útil cuando AutoCAD devuelve nombres con prefijos,
        // sufijos, separadores, índices, estados dinámicos o nombres largos.
        // Ejemplo: "TOMACORRIENTE SIMPLE_01" debe tomar el patrón Excel
        // "TOMACORRIENTE SIMPLE".
        MapeoBloqueFamiliaMYG mejor = null;
        int mejorLongitud = -1;

        foreach (KeyValuePair<string, MapeoBloqueFamiliaMYG> kv in matriz)
        {
            string patron = kv.Key;

            if (string.IsNullOrWhiteSpace(patron))
                continue;

            bool coincide = false;

            if (claveReal.Contains(patron))
                coincide = true;
            else if (patron.Contains(claveReal))
                coincide = true;
            else
            {
                string patronCompacto = CompactarClaveCad(patron);
                string realCompacto = CompactarClaveCad(claveReal);

                if (!string.IsNullOrWhiteSpace(patronCompacto) && !string.IsNullOrWhiteSpace(realCompacto))
                {
                    if (realCompacto.Contains(patronCompacto) || patronCompacto.Contains(realCompacto))
                        coincide = true;
                }
            }

            if (!coincide)
                continue;

            if (patron.Length > mejorLongitud)
            {
                mejorLongitud = patron.Length;
                mejor = kv.Value;
            }
        }

        return mejor;
    }

    private string CompactarClaveCad(string texto)
    {
        if (string.IsNullOrWhiteSpace(texto))
            return "";

        string t = NormalizarClave(texto);

        t = t.Replace(" ", "");
        t = t.Replace("_", "");
        t = t.Replace("-", "");
        t = t.Replace(".", "");
        t = t.Replace("/", "");
        t = t.Replace("\\", "");
        t = t.Replace("(", "");
        t = t.Replace(")", "");
        t = t.Replace("[", "");
        t = t.Replace("]", "");
        t = t.Replace("$", "");

        return t.Trim();
    }

    // =========================================================
    // LECTURA DEL CAD ABIERTO EN AUTOCAD / CIVIL 3D
    // =========================================================

    private List<BloqueCadMYG> ObtenerBloquesCadDesdeImportInstance(
        Document doc,
        ImportInstance cad,
        Dictionary<string, MapeoBloqueFamiliaMYG> matriz)
    {
        List<BloqueCadMYG> resultado = new List<BloqueCadMYG>();

        if (doc == null || cad == null || matriz == null || matriz.Count == 0)
            return resultado;

        resultado = ObtenerBloquesCadDesdeAutoCadCom(doc, cad, matriz);

        if (resultado == null)
            resultado = new List<BloqueCadMYG>();

        return resultado;
    }

    private List<BloqueCadMYG> ObtenerBloquesCadDesdeAutoCadCom(
        Document doc,
        ImportInstance cad,
        Dictionary<string, MapeoBloqueFamiliaMYG> matriz)
    {
        List<BloqueCadMYG> resultado = new List<BloqueCadMYG>();

        if (doc == null || cad == null || matriz == null || matriz.Count == 0)
            return resultado;

        string rutaCad = ObtenerRutaCadDesdeImportInstance(doc, cad);

        if (string.IsNullOrWhiteSpace(rutaCad) || !File.Exists(rutaCad))
        {
            _ultimoDiagnosticoLecturaCad += "AutoCAD COM: no se pudo obtener una ruta DWG válida desde el CAD seleccionado.\r\n";
            return resultado;
        }

        object acadApp = null;
        object acadDoc = null;

        try
        {
            acadApp = ObtenerAplicacionAutoCadCom();

            if (acadApp == null)
            {
                _ultimoDiagnosticoLecturaCad += "AutoCAD COM: no se encontró AutoCAD/Civil 3D abierto.\r\n";
                return resultado;
            }

            acadDoc = ObtenerDocumentoAutoCadAbierto(acadApp, rutaCad);

            if (acadDoc == null)
            {
                _ultimoDiagnosticoLecturaCad +=
                    "AutoCAD COM: AutoCAD/Civil 3D está abierto, pero no se encontró abierto el mismo DWG vinculado/importado.\r\n" +
                    "Ruta esperada:\r\n" + rutaCad + "\r\n";
                return resultado;
            }

            resultado = LeerBloquesDesdeDocumentoCadCom(acadDoc, cad, matriz, "AutoCAD COM - Propiedades");

            if (resultado == null)
                resultado = new List<BloqueCadMYG>();

            if (resultado.Count == 0 || PuntosBloquesSospechosos(resultado))
            {
                List<BloqueCadMYG> resultadoLisp =
                    LeerBloquesDesdeAutoCadConLispCsv(acadDoc, cad, matriz);

                if (resultadoLisp != null && resultadoLisp.Count > 0 && !PuntosBloquesSospechosos(resultadoLisp))
                {
                    resultado = resultadoLisp;
                    _ultimoDiagnosticoLecturaCad += "AutoLISP/DXF: lectura aceptada.\r\n";
                }
            }

            _ultimoDiagnosticoLecturaCad +=
                "Bloques CAD coincidentes leídos = " + resultado.Count.ToString() + ".\r\n";
        }
        catch (Exception ex)
        {
            _ultimoDiagnosticoLecturaCad += "AutoCAD COM: error al leer bloques. " + ex.Message + "\r\n";
        }

        return resultado;
    }

    private List<BloqueCadMYG> LeerBloquesDesdeDocumentoCadCom(
        object acadDoc,
        ImportInstance cad,
        Dictionary<string, MapeoBloqueFamiliaMYG> matriz,
        string fuenteLectura)
    {
        List<BloqueCadMYG> resultado = new List<BloqueCadMYG>();

        if (acadDoc == null || cad == null || matriz == null || matriz.Count == 0)
            return resultado;

        double factorUnidadCadAPies = ObtenerFactorUnidadCadAPies(acadDoc);

        Transform transformCad = Transform.Identity;

        try
        {
            transformCad = cad.GetTransform();
        }
        catch
        {
            transformCad = Transform.Identity;
        }

        object modelSpace = ObtenerPropiedadCom(acadDoc, "ModelSpace");

        if (modelSpace == null)
            return resultado;

        foreach (object entidad in (System.Collections.IEnumerable)modelSpace)
        {
            if (entidad == null)
                continue;

            string objectName = ObtenerTextoPropiedadCom(entidad, "ObjectName");

            if (string.IsNullOrWhiteSpace(objectName))
                objectName = ObtenerTextoPropiedadCom(entidad, "EntityName");

            string objectNameNorm = NormalizarClave(objectName);

            if (!objectNameNorm.Contains("BLOCKREFERENCE") &&
                !objectNameNorm.Contains("INSERT") &&
                !objectNameNorm.Contains("MINSERT"))
            {
                continue;
            }

            string nombreBloqueReal = ObtenerTextoPropiedadCom(entidad, "EffectiveName");

            if (string.IsNullOrWhiteSpace(nombreBloqueReal))
                nombreBloqueReal = ObtenerTextoPropiedadCom(entidad, "Name");

            if (string.IsNullOrWhiteSpace(nombreBloqueReal))
                continue;

            MapeoBloqueFamiliaMYG mapeoDetectado = BuscarMapeoParaBloqueCad(matriz, nombreBloqueReal);

            if (mapeoDetectado == null)
                continue;

            double[] puntoCad = ObtenerPuntoPropiedadCom(entidad, "InsertionPoint");

            if (puntoCad == null || puntoCad.Length < 2)
                continue;

            double xCad = puntoCad[0];
            double yCad = puntoCad[1];
            double zCad = puntoCad.Length >= 3 ? puntoCad[2] : 0.0;

            XYZ puntoEnSimboloCad = new XYZ(
                xCad * factorUnidadCadAPies,
                yCad * factorUnidadCadAPies,
                zCad * factorUnidadCadAPies);

            XYZ puntoEnRevit = TransformarPuntoSeguro(transformCad, puntoEnSimboloCad);

            XYZ puntoBusqueda = ObtenerCentroBoundingBoxBloqueCom(entidad, factorUnidadCadAPies, transformCad, puntoEnRevit);

            double rotacion = ObtenerDoublePropiedadCom(entidad, "Rotation", 0.0);

            XYZ direccionCad = new XYZ(Math.Cos(rotacion), Math.Sin(rotacion), 0.0);
            XYZ direccionRevit = TransformarVectorSeguro(transformCad, direccionCad);

            try
            {
                if (direccionRevit.GetLength() > 0.000001)
                    direccionRevit = direccionRevit.Normalize();
                else
                    direccionRevit = XYZ.BasisX;
            }
            catch
            {
                direccionRevit = XYZ.BasisX;
            }

            BloqueCadMYG bloque = new BloqueCadMYG();
            bloque.NombreBloque = mapeoDetectado.NombreBloque;
            bloque.PuntoInsercion = puntoEnRevit;
            bloque.PuntoBusqueda = puntoBusqueda;
            bloque.DireccionX = direccionRevit;
            bloque.Transform = transformCad;
            bloque.FuenteLectura = fuenteLectura;

            resultado.Add(bloque);
        }

        return resultado;
    }

    private XYZ ObtenerCentroBoundingBoxBloqueCom(
        object entidad,
        double factorUnidadCadAPies,
        Transform transformCad,
        XYZ puntoDefecto)
    {
        if (entidad == null)
            return puntoDefecto;

        try
        {
            object[] args = new object[] { null, null };

            entidad.GetType().InvokeMember(
                "GetBoundingBox",
                BindingFlags.InvokeMethod,
                null,
                entidad,
                args);

            double[] min = ConvertirArrayDouble(args[0]);
            double[] max = ConvertirArrayDouble(args[1]);

            if (min == null || max == null || min.Length < 2 || max.Length < 2)
                return puntoDefecto;

            XYZ centroCad = new XYZ(
                ((min[0] + max[0]) * 0.5) * factorUnidadCadAPies,
                ((min[1] + max[1]) * 0.5) * factorUnidadCadAPies,
                ((min.Length >= 3 && max.Length >= 3 ? (min[2] + max[2]) * 0.5 : 0.0)) * factorUnidadCadAPies);

            return TransformarPuntoSeguro(transformCad, centroCad);
        }
        catch
        {
            return puntoDefecto;
        }
    }

    private double[] ConvertirArrayDouble(object valor)
    {
        try
        {
            Array arr = valor as Array;

            if (arr == null)
                return null;

            List<double> r = new List<double>();

            foreach (object o in arr)
                r.Add(Convert.ToDouble(o, System.Globalization.CultureInfo.InvariantCulture));

            return r.ToArray();
        }
        catch
        {
            return null;
        }
    }

    private List<BloqueCadMYG> LeerBloquesDesdeAutoCadConLispCsv(
        object acadDoc,
        ImportInstance cad,
        Dictionary<string, MapeoBloqueFamiliaMYG> matriz)
    {
        List<BloqueCadMYG> resultado = new List<BloqueCadMYG>();

        if (acadDoc == null || cad == null || matriz == null || matriz.Count == 0)
            return resultado;

        string rutaLisp = "";
        string rutaCsv = "";

        try
        {
            rutaLisp = CrearArchivoLispExportadorBloques54();

            if (string.IsNullOrWhiteSpace(rutaLisp) || !File.Exists(rutaLisp))
                return resultado;

            rutaCsv = Path.Combine(
                Path.GetTempPath(),
                "MYG_BloquesCAD54_Tomas_" + Guid.NewGuid().ToString("N") + ".txt");

            try
            {
                InvocarMetodoCom(acadDoc, "SetVariable", new object[] { "SECURELOAD", 0 });
                InvocarMetodoCom(acadDoc, "SetVariable", new object[] { "CMDECHO", 0 });
                InvocarMetodoCom(acadDoc, "Activate", null);
            }
            catch
            {
            }

            string comando =
                "(load \"" + RutaParaAutoLisp(rutaLisp) + "\")\n" +
                "(MYG_EXPORT_BLOCKS54 \"" + RutaParaAutoLisp(rutaCsv) + "\")\n";

            InvocarMetodoCom(acadDoc, "SendCommand", new object[] { comando });

            for (int i = 0; i < 150; i++)
            {
                if (File.Exists(rutaCsv) && new FileInfo(rutaCsv).Length > 0)
                {
                    System.Threading.Thread.Sleep(150);
                    break;
                }

                System.Threading.Thread.Sleep(100);
            }

            resultado = LeerBloquesDesdeCsvLispExportado54(rutaCsv, cad, acadDoc, matriz);
        }
        catch
        {
        }
        finally
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(rutaLisp) && File.Exists(rutaLisp))
                    File.Delete(rutaLisp);
            }
            catch
            {
            }

            try
            {
                if (!string.IsNullOrWhiteSpace(rutaCsv) && File.Exists(rutaCsv))
                    File.Delete(rutaCsv);
            }
            catch
            {
            }
        }

        return resultado ?? new List<BloqueCadMYG>();
    }

    private string CrearArchivoLispExportadorBloques54()
    {
        string ruta = Path.Combine(
            Path.GetTempPath(),
            "MYG_ExportBlocks54_Tomas_" + Guid.NewGuid().ToString("N") + ".lsp");

        string lisp =
@"(vl-load-com)
(defun MYG54_N2S (v)
  (if v
    (rtos v 2 16)
    ""0""
  )
)
(defun MYG54_CLEAN (s)
  (if (null s)
    (setq s """")
  )
  (setq s (vl-princ-to-string s))
  (setq s (vl-string-translate ""|"" ""_"" s))
  s
)
(defun MYG54_EFFNAME (obj ed / nm)
  (setq nm """")
  (if (vlax-property-available-p obj 'EffectiveName)
    (setq nm (vla-get-EffectiveName obj))
  )
  (if (= nm """")
    (if (vlax-property-available-p obj 'Name)
      (setq nm (vla-get-Name obj))
    )
  )
  (if (= nm """")
    (setq nm (cdr (assoc 2 ed)))
  )
  nm
)
(defun MYG_EXPORT_BLOCKS54 (ruta / doc ms f obj on en ed nm p rot z)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setq ms (vla-get-ModelSpace doc))
  (setq f (open ruta ""w""))
  (if f
    (progn
      (vlax-for obj ms
        (setq on (strcase (vla-get-ObjectName obj)))
        (if (or (wcmatch on ""*BLOCKREFERENCE*"") (wcmatch on ""*MINSERT*"") (wcmatch on ""*INSERT*""))
          (progn
            (setq en (vlax-vla-object->ename obj))
            (setq ed (entget en))
            (setq nm (MYG54_EFFNAME obj ed))
            (setq p (cdr (assoc 10 ed)))
            (setq rot (cdr (assoc 50 ed)))
            (if (null rot)
              (setq rot 0.0)
            )
            (if (and nm p)
              (progn
                (setq z 0.0)
                (if (caddr p)
                  (setq z (caddr p))
                )
                (write-line
                  (strcat
                    (MYG54_CLEAN nm) ""|""
                    (MYG54_N2S (car p)) ""|""
                    (MYG54_N2S (cadr p)) ""|""
                    (MYG54_N2S z) ""|""
                    (MYG54_N2S rot)
                  )
                  f
                )
              )
            )
          )
        )
      )
      (close f)
    )
  )
  (princ)
)
(princ)
";

        File.WriteAllText(ruta, lisp, System.Text.Encoding.ASCII);

        return ruta;
    }

    private List<BloqueCadMYG> LeerBloquesDesdeCsvLispExportado54(
        string rutaCsv,
        ImportInstance cad,
        object documentoCad,
        Dictionary<string, MapeoBloqueFamiliaMYG> matriz)
    {
        List<BloqueCadMYG> resultado = new List<BloqueCadMYG>();

        if (string.IsNullOrWhiteSpace(rutaCsv) || !File.Exists(rutaCsv))
            return resultado;

        double factorUnidadCadAPies = ObtenerFactorUnidadCadAPies(documentoCad);

        Transform transformCad = Transform.Identity;

        try
        {
            transformCad = cad.GetTransform();
        }
        catch
        {
            transformCad = Transform.Identity;
        }

        string[] lineas = File.ReadAllLines(rutaCsv);

        foreach (string linea in lineas)
        {
            if (string.IsNullOrWhiteSpace(linea))
                continue;

            string[] partes = linea.Split('|');

            if (partes == null || partes.Length < 5)
                continue;

            string nombreBloqueCsv = partes[0];

            MapeoBloqueFamiliaMYG mapeoDetectado = BuscarMapeoParaBloqueCad(matriz, nombreBloqueCsv);

            if (mapeoDetectado == null)
                continue;

            double xCad = ConvertirTextoDoubleFlexible(partes[1], 0.0);
            double yCad = ConvertirTextoDoubleFlexible(partes[2], 0.0);
            double zCad = ConvertirTextoDoubleFlexible(partes[3], 0.0);
            double rotacion = ConvertirTextoDoubleFlexible(partes[4], 0.0);

            XYZ puntoCad = new XYZ(
                xCad * factorUnidadCadAPies,
                yCad * factorUnidadCadAPies,
                zCad * factorUnidadCadAPies);

            XYZ puntoRevit = TransformarPuntoSeguro(transformCad, puntoCad);

            XYZ direccionCad = new XYZ(Math.Cos(rotacion), Math.Sin(rotacion), 0.0);
            XYZ direccionRevit = TransformarVectorSeguro(transformCad, direccionCad);

            try
            {
                if (direccionRevit.GetLength() > 0.000001)
                    direccionRevit = direccionRevit.Normalize();
                else
                    direccionRevit = XYZ.BasisX;
            }
            catch
            {
                direccionRevit = XYZ.BasisX;
            }

            BloqueCadMYG bloque = new BloqueCadMYG();
            bloque.NombreBloque = mapeoDetectado.NombreBloque;
            bloque.PuntoInsercion = puntoRevit;
            bloque.PuntoBusqueda = puntoRevit;
            bloque.DireccionX = direccionRevit;
            bloque.Transform = transformCad;
            bloque.FuenteLectura = "AutoLISP/DXF grupo 10";

            resultado.Add(bloque);
        }

        return resultado;
    }

    private string ObtenerRutaCadDesdeImportInstance(Document doc, ImportInstance cad)
    {
        if (doc == null || cad == null)
            return "";

        try
        {
            ElementId typeId = cad.GetTypeId();

            if (typeId == null || typeId == ElementId.InvalidElementId)
                return "";

            ExternalFileReference referencia = ExternalFileUtils.GetExternalFileReference(doc, typeId);

            if (referencia == null)
                return "";

            ModelPath path = referencia.GetAbsolutePath();

            if (path == null)
                return "";

            string ruta = ModelPathUtils.ConvertModelPathToUserVisiblePath(path);

            if (!string.IsNullOrWhiteSpace(ruta) && File.Exists(ruta))
                return ruta;
        }
        catch
        {
        }

        return "";
    }

    private object ObtenerAplicacionAutoCadCom()
    {
        string[] progIds = new string[]
        {
            "AutoCAD.Application",
            "AutoCAD.Application.25",
            "AutoCAD.Application.24.3",
            "AutoCAD.Application.24.2",
            "AutoCAD.Application.24.1",
            "AutoCAD.Application.24"
        };

        foreach (string progId in progIds)
        {
            object app = ObtenerObjetoComActivo(progId);

            if (app != null)
                return app;
        }

        return null;
    }

    private object ObtenerObjetoComActivo(string progId)
    {
        if (string.IsNullOrWhiteSpace(progId))
            return null;

        try
        {
            Guid clsid;
            int hr = CLSIDFromProgID(progId, out clsid);

            if (hr != 0 || clsid == Guid.Empty)
                return null;

            object obj;
            GetActiveObject(ref clsid, IntPtr.Zero, out obj);

            return obj;
        }
        catch
        {
            return null;
        }
    }

    [DllImport("ole32.dll", CharSet = CharSet.Unicode)]
    private static extern int CLSIDFromProgID(string progId, out Guid clsid);

    [DllImport("oleaut32.dll", PreserveSig = false)]
    private static extern void GetActiveObject(
        ref Guid rclsid,
        IntPtr pvReserved,
        [MarshalAs(UnmanagedType.IUnknown)] out object ppunk);

    private object ObtenerDocumentoAutoCadAbierto(object acadApp, string rutaCad)
    {
        if (acadApp == null || string.IsNullOrWhiteSpace(rutaCad))
            return null;

        object documentos = ObtenerPropiedadCom(acadApp, "Documents");

        if (documentos == null)
            return null;

        try
        {
            foreach (object docCad in (System.Collections.IEnumerable)documentos)
            {
                if (docCad == null)
                    continue;

                string nombreCompleto = ObtenerTextoPropiedadCom(docCad, "FullName");

                if (RutasCadCoinciden(nombreCompleto, rutaCad))
                    return docCad;
            }
        }
        catch
        {
        }

        return null;
    }

    private bool RutasCadCoinciden(string rutaA, string rutaB)
    {
        if (string.IsNullOrWhiteSpace(rutaA) || string.IsNullOrWhiteSpace(rutaB))
            return false;

        try
        {
            string a = Path.GetFullPath(rutaA).Trim();
            string b = Path.GetFullPath(rutaB).Trim();

            return string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
        }
        catch
        {
            return false;
        }
    }

    private double ObtenerFactorUnidadCadAPies(object acadDoc)
    {
        int insunits = 0;

        try
        {
            object valor = InvocarMetodoCom(acadDoc, "GetVariable", new object[] { "INSUNITS" });

            if (valor != null)
                insunits = Convert.ToInt32(valor);
        }
        catch
        {
            insunits = 0;
        }

        switch (insunits)
        {
            case 1: return 1.0 / 12.0;
            case 2: return 1.0;
            case 4: return 0.003280839895013123;
            case 5: return 0.03280839895013123;
            case 6: return 3.280839895013123;
            case 7: return 3280.839895013123;
            case 10: return 3.0;
            default: return 1.0;
        }
    }

    private object ObtenerPropiedadCom(object obj, string nombrePropiedad)
    {
        if (obj == null || string.IsNullOrWhiteSpace(nombrePropiedad))
            return null;

        try
        {
            return obj.GetType().InvokeMember(
                nombrePropiedad,
                BindingFlags.GetProperty,
                null,
                obj,
                null);
        }
        catch
        {
            return null;
        }
    }

    private object InvocarMetodoCom(object obj, string nombreMetodo, object[] argumentos)
    {
        if (obj == null || string.IsNullOrWhiteSpace(nombreMetodo))
            return null;

        try
        {
            return obj.GetType().InvokeMember(
                nombreMetodo,
                BindingFlags.InvokeMethod,
                null,
                obj,
                argumentos);
        }
        catch
        {
            return null;
        }
    }

    private string ObtenerTextoPropiedadCom(object obj, string nombrePropiedad)
    {
        object valor = ObtenerPropiedadCom(obj, nombrePropiedad);

        if (valor == null)
            return "";

        try
        {
            return valor.ToString().Trim();
        }
        catch
        {
            return "";
        }
    }

    private double ObtenerDoublePropiedadCom(object obj, string nombrePropiedad, double valorDefecto)
    {
        object valor = ObtenerPropiedadCom(obj, nombrePropiedad);

        if (valor == null)
            return valorDefecto;

        try
        {
            return Convert.ToDouble(valor, System.Globalization.CultureInfo.InvariantCulture);
        }
        catch
        {
            try
            {
                return Convert.ToDouble(valor);
            }
            catch
            {
                return valorDefecto;
            }
        }
    }

    private double[] ObtenerPuntoPropiedadCom(object obj, string nombrePropiedad)
    {
        object valor = ObtenerPropiedadCom(obj, nombrePropiedad);

        if (valor == null)
            return null;

        return ConvertirArrayDouble(valor);
    }

    private string RutaParaAutoLisp(string ruta)
    {
        if (string.IsNullOrWhiteSpace(ruta))
            return "";

        string r = ruta.Replace("\\", "/");
        r = r.Replace("\"", "");

        return r;
    }

    private double ConvertirTextoDoubleFlexible(string texto, double valorDefecto)
    {
        if (string.IsNullOrWhiteSpace(texto))
            return valorDefecto;

        double valor = valorDefecto;

        if (double.TryParse(
            texto.Trim(),
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture,
            out valor))
        {
            return valor;
        }

        if (double.TryParse(texto.Trim(), out valor))
            return valor;

        return valorDefecto;
    }

    // =========================================================
    // ORIENTACIÓN / PARÁMETROS / UTILIDADES
    // =========================================================

    private void OrientarFamiliaHaciaInterior(FamilyInstance instancia, XYZ direccionInteriorHost)
    {
        if (instancia == null || direccionInteriorHost == null)
            return;

        try
        {
            XYZ facing = instancia.FacingOrientation;

            if (facing == null || facing.GetLength() < 0.000001)
                return;

            XYZ f = new XYZ(facing.X, facing.Y, 0.0);
            XYZ d = new XYZ(direccionInteriorHost.X, direccionInteriorHost.Y, 0.0);

            if (f.GetLength() < 0.000001 || d.GetLength() < 0.000001)
                return;

            f = f.Normalize();
            d = d.Normalize();

            if (f.DotProduct(d) < 0.0)
                instancia.flipFacing();
        }
        catch
        {
        }
    }

    private XYZ ObtenerDireccionReferenciaSobreCara(XYZ direccionBase, XYZ normalCara)
    {
        if (normalCara == null)
            normalCara = XYZ.BasisY;

        XYZ dir = direccionBase;

        if (dir == null || dir.GetLength() < 0.000001)
            dir = XYZ.BasisZ;

        try
        {
            normalCara = normalCara.Normalize();
        }
        catch
        {
            normalCara = XYZ.BasisY;
        }

        XYZ proyectada = dir - normalCara.Multiply(dir.DotProduct(normalCara));

        if (proyectada.GetLength() < 0.000001)
        {
            dir = XYZ.BasisX;
            proyectada = dir - normalCara.Multiply(dir.DotProduct(normalCara));
        }

        if (proyectada.GetLength() < 0.000001)
        {
            dir = XYZ.BasisY;
            proyectada = dir - normalCara.Multiply(dir.DotProduct(normalCara));
        }

        try
        {
            return proyectada.Normalize();
        }
        catch
        {
            return XYZ.BasisZ;
        }
    }

    private void IntentarAsignarNivelYDesfaseTomacorriente(
        FamilyInstance instancia,
        Level nivelBase,
        double alturaSobreNivelFt)
    {
        if (instancia == null)
            return;

        if (nivelBase != null)
        {
            IntentarSetearParametroElementId(instancia, "FAMILY_LEVEL_PARAM", nivelBase.Id);
            IntentarSetearParametroElementId(instancia, "INSTANCE_REFERENCE_LEVEL_PARAM", nivelBase.Id);
            IntentarSetearParametroElementId(instancia, "INSTANCE_SCHEDULE_ONLY_LEVEL_PARAM", nivelBase.Id);
            IntentarSetearParametroPorNombreElementId(instancia, "Nivel", nivelBase.Id);
            IntentarSetearParametroPorNombreElementId(instancia, "Level", nivelBase.Id);
        }

        IntentarSetearParametroDouble(instancia, "INSTANCE_ELEVATION_PARAM", alturaSobreNivelFt);
        IntentarSetearParametroDouble(instancia, "INSTANCE_SILL_HEIGHT_PARAM", alturaSobreNivelFt);
        IntentarSetearParametroPorNombreDouble(instancia, "Altura", alturaSobreNivelFt);
        IntentarSetearParametroPorNombreDouble(instancia, "Elevation", alturaSobreNivelFt);
        IntentarSetearParametroPorNombreDouble(instancia, "Elevación", alturaSobreNivelFt);
        IntentarSetearParametroPorNombreDouble(instancia, "Elevacion", alturaSobreNivelFt);
        IntentarSetearParametroPorNombreDouble(instancia, "Altura de montaje", alturaSobreNivelFt);
    }

    private void IntentarSetearParametroElementId(Element elemento, string nombreBuiltIn, ElementId valor)
    {
        if (elemento == null || valor == null || valor == ElementId.InvalidElementId)
            return;

        Parameter p = ObtenerParametroBuiltInPorNombre(elemento, nombreBuiltIn);

        if (p == null || p.IsReadOnly || p.StorageType != StorageType.ElementId)
            return;

        try
        {
            p.Set(valor);
        }
        catch
        {
        }
    }

    private void IntentarSetearParametroDouble(Element elemento, string nombreBuiltIn, double valor)
    {
        if (elemento == null)
            return;

        Parameter p = ObtenerParametroBuiltInPorNombre(elemento, nombreBuiltIn);

        if (p == null || p.IsReadOnly || p.StorageType != StorageType.Double)
            return;

        try
        {
            p.Set(valor);
        }
        catch
        {
        }
    }

    private Parameter ObtenerParametroBuiltInPorNombre(Element elemento, string nombreBuiltIn)
    {
        if (elemento == null || string.IsNullOrWhiteSpace(nombreBuiltIn))
            return null;

        try
        {
            BuiltInParameter bip = (BuiltInParameter)Enum.Parse(typeof(BuiltInParameter), nombreBuiltIn);
            return elemento.get_Parameter(bip);
        }
        catch
        {
            return null;
        }
    }

    private void IntentarSetearParametroPorNombreElementId(Element elemento, string nombreParametro, ElementId valor)
    {
        if (elemento == null || string.IsNullOrWhiteSpace(nombreParametro) || valor == null || valor == ElementId.InvalidElementId)
            return;

        try
        {
            Parameter p = elemento.LookupParameter(nombreParametro);

            if (p != null && !p.IsReadOnly && p.StorageType == StorageType.ElementId)
                p.Set(valor);
        }
        catch
        {
        }
    }

    private void IntentarSetearParametroPorNombreDouble(Element elemento, string nombreParametro, double valor)
    {
        if (elemento == null || string.IsNullOrWhiteSpace(nombreParametro))
            return;

        try
        {
            Parameter p = elemento.LookupParameter(nombreParametro);

            if (p != null && !p.IsReadOnly && p.StorageType == StorageType.Double)
                p.Set(valor);
        }
        catch
        {
        }
    }

    private void AsignarTextoParametroSiExiste(Element elemento, string nombreParametro, string valor)
    {
        if (elemento == null || string.IsNullOrWhiteSpace(nombreParametro))
            return;

        try
        {
            Parameter p = elemento.LookupParameter(nombreParametro);

            if (p == null || p.IsReadOnly)
                return;

            if (p.StorageType == StorageType.String)
                p.Set(valor ?? "");
        }
        catch
        {
        }
    }

    private bool EsRoomOSpace(Element elem)
    {
        if (elem == null)
            return false;

        return elem is Room || elem is Space;
    }

    private string ObtenerNombreElementoEspacial(Element elem, bool esDeVinculo)
    {
        if (elem == null)
            return "";

        try
        {
            Room room = elem as Room;

            if (room != null)
                return (esDeVinculo ? "[V] " : "") + (room.Number + " " + room.Name).Trim();

            Space space = elem as Space;

            if (space != null)
                return (esDeVinculo ? "[V] " : "") + (space.Number + " " + space.Name).Trim();

            return (esDeVinculo ? "[V] " : "") + elem.Id.Value.ToString();
        }
        catch
        {
            return "";
        }
    }

    private double ObtenerElevacionElementoEspacial(SpatialElement elem)
    {
        if (elem == null || elem.Document == null)
            return 0.0;

        try
        {
            Level nivel = elem.Document.GetElement(elem.LevelId) as Level;

            if (nivel != null)
                return nivel.Elevation;
        }
        catch
        {
        }

        return 0.0;
    }

    private bool PuntoDentroDeElementoEspacial(HabitacionCandidataMYG h, XYZ puntoLocal)
    {
        if (h == null || h.ElementoEspacial == null || puntoLocal == null)
            return false;

        try
        {
            Room r = h.ElementoEspacial as Room;

            if (r != null)
                return r.IsPointInRoom(puntoLocal);

            Space s = h.ElementoEspacial as Space;

            if (s != null)
                return s.IsPointInSpace(puntoLocal);
        }
        catch
        {
        }

        return false;
    }

    private XYZ ObtenerPuntoMasCercanoEnCurva(Curve curva, XYZ punto)
    {
        if (curva == null || punto == null)
            return null;

        try
        {
            XYZ pPlano = new XYZ(
                punto.X,
                punto.Y,
                curva.GetEndPoint(0).Z);

            IntersectionResult proy = curva.Project(pPlano);

            if (proy != null && proy.XYZPoint != null)
                return proy.XYZPoint;
        }
        catch
        {
        }

        try
        {
            XYZ a = curva.GetEndPoint(0);
            XYZ b = curva.GetEndPoint(1);

            double da = DistanciaXY(a, punto);
            double db = DistanciaXY(b, punto);

            return da <= db ? a : b;
        }
        catch
        {
            return null;
        }
    }

    private XYZ TransformarPuntoHostADocumento(HabitacionCandidataMYG h, XYZ puntoHost)
    {
        if (h == null || puntoHost == null)
            return puntoHost;

        if (!h.EsDeVinculo || h.TransformHostADoc == null)
            return puntoHost;

        try
        {
            return h.TransformHostADoc.OfPoint(puntoHost);
        }
        catch
        {
            return puntoHost;
        }
    }

    private XYZ TransformarPuntoDocumentoAHost(HabitacionCandidataMYG h, XYZ puntoDocumento)
    {
        if (h == null || puntoDocumento == null)
            return puntoDocumento;

        if (!h.EsDeVinculo || h.TransformDocAHost == null)
            return puntoDocumento;

        try
        {
            return h.TransformDocAHost.OfPoint(puntoDocumento);
        }
        catch
        {
            return puntoDocumento;
        }
    }

    private XYZ TransformarVectorDocumentoAHost(HabitacionCandidataMYG h, XYZ vectorDocumento)
    {
        if (h == null || vectorDocumento == null)
            return vectorDocumento;

        if (!h.EsDeVinculo || h.TransformDocAHost == null)
            return vectorDocumento;

        try
        {
            return h.TransformDocAHost.OfVector(vectorDocumento);
        }
        catch
        {
            return vectorDocumento;
        }
    }

    private XYZ TransformarPuntoSeguro(Transform tr, XYZ p)
    {
        if (tr == null || p == null)
            return p;

        try
        {
            return tr.OfPoint(p);
        }
        catch
        {
            return p;
        }
    }

    private XYZ TransformarVectorSeguro(Transform tr, XYZ v)
    {
        if (tr == null || v == null)
            return v;

        try
        {
            return tr.OfVector(v);
        }
        catch
        {
            return v;
        }
    }

    private bool PuntosBloquesSospechosos(List<BloqueCadMYG> bloques)
    {
        if (bloques == null || bloques.Count <= 1)
            return false;

        Dictionary<string, int> conteoPorPunto = new Dictionary<string, int>();

        foreach (BloqueCadMYG b in bloques)
        {
            if (b == null || b.PuntoBusquedaSeguro() == null)
                continue;

            string clave = CrearClavePuntoXYZ(b.PuntoBusquedaSeguro(), 0.005);

            if (!conteoPorPunto.ContainsKey(clave))
                conteoPorPunto.Add(clave, 0);

            conteoPorPunto[clave]++;
        }

        if (conteoPorPunto.Count == 0)
            return true;

        int maxRepetidos = conteoPorPunto.Values.Max();
        int limiteMayor = Math.Max(5, (int)Math.Ceiling(bloques.Count * 0.80));

        if (conteoPorPunto.Count == 1)
            return true;

        if (maxRepetidos >= limiteMayor)
            return true;

        return false;
    }

    private string ValidarPuntosBloquesCad(List<BloqueCadMYG> bloques)
    {
        if (bloques == null || bloques.Count <= 1)
            return "";

        if (!PuntosBloquesSospechosos(bloques))
            return "";

        return
            "ERROR:\r\n" +
            "Los bloques CAD detectados tienen puntos repetidos o sospechosos.\r\n\r\n" +
            "Fuente de lectura: " + ObtenerFuenteLecturaResumen(bloques) + "\r\n" +
            "Bloques detectados: " + bloques.Count.ToString() + "\r\n\r\n" +
            "Se canceló la creación para evitar tomacorrientes superpuestos.";
    }

    private string CrearClavePuntoXYZ(XYZ p, double toleranciaPies)
    {
        if (p == null)
            return "NULL";

        if (toleranciaPies <= 0.0000001)
            toleranciaPies = 0.005;

        long x = (long)Math.Round(p.X / toleranciaPies);
        long y = (long)Math.Round(p.Y / toleranciaPies);
        long z = (long)Math.Round(p.Z / toleranciaPies);

        return x.ToString() + "|" + y.ToString() + "|" + z.ToString();
    }


    private string ObtenerResumenBloquesPorPatron(List<BloqueCadMYG> bloques)
    {
        if (bloques == null || bloques.Count == 0)
            return "";

        try
        {
            List<string> partes = bloques
                .Where(x => x != null && !string.IsNullOrWhiteSpace(x.NombreBloque))
                .GroupBy(x => x.NombreBloque)
                .OrderBy(x => x.Key)
                .Select(x => x.Key + "=" + x.Count().ToString())
                .ToList();

            if (partes.Count == 0)
                return "";

            return string.Join(" | ", partes);
        }
        catch
        {
            return "";
        }
    }

    private string ObtenerFuenteLecturaResumen(List<BloqueCadMYG> bloques)
    {
        if (bloques == null || bloques.Count == 0)
            return "";

        try
        {
            List<string> fuentes = bloques
                .Where(x => x != null && !string.IsNullOrWhiteSpace(x.FuenteLectura))
                .Select(x => x.FuenteLectura)
                .Distinct()
                .ToList();

            if (fuentes.Count == 0)
                return "";

            return string.Join(", ", fuentes);
        }
        catch
        {
            return "";
        }
    }

    private double DistanciaXY(XYZ a, XYZ b)
    {
        if (a == null || b == null)
            return double.MaxValue;

        double dx = a.X - b.X;
        double dy = a.Y - b.Y;

        return Math.Sqrt(dx * dx + dy * dy);
    }

    private string NormalizarClave(string texto)
    {
        if (string.IsNullOrWhiteSpace(texto))
            return "";

        string limpio = texto.Trim().ToUpperInvariant();

        limpio = limpio.Replace("Á", "A");
        limpio = limpio.Replace("É", "E");
        limpio = limpio.Replace("Í", "I");
        limpio = limpio.Replace("Ó", "O");
        limpio = limpio.Replace("Ú", "U");
        limpio = limpio.Replace("Ü", "U");
        limpio = limpio.Replace("Ñ", "N");

        limpio = limpio.Replace("\r", " ");
        limpio = limpio.Replace("\n", " ");
        limpio = limpio.Replace("\t", " ");

        while (limpio.Contains("  "))
            limpio = limpio.Replace("  ", " ");

        return limpio.Trim();
    }

    private double MetrosAPies(double metros)
    {
        return metros / 0.3048;
    }

    private double PiesAMetros(double pies)
    {
        return pies * 0.3048;
    }

    private void MostrarEnVentana(string mensaje)
    {
        try
        {
            if (Form != null && !Form.IsDisposed)
                Form.MostrarResultado(mensaje);
        }
        catch
        {
        }
    }

    // =========================================================
    // CLASES INTERNAS
    // =========================================================

    private class MapeoBloqueFamiliaMYG
    {
        public string NombreBloque { get; set; }
        public string NombreTipoFamilia { get; set; }
    }

    private class BloqueCadMYG
    {
        public string NombreBloque { get; set; }
        public XYZ PuntoInsercion { get; set; }
        public XYZ PuntoBusqueda { get; set; }
        public XYZ DireccionX { get; set; }
        public Transform Transform { get; set; }
        public string FuenteLectura { get; set; }

        public XYZ PuntoInsercionSeguro()
        {
            if (PuntoInsercion != null)
                return PuntoInsercion;

            if (PuntoBusqueda != null)
                return PuntoBusqueda;

            return XYZ.Zero;
        }

        public XYZ PuntoBusquedaSeguro()
        {
            if (PuntoBusqueda != null)
                return PuntoBusqueda;

            if (PuntoInsercion != null)
                return PuntoInsercion;

            return XYZ.Zero;
        }
    }

    private class HabitacionCandidataMYG
    {
        public Document Documento { get; set; }
        public SpatialElement ElementoEspacial { get; set; }
        public bool EsDeVinculo { get; set; }
        public RevitLinkInstance LinkInstance { get; set; }
        public Transform TransformDocAHost { get; set; }
        public Transform TransformHostADoc { get; set; }
    }

    private class SegmentoHabitacionMYG
    {
        public HabitacionCandidataMYG Habitacion { get; set; }
        public Document DocumentoMuro { get; set; }
        public bool EsDeVinculo { get; set; }
        public RevitLinkInstance LinkInstance { get; set; }
        public Transform TransformDocAHost { get; set; }
        public Transform TransformHostADoc { get; set; }
        public Wall Muro { get; set; }
        public Curve Curva { get; set; }
        public XYZ PuntoMasCercanoLocal { get; set; }
        public XYZ PuntoMasCercanoHost { get; set; }
        public double Distancia { get; set; }
    }

    private class CaraMuroObjetivoMYG
    {
        public Reference Referencia { get; set; }
        public XYZ PuntoEnCara { get; set; }
        public XYZ NormalInterior { get; set; }
        public ElementId MuroId { get; set; }
        public ElementId LinkInstanceId { get; set; }
        public bool EsDeVinculo { get; set; }
        public double Distancia { get; set; }
    }

    private class FiltroSeleccionCadImportInstanceMYG : ISelectionFilter
    {
        public bool AllowElement(Element elem)
        {
            if (elem == null)
                return false;

            return elem is ImportInstance;
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            return false;
        }
    }

    private class FiltroSeleccionRoomSpaceNativoMYG : ISelectionFilter
    {
        public bool AllowElement(Element elem)
        {
            if (elem == null)
                return false;

            return elem is Room || elem is Space;
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            return true;
        }
    }

    private class FiltroSeleccionRoomSpaceVinculoMYG : ISelectionFilter
    {
        private Document _docHost;

        public FiltroSeleccionRoomSpaceVinculoMYG(Document docHost)
        {
            _docHost = docHost;
        }

        public bool AllowElement(Element elem)
        {
            return elem is RevitLinkInstance;
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            if (_docHost == null || reference == null)
                return false;

            try
            {
                if (reference.ElementId == null ||
                    reference.ElementId == ElementId.InvalidElementId ||
                    reference.LinkedElementId == null ||
                    reference.LinkedElementId == ElementId.InvalidElementId)
                {
                    return false;
                }

                RevitLinkInstance link = _docHost.GetElement(reference.ElementId) as RevitLinkInstance;

                if (link == null)
                    return false;

                Document linkDoc = link.GetLinkDocument();

                if (linkDoc == null)
                    return false;

                Element elem = linkDoc.GetElement(reference.LinkedElementId);

                return elem is Room || elem is Space;
            }
            catch
            {
                return false;
            }
        }
    }
}
