using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{


    // =====================================
    // COMANDO 5.4 - CAD BLOQUES A FAMILIAS
    // V3 - MAIN CON FRANJA LATERAL + LUMINARIAS + TOMACORRIENTES
    // SIN USING / SIN NAMESPACE
    // =====================================

    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class CrearFamiliasDesdeBloquesCad54Command : Autodesk.Revit.UI.IExternalCommand
    {
        private static CrearFamiliasDesdeBloquesCad54MainForm _mainForm;

        private static CrearFamiliasDesdeBloquesCad54Form _formLuminarias;
        private static EjecutarCrearFamiliasDesdeBloquesCad54Handler _handlerLuminarias;
        private static Autodesk.Revit.UI.ExternalEvent _eventLuminarias;

        private static CrearTomacorrientesDesdeBloquesCad54Form _formTomacorrientes;
        private static EjecutarCrearTomacorrientesDesdeBloquesCad54Handler _handlerTomacorrientes;
        private static Autodesk.Revit.UI.ExternalEvent _eventTomacorrientes;

        public Autodesk.Revit.UI.Result Execute(
            Autodesk.Revit.UI.ExternalCommandData commandData,
            ref string message,
            Autodesk.Revit.DB.ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            try
            {
                Autodesk.Revit.UI.UIApplication uiapp = commandData.Application;
                Autodesk.Revit.UI.UIDocument uidoc = uiapp.ActiveUIDocument;

                if (uidoc == null || uidoc.Document == null)
                {
                    message = "No hay documento activo.";
                    return Autodesk.Revit.UI.Result.Failed;
                }

                if (_mainForm == null || _mainForm.IsDisposed)
                {
                    _handlerLuminarias = new EjecutarCrearFamiliasDesdeBloquesCad54Handler();
                    _handlerLuminarias.UiDoc = uidoc;
                    _eventLuminarias = Autodesk.Revit.UI.ExternalEvent.Create(_handlerLuminarias);
                    _formLuminarias = new CrearFamiliasDesdeBloquesCad54Form(uidoc);
                    _formLuminarias.Handler = _handlerLuminarias;
                    _formLuminarias.EjecutarEvent = _eventLuminarias;
                    _handlerLuminarias.Form = _formLuminarias;

                    _handlerTomacorrientes = new EjecutarCrearTomacorrientesDesdeBloquesCad54Handler();
                    _handlerTomacorrientes.UiDoc = uidoc;
                    _eventTomacorrientes = Autodesk.Revit.UI.ExternalEvent.Create(_handlerTomacorrientes);
                    _formTomacorrientes = new CrearTomacorrientesDesdeBloquesCad54Form(uidoc);
                    _formTomacorrientes.Handler = _handlerTomacorrientes;
                    _formTomacorrientes.EjecutarEvent = _eventTomacorrientes;
                    _handlerTomacorrientes.Form = _formTomacorrientes;

                    _mainForm = new CrearFamiliasDesdeBloquesCad54MainForm(
                        uidoc,
                        _formLuminarias,
                        _handlerLuminarias,
                        _eventLuminarias,
                        _formTomacorrientes,
                        _handlerTomacorrientes,
                        _eventTomacorrientes);

                    _mainForm.FormClosed += (s, e) =>
                    {
                        _mainForm = null;

                        _formLuminarias = null;
                        _handlerLuminarias = null;
                        _eventLuminarias = null;

                        _formTomacorrientes = null;
                        _handlerTomacorrientes = null;
                        _eventTomacorrientes = null;
                    };
                }
                else
                {
                    if (_handlerLuminarias != null)
                        _handlerLuminarias.UiDoc = uidoc;

                    if (_handlerTomacorrientes != null)
                        _handlerTomacorrientes.UiDoc = uidoc;
                }

                if (!_mainForm.Visible)
                {
                    RevitWindowHandle handle = new RevitWindowHandle(uiapp.MainWindowHandle);
                    _mainForm.Show(handle);
                }
                else
                {
                    _mainForm.Activate();
                }

                return Autodesk.Revit.UI.Result.Succeeded;
            }
            catch (System.Exception ex)
            {
                message = ex.Message;
                return Autodesk.Revit.UI.Result.Failed;
            }
        }

        private class RevitWindowHandle : System.Windows.Forms.IWin32Window
        {
            private readonly System.IntPtr _handle;

            public RevitWindowHandle(System.IntPtr handle)
            {
                _handle = handle;
            }

            public System.IntPtr Handle
            {
                get { return _handle; }
            }
        }
    }

}
