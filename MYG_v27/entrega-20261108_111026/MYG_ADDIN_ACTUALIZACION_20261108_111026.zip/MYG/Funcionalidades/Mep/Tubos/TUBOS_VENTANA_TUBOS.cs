﻿// =====================================
// VENTANA 5.5 - TUBOS AUTOMÁTICOS ENTRE CONECTORES
// V16 - EMBEBIBLE EN MAIN + GUARDA ÚLTIMA CONFIGURACIÓN
// =====================================

using MYG_Addin;

public class EleTubosAutomaticos55Form : System.Windows.Forms.Form
{
    private readonly EjecutarEleTubosAutomaticos55Handler _handler;
    private readonly Autodesk.Revit.UI.ExternalEvent _externalEvent;

    private System.Windows.Forms.Button btnCrearTubos;
    private System.Windows.Forms.Button btnRedistribuirCara;

    private System.Windows.Forms.ComboBox cmbTipoConduit;
    private System.Windows.Forms.ComboBox cmbModoRuta;

    private System.Windows.Forms.Label lblAlturaLibre;
    private System.Windows.Forms.Label lblRetiroMuro;

    private System.Windows.Forms.NumericUpDown nudDiametroMm;
    private System.Windows.Forms.NumericUpDown nudAlturaLibreM;
    private System.Windows.Forms.NumericUpDown nudRetiroMuroM;
    private System.Windows.Forms.NumericUpDown nudToleranciaMm;
    private System.Windows.Forms.NumericUpDown nudSeparacionCaraM;
    private System.Windows.Forms.NumericUpDown nudMargenCaraM;
    private System.Windows.Forms.NumericUpDown nudLongitudAcomodoM;

    private System.Windows.Forms.CheckBox chkCrearCodos;
    private System.Windows.Forms.CheckBox chkConectarExtremos;
    private System.Windows.Forms.CheckBox chkInvertirRetiroMuro;
    private System.Windows.Forms.CheckBox chkBorrarAnteriores;
    private System.Windows.Forms.CheckBox chkSeleccionarResultado;

    private System.Windows.Forms.RichTextBox txtResultado;

    private const string ArchivoConfigNombre = "MYG_TubosAutomaticos55_Config.ini";
    private long _tipoConduitIdGuardado = -1;
    private string _tipoConduitTextoGuardado = "";
    private string _modoRutaTextoGuardado = "";
    private bool _configuracionYaCargada = false;

    public EleTubosAutomaticos55Form(
        EjecutarEleTubosAutomaticos55Handler handler,
        Autodesk.Revit.UI.ExternalEvent externalEvent)
    {
        _handler = handler;
        _externalEvent = externalEvent;

        this.Text = "Tubos rígidos automáticos";
        this.Width = 760;
        this.Height = 735;
        this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
        this.TopLevel = false;
        this.ShowInTaskbar = false;
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.Dock = System.Windows.Forms.DockStyle.Fill;
        this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
        this.Font = new System.Drawing.Font("Segoe UI", 9F);
        this.TopMost = false;

        InicializarComponentes();
        this.FormClosing += (s, e) => GuardarConfiguracion();
    }

    private void InicializarComponentes()
    {
        System.Windows.Forms.Label lblAutor = new System.Windows.Forms.Label()
        {
            Text = "Creado por: Ing. Marlon Yacila  |  MEP - Tubos automáticos entre conectores",
            Left = 20,
            Top = 10,
            Width = 700,
            Height = 20,
            Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
            ForeColor = System.Drawing.Color.Gray
        };

        System.Windows.Forms.Label lblTitulo = new System.Windows.Forms.Label()
        {
            Text = "01. CONFIGURACIÓN DEL TUBO",
            Left = 20,
            Top = 42,
            Width = 700,
            Height = 22,
            Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
            ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
        };

        System.Windows.Forms.Label lblInfo = new System.Windows.Forms.Label()
        {
            Text = "Configura el tipo de tubo y presiona CREAR TUBOS. Para tomacorrientes pica los conectores inferiores: primero baja, luego sale del muro a 90° y une ambos extremos.",
            Left = 20,
            Top = 68,
            Width = 700,
            Height = 48,
            ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
        };

        System.Windows.Forms.Label lblTipo = new System.Windows.Forms.Label()
        {
            Text = "Tipo de tubo / conduit:",
            Left = 20,
            Top = 132,
            Width = 170,
            Height = 22
        };

        cmbTipoConduit = new System.Windows.Forms.ComboBox()
        {
            Left = 190,
            Top = 129,
            Width = 520,
            Height = 24,
            DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown,
            AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend,
            AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        };

        System.Windows.Forms.Label lblDiametro = new System.Windows.Forms.Label()
        {
            Text = "Diámetro nominal (mm):",
            Left = 20,
            Top = 174,
            Width = 170,
            Height = 22
        };

        nudDiametroMm = new System.Windows.Forms.NumericUpDown()
        {
            Left = 190,
            Top = 171,
            Width = 85,
            Height = 24,
            DecimalPlaces = 1,
            Increment = 1,
            Minimum = 1,
            Maximum = 300,
            Value = 20
        };

        lblAlturaLibre = new System.Windows.Forms.Label()
        {
            Text = "Altura libre (m):",
            Left = 315,
            Top = 174,
            Width = 180,
            Height = 22
        };

        nudAlturaLibreM = new System.Windows.Forms.NumericUpDown()
        {
            Left = 500,
            Top = 171,
            Width = 85,
            Height = 24,
            DecimalPlaces = 3,
            Increment = 0.050M,
            Minimum = 0,
            Maximum = 20,
            Value = 0.300M
        };

        System.Windows.Forms.Label lblTol = new System.Windows.Forms.Label()
        {
            Text = "Tol. alineación (mm):",
            Left = 20,
            Top = 212,
            Width = 170,
            Height = 22
        };

        nudToleranciaMm = new System.Windows.Forms.NumericUpDown()
        {
            Left = 190,
            Top = 209,
            Width = 85,
            Height = 24,
            DecimalPlaces = 1,
            Increment = 1,
            Minimum = 1,
            Maximum = 500,
            Value = 15
        };

        System.Windows.Forms.Label lblModo = new System.Windows.Forms.Label()
        {
            Text = "Modo de ruta:",
            Left = 315,
            Top = 212,
            Width = 180,
            Height = 22
        };

        cmbModoRuta = new System.Windows.Forms.ComboBox()
        {
            Left = 500,
            Top = 209,
            Width = 210,
            Height = 24,
            DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown,
            AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend,
            AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        };

        cmbModoRuta.Items.Add("Automático - salida directa");
        cmbModoRuta.Items.Add("Directo si alineados");
        cmbModoRuta.Items.Add("Ruta L");
        cmbModoRuta.Items.Add("Ruta Z");
        cmbModoRuta.Items.Add("Tomacorrientes por cara");
        cmbModoRuta.SelectedIndex = 0;
        cmbModoRuta.SelectedIndexChanged += (s, e) => ActualizarEstadoTomacorrientes();

        lblRetiroMuro = new System.Windows.Forms.Label()
        {
            Text = "Retiro muro (m):",
            Left = 315,
            Top = 247,
            Width = 180,
            Height = 22,
            ForeColor = System.Drawing.Color.Gray
        };

        nudRetiroMuroM = new System.Windows.Forms.NumericUpDown()
        {
            Left = 500,
            Top = 244,
            Width = 85,
            Height = 24,
            DecimalPlaces = 3,
            Increment = 0.010M,
            Minimum = 0,
            Maximum = 5,
            Value = 0.025M,
            Enabled = false
        };

        chkInvertirRetiroMuro = new System.Windows.Forms.CheckBox()
        {
            Text = "Invertir retiro",
            Left = 595,
            Top = 245,
            Width = 120,
            Height = 24,
            Checked = false,
            Enabled = false
        };

        System.Windows.Forms.Label lblOpciones = new System.Windows.Forms.Label()
        {
            Text = "02. OPCIONES DE GENERACIÓN",
            Left = 20,
            Top = 306,
            Width = 700,
            Height = 22,
            Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
            ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
        };

        chkCrearCodos = new System.Windows.Forms.CheckBox()
        {
            Text = "Crear codos automáticos en cambios de dirección",
            Left = 20,
            Top = 338,
            Width = 360,
            Height = 24,
            Checked = true
        };

        chkConectarExtremos = new System.Windows.Forms.CheckBox()
        {
            Text = "Conectar extremos a los conectores picados",
            Left = 390,
            Top = 338,
            Width = 320,
            Height = 24,
            Checked = true
        };

        chkBorrarAnteriores = new System.Windows.Forms.CheckBox()
        {
            Text = "Borrar tubos anteriores creados por esta herramienta al iniciar",
            Left = 20,
            Top = 366,
            Width = 370,
            Height = 24,
            Checked = false
        };

        chkSeleccionarResultado = new System.Windows.Forms.CheckBox()
        {
            Text = "Seleccionar tubos y fittings creados en Revit al terminar",
            Left = 390,
            Top = 366,
            Width = 340,
            Height = 24,
            Checked = true
        };

        System.Windows.Forms.Label lblRedistribucion = new System.Windows.Forms.Label()
        {
            Text = "03. REDISTRIBUCIÓN EN TABLERO / CARA",
            Left = 20,
            Top = 410,
            Width = 700,
            Height = 22,
            Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
            ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
        };

        System.Windows.Forms.Label lblSepCara = new System.Windows.Forms.Label()
        {
            Text = "Separación mínima (m):",
            Left = 20,
            Top = 445,
            Width = 170,
            Height = 22
        };

        nudSeparacionCaraM = new System.Windows.Forms.NumericUpDown()
        {
            Left = 190,
            Top = 442,
            Width = 85,
            Height = 24,
            DecimalPlaces = 3,
            Increment = 0.010M,
            Minimum = 0.010M,
            Maximum = 2,
            Value = 0.050M
        };

        System.Windows.Forms.Label lblMargenCara = new System.Windows.Forms.Label()
        {
            Text = "Margen lateral (m):",
            Left = 315,
            Top = 445,
            Width = 180,
            Height = 22
        };

        nudMargenCaraM = new System.Windows.Forms.NumericUpDown()
        {
            Left = 500,
            Top = 442,
            Width = 85,
            Height = 24,
            DecimalPlaces = 3,
            Increment = 0.010M,
            Minimum = 0,
            Maximum = 5,
            Value = 0.100M
        };

        System.Windows.Forms.Label lblLongitud = new System.Windows.Forms.Label()
        {
            Text = "Longitud de acomodo (m):",
            Left = 20,
            Top = 480,
            Width = 170,
            Height = 22
        };

        nudLongitudAcomodoM = new System.Windows.Forms.NumericUpDown()
        {
            Left = 190,
            Top = 477,
            Width = 85,
            Height = 24,
            DecimalPlaces = 3,
            Increment = 0.050M,
            Minimum = 0.050M,
            Maximum = 10,
            Value = 0.500M
        };

        System.Windows.Forms.Label lblInfoRedistribuir = new System.Windows.Forms.Label()
        {
            Text = "Después de crear los tubos, pica la cara del tablero. Solo se ajusta el extremo cercano al tablero; no mueve los aparatos eléctricos.",
            Left = 315,
            Top = 478,
            Width = 395,
            Height = 36,
            ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
        };

        System.Windows.Forms.Label lblResultado = new System.Windows.Forms.Label()
        {
            Text = "04. RESULTADO",
            Left = 20,
            Top = 530,
            Width = 700,
            Height = 22,
            Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
            ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
        };

        txtResultado = new System.Windows.Forms.RichTextBox()
        {
            Left = 20,
            Top = 558,
            Width = 690,
            Height = 70,
            ReadOnly = true,
            BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
            BackColor = System.Drawing.Color.White,
            Font = new System.Drawing.Font("Consolas", 8.5F),
            WordWrap = false,
            ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        };

        btnCrearTubos = CrearBoton(
            "CREAR TUBOS",
            130,
            642,
            220,
            System.Drawing.Color.FromArgb(0, 120, 215));

        btnRedistribuirCara = CrearBoton(
            "REDISTRIBUIR EN CARA",
            390,
            642,
            240,
            System.Drawing.Color.FromArgb(90, 90, 90));

        btnCrearTubos.Height = 40;
        btnRedistribuirCara.Height = 40;

        btnCrearTubos.Click += (s, e) => EjecutarCreacionRapida();
        btnRedistribuirCara.Click += (s, e) => EjecutarRedistribucionCara();

        this.Controls.Add(lblAutor);
        this.Controls.Add(lblTitulo);
        this.Controls.Add(lblInfo);

        this.Controls.Add(lblTipo);
        this.Controls.Add(cmbTipoConduit);
        this.Controls.Add(lblDiametro);
        this.Controls.Add(nudDiametroMm);
        this.Controls.Add(lblAlturaLibre);
        this.Controls.Add(nudAlturaLibreM);
        this.Controls.Add(lblTol);
        this.Controls.Add(nudToleranciaMm);
        this.Controls.Add(lblModo);
        this.Controls.Add(cmbModoRuta);
        this.Controls.Add(lblRetiroMuro);
        this.Controls.Add(nudRetiroMuroM);
        this.Controls.Add(chkInvertirRetiroMuro);

        this.Controls.Add(lblOpciones);
        this.Controls.Add(chkCrearCodos);
        this.Controls.Add(chkConectarExtremos);
        this.Controls.Add(chkBorrarAnteriores);
        this.Controls.Add(chkSeleccionarResultado);

        this.Controls.Add(lblRedistribucion);
        this.Controls.Add(lblSepCara);
        this.Controls.Add(nudSeparacionCaraM);
        this.Controls.Add(lblMargenCara);
        this.Controls.Add(nudMargenCaraM);
        this.Controls.Add(lblLongitud);
        this.Controls.Add(nudLongitudAcomodoM);
        this.Controls.Add(lblInfoRedistribuir);

        this.Controls.Add(lblResultado);
        this.Controls.Add(txtResultado);
        this.Controls.Add(btnCrearTubos);
        this.Controls.Add(btnRedistribuirCara);

        CargarConfiguracion();
        ActualizarEstadoTomacorrientes();
        MostrarResultado("Configura el tubo y presiona CREAR TUBOS para iniciar el flujo rápido.");
    }

    private System.Windows.Forms.Button CrearBoton(
        string texto,
        int left,
        int top,
        int width,
        System.Drawing.Color color)
    {
        System.Windows.Forms.Button boton = new System.Windows.Forms.Button()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 32,
            BackColor = color,
            ForeColor = System.Drawing.Color.White,
            FlatStyle = System.Windows.Forms.FlatStyle.Flat,
            Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
            Cursor = System.Windows.Forms.Cursors.Hand
        };

        boton.FlatAppearance.BorderSize = 0;
        boton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(
            System.Math.Max(color.R - 15, 0),
            System.Math.Max(color.G - 15, 0),
            System.Math.Max(color.B - 15, 0));

        return boton;
    }

    public void SetTiposConduit(
        System.Collections.Generic.List<EleTubosAutomaticos55TipoInfo> tipos)
    {
        if (cmbTipoConduit == null || cmbTipoConduit.IsDisposed)
            return;

        if (this.InvokeRequired)
        {
            this.BeginInvoke(new System.Action(() => SetTiposConduit(tipos)));
            return;
        }

        long seleccionadoActual = -1;
        string textoActual = cmbTipoConduit.Text;

        EleTubosAutomaticos55TipoInfo actual =
            cmbTipoConduit.SelectedItem as EleTubosAutomaticos55TipoInfo;

        if (actual != null && actual.Id != null)
            seleccionadoActual = actual.Id.Value;

        if (seleccionadoActual <= 0 && _tipoConduitIdGuardado > 0)
            seleccionadoActual = _tipoConduitIdGuardado;

        if (string.IsNullOrWhiteSpace(textoActual) &&
            !string.IsNullOrWhiteSpace(_tipoConduitTextoGuardado))
        {
            textoActual = _tipoConduitTextoGuardado;
        }

        cmbTipoConduit.Items.Clear();

        if (tipos != null)
        {
            foreach (EleTubosAutomaticos55TipoInfo t in tipos)
            {
                if (t != null)
                    cmbTipoConduit.Items.Add(t);
            }
        }

        if (cmbTipoConduit.Items.Count > 0)
        {
            int index = -1;

            if (seleccionadoActual > 0)
            {
                for (int i = 0; i < cmbTipoConduit.Items.Count; i++)
                {
                    EleTubosAutomaticos55TipoInfo item =
                        cmbTipoConduit.Items[i] as EleTubosAutomaticos55TipoInfo;

                    if (item != null && item.Id != null && item.Id.Value == seleccionadoActual)
                    {
                        index = i;
                        break;
                    }
                }
            }

            if (index < 0 && !string.IsNullOrWhiteSpace(textoActual))
            {
                for (int i = 0; i < cmbTipoConduit.Items.Count; i++)
                {
                    EleTubosAutomaticos55TipoInfo item =
                        cmbTipoConduit.Items[i] as EleTubosAutomaticos55TipoInfo;

                    if (item == null || string.IsNullOrWhiteSpace(item.Nombre))
                        continue;

                    if (string.Equals(item.Nombre.Trim(), textoActual.Trim(), System.StringComparison.OrdinalIgnoreCase) ||
                        item.Nombre.Trim().StartsWith(textoActual.Trim(), System.StringComparison.OrdinalIgnoreCase))
                    {
                        index = i;
                        break;
                    }
                }
            }

            if (index >= 0)
                cmbTipoConduit.SelectedIndex = index;
            else if (!string.IsNullOrWhiteSpace(textoActual))
                cmbTipoConduit.Text = textoActual;
            else
                cmbTipoConduit.SelectedIndex = 0;
        }
        else if (!string.IsNullOrWhiteSpace(textoActual))
        {
            cmbTipoConduit.Text = textoActual;
        }
    }

    private void Ejecutar(EleTubosAutomaticos55Request request)
    {
        _handler.Request = request;

        if (_externalEvent == null)
        {
            MostrarResultado("No se pudo crear el evento externo de Revit.");
            return;
        }

        _externalEvent.Raise();
    }

    public void SolicitarCargaInicial()
    {
        Ejecutar(EleTubosAutomaticos55Request.CargarDatos);
    }

    private void EjecutarCreacionRapida()
    {
        EleTubosAutomaticos55TipoInfo tipo = ObtenerTipoConduitSeleccionado();

        if (tipo == null || tipo.Id == null ||
            tipo.Id == Autodesk.Revit.DB.ElementId.InvalidElementId)
        {
            MostrarResultado("Selecciona un tipo de tubo / conduit válido. Puedes escribir parte del nombre y elegirlo de la lista.");
            return;
        }

        _handler.TipoConduitId = tipo.Id;
        _handler.DiametroMm = (double)nudDiametroMm.Value;
        _handler.AlturaLibreM = (double)nudAlturaLibreM.Value;
        _handler.RetiroMuroM = (double)nudRetiroMuroM.Value;
        _handler.InvertirRetiroMuro = chkInvertirRetiroMuro.Checked;
        _handler.ToleranciaAlineacionMm = (double)nudToleranciaMm.Value;
        _handler.ModoRuta = ObtenerModoRuta();
        _handler.CrearCodos = chkCrearCodos.Checked;
        _handler.ConectarExtremos = chkConectarExtremos.Checked;
        _handler.BorrarAnteriores = chkBorrarAnteriores.Checked;
        _handler.SeleccionarResultado = chkSeleccionarResultado.Checked;

        GuardarConfiguracion();

        if (ObtenerModoRuta() == "TOMACORRIENTES")
            MostrarResultado("Modo tomacorrientes activo. Pica los conectores inferiores: primero bajará, luego saldrá del muro a 90°. ESC para terminar.");
        else
            MostrarResultado("Flujo rápido iniciado. Pica conector 1 y luego conector 2. ESC para terminar.");
        Ejecutar(EleTubosAutomaticos55Request.GenerarTubo);
    }

    private void EjecutarRedistribucionCara()
    {
        _handler.SeparacionRedistribucionM = (double)nudSeparacionCaraM.Value;
        _handler.MargenRedistribucionM = (double)nudMargenCaraM.Value;
        _handler.LongitudAcomodoM = (double)nudLongitudAcomodoM.Value;
        _handler.SeleccionarResultado = chkSeleccionarResultado.Checked;

        GuardarConfiguracion();

        MostrarResultado("Pica la cara del tablero donde quieres redistribuir los tubos.");
        Ejecutar(EleTubosAutomaticos55Request.RedistribuirEnCara);
    }

    private string ObtenerModoRuta()
    {
        string texto = "";

        if (cmbModoRuta != null)
            texto = cmbModoRuta.Text;

        if (texto == "Directo si alineados")
            return "DIRECTO";

        if (texto == "Ruta L")
            return "L";

        if (texto == "Ruta Z")
            return "Z";

        if (texto == "Tomacorrientes por cara")
            return "TOMACORRIENTES";

        return "AUTOMATICO";
    }

    private EleTubosAutomaticos55TipoInfo ObtenerTipoConduitSeleccionado()
    {
        EleTubosAutomaticos55TipoInfo tipo =
            cmbTipoConduit == null ? null : cmbTipoConduit.SelectedItem as EleTubosAutomaticos55TipoInfo;

        if (tipo != null && tipo.Id != null &&
            tipo.Id != Autodesk.Revit.DB.ElementId.InvalidElementId)
        {
            return tipo;
        }

        string texto = cmbTipoConduit == null ? "" : cmbTipoConduit.Text;

        if (string.IsNullOrWhiteSpace(texto) || cmbTipoConduit == null)
            return null;

        for (int i = 0; i < cmbTipoConduit.Items.Count; i++)
        {
            EleTubosAutomaticos55TipoInfo item =
                cmbTipoConduit.Items[i] as EleTubosAutomaticos55TipoInfo;

            if (item == null || string.IsNullOrWhiteSpace(item.Nombre))
                continue;

            if (string.Equals(item.Nombre.Trim(), texto.Trim(), System.StringComparison.OrdinalIgnoreCase) ||
                item.Nombre.Trim().StartsWith(texto.Trim(), System.StringComparison.OrdinalIgnoreCase) ||
                item.Nombre.IndexOf(texto.Trim(), System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                cmbTipoConduit.SelectedIndex = i;
                return item;
            }
        }

        return null;
    }

    private string ObtenerRutaConfig()
    {
        string carpeta = System.IO.Path.Combine(
            System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData),
            "MYG_Addin");

        try
        {
            if (!System.IO.Directory.Exists(carpeta))
                System.IO.Directory.CreateDirectory(carpeta);
        }
        catch
        {
        }

        return System.IO.Path.Combine(carpeta, ArchivoConfigNombre);
    }

    private void CargarConfiguracion()
    {
        if (_configuracionYaCargada)
            return;

        _configuracionYaCargada = true;

        string ruta = ObtenerRutaConfig();

        if (!System.IO.File.Exists(ruta))
            return;

        System.Collections.Generic.Dictionary<string, string> datos =
            new System.Collections.Generic.Dictionary<string, string>(System.StringComparer.OrdinalIgnoreCase);

        try
        {
            string[] lineas = System.IO.File.ReadAllLines(ruta);

            foreach (string linea in lineas)
            {
                if (string.IsNullOrWhiteSpace(linea))
                    continue;

                int idx = linea.IndexOf('=');

                if (idx <= 0)
                    continue;

                string clave = linea.Substring(0, idx).Trim();
                string valor = linea.Substring(idx + 1).Trim();

                if (!datos.ContainsKey(clave))
                    datos.Add(clave, valor);
            }
        }
        catch
        {
            return;
        }

        _tipoConduitIdGuardado = ObtenerLong(datos, "TipoConduitId", -1);
        _tipoConduitTextoGuardado = ObtenerString(datos, "TipoConduitTexto", "");
        _modoRutaTextoGuardado = ObtenerString(datos, "ModoRutaTexto", "");

        if (!string.IsNullOrWhiteSpace(_tipoConduitTextoGuardado) && cmbTipoConduit != null)
            cmbTipoConduit.Text = _tipoConduitTextoGuardado;

        SetValorDecimal(nudDiametroMm, ObtenerDecimal(datos, "DiametroMm", nudDiametroMm.Value));
        SetValorDecimal(nudAlturaLibreM, ObtenerDecimal(datos, "AlturaLibreM", nudAlturaLibreM.Value));
        SetValorDecimal(nudRetiroMuroM, ObtenerDecimal(datos, "RetiroMuroM", nudRetiroMuroM.Value));
        SetValorDecimal(nudToleranciaMm, ObtenerDecimal(datos, "ToleranciaMm", nudToleranciaMm.Value));
        SetValorDecimal(nudSeparacionCaraM, ObtenerDecimal(datos, "SeparacionCaraM", nudSeparacionCaraM.Value));
        SetValorDecimal(nudMargenCaraM, ObtenerDecimal(datos, "MargenCaraM", nudMargenCaraM.Value));
        SetValorDecimal(nudLongitudAcomodoM, ObtenerDecimal(datos, "LongitudAcomodoM", nudLongitudAcomodoM.Value));

        SetCheck(chkCrearCodos, ObtenerBool(datos, "CrearCodos", chkCrearCodos.Checked));
        SetCheck(chkConectarExtremos, ObtenerBool(datos, "ConectarExtremos", chkConectarExtremos.Checked));
        SetCheck(chkBorrarAnteriores, ObtenerBool(datos, "BorrarAnteriores", chkBorrarAnteriores.Checked));
        SetCheck(chkSeleccionarResultado, ObtenerBool(datos, "SeleccionarResultado", chkSeleccionarResultado.Checked));
        SetCheck(chkInvertirRetiroMuro, ObtenerBool(datos, "InvertirRetiroMuro", chkInvertirRetiroMuro.Checked));

        if (!string.IsNullOrWhiteSpace(_modoRutaTextoGuardado) && cmbModoRuta != null)
        {
            int index = -1;

            for (int i = 0; i < cmbModoRuta.Items.Count; i++)
            {
                string item = cmbModoRuta.Items[i] == null ? "" : cmbModoRuta.Items[i].ToString();

                if (string.Equals(item, _modoRutaTextoGuardado, System.StringComparison.OrdinalIgnoreCase))
                {
                    index = i;
                    break;
                }
            }

            if (index >= 0)
                cmbModoRuta.SelectedIndex = index;
            else
                cmbModoRuta.Text = _modoRutaTextoGuardado;
        }
    }

    private void GuardarConfiguracion()
    {
        try
        {
            EleTubosAutomaticos55TipoInfo tipo = ObtenerTipoConduitSeleccionado();
            string tipoTexto = cmbTipoConduit == null ? "" : cmbTipoConduit.Text;
            long tipoId = -1;

            if (tipo != null && tipo.Id != null)
                tipoId = tipo.Id.Value;

            System.Collections.Generic.List<string> lineas = new System.Collections.Generic.List<string>();

            lineas.Add("TipoConduitId=" + tipoId.ToString(System.Globalization.CultureInfo.InvariantCulture));
            lineas.Add("TipoConduitTexto=" + LimpiarValorConfig(tipoTexto));
            lineas.Add("DiametroMm=" + ValorDecimal(nudDiametroMm));
            lineas.Add("AlturaLibreM=" + ValorDecimal(nudAlturaLibreM));
            lineas.Add("RetiroMuroM=" + ValorDecimal(nudRetiroMuroM));
            lineas.Add("ToleranciaMm=" + ValorDecimal(nudToleranciaMm));
            lineas.Add("ModoRutaTexto=" + LimpiarValorConfig(cmbModoRuta == null ? "" : cmbModoRuta.Text));
            lineas.Add("CrearCodos=" + ValorCheck(chkCrearCodos));
            lineas.Add("ConectarExtremos=" + ValorCheck(chkConectarExtremos));
            lineas.Add("BorrarAnteriores=" + ValorCheck(chkBorrarAnteriores));
            lineas.Add("SeleccionarResultado=" + ValorCheck(chkSeleccionarResultado));
            lineas.Add("SeparacionCaraM=" + ValorDecimal(nudSeparacionCaraM));
            lineas.Add("MargenCaraM=" + ValorDecimal(nudMargenCaraM));
            lineas.Add("LongitudAcomodoM=" + ValorDecimal(nudLongitudAcomodoM));
            lineas.Add("InvertirRetiroMuro=" + ValorCheck(chkInvertirRetiroMuro));

            System.IO.File.WriteAllLines(ObtenerRutaConfig(), lineas.ToArray());
        }
        catch
        {
        }
    }

    private string LimpiarValorConfig(string texto)
    {
        if (texto == null)
            return "";

        return texto.Replace("\r", " ").Replace("\n", " ").Trim();
    }

    private string ValorDecimal(System.Windows.Forms.NumericUpDown nud)
    {
        decimal valor = nud == null ? 0 : nud.Value;
        return valor.ToString(System.Globalization.CultureInfo.InvariantCulture);
    }

    private string ValorCheck(System.Windows.Forms.CheckBox chk)
    {
        return chk != null && chk.Checked ? "1" : "0";
    }

    private string ObtenerString(
        System.Collections.Generic.Dictionary<string, string> datos,
        string clave,
        string defecto)
    {
        if (datos == null || !datos.ContainsKey(clave))
            return defecto;

        return datos[clave] ?? defecto;
    }

    private long ObtenerLong(
        System.Collections.Generic.Dictionary<string, string> datos,
        string clave,
        long defecto)
    {
        string texto = ObtenerString(datos, clave, "");
        long valor;

        if (long.TryParse(texto, System.Globalization.NumberStyles.Integer, System.Globalization.CultureInfo.InvariantCulture, out valor))
            return valor;

        return defecto;
    }

    private decimal ObtenerDecimal(
        System.Collections.Generic.Dictionary<string, string> datos,
        string clave,
        decimal defecto)
    {
        string texto = ObtenerString(datos, clave, "");
        decimal valor;

        if (decimal.TryParse(texto, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out valor))
            return valor;

        return defecto;
    }

    private bool ObtenerBool(
        System.Collections.Generic.Dictionary<string, string> datos,
        string clave,
        bool defecto)
    {
        string texto = ObtenerString(datos, clave, "").Trim().ToUpperInvariant();

        if (texto == "1" || texto == "TRUE" || texto == "SI" || texto == "SÍ")
            return true;

        if (texto == "0" || texto == "FALSE" || texto == "NO")
            return false;

        return defecto;
    }

    private void SetValorDecimal(System.Windows.Forms.NumericUpDown nud, decimal valor)
    {
        if (nud == null)
            return;

        if (valor < nud.Minimum)
            valor = nud.Minimum;

        if (valor > nud.Maximum)
            valor = nud.Maximum;

        nud.Value = valor;
    }

    private void SetCheck(System.Windows.Forms.CheckBox chk, bool valor)
    {
        if (chk != null)
            chk.Checked = valor;
    }

    private void ActualizarEstadoTomacorrientes()
    {
        bool esTomacorrientes = ObtenerModoRuta() == "TOMACORRIENTES";

        if (lblRetiroMuro != null)
            lblRetiroMuro.ForeColor = esTomacorrientes
                ? System.Drawing.Color.FromArgb(50, 50, 50)
                : System.Drawing.Color.Gray;

        if (nudRetiroMuroM != null)
            nudRetiroMuroM.Enabled = esTomacorrientes;

        if (chkInvertirRetiroMuro != null)
            chkInvertirRetiroMuro.Enabled = esTomacorrientes;

        if (lblAlturaLibre != null)
            lblAlturaLibre.Text = esTomacorrientes
                ? "Bajada toma (m):"
                : "Altura libre (m):";
    }

    public void SetConectorInicio(EleTubosAutomaticos55ConectorInfo info)
    {
        if (info != null)
            MostrarResultado("Conector inicial seleccionado: " + info.TextoResumen);
    }

    public void SetConectorFin(EleTubosAutomaticos55ConectorInfo info)
    {
        if (info != null)
            MostrarResultado("Conector final seleccionado: " + info.TextoResumen);
    }

    public void MostrarResultado(string texto)
    {
        if (txtResultado == null || txtResultado.IsDisposed)
            return;

        if (this.InvokeRequired)
        {
            this.BeginInvoke(new System.Action(() => MostrarResultado(texto)));
            return;
        }

        txtResultado.Clear();
        txtResultado.SelectionColor = System.Drawing.Color.FromArgb(50, 50, 50);
        txtResultado.AppendText(texto ?? "");
        txtResultado.SelectionStart = 0;
        txtResultado.ScrollToCaret();
    }

    public void AgregarResultado(string texto)
    {
        if (txtResultado == null || txtResultado.IsDisposed)
            return;

        if (this.InvokeRequired)
        {
            this.BeginInvoke(new System.Action(() => AgregarResultado(texto)));
            return;
        }

        txtResultado.AppendText("\r\n" + (texto ?? ""));
        txtResultado.SelectionStart = txtResultado.TextLength;
        txtResultado.ScrollToCaret();
    }
}