﻿/*
=========================================================
MYG - Proyectar octogonales / familias por cara
Panel 5 - Botón 5.5
V19 - Selección previa + caras nativas/vínculos + tubería flexible entre familia base y proyectada
=========================================================
*/

using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;

namespace MYG_Addin
{
    public enum EleProyectarOctogonales55Request
    {
        None,
        CargarDatos,
        SeleccionarBases,
        ProyectarFamilias
    }

    public class EleProyectarOctogonales55TipoInfo
    {
        public ElementId Id { get; set; }
        public string Nombre { get; set; }

        public override string ToString()
        {
            return string.IsNullOrWhiteSpace(Nombre) ? "(Sin nombre)" : Nombre;
        }
    }

    public class EjecutarEleProyectarOctogonales55Handler : IExternalEventHandler
    {
        private const double Epsilon = 1.0e-9;

        public UIDocument UiDoc { get; set; }
        public EleProyectarOctogonales55Form Form { get; set; }
        public EleProyectarOctogonales55Request Request { get; set; } = EleProyectarOctogonales55Request.None;

        public List<EleProyectarOctogonales55TipoInfo> TiposDisponibles { get; private set; } =
            new List<EleProyectarOctogonales55TipoInfo>();

        public List<ElementId> ElementosBaseIds { get; private set; } =
            new List<ElementId>();

        public ElementId TipoFamiliaId { get; set; } = ElementId.InvalidElementId;
        public double DesfaseSobreCaraM { get; set; } = 0.0;
        public double AlturaMaximaBusquedaM { get; set; } = 6.0;
        public double SeparacionInicioRayoM { get; set; } = 0.05;
        public bool IgnorarAnfitrionOriginal { get; set; } = true;
        public bool UsarOrientacionOriginal { get; set; } = true;
        public bool SeleccionarCreadas { get; set; } = true;
        public bool CrearTuberiaFlexible { get; set; } = false;
        public double DiametroFlexibleMm { get; set; } = 20.0;
        public double LongitudRectaFlexibleM { get; set; } = 0.20;
        private double _ultimoRadioGiroAutomaticoM = 0.0;

        public string GetName()
        {
            return "MYG - Proyectar octogonales a cara superior";
        }

        public void Execute(UIApplication app)
        {
            try
            {
                UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

                if (uidoc == null || uidoc.Document == null)
                    return;

                Document doc = uidoc.Document;

                if (Request == EleProyectarOctogonales55Request.CargarDatos)
                {
                    CargarTiposFamilia(doc);

                    if (Form != null && !Form.IsDisposed)
                        Form.SetTiposFamilia(TiposDisponibles);
                }
                else if (Request == EleProyectarOctogonales55Request.SeleccionarBases)
                {
                    EjecutarSeleccionarBases(uidoc, doc);
                }
                else if (Request == EleProyectarOctogonales55Request.ProyectarFamilias)
                {
                    EjecutarProyeccion(uidoc, doc);
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
            }
            catch (Exception ex)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("MYG - Error: " + ex.Message);
            }
            finally
            {
                Request = EleProyectarOctogonales55Request.None;
            }
        }

        public void CargarTiposFamilia(Document doc)
        {
            TiposDisponibles.Clear();

            if (doc == null)
                return;

            try
            {
                List<FamilySymbol> symbols = new FilteredElementCollector(doc)
                    .OfClass(typeof(FamilySymbol))
                    .Cast<FamilySymbol>()
                    .Where(x => x != null && x.Family != null && x.Category != null)
                    .Where(x => EsCandidatoFamiliaPorCara(x))
                    .OrderBy(x => ObtenerNombreCompleto(x))
                    .ToList();

                foreach (FamilySymbol fs in symbols)
                {
                    TiposDisponibles.Add(new EleProyectarOctogonales55TipoInfo
                    {
                        Id = fs.Id,
                        Nombre = ObtenerNombreCompleto(fs) + "  [" + fs.Category.Name + "]"
                    });
                }
            }
            catch
            {
            }
        }

        private bool EsCandidatoFamiliaPorCara(FamilySymbol fs)
        {
            if (fs == null || fs.Family == null || fs.Category == null)
                return false;

            bool placementOk = false;

            try
            {
                FamilyPlacementType fpt = fs.Family.FamilyPlacementType;

                if (fpt == FamilyPlacementType.WorkPlaneBased)
                    placementOk = true;

                string txt = fpt.ToString().ToUpperInvariant();

                if (txt.Contains("FACE") || txt.Contains("WORKPLANE"))
                    placementOk = true;
            }
            catch
            {
            }

            if (!placementOk)
                return false;

            string categoria = Normalizar((fs.Category == null ? "" : fs.Category.Name));
            string nombre = Normalizar(ObtenerNombreCompleto(fs));

            if (categoria.Contains("LIGHTING") || categoria.Contains("LUMINARIA")) return true;
            if (categoria.Contains("ELECTRICAL_FIXTURES")) return true;
            if (categoria.Contains("APARATOS_ELECTRICOS")) return true;
            if (categoria.Contains("ELECTRICALFIXTURES")) return true;
            if (categoria.Contains("GENERIC_MODELS")) return true;
            if (categoria.Contains("MODELOS_GENERICOS")) return true;
            if (categoria.Contains("DATA_DEVICES")) return true;
            if (categoria.Contains("COMMUNICATION_DEVICES")) return true;
            if (categoria.Contains("FIRE_ALARM_DEVICES")) return true;
            if (categoria.Contains("ELECTRICAL_EQUIPMENT")) return true;
            if (categoria.Contains("EQUIPOS_ELECTRICOS")) return true;

            if (nombre.Contains("OCTOGON")) return true;
            if (nombre.Contains("CAJA")) return true;
            if (nombre.Contains("JUNCTION")) return true;
            if (nombre.Contains("BOX")) return true;

            return true;
        }

        private string ObtenerNombreCompleto(FamilySymbol fs)
        {
            if (fs == null)
                return "";

            string familia = "";

            try
            {
                if (fs.Family != null)
                    familia = fs.Family.Name;
            }
            catch
            {
            }

            if (string.IsNullOrWhiteSpace(familia))
                return fs.Name;

            return familia + " : " + fs.Name;
        }

        private void EjecutarSeleccionarBases(UIDocument uidoc, Document doc)
        {
            if (uidoc == null || doc == null)
                return;

            IList<Reference> refs = null;
            bool estabaVisible = Form != null && !Form.IsDisposed && Form.Visible;

            try
            {
                if (Form != null && !Form.IsDisposed)
                    Form.Hide();

                refs = uidoc.Selection.PickObjects(
                    ObjectType.Element,
                    new FiltroFamiliasBaseProyeccion55(),
                    "Selecciona las luminarias/familias base. Finaliza para guardar la selección.");
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("Selección cancelada por el usuario.");

                return;
            }
            finally
            {
                try
                {
                    if (estabaVisible && Form != null && !Form.IsDisposed)
                    {
                        Form.Show();
                        Form.BringToFront();
                    }
                }
                catch
                {
                }
            }

            ElementosBaseIds.Clear();
            List<Element> elementos = new List<Element>();

            if (refs != null)
            {
                foreach (Reference r in refs)
                {
                    if (r == null)
                        continue;

                    Element e = doc.GetElement(r.ElementId);

                    if (!(e is FamilyInstance))
                        continue;

                    if (ElementosBaseIds.Any(x => x.Value == e.Id.Value))
                        continue;

                    ElementosBaseIds.Add(e.Id);
                    elementos.Add(e);
                }
            }

            if (Form != null && !Form.IsDisposed)
                Form.SetElementosBaseSeleccionados(elementos);
        }

        private void EjecutarProyeccion(UIDocument uidoc, Document doc)
        {
            if (uidoc == null || doc == null)
                return;

            FamilySymbol symbol = doc.GetElement(TipoFamiliaId) as FamilySymbol;

            if (symbol == null)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("Selecciona una familia por cara/octogonal válida.");

                return;
            }

            View3D view3D = ObtenerVista3DParaInterseccion(doc, uidoc.ActiveView);

            if (view3D == null)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("La proyección necesita una vista 3D activa no plantilla. Abre/activa una vista 3D donde estén visibles nativos y vínculos.");

                return;
            }

            double desfase = UnitUtils.ConvertToInternalUnits(DesfaseSobreCaraM, UnitTypeId.Meters);
            double alturaMax = UnitUtils.ConvertToInternalUnits(Math.Max(AlturaMaximaBusquedaM, 0.10), UnitTypeId.Meters);
            double separacionInicio = UnitUtils.ConvertToInternalUnits(Math.Max(SeparacionInicioRayoM, 0.001), UnitTypeId.Meters);
            double distanciaMinima = UnitUtils.ConvertToInternalUnits(0.01, UnitTypeId.Meters);

            if (ElementosBaseIds == null || ElementosBaseIds.Count == 0)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("Primero presiona SELECCIONAR ELEMENTOS y elige las luminarias/familias base.");

                return;
            }

            List<FamilyInstance> bases = new List<FamilyInstance>();

            foreach (ElementId id in ElementosBaseIds)
            {
                if (id == null || id == ElementId.InvalidElementId)
                    continue;

                FamilyInstance fi = doc.GetElement(id) as FamilyInstance;

                if (fi == null)
                    continue;

                if (!bases.Any(x => x.Id.Value == fi.Id.Value))
                    bases.Add(fi);
            }

            if (bases.Count == 0)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("La selección no contiene familias válidas.");

                return;
            }

            List<ElementId> creados = new List<ElementId>();
            List<ElementId> flexiblesCreados = new List<ElementId>();
            int sinCara = 0;
            int fallidos = 0;
            int omitidos = 0;
            int flexiblesOk = 0;
            int flexiblesFallidos = 0;
            int flexiblesSinConector = 0;

            using (Transaction t = new Transaction(doc, "MYG - Proyectar octogonales a cara superior"))
            {
                try
                {
                    t.Start();

                    FailureHandlingOptions failureOptions = t.GetFailureHandlingOptions();
                    failureOptions.SetFailuresPreprocessor(new EleProyectarOctogonales55FailurePreprocessor());
                    t.SetFailureHandlingOptions(failureOptions);

                    if (!symbol.IsActive)
                    {
                        symbol.Activate();
                        doc.Regenerate();
                    }

                    ReferenceIntersector intersector = new ReferenceIntersector(view3D);
                    intersector.FindReferencesInRevitLinks = true;

                    foreach (FamilyInstance origen in bases)
                    {
                        if (origen == null)
                        {
                            omitidos++;
                            continue;
                        }

                        XYZ puntoBase = ObtenerPuntoBase(origen);

                        if (EsVectorCero(puntoBase))
                        {
                            fallidos++;
                            continue;
                        }

                        ElementId hostId = ObtenerHostId(origen);
                        XYZ origenRayo = puntoBase + XYZ.BasisZ * separacionInicio;

                        DatosCaraObjetivo55 objetivo = BuscarSiguienteCaraSuperior(
                            doc,
                            intersector,
                            origenRayo,
                            alturaMax,
                            distanciaMinima,
                            origen.Id,
                            hostId);

                        if (objetivo == null || objetivo.FaceReference == null)
                        {
                            sinCara++;
                            continue;
                        }

                        XYZ puntoColocacion = objetivo.Punto;

                        if (desfase != 0.0 && !EsVectorCero(objetivo.Normal))
                            puntoColocacion = puntoColocacion + objetivo.Normal.Normalize() * desfase;

                        XYZ refDir = ObtenerDireccionReferencia(origen, objetivo);

                        if (EsVectorCero(refDir))
                        {
                            fallidos++;
                            continue;
                        }

                        FamilyInstance nueva = null;

                        try
                        {
                            nueva = doc.Create.NewFamilyInstance(
                                objetivo.FaceReference,
                                puntoColocacion,
                                refDir,
                                symbol);
                        }
                        catch
                        {
                            // Segundo intento con una dirección segura propia de la cara.
                            try
                            {
                                refDir = ObtenerDireccionSeguraEnPlano(objetivo.Normal);
                                nueva = doc.Create.NewFamilyInstance(
                                    objetivo.FaceReference,
                                    puntoColocacion,
                                    refDir,
                                    symbol);
                            }
                            catch
                            {
                                nueva = null;
                            }
                        }

                        if (nueva == null)
                        {
                            fallidos++;
                            continue;
                        }

                        creados.Add(nueva.Id);

                        if (CrearTuberiaFlexible)
                        {
                            try
                            {
                                doc.Regenerate();

                                ResultadoFlexibleProyectado55 resFlex = CrearFlexibleEntreFamiliasProyectadas(doc, origen, nueva);

                                if (resFlex != null && resFlex.Ok)
                                {
                                    flexiblesOk++;

                                    if (resFlex.IdCreado != null && resFlex.IdCreado != ElementId.InvalidElementId)
                                        flexiblesCreados.Add(resFlex.IdCreado);
                                }
                                else
                                {
                                    flexiblesFallidos++;

                                    if (resFlex != null && resFlex.SinConector)
                                        flexiblesSinConector++;
                                }
                            }
                            catch
                            {
                                flexiblesFallidos++;
                            }
                        }
                    }

                    t.Commit();
                }
                catch (Exception ex)
                {
                    try
                    {
                        if (t.GetStatus() == TransactionStatus.Started)
                            t.RollBack();
                    }
                    catch
                    {
                    }

                    if (Form != null && !Form.IsDisposed)
                        Form.MostrarResultado("No se pudo proyectar: " + ex.Message);

                    return;
                }
            }

            if (SeleccionarCreadas && (creados.Count > 0 || flexiblesCreados.Count > 0))
            {
                List<ElementId> seleccion = new List<ElementId>();
                seleccion.AddRange(creados);
                seleccion.AddRange(flexiblesCreados);
                uidoc.Selection.SetElementIds(seleccion);
            }

            if (Form != null && !Form.IsDisposed)
            {
                Form.MostrarResultado("Proyección finalizada.");
                Form.AgregarResultado("Familias base seleccionadas: " + bases.Count);
                Form.AgregarResultado("Familias creadas: " + creados.Count);
                Form.AgregarResultado("Crear tubería flexible: " + (CrearTuberiaFlexible ? "Sí" : "No"));
                if (CrearTuberiaFlexible)
                {
                    Form.AgregarResultado("Tuberías flexibles creadas: " + flexiblesOk);
                    Form.AgregarResultado("Tuberías flexibles fallidas: " + flexiblesFallidos);
                    Form.AgregarResultado("Pares sin conectores compatibles: " + flexiblesSinConector);
                }
                Form.AgregarResultado("Sin cara superior válida: " + sinCara);
                Form.AgregarResultado("Fallidos: " + fallidos);
                Form.AgregarResultado("Ignorar anfitrión original: " + (IgnorarAnfitrionOriginal ? "Sí" : "No"));
                Form.AgregarResultado("Altura máxima búsqueda: " + AlturaMaximaBusquedaM.ToString("0.###") + " m");
                Form.AgregarResultado("Caras detectadas: nativos + vínculos visibles en vista 3D activa.");
            }
        }

        private DatosCaraObjetivo55 BuscarSiguienteCaraSuperior(
            Document doc,
            ReferenceIntersector intersector,
            XYZ origenRayo,
            double alturaMax,
            double distanciaMinima,
            ElementId elementoBaseId,
            ElementId hostId)
        {
            if (doc == null || intersector == null || EsVectorCero(origenRayo))
                return null;

            IList<ReferenceWithContext> encontrados = null;

            try
            {
                encontrados = intersector.Find(origenRayo, XYZ.BasisZ);
            }
            catch
            {
                return null;
            }

            if (encontrados == null || encontrados.Count == 0)
                return null;

            foreach (ReferenceWithContext rwc in encontrados.OrderBy(x => x.Proximity))
            {
                if (rwc == null)
                    continue;

                double distancia = rwc.Proximity;

                if (distancia < distanciaMinima)
                    continue;

                if (distancia > alturaMax)
                    continue;

                Reference r = rwc.GetReference();

                if (r == null)
                    continue;

                if (r.ElementId == null || r.ElementId == ElementId.InvalidElementId)
                    continue;

                // Caso nativo: evitar la propia familia base y su anfitrión original.
                if (elementoBaseId != null && r.ElementId.Value == elementoBaseId.Value)
                    continue;

                if (IgnorarAnfitrionOriginal && hostId != null &&
                    hostId != ElementId.InvalidElementId &&
                    r.ElementId.Value == hostId.Value)
                    continue;

                XYZ punto = origenRayo + XYZ.BasisZ * distancia;

                DatosCaraObjetivo55 datos = CrearDatosCaraObjetivoDesdeReferencia(doc, r, punto);

                if (datos == null || datos.FaceReference == null || datos.Elemento == null)
                    continue;

                if (!EsElementoObjetivoPermitido(datos))
                    continue;

                return datos;
            }

            return null;
        }

        private DatosCaraObjetivo55 CrearDatosCaraObjetivoDesdeReferencia(
            Document doc,
            Reference referencia,
            XYZ punto)
        {
            if (doc == null || referencia == null)
                return null;

            Element elementoHost = doc.GetElement(referencia.ElementId);

            if (elementoHost == null)
                return null;

            RevitLinkInstance linkInstance = elementoHost as RevitLinkInstance;
            Element elementoGeometria = elementoHost;
            Reference referenciaGeometria = referencia;
            Transform transform = Transform.Identity;
            bool esVinculo = false;

            if (linkInstance != null)
            {
                try
                {
                    Document linkDoc = linkInstance.GetLinkDocument();

                    if (linkDoc == null)
                        return null;

                    ElementId linkedId = referencia.LinkedElementId;

                    if (linkedId == null || linkedId == ElementId.InvalidElementId)
                        return null;

                    elementoGeometria = linkDoc.GetElement(linkedId);

                    if (elementoGeometria == null)
                        return null;

                    referenciaGeometria = referencia.CreateReferenceInLink();
                    transform = linkInstance.GetTotalTransform();
                    esVinculo = true;
                }
                catch
                {
                    return null;
                }
            }

            Face face = null;
            PlanarFace pf = null;

            try
            {
                GeometryObject go = elementoGeometria.GetGeometryObjectFromReference(referenciaGeometria);
                face = go as Face;
                pf = go as PlanarFace;
            }
            catch
            {
            }

            XYZ normal = XYZ.BasisZ;
            XYZ ejeX = XYZ.BasisX;
            XYZ ejeY = XYZ.BasisY;

            if (pf != null)
            {
                normal = pf.FaceNormal;
                ejeX = pf.XVector;
                ejeY = pf.YVector;
            }
            else if (face != null)
            {
                try
                {
                    BoundingBoxUV bb = face.GetBoundingBox();
                    UV uv = new UV((bb.Min.U + bb.Max.U) * 0.5, (bb.Min.V + bb.Max.V) * 0.5);
                    normal = face.ComputeNormal(uv);
                }
                catch
                {
                }
            }

            if (esVinculo)
            {
                try
                {
                    normal = transform.OfVector(normal);
                    ejeX = transform.OfVector(ejeX);
                    ejeY = transform.OfVector(ejeY);
                }
                catch
                {
                }
            }

            if (EsVectorCero(normal))
                normal = XYZ.BasisZ;

            normal = normal.Normalize();

            XYZ ex = ProyectarVectorEnPlano(ejeX, normal);

            if (EsVectorCero(ex))
                ex = ObtenerDireccionSeguraEnPlano(normal);

            XYZ ey = ProyectarVectorEnPlano(ejeY, normal);

            if (EsVectorCero(ey))
                ey = normal.CrossProduct(ex);

            if (EsVectorCero(ey))
                ey = ObtenerDireccionSeguraEnPlano(normal);

            return new DatosCaraObjetivo55
            {
                FaceReference = referencia,
                Elemento = elementoHost,
                ElementoVinculo = esVinculo ? elementoGeometria : null,
                EsVinculo = esVinculo,
                Punto = punto,
                Normal = normal,
                EjeX = ex.Normalize(),
                EjeY = ey.Normalize()
            };
        }

        private bool EsElementoObjetivoPermitido(DatosCaraObjetivo55 datos)
        {
            if (datos == null)
                return false;

            Element e = datos.EsVinculo ? datos.ElementoVinculo : datos.Elemento;

            if (e == null)
                return false;

            FamilyInstance fi = e as FamilyInstance;

            if (fi != null)
            {
                string cat = e.Category == null ? "" : Normalizar(e.Category.Name);
                string nombre = Normalizar(e.Name);

                if (cat.Contains("CEILING") || cat.Contains("CIELO")) return true;
                if (cat.Contains("FLOOR") || cat.Contains("PISO") || cat.Contains("SUELO")) return true;
                if (cat.Contains("ROOF") || cat.Contains("TECHO")) return true;
                if (cat.Contains("GENERIC") || cat.Contains("MODELOS_GENERICOS"))
                {
                    if (nombre.Contains("PANEL") || nombre.Contains("CIELO") || nombre.Contains("CEILING") || nombre.Contains("LOSA"))
                        return true;
                }

                return false;
            }

            return true;
        }

        private XYZ ObtenerPuntoBase(FamilyInstance fi)
        {
            if (fi == null)
                return XYZ.Zero;

            try
            {
                LocationPoint lp = fi.Location as LocationPoint;

                if (lp != null && lp.Point != null)
                    return lp.Point;
            }
            catch
            {
            }

            try
            {
                BoundingBoxXYZ bb = fi.get_BoundingBox(null);

                if (bb != null)
                    return (bb.Min + bb.Max) * 0.5;
            }
            catch
            {
            }

            return XYZ.Zero;
        }

        private ElementId ObtenerHostId(FamilyInstance fi)
        {
            if (fi == null)
                return ElementId.InvalidElementId;

            try
            {
                Element host = fi.Host;

                if (host != null)
                    return host.Id;
            }
            catch
            {
            }

            return ElementId.InvalidElementId;
        }

        private XYZ ObtenerDireccionReferencia(FamilyInstance origen, DatosCaraObjetivo55 objetivo)
        {
            if (objetivo == null)
                return XYZ.BasisX;

            XYZ normal = objetivo.Normal;

            if (EsVectorCero(normal))
                normal = XYZ.BasisZ;

            normal = normal.Normalize();

            if (UsarOrientacionOriginal && origen != null)
            {
                XYZ dir = XYZ.Zero;

                try
                {
                    dir = origen.HandOrientation;
                }
                catch
                {
                }

                dir = ProyectarVectorEnPlano(dir, normal);

                if (!EsVectorCero(dir))
                    return dir.Normalize();

                try
                {
                    dir = origen.FacingOrientation;
                }
                catch
                {
                }

                dir = ProyectarVectorEnPlano(dir, normal);

                if (!EsVectorCero(dir))
                    return dir.Normalize();
            }

            if (!EsVectorCero(objetivo.EjeX))
                return ProyectarVectorEnPlano(objetivo.EjeX, normal).Normalize();

            if (!EsVectorCero(objetivo.EjeY))
                return ProyectarVectorEnPlano(objetivo.EjeY, normal).Normalize();

            return ObtenerDireccionSeguraEnPlano(normal);
        }

        private View3D ObtenerVista3DParaInterseccion(Document doc, View vistaActiva)
        {
            if (doc == null || vistaActiva == null)
                return null;

            View3D v3dActiva = vistaActiva as View3D;

            if (v3dActiva != null && !v3dActiva.IsTemplate)
                return v3dActiva;

            // ReferenceIntersector trabaja con View3D.
            // Para respetar la vista activa y sus visibilidades/filtros/links,
            // esta herramienta exige que la vista activa sea 3D.
            return null;
        }

        private XYZ ProyectarVectorEnPlano(XYZ v, XYZ normal)
        {
            if (EsVectorCero(v))
                return XYZ.Zero;

            if (EsVectorCero(normal))
                return v;

            XYZ n = normal.Normalize();
            XYZ p = v - n * v.DotProduct(n);

            if (EsVectorCero(p))
                return XYZ.Zero;

            return p.Normalize();
        }

        private XYZ ObtenerDireccionSeguraEnPlano(XYZ normal)
        {
            if (EsVectorCero(normal))
                return XYZ.BasisX;

            XYZ n = normal.Normalize();
            XYZ candidato = XYZ.BasisX;

            if (Math.Abs(candidato.DotProduct(n)) > 0.95)
                candidato = XYZ.BasisY;

            XYZ dir = candidato - n * candidato.DotProduct(n);

            if (EsVectorCero(dir))
                dir = XYZ.BasisZ.CrossProduct(n);

            if (EsVectorCero(dir))
                dir = XYZ.BasisX;

            return dir.Normalize();
        }

        private bool EsVectorCero(XYZ v)
        {
            if (v == null)
                return true;

            try
            {
                return v.GetLength() < Epsilon;
            }
            catch
            {
                return true;
            }
        }

        private string Normalizar(string texto)
        {
            if (texto == null)
                return "";

            string s = texto.Trim().ToUpperInvariant();

            s = s.Replace("Á", "A");
            s = s.Replace("É", "E");
            s = s.Replace("Í", "I");
            s = s.Replace("Ó", "O");
            s = s.Replace("Ú", "U");
            s = s.Replace("Ñ", "N");
            s = s.Replace(" ", "_");

            return s;
        }


        // =========================================================
        // TUBERÍA FLEXIBLE ENTRE FAMILIA BASE Y FAMILIA PROYECTADA
        // =========================================================

        private ResultadoFlexibleProyectado55 CrearFlexibleEntreFamiliasProyectadas(
            Document doc,
            FamilyInstance familiaBase,
            FamilyInstance familiaProyectada)
        {
            ResultadoFlexibleProyectado55 resultado = new ResultadoFlexibleProyectado55();

            if (doc == null || familiaBase == null || familiaProyectada == null)
            {
                resultado.Error = "Familias inválidas para crear tubería flexible.";
                return resultado;
            }

            List<Connector> conectoresBase = ObtenerConectoresFlexibles(familiaBase);
            List<Connector> conectoresProyectada = ObtenerConectoresFlexibles(familiaProyectada);

            if (conectoresBase.Count == 0 || conectoresProyectada.Count == 0)
            {
                resultado.SinConector = true;
                resultado.Error = "Una de las familias no tiene conectores Pipe/HVAC de extremo compatibles.";
                return resultado;
            }

            ParConectoresProyectado55 par = BuscarMejorParFlexible(conectoresBase, conectoresProyectada);

            if (par == null || par.A == null || par.B == null)
            {
                resultado.SinConector = true;
                resultado.Error = "No se encontró un par compatible de conectores para FlexPipe/FlexDuct.";
                return resultado;
            }

            ElementId tipoFlexibleId = ResolverTipoFlexibleParaPar(doc, par);

            if (tipoFlexibleId == null || tipoFlexibleId == ElementId.InvalidElementId)
            {
                resultado.Error = "No se encontró un tipo FlexPipe/FlexDuct compatible en el proyecto.";
                return resultado;
            }

            try
            {
                XYZ dirA = ObtenerDireccionNormalSalidaFlexible(par.A, familiaBase, par.B);
                XYZ dirB = ObtenerDireccionNormalSalidaFlexible(par.B, familiaProyectada, par.A);
                List<XYZ> puntosRuta = CalcularPuntosRutaFlexible(par.A, par.B, dirA, dirB);

                if (puntosRuta == null || puntosRuta.Count < 2)
                {
                    resultado.Error = "No se pudo calcular una ruta flexible válida.";
                    return resultado;
                }

                Element nuevo = null;

                if (par.EsPipe)
                {
                    FlexPipeType tipoPipe = doc.GetElement(tipoFlexibleId) as FlexPipeType;

                    if (tipoPipe == null)
                    {
                        resultado.Error = "El tipo FlexPipe encontrado no es válido.";
                        return resultado;
                    }

                    FlexPipe fp = doc.Create.NewFlexPipe(par.A, puntosRuta, tipoPipe);
                    nuevo = fp as Element;
                    AplicarTangentesFlexible(nuevo, dirA, -dirB);
                }
                else if (par.EsDuct)
                {
                    FlexDuctType tipoDuct = doc.GetElement(tipoFlexibleId) as FlexDuctType;

                    if (tipoDuct == null)
                    {
                        resultado.Error = "El tipo FlexDuct encontrado no es válido.";
                        return resultado;
                    }

                    FlexDuct fd = doc.Create.NewFlexDuct(par.A, puntosRuta, tipoDuct);
                    nuevo = fd as Element;
                    AplicarTangentesFlexible(nuevo, dirA, -dirB);
                }

                if (nuevo == null)
                {
                    resultado.Error = "Revit no devolvió la tubería flexible creada.";
                    return resultado;
                }

                AplicarDiametroFlexible(nuevo, DiametroFlexibleMm);
                MarcarFlexibleProyectado(nuevo);
                doc.Regenerate();

                int conexiones = ConectarAmbosExtremosFlexible(doc, nuevo, par.A, par.B);
                doc.Regenerate();

                resultado.Ok = true;
                resultado.IdCreado = nuevo.Id;
                resultado.ConexionesConfirmadas = conexiones;
                return resultado;
            }
            catch (Exception ex)
            {
                resultado.Error = ex.Message;
                return resultado;
            }
        }

        private List<Connector> ObtenerConectoresFlexibles(Element e)
        {
            List<Connector> lista = new List<Connector>();

            if (e == null)
                return lista;

            try
            {
                FamilyInstance fi = e as FamilyInstance;

                if (fi != null && fi.MEPModel != null && fi.MEPModel.ConnectorManager != null)
                    AgregarConectoresFlexibles(lista, fi.MEPModel.ConnectorManager.Connectors);
            }
            catch
            {
            }

            try
            {
                MEPCurve curva = e as MEPCurve;

                if (curva != null && curva.ConnectorManager != null)
                    AgregarConectoresFlexibles(lista, curva.ConnectorManager.Connectors);
            }
            catch
            {
            }

            return lista
                .Where(x => x != null)
                .GroupBy(x => ObtenerOrigenSeguro(x).ToString())
                .Select(g => g.First())
                .ToList();
        }

        private void AgregarConectoresFlexibles(List<Connector> lista, ConnectorSet set)
        {
            if (lista == null || set == null)
                return;

            foreach (Connector c in set)
            {
                if (c == null)
                    continue;

                if (EsConectorValidoParaFlexible(c))
                    lista.Add(c);
            }
        }

        private bool EsConectorValidoParaFlexible(Connector c)
        {
            if (c == null)
                return false;

            if (!EsDominioPiping(c) && !EsDominioHvac(c))
                return false;

            try
            {
                if (c.ConnectorType != ConnectorType.End)
                    return false;
            }
            catch
            {
            }

            return true;
        }

        private ParConectoresProyectado55 BuscarMejorParFlexible(List<Connector> a, List<Connector> b)
        {
            ParConectoresProyectado55 mejor = null;
            double mejorScore = double.MaxValue;

            foreach (Connector c1 in a)
            {
                if (c1 == null)
                    continue;

                foreach (Connector c2 in b)
                {
                    if (c2 == null)
                        continue;

                    bool pipe = EsDominioPiping(c1) && EsDominioPiping(c2);
                    bool duct = EsDominioHvac(c1) && EsDominioHvac(c2);

                    if (!pipe && !duct)
                        continue;

                    XYZ p1 = ObtenerOrigenSeguro(c1);
                    XYZ p2 = ObtenerOrigenSeguro(c2);

                    if (EsVectorCero(p1) || EsVectorCero(p2))
                        continue;

                    double score = p1.DistanceTo(p2);

                    if (EstaConectado(c1))
                        score += 1000.0;

                    if (EstaConectado(c2))
                        score += 1000.0;

                    if (score < mejorScore)
                    {
                        mejorScore = score;
                        mejor = new ParConectoresProyectado55
                        {
                            A = c1,
                            B = c2,
                            EsPipe = pipe,
                            EsDuct = duct
                        };
                    }
                }
            }

            return mejor;
        }

        private ElementId ResolverTipoFlexibleParaPar(Document doc, ParConectoresProyectado55 par)
        {
            if (doc == null || par == null)
                return ElementId.InvalidElementId;

            if (par.EsPipe)
            {
                try
                {
                    FlexPipeType tipo = new FilteredElementCollector(doc)
                        .OfClass(typeof(FlexPipeType))
                        .Cast<FlexPipeType>()
                        .OrderBy(x => x.Name)
                        .FirstOrDefault();

                    if (tipo != null)
                        return tipo.Id;
                }
                catch
                {
                }
            }

            if (par.EsDuct)
            {
                try
                {
                    FlexDuctType tipo = new FilteredElementCollector(doc)
                        .OfClass(typeof(FlexDuctType))
                        .Cast<FlexDuctType>()
                        .OrderBy(x => x.Name)
                        .FirstOrDefault();

                    if (tipo != null)
                        return tipo.Id;
                }
                catch
                {
                }
            }

            return ElementId.InvalidElementId;
        }

        private List<XYZ> CalcularPuntosRutaFlexible(
            Connector conectorInicio,
            Connector conectorFin,
            XYZ dirInicio,
            XYZ dirFin)
        {
            List<XYZ> puntos = new List<XYZ>();

            if (conectorInicio == null || conectorFin == null)
                return puntos;

            XYZ p0 = ObtenerOrigenSeguro(conectorInicio);
            XYZ p1 = ObtenerOrigenSeguro(conectorFin);

            if (EsVectorCero(p0) || EsVectorCero(p1))
                return puntos;

            if (EsVectorCero(dirInicio))
                dirInicio = p1 - p0;

            if (EsVectorCero(dirFin))
                dirFin = p0 - p1;

            if (EsVectorCero(dirInicio) || EsVectorCero(dirFin))
                return puntos;

            dirInicio = dirInicio.Normalize();
            dirFin = dirFin.Normalize();

            double recta = UnitUtils.ConvertToInternalUnits(
                Math.Max(LongitudRectaFlexibleM, 0.02),
                UnitTypeId.Meters);

            double diametro = UnitUtils.ConvertToInternalUnits(
                Math.Max(DiametroFlexibleMm, 1.0),
                UnitTypeId.Millimeters);

            double radioU = Math.Max(
                diametro * 18.0,
                UnitUtils.ConvertToInternalUnits(0.25, UnitTypeId.Meters));

            radioU = Math.Max(
                radioU,
                UnitUtils.ConvertToInternalUnits(Math.Min(Math.Max(DiametroFlexibleMm / 1000.0 * 20.0, 0.25), 1.20), UnitTypeId.Meters));

            recta = Math.Max(recta, diametro * 5.0);

            double distancia = p0.DistanceTo(p1);

            if (distancia > Epsilon)
            {
                recta = Math.Min(recta, distancia * 0.30);

                double radioMaxPorDistancia = distancia * 0.48;
                double radioMinPorDiametro = diametro * 10.0;

                if (radioU > radioMaxPorDistancia)
                    radioU = Math.Max(radioMinPorDiametro, radioMaxPorDistancia);
            }

            _ultimoRadioGiroAutomaticoM = UnitUtils.ConvertFromInternalUnits(radioU, UnitTypeId.Meters);

            XYZ lineaInicioFin = p1 - p0;

            if (EsVectorCero(lineaInicioFin))
                return puntos;

            lineaInicioFin = lineaInicioFin.Normalize();

            bool giroUInicio = dirInicio.DotProduct(lineaInicioFin) < -0.25;
            bool giroUFin = dirFin.DotProduct(-lineaInicioFin) < -0.25;

            XYZ salidaInicio = p0 + dirInicio * recta;
            XYZ salidaFin = p1 + dirFin * recta;

            AgregarPuntoRutaFlexible(puntos, salidaInicio);

            if (giroUInicio)
            {
                XYZ extInicio = salidaInicio + dirInicio * radioU;
                XYZ lateralInicio = ProyectarPerpendicularFlexible(salidaFin - extInicio, dirInicio);

                if (EsVectorCero(lateralInicio))
                    lateralInicio = ObtenerPerpendicularSeguroFlexible(dirInicio, lineaInicioFin);

                lateralInicio = lateralInicio.Normalize();

                AgregarPuntoRutaFlexible(puntos, extInicio);
                AgregarPuntoRutaFlexible(puntos, extInicio + lateralInicio * radioU);
            }

            XYZ vectorEntreSalidas = salidaFin - salidaInicio;

            if (!EsVectorCero(vectorEntreSalidas) && salidaInicio.DistanceTo(salidaFin) > diametro * 2.0)
            {
                XYZ ultimo = puntos.Count > 0 ? puntos[puntos.Count - 1] : salidaInicio;
                XYZ previoFin = salidaFin;

                if (giroUFin)
                {
                    XYZ extFin = salidaFin + dirFin * radioU;
                    XYZ lateralFin = ProyectarPerpendicularFlexible(ultimo - extFin, dirFin);

                    if (EsVectorCero(lateralFin))
                        lateralFin = ObtenerPerpendicularSeguroFlexible(dirFin, -lineaInicioFin);

                    lateralFin = lateralFin.Normalize();
                    previoFin = extFin + lateralFin * radioU;
                }

                XYZ mitad = (ultimo + previoFin) * 0.5;
                AgregarPuntoRutaFlexible(puntos, mitad);

                if (giroUFin)
                {
                    XYZ extFin = salidaFin + dirFin * radioU;
                    AgregarPuntoRutaFlexible(puntos, previoFin);
                    AgregarPuntoRutaFlexible(puntos, extFin);
                }
            }

            AgregarPuntoRutaFlexible(puntos, salidaFin);
            AgregarPuntoRutaFlexible(puntos, p1);

            return LimpiarPuntosFlexibles(puntos, Math.Max(diametro * 0.25, UnitUtils.ConvertToInternalUnits(2.0, UnitTypeId.Millimeters)));
        }

        private void AgregarPuntoRutaFlexible(List<XYZ> puntos, XYZ p)
        {
            if (puntos == null || p == null || EsVectorCero(p))
                return;

            if (puntos.Count == 0 || puntos[puntos.Count - 1].DistanceTo(p) > UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Millimeters))
                puntos.Add(p);
        }

        private List<XYZ> LimpiarPuntosFlexibles(List<XYZ> puntos, double tolerancia)
        {
            List<XYZ> salida = new List<XYZ>();

            if (puntos == null)
                return salida;

            foreach (XYZ p in puntos)
            {
                if (p == null || EsVectorCero(p))
                    continue;

                if (salida.Count == 0 || salida[salida.Count - 1].DistanceTo(p) > tolerancia)
                    salida.Add(p);
            }

            return salida;
        }

        private XYZ ObtenerDireccionNormalSalidaFlexible(Connector conector, Element owner, Connector conectorOpuesto)
        {
            XYZ dir = XYZ.Zero;

            try
            {
                if (conector != null && conector.CoordinateSystem != null)
                    dir = conector.CoordinateSystem.BasisZ;
            }
            catch
            {
            }

            if (EsVectorCero(dir))
            {
                XYZ p = ObtenerOrigenSeguro(conector);
                XYZ pOtro = ObtenerOrigenSeguro(conectorOpuesto);

                if (!EsVectorCero(p) && !EsVectorCero(pOtro))
                    dir = pOtro - p;
            }

            if (EsVectorCero(dir))
                dir = XYZ.BasisZ;

            dir = dir.Normalize();

            XYZ origen = ObtenerOrigenSeguro(conector);
            XYZ centro = ObtenerCentroElementoFlexible(owner);
            XYZ desdeCentro = origen - centro;

            if (!EsVectorCero(desdeCentro))
            {
                desdeCentro = desdeCentro.Normalize();

                if (dir.DotProduct(desdeCentro) < 0.0)
                    dir = -dir;
            }
            else
            {
                XYZ pOtro = ObtenerOrigenSeguro(conectorOpuesto);

                if (!EsVectorCero(pOtro))
                {
                    XYZ haciaOtro = pOtro - origen;

                    if (!EsVectorCero(haciaOtro) && dir.DotProduct(haciaOtro.Normalize()) < -0.85)
                        dir = -dir;
                }
            }

            return dir.Normalize();
        }

        private XYZ ObtenerCentroElementoFlexible(Element e)
        {
            if (e == null)
                return XYZ.Zero;

            try
            {
                BoundingBoxXYZ bb = e.get_BoundingBox(null);

                if (bb != null)
                    return (bb.Min + bb.Max) * 0.5;
            }
            catch
            {
            }

            try
            {
                LocationPoint lp = e.Location as LocationPoint;

                if (lp != null)
                    return lp.Point;
            }
            catch
            {
            }

            return XYZ.Zero;
        }

        private XYZ ProyectarPerpendicularFlexible(XYZ vector, XYZ eje)
        {
            if (EsVectorCero(vector) || EsVectorCero(eje))
                return XYZ.Zero;

            XYZ e = eje.Normalize();
            XYZ r = vector - e * vector.DotProduct(e);

            if (EsVectorCero(r))
                return XYZ.Zero;

            return r.Normalize();
        }

        private XYZ ObtenerPerpendicularSeguroFlexible(XYZ eje, XYZ referencia)
        {
            XYZ r = ProyectarPerpendicularFlexible(referencia, eje);

            if (!EsVectorCero(r))
                return r.Normalize();

            XYZ e = EsVectorCero(eje) ? XYZ.BasisZ : eje.Normalize();
            XYZ baseRef = Math.Abs(e.DotProduct(XYZ.BasisZ)) < 0.90 ? XYZ.BasisZ : XYZ.BasisX;
            XYZ p = e.CrossProduct(baseRef);

            if (EsVectorCero(p))
                p = e.CrossProduct(XYZ.BasisY);

            if (EsVectorCero(p))
                return XYZ.BasisX;

            return p.Normalize();
        }

        private void AplicarTangentesFlexible(Element flexible, XYZ tangenteInicio, XYZ tangenteFin)
        {
            if (flexible == null)
                return;

            try
            {
                if (!EsVectorCero(tangenteInicio))
                {
                    System.Reflection.PropertyInfo pStart = flexible.GetType().GetProperty("StartTangent");

                    if (pStart != null && pStart.CanWrite)
                        pStart.SetValue(flexible, tangenteInicio.Normalize(), null);
                }
            }
            catch
            {
            }

            try
            {
                if (!EsVectorCero(tangenteFin))
                {
                    System.Reflection.PropertyInfo pEnd = flexible.GetType().GetProperty("EndTangent");

                    if (pEnd != null && pEnd.CanWrite)
                        pEnd.SetValue(flexible, tangenteFin.Normalize(), null);
                }
            }
            catch
            {
            }
        }

        private void AplicarDiametroFlexible(Element flexible, double diametroMm)
        {
            if (flexible == null)
                return;

            double diametro = UnitUtils.ConvertToInternalUnits(
                Math.Max(diametroMm, 1.0),
                UnitTypeId.Millimeters);

            try
            {
                System.Reflection.PropertyInfo pDiam = flexible.GetType().GetProperty("Diameter");

                if (pDiam != null && pDiam.CanWrite)
                    pDiam.SetValue(flexible, diametro, null);
            }
            catch
            {
            }

            string[] nombres = new string[]
            {
                "Diámetro",
                "Diametro",
                "Diameter",
                "Diámetro nominal",
                "Nominal Diameter",
                "D"
            };

            foreach (string nombre in nombres)
            {
                try
                {
                    Parameter p = flexible.LookupParameter(nombre);

                    if (p != null && !p.IsReadOnly && p.StorageType == StorageType.Double)
                        p.Set(diametro);
                }
                catch
                {
                }
            }

            string[] builtIns = new string[]
            {
                "RBS_PIPE_DIAMETER_PARAM",
                "RBS_CURVE_DIAMETER_PARAM",
                "RBS_FLEX_PIPE_DIAMETER_PARAM",
                "RBS_FLEX_DUCT_DIAMETER_PARAM"
            };

            foreach (string bipName in builtIns)
            {
                try
                {
                    BuiltInParameter bip;

                    if (!Enum.TryParse<BuiltInParameter>(bipName, out bip))
                        continue;

                    Parameter p = flexible.get_Parameter(bip);

                    if (p != null && !p.IsReadOnly && p.StorageType == StorageType.Double)
                        p.Set(diametro);
                }
                catch
                {
                }
            }
        }

        private int ConectarAmbosExtremosFlexible(Document doc, Element flexible, Connector conectorInicio, Connector conectorFin)
        {
            int confirmadas = 0;

            if (doc == null || flexible == null || conectorInicio == null || conectorFin == null)
                return confirmadas;

            try
            {
                XYZ pInicio = ObtenerOrigenSeguro(conectorInicio);
                XYZ pFin = ObtenerOrigenSeguro(conectorFin);

                List<Connector> conectoresFlex = ObtenerConectoresFlexibles(flexible);

                if (conectoresFlex == null || conectoresFlex.Count == 0)
                    return confirmadas;

                Connector flexInicio = ObtenerConectorMasCercanoEnLista(conectoresFlex, pInicio, null);
                Connector flexFin = ObtenerConectorMasCercanoEnLista(conectoresFlex, pFin, flexInicio);

                if (flexFin == null || object.ReferenceEquals(flexInicio, flexFin))
                    flexFin = ObtenerConectorMasLejanoEnLista(conectoresFlex, pInicio, flexInicio);

                if (flexInicio != null)
                {
                    if (ConectarDosConectoresRobusto(flexInicio, conectorInicio))
                        confirmadas++;

                    try { doc.Regenerate(); } catch { }
                }

                if (flexFin != null)
                {
                    if (ConectarDosConectoresRobusto(flexFin, conectorFin))
                        confirmadas++;

                    try { doc.Regenerate(); } catch { }
                }
            }
            catch
            {
            }

            return confirmadas;
        }

        private bool ConectarDosConectoresRobusto(Connector a, Connector b)
        {
            if (a == null || b == null)
                return false;

            try
            {
                if (a.IsConnectedTo(b))
                    return true;
            }
            catch
            {
            }

            try
            {
                a.ConnectTo(b);

                try
                {
                    if (a.IsConnectedTo(b))
                        return true;
                }
                catch
                {
                    return true;
                }
            }
            catch
            {
            }

            try
            {
                b.ConnectTo(a);

                try
                {
                    if (a.IsConnectedTo(b))
                        return true;
                }
                catch
                {
                    return true;
                }
            }
            catch
            {
            }

            return false;
        }

        private Connector ObtenerConectorMasCercanoEnLista(List<Connector> conectores, XYZ punto, Connector excluir)
        {
            if (conectores == null || conectores.Count == 0 || EsVectorCero(punto))
                return null;

            Connector mejor = null;
            double mejorDist = double.MaxValue;

            foreach (Connector c in conectores)
            {
                if (c == null)
                    continue;

                if (excluir != null && object.ReferenceEquals(c, excluir))
                    continue;

                XYZ p = ObtenerOrigenSeguro(c);

                if (EsVectorCero(p))
                    continue;

                double d = p.DistanceTo(punto);

                if (d < mejorDist)
                {
                    mejorDist = d;
                    mejor = c;
                }
            }

            return mejor;
        }

        private Connector ObtenerConectorMasLejanoEnLista(List<Connector> conectores, XYZ punto, Connector excluir)
        {
            if (conectores == null || conectores.Count == 0 || EsVectorCero(punto))
                return null;

            Connector mejor = null;
            double mejorDist = double.MinValue;

            foreach (Connector c in conectores)
            {
                if (c == null)
                    continue;

                if (excluir != null && object.ReferenceEquals(c, excluir))
                    continue;

                XYZ p = ObtenerOrigenSeguro(c);

                if (EsVectorCero(p))
                    continue;

                double d = p.DistanceTo(punto);

                if (d > mejorDist)
                {
                    mejorDist = d;
                    mejor = c;
                }
            }

            return mejor;
        }

        private bool EstaConectado(Connector c)
        {
            if (c == null)
                return false;

            try
            {
                return c.IsConnected;
            }
            catch
            {
                return false;
            }
        }

        private bool EsDominioPiping(Connector c)
        {
            if (c == null)
                return false;

            try
            {
                string d = c.Domain.ToString().ToUpperInvariant();
                return d.Contains("PIPING") || d.Contains("PIPE");
            }
            catch
            {
                return false;
            }
        }

        private bool EsDominioHvac(Connector c)
        {
            if (c == null)
                return false;

            try
            {
                string d = c.Domain.ToString().ToUpperInvariant();
                return d.Contains("HVAC") || d.Contains("DUCT");
            }
            catch
            {
                return false;
            }
        }

        private XYZ ObtenerOrigenSeguro(Connector c)
        {
            if (c == null)
                return XYZ.Zero;

            try
            {
                return c.Origin;
            }
            catch
            {
                return XYZ.Zero;
            }
        }

        private void MarcarFlexibleProyectado(Element e)
        {
            if (e == null)
                return;

            try
            {
                Parameter p = e.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);

                if (p != null && !p.IsReadOnly)
                    p.Set("MYG_OCTOGONAL_FLEXIBLE_55");
            }
            catch
            {
            }
        }

        private class DatosCaraObjetivo55
        {
            public Reference FaceReference;
            public Element Elemento;
            public Element ElementoVinculo;
            public bool EsVinculo;
            public XYZ Punto;
            public XYZ Normal;
            public XYZ EjeX;
            public XYZ EjeY;
        }

        private class ParConectoresProyectado55
        {
            public Connector A { get; set; }
            public Connector B { get; set; }
            public bool EsPipe { get; set; }
            public bool EsDuct { get; set; }
        }

        private class ResultadoFlexibleProyectado55
        {
            public bool Ok { get; set; }
            public bool SinConector { get; set; }
            public ElementId IdCreado { get; set; }
            public int ConexionesConfirmadas { get; set; }
            public string Error { get; set; }
        }

        private class FiltroFamiliasBaseProyeccion55 : ISelectionFilter
        {
            public bool AllowElement(Element elem)
            {
                if (elem == null)
                    return false;

                if (!(elem is FamilyInstance))
                    return false;

                if (elem.Category == null)
                    return false;

                return true;
            }

            public bool AllowReference(Reference reference, XYZ position)
            {
                return true;
            }
        }

        private class EleProyectarOctogonales55FailurePreprocessor : IFailuresPreprocessor
        {
            public FailureProcessingResult PreprocessFailures(FailuresAccessor failuresAccessor)
            {
                try
                {
                    IList<FailureMessageAccessor> failures = failuresAccessor.GetFailureMessages();

                    foreach (FailureMessageAccessor f in failures)
                    {
                        if (f == null)
                            continue;

                        FailureSeverity severity = f.GetSeverity();

                        if (severity == FailureSeverity.Warning)
                            failuresAccessor.DeleteWarning(f);
                    }
                }
                catch
                {
                }

                return FailureProcessingResult.Continue;
            }
        }
    }
}
