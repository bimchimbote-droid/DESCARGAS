﻿using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_Addin
{
    // =====================================
    // COMANDO 5.6 - ALINEAR SECCIÓN A TUBO
    // SIN VENTANA
    //
    // FLUJO:
    // 1) PICAR TUBERÍA / TUBO / CONDUIT
    // 2) PICAR UN PUNTO SOBRE LA LÍNEA DEL CORTE
    // 3) ESE PUNTO SE COLOCA EN EL EJE DEL TUBO
    // 4) EL CORTE SE ROTA PARA QUEDAR PARALELO AL TUBO
    // =====================================

    [Transaction(TransactionMode.Manual)]
    public class EleAlinearSeccionTubo56Command : IExternalCommand
    {
        private const double TOL = 1e-9;

        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            try
            {
                UIApplication uiapp = commandData.Application;
                UIDocument uidoc = uiapp == null ? null : uiapp.ActiveUIDocument;
                Document doc = uidoc == null ? null : uidoc.Document;

                if (uidoc == null || doc == null)
                {
                    message = "No hay documento activo.";
                    return Result.Failed;
                }

                View vistaActiva = doc.ActiveView;

                // =====================================================
                // 1. SELECCIONAR TUBERÍA / TUBO / CONDUIT
                // =====================================================
                Reference refTubo =
                    uidoc.Selection.PickObject(
                        ObjectType.Element,
                        new FiltroTuboMEP(),
                        "Selecciona primero la tubería / tubo / conduit");

                if (refTubo == null)
                    return Result.Cancelled;

                Element elemTubo = doc.GetElement(refTubo.ElementId);

                if (!EsTuboMEPValido(elemTubo))
                {
                    message = "El primer elemento seleccionado no es una tubería/tubo/conduit válido.";
                    return Result.Cancelled;
                }

                LocationCurve locCurve =
                    elemTubo.Location as LocationCurve;

                if (locCurve == null || locCurve.Curve == null)
                {
                    message = "No se pudo obtener el eje central del tubo.";
                    return Result.Cancelled;
                }

                Curve curvaTubo = locCurve.Curve;

                XYZ centroTubo = ObtenerCentroCurva(curvaTubo);
                XYZ direccionTubo = ObtenerDireccionCurva(curvaTubo);

                if (direccionTubo == null || direccionTubo.GetLength() < TOL)
                {
                    message = "No se pudo obtener la dirección del tubo.";
                    return Result.Cancelled;
                }

                direccionTubo = direccionTubo.Normalize();

                XYZ direccionTuboXY =
                    new XYZ(
                        direccionTubo.X,
                        direccionTubo.Y,
                        0.0);

                bool tuboVertical = direccionTuboXY.GetLength() < 0.0001;

                if (!tuboVertical)
                    direccionTuboXY = direccionTuboXY.Normalize();

                // =====================================================
                // 2. PICAR PUNTO SOBRE LA LÍNEA DEL CORTE
                // =====================================================
                // IMPORTANTE:
                // Usamos PointOnElement para obtener el punto exacto donde picas.
                // Ese punto se llevará al eje del tubo.
                Reference refMarcador =
                    uidoc.Selection.PickObject(
                        ObjectType.PointOnElement,
                        "Pica un punto SOBRE LA LÍNEA del corte que quieres alinear");

                if (refMarcador == null)
                    return Result.Cancelled;

                Element marcadorSeccion =
                    doc.GetElement(refMarcador.ElementId);

                if (marcadorSeccion == null)
                {
                    message = "No se pudo obtener el marcador de sección seleccionado.";
                    return Result.Cancelled;
                }

                XYZ puntoPicadoCorte = null;

                try
                {
                    puntoPicadoCorte = refMarcador.GlobalPoint;
                }
                catch
                {
                    puntoPicadoCorte = null;
                }

                if (!EsPuntoValido(puntoPicadoCorte))
                {
                    message =
                        "No se pudo obtener el punto picado sobre el corte.\n" +
                        "Vuelve a ejecutar y pica directamente sobre la línea del corte.";

                    return Result.Cancelled;
                }

                // =====================================================
                // 3. OBTENER DIRECCIÓN ACTUAL DEL CORTE
                // =====================================================
                // Primero intentamos desde la sección real asociada/cercana.
                XYZ direccionActualCorte =
                    ObtenerDireccionCorteDesdeSeccionCercana(
                        doc,
                        vistaActiva,
                        refMarcador,
                        marcadorSeccion);

                // Respaldo: intentar leer líneas de geometría, si Revit las entrega.
                if (direccionActualCorte == null ||
                    direccionActualCorte.GetLength() < 0.0001)
                {
                    direccionActualCorte =
                        ObtenerDireccionMarcadorPorGeometria(
                            marcadorSeccion,
                            vistaActiva);
                }

                // Último respaldo: usar el bounding box visible.
                // Sirve para cortes horizontales o verticales.
                if (direccionActualCorte == null ||
                    direccionActualCorte.GetLength() < 0.0001)
                {
                    direccionActualCorte =
                        ObtenerDireccionPorBoundingBox(
                            marcadorSeccion,
                            vistaActiva);
                }

                if (!tuboVertical &&
                    (direccionActualCorte == null ||
                     direccionActualCorte.GetLength() < 0.0001))
                {
                    message =
                        "No se pudo obtener la dirección actual del corte.\n" +
                        "Prueba picando sobre la línea larga del corte.";

                    return Result.Cancelled;
                }

                if (direccionActualCorte != null &&
                    direccionActualCorte.GetLength() > 0.0001)
                {
                    direccionActualCorte = direccionActualCorte.Normalize();
                }

                // =====================================================
                // 4. MOVER Y ROTAR MARCADOR
                // =====================================================
                using (Transaction tx =
                    new Transaction(doc, "MYG - Alinear sección a tubo"))
                {
                    tx.Start();

                    bool estabaFijado = marcadorSeccion.Pinned;

                    if (estabaFijado)
                        marcadorSeccion.Pinned = false;

                    // El punto que picamos sobre el corte se mueve al centro/eje del tubo.
                    XYZ destinoPuntoCorte =
                        new XYZ(
                            centroTubo.X,
                            centroTubo.Y,
                            puntoPicadoCorte.Z);

                    XYZ vectorMovimiento =
                        destinoPuntoCorte - puntoPicadoCorte;

                    if (vectorMovimiento.GetLength() > 0.000001)
                    {
                        ElementTransformUtils.MoveElement(
                            doc,
                            marcadorSeccion.Id,
                            vectorMovimiento);
                    }

                    doc.Regenerate();

                    // Rotamos alrededor del punto que ya quedó sobre el eje del tubo.
                    if (!tuboVertical)
                    {
                        XYZ ejeActual = direccionActualCorte;
                        XYZ ejeDeseado = direccionTuboXY;

                        // Evita giro innecesario de 180 grados.
                        if (ejeActual.DotProduct(ejeDeseado) < 0.0)
                        {
                            ejeDeseado =
                                new XYZ(
                                    -ejeDeseado.X,
                                    -ejeDeseado.Y,
                                    -ejeDeseado.Z);
                        }

                        double angulo =
                            ObtenerAnguloFirmadoEnXY(
                                ejeActual,
                                ejeDeseado);

                        if (Math.Abs(angulo) > 0.0000001)
                        {
                            Line ejeRotacion =
                                Line.CreateBound(
                                    destinoPuntoCorte,
                                    destinoPuntoCorte + XYZ.BasisZ);

                            ElementTransformUtils.RotateElement(
                                doc,
                                marcadorSeccion.Id,
                                ejeRotacion,
                                angulo);
                        }
                    }

                    if (estabaFijado)
                        marcadorSeccion.Pinned = true;

                    tx.Commit();
                }

                return Result.Succeeded;
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                return Result.Cancelled;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return Result.Failed;
            }
        }

        // =====================================================
        // VALIDACIÓN TUBO
        // =====================================================
        private static bool EsTuboMEPValido(Element elem)
        {
            if (elem == null)
                return false;

            if (!(elem is MEPCurve))
                return false;

            if (!(elem.Location is LocationCurve))
                return false;

            return true;
        }

        // =====================================================
        // CENTRO Y DIRECCIÓN DE TUBO
        // =====================================================
        private static XYZ ObtenerCentroCurva(Curve curva)
        {
            try
            {
                return curva.Evaluate(0.5, true);
            }
            catch
            {
                XYZ p0 = curva.GetEndPoint(0);
                XYZ p1 = curva.GetEndPoint(1);

                return new XYZ(
                    (p0.X + p1.X) * 0.5,
                    (p0.Y + p1.Y) * 0.5,
                    (p0.Z + p1.Z) * 0.5);
            }
        }

        private static XYZ ObtenerDireccionCurva(Curve curva)
        {
            Line linea = curva as Line;

            if (linea != null)
            {
                XYZ p0 = linea.GetEndPoint(0);
                XYZ p1 = linea.GetEndPoint(1);

                XYZ dir = p1 - p0;

                if (dir.GetLength() > TOL)
                    return dir.Normalize();
            }

            try
            {
                XYZ pA = curva.Evaluate(0.49, true);
                XYZ pB = curva.Evaluate(0.51, true);

                XYZ dir = pB - pA;

                if (dir.GetLength() > TOL)
                    return dir.Normalize();
            }
            catch
            {
            }

            try
            {
                XYZ p0 = curva.GetEndPoint(0);
                XYZ p1 = curva.GetEndPoint(1);

                XYZ dir = p1 - p0;

                if (dir.GetLength() > TOL)
                    return dir.Normalize();
            }
            catch
            {
            }

            return null;
        }

        // =====================================================
        // DIRECCIÓN DESDE VIEWSECTION CERCANA
        // =====================================================
        private static XYZ ObtenerDireccionCorteDesdeSeccionCercana(
            Document doc,
            View vistaActiva,
            Reference referencia,
            Element marcadorSeccion)
        {
            ViewSection sec =
                BuscarSeccionVisibleMasCercana(
                    doc,
                    vistaActiva,
                    referencia,
                    marcadorSeccion);

            if (sec == null)
                return null;

            BoundingBoxXYZ crop = null;

            try
            {
                crop = sec.CropBox;
            }
            catch
            {
                crop = null;
            }

            if (crop == null)
                return null;

            XYZ eje = crop.Transform.BasisX;

            XYZ ejeXY =
                new XYZ(
                    eje.X,
                    eje.Y,
                    0.0);

            if (ejeXY.GetLength() < 0.0001)
                return null;

            return ejeXY.Normalize();
        }

        private static ViewSection BuscarSeccionVisibleMasCercana(
            Document doc,
            View vistaActiva,
            Reference referencia,
            Element marcadorSeccion)
        {
            if (doc == null || vistaActiva == null)
                return null;

            XYZ punto =
                ObtenerPuntoReferencia(
                    referencia,
                    marcadorSeccion,
                    vistaActiva);

            if (!EsPuntoValido(punto))
                return null;

            List<ViewSection> secciones =
                new FilteredElementCollector(doc)
                    .OfClass(typeof(ViewSection))
                    .Cast<ViewSection>()
                    .Where(x => EsSeccionValida(x))
                    .ToList();

            ViewSection mejor = null;
            double mejorDistancia = double.MaxValue;

            foreach (ViewSection sec in secciones)
            {
                BoundingBoxXYZ bbVista = null;

                try
                {
                    bbVista = sec.get_BoundingBox(vistaActiva);
                }
                catch
                {
                    bbVista = null;
                }

                if (bbVista == null)
                    continue;

                XYZ c = ObtenerCentroBoundingBox(bbVista);

                if (!EsPuntoValido(c))
                    continue;

                double d = DistanciaXY(punto, c);

                if (d < mejorDistancia)
                {
                    mejorDistancia = d;
                    mejor = sec;
                }
            }

            if (mejor != null)
                return mejor;

            foreach (ViewSection sec in secciones)
            {
                BoundingBoxXYZ crop = null;

                try
                {
                    crop = sec.CropBox;
                }
                catch
                {
                    crop = null;
                }

                if (crop == null)
                    continue;

                XYZ c = ObtenerCentroCropBoxEnModelo(crop);

                if (!EsPuntoValido(c))
                    continue;

                double d = DistanciaXY(punto, c);

                if (d < mejorDistancia)
                {
                    mejorDistancia = d;
                    mejor = sec;
                }
            }

            return mejor;
        }

        private static bool EsSeccionValida(ViewSection seccion)
        {
            if (seccion == null)
                return false;

            if (seccion.IsTemplate)
                return false;

            if (seccion.ViewType != ViewType.Section)
                return false;

            return true;
        }

        // =====================================================
        // RESPALDO: DIRECCIÓN POR GEOMETRÍA
        // =====================================================
        private static XYZ ObtenerDireccionMarcadorPorGeometria(
            Element elem,
            View vista)
        {
            if (elem == null || vista == null)
                return null;

            try
            {
                Options opt = new Options();
                opt.View = vista;
                opt.IncludeNonVisibleObjects = true;
                opt.DetailLevel = ViewDetailLevel.Fine;

                GeometryElement geo =
                    elem.get_Geometry(opt);

                if (geo == null)
                    return null;

                List<Line> lineas = new List<Line>();

                ExtraerLineasGeometria(
                    geo,
                    Transform.Identity,
                    lineas);

                Line mejorLinea = null;
                double mejorLongitud = 0.0;

                foreach (Line l in lineas)
                {
                    if (l == null)
                        continue;

                    XYZ p0 = l.GetEndPoint(0);
                    XYZ p1 = l.GetEndPoint(1);

                    XYZ dirXY =
                        new XYZ(
                            p1.X - p0.X,
                            p1.Y - p0.Y,
                            0.0);

                    double longXY = dirXY.GetLength();

                    if (longXY > mejorLongitud)
                    {
                        mejorLongitud = longXY;
                        mejorLinea = l;
                    }
                }

                if (mejorLinea == null || mejorLongitud < 0.0001)
                    return null;

                XYZ a = mejorLinea.GetEndPoint(0);
                XYZ b = mejorLinea.GetEndPoint(1);

                XYZ dir =
                    new XYZ(
                        b.X - a.X,
                        b.Y - a.Y,
                        0.0);

                if (dir.GetLength() < 0.0001)
                    return null;

                return dir.Normalize();
            }
            catch
            {
                return null;
            }
        }

        private static void ExtraerLineasGeometria(
            GeometryElement geo,
            Transform transformAcumulado,
            List<Line> lineas)
        {
            if (geo == null || lineas == null)
                return;

            foreach (GeometryObject obj in geo)
            {
                if (obj == null)
                    continue;

                Line linea = obj as Line;

                if (linea != null)
                {
                    XYZ p0 = transformAcumulado.OfPoint(linea.GetEndPoint(0));
                    XYZ p1 = transformAcumulado.OfPoint(linea.GetEndPoint(1));

                    lineas.Add(Line.CreateBound(p0, p1));
                    continue;
                }

                Curve curva = obj as Curve;

                if (curva != null)
                {
                    Line l = curva as Line;

                    if (l != null)
                    {
                        XYZ p0 = transformAcumulado.OfPoint(l.GetEndPoint(0));
                        XYZ p1 = transformAcumulado.OfPoint(l.GetEndPoint(1));

                        lineas.Add(Line.CreateBound(p0, p1));
                    }

                    continue;
                }

                GeometryInstance gi = obj as GeometryInstance;

                if (gi != null)
                {
                    try
                    {
                        Transform t = transformAcumulado.Multiply(gi.Transform);

                        GeometryElement geoInst =
                            gi.GetInstanceGeometry();

                        ExtraerLineasGeometria(
                            geoInst,
                            t,
                            lineas);
                    }
                    catch
                    {
                    }
                }
            }
        }

        // =====================================================
        // ÚLTIMO RESPALDO: BOUNDING BOX
        // =====================================================
        private static XYZ ObtenerDireccionPorBoundingBox(
            Element elem,
            View vista)
        {
            if (elem == null)
                return null;

            BoundingBoxXYZ bb = null;

            try
            {
                bb = elem.get_BoundingBox(vista);
            }
            catch
            {
                bb = null;
            }

            if (bb == null)
            {
                try
                {
                    bb = elem.get_BoundingBox(null);
                }
                catch
                {
                    bb = null;
                }
            }

            if (bb == null)
                return null;

            double dx = Math.Abs(bb.Max.X - bb.Min.X);
            double dy = Math.Abs(bb.Max.Y - bb.Min.Y);

            if (dx < 0.0001 && dy < 0.0001)
                return null;

            if (dx >= dy)
                return XYZ.BasisX;

            return XYZ.BasisY;
        }

        // =====================================================
        // UTILIDADES
        // =====================================================
        private static XYZ ObtenerPuntoReferencia(
            Reference referencia,
            Element elem,
            View vista)
        {
            if (referencia != null)
            {
                try
                {
                    XYZ p = referencia.GlobalPoint;

                    if (EsPuntoValido(p))
                        return p;
                }
                catch
                {
                }
            }

            if (elem != null)
            {
                try
                {
                    BoundingBoxXYZ bb = elem.get_BoundingBox(vista);

                    if (bb != null)
                        return ObtenerCentroBoundingBox(bb);
                }
                catch
                {
                }

                try
                {
                    BoundingBoxXYZ bb = elem.get_BoundingBox(null);

                    if (bb != null)
                        return ObtenerCentroBoundingBox(bb);
                }
                catch
                {
                }
            }

            return null;
        }

        private static XYZ ObtenerCentroBoundingBox(
            BoundingBoxXYZ bb)
        {
            if (bb == null)
                return null;

            XYZ min = bb.Min;
            XYZ max = bb.Max;

            XYZ c =
                new XYZ(
                    (min.X + max.X) * 0.5,
                    (min.Y + max.Y) * 0.5,
                    (min.Z + max.Z) * 0.5);

            try
            {
                if (bb.Transform != null)
                    return bb.Transform.OfPoint(c);
            }
            catch
            {
            }

            return c;
        }

        private static XYZ ObtenerCentroCropBoxEnModelo(
            BoundingBoxXYZ crop)
        {
            if (crop == null)
                return null;

            XYZ min = crop.Min;
            XYZ max = crop.Max;

            XYZ c =
                new XYZ(
                    (min.X + max.X) * 0.5,
                    (min.Y + max.Y) * 0.5,
                    (min.Z + max.Z) * 0.5);

            try
            {
                return crop.Transform.OfPoint(c);
            }
            catch
            {
                return c;
            }
        }

        private static double ObtenerAnguloFirmadoEnXY(
            XYZ desde,
            XYZ hacia)
        {
            XYZ a =
                new XYZ(
                    desde.X,
                    desde.Y,
                    0.0);

            XYZ b =
                new XYZ(
                    hacia.X,
                    hacia.Y,
                    0.0);

            if (a.GetLength() < TOL || b.GetLength() < TOL)
                return 0.0;

            a = a.Normalize();
            b = b.Normalize();

            double crossZ = a.X * b.Y - a.Y * b.X;
            double dot = a.X * b.X + a.Y * b.Y;

            return Math.Atan2(crossZ, dot);
        }

        private static double DistanciaXY(
            XYZ a,
            XYZ b)
        {
            if (a == null || b == null)
                return double.MaxValue;

            double dx = a.X - b.X;
            double dy = a.Y - b.Y;

            return Math.Sqrt(dx * dx + dy * dy);
        }

        private static bool EsPuntoValido(XYZ p)
        {
            if (p == null)
                return false;

            if (double.IsNaN(p.X) ||
                double.IsNaN(p.Y) ||
                double.IsNaN(p.Z))
                return false;

            if (double.IsInfinity(p.X) ||
                double.IsInfinity(p.Y) ||
                double.IsInfinity(p.Z))
                return false;

            return true;
        }

        // =====================================================
        // FILTRO TUBO
        // =====================================================
        private class FiltroTuboMEP : ISelectionFilter
        {
            public bool AllowElement(Element elem)
            {
                return EsTuboMEPValido(elem);
            }

            public bool AllowReference(
                Reference reference,
                XYZ position)
            {
                return false;
            }
        }
    }
}