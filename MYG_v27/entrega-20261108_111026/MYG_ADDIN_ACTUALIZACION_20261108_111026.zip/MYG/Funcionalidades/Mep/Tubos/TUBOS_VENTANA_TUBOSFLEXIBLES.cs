﻿// =====================================
// VENTANA 5.5 - TUBOS FLEXIBLES
// Contenido embebible para MYG_TubosAutomaticos55MainForm
// V16: recuerda última configuración de inputs y tipo flexible
// SIN USING NI NAMESPACE
// =====================================

public class EleTubosFlexibles55Form : System.Windows.Forms.Form
{
    private readonly global::MYG_Addin.EjecutarEleTubosFlexibles55Handler _handler;
    private readonly Autodesk.Revit.UI.ExternalEvent _externalEvent;

    private System.Windows.Forms.ComboBox cmbTipoFlexible;
    private System.Windows.Forms.NumericUpDown nudDiametroFlexibleMm;
    private System.Windows.Forms.NumericUpDown nudTramoRectoM;
    private System.Windows.Forms.Button btnCrearFlexible;
    private System.Windows.Forms.CheckBox chkSeleccionarResultado;
    private System.Windows.Forms.CheckBox chkPreferirConectoresLibres;
    private System.Windows.Forms.RichTextBox txtResultado;

    private const string ArchivoConfigNombre = "MYG_TubosFlexibles55_Config.ini";
    private long _tipoFlexibleIdGuardado = long.MinValue;
    private string _tipoFlexibleTextoGuardado = "";
    private bool _configuracionYaCargada = false;

    public EleTubosFlexibles55Form(
        global::MYG_Addin.EjecutarEleTubosFlexibles55Handler handler,
        Autodesk.Revit.UI.ExternalEvent externalEvent)
    {
        _handler = handler;
        _externalEvent = externalEvent;

        this.Text = "Tubos flexibles";
        this.Width = 760;
        this.Height = 735;
        this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
        this.TopLevel = false;
        this.ShowInTaskbar = false;
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.Dock = System.Windows.Forms.DockStyle.Fill;
        this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
        this.Font = new System.Drawing.Font("Segoe UI", 9F);
        this.TopMost = false;

        InicializarComponentes();
        this.FormClosing += (s, e) => GuardarConfiguracion();
    }

    private void InicializarComponentes()
    {
        System.Windows.Forms.Label lblAutor = new System.Windows.Forms.Label()
        {
            Text = "Creado por: Ing. Marlon Yacila  |  MEP - Tubos flexibles entre equipos",
            Left = 20,
            Top = 10,
            Width = 700,
            Height = 20,
            Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
            ForeColor = System.Drawing.Color.Gray
        };

        System.Windows.Forms.Label lblTitulo = CrearTitulo("01. CONFIGURACIÓN DEL TUBO FLEXIBLE", 20, 42, 700);

        System.Windows.Forms.Label lblInfo = new System.Windows.Forms.Label()
        {
            Text = "Selecciona un tipo flexible o deja Automático. Indica diámetro y tramo recto inicial/final. El radio de giro se calcula automáticamente según el diámetro para evitar curvas tipo línea. ESC para terminar.",
            Left = 20,
            Top = 68,
            Width = 700,
            Height = 48,
            ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
        };

        System.Windows.Forms.Label lblTipo = CrearLabel("Tipo flexible:", 20, 132, 145);

        cmbTipoFlexible = new System.Windows.Forms.ComboBox()
        {
            Left = 170,
            Top = 129,
            Width = 540,
            Height = 24,
            DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown,
            AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend,
            AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        };

        System.Windows.Forms.Label lblDiametro = CrearLabel("Diámetro flexible (mm):", 20, 172, 145);

        nudDiametroFlexibleMm = new System.Windows.Forms.NumericUpDown()
        {
            Left = 170,
            Top = 169,
            Width = 85,
            Height = 24,
            DecimalPlaces = 1,
            Increment = 1,
            Minimum = 1,
            Maximum = 500,
            Value = 20
        };

        System.Windows.Forms.Label lblTramoRecto = CrearLabel("Tramo recto salida (m):", 300, 172, 160);

        nudTramoRectoM = new System.Windows.Forms.NumericUpDown()
        {
            Left = 470,
            Top = 169,
            Width = 85,
            Height = 24,
            DecimalPlaces = 3,
            Increment = 0.050M,
            Minimum = 0.020M,
            Maximum = 5,
            Value = 0.200M
        };

        System.Windows.Forms.Label lblRadioGiro = CrearLabel("Radio giro U:", 20, 212, 145);

        System.Windows.Forms.Label lblRadioAuto = new System.Windows.Forms.Label()
        {
            Text = "Automático según diámetro",
            Left = 170,
            Top = 212,
            Width = 260,
            Height = 22,
            ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
        };

        chkPreferirConectoresLibres = new System.Windows.Forms.CheckBox()
        {
            Text = "Preferir conectores libres",
            Left = 20,
            Top = 248,
            Width = 250,
            Height = 24,
            Checked = true
        };

        chkSeleccionarResultado = new System.Windows.Forms.CheckBox()
        {
            Text = "Seleccionar tubos flexibles creados en Revit al terminar",
            Left = 300,
            Top = 248,
            Width = 410,
            Height = 24,
            Checked = true
        };

        System.Windows.Forms.Label lblFlujo = CrearTitulo("02. FLUJO DE SELECCIÓN", 20, 292, 700);

        System.Windows.Forms.Label lblNota = new System.Windows.Forms.Label()
        {
            Text = "La herramienta detecta conectores físicos HVAC o Piping. El flexible arranca recto normal al plano del conector. Si la salida mira al lado contrario, calcula un radio U automático proporcional al diámetro para abrir más la vuelta.",
            Left = 20,
            Top = 322,
            Width = 700,
            Height = 54,
            ForeColor = System.Drawing.Color.FromArgb(90, 90, 90)
        };

        System.Windows.Forms.Label lblResultado = CrearTitulo("03. RESULTADO", 20, 390, 700);

        txtResultado = new System.Windows.Forms.RichTextBox()
        {
            Left = 20,
            Top = 420,
            Width = 690,
            Height = 160,
            ReadOnly = true,
            BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
            BackColor = System.Drawing.Color.White,
            Font = new System.Drawing.Font("Consolas", 8.5F),
            WordWrap = false,
            ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        };

        btnCrearFlexible = CrearBoton(
            "CREAR TUBO FLEXIBLE",
            245,
            610,
            280,
            System.Drawing.Color.FromArgb(0, 120, 215));

        btnCrearFlexible.Height = 42;
        btnCrearFlexible.Click += (s, e) => EjecutarCreacionFlexible();

        this.Controls.Add(lblAutor);
        this.Controls.Add(lblTitulo);
        this.Controls.Add(lblInfo);
        this.Controls.Add(lblTipo);
        this.Controls.Add(cmbTipoFlexible);
        this.Controls.Add(lblDiametro);
        this.Controls.Add(nudDiametroFlexibleMm);
        this.Controls.Add(lblTramoRecto);
        this.Controls.Add(nudTramoRectoM);
        this.Controls.Add(lblRadioGiro);
        this.Controls.Add(lblRadioAuto);
        this.Controls.Add(chkPreferirConectoresLibres);
        this.Controls.Add(chkSeleccionarResultado);
        this.Controls.Add(lblFlujo);
        this.Controls.Add(lblNota);
        this.Controls.Add(lblResultado);
        this.Controls.Add(txtResultado);
        this.Controls.Add(btnCrearFlexible);

        CargarConfiguracion();
        MostrarResultado("Carga los tipos flexibles y presiona CREAR TUBO FLEXIBLE.");
    }

    private System.Windows.Forms.Label CrearTitulo(string texto, int left, int top, int width)
    {
        return new System.Windows.Forms.Label()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 22,
            Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
            ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
        };
    }

    private System.Windows.Forms.Label CrearLabel(string texto, int left, int top, int width)
    {
        return new System.Windows.Forms.Label()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 22
        };
    }

    private System.Windows.Forms.Button CrearBoton(
        string texto,
        int left,
        int top,
        int width,
        System.Drawing.Color color)
    {
        System.Windows.Forms.Button boton = new System.Windows.Forms.Button()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 32,
            BackColor = color,
            ForeColor = System.Drawing.Color.White,
            FlatStyle = System.Windows.Forms.FlatStyle.Flat,
            Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
            Cursor = System.Windows.Forms.Cursors.Hand
        };

        boton.FlatAppearance.BorderSize = 0;
        boton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(
            System.Math.Max(color.R - 15, 0),
            System.Math.Max(color.G - 15, 0),
            System.Math.Max(color.B - 15, 0));

        return boton;
    }

    public void SolicitarCargaInicial()
    {
        Ejecutar(global::MYG_Addin.EleTubosFlexibles55Request.CargarDatos);
    }

    public void SetTiposFlexibles(
        System.Collections.Generic.List<global::MYG_Addin.EleTubosFlexibles55TipoInfo> tipos)
    {
        if (cmbTipoFlexible == null || cmbTipoFlexible.IsDisposed)
            return;

        if (this.InvokeRequired)
        {
            this.BeginInvoke(new System.Action(() => SetTiposFlexibles(tipos)));
            return;
        }

        long seleccionadoActual = long.MinValue;
        string textoActual = cmbTipoFlexible.Text;

        global::MYG_Addin.EleTubosFlexibles55TipoInfo actual =
            cmbTipoFlexible.SelectedItem as global::MYG_Addin.EleTubosFlexibles55TipoInfo;

        if (actual != null && actual.Id != null)
            seleccionadoActual = actual.Id.Value;

        if (seleccionadoActual == long.MinValue && _tipoFlexibleIdGuardado != long.MinValue)
            seleccionadoActual = _tipoFlexibleIdGuardado;

        if (string.IsNullOrWhiteSpace(textoActual) &&
            !string.IsNullOrWhiteSpace(_tipoFlexibleTextoGuardado))
        {
            textoActual = _tipoFlexibleTextoGuardado;
        }

        cmbTipoFlexible.Items.Clear();

        if (tipos != null)
        {
            foreach (global::MYG_Addin.EleTubosFlexibles55TipoInfo t in tipos)
            {
                if (t != null)
                    cmbTipoFlexible.Items.Add(t);
            }
        }

        if (cmbTipoFlexible.Items.Count > 0)
        {
            int index = -1;

            if (seleccionadoActual != long.MinValue)
            {
                for (int i = 0; i < cmbTipoFlexible.Items.Count; i++)
                {
                    global::MYG_Addin.EleTubosFlexibles55TipoInfo item =
                        cmbTipoFlexible.Items[i] as global::MYG_Addin.EleTubosFlexibles55TipoInfo;

                    if (item != null && item.Id != null && item.Id.Value == seleccionadoActual)
                    {
                        index = i;
                        break;
                    }
                }
            }

            if (index < 0 && !string.IsNullOrWhiteSpace(textoActual))
            {
                for (int i = 0; i < cmbTipoFlexible.Items.Count; i++)
                {
                    object item = cmbTipoFlexible.Items[i];
                    string textoItem = item == null ? "" : item.ToString();

                    if (string.Equals(textoItem.Trim(), textoActual.Trim(), System.StringComparison.OrdinalIgnoreCase) ||
                        textoItem.IndexOf(textoActual.Trim(), System.StringComparison.OrdinalIgnoreCase) >= 0 ||
                        textoActual.IndexOf(textoItem.Trim(), System.StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        index = i;
                        break;
                    }
                }
            }

            if (index >= 0)
                cmbTipoFlexible.SelectedIndex = index;
            else if (!string.IsNullOrWhiteSpace(textoActual))
                cmbTipoFlexible.Text = textoActual;
            else
                cmbTipoFlexible.SelectedIndex = 0;
        }
        else if (!string.IsNullOrWhiteSpace(textoActual))
        {
            cmbTipoFlexible.Text = textoActual;
        }
    }

    private global::MYG_Addin.EleTubosFlexibles55TipoInfo ObtenerTipoFlexibleSeleccionado()
    {
        global::MYG_Addin.EleTubosFlexibles55TipoInfo tipo =
            cmbTipoFlexible == null ? null : cmbTipoFlexible.SelectedItem as global::MYG_Addin.EleTubosFlexibles55TipoInfo;

        if (tipo != null)
            return tipo;

        string texto = cmbTipoFlexible == null ? "" : cmbTipoFlexible.Text;

        if (string.IsNullOrWhiteSpace(texto) || cmbTipoFlexible == null)
            return null;

        for (int i = 0; i < cmbTipoFlexible.Items.Count; i++)
        {
            global::MYG_Addin.EleTubosFlexibles55TipoInfo item =
                cmbTipoFlexible.Items[i] as global::MYG_Addin.EleTubosFlexibles55TipoInfo;

            if (item == null)
                continue;

            string textoItem = item.ToString();

            if (string.Equals(textoItem.Trim(), texto.Trim(), System.StringComparison.OrdinalIgnoreCase) ||
                textoItem.Trim().StartsWith(texto.Trim(), System.StringComparison.OrdinalIgnoreCase) ||
                textoItem.IndexOf(texto.Trim(), System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                cmbTipoFlexible.SelectedIndex = i;
                return item;
            }
        }

        return null;
    }

    private void EjecutarCreacionFlexible()
    {
        global::MYG_Addin.EleTubosFlexibles55TipoInfo tipo = ObtenerTipoFlexibleSeleccionado();

        if (tipo == null)
        {
            MostrarResultado("Selecciona un tipo flexible válido o Automático.");
            return;
        }

        _handler.TipoSeleccionado = tipo;
        _handler.DiametroFlexibleMm = (double)nudDiametroFlexibleMm.Value;
        _handler.LongitudRectaSalidaM = (double)nudTramoRectoM.Value;
        _handler.PreferirConectoresLibres = chkPreferirConectoresLibres.Checked;
        _handler.SeleccionarResultado = chkSeleccionarResultado.Checked;

        GuardarConfiguracion();

        MostrarResultado("Flujo flexible iniciado. Selecciona elemento 1 y luego elemento 2. ESC para terminar.");
        AgregarResultado("Diámetro flexible: " + nudDiametroFlexibleMm.Value.ToString("0.#") + " mm");
        AgregarResultado("Tramo recto salida: " + nudTramoRectoM.Value.ToString("0.###") + " m");
        AgregarResultado("Radio giro U: automático según diámetro.");
        Ejecutar(global::MYG_Addin.EleTubosFlexibles55Request.GenerarFlexible);
    }

    private void Ejecutar(global::MYG_Addin.EleTubosFlexibles55Request request)
    {
        _handler.Request = request;

        if (_externalEvent == null)
        {
            MostrarResultado("No se pudo crear el evento externo de Revit.");
            return;
        }

        _externalEvent.Raise();
    }

    private string ObtenerRutaConfig()
    {
        string carpeta = System.IO.Path.Combine(
            System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData),
            "MYG_Addin");

        try
        {
            if (!System.IO.Directory.Exists(carpeta))
                System.IO.Directory.CreateDirectory(carpeta);
        }
        catch
        {
        }

        return System.IO.Path.Combine(carpeta, ArchivoConfigNombre);
    }

    private void CargarConfiguracion()
    {
        if (_configuracionYaCargada)
            return;

        _configuracionYaCargada = true;

        string ruta = ObtenerRutaConfig();

        if (!System.IO.File.Exists(ruta))
            return;

        System.Collections.Generic.Dictionary<string, string> datos =
            new System.Collections.Generic.Dictionary<string, string>(System.StringComparer.OrdinalIgnoreCase);

        try
        {
            string[] lineas = System.IO.File.ReadAllLines(ruta);

            foreach (string linea in lineas)
            {
                if (string.IsNullOrWhiteSpace(linea))
                    continue;

                int idx = linea.IndexOf('=');

                if (idx <= 0)
                    continue;

                string clave = linea.Substring(0, idx).Trim();
                string valor = linea.Substring(idx + 1).Trim();

                if (!datos.ContainsKey(clave))
                    datos.Add(clave, valor);
            }
        }
        catch
        {
            return;
        }

        _tipoFlexibleIdGuardado = ObtenerLong(datos, "TipoFlexibleId", long.MinValue);
        _tipoFlexibleTextoGuardado = ObtenerString(datos, "TipoFlexibleTexto", "");

        if (!string.IsNullOrWhiteSpace(_tipoFlexibleTextoGuardado) && cmbTipoFlexible != null)
            cmbTipoFlexible.Text = _tipoFlexibleTextoGuardado;

        SetValorDecimal(nudDiametroFlexibleMm, ObtenerDecimal(datos, "DiametroFlexibleMm", nudDiametroFlexibleMm.Value));
        SetValorDecimal(nudTramoRectoM, ObtenerDecimal(datos, "TramoRectoSalidaM", nudTramoRectoM.Value));
        SetCheck(chkPreferirConectoresLibres, ObtenerBool(datos, "PreferirConectoresLibres", chkPreferirConectoresLibres.Checked));
        SetCheck(chkSeleccionarResultado, ObtenerBool(datos, "SeleccionarResultado", chkSeleccionarResultado.Checked));
    }

    private void GuardarConfiguracion()
    {
        try
        {
            global::MYG_Addin.EleTubosFlexibles55TipoInfo tipo = ObtenerTipoFlexibleSeleccionado();
            string tipoTexto = cmbTipoFlexible == null ? "" : cmbTipoFlexible.Text;
            long tipoId = long.MinValue;

            if (tipo != null && tipo.Id != null)
                tipoId = tipo.Id.Value;

            System.Collections.Generic.List<string> lineas = new System.Collections.Generic.List<string>();

            lineas.Add("TipoFlexibleId=" + tipoId.ToString(System.Globalization.CultureInfo.InvariantCulture));
            lineas.Add("TipoFlexibleTexto=" + LimpiarValorConfig(tipoTexto));
            lineas.Add("DiametroFlexibleMm=" + ValorDecimal(nudDiametroFlexibleMm));
            lineas.Add("TramoRectoSalidaM=" + ValorDecimal(nudTramoRectoM));
            lineas.Add("PreferirConectoresLibres=" + ValorCheck(chkPreferirConectoresLibres));
            lineas.Add("SeleccionarResultado=" + ValorCheck(chkSeleccionarResultado));

            System.IO.File.WriteAllLines(ObtenerRutaConfig(), lineas.ToArray());
        }
        catch
        {
        }
    }

    private string LimpiarValorConfig(string texto)
    {
        if (texto == null)
            return "";

        return texto.Replace("\r", " ").Replace("\n", " ").Trim();
    }

    private string ValorDecimal(System.Windows.Forms.NumericUpDown nud)
    {
        decimal valor = nud == null ? 0 : nud.Value;
        return valor.ToString(System.Globalization.CultureInfo.InvariantCulture);
    }

    private string ValorCheck(System.Windows.Forms.CheckBox chk)
    {
        return chk != null && chk.Checked ? "1" : "0";
    }

    private string ObtenerString(
        System.Collections.Generic.Dictionary<string, string> datos,
        string clave,
        string defecto)
    {
        if (datos == null || !datos.ContainsKey(clave))
            return defecto;

        return datos[clave] ?? defecto;
    }

    private long ObtenerLong(
        System.Collections.Generic.Dictionary<string, string> datos,
        string clave,
        long defecto)
    {
        string texto = ObtenerString(datos, clave, "");
        long valor;

        if (long.TryParse(texto, System.Globalization.NumberStyles.Integer, System.Globalization.CultureInfo.InvariantCulture, out valor))
            return valor;

        return defecto;
    }

    private decimal ObtenerDecimal(
        System.Collections.Generic.Dictionary<string, string> datos,
        string clave,
        decimal defecto)
    {
        string texto = ObtenerString(datos, clave, "");
        decimal valor;

        if (decimal.TryParse(texto, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out valor))
            return valor;

        return defecto;
    }

    private bool ObtenerBool(
        System.Collections.Generic.Dictionary<string, string> datos,
        string clave,
        bool defecto)
    {
        string texto = ObtenerString(datos, clave, "").Trim().ToUpperInvariant();

        if (texto == "1" || texto == "TRUE" || texto == "SI" || texto == "SÍ")
            return true;

        if (texto == "0" || texto == "FALSE" || texto == "NO")
            return false;

        return defecto;
    }

    private void SetValorDecimal(System.Windows.Forms.NumericUpDown nud, decimal valor)
    {
        if (nud == null)
            return;

        if (valor < nud.Minimum)
            valor = nud.Minimum;

        if (valor > nud.Maximum)
            valor = nud.Maximum;

        nud.Value = valor;
    }

    private void SetCheck(System.Windows.Forms.CheckBox chk, bool valor)
    {
        if (chk != null)
            chk.Checked = valor;
    }

    public void MostrarResultado(string texto)
    {
        if (txtResultado == null || txtResultado.IsDisposed)
            return;

        if (this.InvokeRequired)
        {
            this.BeginInvoke(new System.Action(() => MostrarResultado(texto)));
            return;
        }

        txtResultado.Clear();
        txtResultado.SelectionColor = System.Drawing.Color.FromArgb(50, 50, 50);
        txtResultado.AppendText(texto ?? "");
        txtResultado.SelectionStart = 0;
        txtResultado.ScrollToCaret();
    }

    public void AgregarResultado(string texto)
    {
        if (txtResultado == null || txtResultado.IsDisposed)
            return;

        if (this.InvokeRequired)
        {
            this.BeginInvoke(new System.Action(() => AgregarResultado(texto)));
            return;
        }

        if (txtResultado.TextLength > 0)
            txtResultado.AppendText(System.Environment.NewLine);

        txtResultado.SelectionColor = System.Drawing.Color.FromArgb(50, 50, 50);
        txtResultado.AppendText(texto ?? "");
        txtResultado.SelectionStart = txtResultado.TextLength;
        txtResultado.ScrollToCaret();
    }
}
