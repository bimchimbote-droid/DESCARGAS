﻿/*
=========================================================
MYG - Tubos automáticos entre conectores
Panel 5 - Botón 5.5
V11 - Embebible en main con franja lateral
=========================================================
*/

using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Electrical;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;

namespace MYG_Addin
{
    public enum EleTubosAutomaticos55Request
    {
        None,
        CargarDatos,
        PicarConectorInicio,
        PicarConectorFin,
        GenerarTubo,
        RedistribuirEnCara,
        BorrarTubos
    }

    public class EleTubosAutomaticos55TipoInfo
    {
        public ElementId Id { get; set; }
        public string Nombre { get; set; }

        public override string ToString()
        {
            return string.IsNullOrWhiteSpace(Nombre) ? "(Sin nombre)" : Nombre;
        }
    }

    public class EleTubosAutomaticos55ConectorInfo
    {
        public ElementId OwnerId { get; set; }
        public XYZ Origen { get; set; }
        public XYZ Direccion { get; set; }
        public string TextoResumen { get; set; }
    }

    public class EjecutarEleTubosAutomaticos55Handler : IExternalEventHandler
    {
        private const string MarcaGenerado = "MYG_TUBOS_AUTOMATICOS_55";
        private const double Epsilon = 1.0e-9;

        public EleTubosAutomaticos55Request Request { get; set; } = EleTubosAutomaticos55Request.None;

        public EleTubosAutomaticos55Form Form { get; set; }

        public List<EleTubosAutomaticos55TipoInfo> TiposConduitDisponibles { get; private set; } =
            new List<EleTubosAutomaticos55TipoInfo>();

        public EleTubosAutomaticos55ConectorInfo ConectorInicio { get; set; }
        public EleTubosAutomaticos55ConectorInfo ConectorFin { get; set; }

        public ElementId TipoConduitId { get; set; } = ElementId.InvalidElementId;

        public double DiametroMm { get; set; } = 20.0;
        public double AlturaLibreM { get; set; } = 0.30;
        public double RetiroMuroM { get; set; } = 0.025;
        public bool InvertirRetiroMuro { get; set; } = false;
        public double ToleranciaAlineacionMm { get; set; } = 15.0;

        public double SeparacionRedistribucionM { get; set; } = 0.05;
        public double MargenRedistribucionM { get; set; } = 0.10;
        public double LongitudAcomodoM { get; set; } = 0.50;

        public string ModoRuta { get; set; } = "AUTOMATICO";

        public bool CrearCodos { get; set; } = true;
        public bool ConectarExtremos { get; set; } = true;
        public bool BorrarAnteriores { get; set; } = false;
        public bool SeleccionarResultado { get; set; } = true;

        public string GetName()
        {
            return "MYG - Tubos automáticos entre conectores";
        }

        public void Execute(UIApplication app)
        {
            try
            {
                UIDocument uidoc = app.ActiveUIDocument;

                if (uidoc == null || uidoc.Document == null)
                    return;

                Document doc = uidoc.Document;

                if (Request == EleTubosAutomaticos55Request.CargarDatos)
                {
                    CargarTiposConduit(doc);

                    if (Form != null && !Form.IsDisposed)
                        Form.SetTiposConduit(TiposConduitDisponibles);
                }
                else if (Request == EleTubosAutomaticos55Request.PicarConectorInicio)
                {
                    EjecutarPicarConector(uidoc, doc, true);
                }
                else if (Request == EleTubosAutomaticos55Request.PicarConectorFin)
                {
                    EjecutarPicarConector(uidoc, doc, false);
                }
                else if (Request == EleTubosAutomaticos55Request.GenerarTubo)
                {
                    EjecutarGenerarTubo(uidoc, doc);
                }
                else if (Request == EleTubosAutomaticos55Request.RedistribuirEnCara)
                {
                    EjecutarRedistribuirEnCara(uidoc, doc);
                }
                else if (Request == EleTubosAutomaticos55Request.BorrarTubos)
                {
                    EjecutarBorrarTubos(uidoc, doc, true);
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
            }
            catch (Exception ex)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("MYG - Error: " + ex.Message);
            }
            finally
            {
                Request = EleTubosAutomaticos55Request.None;
            }
        }

        public bool TieneConectoresSeleccionados()
        {
            return ConectorInicio != null &&
                   ConectorFin != null &&
                   ConectorInicio.OwnerId != null &&
                   ConectorFin.OwnerId != null &&
                   ConectorInicio.OwnerId != ElementId.InvalidElementId &&
                   ConectorFin.OwnerId != ElementId.InvalidElementId;
        }

        public void CargarTiposConduit(Document doc)
        {
            TiposConduitDisponibles.Clear();

            if (doc == null)
                return;

            try
            {
                List<ConduitType> tipos = new FilteredElementCollector(doc)
                    .OfClass(typeof(ConduitType))
                    .Cast<ConduitType>()
                    .OrderBy(x => x.Name)
                    .ToList();

                foreach (ConduitType tipo in tipos)
                {
                    if (tipo == null)
                        continue;

                    TiposConduitDisponibles.Add(new EleTubosAutomaticos55TipoInfo
                    {
                        Id = tipo.Id,
                        Nombre = tipo.Name + "  [Id " + tipo.Id.Value + "]"
                    });
                }
            }
            catch
            {
            }
        }

        private void EjecutarPicarConector(
            UIDocument uidoc,
            Document doc,
            bool esInicio)
        {
            Reference r = uidoc.Selection.PickObject(
                ObjectType.PointOnElement,
                new FiltroElementoConConectores(),
                esInicio
                    ? "Pica CERCA del conector INICIAL"
                    : "Pica CERCA del conector FINAL");

            if (r == null)
                return;

            Element e = doc.GetElement(r.ElementId);

            if (e == null)
                return;

            XYZ puntoPicado = r.GlobalPoint;

            if (EsVectorCero(puntoPicado))
                puntoPicado = ObtenerCentroElemento(e);

            Connector conector = ObtenerConectorMasCercano(e, puntoPicado);

            if (conector == null)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("El elemento seleccionado no tiene conectores MEP válidos.");

                return;
            }

            EleTubosAutomaticos55ConectorInfo info = CrearInfoConector(e, conector, puntoPicado);

            if (esInicio)
            {
                ConectorInicio = info;

                if (Form != null && !Form.IsDisposed)
                    Form.SetConectorInicio(info);
            }
            else
            {
                ConectorFin = info;

                if (Form != null && !Form.IsDisposed)
                    Form.SetConectorFin(info);
            }
        }

        private EleTubosAutomaticos55ConectorInfo CrearInfoConector(
            Element owner,
            Connector conector,
            XYZ puntoPicado)
        {
            XYZ origen = ObtenerOrigenSeguro(conector);
            XYZ direccion = ObtenerDireccionConector(conector);

            string categoria = "";

            try
            {
                if (owner != null && owner.Category != null)
                    categoria = owner.Category.Name;
            }
            catch
            {
            }

            string resumen =
                "Id " + (owner == null ? "-" : owner.Id.Value.ToString()) +
                " | " + categoria +
                " | " + (owner == null ? "" : owner.Name) +
                " | Dist. " + FeetToMm(origen.DistanceTo(puntoPicado)).ToString("0") + " mm";

            return new EleTubosAutomaticos55ConectorInfo
            {
                OwnerId = owner == null ? ElementId.InvalidElementId : owner.Id,
                Origen = origen,
                Direccion = direccion,
                TextoResumen = resumen
            };
        }

        private void EjecutarGenerarTubo(UIDocument uidoc, Document doc)
        {
            if (!ValidarTipoConduit(doc))
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("No se encontró ningún tipo de Conduit cargado en el proyecto.");

                return;
            }

            int borradosIniciales = 0;

            if (BorrarAnteriores)
            {
                using (Transaction tBorrar = new Transaction(doc, "MYG - Borrar tubos automáticos previos"))
                {
                    tBorrar.Start();
                    borradosIniciales = BorrarElementosPrevios(doc);
                    tBorrar.Commit();
                }
            }

            if (Form != null && !Form.IsDisposed)
            {
                Form.MostrarResultado("Flujo rápido activo.");
                Form.AgregarResultado("Pica conector 1 y luego conector 2. Al picar el segundo se crea el tubo.");
                Form.AgregarResultado("Presiona ESC para terminar.");

                if (borradosIniciales > 0)
                    Form.AgregarResultado("Tubos anteriores borrados: " + borradosIniciales);
            }

            List<ElementId> todosCreados = new List<ElementId>();
            int paresCreados = 0;
            int paresFallidos = 0;
            int segmentosTotal = 0;
            int codosTotal = 0;
            int conexionesTotal = 0;
            int advertenciasTotal = 0;

            while (true)
            {
                PicarConectorResultado55 inicio = null;
                PicarConectorResultado55 fin = null;

                try
                {
                    inicio = PicarConectorParaFlujo(
                        uidoc,
                        doc,
                        "Pica el CONECTOR 1. ESC para terminar.");

                    if (inicio == null)
                        continue;

                    if (Form != null && !Form.IsDisposed)
                    {
                        Form.MostrarResultado("Conector 1 seleccionado.");
                        Form.AgregarResultado(inicio.Info == null ? "" : inicio.Info.TextoResumen);
                        Form.AgregarResultado("Ahora pica el CONECTOR 2 para crear el tubo.");
                    }

                    fin = PicarConectorParaFlujo(
                        uidoc,
                        doc,
                        "Pica el CONECTOR 2. Al picarlo se creará el tubo. ESC para terminar.");

                    if (fin == null)
                        continue;
                }
                catch (Autodesk.Revit.Exceptions.OperationCanceledException)
                {
                    break;
                }

                ResultadoCreacionTubos55 resultado = CrearTuboEntreConectores(
                    doc,
                    inicio.Owner,
                    inicio.Conector,
                    fin.Owner,
                    fin.Conector);

                if (resultado.Ok)
                {
                    paresCreados++;
                    segmentosTotal += resultado.SegmentosCreados;
                    codosTotal += resultado.CodosCreados;
                    conexionesTotal += resultado.ConexionesExtremo;
                    advertenciasTotal += resultado.ErroresConexion;

                    if (resultado.Creados != null)
                        todosCreados.AddRange(resultado.Creados);

                    if (Form != null && !Form.IsDisposed)
                    {
                        Form.MostrarResultado("Tubo creado correctamente. Puedes seguir picando otro par.");
                        Form.AgregarResultado("Pares creados: " + paresCreados);
                        Form.AgregarResultado("Tramos creados: " + segmentosTotal);
                        Form.AgregarResultado("Codos/fittings creados: " + codosTotal);
                        Form.AgregarResultado("Conexiones a cajas/familias: " + conexionesTotal);
                        Form.AgregarResultado("Conexiones con advertencia: " + advertenciasTotal);
                        if (ModoRuta == "TOMACORRIENTES")
                        {
                            Form.AgregarResultado("Bajada toma: " + AlturaLibreM.ToString("0.###") + " m");
                            Form.AgregarResultado("Retiro muro: " + RetiroMuroM.ToString("0.###") + " m");
                        }
                        else
                        {
                            Form.AgregarResultado("Altura libre: " + AlturaLibreM.ToString("0.###") + " m");
                        }
                    }
                }
                else
                {
                    paresFallidos++;

                    if (Form != null && !Form.IsDisposed)
                    {
                        Form.MostrarResultado("No se pudo crear el tubo de este par. Puedes seguir picando otro par.");
                        Form.AgregarResultado(resultado.Error ?? "Error no especificado.");
                        Form.AgregarResultado("Pares creados: " + paresCreados);
                        Form.AgregarResultado("Pares fallidos: " + paresFallidos);
                    }
                }
            }

            if (SeleccionarResultado && todosCreados.Count > 0)
                uidoc.Selection.SetElementIds(todosCreados);

            if (Form != null && !Form.IsDisposed)
            {
                Form.MostrarResultado("Flujo rápido terminado.");
                Form.AgregarResultado("Pares creados: " + paresCreados);
                Form.AgregarResultado("Pares fallidos: " + paresFallidos);
                Form.AgregarResultado("Tramos creados: " + segmentosTotal);
                Form.AgregarResultado("Codos/fittings creados: " + codosTotal);
                Form.AgregarResultado("Conexiones a cajas/familias: " + conexionesTotal);
                Form.AgregarResultado("Conexiones con advertencia: " + advertenciasTotal);
                Form.AgregarResultado("Modo de ruta: " + ModoRuta);

                if (ModoRuta == "TOMACORRIENTES")
                {
                    Form.AgregarResultado("Bajada toma: " + AlturaLibreM.ToString("0.###") + " m");
                    Form.AgregarResultado("Retiro muro: " + RetiroMuroM.ToString("0.###") + " m");
                }
                else
                {
                    Form.AgregarResultado("Altura libre: " + AlturaLibreM.ToString("0.###") + " m");
                }
            }
        }

        private bool ValidarTipoConduit(Document doc)
        {
            if (doc == null)
                return false;

            if (TipoConduitId == null ||
                TipoConduitId == ElementId.InvalidElementId ||
                doc.GetElement(TipoConduitId) == null)
            {
                CargarTiposConduit(doc);

                if (TiposConduitDisponibles.Count > 0)
                    TipoConduitId = TiposConduitDisponibles[0].Id;
            }

            return TipoConduitId != null &&
                   TipoConduitId != ElementId.InvalidElementId &&
                   doc.GetElement(TipoConduitId) != null;
        }

        private PicarConectorResultado55 PicarConectorParaFlujo(
            UIDocument uidoc,
            Document doc,
            string mensaje)
        {
            Reference r = uidoc.Selection.PickObject(
                ObjectType.PointOnElement,
                new FiltroElementoConConectores(),
                mensaje);

            if (r == null)
                return null;

            Element e = doc.GetElement(r.ElementId);

            if (e == null)
                return null;

            XYZ puntoPicado = r.GlobalPoint;

            if (EsVectorCero(puntoPicado))
                puntoPicado = ObtenerCentroElemento(e);

            Connector conector = ObtenerConectorMasCercano(e, puntoPicado);

            if (conector == null)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("El elemento seleccionado no tiene conectores MEP válidos.");

                return null;
            }

            EleTubosAutomaticos55ConectorInfo info = CrearInfoConector(e, conector, puntoPicado);

            return new PicarConectorResultado55
            {
                Owner = e,
                Conector = conector,
                Info = info
            };
        }

        private ResultadoCreacionTubos55 CrearTuboEntreConectores(
            Document doc,
            Element ownerInicio,
            Connector cInicio,
            Element ownerFin,
            Connector cFin)
        {
            ResultadoCreacionTubos55 resultado = new ResultadoCreacionTubos55();

            if (doc == null || ownerInicio == null || ownerFin == null || cInicio == null || cFin == null)
            {
                resultado.Error = "No se encontraron conectores válidos para este par.";
                return resultado;
            }

            Level nivel = ObtenerNivelParaCreacion(doc, ownerInicio, ownerFin);

            if (nivel == null)
            {
                resultado.Error = "No se encontró un nivel válido para crear el tubo.";
                return resultado;
            }

            using (Transaction t = new Transaction(doc, "MYG - Crear tubo automático entre conectores"))
            {
                try
                {
                    t.Start();

                    FailureHandlingOptions failureOptions = t.GetFailureHandlingOptions();
                    failureOptions.SetFailuresPreprocessor(new EleTubosAutomaticos55FailurePreprocessor());
                    t.SetFailureHandlingOptions(failureOptions);

                    List<XYZ> ruta = CalcularRuta(cInicio, ownerInicio, cFin, ownerFin);

                    if (ruta == null || ruta.Count < 2)
                    {
                        resultado.Error = "No se pudo calcular una ruta válida entre conectores.";
                        t.RollBack();
                        return resultado;
                    }

                    int segmentosCreados = 0;
                    List<ElementId> creados = new List<ElementId>();

                    List<SegmentoConduitInfo> segmentos = CrearSegmentosConduit(
                        doc,
                        ruta,
                        nivel.Id,
                        creados,
                        out segmentosCreados);

                    if (segmentos.Count == 0)
                    {
                        resultado.Error = "No se pudo crear ningún tramo de tubo/conduit.";
                        t.RollBack();
                        return resultado;
                    }

                    doc.Regenerate();

                    int erroresConexion = 0;
                    int codosCreados = 0;
                    int conexionesExtremo = 0;

                    if (CrearCodos)
                    {
                        codosCreados = CrearCodosEntreSegmentos(
                            doc,
                            segmentos,
                            creados,
                            ref erroresConexion);

                        doc.Regenerate();
                    }

                    if (ConectarExtremos)
                    {
                        if (ConectarConectorAConduit(cInicio, segmentos[0].Conduit, segmentos[0].Inicio))
                            conexionesExtremo++;
                        else
                            erroresConexion++;

                        if (ConectarConectorAConduit(cFin, segmentos[segmentos.Count - 1].Conduit, segmentos[segmentos.Count - 1].Fin))
                            conexionesExtremo++;
                        else
                            erroresConexion++;

                        doc.Regenerate();
                    }

                    t.Commit();

                    resultado.Ok = true;
                    resultado.Creados = creados;
                    resultado.SegmentosCreados = segmentosCreados;
                    resultado.CodosCreados = codosCreados;
                    resultado.ConexionesExtremo = conexionesExtremo;
                    resultado.ErroresConexion = erroresConexion;

                    return resultado;
                }
                catch (Exception ex)
                {
                    try
                    {
                        if (t.GetStatus() == TransactionStatus.Started)
                            t.RollBack();
                    }
                    catch
                    {
                    }

                    resultado.Error = ex.Message;
                    return resultado;
                }
            }
        }

        private List<XYZ> CalcularRuta(
            Connector cInicio,
            Element ownerInicio,
            Connector cFin,
            Element ownerFin)
        {
            XYZ p0 = ObtenerOrigenSeguro(cInicio);
            XYZ pN = ObtenerOrigenSeguro(cFin);

            double tolerancia = MmToFeet(Math.Max(ToleranciaAlineacionMm, 1.0));

            if (ModoRuta == "TOMACORRIENTES")
            {
                return CalcularRutaTomacorrientes(
                    cInicio,
                    ownerInicio,
                    cFin,
                    ownerFin,
                    tolerancia);
            }

            // V4:
            // La altura de la ventana se expresa en metros y representa la distancia libre
            // desde el conector hasta la CARA INFERIOR del tubo, medida en la dirección
            // real de salida del conector.
            // Como Revit crea el Conduit por eje, se suma el radio para obtener el eje
            // del tubo: distancia al eje = altura libre + diámetro/2.
            double alturaLibre = MmToFeet(Math.Max(AlturaLibreM, 0.0) * 1000.0);
            double radioTubo = MmToFeet(Math.Max(DiametroMm, 1.0) / 2.0);
            double distanciaSalidaEje = alturaLibre + radioTubo;

            XYZ vector = pN - p0;

            if (EsVectorCero(vector))
                return null;

            XYZ linea = vector.Normalize();

            // V2:
            // La salida ya NO se fuerza hacia el eje Z global ni hacia el otro conector.
            // Se toma la dirección real del conector y se invierte solo si apunta hacia
            // dentro de la familia. Así, si el conector apunta hacia abajo, el tubo sale
            // hacia abajo; si apunta hacia arriba, sale hacia arriba.
            XYZ dirInicio = ObtenerDireccionSalidaConector(cInicio, ownerInicio, linea);
            XYZ dirFin = ObtenerDireccionSalidaConector(cFin, ownerFin, -linea);

            bool alineados = EstanAlineados(p0, pN, dirInicio, dirFin, tolerancia);

            if (ModoRuta == "DIRECTO")
            {
                if (!alineados)
                {
                    // En modo directo estricto solo se crea si están alineados sobre el mismo eje.
                    return null;
                }

                return LimpiarPuntosRuta(new List<XYZ> { p0, pN }, tolerancia);
            }

            if (ModoRuta == "AUTOMATICO" && alineados)
            {
                return LimpiarPuntosRuta(new List<XYZ> { p0, pN }, tolerancia);
            }

            XYZ pSalidaInicio = p0;
            XYZ pSalidaFin = pN;

            if (distanciaSalidaEje > tolerancia)
            {
                pSalidaInicio = p0 + dirInicio.Normalize() * distanciaSalidaEje;
                pSalidaFin = pN + dirFin.Normalize() * distanciaSalidaEje;

                // V4:
                // Si ambos conectores salen en una dirección vertical similar, el tramo
                // principal se fuerza a una misma cota. La cota se toma desde el conector
                // que queda más arriba en la dirección de salida del tubo.
                // Así el tramo superior entre salidas queda completamente horizontal.
                AjustarSalidasAPlanoComunSegunDireccion(
                    ref pSalidaInicio,
                    ref pSalidaFin,
                    p0,
                    pN,
                    dirInicio,
                    dirFin,
                    distanciaSalidaEje,
                    tolerancia);
            }

            List<XYZ> puntos = new List<XYZ>();
            puntos.Add(p0);

            if (p0.DistanceTo(pSalidaInicio) > tolerancia)
                puntos.Add(pSalidaInicio);

            if (ModoRuta == "AUTOMATICO")
            {
                // Automático V2:
                // Primero sale de ambos conectores hacia afuera y luego une esos dos puntos
                // con un tramo directo. Esto evita que dos cajas con conectores hacia arriba
                // creen una L innecesaria por debajo del conector.
                if (pSalidaInicio.DistanceTo(pSalidaFin) > tolerancia)
                    puntos.Add(pSalidaFin);
            }
            else
            {
                List<XYZ> intermedios;

                if (ModoRuta == "Z")
                    intermedios = CrearRutaZ(pSalidaInicio, pSalidaFin, tolerancia);
                else
                    intermedios = CrearRutaL(pSalidaInicio, pSalidaFin, tolerancia);

                foreach (XYZ p in intermedios)
                    puntos.Add(p);

                if (puntos.Count == 0 || puntos[puntos.Count - 1].DistanceTo(pSalidaFin) > tolerancia)
                    puntos.Add(pSalidaFin);
            }

            if (puntos[puntos.Count - 1].DistanceTo(pN) > tolerancia)
                puntos.Add(pN);

            return LimpiarPuntosRuta(puntos, tolerancia);
        }


        private List<XYZ> CalcularRutaTomacorrientes(
            Connector cInicio,
            Element ownerInicio,
            Connector cFin,
            Element ownerFin,
            double tolerancia)
        {
            XYZ p0 = ObtenerOrigenSeguro(cInicio);
            XYZ pN = ObtenerOrigenSeguro(cFin);

            if (EsVectorCero(p0) || EsVectorCero(pN))
                return null;

            XYZ linea = pN - p0;

            if (EsVectorCero(linea))
                return null;

            double retiro = UnitUtils.ConvertToInternalUnits(
                Math.Max(RetiroMuroM, 0.0),
                UnitTypeId.Meters);

            double bajadaLibre = UnitUtils.ConvertToInternalUnits(
                Math.Max(AlturaLibreM, 0.0),
                UnitTypeId.Meters);

            // V8 - TOMACORRIENTES:
            // Para conectores inferiores de tomacorriente, el recorrido correcto es:
            // 1) salir primero hacia ABAJO desde cada conector;
            // 2) luego salir del muro/piso a 90° usando el Retiro muro;
            // 3) unir los dos puntos retirados con un tramo inferior común;
            // 4) llegar al segundo tomacorriente con la misma forma inversa.
            //
            // La bajada se mide como distancia libre desde el conector hasta la
            // cara superior/inferior del tubo según el sentido constructivo. Como
            // Revit crea Conduit por eje, se suma el radio para obtener la cota eje.
            double radioTubo = MmToFeet(Math.Max(DiametroMm, 1.0) / 2.0);
            double bajadaEje = bajadaLibre + radioTubo;

            // La bajada de tomacorrientes siempre se fuerza hacia abajo global.
            // Esto evita que la dirección propia del conector haga curvas hacia el muro
            // antes de bajar, que era el problema de la V7.
            double zObjetivo = Math.Min(p0.Z, pN.Z) - bajadaEje;

            XYZ pBajadaInicio = new XYZ(p0.X, p0.Y, zObjetivo);
            XYZ pBajadaFin = new XYZ(pN.X, pN.Y, zObjetivo);

            XYZ dirRetiroInicio = ObtenerDireccionRetiroTomacorriente(
                cInicio,
                ownerInicio,
                linea);

            XYZ dirRetiroFin = ObtenerDireccionRetiroTomacorriente(
                cFin,
                ownerFin,
                -linea);

            if (InvertirRetiroMuro)
            {
                dirRetiroInicio = -dirRetiroInicio;
                dirRetiroFin = -dirRetiroFin;
            }

            // V10:
            // Los dos extremos deben salir hacia el mismo lado del muro y el tramo corto
            // de salida debe ser NORMAL a la cara anfitriona. Si una familia está espejada,
            // o si el segundo tomacorriente devuelve una normal ligeramente distinta,
            // se fuerza el mismo vector normal para evitar salidas inclinadas respecto al muro.
            if (!EsVectorCero(dirRetiroInicio) && !EsVectorCero(dirRetiroFin))
            {
                XYZ d0 = dirRetiroInicio.Normalize();
                XYZ d1 = dirRetiroFin.Normalize();

                if (d0.DotProduct(d1) < 0.0)
                    d1 = -d1;

                if (Math.Abs(d0.DotProduct(d1)) > 0.70)
                    dirRetiroFin = dirRetiroInicio;
                else
                    dirRetiroFin = d1;
            }

            XYZ pSalidaInicio = pBajadaInicio;
            XYZ pSalidaFin = pBajadaFin;

            if (retiro > tolerancia)
            {
                pSalidaInicio = pBajadaInicio + dirRetiroInicio.Normalize() * retiro;
                pSalidaFin = pBajadaFin + dirRetiroFin.Normalize() * retiro;
            }

            List<XYZ> puntos = new List<XYZ>();
            puntos.Add(p0);

            // Conector 1 -> baja primero.
            if (p0.DistanceTo(pBajadaInicio) > tolerancia)
                puntos.Add(pBajadaInicio);

            // Luego sale del muro/piso a 90°.
            if (pBajadaInicio.DistanceTo(pSalidaInicio) > tolerancia)
                puntos.Add(pSalidaInicio);

            // Tramo inferior común.
            if (pSalidaInicio.DistanceTo(pSalidaFin) > tolerancia)
                puntos.Add(pSalidaFin);

            // En el otro extremo entra al muro/piso a 90°.
            if (pSalidaFin.DistanceTo(pBajadaFin) > tolerancia)
                puntos.Add(pBajadaFin);

            // Finalmente sube al conector 2.
            if (pBajadaFin.DistanceTo(pN) > tolerancia)
                puntos.Add(pN);

            return LimpiarPuntosRuta(puntos, tolerancia);
        }

        private XYZ ObtenerDireccionRetiroTomacorriente(
            Connector conector,
            Element owner,
            XYZ direccionRespaldo)
        {
            // V10:
            // Para tomacorrientes, el retiro NO debe tomarse desde el conector inferior
            // porque ese conector puede apuntar hacia abajo o tener ejes internos de familia.
            // Primero se intenta obtener la normal real de la cara anfitriona:
            // - HostFace si la familia está hospedada por cara.
            // - FacingOrientation del FamilyInstance.
            // - Normal del muro anfitrión si existe.
            // Solo si todo falla se usa la lógica anterior como respaldo.
            XYZ normalHost = ObtenerNormalHorizontalCaraAnfitriona(owner, direccionRespaldo);

            if (!EsVectorCero(normalHost))
                return normalHost.Normalize();

            XYZ dir = ObtenerDireccionSalidaConector(conector, owner, direccionRespaldo);

            if (EsVectorCero(dir))
                dir = direccionRespaldo;

            if (EsVectorCero(dir))
                dir = XYZ.BasisX;

            XYZ dirHorizontal = ProyectarVectorHorizontal(dir);

            if (EsVectorCero(dirHorizontal))
            {
                XYZ centro = ObtenerCentroElemento(owner);
                XYZ origen = ObtenerOrigenSeguro(conector);
                XYZ desdeCentro = origen - centro;
                dirHorizontal = ProyectarVectorHorizontal(desdeCentro);
            }

            if (EsVectorCero(dirHorizontal))
            {
                XYZ linea = ProyectarVectorHorizontal(direccionRespaldo);

                if (!EsVectorCero(linea))
                    dirHorizontal = XYZ.BasisZ.CrossProduct(linea);
            }

            if (EsVectorCero(dirHorizontal))
                dirHorizontal = XYZ.BasisX;

            return dirHorizontal.Normalize();
        }

        private XYZ ObtenerNormalHorizontalCaraAnfitriona(
            Element owner,
            XYZ direccionRespaldo)
        {
            if (owner == null)
                return XYZ.Zero;

            XYZ preferida = XYZ.Zero;
            FamilyInstance fi = owner as FamilyInstance;

            if (fi != null)
            {
                try
                {
                    preferida = ProyectarVectorHorizontal(fi.FacingOrientation);
                }
                catch
                {
                    preferida = XYZ.Zero;
                }

                // 1) Mejor caso: familia hospedada por cara.
                XYZ normalHostFace = ObtenerNormalDesdeHostFace(fi, preferida);

                if (!EsVectorCero(normalHostFace))
                    return normalHostFace.Normalize();

                // 2) Segundo caso: familia hospedada en muro.
                XYZ normalMuro = ObtenerNormalDesdeMuroAnfitrion(fi, preferida);

                if (!EsVectorCero(normalMuro))
                    return normalMuro.Normalize();

                // 3) Tercer caso: orientación de la familia.
                if (!EsVectorCero(preferida))
                    return preferida.Normalize();
            }

            XYZ respaldo = ProyectarVectorHorizontal(direccionRespaldo);

            if (!EsVectorCero(respaldo))
            {
                XYZ normal = XYZ.BasisZ.CrossProduct(respaldo);

                if (!EsVectorCero(normal))
                    return normal.Normalize();
            }

            return XYZ.Zero;
        }

        private XYZ ObtenerNormalDesdeHostFace(
            FamilyInstance fi,
            XYZ preferida)
        {
            if (fi == null)
                return XYZ.Zero;

            try
            {
                Reference refHost = fi.HostFace;

                if (refHost == null)
                    return XYZ.Zero;

                Document doc = fi.Document;

                if (doc == null)
                    return XYZ.Zero;

                Element host = doc.GetElement(refHost.ElementId);

                if (host == null)
                    return XYZ.Zero;

                Face face = null;

                try
                {
                    face = host.GetGeometryObjectFromReference(refHost) as Face;
                }
                catch
                {
                    face = null;
                }

                if (face == null)
                    return XYZ.Zero;

                XYZ normal = XYZ.Zero;

                PlanarFace pf = face as PlanarFace;

                if (pf != null)
                {
                    normal = pf.FaceNormal;
                }
                else
                {
                    BoundingBoxUV bb = face.GetBoundingBox();
                    UV uv = new UV(
                        (bb.Min.U + bb.Max.U) * 0.5,
                        (bb.Min.V + bb.Max.V) * 0.5);

                    normal = face.ComputeNormal(uv);
                }

                normal = ProyectarVectorHorizontal(normal);

                if (EsVectorCero(normal))
                    return XYZ.Zero;

                normal = normal.Normalize();

                if (!EsVectorCero(preferida) && normal.DotProduct(preferida.Normalize()) < 0.0)
                    normal = -normal;

                return normal.Normalize();
            }
            catch
            {
                return XYZ.Zero;
            }
        }

        private XYZ ObtenerNormalDesdeMuroAnfitrion(
            FamilyInstance fi,
            XYZ preferida)
        {
            if (fi == null)
                return XYZ.Zero;

            try
            {
                Wall muro = fi.Host as Wall;

                if (muro == null)
                    return XYZ.Zero;

                LocationCurve lc = muro.Location as LocationCurve;

                if (lc == null || lc.Curve == null)
                    return XYZ.Zero;

                XYZ a = lc.Curve.GetEndPoint(0);
                XYZ b = lc.Curve.GetEndPoint(1);
                XYZ tangente = ProyectarVectorHorizontal(b - a);

                if (EsVectorCero(tangente))
                    return XYZ.Zero;

                tangente = tangente.Normalize();
                XYZ normal = XYZ.BasisZ.CrossProduct(tangente);

                if (EsVectorCero(normal))
                    return XYZ.Zero;

                normal = normal.Normalize();

                if (!EsVectorCero(preferida))
                {
                    XYZ pref = preferida.Normalize();

                    if (normal.DotProduct(pref) < 0.0)
                        normal = -normal;
                }
                else
                {
                    XYZ centroMuro = ObtenerCentroElemento(muro);
                    XYZ centroFamilia = ObtenerCentroElemento(fi);
                    XYZ desdeMuro = ProyectarVectorHorizontal(centroFamilia - centroMuro);

                    if (!EsVectorCero(desdeMuro) && normal.DotProduct(desdeMuro.Normalize()) < 0.0)
                        normal = -normal;
                }

                return normal.Normalize();
            }
            catch
            {
                return XYZ.Zero;
            }
        }

        private XYZ ProyectarVectorHorizontal(XYZ v)
        {
            if (v == null)
                return XYZ.Zero;

            XYZ h = new XYZ(v.X, v.Y, 0.0);

            if (EsVectorCero(h))
                return XYZ.Zero;

            return h.Normalize();
        }

        private void AjustarSalidasAPlanoComunSegunDireccion(
            ref XYZ pSalidaInicio,
            ref XYZ pSalidaFin,
            XYZ p0,
            XYZ pN,
            XYZ dirInicio,
            XYZ dirFin,
            double distanciaMinimaEje,
            double tolerancia)
        {
            if (EsVectorCero(dirInicio) || EsVectorCero(dirFin))
                return;

            XYZ d0 = dirInicio.Normalize();
            XYZ d1 = dirFin.Normalize();

            // Solo aplica cuando los dos conectores salen hacia una dirección parecida.
            // Si uno sale hacia arriba y el otro hacia abajo, se respeta la salida individual.
            double paralelismo = d0.DotProduct(d1);

            if (paralelismo < 0.85)
                return;

            XYZ eje = d0 + d1;

            if (EsVectorCero(eje))
                eje = d0;

            eje = eje.Normalize();

            // La intención de esta mejora es que el tramo principal sea horizontal.
            // Por eso se aplica solo cuando la dirección de salida es claramente vertical.
            if (Math.Abs(eje.DotProduct(XYZ.BasisZ)) < 0.65)
                return;

            double proySalidaInicio = pSalidaInicio.DotProduct(eje);
            double proySalidaFin = pSalidaFin.DotProduct(eje);

            // Se toma la salida que queda más arriba en la dirección de creación del tubo.
            double proyObjetivo = Math.Max(proySalidaInicio, proySalidaFin);

            double denom0 = d0.DotProduct(eje);
            double denom1 = d1.DotProduct(eje);

            if (Math.Abs(denom0) < 0.10 || Math.Abs(denom1) < 0.10)
                return;

            double distancia0 = (proyObjetivo - p0.DotProduct(eje)) / denom0;
            double distancia1 = (proyObjetivo - pN.DotProduct(eje)) / denom1;

            // Nunca se permite que la cara inferior quede a menos de la altura indicada.
            distancia0 = Math.Max(distancia0, distanciaMinimaEje);
            distancia1 = Math.Max(distancia1, distanciaMinimaEje);

            if (distancia0 < tolerancia || distancia1 < tolerancia)
                return;

            pSalidaInicio = p0 + d0 * distancia0;
            pSalidaFin = pN + d1 * distancia1;
        }

        private XYZ ObtenerDireccionSalidaConector(
            Connector conector,
            Element owner,
            XYZ direccionRespaldo)
        {
            XYZ dir = ObtenerDireccionConector(conector);

            if (EsVectorCero(dir))
                dir = direccionRespaldo;

            if (EsVectorCero(dir))
                dir = XYZ.BasisZ;

            dir = dir.Normalize();

            XYZ origen = ObtenerOrigenSeguro(conector);
            XYZ centro = ObtenerCentroElemento(owner);
            XYZ desdeCentro = origen - centro;

            if (!EsVectorCero(desdeCentro))
            {
                desdeCentro = desdeCentro.Normalize();

                // Si la dirección del conector mira hacia el centro de la familia,
                // se invierte para que el tubo siempre salga hacia afuera de la caja/familia.
                if (dir.DotProduct(desdeCentro) < 0.0)
                    dir = -dir;
            }

            return dir.Normalize();
        }

        private bool EstanAlineados(
            XYZ p0,
            XYZ p1,
            XYZ dirInicio,
            XYZ dirFin,
            double tolerancia)
        {
            XYZ v = p1 - p0;

            if (EsVectorCero(v))
                return false;

            XYZ linea = v.Normalize();

            if (EsVectorCero(dirInicio))
                return false;

            XYZ d0 = dirInicio.Normalize();

            double paralelismoInicio = Math.Abs(d0.DotProduct(linea));

            if (paralelismoInicio < 0.985)
                return false;

            if (!EsVectorCero(dirFin))
            {
                XYZ d1 = dirFin.Normalize();
                double paralelismoFin = Math.Abs(d1.DotProduct(linea));

                if (paralelismoFin < 0.985)
                    return false;
            }

            double distanciaALinea = v.CrossProduct(d0).GetLength();

            return distanciaALinea <= tolerancia;
        }

        private List<XYZ> CrearRutaL(
            XYZ a,
            XYZ b,
            double tolerancia)
        {
            List<XYZ> puntos = new List<XYZ>();

            XYZ actual = a;

            XYZ pX = new XYZ(b.X, actual.Y, actual.Z);

            if (actual.DistanceTo(pX) > tolerancia)
            {
                puntos.Add(pX);
                actual = pX;
            }

            XYZ pY = new XYZ(actual.X, b.Y, actual.Z);

            if (actual.DistanceTo(pY) > tolerancia)
            {
                puntos.Add(pY);
                actual = pY;
            }

            XYZ pZ = new XYZ(actual.X, actual.Y, b.Z);

            if (actual.DistanceTo(pZ) > tolerancia)
            {
                puntos.Add(pZ);
                actual = pZ;
            }

            return puntos;
        }

        private List<XYZ> CrearRutaZ(
            XYZ a,
            XYZ b,
            double tolerancia)
        {
            List<XYZ> puntos = new List<XYZ>();

            double dx = Math.Abs(b.X - a.X);
            double dy = Math.Abs(b.Y - a.Y);
            double dz = Math.Abs(b.Z - a.Z);

            XYZ actual = a;

            if (dx >= dy && dx >= dz)
            {
                double midX = (a.X + b.X) / 2.0;

                XYZ p1 = new XYZ(midX, a.Y, a.Z);
                XYZ p2 = new XYZ(midX, b.Y, a.Z);
                XYZ p3 = new XYZ(b.X, b.Y, a.Z);
                XYZ p4 = new XYZ(b.X, b.Y, b.Z);

                AgregarSiDistinto(puntos, ref actual, p1, tolerancia);
                AgregarSiDistinto(puntos, ref actual, p2, tolerancia);
                AgregarSiDistinto(puntos, ref actual, p3, tolerancia);
                AgregarSiDistinto(puntos, ref actual, p4, tolerancia);
            }
            else if (dy >= dx && dy >= dz)
            {
                double midY = (a.Y + b.Y) / 2.0;

                XYZ p1 = new XYZ(a.X, midY, a.Z);
                XYZ p2 = new XYZ(b.X, midY, a.Z);
                XYZ p3 = new XYZ(b.X, b.Y, a.Z);
                XYZ p4 = new XYZ(b.X, b.Y, b.Z);

                AgregarSiDistinto(puntos, ref actual, p1, tolerancia);
                AgregarSiDistinto(puntos, ref actual, p2, tolerancia);
                AgregarSiDistinto(puntos, ref actual, p3, tolerancia);
                AgregarSiDistinto(puntos, ref actual, p4, tolerancia);
            }
            else
            {
                double midZ = (a.Z + b.Z) / 2.0;

                XYZ p1 = new XYZ(a.X, a.Y, midZ);
                XYZ p2 = new XYZ(b.X, a.Y, midZ);
                XYZ p3 = new XYZ(b.X, b.Y, midZ);
                XYZ p4 = new XYZ(b.X, b.Y, b.Z);

                AgregarSiDistinto(puntos, ref actual, p1, tolerancia);
                AgregarSiDistinto(puntos, ref actual, p2, tolerancia);
                AgregarSiDistinto(puntos, ref actual, p3, tolerancia);
                AgregarSiDistinto(puntos, ref actual, p4, tolerancia);
            }

            return puntos;
        }

        private void AgregarSiDistinto(
            List<XYZ> puntos,
            ref XYZ actual,
            XYZ candidato,
            double tolerancia)
        {
            if (actual.DistanceTo(candidato) > tolerancia)
            {
                puntos.Add(candidato);
                actual = candidato;
            }
        }

        private List<XYZ> LimpiarPuntosRuta(
            List<XYZ> puntos,
            double tolerancia)
        {
            List<XYZ> salida = new List<XYZ>();

            if (puntos == null)
                return salida;

            foreach (XYZ p in puntos)
            {
                if (p == null)
                    continue;

                if (salida.Count == 0 ||
                    salida[salida.Count - 1].DistanceTo(p) > tolerancia)
                {
                    salida.Add(p);
                }
            }

            bool cambio = true;

            while (cambio && salida.Count >= 3)
            {
                cambio = false;

                for (int i = 1; i < salida.Count - 1; i++)
                {
                    XYZ a = salida[i - 1];
                    XYZ b = salida[i];
                    XYZ c = salida[i + 1];

                    XYZ ab = b - a;
                    XYZ bc = c - b;

                    if (EsVectorCero(ab) || EsVectorCero(bc))
                        continue;

                    double dot = Math.Abs(ab.Normalize().DotProduct(bc.Normalize()));

                    if (dot > 0.999)
                    {
                        salida.RemoveAt(i);
                        cambio = true;
                        break;
                    }
                }
            }

            return salida;
        }

        private List<SegmentoConduitInfo> CrearSegmentosConduit(
            Document doc,
            List<XYZ> ruta,
            ElementId nivelId,
            List<ElementId> creados,
            out int segmentosCreados)
        {
            segmentosCreados = 0;

            List<SegmentoConduitInfo> segmentos = new List<SegmentoConduitInfo>();

            if (ruta == null || ruta.Count < 2)
                return segmentos;

            double minLongitud = MmToFeet(5.0);

            for (int i = 0; i < ruta.Count - 1; i++)
            {
                XYZ a = ruta[i];
                XYZ b = ruta[i + 1];

                if (a.DistanceTo(b) < minLongitud)
                    continue;

                try
                {
                    Conduit conduit = Conduit.Create(
                        doc,
                        TipoConduitId,
                        a,
                        b,
                        nivelId);

                    if (conduit == null)
                        continue;

                    SetDiametroConduit(conduit, DiametroMm);
                    MarcarElemento(conduit);

                    segmentos.Add(new SegmentoConduitInfo
                    {
                        Conduit = conduit,
                        Inicio = a,
                        Fin = b
                    });

                    creados.Add(conduit.Id);
                    segmentosCreados++;
                }
                catch
                {
                }
            }

            return segmentos;
        }

        private bool ConectarConectorAConduit(
            Connector conectorFamilia,
            Conduit conduit,
            XYZ punto)
        {
            if (conectorFamilia == null || conduit == null)
                return false;

            try
            {
                Connector cConduit = ObtenerConectorMasCercano(conduit, punto);

                if (cConduit == null)
                    return false;

                if (!conectorFamilia.IsConnectedTo(cConduit))
                    conectorFamilia.ConnectTo(cConduit);

                return true;
            }
            catch
            {
                return false;
            }
        }

        private int CrearCodosEntreSegmentos(
            Document doc,
            List<SegmentoConduitInfo> segmentos,
            List<ElementId> creados,
            ref int erroresConexion)
        {
            int creadosCodos = 0;

            if (doc == null || segmentos == null || segmentos.Count < 2)
                return creadosCodos;

            for (int i = 0; i < segmentos.Count - 1; i++)
            {
                SegmentoConduitInfo s1 = segmentos[i];
                SegmentoConduitInfo s2 = segmentos[i + 1];

                if (s1 == null || s2 == null || s1.Conduit == null || s2.Conduit == null)
                    continue;

                XYZ puntoUnion = s1.Fin;

                if (puntoUnion.DistanceTo(s2.Inicio) > MmToFeet(2.0))
                    puntoUnion = (s1.Fin + s2.Inicio) * 0.5;

                Connector c1 = ObtenerConectorMasCercano(s1.Conduit, puntoUnion);
                Connector c2 = ObtenerConectorMasCercano(s2.Conduit, puntoUnion);

                if (c1 == null || c2 == null)
                {
                    erroresConexion++;
                    continue;
                }

                try
                {
                    if (c1.IsConnectedTo(c2))
                        continue;
                }
                catch
                {
                }

                XYZ d1 = ObtenerDireccionConector(c1);
                XYZ d2 = ObtenerDireccionConector(c2);

                double dot = 0.0;

                if (!EsVectorCero(d1) && !EsVectorCero(d2))
                    dot = Math.Abs(d1.Normalize().DotProduct(d2.Normalize()));

                try
                {
                    // Si los dos tramos terminaron colineales, se conecta sin codo.
                    // La limpieza de puntos normalmente elimina estos casos.
                    if (dot > 0.995)
                    {
                        if (!c1.IsConnectedTo(c2))
                            c1.ConnectTo(c2);

                        continue;
                    }

                    FamilyInstance codo = doc.Create.NewElbowFitting(c1, c2);

                    if (codo != null)
                    {
                        MarcarElemento(codo);
                        creados.Add(codo.Id);
                        creadosCodos++;
                    }
                }
                catch
                {
                    // Segundo intento: algunos tipos de conduit sí resuelven el fitting
                    // con ConnectTo cuando NewElbowFitting no devuelve instancia.
                    try
                    {
                        if (!c1.IsConnectedTo(c2))
                            c1.ConnectTo(c2);
                    }
                    catch
                    {
                        erroresConexion++;
                    }
                }
            }

            return creadosCodos;
        }


        // =========================================================
        // V5 - REDISTRIBUIR EN CARA
        // Flujo:
        // 1. Se pica la cara del tablero.
        // 2. Se detectan los conduits creados por esta herramienta que llegan a esa cara.
        // 3. Se reparte el extremo cercano al tablero a lo largo del ancho de la cara.
        // 4. No se mueve el aparato eléctrico ni el extremo opuesto del conduit.
        // 5. Se intenta reconectar el extremo redistribuido al conector de superficie del tablero.
        // =========================================================
        private void EjecutarRedistribuirEnCara(
            UIDocument uidoc,
            Document doc)
        {
            if (uidoc == null || doc == null)
                return;

            Reference r = uidoc.Selection.PickObject(
                ObjectType.Face,
                new FiltroElementoConConectores(),
                "Pica la CARA del tablero donde llegan los tubos MYG");

            if (r == null)
                return;

            Element tablero = doc.GetElement(r.ElementId);

            if (tablero == null)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("No se encontró el tablero seleccionado.");

                return;
            }

            Face cara = null;

            try
            {
                cara = tablero.GetGeometryObjectFromReference(r) as Face;
            }
            catch
            {
            }

            if (cara == null)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("No se pudo leer la cara seleccionada. Intenta picar directamente sobre la superficie del tablero.");

                return;
            }

            XYZ puntoPicado = r.GlobalPoint;

            if (EsVectorCero(puntoPicado))
                puntoPicado = ObtenerCentroElemento(tablero);

            DatosCaraRedistribucion55 datosCara = ObtenerDatosCaraRedistribucion(cara, puntoPicado);

            if (datosCara == null)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("No se pudo calcular la orientación de la cara seleccionada.");

                return;
            }

            Connector conectorTablero = ObtenerConectorMasCercano(tablero, puntoPicado);

            if (conectorTablero == null)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("El tablero seleccionado no tiene conectores MEP válidos para reconectar.");

                return;
            }

            double distanciaBusqueda = UnitUtils.ConvertToInternalUnits(
                Math.Max(LongitudAcomodoM, 0.05),
                UnitTypeId.Meters);

            List<ConduitFinalRedistribucion55> finales = DetectarConduitsCercanosACara(
                doc,
                tablero,
                datosCara,
                distanciaBusqueda);

            if (finales.Count == 0)
            {
                if (Form != null && !Form.IsDisposed)
                {
                    Form.MostrarResultado("No se detectaron tubos MYG llegando a la cara seleccionada.");
                    Form.AgregarResultado("Aumenta la Longitud de acomodo o verifica que los tubos tengan la marca MYG en Comentarios.");
                }

                return;
            }

            List<XYZ> puntosObjetivo = CalcularPuntosRedistribuidosEnCara(
                datosCara,
                finales,
                UnitUtils.ConvertToInternalUnits(Math.Max(SeparacionRedistribucionM, 0.01), UnitTypeId.Meters),
                UnitUtils.ConvertToInternalUnits(Math.Max(MargenRedistribucionM, 0.0), UnitTypeId.Meters));

            if (puntosObjetivo == null || puntosObjetivo.Count != finales.Count)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("No se pudieron calcular puntos de redistribución válidos.");

                return;
            }

            List<ElementId> modificados = new List<ElementId>();
            int movidos = 0;
            int reconectados = 0;
            int advertencias = 0;

            using (Transaction t = new Transaction(doc, "MYG - Redistribuir tubos en cara"))
            {
                try
                {
                    t.Start();

                    FailureHandlingOptions failureOptions = t.GetFailureHandlingOptions();
                    failureOptions.SetFailuresPreprocessor(new EleTubosAutomaticos55FailurePreprocessor());
                    t.SetFailureHandlingOptions(failureOptions);

                    for (int i = 0; i < finales.Count; i++)
                    {
                        ConduitFinalRedistribucion55 final = finales[i];
                        XYZ destino = puntosObjetivo[i];

                        if (final == null || final.Conduit == null || EsVectorCero(destino))
                        {
                            advertencias++;
                            continue;
                        }

                        bool okMover = MoverExtremoConduitSinMoverOpuesto(final, destino);

                        if (!okMover)
                        {
                            advertencias++;
                            continue;
                        }

                        movidos++;

                        if (!modificados.Any(x => x.Value == final.Conduit.Id.Value))
                            modificados.Add(final.Conduit.Id);
                    }

                    doc.Regenerate();

                    for (int i = 0; i < finales.Count; i++)
                    {
                        ConduitFinalRedistribucion55 final = finales[i];

                        if (final == null || final.Conduit == null)
                            continue;

                        XYZ destino = puntosObjetivo[i];
                        Connector cConduit = ObtenerConectorMasCercano(final.Conduit, destino);

                        if (cConduit == null)
                        {
                            advertencias++;
                            continue;
                        }

                        if (ReconectarConduitATablero(cConduit, conectorTablero, tablero.Id))
                            reconectados++;
                        else
                            advertencias++;
                    }

                    doc.Regenerate();
                    t.Commit();
                }
                catch (Exception ex)
                {
                    try
                    {
                        if (t.GetStatus() == TransactionStatus.Started)
                            t.RollBack();
                    }
                    catch
                    {
                    }

                    if (Form != null && !Form.IsDisposed)
                        Form.MostrarResultado("No se pudo redistribuir: " + ex.Message);

                    return;
                }
            }

            if (SeleccionarResultado && modificados.Count > 0)
                uidoc.Selection.SetElementIds(modificados);

            if (Form != null && !Form.IsDisposed)
            {
                Form.MostrarResultado("Redistribución finalizada.");
                Form.AgregarResultado("Tubos detectados en cara: " + finales.Count);
                Form.AgregarResultado("Extremos redistribuidos: " + movidos);
                Form.AgregarResultado("Reconexiones intentadas/confirmadas: " + reconectados);
                Form.AgregarResultado("Advertencias: " + advertencias);
                Form.AgregarResultado("Separación mínima: " + SeparacionRedistribucionM.ToString("0.###") + " m");
                Form.AgregarResultado("Margen lateral: " + MargenRedistribucionM.ToString("0.###") + " m");
                Form.AgregarResultado("Longitud de acomodo: " + LongitudAcomodoM.ToString("0.###") + " m");
            }
        }

        private DatosCaraRedistribucion55 ObtenerDatosCaraRedistribucion(
            Face cara,
            XYZ puntoReferencia)
        {
            if (cara == null)
                return null;

            List<XYZ> puntos = ObtenerPuntosBordeCara(cara);

            XYZ normal = XYZ.Zero;
            XYZ ejeA = XYZ.Zero;
            XYZ ejeB = XYZ.Zero;
            XYZ origen = XYZ.Zero;

            try
            {
                PlanarFace pf = cara as PlanarFace;

                if (pf != null)
                {
                    normal = pf.FaceNormal;
                    ejeA = pf.XVector;
                    ejeB = pf.YVector;
                    origen = pf.Origin;
                }
            }
            catch
            {
            }

            if (EsVectorCero(normal))
            {
                try
                {
                    BoundingBoxUV bb = cara.GetBoundingBox();
                    UV uv = new UV((bb.Min.U + bb.Max.U) * 0.5, (bb.Min.V + bb.Max.V) * 0.5);
                    normal = cara.ComputeNormal(uv);
                    origen = cara.Evaluate(uv);
                }
                catch
                {
                }
            }

            if (EsVectorCero(normal))
                return null;

            normal = normal.Normalize();

            if (EsVectorCero(ejeA))
            {
                if (Math.Abs(normal.DotProduct(XYZ.BasisZ)) < 0.90)
                    ejeA = XYZ.BasisZ.CrossProduct(normal);
                else
                    ejeA = XYZ.BasisX;
            }

            if (EsVectorCero(ejeA))
                ejeA = XYZ.BasisX;

            ejeA = (ejeA - normal * ejeA.DotProduct(normal));

            if (EsVectorCero(ejeA))
                ejeA = XYZ.BasisX;

            ejeA = ejeA.Normalize();

            if (EsVectorCero(ejeB))
                ejeB = normal.CrossProduct(ejeA);

            ejeB = (ejeB - normal * ejeB.DotProduct(normal) - ejeA * ejeB.DotProduct(ejeA));

            if (EsVectorCero(ejeB))
                ejeB = normal.CrossProduct(ejeA);

            if (EsVectorCero(ejeB))
                ejeB = XYZ.BasisY;

            ejeB = ejeB.Normalize();

            if (puntos.Count > 0)
            {
                origen = XYZ.Zero;

                foreach (XYZ p in puntos)
                    origen += p;

                origen = origen * (1.0 / puntos.Count);
            }
            else if (EsVectorCero(origen))
            {
                origen = puntoReferencia;
            }

            double minA = double.MaxValue;
            double maxA = double.MinValue;
            double minB = double.MaxValue;
            double maxB = double.MinValue;

            if (puntos.Count == 0)
                puntos.Add(puntoReferencia);

            foreach (XYZ p in puntos)
            {
                XYZ v = p - origen;
                double a = v.DotProduct(ejeA);
                double b = v.DotProduct(ejeB);

                minA = Math.Min(minA, a);
                maxA = Math.Max(maxA, a);
                minB = Math.Min(minB, b);
                maxB = Math.Max(maxB, b);
            }

            double rangoA = maxA - minA;
            double rangoB = maxB - minB;

            XYZ ejeAncho = ejeA;
            XYZ ejeAlto = ejeB;
            double minU = minA;
            double maxU = maxA;
            double minV = minB;
            double maxV = maxB;

            // Se toma como ancho el eje con mayor dimensión real de la cara.
            if (rangoB > rangoA)
            {
                ejeAncho = ejeB;
                ejeAlto = ejeA;
                minU = minB;
                maxU = maxB;
                minV = minA;
                maxV = maxA;
            }

            return new DatosCaraRedistribucion55
            {
                Cara = cara,
                Origen = origen,
                Normal = normal,
                EjeAncho = ejeAncho.Normalize(),
                EjeAlto = ejeAlto.Normalize(),
                MinU = minU,
                MaxU = maxU,
                MinV = minV,
                MaxV = maxV
            };
        }

        private List<XYZ> ObtenerPuntosBordeCara(Face cara)
        {
            List<XYZ> puntos = new List<XYZ>();

            if (cara == null)
                return puntos;

            try
            {
                IList<CurveLoop> loops = cara.GetEdgesAsCurveLoops();

                if (loops != null)
                {
                    foreach (CurveLoop loop in loops)
                    {
                        if (loop == null)
                            continue;

                        foreach (Curve c in loop)
                        {
                            if (c == null)
                                continue;

                            IList<XYZ> tess = c.Tessellate();

                            if (tess == null)
                                continue;

                            foreach (XYZ p in tess)
                            {
                                if (p != null)
                                    puntos.Add(p);
                            }
                        }
                    }
                }
            }
            catch
            {
            }

            return puntos;
        }

        private List<ConduitFinalRedistribucion55> DetectarConduitsCercanosACara(
            Document doc,
            Element tablero,
            DatosCaraRedistribucion55 datosCara,
            double distanciaBusqueda)
        {
            List<ConduitFinalRedistribucion55> finales = new List<ConduitFinalRedistribucion55>();

            if (doc == null || tablero == null || datosCara == null)
                return finales;

            double toleranciaCara = Math.Max(distanciaBusqueda, MmToFeet(50.0));
            double margenUV = Math.Max(distanciaBusqueda, MmToFeet(50.0));

            List<Conduit> conduits = new FilteredElementCollector(doc)
                .OfClass(typeof(Conduit))
                .WhereElementIsNotElementType()
                .Cast<Conduit>()
                .Where(x => x != null && ObtenerMarca(x) == MarcaGenerado)
                .ToList();

            foreach (Conduit conduit in conduits)
            {
                List<Connector> conectores = ObtenerConectores(conduit);

                if (conectores.Count < 2)
                    continue;

                ConduitFinalRedistribucion55 mejor = null;
                double mejorScore = double.MaxValue;

                for (int i = 0; i < conectores.Count; i++)
                {
                    Connector c = conectores[i];

                    if (c == null)
                        continue;

                    XYZ p = ObtenerOrigenSeguro(c);

                    if (EsVectorCero(p))
                        continue;

                    bool conectadoTablero = ConectorTieneConexionConElemento(c, tablero.Id);
                    double distPlano = Math.Abs((p - datosCara.Origen).DotProduct(datosCara.Normal));
                    XYZ proy = p - datosCara.Normal * ((p - datosCara.Origen).DotProduct(datosCara.Normal));

                    double u = (proy - datosCara.Origen).DotProduct(datosCara.EjeAncho);
                    double v = (proy - datosCara.Origen).DotProduct(datosCara.EjeAlto);

                    bool dentroRango =
                        u >= datosCara.MinU - margenUV &&
                        u <= datosCara.MaxU + margenUV &&
                        v >= datosCara.MinV - margenUV &&
                        v <= datosCara.MaxV + margenUV;

                    if (!conectadoTablero && (distPlano > toleranciaCara || !dentroRango))
                        continue;

                    Connector otro = null;
                    foreach (Connector cOtro in conectores)
                    {
                        if (cOtro == null)
                            continue;

                        if (!object.ReferenceEquals(cOtro, c))
                        {
                            otro = cOtro;
                            break;
                        }
                    }

                    if (otro == null)
                        continue;

                    double score = distPlano + (conectadoTablero ? 0.0 : distanciaBusqueda * 0.50);

                    if (score < mejorScore)
                    {
                        mejorScore = score;
                        mejor = new ConduitFinalRedistribucion55
                        {
                            Conduit = conduit,
                            ConectorCercano = c,
                            ConectorOpuesto = otro,
                            PuntoActual = p,
                            PuntoOpuesto = ObtenerOrigenSeguro(otro),
                            ConectadoATablero = conectadoTablero
                        };
                    }
                }

                if (mejor != null)
                    finales.Add(mejor);
            }

            finales = finales
                .GroupBy(x => x.Conduit.Id.Value)
                .Select(g => g.First())
                .OrderBy(x => (x.PuntoActual - datosCara.Origen).DotProduct(datosCara.EjeAncho))
                .ToList();

            return finales;
        }

        private List<XYZ> CalcularPuntosRedistribuidosEnCara(
            DatosCaraRedistribucion55 datosCara,
            List<ConduitFinalRedistribucion55> finales,
            double separacionMinima,
            double margenLateral)
        {
            List<XYZ> puntos = new List<XYZ>();

            if (datosCara == null || finales == null || finales.Count == 0)
                return puntos;

            int n = finales.Count;
            double minU = datosCara.MinU + margenLateral;
            double maxU = datosCara.MaxU - margenLateral;

            if (maxU < minU)
            {
                minU = datosCara.MinU;
                maxU = datosCara.MaxU;
            }

            double anchoUtil = maxU - minU;
            double centroU = (datosCara.MinU + datosCara.MaxU) * 0.5;

            double sumaV = 0.0;
            int cuentaV = 0;

            foreach (ConduitFinalRedistribucion55 f in finales)
            {
                if (f == null || EsVectorCero(f.PuntoActual))
                    continue;

                XYZ proy = f.PuntoActual - datosCara.Normal * ((f.PuntoActual - datosCara.Origen).DotProduct(datosCara.Normal));
                double v = (proy - datosCara.Origen).DotProduct(datosCara.EjeAlto);
                sumaV += v;
                cuentaV++;
            }

            double objetivoV = cuentaV > 0
                ? sumaV / cuentaV
                : (datosCara.MinV + datosCara.MaxV) * 0.5;

            objetivoV = Math.Max(datosCara.MinV, Math.Min(datosCara.MaxV, objetivoV));

            if (n == 1)
            {
                double uUnico = finales[0] == null
                    ? centroU
                    : ((finales[0].PuntoActual - datosCara.Origen).DotProduct(datosCara.EjeAncho));

                uUnico = Math.Max(minU, Math.Min(maxU, uUnico));
                puntos.Add(datosCara.Origen + datosCara.EjeAncho * uUnico + datosCara.EjeAlto * objetivoV);
                return puntos;
            }

            double paso = anchoUtil / Math.Max(n - 1, 1);
            double inicio = minU;

            // Si la cara es muy angosta para la separación mínima, se centra el arreglo.
            if (paso < separacionMinima)
            {
                paso = separacionMinima;
                inicio = centroU - paso * (n - 1) * 0.5;
            }

            for (int i = 0; i < n; i++)
            {
                double u = inicio + paso * i;
                XYZ p = datosCara.Origen + datosCara.EjeAncho * u + datosCara.EjeAlto * objetivoV;
                puntos.Add(p);
            }

            return puntos;
        }

        private bool MoverExtremoConduitSinMoverOpuesto(
            ConduitFinalRedistribucion55 final,
            XYZ nuevoPunto)
        {
            if (final == null || final.Conduit == null || EsVectorCero(nuevoPunto))
                return false;

            try
            {
                LocationCurve lc = final.Conduit.Location as LocationCurve;

                if (lc == null || lc.Curve == null)
                    return false;

                Curve curva = lc.Curve;
                XYZ e0 = curva.GetEndPoint(0);
                XYZ e1 = curva.GetEndPoint(1);

                double d0 = e0.DistanceTo(final.PuntoActual);
                double d1 = e1.DistanceTo(final.PuntoActual);

                XYZ fijo = d0 <= d1 ? e1 : e0;

                if (fijo.DistanceTo(nuevoPunto) < MmToFeet(10.0))
                    return false;

                DesconectarConexionesConElemento(final.ConectorCercano, null);

                Line nuevaLinea = Line.CreateBound(fijo, nuevoPunto);
                lc.Curve = nuevaLinea;

                return true;
            }
            catch
            {
                return false;
            }
        }

        private bool ReconectarConduitATablero(
            Connector conectorConduit,
            Connector conectorTablero,
            ElementId tableroId)
        {
            if (conectorConduit == null || conectorTablero == null)
                return false;

            try
            {
                if (conectorConduit.IsConnectedTo(conectorTablero))
                    return true;
            }
            catch
            {
            }

            try
            {
                conectorTablero.ConnectTo(conectorConduit);

                if (conectorConduit.IsConnectedTo(conectorTablero))
                    return true;
            }
            catch
            {
            }

            try
            {
                conectorConduit.ConnectTo(conectorTablero);

                if (conectorConduit.IsConnectedTo(conectorTablero))
                    return true;
            }
            catch
            {
            }

            // Si Revit no permite confirmar IsConnectedTo para conectores de superficie,
            // se considera aceptable si después de ConnectTo existe alguna referencia al tablero.
            try
            {
                if (tableroId != null && tableroId != ElementId.InvalidElementId)
                    return ConectorTieneConexionConElemento(conectorConduit, tableroId);
            }
            catch
            {
            }

            return false;
        }

        private bool ConectorTieneConexionConElemento(
            Connector conector,
            ElementId elementId)
        {
            if (conector == null || elementId == null || elementId == ElementId.InvalidElementId)
                return false;

            try
            {
                ConnectorSet refs = conector.AllRefs;

                if (refs == null)
                    return false;

                foreach (Connector r in refs)
                {
                    if (r == null || r.Owner == null)
                        continue;

                    if (r.Owner.Id.Value == elementId.Value)
                        return true;
                }
            }
            catch
            {
            }

            return false;
        }

        private void DesconectarConexionesConElemento(
            Connector conector,
            ElementId elementId)
        {
            if (conector == null)
                return;

            try
            {
                ConnectorSet refs = conector.AllRefs;

                if (refs == null)
                    return;

                List<Connector> refsLista = new List<Connector>();

                foreach (Connector r in refs)
                {
                    if (r == null)
                        continue;

                    if (elementId == null || elementId == ElementId.InvalidElementId)
                    {
                        refsLista.Add(r);
                    }
                    else if (r.Owner != null && r.Owner.Id.Value == elementId.Value)
                    {
                        refsLista.Add(r);
                    }
                }

                foreach (Connector r in refsLista)
                {
                    try
                    {
                        if (conector.IsConnectedTo(r))
                            conector.DisconnectFrom(r);
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }
        }

        private void EjecutarBorrarTubos(
            UIDocument uidoc,
            Document doc,
            bool mostrarDialogo)
        {
            int borrados = 0;

            using (Transaction t = new Transaction(doc, "MYG - Borrar tubos automáticos"))
            {
                t.Start();
                borrados = BorrarElementosPrevios(doc);
                t.Commit();
            }

            if (Form != null && !Form.IsDisposed)
                Form.MostrarResultado("Tubos MYG borrados: " + borrados);

            // V3: sin ventanas emergentes. El resultado se muestra solo en la ventana MYG.
        }

        private int BorrarElementosPrevios(Document doc)
        {
            if (doc == null)
                return 0;

            List<ElementId> ids = new List<ElementId>();

            FilteredElementCollector collector = new FilteredElementCollector(doc)
                .WhereElementIsNotElementType();

            foreach (Element e in collector)
            {
                if (e == null)
                    continue;

                string marca = ObtenerMarca(e);

                if (marca == MarcaGenerado)
                    ids.Add(e.Id);
            }

            int borrados = 0;

            foreach (ElementId id in ids)
            {
                try
                {
                    ICollection<ElementId> res = doc.Delete(id);

                    if (res != null)
                        borrados += res.Count;
                    else
                        borrados++;
                }
                catch
                {
                }
            }

            return borrados;
        }

        private void MarcarElemento(Element e)
        {
            if (e == null)
                return;

            try
            {
                Parameter p = e.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);

                if (p != null && !p.IsReadOnly)
                    p.Set(MarcaGenerado);
            }
            catch
            {
            }
        }

        private string ObtenerMarca(Element e)
        {
            if (e == null)
                return "";

            try
            {
                Parameter p = e.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);

                if (p != null && p.StorageType == StorageType.String)
                    return p.AsString() ?? "";
            }
            catch
            {
            }

            return "";
        }

        private void SetDiametroConduit(
            Conduit conduit,
            double diametroMm)
        {
            if (conduit == null || diametroMm <= 0.0)
                return;

            double valorFeet = MmToFeet(diametroMm);

            try
            {
                Parameter p = conduit.get_Parameter(BuiltInParameter.RBS_CONDUIT_DIAMETER_PARAM);

                if (p != null && !p.IsReadOnly)
                    p.Set(valorFeet);
            }
            catch
            {
            }
        }

        private Level ObtenerNivelParaCreacion(
            Document doc,
            Element a,
            Element b)
        {
            if (doc == null)
                return null;

            try
            {
                ViewPlan vp = doc.ActiveView as ViewPlan;

                if (vp != null && vp.GenLevel != null)
                    return vp.GenLevel;
            }
            catch
            {
            }

            try
            {
                if (a != null && a.LevelId != null && a.LevelId != ElementId.InvalidElementId)
                {
                    Level l = doc.GetElement(a.LevelId) as Level;

                    if (l != null)
                        return l;
                }
            }
            catch
            {
            }

            try
            {
                if (b != null && b.LevelId != null && b.LevelId != ElementId.InvalidElementId)
                {
                    Level l = doc.GetElement(b.LevelId) as Level;

                    if (l != null)
                        return l;
                }
            }
            catch
            {
            }

            try
            {
                return new FilteredElementCollector(doc)
                    .OfClass(typeof(Level))
                    .Cast<Level>()
                    .OrderBy(x => x.Elevation)
                    .FirstOrDefault();
            }
            catch
            {
            }

            return null;
        }

        private Connector RecuperarConector(
            Element owner,
            EleTubosAutomaticos55ConectorInfo info)
        {
            if (owner == null || info == null)
                return null;

            List<Connector> conectores = ObtenerConectores(owner);

            if (conectores.Count == 0)
                return null;

            Connector mejor = null;
            double mejorDist = double.MaxValue;

            foreach (Connector c in conectores)
            {
                XYZ o = ObtenerOrigenSeguro(c);
                double d = o.DistanceTo(info.Origen);

                if (d < mejorDist)
                {
                    mejorDist = d;
                    mejor = c;
                }
            }

            return mejor;
        }

        private Connector ObtenerConectorMasCercano(
            Element e,
            XYZ punto)
        {
            List<Connector> conectores = ObtenerConectores(e);

            if (conectores.Count == 0)
                return null;

            Connector mejor = null;
            double mejorDist = double.MaxValue;

            foreach (Connector c in conectores)
            {
                if (c == null)
                    continue;

                XYZ o = ObtenerOrigenSeguro(c);

                if (EsVectorCero(o))
                    continue;

                double dist = o.DistanceTo(punto);

                if (dist < mejorDist)
                {
                    mejorDist = dist;
                    mejor = c;
                }
            }

            return mejor;
        }

        private List<Connector> ObtenerConectores(Element e)
        {
            List<Connector> conectores = new List<Connector>();

            if (e == null)
                return conectores;

            try
            {
                FamilyInstance fi = e as FamilyInstance;

                if (fi != null && fi.MEPModel != null && fi.MEPModel.ConnectorManager != null)
                {
                    AgregarConectoresDesdeSet(fi.MEPModel.ConnectorManager.Connectors, conectores);
                }
            }
            catch
            {
            }

            try
            {
                MEPCurve mep = e as MEPCurve;

                if (mep != null && mep.ConnectorManager != null)
                {
                    AgregarConectoresDesdeSet(mep.ConnectorManager.Connectors, conectores);
                }
            }
            catch
            {
            }

            return conectores;
        }

        private void AgregarConectoresDesdeSet(
            ConnectorSet set,
            List<Connector> lista)
        {
            if (set == null || lista == null)
                return;

            foreach (Connector c in set)
            {
                if (c == null)
                    continue;

                // V5:
                // En tableros con "conector de superficie de tubo" el conector puede no ser End.
                // Por eso se permite todo conector físico con origen válido. Los conectores lógicos
                // que no sirven para conectar fallarán de forma segura más adelante.
                try
                {
                    XYZ o = c.Origin;
                }
                catch
                {
                    continue;
                }

                lista.Add(c);
            }
        }

        private XYZ ObtenerOrigenSeguro(Connector c)
        {
            if (c == null)
                return XYZ.Zero;

            try
            {
                return c.Origin;
            }
            catch
            {
                return XYZ.Zero;
            }
        }

        private XYZ ObtenerDireccionConector(Connector c)
        {
            if (c == null)
                return XYZ.Zero;

            try
            {
                if (c.CoordinateSystem != null &&
                    !EsVectorCero(c.CoordinateSystem.BasisZ))
                {
                    return c.CoordinateSystem.BasisZ.Normalize();
                }
            }
            catch
            {
            }

            try
            {
                if (c.CoordinateSystem != null &&
                    !EsVectorCero(c.CoordinateSystem.BasisX))
                {
                    return c.CoordinateSystem.BasisX.Normalize();
                }
            }
            catch
            {
            }

            return XYZ.Zero;
        }

        private XYZ ObtenerCentroElemento(Element e)
        {
            if (e == null)
                return XYZ.Zero;

            try
            {
                BoundingBoxXYZ bb = e.get_BoundingBox(null);

                if (bb != null)
                    return (bb.Min + bb.Max) * 0.5;
            }
            catch
            {
            }

            try
            {
                LocationPoint lp = e.Location as LocationPoint;

                if (lp != null)
                    return lp.Point;
            }
            catch
            {
            }

            try
            {
                LocationCurve lc = e.Location as LocationCurve;

                if (lc != null && lc.Curve != null)
                    return lc.Curve.Evaluate(0.5, true);
            }
            catch
            {
            }

            return XYZ.Zero;
        }

        private double MmToFeet(double mm)
        {
            return UnitUtils.ConvertToInternalUnits(mm, UnitTypeId.Millimeters);
        }

        private double FeetToMm(double feet)
        {
            return UnitUtils.ConvertFromInternalUnits(feet, UnitTypeId.Millimeters);
        }

        private bool EsVectorCero(XYZ v)
        {
            if (v == null)
                return true;

            return v.GetLength() < Epsilon;
        }

        private class PicarConectorResultado55
        {
            public Element Owner { get; set; }
            public Connector Conector { get; set; }
            public EleTubosAutomaticos55ConectorInfo Info { get; set; }
        }

        private class ResultadoCreacionTubos55
        {
            public bool Ok { get; set; }
            public string Error { get; set; }
            public List<ElementId> Creados { get; set; } = new List<ElementId>();
            public int SegmentosCreados { get; set; }
            public int CodosCreados { get; set; }
            public int ConexionesExtremo { get; set; }
            public int ErroresConexion { get; set; }
        }

        private class EleTubosAutomaticos55FailurePreprocessor : IFailuresPreprocessor
        {
            public FailureProcessingResult PreprocessFailures(FailuresAccessor failuresAccessor)
            {
                if (failuresAccessor == null)
                    return FailureProcessingResult.Continue;

                try
                {
                    IList<FailureMessageAccessor> failures = failuresAccessor.GetFailureMessages();

                    if (failures == null)
                        return FailureProcessingResult.Continue;

                    foreach (FailureMessageAccessor failure in failures)
                    {
                        if (failure == null)
                            continue;

                        if (failure.GetSeverity() == FailureSeverity.Warning)
                            failuresAccessor.DeleteWarning(failure);
                    }
                }
                catch
                {
                }

                return FailureProcessingResult.Continue;
            }
        }

        private class SegmentoConduitInfo
        {
            public Conduit Conduit { get; set; }
            public XYZ Inicio { get; set; }
            public XYZ Fin { get; set; }
        }

        private class DatosCaraRedistribucion55
        {
            public Face Cara { get; set; }
            public XYZ Origen { get; set; }
            public XYZ Normal { get; set; }
            public XYZ EjeAncho { get; set; }
            public XYZ EjeAlto { get; set; }
            public double MinU { get; set; }
            public double MaxU { get; set; }
            public double MinV { get; set; }
            public double MaxV { get; set; }
        }

        private class ConduitFinalRedistribucion55
        {
            public Conduit Conduit { get; set; }
            public Connector ConectorCercano { get; set; }
            public Connector ConectorOpuesto { get; set; }
            public XYZ PuntoActual { get; set; }
            public XYZ PuntoOpuesto { get; set; }
            public bool ConectadoATablero { get; set; }
        }

        private class FiltroElementoConConectores : ISelectionFilter
        {
            public bool AllowElement(Element elem)
            {
                if (elem == null)
                    return false;

                try
                {
                    FamilyInstance fi = elem as FamilyInstance;

                    if (fi != null &&
                        fi.MEPModel != null &&
                        fi.MEPModel.ConnectorManager != null &&
                        fi.MEPModel.ConnectorManager.Connectors != null &&
                        fi.MEPModel.ConnectorManager.Connectors.Size > 0)
                    {
                        return true;
                    }
                }
                catch
                {
                }

                try
                {
                    MEPCurve mep = elem as MEPCurve;

                    if (mep != null &&
                        mep.ConnectorManager != null &&
                        mep.ConnectorManager.Connectors != null &&
                        mep.ConnectorManager.Connectors.Size > 0)
                    {
                        return true;
                    }
                }
                catch
                {
                }

                return false;
            }

            public bool AllowReference(Reference reference, XYZ position)
            {
                return true;
            }
        }
    }
}
