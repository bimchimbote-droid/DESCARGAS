using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{






    // =====================================
    // COMANDO 5.5 - TUBOS AUTOMÁTICOS
    // V17: MAIN CON FRANJA LATERAL + RÍGIDOS + FLEXIBLES + PROYECTAR OCTOGONALES
    // SIN USING NI NAMESPACE
    // =====================================

    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class EleTubosAutomaticos55Command : Autodesk.Revit.UI.IExternalCommand
    {
        private static MYG_TubosAutomaticos55MainForm _mainForm;

        private static EleTubosAutomaticos55Form _formRigidos;
        private static global::MYG_Addin.EjecutarEleTubosAutomaticos55Handler _handlerRigidos;
        private static Autodesk.Revit.UI.ExternalEvent _eventRigidos;

        private static EleTubosFlexibles55Form _formFlexibles;
        private static global::MYG_Addin.EjecutarEleTubosFlexibles55Handler _handlerFlexibles;
        private static Autodesk.Revit.UI.ExternalEvent _eventFlexibles;

        private static EleProyectarOctogonales55Form _formProyectar;
        private static global::MYG_Addin.EjecutarEleProyectarOctogonales55Handler _handlerProyectar;
        private static Autodesk.Revit.UI.ExternalEvent _eventProyectar;

        public Autodesk.Revit.UI.Result Execute(
            Autodesk.Revit.UI.ExternalCommandData commandData,
            ref string message,
            Autodesk.Revit.DB.ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            try
            {
                Autodesk.Revit.UI.UIApplication uiapp = commandData.Application;
                Autodesk.Revit.UI.UIDocument uidoc = uiapp == null ? null : uiapp.ActiveUIDocument;

                if (uidoc == null || uidoc.Document == null)
                {
                    message = "No hay documento activo.";
                    return Autodesk.Revit.UI.Result.Failed;
                }

                if (_mainForm == null || _mainForm.IsDisposed)
                {
                    _handlerRigidos = new global::MYG_Addin.EjecutarEleTubosAutomaticos55Handler();
                    _eventRigidos = Autodesk.Revit.UI.ExternalEvent.Create(_handlerRigidos);
                    _formRigidos = new EleTubosAutomaticos55Form(_handlerRigidos, _eventRigidos);
                    _handlerRigidos.Form = _formRigidos;

                    _handlerFlexibles = new global::MYG_Addin.EjecutarEleTubosFlexibles55Handler();
                    _handlerFlexibles.UiDoc = uidoc;
                    _eventFlexibles = Autodesk.Revit.UI.ExternalEvent.Create(_handlerFlexibles);
                    _formFlexibles = new EleTubosFlexibles55Form(_handlerFlexibles, _eventFlexibles);
                    _handlerFlexibles.Form = _formFlexibles;

                    _handlerProyectar = new global::MYG_Addin.EjecutarEleProyectarOctogonales55Handler();
                    _handlerProyectar.UiDoc = uidoc;
                    _eventProyectar = Autodesk.Revit.UI.ExternalEvent.Create(_handlerProyectar);
                    _formProyectar = new EleProyectarOctogonales55Form(_handlerProyectar, _eventProyectar);
                    _handlerProyectar.Form = _formProyectar;

                    _mainForm = new MYG_TubosAutomaticos55MainForm(
                        uidoc,
                        _formRigidos,
                        _handlerRigidos,
                        _eventRigidos,
                        _formFlexibles,
                        _handlerFlexibles,
                        _eventFlexibles,
                        _formProyectar,
                        _handlerProyectar,
                        _eventProyectar);
                }
                else
                {
                    if (_handlerFlexibles != null)
                        _handlerFlexibles.UiDoc = uidoc;

                    if (_handlerProyectar != null)
                        _handlerProyectar.UiDoc = uidoc;
                }

                if (!_mainForm.Visible)
                {
                    RevitWindowHandle handle = new RevitWindowHandle(uiapp.MainWindowHandle);
                    _mainForm.Show(handle);
                }
                else
                {
                    _mainForm.Activate();
                }

                return Autodesk.Revit.UI.Result.Succeeded;
            }
            catch (System.Exception ex)
            {
                message = ex.Message;
                return Autodesk.Revit.UI.Result.Failed;
            }
        }

        private class RevitWindowHandle : System.Windows.Forms.IWin32Window
        {
            private readonly System.IntPtr _handle;

            public RevitWindowHandle(System.IntPtr handle)
            {
                _handle = handle;
            }

            public System.IntPtr Handle
            {
                get { return _handle; }
            }
        }
    }

}
