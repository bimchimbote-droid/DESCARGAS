using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{






    // =====================================
    // VENTANA MAIN 5.5 - TUBOS AUTOMÁTICOS
    // =====================================

    public class MYG_TubosAutomaticos55MainForm : System.Windows.Forms.Form
    {
        private const int ANCHO_MENU = 175;

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel panelContenido;
        private System.Windows.Forms.Button btnMenuTubosRigidos;
        private System.Windows.Forms.Button btnMenuTubosFlexibles;
        private System.Windows.Forms.Button btnMenuProyectarOctogonales;
        private System.Windows.Forms.PictureBox picIconoModulo;
        private System.Windows.Forms.Label lblTituloModulo;

        private Autodesk.Revit.UI.UIDocument uiDoc;

        public EleTubosAutomaticos55Form VentanaTubosRigidos { get; private set; }
        public EleTubosFlexibles55Form VentanaTubosFlexibles { get; private set; }
        public EleProyectarOctogonales55Form VentanaProyectarOctogonales { get; private set; }

        private global::MYG_Addin.EjecutarEleTubosAutomaticos55Handler handlerTubosRigidos;
        private global::MYG_Addin.EjecutarEleTubosFlexibles55Handler handlerTubosFlexibles;
        private global::MYG_Addin.EjecutarEleProyectarOctogonales55Handler handlerProyectarOctogonales;

        private Autodesk.Revit.UI.ExternalEvent eventoTubosRigidos;
        private Autodesk.Revit.UI.ExternalEvent eventoTubosFlexibles;
        private Autodesk.Revit.UI.ExternalEvent eventoProyectarOctogonales;

        private bool cargaInicialRigidosSolicitada = false;
        private bool cargaInicialFlexiblesSolicitada = false;
        private bool cargaInicialProyectarSolicitada = false;

        public MYG_TubosAutomaticos55MainForm(
            Autodesk.Revit.UI.UIDocument uidoc,
            EleTubosAutomaticos55Form ventanaRigidos,
            global::MYG_Addin.EjecutarEleTubosAutomaticos55Handler handlerRigidos,
            Autodesk.Revit.UI.ExternalEvent eventoRigidos,
            EleTubosFlexibles55Form ventanaFlexibles,
            global::MYG_Addin.EjecutarEleTubosFlexibles55Handler handlerFlexibles,
            Autodesk.Revit.UI.ExternalEvent eventoFlexibles,
            EleProyectarOctogonales55Form ventanaProyectar,
            global::MYG_Addin.EjecutarEleProyectarOctogonales55Handler handlerProyectar,
            Autodesk.Revit.UI.ExternalEvent eventoProyectar)
        {
            uiDoc = uidoc;

            VentanaTubosRigidos = ventanaRigidos;
            handlerTubosRigidos = handlerRigidos;
            eventoTubosRigidos = eventoRigidos;

            VentanaTubosFlexibles = ventanaFlexibles;
            handlerTubosFlexibles = handlerFlexibles;
            eventoTubosFlexibles = eventoFlexibles;

            VentanaProyectarOctogonales = ventanaProyectar;
            handlerProyectarOctogonales = handlerProyectar;
            eventoProyectarOctogonales = eventoProyectar;

            this.Text = "MEP 5.5 - Tubos automáticos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.ControlBox = true;
            this.MinimizeBox = true;
            this.MaximizeBox = false;
            this.ShowInTaskbar = true;
            this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;

            int anchoContenido = 760;
            int altoTotal = 735;
            this.ClientSize = new System.Drawing.Size(ANCHO_MENU + anchoContenido, altoTotal);

            CrearMenuLateral();
            CrearPanelContenido();

            this.Controls.Add(panelContenido);
            this.Controls.Add(panelMenu);

            ValidarReferenciasRecibidas();
            CargarVentanaTubosRigidos();

            this.FormClosed += (s, e) =>
            {
                try
                {
                    LiberarImagenIcono();

                    if (VentanaTubosRigidos != null && !VentanaTubosRigidos.IsDisposed)
                        VentanaTubosRigidos.Dispose();

                    if (VentanaTubosFlexibles != null && !VentanaTubosFlexibles.IsDisposed)
                        VentanaTubosFlexibles.Dispose();

                    if (VentanaProyectarOctogonales != null && !VentanaProyectarOctogonales.IsDisposed)
                        VentanaProyectarOctogonales.Dispose();
                }
                catch
                {
                }
            };
        }

        private void ValidarReferenciasRecibidas()
        {
            if (VentanaTubosRigidos == null)
                throw new System.InvalidOperationException("No se recibió la ventana de Tubos rígidos.");

            if (VentanaTubosFlexibles == null)
                throw new System.InvalidOperationException("No se recibió la ventana de Tubos flexibles.");

            if (VentanaProyectarOctogonales == null)
                throw new System.InvalidOperationException("No se recibió la ventana de Proyectar octogonales.");

            if (eventoTubosRigidos == null)
                throw new System.InvalidOperationException("No se recibió el ExternalEvent de Tubos rígidos.");

            if (eventoTubosFlexibles == null)
                throw new System.InvalidOperationException("No se recibió el ExternalEvent de Tubos flexibles.");

            if (eventoProyectarOctogonales == null)
                throw new System.InvalidOperationException("No se recibió el ExternalEvent de Proyectar octogonales.");
        }

        private void CrearMenuLateral()
        {
            panelMenu = new System.Windows.Forms.Panel()
            {
                Left = 0,
                Top = 0,
                Width = ANCHO_MENU,
                Height = this.ClientSize.Height,
                Anchor = System.Windows.Forms.AnchorStyles.Top |
                         System.Windows.Forms.AnchorStyles.Bottom |
                         System.Windows.Forms.AnchorStyles.Left,
                BackColor = System.Drawing.Color.FromArgb(238, 240, 243),
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            };

            picIconoModulo = new System.Windows.Forms.PictureBox()
            {
                Left = 14,
                Top = 14,
                Width = 54,
                Height = 54,
                SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom,
                BackColor = System.Drawing.Color.Transparent
            };

            picIconoModulo.Image = CargarIconoDesdeCarpeta("ele_tubos_automaticos.png");

            lblTituloModulo = new System.Windows.Forms.Label()
            {
                Text = "MYG\nTUBOS\nMEP",
                Left = 74,
                Top = 13,
                Width = ANCHO_MENU - 82,
                Height = 58,
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(55, 55, 55),
                BackColor = System.Drawing.Color.Transparent
            };

            System.Windows.Forms.Panel linea = new System.Windows.Forms.Panel()
            {
                Left = 0,
                Top = 84,
                Width = ANCHO_MENU,
                Height = 1,
                BackColor = System.Drawing.Color.FromArgb(210, 210, 210)
            };

            btnMenuTubosRigidos = CrearBotonMenu("  Tubos rígidos", 103);
            btnMenuTubosRigidos.Click += (s, e) => CargarVentanaTubosRigidos();

            btnMenuTubosFlexibles = CrearBotonMenu("  Tubos flexibles", 145);
            btnMenuTubosFlexibles.Click += (s, e) => CargarVentanaTubosFlexibles();

            btnMenuProyectarOctogonales = CrearBotonMenu("  Proyectar octogonales", 187);
            btnMenuProyectarOctogonales.Click += (s, e) => CargarVentanaProyectarOctogonales();

            panelMenu.Controls.Add(picIconoModulo);
            panelMenu.Controls.Add(lblTituloModulo);
            panelMenu.Controls.Add(linea);
            panelMenu.Controls.Add(btnMenuTubosRigidos);
            panelMenu.Controls.Add(btnMenuTubosFlexibles);
            panelMenu.Controls.Add(btnMenuProyectarOctogonales);
        }

        private System.Windows.Forms.Button CrearBotonMenu(string texto, int top)
        {
            System.Windows.Forms.Button btn = new System.Windows.Forms.Button()
            {
                Text = texto,
                Left = 0,
                Top = top,
                Width = ANCHO_MENU - 1,
                Height = 42,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                Cursor = System.Windows.Forms.Cursors.Hand,
                BackColor = System.Drawing.Color.FromArgb(238, 240, 243),
                ForeColor = System.Drawing.Color.FromArgb(55, 55, 55)
            };

            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(225, 228, 232);
            btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(215, 218, 222);

            return btn;
        }

        private void CrearPanelContenido()
        {
            panelContenido = new System.Windows.Forms.Panel()
            {
                Left = ANCHO_MENU,
                Top = 0,
                Width = this.ClientSize.Width - ANCHO_MENU,
                Height = this.ClientSize.Height,
                Anchor = System.Windows.Forms.AnchorStyles.Top |
                         System.Windows.Forms.AnchorStyles.Bottom |
                         System.Windows.Forms.AnchorStyles.Left |
                         System.Windows.Forms.AnchorStyles.Right,
                BackColor = System.Drawing.Color.FromArgb(245, 247, 250)
            };
        }

        private void CargarVentanaTubosRigidos()
        {
            if (VentanaTubosRigidos == null || VentanaTubosRigidos.IsDisposed)
                return;

            MostrarFormularioEnContenido(VentanaTubosRigidos);
            MarcarBotonActivo(btnMenuTubosRigidos);

            if (!cargaInicialRigidosSolicitada)
            {
                cargaInicialRigidosSolicitada = true;
                SolicitarCargaTubosRigidos();
            }
        }

        private void CargarVentanaTubosFlexibles()
        {
            if (VentanaTubosFlexibles == null || VentanaTubosFlexibles.IsDisposed)
                return;

            MostrarFormularioEnContenido(VentanaTubosFlexibles);
            MarcarBotonActivo(btnMenuTubosFlexibles);

            if (!cargaInicialFlexiblesSolicitada)
            {
                cargaInicialFlexiblesSolicitada = true;
                SolicitarCargaTubosFlexibles();
            }
        }

        private void CargarVentanaProyectarOctogonales()
        {
            if (VentanaProyectarOctogonales == null || VentanaProyectarOctogonales.IsDisposed)
                return;

            MostrarFormularioEnContenido(VentanaProyectarOctogonales);
            MarcarBotonActivo(btnMenuProyectarOctogonales);

            if (!cargaInicialProyectarSolicitada)
            {
                cargaInicialProyectarSolicitada = true;
                SolicitarCargaProyectarOctogonales();
            }
        }

        private void MostrarFormularioEnContenido(System.Windows.Forms.Form form)
        {
            if (form == null || panelContenido == null)
                return;

            panelContenido.SuspendLayout();
            panelContenido.Controls.Clear();

            form.TopLevel = false;
            form.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            form.Dock = System.Windows.Forms.DockStyle.Fill;
            form.Visible = true;
            form.TopMost = false;

            panelContenido.Controls.Add(form);
            form.Show();
            form.BringToFront();
            panelContenido.ResumeLayout();
        }

        private void MarcarBotonActivo(System.Windows.Forms.Button activo)
        {
            System.Drawing.Color azul = System.Drawing.Color.FromArgb(0, 122, 204);
            System.Drawing.Color fondo = System.Drawing.Color.FromArgb(238, 240, 243);
            System.Drawing.Color texto = System.Drawing.Color.FromArgb(55, 55, 55);

            System.Windows.Forms.Button[] botones = new System.Windows.Forms.Button[]
            {
            btnMenuTubosRigidos,
            btnMenuTubosFlexibles,
            btnMenuProyectarOctogonales
            };

            foreach (System.Windows.Forms.Button b in botones)
            {
                if (b == null)
                    continue;

                if (b == activo)
                {
                    b.BackColor = azul;
                    b.ForeColor = System.Drawing.Color.White;
                }
                else
                {
                    b.BackColor = fondo;
                    b.ForeColor = texto;
                }
            }
        }

        private void SolicitarCargaTubosRigidos()
        {
            try
            {
                VentanaTubosRigidos.SolicitarCargaInicial();
            }
            catch
            {
            }
        }

        private void SolicitarCargaTubosFlexibles()
        {
            try
            {
                VentanaTubosFlexibles.SolicitarCargaInicial();
            }
            catch
            {
            }
        }

        private void SolicitarCargaProyectarOctogonales()
        {
            try
            {
                VentanaProyectarOctogonales.SolicitarCargaInicial();
            }
            catch
            {
            }
        }

        private System.Drawing.Image CargarIconoDesdeCarpeta(string nombreArchivo)
        {
            try
            {
                string baseDir = System.IO.Path.GetDirectoryName(
                    System.Reflection.Assembly.GetExecutingAssembly().Location);

                if (string.IsNullOrWhiteSpace(baseDir))
                    return CrearIconoRespaldo();

                string[] rutas = new string[]
                {
                System.IO.Path.Combine(baseDir, "iconos", nombreArchivo),
                System.IO.Path.Combine(baseDir, nombreArchivo)
                };

                foreach (string ruta in rutas)
                {
                    if (!System.IO.File.Exists(ruta))
                        continue;

                    using (System.Drawing.Image imgTemp = System.Drawing.Image.FromFile(ruta))
                    {
                        return new System.Drawing.Bitmap(imgTemp);
                    }
                }
            }
            catch
            {
            }

            return CrearIconoRespaldo();
        }

        private System.Drawing.Image CrearIconoRespaldo()
        {
            System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(64, 64);

            using (System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(bmp))
            using (System.Drawing.Pen pen = new System.Drawing.Pen(System.Drawing.Color.FromArgb(60, 60, 60), 2))
            using (System.Drawing.Brush gris = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(170, 170, 170)))
            using (System.Drawing.Brush azul = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(0, 122, 204)))
            {
                g.Clear(System.Drawing.Color.Transparent);
                g.DrawEllipse(pen, 8, 18, 48, 22);
                g.DrawLine(pen, 12, 29, 52, 29);
                g.FillEllipse(azul, 10, 25, 8, 8);
                g.FillEllipse(azul, 46, 25, 8, 8);
                g.FillRectangle(gris, 18, 34, 28, 9);
                g.DrawRectangle(pen, 18, 34, 28, 9);
            }

            return bmp;
        }

        private void LiberarImagenIcono()
        {
            try
            {
                if (picIconoModulo != null && picIconoModulo.Image != null)
                {
                    System.Drawing.Image img = picIconoModulo.Image;
                    picIconoModulo.Image = null;
                    img.Dispose();
                }
            }
            catch
            {
            }
        }
    }

}
