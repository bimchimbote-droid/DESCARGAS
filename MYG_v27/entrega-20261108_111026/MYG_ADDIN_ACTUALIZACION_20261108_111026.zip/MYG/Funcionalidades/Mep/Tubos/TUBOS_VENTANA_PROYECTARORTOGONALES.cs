﻿// =====================================
// VENTANA 5.5 - PROYECTAR OCTOGONALES / FAMILIAS POR CARA
// Contenido embebible para MYG_TubosAutomaticos55MainForm
// V19: selección previa + nativos/vínculos + opción crear tubería flexible
// SIN USING NI NAMESPACE
// =====================================

public class EleProyectarOctogonales55Form : System.Windows.Forms.Form
{
    private readonly global::MYG_Addin.EjecutarEleProyectarOctogonales55Handler _handler;
    private readonly Autodesk.Revit.UI.ExternalEvent _externalEvent;

    private System.Windows.Forms.ComboBox cmbFamiliaPorCara;
    private System.Windows.Forms.NumericUpDown nudDesfaseSobreCaraM;
    private System.Windows.Forms.NumericUpDown nudAlturaMaximaBusquedaM;
    private System.Windows.Forms.NumericUpDown nudSeparacionInicioM;
    private System.Windows.Forms.CheckBox chkIgnorarAnfitrion;
    private System.Windows.Forms.CheckBox chkOrientacionOriginal;
    private System.Windows.Forms.CheckBox chkSeleccionarCreadas;
    private System.Windows.Forms.CheckBox chkCrearTuberiaFlexible;
    private System.Windows.Forms.Button btnRecargarFamilias;
    private System.Windows.Forms.Button btnSeleccionarBases;
    private System.Windows.Forms.Button btnProyectar;
    private System.Windows.Forms.Label lblBasesSeleccionadas;
    private System.Windows.Forms.RichTextBox txtResultado;

    private const string ArchivoConfigNombre = "MYG_ProyectarOctogonales55_Config.ini";
    private long _familiaIdGuardada = long.MinValue;
    private string _familiaTextoGuardada = "";
    private bool _configuracionYaCargada = false;

    public EleProyectarOctogonales55Form(
        global::MYG_Addin.EjecutarEleProyectarOctogonales55Handler handler,
        Autodesk.Revit.UI.ExternalEvent externalEvent)
    {
        _handler = handler;
        _externalEvent = externalEvent;

        this.Text = "Proyectar octogonales";
        this.Width = 760;
        this.Height = 760;
        this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
        this.TopLevel = false;
        this.ShowInTaskbar = false;
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.Dock = System.Windows.Forms.DockStyle.Fill;
        this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
        this.Font = new System.Drawing.Font("Segoe UI", 9F);
        this.TopMost = false;

        InicializarComponentes();
        this.FormClosing += (s, e) => GuardarConfiguracion();
    }

    private void InicializarComponentes()
    {
        System.Windows.Forms.Label lblAutor = new System.Windows.Forms.Label()
        {
            Text = "Creado por: Ing. Marlon Yacila  |  MEP - Proyectar octogonales / familias por cara",
            Left = 20,
            Top = 10,
            Width = 700,
            Height = 20,
            Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
            ForeColor = System.Drawing.Color.Gray
        };

        System.Windows.Forms.Label lblTitulo = CrearTitulo("01. FAMILIA A PROYECTAR", 20, 42, 700);

        System.Windows.Forms.Label lblInfo = new System.Windows.Forms.Label()
        {
            Text = "Selecciona el tipo de familia por cara/octogonal. Luego selecciona masivamente luminarias o familias base y proyecta hacia la siguiente cara superior visible en la vista 3D activa, incluyendo nativos y vínculos.",
            Left = 20,
            Top = 68,
            Width = 700,
            Height = 48,
            ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
        };

        System.Windows.Forms.Label lblFamilia = CrearLabel("Familia por cara:", 20, 132, 145);

        cmbFamiliaPorCara = new System.Windows.Forms.ComboBox()
        {
            Left = 170,
            Top = 129,
            Width = 540,
            Height = 24,
            DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown,
            AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend,
            AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        };

        btnRecargarFamilias = CrearBoton(
            "RECARGAR FAMILIAS",
            20,
            170,
            190,
            System.Drawing.Color.FromArgb(90, 90, 90));

        btnRecargarFamilias.Click += (s, e) => SolicitarCargaInicial();

        System.Windows.Forms.Label lblTitulo02 = CrearTitulo("02. PARÁMETROS DE PROYECCIÓN", 20, 220, 700);

        System.Windows.Forms.Label lblDesfase = CrearLabel("Desfase sobre cara (m):", 20, 256, 165);

        nudDesfaseSobreCaraM = new System.Windows.Forms.NumericUpDown()
        {
            Left = 190,
            Top = 253,
            Width = 85,
            Height = 24,
            DecimalPlaces = 3,
            Increment = 0.010M,
            Minimum = -2,
            Maximum = 5,
            Value = 0.000M
        };

        System.Windows.Forms.Label lblAltura = CrearLabel("Altura máx. búsqueda (m):", 320, 256, 180);

        nudAlturaMaximaBusquedaM = new System.Windows.Forms.NumericUpDown()
        {
            Left = 510,
            Top = 253,
            Width = 85,
            Height = 24,
            DecimalPlaces = 2,
            Increment = 0.50M,
            Minimum = 0.10M,
            Maximum = 50,
            Value = 6.00M
        };

        System.Windows.Forms.Label lblSeparacion = CrearLabel("Separación inicio rayo (m):", 20, 292, 165);

        nudSeparacionInicioM = new System.Windows.Forms.NumericUpDown()
        {
            Left = 190,
            Top = 289,
            Width = 85,
            Height = 24,
            DecimalPlaces = 3,
            Increment = 0.010M,
            Minimum = 0.001M,
            Maximum = 1,
            Value = 0.050M
        };

        chkIgnorarAnfitrion = new System.Windows.Forms.CheckBox()
        {
            Text = "Ignorar anfitrión original de cada familia seleccionada",
            Left = 20,
            Top = 330,
            Width = 390,
            Height = 24,
            Checked = true
        };

        chkOrientacionOriginal = new System.Windows.Forms.CheckBox()
        {
            Text = "Usar orientación de la familia original",
            Left = 430,
            Top = 330,
            Width = 280,
            Height = 24,
            Checked = true
        };

        chkSeleccionarCreadas = new System.Windows.Forms.CheckBox()
        {
            Text = "Seleccionar familias creadas al terminar",
            Left = 20,
            Top = 358,
            Width = 330,
            Height = 24,
            Checked = true
        };

        chkCrearTuberiaFlexible = new System.Windows.Forms.CheckBox()
        {
            Text = "Crear tubería flexible",
            Left = 380,
            Top = 358,
            Width = 250,
            Height = 24,
            Checked = false
        };

        System.Windows.Forms.Label lblTitulo03 = CrearTitulo("03. SELECCIÓN DE ELEMENTOS BASE", 20, 405, 700);

        btnSeleccionarBases = CrearBoton(
            "SELECCIONAR ELEMENTOS",
            20,
            435,
            220,
            System.Drawing.Color.FromArgb(90, 90, 90));

        btnSeleccionarBases.Click += (s, e) => EjecutarSeleccionBases();

        lblBasesSeleccionadas = new System.Windows.Forms.Label()
        {
            Text = "Elementos base: no seleccionados.",
            Left = 260,
            Top = 440,
            Width = 450,
            Height = 38,
            ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
        };

        System.Windows.Forms.Label lblTitulo04 = CrearTitulo("04. FLUJO", 20, 500, 700);

        System.Windows.Forms.Label lblNota = new System.Windows.Forms.Label()
        {
            Text = "Flujo: selecciona las luminarias/familias base → PROYECTAR. El handler lanza un rayo vertical hacia arriba desde cada origen y busca caras nativas o de vínculos visibles en la vista 3D activa. Si activas tubería flexible, conecta cada familia seleccionada con su familia proyectada.",
            Left = 20,
            Top = 530,
            Width = 700,
            Height = 40,
            ForeColor = System.Drawing.Color.FromArgb(90, 90, 90)
        };

        System.Windows.Forms.Label lblResultado = CrearTitulo("05. RESULTADO", 20, 585, 700);

        txtResultado = new System.Windows.Forms.RichTextBox()
        {
            Left = 20,
            Top = 615,
            Width = 690,
            Height = 60,
            ReadOnly = true,
            BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
            BackColor = System.Drawing.Color.White,
            Font = new System.Drawing.Font("Consolas", 8.5F),
            WordWrap = false,
            ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        };

        btnProyectar = CrearBoton(
            "PROYECTAR EN CARA SUPERIOR",
            235,
            690,
            310,
            System.Drawing.Color.FromArgb(0, 120, 215));

        btnProyectar.Height = 42;
        btnProyectar.Click += (s, e) => EjecutarProyeccion();

        this.Controls.Add(lblAutor);
        this.Controls.Add(lblTitulo);
        this.Controls.Add(lblInfo);
        this.Controls.Add(lblFamilia);
        this.Controls.Add(cmbFamiliaPorCara);
        this.Controls.Add(btnRecargarFamilias);
        this.Controls.Add(lblTitulo02);
        this.Controls.Add(lblDesfase);
        this.Controls.Add(nudDesfaseSobreCaraM);
        this.Controls.Add(lblAltura);
        this.Controls.Add(nudAlturaMaximaBusquedaM);
        this.Controls.Add(lblSeparacion);
        this.Controls.Add(nudSeparacionInicioM);
        this.Controls.Add(chkIgnorarAnfitrion);
        this.Controls.Add(chkOrientacionOriginal);
        this.Controls.Add(chkSeleccionarCreadas);
        this.Controls.Add(chkCrearTuberiaFlexible);
        this.Controls.Add(lblTitulo03);
        this.Controls.Add(btnSeleccionarBases);
        this.Controls.Add(lblBasesSeleccionadas);
        this.Controls.Add(lblTitulo04);
        this.Controls.Add(lblNota);
        this.Controls.Add(lblResultado);
        this.Controls.Add(txtResultado);
        this.Controls.Add(btnProyectar);

        CargarConfiguracion();
        MostrarResultado("Carga las familias, selecciona elementos base y luego proyecta en cara superior. Activa Crear tubería flexible si quieres conectar cada par.");
    }

    private System.Windows.Forms.Label CrearTitulo(string texto, int left, int top, int width)
    {
        return new System.Windows.Forms.Label()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 22,
            Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
            ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
        };
    }

    private System.Windows.Forms.Label CrearLabel(string texto, int left, int top, int width)
    {
        return new System.Windows.Forms.Label()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 22,
            ForeColor = System.Drawing.Color.FromArgb(60, 60, 60)
        };
    }

    private System.Windows.Forms.Button CrearBoton(
        string texto,
        int left,
        int top,
        int width,
        System.Drawing.Color color)
    {
        System.Windows.Forms.Button boton = new System.Windows.Forms.Button()
        {
            Text = texto,
            Left = left,
            Top = top,
            Width = width,
            Height = 32,
            BackColor = color,
            ForeColor = System.Drawing.Color.White,
            FlatStyle = System.Windows.Forms.FlatStyle.Flat,
            Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
            Cursor = System.Windows.Forms.Cursors.Hand
        };

        boton.FlatAppearance.BorderSize = 0;
        boton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(
            System.Math.Max(color.R - 15, 0),
            System.Math.Max(color.G - 15, 0),
            System.Math.Max(color.B - 15, 0));

        return boton;
    }

    public void SolicitarCargaInicial()
    {
        Ejecutar(global::MYG_Addin.EleProyectarOctogonales55Request.CargarDatos);
    }

    private void EjecutarSeleccionBases()
    {
        MostrarResultado("Selecciona masivamente las luminarias/familias base. Finaliza la selección para guardar sus puntos de origen.");
        Ejecutar(global::MYG_Addin.EleProyectarOctogonales55Request.SeleccionarBases);
    }

    private void EjecutarProyeccion()
    {
        global::MYG_Addin.EleProyectarOctogonales55TipoInfo tipo =
            cmbFamiliaPorCara.SelectedItem as global::MYG_Addin.EleProyectarOctogonales55TipoInfo;

        if (tipo == null || tipo.Id == null ||
            tipo.Id == Autodesk.Revit.DB.ElementId.InvalidElementId)
        {
            MostrarResultado("Selecciona una familia por cara/octogonal válida.");
            return;
        }

        GuardarConfiguracion();

        _handler.TipoFamiliaId = tipo.Id;
        _handler.DesfaseSobreCaraM = (double)nudDesfaseSobreCaraM.Value;
        _handler.AlturaMaximaBusquedaM = (double)nudAlturaMaximaBusquedaM.Value;
        _handler.SeparacionInicioRayoM = (double)nudSeparacionInicioM.Value;
        _handler.IgnorarAnfitrionOriginal = chkIgnorarAnfitrion.Checked;
        _handler.UsarOrientacionOriginal = chkOrientacionOriginal.Checked;
        _handler.SeleccionarCreadas = chkSeleccionarCreadas.Checked;
        _handler.CrearTuberiaFlexible = chkCrearTuberiaFlexible.Checked;

        MostrarResultado("Proyectando elementos base seleccionados hacia caras superiores visibles en la vista activa. Tubería flexible: " + (chkCrearTuberiaFlexible.Checked ? "Sí" : "No"));
        Ejecutar(global::MYG_Addin.EleProyectarOctogonales55Request.ProyectarFamilias);
    }

    private void Ejecutar(global::MYG_Addin.EleProyectarOctogonales55Request request)
    {
        if (_handler == null)
        {
            MostrarResultado("No se pudo acceder al handler de proyección.");
            return;
        }

        _handler.Request = request;

        if (_externalEvent == null)
        {
            MostrarResultado("No se pudo crear el evento externo de Revit.");
            return;
        }

        _externalEvent.Raise();
    }

    public void SetTiposFamilia(System.Collections.Generic.List<global::MYG_Addin.EleProyectarOctogonales55TipoInfo> tipos)
    {
        if (cmbFamiliaPorCara == null || cmbFamiliaPorCara.IsDisposed)
            return;

        if (this.InvokeRequired)
        {
            this.BeginInvoke(new System.Action(() => SetTiposFamilia(tipos)));
            return;
        }

        long seleccionadoActual = -1;

        global::MYG_Addin.EleProyectarOctogonales55TipoInfo actual =
            cmbFamiliaPorCara.SelectedItem as global::MYG_Addin.EleProyectarOctogonales55TipoInfo;

        if (actual != null && actual.Id != null)
            seleccionadoActual = actual.Id.Value;

        cmbFamiliaPorCara.Items.Clear();

        if (tipos != null)
        {
            foreach (global::MYG_Addin.EleProyectarOctogonales55TipoInfo t in tipos)
            {
                if (t != null)
                    cmbFamiliaPorCara.Items.Add(t);
            }
        }

        if (cmbFamiliaPorCara.Items.Count > 0)
        {
            int index = 0;
            bool encontrado = false;

            if (seleccionadoActual > 0)
            {
                for (int i = 0; i < cmbFamiliaPorCara.Items.Count; i++)
                {
                    global::MYG_Addin.EleProyectarOctogonales55TipoInfo item =
                        cmbFamiliaPorCara.Items[i] as global::MYG_Addin.EleProyectarOctogonales55TipoInfo;

                    if (item != null && item.Id != null && item.Id.Value == seleccionadoActual)
                    {
                        index = i;
                        encontrado = true;
                        break;
                    }
                }
            }

            if (!encontrado && _familiaIdGuardada > 0)
            {
                for (int i = 0; i < cmbFamiliaPorCara.Items.Count; i++)
                {
                    global::MYG_Addin.EleProyectarOctogonales55TipoInfo item =
                        cmbFamiliaPorCara.Items[i] as global::MYG_Addin.EleProyectarOctogonales55TipoInfo;

                    if (item != null && item.Id != null && item.Id.Value == _familiaIdGuardada)
                    {
                        index = i;
                        encontrado = true;
                        break;
                    }
                }
            }

            if (!encontrado && !string.IsNullOrWhiteSpace(_familiaTextoGuardada))
            {
                for (int i = 0; i < cmbFamiliaPorCara.Items.Count; i++)
                {
                    object obj = cmbFamiliaPorCara.Items[i];
                    string texto = obj == null ? "" : obj.ToString();

                    if (string.Equals(texto, _familiaTextoGuardada, System.StringComparison.OrdinalIgnoreCase))
                    {
                        index = i;
                        encontrado = true;
                        break;
                    }
                }
            }

            cmbFamiliaPorCara.SelectedIndex = index;
        }

        MostrarResultado("Familias por cara cargadas: " + cmbFamiliaPorCara.Items.Count);
    }

    public void SetElementosBaseSeleccionados(System.Collections.Generic.List<Autodesk.Revit.DB.Element> elementos)
    {
        if (this.InvokeRequired)
        {
            this.BeginInvoke(new System.Action(() => SetElementosBaseSeleccionados(elementos)));
            return;
        }

        int cantidad = elementos == null ? 0 : elementos.Count;

        if (lblBasesSeleccionadas != null && !lblBasesSeleccionadas.IsDisposed)
            lblBasesSeleccionadas.Text = cantidad <= 0
                ? "Elementos base: no seleccionados."
                : "Elementos base seleccionados: " + cantidad + ". Presiona PROYECTAR EN CARA SUPERIOR.";

        MostrarResultado(cantidad <= 0
            ? "No se seleccionaron elementos base."
            : "Elementos base seleccionados: " + cantidad + ". Ahora presiona PROYECTAR EN CARA SUPERIOR.");
    }

    public void MostrarResultado(string texto)
    {
        if (txtResultado == null || txtResultado.IsDisposed)
            return;

        if (this.InvokeRequired)
        {
            this.BeginInvoke(new System.Action(() => MostrarResultado(texto)));
            return;
        }

        txtResultado.Clear();
        txtResultado.SelectionColor = System.Drawing.Color.FromArgb(50, 50, 50);
        txtResultado.AppendText(texto ?? "");
        txtResultado.SelectionStart = 0;
        txtResultado.ScrollToCaret();
    }

    public void AgregarResultado(string texto)
    {
        if (txtResultado == null || txtResultado.IsDisposed)
            return;

        if (this.InvokeRequired)
        {
            this.BeginInvoke(new System.Action(() => AgregarResultado(texto)));
            return;
        }

        if (txtResultado.TextLength > 0)
            txtResultado.AppendText(System.Environment.NewLine);

        txtResultado.SelectionColor = System.Drawing.Color.FromArgb(50, 50, 50);
        txtResultado.AppendText(texto ?? "");
        txtResultado.SelectionStart = txtResultado.TextLength;
        txtResultado.ScrollToCaret();
    }

    private void CargarConfiguracion()
    {
        if (_configuracionYaCargada)
            return;

        _configuracionYaCargada = true;

        try
        {
            string ruta = ObtenerRutaConfig();

            if (!System.IO.File.Exists(ruta))
                return;

            string[] lineas = System.IO.File.ReadAllLines(ruta);

            foreach (string linea in lineas)
            {
                if (string.IsNullOrWhiteSpace(linea) || !linea.Contains("="))
                    continue;

                int idx = linea.IndexOf('=');
                string clave = linea.Substring(0, idx).Trim();
                string valor = linea.Substring(idx + 1).Trim();

                if (clave == "FamiliaId")
                    long.TryParse(valor, out _familiaIdGuardada);
                else if (clave == "FamiliaTexto")
                    _familiaTextoGuardada = valor;
                else if (clave == "DesfaseSobreCaraM")
                    SetNumeric(nudDesfaseSobreCaraM, valor);
                else if (clave == "AlturaMaximaBusquedaM")
                    SetNumeric(nudAlturaMaximaBusquedaM, valor);
                else if (clave == "SeparacionInicioRayoM")
                    SetNumeric(nudSeparacionInicioM, valor);
                else if (clave == "IgnorarAnfitrion")
                    chkIgnorarAnfitrion.Checked = LeerBool(valor, true);
                else if (clave == "OrientacionOriginal")
                    chkOrientacionOriginal.Checked = LeerBool(valor, true);
                else if (clave == "SeleccionarCreadas")
                    chkSeleccionarCreadas.Checked = LeerBool(valor, true);
                else if (clave == "CrearTuberiaFlexible")
                    chkCrearTuberiaFlexible.Checked = LeerBool(valor, false);
            }
        }
        catch
        {
        }
    }

    private void GuardarConfiguracion()
    {
        try
        {
            string ruta = ObtenerRutaConfig();
            string carpeta = System.IO.Path.GetDirectoryName(ruta);

            if (!System.IO.Directory.Exists(carpeta))
                System.IO.Directory.CreateDirectory(carpeta);

            long id = -1;
            string texto = "";

            global::MYG_Addin.EleProyectarOctogonales55TipoInfo tipo =
                cmbFamiliaPorCara.SelectedItem as global::MYG_Addin.EleProyectarOctogonales55TipoInfo;

            if (tipo != null)
            {
                if (tipo.Id != null)
                    id = tipo.Id.Value;

                texto = tipo.ToString();
            }
            else if (cmbFamiliaPorCara != null && cmbFamiliaPorCara.Text != null)
            {
                texto = cmbFamiliaPorCara.Text.Trim();
            }

            System.Collections.Generic.List<string> lineas = new System.Collections.Generic.List<string>();
            lineas.Add("FamiliaId=" + id);
            lineas.Add("FamiliaTexto=" + texto);
            lineas.Add("DesfaseSobreCaraM=" + nudDesfaseSobreCaraM.Value.ToString(System.Globalization.CultureInfo.InvariantCulture));
            lineas.Add("AlturaMaximaBusquedaM=" + nudAlturaMaximaBusquedaM.Value.ToString(System.Globalization.CultureInfo.InvariantCulture));
            lineas.Add("SeparacionInicioRayoM=" + nudSeparacionInicioM.Value.ToString(System.Globalization.CultureInfo.InvariantCulture));
            lineas.Add("IgnorarAnfitrion=" + chkIgnorarAnfitrion.Checked);
            lineas.Add("OrientacionOriginal=" + chkOrientacionOriginal.Checked);
            lineas.Add("SeleccionarCreadas=" + chkSeleccionarCreadas.Checked);
            lineas.Add("CrearTuberiaFlexible=" + chkCrearTuberiaFlexible.Checked);

            System.IO.File.WriteAllLines(ruta, lineas.ToArray());
        }
        catch
        {
        }
    }

    private string ObtenerRutaConfig()
    {
        string appData = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData);
        return System.IO.Path.Combine(appData, "MYG_Addin", ArchivoConfigNombre);
    }

    private void SetNumeric(System.Windows.Forms.NumericUpDown nud, string valor)
    {
        if (nud == null)
            return;

        decimal d;

        if (!decimal.TryParse(valor, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out d))
            return;

        if (d < nud.Minimum)
            d = nud.Minimum;

        if (d > nud.Maximum)
            d = nud.Maximum;

        nud.Value = d;
    }

    private bool LeerBool(string valor, bool def)
    {
        bool b;

        if (bool.TryParse(valor, out b))
            return b;

        if (valor == "1")
            return true;

        if (valor == "0")
            return false;

        return def;
    }
}
