﻿/*
=========================================================
MYG - Tubos flexibles entre elementos
Panel 5 - Botón 5.5
V14 - diámetro flexible + arranque recto normal + radio giro U automático por diámetro
=========================================================
*/

using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;

namespace MYG_Addin
{
    public enum EleTubosFlexibles55Request
    {
        None,
        CargarDatos,
        GenerarFlexible
    }

    public class EleTubosFlexibles55TipoInfo
    {
        public ElementId Id { get; set; }
        public string Nombre { get; set; }
        public string Clase { get; set; }
        public bool EsAutomatico { get; set; }
        public bool EsPipe { get; set; }
        public bool EsDuct { get; set; }

        public override string ToString()
        {
            return string.IsNullOrWhiteSpace(Nombre) ? "(Sin nombre)" : Nombre;
        }
    }

    public class EjecutarEleTubosFlexibles55Handler : IExternalEventHandler
    {
        private const string MarcaGenerado = "MYG_TUBOS_FLEXIBLES_55";
        private const double Epsilon = 1.0e-9;

        public UIDocument UiDoc { get; set; }
        public EleTubosFlexibles55Form Form { get; set; }
        public EleTubosFlexibles55Request Request { get; set; } = EleTubosFlexibles55Request.None;

        public List<EleTubosFlexibles55TipoInfo> TiposDisponibles { get; private set; } =
            new List<EleTubosFlexibles55TipoInfo>();

        public EleTubosFlexibles55TipoInfo TipoSeleccionado { get; set; }
        public double DiametroFlexibleMm { get; set; } = 20.0;
        public double LongitudRectaSalidaM { get; set; } = 0.20;
        private double _ultimoRadioGiroAutomaticoM = 0.0;
        public bool PreferirConectoresLibres { get; set; } = true;
        public bool SeleccionarResultado { get; set; } = true;

        public string GetName()
        {
            return "MYG - Tubos flexibles entre elementos";
        }

        public void Execute(UIApplication app)
        {
            try
            {
                UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

                if (uidoc == null || uidoc.Document == null)
                    return;

                Document doc = uidoc.Document;

                if (Request == EleTubosFlexibles55Request.CargarDatos)
                {
                    CargarTiposFlexibles(doc);

                    if (Form != null && !Form.IsDisposed)
                        Form.SetTiposFlexibles(TiposDisponibles);
                }
                else if (Request == EleTubosFlexibles55Request.GenerarFlexible)
                {
                    EjecutarGenerarFlexible(uidoc, doc);
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
            }
            catch (Exception ex)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("MYG - Error: " + ex.Message);
            }
            finally
            {
                Request = EleTubosFlexibles55Request.None;
            }
        }

        public void CargarTiposFlexibles(Document doc)
        {
            TiposDisponibles.Clear();

            TiposDisponibles.Add(new EleTubosFlexibles55TipoInfo
            {
                Id = ElementId.InvalidElementId,
                Nombre = "Automático - según conectores",
                Clase = "AUTO",
                EsAutomatico = true,
                EsPipe = false,
                EsDuct = false
            });

            if (doc == null)
                return;

            try
            {
                List<FlexPipeType> tiposPipe = new FilteredElementCollector(doc)
                    .OfClass(typeof(FlexPipeType))
                    .Cast<FlexPipeType>()
                    .OrderBy(x => x.Name)
                    .ToList();

                foreach (FlexPipeType t in tiposPipe)
                {
                    if (t == null)
                        continue;

                    TiposDisponibles.Add(new EleTubosFlexibles55TipoInfo
                    {
                        Id = t.Id,
                        Nombre = "Flex Pipe: " + t.Name + "  [Id " + t.Id.Value + "]",
                        Clase = "PIPE",
                        EsAutomatico = false,
                        EsPipe = true,
                        EsDuct = false
                    });
                }
            }
            catch
            {
            }

            try
            {
                List<FlexDuctType> tiposDuct = new FilteredElementCollector(doc)
                    .OfClass(typeof(FlexDuctType))
                    .Cast<FlexDuctType>()
                    .OrderBy(x => x.Name)
                    .ToList();

                foreach (FlexDuctType t in tiposDuct)
                {
                    if (t == null)
                        continue;

                    TiposDisponibles.Add(new EleTubosFlexibles55TipoInfo
                    {
                        Id = t.Id,
                        Nombre = "Flex Duct: " + t.Name + "  [Id " + t.Id.Value + "]",
                        Clase = "DUCT",
                        EsAutomatico = false,
                        EsPipe = false,
                        EsDuct = true
                    });
                }
            }
            catch
            {
            }
        }

        private void EjecutarGenerarFlexible(UIDocument uidoc, Document doc)
        {
            if (TipoSeleccionado == null)
            {
                CargarTiposFlexibles(doc);
                TipoSeleccionado = TiposDisponibles.FirstOrDefault();
            }

            if (TiposDisponibles.Count == 0)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.MostrarResultado("No se encontraron tipos FlexPipe/FlexDuct en el proyecto.");

                return;
            }

            if (Form != null && !Form.IsDisposed)
            {
                Form.MostrarResultado("Flujo de tubos flexibles activo.");
                Form.AgregarResultado("Selecciona elemento 1 y luego elemento 2. Al seleccionar el segundo se creará el flexible.");
                Form.AgregarResultado("Diámetro flexible: " + DiametroFlexibleMm.ToString("0.#") + " mm");
                Form.AgregarResultado("Tramo recto normal al conector: " + LongitudRectaSalidaM.ToString("0.###") + " m");
                Form.AgregarResultado("Radio giro U: automático según diámetro.");
                Form.AgregarResultado("Presiona ESC para terminar.");
            }

            List<ElementId> creados = new List<ElementId>();
            int paresCreados = 0;
            int paresFallidos = 0;

            while (true)
            {
                Element e1 = null;
                Element e2 = null;

                try
                {
                    e1 = PickElementoConConectores(uidoc, doc, "Selecciona el ELEMENTO 1 para tubo flexible. ESC para terminar.");

                    if (e1 == null)
                        continue;

                    if (Form != null && !Form.IsDisposed)
                    {
                        Form.MostrarResultado("Elemento 1 seleccionado: Id " + e1.Id.Value);
                        Form.AgregarResultado("Ahora selecciona el ELEMENTO 2.");
                    }

                    e2 = PickElementoConConectores(uidoc, doc, "Selecciona el ELEMENTO 2. Al seleccionarlo se creará el tubo flexible.");

                    if (e2 == null)
                        continue;
                }
                catch (Autodesk.Revit.Exceptions.OperationCanceledException)
                {
                    break;
                }

                ResultadoFlexible55 resultado = CrearFlexibleEntreElementos(doc, e1, e2);

                if (resultado.Ok)
                {
                    paresCreados++;

                    if (resultado.IdCreado != null && resultado.IdCreado != ElementId.InvalidElementId)
                        creados.Add(resultado.IdCreado);

                    if (Form != null && !Form.IsDisposed)
                    {
                        Form.MostrarResultado("Tubo flexible creado correctamente. Puedes seguir seleccionando otro par.");
                        Form.AgregarResultado("Pares creados: " + paresCreados);
                        Form.AgregarResultado("Tipo usado: " + resultado.TipoUsado);
                        Form.AgregarResultado("Diámetro: " + DiametroFlexibleMm.ToString("0.#") + " mm");
                        Form.AgregarResultado("Conectores: " + resultado.ResumenConectores);
                    }
                }
                else
                {
                    paresFallidos++;

                    if (Form != null && !Form.IsDisposed)
                    {
                        Form.MostrarResultado("No se pudo crear el tubo flexible para este par.");
                        Form.AgregarResultado(resultado.Error ?? "Error no especificado.");
                        Form.AgregarResultado("Pares creados: " + paresCreados);
                        Form.AgregarResultado("Pares fallidos: " + paresFallidos);
                    }
                }
            }

            if (SeleccionarResultado && creados.Count > 0)
                uidoc.Selection.SetElementIds(creados);

            if (Form != null && !Form.IsDisposed)
            {
                Form.MostrarResultado("Flujo flexible terminado.");
                Form.AgregarResultado("Pares creados: " + paresCreados);
                Form.AgregarResultado("Pares fallidos: " + paresFallidos);
                Form.AgregarResultado("Elementos flexibles creados: " + creados.Count);
            }
        }

        private Element PickElementoConConectores(UIDocument uidoc, Document doc, string mensaje)
        {
            Reference r = uidoc.Selection.PickObject(
                ObjectType.Element,
                new FiltroElementoConConectoresFlexibles(),
                mensaje);

            if (r == null)
                return null;

            return doc.GetElement(r.ElementId);
        }

        private ResultadoFlexible55 CrearFlexibleEntreElementos(Document doc, Element e1, Element e2)
        {
            ResultadoFlexible55 resultado = new ResultadoFlexible55();

            if (doc == null || e1 == null || e2 == null)
            {
                resultado.Error = "No se encontraron elementos válidos.";
                return resultado;
            }

            List<Connector> conectores1 = ObtenerConectores(e1);
            List<Connector> conectores2 = ObtenerConectores(e2);

            if (conectores1.Count == 0 || conectores2.Count == 0)
            {
                resultado.Error = "Uno de los elementos no tiene conectores MEP válidos.";
                return resultado;
            }

            ParConectoresFlexible55 par = BuscarMejorParCompatible(conectores1, conectores2, TipoSeleccionado);

            if (par == null || par.A == null || par.B == null)
            {
                resultado.Error = "No se encontró un par de conectores compatible para FlexPipe o FlexDuct.";
                return resultado;
            }

            EleTubosFlexibles55TipoInfo tipoUso = ResolverTipoParaPar(doc, par, TipoSeleccionado);

            if (tipoUso == null)
            {
                resultado.Error = "No se encontró un tipo flexible compatible con el dominio de los conectores.";
                return resultado;
            }

            using (Transaction t = new Transaction(doc, "MYG - Crear tubo flexible"))
            {
                try
                {
                    t.Start();

                    FailureHandlingOptions failureOptions = t.GetFailureHandlingOptions();
                    failureOptions.SetFailuresPreprocessor(new Flexibles55FailurePreprocessor());
                    t.SetFailureHandlingOptions(failureOptions);

                    Element nuevo = null;

                    XYZ dirA = ObtenerDireccionNormalSalida(par.A, e1, par.B);
                    XYZ dirB = ObtenerDireccionNormalSalida(par.B, e2, par.A);
                    List<XYZ> puntosRuta = CalcularPuntosRutaFlexible(par.A, par.B, dirA, dirB);

                    if (puntosRuta == null || puntosRuta.Count < 2)
                    {
                        resultado.Error = "No se pudo calcular una ruta flexible válida.";
                        t.RollBack();
                        return resultado;
                    }

                    if (tipoUso.EsPipe)
                    {
                        FlexPipeType tipoPipe = doc.GetElement(tipoUso.Id) as FlexPipeType;

                        if (tipoPipe == null)
                        {
                            resultado.Error = "El tipo FlexPipe seleccionado no es válido.";
                            t.RollBack();
                            return resultado;
                        }

                        FlexPipe fp = doc.Create.NewFlexPipe(par.A, puntosRuta, tipoPipe);
                        nuevo = fp as Element;
                        AplicarTangentesFlexible(nuevo, dirA, -dirB);
                    }
                    else if (tipoUso.EsDuct)
                    {
                        FlexDuctType tipoDuct = doc.GetElement(tipoUso.Id) as FlexDuctType;

                        if (tipoDuct == null)
                        {
                            resultado.Error = "El tipo FlexDuct seleccionado no es válido.";
                            t.RollBack();
                            return resultado;
                        }

                        FlexDuct fd = doc.Create.NewFlexDuct(par.A, puntosRuta, tipoDuct);
                        nuevo = fd as Element;
                        AplicarTangentesFlexible(nuevo, dirA, -dirB);
                    }

                    if (nuevo == null)
                    {
                        resultado.Error = "Revit no devolvió un elemento flexible creado.";
                        t.RollBack();
                        return resultado;
                    }

                    AplicarDiametroFlexible(nuevo, DiametroFlexibleMm);
                    MarcarElemento(nuevo);
                    doc.Regenerate();

                    // V15:
                    // El overload con conector + puntos suele conectar solo el arranque.
                    // Para que TAB seleccione toda la red, se fuerzan y verifican AMBOS extremos
                    // después de aplicar diámetro/tangentes y después de regenerar el flexible.
                    doc.Regenerate();

                    int conexionesConfirmadas = ConectarAmbosExtremosFlexible(
                        doc,
                        nuevo,
                        par.A,
                        par.B);

                    doc.Regenerate();
                    t.Commit();

                    resultado.Ok = true;
                    resultado.IdCreado = nuevo.Id;
                    resultado.TipoUsado = tipoUso.Nombre;
                    resultado.ResumenConectores = "Id " + e1.Id.Value + " ↔ Id " + e2.Id.Value +
                        " | tramo recto " + LongitudRectaSalidaM.ToString("0.###") + " m" +
                        " | radio U automático " + _ultimoRadioGiroAutomaticoM.ToString("0.###") + " m" +
                        " | conexiones confirmadas " + conexionesConfirmadas + "/2";
                    return resultado;
                }
                catch (Exception ex)
                {
                    try
                    {
                        if (t.GetStatus() == TransactionStatus.Started)
                            t.RollBack();
                    }
                    catch
                    {
                    }

                    resultado.Error = ex.Message;
                    return resultado;
                }
            }
        }


        private List<XYZ> CalcularPuntosRutaFlexible(
            Connector conectorInicio,
            Connector conectorFin,
            XYZ dirInicio,
            XYZ dirFin)
        {
            List<XYZ> puntos = new List<XYZ>();

            if (conectorInicio == null || conectorFin == null)
                return puntos;

            XYZ p0 = ObtenerOrigenSeguro(conectorInicio);
            XYZ p1 = ObtenerOrigenSeguro(conectorFin);

            if (EsVectorCero(p0) || EsVectorCero(p1))
                return puntos;

            if (EsVectorCero(dirInicio))
                dirInicio = (p1 - p0);

            if (EsVectorCero(dirFin))
                dirFin = (p0 - p1);

            if (EsVectorCero(dirInicio) || EsVectorCero(dirFin))
                return puntos;

            dirInicio = dirInicio.Normalize();
            dirFin = dirFin.Normalize();

            double recta = UnitUtils.ConvertToInternalUnits(
                Math.Max(LongitudRectaSalidaM, 0.02),
                UnitTypeId.Meters);

            double diametro = UnitUtils.ConvertToInternalUnits(
                Math.Max(DiametroFlexibleMm, 1.0),
                UnitTypeId.Millimeters);

            // V14:
            // El radio de giro ya no se pide en la ventana. Se calcula automáticamente
            // desde el diámetro para que el flexible no se vea como una línea quebrada.
            // Criterio: radio base >= 18D y nunca menor que 0.25 m para vueltas en U.
            double radioU = Math.Max(
                diametro * 18.0,
                UnitUtils.ConvertToInternalUnits(0.25, UnitTypeId.Meters));

            // Si el flexible es grande, se permite una curva todavía más abierta.
            // Esto evita que un flexible de mayor diámetro tenga la misma curvatura que uno pequeño.
            radioU = Math.Max(
                radioU,
                UnitUtils.ConvertToInternalUnits(Math.Min(Math.Max(DiametroFlexibleMm / 1000.0 * 20.0, 0.25), 1.20), UnitTypeId.Meters));

            // El tramo recto también se protege por diámetro para que la curva no nazca pegada al conector.
            recta = Math.Max(recta, diametro * 5.0);

            double distancia = p0.DistanceTo(p1);

            if (distancia > Epsilon)
            {
                recta = Math.Min(recta, distancia * 0.30);

                // No permitir que el radio automático consuma casi toda la luz entre conectores.
                // Aun así, se mantiene como mínimo geométrico por diámetro si hay espacio.
                double radioMaxPorDistancia = distancia * 0.48;
                double radioMinPorDiametro = diametro * 10.0;

                if (radioU > radioMaxPorDistancia)
                    radioU = Math.Max(radioMinPorDiametro, radioMaxPorDistancia);
            }

            _ultimoRadioGiroAutomaticoM = UnitUtils.ConvertFromInternalUnits(radioU, UnitTypeId.Meters);

            XYZ lineaInicioFin = p1 - p0;

            if (EsVectorCero(lineaInicioFin))
                return puntos;

            lineaInicioFin = lineaInicioFin.Normalize();

            // Detecta el caso mostrado: el conector obliga a salir en dirección opuesta
            // al punto destino. En ese escenario se agregan puntos de control extra
            // para que la vuelta en U tenga mayor radio y no arranque con una curva cerrada.
            bool giroUInicio = dirInicio.DotProduct(lineaInicioFin) < -0.25;
            bool giroUFin = dirFin.DotProduct(-lineaInicioFin) < -0.25;

            XYZ salidaInicio = p0 + dirInicio * recta;
            XYZ salidaFin = p1 + dirFin * recta;

            // La lista de puntos pertenece al overload con conector inicial.
            // Por eso el primer tramo va desde conectorInicio hacia salidaInicio.
            AgregarPuntoRutaFlexible(puntos, salidaInicio);

            if (giroUInicio)
            {
                XYZ extInicio = salidaInicio + dirInicio * radioU;
                XYZ lateralInicio = ProyectarPerpendicularFlex55(salidaFin - extInicio, dirInicio);

                if (EsVectorCero(lateralInicio))
                    lateralInicio = ObtenerPerpendicularSeguroFlex55(dirInicio, lineaInicioFin);

                lateralInicio = lateralInicio.Normalize();

                AgregarPuntoRutaFlexible(puntos, extInicio);
                AgregarPuntoRutaFlexible(puntos, extInicio + lateralInicio * radioU);
            }

            XYZ vectorEntreSalidas = salidaFin - salidaInicio;

            if (!EsVectorCero(vectorEntreSalidas) && salidaInicio.DistanceTo(salidaFin) > diametro * 2.0)
            {
                XYZ ultimo = puntos.Count > 0 ? puntos[puntos.Count - 1] : salidaInicio;
                XYZ previoFin = salidaFin;

                if (giroUFin)
                {
                    XYZ extFin = salidaFin + dirFin * radioU;
                    XYZ lateralFin = ProyectarPerpendicularFlex55(ultimo - extFin, dirFin);

                    if (EsVectorCero(lateralFin))
                        lateralFin = ObtenerPerpendicularSeguroFlex55(dirFin, -lineaInicioFin);

                    lateralFin = lateralFin.Normalize();
                    previoFin = extFin + lateralFin * radioU;
                }

                XYZ mitad = (ultimo + previoFin) * 0.5;

                // Punto suave adicional para evitar que el spline intente ir recto
                // desde una normal hacia la otra cuando los conectores están muy separados.
                AgregarPuntoRutaFlexible(puntos, mitad);

                if (giroUFin)
                {
                    XYZ extFin = salidaFin + dirFin * radioU;
                    AgregarPuntoRutaFlexible(puntos, previoFin);
                    AgregarPuntoRutaFlexible(puntos, extFin);
                }
            }

            AgregarPuntoRutaFlexible(puntos, salidaFin);
            AgregarPuntoRutaFlexible(puntos, p1);

            return LimpiarPuntosFlexibles(puntos, Math.Max(diametro * 0.25, UnitUtils.ConvertToInternalUnits(2.0, UnitTypeId.Millimeters)));
        }

        private XYZ ProyectarPerpendicularFlex55(XYZ vector, XYZ eje)
        {
            if (EsVectorCero(vector) || EsVectorCero(eje))
                return XYZ.Zero;

            XYZ e = eje.Normalize();
            XYZ r = vector - e * vector.DotProduct(e);

            if (EsVectorCero(r))
                return XYZ.Zero;

            return r.Normalize();
        }

        private XYZ ObtenerPerpendicularSeguroFlex55(XYZ eje, XYZ referencia)
        {
            XYZ r = ProyectarPerpendicularFlex55(referencia, eje);

            if (!EsVectorCero(r))
                return r.Normalize();

            XYZ e = EsVectorCero(eje) ? XYZ.BasisZ : eje.Normalize();
            XYZ baseRef = Math.Abs(e.DotProduct(XYZ.BasisZ)) < 0.90 ? XYZ.BasisZ : XYZ.BasisX;
            XYZ p = e.CrossProduct(baseRef);

            if (EsVectorCero(p))
                p = e.CrossProduct(XYZ.BasisY);

            if (EsVectorCero(p))
                return XYZ.BasisX;

            return p.Normalize();
        }

        private void AgregarPuntoRutaFlexible(List<XYZ> puntos, XYZ p)
        {
            if (puntos == null || p == null || EsVectorCero(p))
                return;

            if (puntos.Count == 0 || puntos[puntos.Count - 1].DistanceTo(p) > UnitUtils.ConvertToInternalUnits(1.0, UnitTypeId.Millimeters))
                puntos.Add(p);
        }

        private List<XYZ> LimpiarPuntosFlexibles(List<XYZ> puntos, double tolerancia)
        {
            List<XYZ> salida = new List<XYZ>();

            if (puntos == null)
                return salida;

            foreach (XYZ p in puntos)
            {
                if (p == null || EsVectorCero(p))
                    continue;

                if (salida.Count == 0 || salida[salida.Count - 1].DistanceTo(p) > tolerancia)
                    salida.Add(p);
            }

            return salida;
        }

        private XYZ ObtenerDireccionNormalSalida(
            Connector conector,
            Element owner,
            Connector conectorOpuesto)
        {
            XYZ dir = XYZ.Zero;

            try
            {
                if (conector != null && conector.CoordinateSystem != null)
                    dir = conector.CoordinateSystem.BasisZ;
            }
            catch
            {
            }

            if (EsVectorCero(dir))
            {
                XYZ p = ObtenerOrigenSeguro(conector);
                XYZ pOtro = ObtenerOrigenSeguro(conectorOpuesto);

                if (!EsVectorCero(p) && !EsVectorCero(pOtro))
                    dir = pOtro - p;
            }

            if (EsVectorCero(dir))
                dir = XYZ.BasisZ;

            dir = dir.Normalize();

            XYZ origen = ObtenerOrigenSeguro(conector);
            XYZ centro = ObtenerCentroElemento(owner);
            XYZ desdeCentro = origen - centro;

            if (!EsVectorCero(desdeCentro))
            {
                desdeCentro = desdeCentro.Normalize();

                // El conector físico debería salir hacia afuera del equipo.
                // Si BasisZ apunta hacia el centro de la familia, lo invertimos.
                if (dir.DotProduct(desdeCentro) < 0.0)
                    dir = -dir;
            }
            else
            {
                XYZ pOtro = ObtenerOrigenSeguro(conectorOpuesto);

                if (!EsVectorCero(pOtro))
                {
                    XYZ haciaOtro = pOtro - origen;

                    if (!EsVectorCero(haciaOtro) && dir.DotProduct(haciaOtro.Normalize()) < -0.85)
                        dir = -dir;
                }
            }

            return dir.Normalize();
        }

        private XYZ ObtenerCentroElemento(Element e)
        {
            if (e == null)
                return XYZ.Zero;

            try
            {
                BoundingBoxXYZ bb = e.get_BoundingBox(null);

                if (bb != null)
                    return (bb.Min + bb.Max) * 0.5;
            }
            catch
            {
            }

            try
            {
                LocationPoint lp = e.Location as LocationPoint;

                if (lp != null)
                    return lp.Point;
            }
            catch
            {
            }

            return XYZ.Zero;
        }

        private void AplicarTangentesFlexible(Element flexible, XYZ tangenteInicio, XYZ tangenteFin)
        {
            if (flexible == null)
                return;

            try
            {
                if (!EsVectorCero(tangenteInicio))
                {
                    System.Reflection.PropertyInfo pStart = flexible.GetType().GetProperty("StartTangent");

                    if (pStart != null && pStart.CanWrite)
                        pStart.SetValue(flexible, tangenteInicio.Normalize(), null);
                }
            }
            catch
            {
            }

            try
            {
                if (!EsVectorCero(tangenteFin))
                {
                    System.Reflection.PropertyInfo pEnd = flexible.GetType().GetProperty("EndTangent");

                    if (pEnd != null && pEnd.CanWrite)
                        pEnd.SetValue(flexible, tangenteFin.Normalize(), null);
                }
            }
            catch
            {
            }
        }

        private void AplicarDiametroFlexible(Element flexible, double diametroMm)
        {
            if (flexible == null)
                return;

            double diametro = UnitUtils.ConvertToInternalUnits(
                Math.Max(diametroMm, 1.0),
                UnitTypeId.Millimeters);

            try
            {
                System.Reflection.PropertyInfo pDiam = flexible.GetType().GetProperty("Diameter");

                if (pDiam != null && pDiam.CanWrite)
                    pDiam.SetValue(flexible, diametro, null);
            }
            catch
            {
            }

            string[] nombres = new string[]
            {
                "Diámetro",
                "Diametro",
                "Diameter",
                "Diámetro nominal",
                "Nominal Diameter",
                "D"
            };

            foreach (string nombre in nombres)
            {
                try
                {
                    Parameter p = flexible.LookupParameter(nombre);

                    if (p != null && !p.IsReadOnly && p.StorageType == StorageType.Double)
                        p.Set(diametro);
                }
                catch
                {
                }
            }

            string[] builtIns = new string[]
            {
                "RBS_PIPE_DIAMETER_PARAM",
                "RBS_CURVE_DIAMETER_PARAM",
                "RBS_FLEX_PIPE_DIAMETER_PARAM",
                "RBS_FLEX_DUCT_DIAMETER_PARAM"
            };

            foreach (string bipName in builtIns)
            {
                try
                {
                    BuiltInParameter bip;

                    if (!Enum.TryParse<BuiltInParameter>(bipName, out bip))
                        continue;

                    Parameter p = flexible.get_Parameter(bip);

                    if (p != null && !p.IsReadOnly && p.StorageType == StorageType.Double)
                        p.Set(diametro);
                }
                catch
                {
                }
            }
        }

        private int ConectarAmbosExtremosFlexible(
            Document doc,
            Element flexible,
            Connector conectorInicio,
            Connector conectorFin)
        {
            int confirmadas = 0;

            if (doc == null || flexible == null || conectorInicio == null || conectorFin == null)
                return confirmadas;

            try
            {
                XYZ pInicio = ObtenerOrigenSeguro(conectorInicio);
                XYZ pFin = ObtenerOrigenSeguro(conectorFin);

                List<Connector> conectoresFlex = ObtenerConectores(flexible);

                if (conectoresFlex == null || conectoresFlex.Count == 0)
                    return confirmadas;

                Connector flexInicio = ObtenerConectorMasCercanoEnLista(conectoresFlex, pInicio, null);
                Connector flexFin = ObtenerConectorMasCercanoEnLista(conectoresFlex, pFin, flexInicio);

                // En algunos flexibles Revit devuelve conectores muy próximos o reordena conectores.
                // Si por cercanía tomó el mismo conector, se vuelve a resolver usando el más lejano al inicio.
                if (flexFin == null || object.ReferenceEquals(flexInicio, flexFin))
                    flexFin = ObtenerConectorMasLejanoEnLista(conectoresFlex, pInicio, flexInicio);

                if (flexInicio != null)
                {
                    if (ConectarDosConectoresRobusto(flexInicio, conectorInicio))
                        confirmadas++;

                    try { doc.Regenerate(); } catch { }
                }

                if (flexFin != null)
                {
                    if (ConectarDosConectoresRobusto(flexFin, conectorFin))
                        confirmadas++;

                    try { doc.Regenerate(); } catch { }
                }
            }
            catch
            {
            }

            return confirmadas;
        }

        private bool ConectarDosConectoresRobusto(Connector a, Connector b)
        {
            if (a == null || b == null)
                return false;

            try
            {
                if (a.IsConnectedTo(b))
                    return true;
            }
            catch
            {
            }

            // Primer intento: conector flexible hacia familia.
            try
            {
                a.ConnectTo(b);

                try
                {
                    if (a.IsConnectedTo(b))
                        return true;
                }
                catch
                {
                    return true;
                }
            }
            catch
            {
            }

            // Segundo intento: familia hacia conector flexible.
            try
            {
                b.ConnectTo(a);

                try
                {
                    if (a.IsConnectedTo(b))
                        return true;
                }
                catch
                {
                    return true;
                }
            }
            catch
            {
            }

            return false;
        }

        private Connector ObtenerConectorMasCercanoEnLista(
            List<Connector> conectores,
            XYZ punto,
            Connector excluir)
        {
            if (conectores == null || conectores.Count == 0 || EsVectorCero(punto))
                return null;

            Connector mejor = null;
            double mejorDist = double.MaxValue;

            foreach (Connector c in conectores)
            {
                if (c == null)
                    continue;

                if (excluir != null && object.ReferenceEquals(c, excluir))
                    continue;

                XYZ p = ObtenerOrigenSeguro(c);

                if (EsVectorCero(p))
                    continue;

                double d = p.DistanceTo(punto);

                if (d < mejorDist)
                {
                    mejorDist = d;
                    mejor = c;
                }
            }

            return mejor;
        }

        private Connector ObtenerConectorMasLejanoEnLista(
            List<Connector> conectores,
            XYZ punto,
            Connector preferirDistinto)
        {
            if (conectores == null || conectores.Count == 0 || EsVectorCero(punto))
                return null;

            Connector mejor = null;
            double mejorDist = double.MinValue;

            foreach (Connector c in conectores)
            {
                if (c == null)
                    continue;

                if (preferirDistinto != null && object.ReferenceEquals(c, preferirDistinto))
                    continue;

                XYZ p = ObtenerOrigenSeguro(c);

                if (EsVectorCero(p))
                    continue;

                double d = p.DistanceTo(punto);

                if (d > mejorDist)
                {
                    mejorDist = d;
                    mejor = c;
                }
            }

            return mejor;
        }

        private bool ConectarExtremoFinalFlexible(Element flexible, Connector conectorDestino)
        {
            if (flexible == null || conectorDestino == null)
                return false;

            try
            {
                XYZ pDestino = ObtenerOrigenSeguro(conectorDestino);
                Connector cFlex = ObtenerConectorMasCercano(flexible, pDestino);

                return ConectarDosConectoresRobusto(cFlex, conectorDestino);
            }
            catch
            {
                return false;
            }
        }

        private Connector ObtenerConectorMasCercano(Element e, XYZ punto)
        {
            Connector mejor = null;
            double mejorDist = double.MaxValue;

            List<Connector> conectores = ObtenerConectores(e);

            foreach (Connector c in conectores)
            {
                XYZ p = ObtenerOrigenSeguro(c);

                if (EsVectorCero(p))
                    continue;

                double d = p.DistanceTo(punto);

                if (d < mejorDist)
                {
                    mejorDist = d;
                    mejor = c;
                }
            }

            return mejor;
        }

        private ParConectoresFlexible55 BuscarMejorParCompatible(
            List<Connector> a,
            List<Connector> b,
            EleTubosFlexibles55TipoInfo tipo)
        {
            ParConectoresFlexible55 mejor = null;
            double mejorScore = double.MaxValue;

            foreach (Connector c1 in a)
            {
                if (c1 == null)
                    continue;

                foreach (Connector c2 in b)
                {
                    if (c2 == null)
                        continue;

                    if (!SonCompatiblesParaTipo(c1, c2, tipo))
                        continue;

                    XYZ p1 = ObtenerOrigenSeguro(c1);
                    XYZ p2 = ObtenerOrigenSeguro(c2);

                    if (EsVectorCero(p1) || EsVectorCero(p2))
                        continue;

                    double score = p1.DistanceTo(p2);

                    if (PreferirConectoresLibres)
                    {
                        if (EstaConectado(c1))
                            score += 1000.0;

                        if (EstaConectado(c2))
                            score += 1000.0;
                    }

                    if (score < mejorScore)
                    {
                        mejorScore = score;
                        mejor = new ParConectoresFlexible55
                        {
                            A = c1,
                            B = c2,
                            EsPipe = EsDominioPiping(c1) && EsDominioPiping(c2),
                            EsDuct = EsDominioHvac(c1) && EsDominioHvac(c2)
                        };
                    }
                }
            }

            return mejor;
        }

        private bool SonCompatiblesParaTipo(Connector a, Connector b, EleTubosFlexibles55TipoInfo tipo)
        {
            if (a == null || b == null)
                return false;

            bool pipe = EsDominioPiping(a) && EsDominioPiping(b);
            bool duct = EsDominioHvac(a) && EsDominioHvac(b);

            if (tipo != null && !tipo.EsAutomatico)
            {
                if (tipo.EsPipe)
                    return pipe;

                if (tipo.EsDuct)
                    return duct;

                return false;
            }

            return pipe || duct;
        }

        private EleTubosFlexibles55TipoInfo ResolverTipoParaPar(
            Document doc,
            ParConectoresFlexible55 par,
            EleTubosFlexibles55TipoInfo tipoSeleccionado)
        {
            if (doc == null || par == null)
                return null;

            if (tipoSeleccionado != null && !tipoSeleccionado.EsAutomatico)
                return tipoSeleccionado;

            if (par.EsPipe)
            {
                EleTubosFlexibles55TipoInfo tipoPipe = TiposDisponibles
                    .FirstOrDefault(x => x != null && x.EsPipe && x.Id != null && x.Id != ElementId.InvalidElementId);

                if (tipoPipe != null)
                    return tipoPipe;
            }

            if (par.EsDuct)
            {
                EleTubosFlexibles55TipoInfo tipoDuct = TiposDisponibles
                    .FirstOrDefault(x => x != null && x.EsDuct && x.Id != null && x.Id != ElementId.InvalidElementId);

                if (tipoDuct != null)
                    return tipoDuct;
            }

            return null;
        }

        private List<Connector> ObtenerConectores(Element e)
        {
            List<Connector> lista = new List<Connector>();

            if (e == null)
                return lista;

            try
            {
                FamilyInstance fi = e as FamilyInstance;

                if (fi != null && fi.MEPModel != null && fi.MEPModel.ConnectorManager != null)
                    AgregarConectores(lista, fi.MEPModel.ConnectorManager.Connectors);
            }
            catch
            {
            }

            try
            {
                MEPCurve curva = e as MEPCurve;

                if (curva != null && curva.ConnectorManager != null)
                    AgregarConectores(lista, curva.ConnectorManager.Connectors);
            }
            catch
            {
            }

            return lista
                .Where(x => x != null)
                .GroupBy(x => ObtenerOrigenSeguro(x).ToString())
                .Select(g => g.First())
                .ToList();
        }

        private void AgregarConectores(List<Connector> lista, ConnectorSet set)
        {
            if (lista == null || set == null)
                return;

            foreach (Connector c in set)
            {
                if (c == null)
                    continue;

                if (EsConectorValidoParaFlexible(c))
                    lista.Add(c);
            }
        }


        private bool EsConectorValidoParaFlexible(Connector c)
        {
            if (c == null)
                return false;

            if (!EsDominioPiping(c) && !EsDominioHvac(c))
                return false;

            try
            {
                // Para tubería flexible se priorizan conectores físicos de extremo.
                // Esto evita tomar conectores lógicos o auxiliares que la familia pueda tener.
                if (c.ConnectorType != ConnectorType.End)
                    return false;
            }
            catch
            {
            }

            return true;
        }

        private bool EstaConectado(Connector c)
        {
            if (c == null)
                return false;

            try
            {
                return c.IsConnected;
            }
            catch
            {
                return false;
            }
        }

        private bool EsDominioPiping(Connector c)
        {
            if (c == null)
                return false;

            try
            {
                string d = c.Domain.ToString().ToUpperInvariant();
                return d.Contains("PIPING") || d.Contains("PIPE");
            }
            catch
            {
                return false;
            }
        }

        private bool EsDominioHvac(Connector c)
        {
            if (c == null)
                return false;

            try
            {
                string d = c.Domain.ToString().ToUpperInvariant();
                return d.Contains("HVAC") || d.Contains("DUCT");
            }
            catch
            {
                return false;
            }
        }

        private XYZ ObtenerOrigenSeguro(Connector c)
        {
            if (c == null)
                return XYZ.Zero;

            try
            {
                return c.Origin;
            }
            catch
            {
                return XYZ.Zero;
            }
        }

        private bool EsVectorCero(XYZ p)
        {
            if (p == null)
                return true;

            return Math.Abs(p.X) < Epsilon && Math.Abs(p.Y) < Epsilon && Math.Abs(p.Z) < Epsilon;
        }

        private void MarcarElemento(Element e)
        {
            if (e == null)
                return;

            try
            {
                Parameter p = e.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);

                if (p != null && !p.IsReadOnly)
                    p.Set(MarcaGenerado);
            }
            catch
            {
            }
        }

        private class FiltroElementoConConectoresFlexibles : ISelectionFilter
        {
            public bool AllowElement(Element elem)
            {
                if (elem == null)
                    return false;

                try
                {
                    FamilyInstance fi = elem as FamilyInstance;

                    if (fi != null && fi.MEPModel != null && fi.MEPModel.ConnectorManager != null)
                    {
                        ConnectorSet cs = fi.MEPModel.ConnectorManager.Connectors;

                        if (cs != null && cs.Size > 0)
                            return true;
                    }
                }
                catch
                {
                }

                try
                {
                    MEPCurve curva = elem as MEPCurve;

                    if (curva != null && curva.ConnectorManager != null && curva.ConnectorManager.Connectors != null)
                        return curva.ConnectorManager.Connectors.Size > 0;
                }
                catch
                {
                }

                return false;
            }

            public bool AllowReference(Reference reference, XYZ position)
            {
                return true;
            }
        }

        private class Flexibles55FailurePreprocessor : IFailuresPreprocessor
        {
            public FailureProcessingResult PreprocessFailures(FailuresAccessor failuresAccessor)
            {
                if (failuresAccessor == null)
                    return FailureProcessingResult.Continue;

                try
                {
                    IList<FailureMessageAccessor> failures = failuresAccessor.GetFailureMessages();

                    if (failures == null)
                        return FailureProcessingResult.Continue;

                    foreach (FailureMessageAccessor failure in failures)
                    {
                        if (failure == null)
                            continue;

                        if (failure.GetSeverity() == FailureSeverity.Warning)
                            failuresAccessor.DeleteWarning(failure);
                    }
                }
                catch
                {
                }

                return FailureProcessingResult.Continue;
            }
        }

        private class ParConectoresFlexible55
        {
            public Connector A { get; set; }
            public Connector B { get; set; }
            public bool EsPipe { get; set; }
            public bool EsDuct { get; set; }
        }

        private class ResultadoFlexible55
        {
            public bool Ok { get; set; }
            public ElementId IdCreado { get; set; }
            public string TipoUsado { get; set; }
            public string ResumenConectores { get; set; }
            public string Error { get; set; }
        }
    }
}
