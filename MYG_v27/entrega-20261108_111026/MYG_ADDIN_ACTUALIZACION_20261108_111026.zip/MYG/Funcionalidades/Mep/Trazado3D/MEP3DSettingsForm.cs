using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // VENTANA MEP 5.7 - CONFIGURACIÓN TRAZADO MEP 3D
    // SIN USING / SIN NAMESPACE
    // =====================================

    public class MEP3DSettingsForm : System.Windows.Forms.Form
    {
        private System.Windows.Forms.NumericUpDown nudLongitudBloom;
        private System.Windows.Forms.NumericUpDown nudLongitudCodo;
        private System.Windows.Forms.NumericUpDown nudTolerancia;

        private System.Windows.Forms.CheckBox chkUsarSeleccionActual;
        private System.Windows.Forms.CheckBox chkTodosConectoresLibres;
        private System.Windows.Forms.CheckBox chkSoloConectoresLibres;
        private System.Windows.Forms.CheckBox chkMoverRamal;
        private System.Windows.Forms.CheckBox chkSeleccionarResultado;
        private System.Windows.Forms.CheckBox chkMostrarResumen;

        private System.Windows.Forms.CheckBox chkTuberias;
        private System.Windows.Forms.CheckBox chkDuctos;
        private System.Windows.Forms.CheckBox chkConduits;
        private System.Windows.Forms.CheckBox chkBandejas;

        private System.Windows.Forms.ComboBox cmbModoVolteo;

        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnRestaurar;
        private System.Windows.Forms.Button btnCancelar;

        public MEP3DSettingsForm()
        {
            this.Text = "MEP 5.7 - Configuración de Trazado MEP 3D";
            this.Width = 700;
            this.Height = 710;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ShowInTaskbar = false;

            InicializarComponentes();
            CargarConfiguracion(global::MYG_Addin.MEP3DSettings.Obtener());
        }

        private void InicializarComponentes()
        {
            System.Windows.Forms.Label lblAutor = CrearEtiqueta(
                "Creado por: Ing. Marlon Yacila  |  MEP - Trazado 3D",
                20,
                12,
                640,
                20,
                true,
                System.Drawing.Color.Gray);

            System.Windows.Forms.Label lblGeometria = CrearEtiqueta(
                "01. GEOMETRÍA DE CREACIÓN",
                20,
                45,
                640,
                22,
                true,
                System.Drawing.Color.FromArgb(50, 50, 50));

            System.Windows.Forms.Label lblBloom = CrearEtiqueta(
                "Longitud del tramo Bloom (mm):",
                20,
                82,
                240,
                22,
                false,
                System.Drawing.Color.FromArgb(55, 55, 55));

            nudLongitudBloom = CrearNumerico(275, 79, 120, 10M, 5000M, 150M, 0);

            System.Windows.Forms.Label lblCodo = CrearEtiqueta(
                "Longitud después del codo (mm):",
                20,
                118,
                240,
                22,
                false,
                System.Drawing.Color.FromArgb(55, 55, 55));

            nudLongitudCodo = CrearNumerico(275, 115, 120, 20M, 10000M, 300M, 0);

            System.Windows.Forms.Label lblTol = CrearEtiqueta(
                "Tolerancia de conexión (mm):",
                20,
                154,
                240,
                22,
                false,
                System.Drawing.Color.FromArgb(55, 55, 55));

            nudTolerancia = CrearNumerico(275, 151, 120, 0.5M, 50M, 3M, 1);
            nudTolerancia.Increment = 0.5M;

            System.Windows.Forms.Label lblNotaDireccion = CrearEtiqueta(
                "Arriba/abajo se calcula respecto al eje Z. Izquierda/derecha se interpreta según la vista activa y se proyecta perpendicularmente al tramo.",
                420,
                79,
                240,
                92,
                false,
                System.Drawing.Color.FromArgb(90, 90, 90));

            lblNotaDireccion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            lblNotaDireccion.Padding = new System.Windows.Forms.Padding(8);

            System.Windows.Forms.Label lblFlujo = CrearEtiqueta(
                "02. FLUJO DE TRABAJO",
                20,
                205,
                640,
                22,
                true,
                System.Drawing.Color.FromArgb(50, 50, 50));

            chkUsarSeleccionActual = CrearCheck(
                "Usar primero la selección actual de Revit",
                20,
                240,
                310,
                true);

            chkTodosConectoresLibres = CrearCheck(
                "Bloom en todos los conectores libres del elemento",
                350,
                240,
                310,
                true);

            chkSoloConectoresLibres = CrearCheck(
                "Mover/conectar usando solamente conectores libres",
                20,
                272,
                330,
                true);

            chkMoverRamal = CrearCheck(
                "Mover el ramal conectado completo",
                350,
                272,
                280,
                false);

            chkSeleccionarResultado = CrearCheck(
                "Seleccionar los elementos creados o modificados",
                20,
                304,
                330,
                true);

            chkMostrarResumen = CrearCheck(
                "Mostrar resumen al finalizar",
                350,
                304,
                280,
                false);

            System.Windows.Forms.Label lblAdvertenciaRamal = CrearEtiqueta(
                "Precaución: 'Mover el ramal conectado completo' recorre conexiones físicas y mueve hasta 250 elementos. Mantén la opción apagada para mover únicamente el elemento escogido.",
                20,
                340,
                640,
                52,
                false,
                System.Drawing.Color.FromArgb(130, 80, 0));

            lblAdvertenciaRamal.BackColor = System.Drawing.Color.FromArgb(255, 247, 224);
            lblAdvertenciaRamal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            lblAdvertenciaRamal.Padding = new System.Windows.Forms.Padding(8);

            System.Windows.Forms.Label lblDominios = CrearEtiqueta(
                "03. DOMINIOS HABILITADOS PARA BLOOM",
                20,
                415,
                640,
                22,
                true,
                System.Drawing.Color.FromArgb(50, 50, 50));

            chkTuberias = CrearCheck("Tuberías", 20, 450, 140, true);
            chkDuctos = CrearCheck("Ductos", 175, 450, 140, true);
            chkConduits = CrearCheck("Conduits", 330, 450, 140, true);
            chkBandejas = CrearCheck("Bandejas", 485, 450, 140, true);

            System.Windows.Forms.Label lblNotaTipos = CrearEtiqueta(
                "Cuando Bloom parte desde una familia sin sistema conectado, se utiliza el primer tipo y sistema compatible disponible en el proyecto. Desde un tramo existente se conserva su tipo.",
                20,
                485,
                640,
                48,
                false,
                System.Drawing.Color.FromArgb(90, 90, 90));

            System.Windows.Forms.Label lblVolteo = CrearEtiqueta(
                "04. VOLTEAR MÚLTIPLE",
                20,
                548,
                640,
                22,
                true,
                System.Drawing.Color.FromArgb(50, 50, 50));

            System.Windows.Forms.Label lblModo = CrearEtiqueta(
                "Modo aplicado a las familias seleccionadas:",
                20,
                584,
                280,
                22,
                false,
                System.Drawing.Color.FromArgb(55, 55, 55));

            cmbModoVolteo = new System.Windows.Forms.ComboBox()
            {
                Left = 310,
                Top = 581,
                Width = 350,
                Height = 26,
                DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            };

            cmbModoVolteo.Items.AddRange(new object[]
            {
            "Voltear cara (Facing)",
            "Voltear mano (Hand)",
            "Voltear cara y mano",
            "Girar 180°"
            });

            btnRestaurar = CrearBoton(
                "RESTAURAR",
                20,
                630,
                145,
                System.Drawing.Color.FromArgb(95, 95, 95));

            btnCancelar = CrearBoton(
                "CANCELAR",
                340,
                630,
                145,
                System.Drawing.Color.FromArgb(95, 95, 95));

            btnGuardar = CrearBoton(
                "GUARDAR",
                500,
                630,
                160,
                System.Drawing.Color.FromArgb(0, 120, 215));

            btnRestaurar.Click += (s, e) => RestaurarPredeterminados();
            btnCancelar.Click += (s, e) =>
            {
                this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
                this.Close();
            };

            btnGuardar.Click += (s, e) => GuardarYSalir();

            this.AcceptButton = btnGuardar;
            this.CancelButton = btnCancelar;

            this.Controls.Add(lblAutor);
            this.Controls.Add(lblGeometria);
            this.Controls.Add(lblBloom);
            this.Controls.Add(nudLongitudBloom);
            this.Controls.Add(lblCodo);
            this.Controls.Add(nudLongitudCodo);
            this.Controls.Add(lblTol);
            this.Controls.Add(nudTolerancia);
            this.Controls.Add(lblNotaDireccion);

            this.Controls.Add(lblFlujo);
            this.Controls.Add(chkUsarSeleccionActual);
            this.Controls.Add(chkTodosConectoresLibres);
            this.Controls.Add(chkSoloConectoresLibres);
            this.Controls.Add(chkMoverRamal);
            this.Controls.Add(chkSeleccionarResultado);
            this.Controls.Add(chkMostrarResumen);
            this.Controls.Add(lblAdvertenciaRamal);

            this.Controls.Add(lblDominios);
            this.Controls.Add(chkTuberias);
            this.Controls.Add(chkDuctos);
            this.Controls.Add(chkConduits);
            this.Controls.Add(chkBandejas);
            this.Controls.Add(lblNotaTipos);

            this.Controls.Add(lblVolteo);
            this.Controls.Add(lblModo);
            this.Controls.Add(cmbModoVolteo);

            this.Controls.Add(btnRestaurar);
            this.Controls.Add(btnCancelar);
            this.Controls.Add(btnGuardar);
        }

        private void CargarConfiguracion(
            global::MYG_Addin.MEP3DSettingsData datos)
        {
            if (datos == null)
                datos = global::MYG_Addin.MEP3DSettingsData.CrearPredeterminada();

            nudLongitudBloom.Value = LimitarDecimal(
                (decimal)datos.LongitudBloomMm,
                nudLongitudBloom.Minimum,
                nudLongitudBloom.Maximum);

            nudLongitudCodo.Value = LimitarDecimal(
                (decimal)datos.LongitudCodoMm,
                nudLongitudCodo.Minimum,
                nudLongitudCodo.Maximum);

            nudTolerancia.Value = LimitarDecimal(
                (decimal)datos.ToleranciaConexionMm,
                nudTolerancia.Minimum,
                nudTolerancia.Maximum);

            chkUsarSeleccionActual.Checked = datos.UsarSeleccionActual;
            chkTodosConectoresLibres.Checked = datos.CrearEnTodosLosConectoresLibres;
            chkSoloConectoresLibres.Checked = datos.SoloConectoresLibres;
            chkMoverRamal.Checked = datos.MoverRamalConectado;
            chkSeleccionarResultado.Checked = datos.SeleccionarResultado;
            chkMostrarResumen.Checked = datos.MostrarResumen;

            chkTuberias.Checked = datos.HabilitarTuberias;
            chkDuctos.Checked = datos.HabilitarDuctos;
            chkConduits.Checked = datos.HabilitarConduits;
            chkBandejas.Checked = datos.HabilitarBandejas;

            int indice = (int)datos.ModoVolteo;

            if (indice < 0 || indice >= cmbModoVolteo.Items.Count)
                indice = 0;

            cmbModoVolteo.SelectedIndex = indice;
        }

        private void GuardarYSalir()
        {
            global::MYG_Addin.MEP3DSettingsData datos =
                new global::MYG_Addin.MEP3DSettingsData()
                {
                    LongitudBloomMm = (double)nudLongitudBloom.Value,
                    LongitudCodoMm = (double)nudLongitudCodo.Value,
                    ToleranciaConexionMm = (double)nudTolerancia.Value,

                    UsarSeleccionActual = chkUsarSeleccionActual.Checked,
                    CrearEnTodosLosConectoresLibres = chkTodosConectoresLibres.Checked,
                    SoloConectoresLibres = chkSoloConectoresLibres.Checked,
                    MoverRamalConectado = chkMoverRamal.Checked,
                    SeleccionarResultado = chkSeleccionarResultado.Checked,
                    MostrarResumen = chkMostrarResumen.Checked,

                    HabilitarTuberias = chkTuberias.Checked,
                    HabilitarDuctos = chkDuctos.Checked,
                    HabilitarConduits = chkConduits.Checked,
                    HabilitarBandejas = chkBandejas.Checked,

                    ModoVolteo = (global::MYG_Addin.MEP3DFlipMode)
                        System.Math.Max(cmbModoVolteo.SelectedIndex, 0)
                };

            global::MYG_Addin.MEP3DSettings.Guardar(datos);

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private void RestaurarPredeterminados()
        {
            System.Windows.Forms.DialogResult respuesta =
                System.Windows.Forms.MessageBox.Show(
                    "¿Deseas restaurar la configuración predeterminada del Trazado MEP 3D?",
                    "MYG",
                    System.Windows.Forms.MessageBoxButtons.YesNo,
                    System.Windows.Forms.MessageBoxIcon.Question);

            if (respuesta != System.Windows.Forms.DialogResult.Yes)
                return;

            global::MYG_Addin.MEP3DSettingsData datos =
                global::MYG_Addin.MEP3DSettings.RestaurarPredeterminada();

            CargarConfiguracion(datos);
        }

        private System.Windows.Forms.Label CrearEtiqueta(
            string texto,
            int left,
            int top,
            int width,
            int height,
            bool negrita,
            System.Drawing.Color color)
        {
            return new System.Windows.Forms.Label()
            {
                Text = texto,
                Left = left,
                Top = top,
                Width = width,
                Height = height,
                AutoEllipsis = false,
                Font = new System.Drawing.Font(
                    "Segoe UI",
                    negrita ? 9F : 8.7F,
                    negrita
                        ? System.Drawing.FontStyle.Bold
                        : System.Drawing.FontStyle.Regular),
                ForeColor = color
            };
        }

        private System.Windows.Forms.NumericUpDown CrearNumerico(
            int left,
            int top,
            int width,
            decimal minimo,
            decimal maximo,
            decimal valor,
            int decimales)
        {
            return new System.Windows.Forms.NumericUpDown()
            {
                Left = left,
                Top = top,
                Width = width,
                Height = 25,
                Minimum = minimo,
                Maximum = maximo,
                Value = valor,
                DecimalPlaces = decimales,
                ThousandsSeparator = true,
                TextAlign = System.Windows.Forms.HorizontalAlignment.Right
            };
        }

        private System.Windows.Forms.CheckBox CrearCheck(
            string texto,
            int left,
            int top,
            int width,
            bool valor)
        {
            return new System.Windows.Forms.CheckBox()
            {
                Text = texto,
                Left = left,
                Top = top,
                Width = width,
                Height = 25,
                Checked = valor
            };
        }

        private System.Windows.Forms.Button CrearBoton(
            string texto,
            int left,
            int top,
            int width,
            System.Drawing.Color color)
        {
            System.Windows.Forms.Button boton = new System.Windows.Forms.Button()
            {
                Text = texto,
                Left = left,
                Top = top,
                Width = width,
                Height = 38,
                BackColor = color,
                ForeColor = System.Drawing.Color.White,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font(
                    "Segoe UI",
                    8.7F,
                    System.Drawing.FontStyle.Bold),
                Cursor = System.Windows.Forms.Cursors.Hand
            };

            boton.FlatAppearance.BorderSize = 0;
            boton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(
                System.Math.Max(color.R - 15, 0),
                System.Math.Max(color.G - 15, 0),
                System.Math.Max(color.B - 15, 0));

            return boton;
        }

        private decimal LimitarDecimal(
            decimal valor,
            decimal minimo,
            decimal maximo)
        {
            if (valor < minimo)
                return minimo;

            if (valor > maximo)
                return maximo;

            return valor;
        }
    }

}
