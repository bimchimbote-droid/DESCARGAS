﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Electrical;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.UI.Events;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace MYG_Addin
{
    public enum MEP3DOperation
    {
        Bloom = 0,
        CodoArriba = 1,
        CodoAbajo = 2,
        CodoIzquierda = 3,
        CodoDerecha = 4,
        MoverConectar = 5,
        MoverAlinearConectar = 6,
        VoltearMultiple = 7,
        Configuracion = 8,
        ConectarCaraProxima = 9
    }

    public enum MEP3DFlipMode
    {
        Cara = 0,
        Mano = 1,
        CaraYMano = 2,
        Girar180 = 3
    }

    public sealed class MEP3DSettingsData
    {
        public double LongitudBloomMm { get; set; }
        public double LongitudCodoMm { get; set; }
        public double ToleranciaConexionMm { get; set; }

        public bool UsarSeleccionActual { get; set; }
        public bool CrearEnTodosLosConectoresLibres { get; set; }
        public bool SoloConectoresLibres { get; set; }
        public bool MoverRamalConectado { get; set; }
        public bool SeleccionarResultado { get; set; }
        public bool MostrarResumen { get; set; }

        public bool HabilitarTuberias { get; set; }
        public bool HabilitarDuctos { get; set; }
        public bool HabilitarConduits { get; set; }
        public bool HabilitarBandejas { get; set; }

        public MEP3DFlipMode ModoVolteo { get; set; }

        public static MEP3DSettingsData CrearPredeterminada()
        {
            return new MEP3DSettingsData()
            {
                LongitudBloomMm = 150.0,
                LongitudCodoMm = 300.0,
                ToleranciaConexionMm = 3.0,

                UsarSeleccionActual = true,
                CrearEnTodosLosConectoresLibres = true,
                SoloConectoresLibres = true,
                MoverRamalConectado = false,
                SeleccionarResultado = true,
                MostrarResumen = false,

                HabilitarTuberias = true,
                HabilitarDuctos = true,
                HabilitarConduits = true,
                HabilitarBandejas = true,

                ModoVolteo = MEP3DFlipMode.Cara
            };
        }

        public MEP3DSettingsData Clonar()
        {
            return new MEP3DSettingsData()
            {
                LongitudBloomMm = LongitudBloomMm,
                LongitudCodoMm = LongitudCodoMm,
                ToleranciaConexionMm = ToleranciaConexionMm,

                UsarSeleccionActual = UsarSeleccionActual,
                CrearEnTodosLosConectoresLibres = CrearEnTodosLosConectoresLibres,
                SoloConectoresLibres = SoloConectoresLibres,
                MoverRamalConectado = MoverRamalConectado,
                SeleccionarResultado = SeleccionarResultado,
                MostrarResumen = MostrarResumen,

                HabilitarTuberias = HabilitarTuberias,
                HabilitarDuctos = HabilitarDuctos,
                HabilitarConduits = HabilitarConduits,
                HabilitarBandejas = HabilitarBandejas,

                ModoVolteo = ModoVolteo
            };
        }
    }

    public static class MEP3DSettings
    {
        private static readonly object SyncRoot = new object();
        private static MEP3DSettingsData _actual;
        private static bool _cargado;

        public static MEP3DSettingsData Obtener()
        {
            lock (SyncRoot)
            {
                CargarSiCorresponde();
                return _actual.Clonar();
            }
        }

        public static void Guardar(MEP3DSettingsData configuracion)
        {
            if (configuracion == null)
                configuracion = MEP3DSettingsData.CrearPredeterminada();

            lock (SyncRoot)
            {
                _actual = Normalizar(configuracion.Clonar());
                _cargado = true;

                try
                {
                    string ruta = ObtenerRutaArchivo();
                    string carpeta = Path.GetDirectoryName(ruta);

                    if (!string.IsNullOrWhiteSpace(carpeta))
                        Directory.CreateDirectory(carpeta);

                    File.WriteAllText(
                        ruta,
                        SerializarConfiguracion(_actual));
                }
                catch
                {
                    // La herramienta continúa usando la configuración en memoria.
                }
            }
        }

        public static MEP3DSettingsData RestaurarPredeterminada()
        {
            MEP3DSettingsData datos = MEP3DSettingsData.CrearPredeterminada();
            Guardar(datos);
            return datos.Clonar();
        }

        private static void CargarSiCorresponde()
        {
            if (_cargado && _actual != null)
                return;

            _actual = MEP3DSettingsData.CrearPredeterminada();

            try
            {
                string ruta = ObtenerRutaArchivo();

                if (File.Exists(ruta))
                {
                    string contenido = File.ReadAllText(ruta);
                    MEP3DSettingsData datos = DeserializarConfiguracion(contenido);

                    if (datos != null)
                        _actual = Normalizar(datos);
                }
            }
            catch
            {
                _actual = MEP3DSettingsData.CrearPredeterminada();
            }

            _cargado = true;
        }

        private static MEP3DSettingsData Normalizar(MEP3DSettingsData datos)
        {
            if (datos == null)
                datos = MEP3DSettingsData.CrearPredeterminada();

            datos.LongitudBloomMm = Limitar(datos.LongitudBloomMm, 10.0, 5000.0, 150.0);
            datos.LongitudCodoMm = Limitar(datos.LongitudCodoMm, 20.0, 10000.0, 300.0);
            datos.ToleranciaConexionMm = Limitar(datos.ToleranciaConexionMm, 0.5, 50.0, 3.0);

            return datos;
        }

        private static double Limitar(double valor, double minimo, double maximo, double defecto)
        {
            if (double.IsNaN(valor) || double.IsInfinity(valor))
                return defecto;

            if (valor < minimo)
                return minimo;

            if (valor > maximo)
                return maximo;

            return valor;
        }

        private static string SerializarConfiguracion(MEP3DSettingsData datos)
        {
            if (datos == null)
                datos = MEP3DSettingsData.CrearPredeterminada();

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            System.Globalization.CultureInfo cultura = System.Globalization.CultureInfo.InvariantCulture;

            sb.AppendLine("LongitudBloomMm=" + datos.LongitudBloomMm.ToString(cultura));
            sb.AppendLine("LongitudCodoMm=" + datos.LongitudCodoMm.ToString(cultura));
            sb.AppendLine("ToleranciaConexionMm=" + datos.ToleranciaConexionMm.ToString(cultura));

            sb.AppendLine("UsarSeleccionActual=" + datos.UsarSeleccionActual.ToString());
            sb.AppendLine("CrearEnTodosLosConectoresLibres=" + datos.CrearEnTodosLosConectoresLibres.ToString());
            sb.AppendLine("SoloConectoresLibres=" + datos.SoloConectoresLibres.ToString());
            sb.AppendLine("MoverRamalConectado=" + datos.MoverRamalConectado.ToString());
            sb.AppendLine("SeleccionarResultado=" + datos.SeleccionarResultado.ToString());
            sb.AppendLine("MostrarResumen=" + datos.MostrarResumen.ToString());

            sb.AppendLine("HabilitarTuberias=" + datos.HabilitarTuberias.ToString());
            sb.AppendLine("HabilitarDuctos=" + datos.HabilitarDuctos.ToString());
            sb.AppendLine("HabilitarConduits=" + datos.HabilitarConduits.ToString());
            sb.AppendLine("HabilitarBandejas=" + datos.HabilitarBandejas.ToString());

            sb.AppendLine("ModoVolteo=" + datos.ModoVolteo.ToString());

            return sb.ToString();
        }

        private static MEP3DSettingsData DeserializarConfiguracion(string contenido)
        {
            MEP3DSettingsData datos = MEP3DSettingsData.CrearPredeterminada();

            if (string.IsNullOrWhiteSpace(contenido))
                return datos;

            Dictionary<string, string> valores = new Dictionary<string, string>(
                StringComparer.OrdinalIgnoreCase);

            string[] lineas = contenido.Replace("\r", "").Split('\n');

            foreach (string lineaOriginal in lineas)
            {
                if (string.IsNullOrWhiteSpace(lineaOriginal))
                    continue;

                string linea = lineaOriginal.Trim();

                if (linea.StartsWith("#") || linea.StartsWith(";"))
                    continue;

                int indice = linea.IndexOf('=');

                if (indice <= 0)
                    continue;

                string clave = linea.Substring(0, indice).Trim();
                string valor = linea.Substring(indice + 1).Trim();

                if (!string.IsNullOrWhiteSpace(clave))
                    valores[clave] = valor;
            }

            double numero;
            bool booleano;
            MEP3DFlipMode modo;

            if (TryLeerDouble(valores, "LongitudBloomMm", out numero))
                datos.LongitudBloomMm = numero;

            if (TryLeerDouble(valores, "LongitudCodoMm", out numero))
                datos.LongitudCodoMm = numero;

            if (TryLeerDouble(valores, "ToleranciaConexionMm", out numero))
                datos.ToleranciaConexionMm = numero;

            if (TryLeerBool(valores, "UsarSeleccionActual", out booleano))
                datos.UsarSeleccionActual = booleano;

            if (TryLeerBool(valores, "CrearEnTodosLosConectoresLibres", out booleano))
                datos.CrearEnTodosLosConectoresLibres = booleano;

            if (TryLeerBool(valores, "SoloConectoresLibres", out booleano))
                datos.SoloConectoresLibres = booleano;

            if (TryLeerBool(valores, "MoverRamalConectado", out booleano))
                datos.MoverRamalConectado = booleano;

            if (TryLeerBool(valores, "SeleccionarResultado", out booleano))
                datos.SeleccionarResultado = booleano;

            if (TryLeerBool(valores, "MostrarResumen", out booleano))
                datos.MostrarResumen = booleano;

            if (TryLeerBool(valores, "HabilitarTuberias", out booleano))
                datos.HabilitarTuberias = booleano;

            if (TryLeerBool(valores, "HabilitarDuctos", out booleano))
                datos.HabilitarDuctos = booleano;

            if (TryLeerBool(valores, "HabilitarConduits", out booleano))
                datos.HabilitarConduits = booleano;

            if (TryLeerBool(valores, "HabilitarBandejas", out booleano))
                datos.HabilitarBandejas = booleano;

            string textoModo;

            if (valores.TryGetValue("ModoVolteo", out textoModo) &&
                Enum.TryParse<MEP3DFlipMode>(textoModo, true, out modo))
            {
                datos.ModoVolteo = modo;
            }

            return datos;
        }

        private static bool TryLeerDouble(
            Dictionary<string, string> valores,
            string clave,
            out double valor)
        {
            valor = 0.0;
            string texto;

            if (valores == null || !valores.TryGetValue(clave, out texto))
                return false;

            return double.TryParse(
                texto.Replace(',', '.'),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out valor);
        }

        private static bool TryLeerBool(
            Dictionary<string, string> valores,
            string clave,
            out bool valor)
        {
            valor = false;
            string texto;

            if (valores == null || !valores.TryGetValue(clave, out texto))
                return false;

            return bool.TryParse(texto, out valor);
        }

        private static string ObtenerRutaArchivo()
        {
            string appData = Environment.GetFolderPath(
                Environment.SpecialFolder.ApplicationData);

            return Path.Combine(
                appData,
                "MYG_Addin",
                "MEP_Trazado3D_Config.cfg");
        }
    }

    public static class MEP3DCommandHandler
    {
        private const double EPS = 1.0e-9;
        private const int MAX_ELEMENTOS_RAMAL = 250;

        // Cache de conectores By Face/Surface. Abrir y cerrar el documento de familia
        // en cada ejecución es la operación más costosa de este módulo. Se almacenan
        // únicamente coordenadas locales; la transformación de cada instancia sigue
        // calculándose en tiempo real para respetar posición y giro.
        private const int MAX_CACHE_CONECTORES_FAMILIA = 256;
        private static readonly object CacheConectoresFamiliaSync = new object();
        private static readonly Dictionary<string, MEP3DConectorFamiliaCacheData>
            CacheConectoresFamilia =
                new Dictionary<string, MEP3DConectorFamiliaCacheData>(
                    StringComparer.Ordinal);

        private sealed class MEP3DPuntoConectorFamiliaData
        {
            public XYZ PuntoLocal { get; set; }
            public bool EsPrimario { get; set; }
        }

        private sealed class MEP3DConectorFamiliaCacheData
        {
            public List<MEP3DPuntoConectorFamiliaData> Puntos { get; set; }
            public long OrdenUso { get; set; }
        }

        private static long _ordenUsoCacheConectoresFamilia;

        public static Result Ejecutar(
            ExternalCommandData commandData,
            MEP3DOperation operacion,
            ref string message)
        {
            try
            {
                UIApplication uiapp = commandData == null
                    ? null
                    : commandData.Application;

                UIDocument uidoc = uiapp == null
                    ? null
                    : uiapp.ActiveUIDocument;

                if (uidoc == null || uidoc.Document == null)
                {
                    message = "No hay documento activo.";
                    return Result.Failed;
                }

                switch (operacion)
                {
                    case MEP3DOperation.Bloom:
                        return EjecutarBloom(uidoc, ref message);

                    case MEP3DOperation.CodoArriba:
                    case MEP3DOperation.CodoAbajo:
                    case MEP3DOperation.CodoIzquierda:
                    case MEP3DOperation.CodoDerecha:
                        return EjecutarCodo(uidoc, operacion, ref message);

                    case MEP3DOperation.MoverConectar:
                        return EjecutarMoverConectar(uidoc, false, ref message);

                    case MEP3DOperation.MoverAlinearConectar:
                        return EjecutarMoverConectar(uidoc, true, ref message);

                    case MEP3DOperation.VoltearMultiple:
                        return EjecutarVoltearMultiple(uidoc, ref message);

                    case MEP3DOperation.Configuracion:
                        return EjecutarConfiguracion(uiapp, ref message);



                    default:
                        message = "Operación MEP 3D no reconocida.";
                        return Result.Failed;
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                return Result.Cancelled;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                MostrarError("Trazado MEP 3D", ex.Message);
                return Result.Failed;
            }
        }

        private static Result EjecutarConfiguracion(
            UIApplication uiapp,
            ref string message)
        {
            try
            {
                MEP3DSettingsForm ventana = new MEP3DSettingsForm();

                if (uiapp != null)
                {
                    RevitWindowHandle handle = new RevitWindowHandle(
                        uiapp.MainWindowHandle);

                    ventana.ShowDialog(handle);
                }
                else
                {
                    ventana.ShowDialog();
                }

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return Result.Failed;
            }
        }

        private static Result EjecutarBloom(
            UIDocument uidoc,
            ref string message)
        {
            Document doc = uidoc.Document;
            MEP3DSettingsData config = MEP3DSettings.Obtener();

            List<Element> elementos = ObtenerElementosParaBloom(
                uidoc,
                config.UsarSeleccionActual);

            if (elementos.Count == 0)
            {
                message = "No se seleccionaron elementos con conectores MEP físicos.";
                return Result.Cancelled;
            }

            double longitud = MmAInterno(config.LongitudBloomMm);
            List<ElementId> creados = new List<ElementId>();
            List<string> errores = new List<string>();
            int conectoresEvaluados = 0;

            using (Transaction transaccion = new Transaction(doc, "MYG - Bloom MEP 3D"))
            {
                transaccion.Start();
                ConfigurarFallos(transaccion);

                foreach (Element elemento in elementos)
                {
                    List<Connector> conectores = ObtenerConectoresFisicos(elemento)
                        .Where(x => EstaLibreSeguro(x))
                        .ToList();

                    if (!config.CrearEnTodosLosConectoresLibres && conectores.Count > 1)
                        conectores = conectores.Take(1).ToList();

                    foreach (Connector conector in conectores)
                    {
                        conectoresEvaluados++;

                        SubTransaction sub = new SubTransaction(doc);
                        sub.Start();

                        try
                        {
                            XYZ direccion = ObtenerDireccionExterior(
                                elemento,
                                conector);

                            XYZ inicio = conector.Origin;
                            XYZ fin = inicio.Add(direccion.Multiply(longitud));

                            MEPCurve tramo = CrearTramoDesdeConector(
                                doc,
                                elemento,
                                conector,
                                inicio,
                                fin,
                                config);

                            if (tramo == null)
                                throw new InvalidOperationException(
                                    "El dominio del conector no está habilitado o no es compatible.");

                            AplicarTamanoDesdeConector(tramo, conector);
                            doc.Regenerate();

                            Connector conectorNuevo = BuscarConectorMasCercano(
                                tramo,
                                inicio,
                                conector.Domain,
                                false);

                            if (conectorNuevo == null)
                                throw new InvalidOperationException(
                                    "No se encontró el conector inicial del tramo creado.");

                            ConectarConectores(doc, conector, conectorNuevo);

                            creados.Add(tramo.Id);
                            sub.Commit();
                        }
                        catch (Exception ex)
                        {
                            try
                            {
                                sub.RollBack();
                            }
                            catch
                            {
                            }

                            if (errores.Count < 12)
                            {
                                errores.Add(
                                    "Elemento " + elemento.Id.Value + ": " + ex.Message);
                            }
                        }
                    }
                }

                transaccion.Commit();
            }

            if (config.SeleccionarResultado && creados.Count > 0)
                uidoc.Selection.SetElementIds(creados);

            if (creados.Count == 0)
            {
                message = errores.Count > 0
                    ? string.Join(" | ", errores)
                    : "No se encontraron conectores libres compatibles.";

                return Result.Failed;
            }

            return Result.Succeeded;
        }

        private static Result EjecutarCodo(
            UIDocument uidoc,
            MEP3DOperation operacion,
            ref string message)
        {
            Document doc = uidoc.Document;
            MEP3DSettingsData config = MEP3DSettings.Obtener();

            Reference referencia = uidoc.Selection.PickObject(
                ObjectType.PointOnElement,
                new MEP3DCurveSelectionFilter(),
                "Selecciona el tramo cerca del extremo libre donde se creará el codo.");

            MEPCurve tramoOrigen = doc.GetElement(referencia.ElementId) as MEPCurve;

            if (tramoOrigen == null)
            {
                message = "El elemento seleccionado no es un tramo MEP compatible.";
                return Result.Failed;
            }

            XYZ puntoClick = referencia.GlobalPoint;

            if (puntoClick == null)
                puntoClick = ObtenerCentroCurva(tramoOrigen);

            Connector conectorOrigen = ObtenerConectorExtremoMasCercano(
                tramoOrigen,
                puntoClick);

            if (conectorOrigen == null)
            {
                message = "No se encontró un conector extremo en el tramo seleccionado.";
                return Result.Failed;
            }

            if (conectorOrigen.IsConnected)
            {
                message = "El extremo seleccionado ya está conectado. Selecciona un extremo libre.";
                MostrarError("Trazado MEP 3D", message);
                return Result.Failed;
            }

            XYZ direccionOrigen = ObtenerDireccionExterior(
                tramoOrigen,
                conectorOrigen);

            XYZ direccionNueva = CalcularDireccionCodo(
                uidoc.ActiveView,
                direccionOrigen,
                operacion);

            if (direccionNueva == null || direccionNueva.GetLength() < EPS)
            {
                message = "No fue posible calcular la dirección del nuevo tramo.";
                return Result.Failed;
            }

            double longitud = MmAInterno(config.LongitudCodoMm);
            XYZ inicio = conectorOrigen.Origin;
            XYZ fin = inicio.Add(direccionNueva.Multiply(longitud));
            MEPCurve tramoNuevo = null;

            using (Transaction transaccion = new Transaction(doc, "MYG - Codo MEP 3D"))
            {
                transaccion.Start();
                ConfigurarFallos(transaccion);

                try
                {
                    tramoNuevo = ClonarTipoDeTramo(
                        doc,
                        tramoOrigen,
                        inicio,
                        fin);

                    AplicarTamanoDesdeConector(tramoNuevo, conectorOrigen);
                    doc.Regenerate();

                    Connector conectorNuevo = BuscarConectorMasCercano(
                        tramoNuevo,
                        inicio,
                        conectorOrigen.Domain,
                        false);

                    if (conectorNuevo == null)
                        throw new InvalidOperationException(
                            "No se encontró el conector inicial del tramo nuevo.");

                    doc.Create.NewElbowFitting(
                        conectorOrigen,
                        conectorNuevo);

                    transaccion.Commit();
                }
                catch (Exception ex)
                {
                    try
                    {
                        transaccion.RollBack();
                    }
                    catch
                    {
                    }

                    message =
                        "No se pudo crear el codo. Revisa las preferencias de enrutamiento " +
                        "del tipo MEP y la disponibilidad de un codo compatible.\n\n" +
                        ex.Message;

                    MostrarError("Trazado MEP 3D", message);
                    return Result.Failed;
                }
            }

            if (config.SeleccionarResultado && tramoNuevo != null)
            {
                uidoc.Selection.SetElementIds(
                    new List<ElementId>() { tramoNuevo.Id });
            }

            return Result.Succeeded;
        }


        private static Result EjecutarMoverConectar(
            UIDocument uidoc,
            bool ejecutarConexion,
            ref string message)
        {
            Document doc = uidoc.Document;
            MEP3DSettingsData config = MEP3DSettings.Obtener();

            Reference referenciaDestino = uidoc.Selection.PickObject(
                ObjectType.Element,
                new MEP3DDestinationSelectionFilter(),
                "Selecciona primero el elemento DESTINO o de REFERENCIA.");

            Reference referenciaMovil = uidoc.Selection.PickObject(
                ObjectType.Element,
                new MEP3DCurveSelectionFilter(),
                "Selecciona ahora el tramo MEP que se MOVERÁ.");

            Element destino = doc.GetElement(referenciaDestino.ElementId);
            MEPCurve movil = doc.GetElement(referenciaMovil.ElementId) as MEPCurve;

            if (destino == null || movil == null)
            {
                message =
                    "No se pudieron leer los elementos seleccionados. " +
                    "La segunda selección debe ser una tubería, ducto, conduit o bandeja.";
                return Result.Failed;
            }

            if (destino.Id == movil.Id)
            {
                message = "El elemento destino y el elemento móvil no pueden ser el mismo.";
                return Result.Failed;
            }

            // Cuando la primera selección es otro tramo MEP, se conserva el flujo
            // aprobado: alinear como Revit y, solo en el segundo botón, ejecutar TRIM.
            MEPCurve destinoCurva = destino as MEPCurve;

            if (destinoCurva != null)
            {
                ConnectorPair parCurvas = BuscarMejorParConectores(
                    destinoCurva,
                    movil,
                    config.SoloConectoresLibres);

                if (parCurvas == null)
                {
                    message =
                        "No se encontró un par de conectores físicos compatibles. " +
                        "Revisa el dominio y la opción de conectores libres.";

                    MostrarError("Trazado MEP 3D", message);
                    return Result.Failed;
                }

                return EjecutarTrimMismoPlanoConAccesorio(
                    uidoc,
                    destinoCurva,
                    movil,
                    parCurvas,
                    config,
                    ejecutarConexion,
                    ref message);
            }

            // Cuando la primera selección es una familia/aparato:
            // 1) se usa su conector compatible como referencia;
            // 2) si el conector es de superficie (By Face), se usa el centro real
            //    de la cara asociada como punto de alineación;
            // 3) el segundo tramo se alinea con el mismo comportamiento de Revit.
            MEP3DReferenciaDestinoData referenciaNoCurva =
                ResolverReferenciaDestinoNoCurva(
                    doc,
                    destino,
                    referenciaDestino,
                    movil,
                    config.SoloConectoresLibres);

            if (referenciaNoCurva == null ||
                referenciaNoCurva.PuntoAlineacion == null ||
                referenciaNoCurva.ConectorMovil == null)
            {
                message =
                    "No se pudo determinar un conector o una cara válida en la primera selección.";

                MostrarError("Trazado MEP 3D", message);
                return Result.Failed;
            }

            return EjecutarAlinearHaciaElementoNoCurva(
                uidoc,
                destino,
                movil,
                referenciaNoCurva,
                config,
                ejecutarConexion,
                ref message);
        }

        private sealed class MEP3DReferenciaDestinoData
        {
            public Connector ConectorDestino { get; set; }
            public Connector ConectorMovil { get; set; }
            public XYZ PuntoAlineacion { get; set; }
            public XYZ PuntoConexion { get; set; }
            public bool EsConectorDeSuperficie { get; set; }
            public bool PuedeConectar { get; set; }
        }

        private sealed class MEP3DConectorConPuntoData
        {
            public Connector Conector { get; set; }
            public XYZ Punto { get; set; }
        }

        private static MEP3DReferenciaDestinoData ResolverReferenciaDestinoNoCurva(
            Document doc,
            Element destino,
            Reference referenciaSeleccion,
            MEPCurve movil,
            bool soloLibres)
        {
            if (doc == null || destino == null || movil == null)
                return null;

            List<Connector> conectoresMovil = ObtenerConectoresFisicos(movil)
                .Where(x => x != null)
                .Where(x => x.ConnectorType == ConnectorType.End)
                .Where(x => !soloLibres || EstaLibreSeguro(x))
                .ToList();

            if (conectoresMovil.Count == 0)
                return null;

            XYZ puntoClick = null;

            try
            {
                puntoClick = referenciaSeleccion == null
                    ? null
                    : referenciaSeleccion.GlobalPoint;
            }
            catch
            {
                puntoClick = null;
            }

            List<Connector> conectoresDestino = ObtenerConectoresFisicos(destino)
                .Where(x => x != null)
                .Where(x => x.ConnectorType != ConnectorType.Logical)
                .Where(x => conectoresMovil.Any(m => m.Domain == x.Domain))
                .Where(x => !soloLibres || EstaLibreSeguro(x))
                .ToList();

            // IMPORTANTE:
            // Connector.Origin no está disponible para conectores Surface/By Face.
            // En ese caso se abre temporalmente la familia, se obtiene el Origin del
            // ConnectorElement (que sí representa el símbolo visible del conector en
            // la familia) y se transforma a coordenadas del proyecto.
            List<Connector> conectoresSuperficie = conectoresDestino
                .Where(EsConectorDeSuperficie)
                .ToList();

            if (conectoresSuperficie.Count > 0)
            {
                XYZ puntoReferencia = EsPuntoValido(puntoClick)
                    ? puntoClick
                    : ObtenerCentroCurva(movil);

                // Ruta rápida: algunos conectores Surface no exponen Origin, pero sí
                // permiten leer el origen de su sistema de coordenadas. Cuando Revit
                // lo admite se evita por completo abrir el documento de familia.
                XYZ centroConectorCara =
                    ObtenerPuntoConectorSuperficieRapido(
                        conectoresSuperficie,
                        puntoReferencia);

                // Ruta exacta con cache: solo la primera vez que se utiliza un tipo de
                // familia se abre EditFamily. Las siguientes ejecuciones usan puntos
                // locales cacheados y únicamente aplican el Transform de la instancia.
                if (!EsPuntoValido(centroConectorCara))
                {
                    centroConectorCara =
                        ObtenerPuntoConectorCaraDesdeFamilia(
                            doc,
                            destino,
                            puntoReferencia,
                            ObtenerCentroCurva(movil));
                }

                if (!EsPuntoValido(centroConectorCara))
                {
                    centroConectorCara = ObtenerCentroCaraMasCercana(
                        destino,
                        puntoReferencia);
                }

                if (!EsPuntoValido(centroConectorCara))
                    centroConectorCara = ObtenerCentroElemento(destino);

                if (EsPuntoValido(centroConectorCara))
                {
                    Connector conectorMovilCara = conectoresMovil
                        .OrderBy(x => x.Origin.DistanceTo(centroConectorCara))
                        .FirstOrDefault();

                    return new MEP3DReferenciaDestinoData()
                    {
                        // No se conserva el Connector de superficie para conexión porque
                        // sus propiedades Origin/ConnectionStatus no son válidas en el
                        // documento de proyecto. Este caso sirve como referencia geométrica.
                        ConectorDestino = null,
                        ConectorMovil = conectorMovilCara,
                        PuntoAlineacion = centroConectorCara,
                        PuntoConexion = null,
                        EsConectorDeSuperficie = true,
                        PuedeConectar = false
                    };
                }
            }

            // Conectores físicos normales: solo se consideran aquellos cuyo Origin
            // puede leerse sin excepción.
            List<MEP3DConectorConPuntoData> candidatosFisicos =
                new List<MEP3DConectorConPuntoData>();

            foreach (Connector conector in conectoresDestino)
            {
                if (EsConectorDeSuperficie(conector))
                    continue;

                XYZ origenSeguro;

                if (!TryObtenerOrigenConector(conector, out origenSeguro))
                    continue;

                candidatosFisicos.Add(new MEP3DConectorConPuntoData()
                {
                    Conector = conector,
                    Punto = origenSeguro
                });
            }

            if (candidatosFisicos.Count > 0)
            {
                XYZ referenciaPuntaje = EsPuntoValido(puntoClick)
                    ? puntoClick
                    : ObtenerCentroElemento(destino);

                if (!EsPuntoValido(referenciaPuntaje))
                    referenciaPuntaje = ObtenerCentroCurva(movil);

                MEP3DConectorConPuntoData mejor = candidatosFisicos
                    .OrderBy(x =>
                    {
                        double dClick = EsPuntoValido(referenciaPuntaje)
                            ? x.Punto.DistanceTo(referenciaPuntaje)
                            : 0.0;

                        double dMovil = conectoresMovil
                            .Min(m => m.Origin.DistanceTo(x.Punto));

                        return dClick + dMovil * 0.05;
                    })
                    .FirstOrDefault();

                if (mejor != null &&
                    mejor.Conector != null &&
                    EsPuntoValido(mejor.Punto))
                {
                    Connector conectorMovil = conectoresMovil
                        .OrderBy(x => x.Origin.DistanceTo(mejor.Punto))
                        .FirstOrDefault();

                    return new MEP3DReferenciaDestinoData()
                    {
                        ConectorDestino = mejor.Conector,
                        ConectorMovil = conectorMovil,
                        PuntoAlineacion = mejor.Punto,
                        PuntoConexion = mejor.Punto,
                        EsConectorDeSuperficie = false,
                        PuedeConectar = true
                    };
                }
            }

            // Respaldo para una familia sin ConnectorManager utilizable:
            // se toma el centro de la cara más cercana al punto seleccionado.
            XYZ centroCaraRespaldo = ObtenerCentroCaraMasCercana(
                destino,
                puntoClick);

            if (!EsPuntoValido(centroCaraRespaldo))
                centroCaraRespaldo = ObtenerCentroElemento(destino);

            if (!EsPuntoValido(centroCaraRespaldo))
                return null;

            Connector conectorMovilRespaldo = conectoresMovil
                .OrderBy(x => x.Origin.DistanceTo(centroCaraRespaldo))
                .FirstOrDefault();

            return new MEP3DReferenciaDestinoData()
            {
                ConectorDestino = null,
                ConectorMovil = conectorMovilRespaldo,
                PuntoAlineacion = centroCaraRespaldo,
                PuntoConexion = null,
                EsConectorDeSuperficie = true,
                PuedeConectar = false
            };
        }

        private static Result EjecutarAlinearHaciaElementoNoCurva(
            UIDocument uidoc,
            Element destino,
            MEPCurve movil,
            MEP3DReferenciaDestinoData referencia,
            MEP3DSettingsData config,
            bool ejecutarConexion,
            ref string message)
        {
            Document doc = uidoc.Document;

            if (destino == null ||
                movil == null ||
                referencia == null ||
                referencia.ConectorMovil == null ||
                referencia.PuntoAlineacion == null)
            {
                message = "No se recibieron datos válidos para la alineación.";
                return Result.Failed;
            }

            if (movil.Pinned)
            {
                message = "El segundo tramo está fijado y no puede desplazarse.";
                MostrarError("Trazado MEP 3D", message);
                return Result.Failed;
            }

            LocationCurve ubicacionMovil = movil.Location as LocationCurve;
            Line lineaMovil = ubicacionMovil == null
                ? null
                : ubicacionMovil.Curve as Line;

            if (lineaMovil == null)
            {
                message =
                    "La segunda selección debe ser un tramo MEP recto.";

                MostrarError("Trazado MEP 3D", message);
                return Result.Failed;
            }

            Connector conectorMovilOriginal = referencia.ConectorMovil;

            if (conectorMovilOriginal.ConnectorType != ConnectorType.End)
            {
                message =
                    "No se pudo identificar un conector de extremo en el segundo tramo.";

                MostrarError("Trazado MEP 3D", message);
                return Result.Failed;
            }

            if (!EstaLibreSeguro(conectorMovilOriginal))
            {
                message =
                    "El extremo del segundo tramo que se alineará debe estar libre.";

                MostrarError("Trazado MEP 3D", message);
                return Result.Failed;
            }

            ElementId idMovilOriginal = movil.Id;
            ElementId idDestinoOriginal = destino.Id;
            XYZ puntoConectorMovilOriginal = conectorMovilOriginal.Origin;

            double tolerancia = MmAInterno(config.ToleranciaConexionMm);
            double toleranciaGeometrica = Math.Max(
                tolerancia,
                MmAInterno(1.0));

            double longitudMinima = Math.Max(
                doc.Application.ShortCurveTolerance * 1.05,
                MmAInterno(2.0));

            double longitudMovilAntesAlinear = lineaMovil.Length;
            XYZ direccionMovilAntesAlinear = lineaMovil.Direction.Normalize();

            MEP3DConexionDeslizanteData conexionDeslizante =
                ObtenerConexionDeslizanteParaAlineacion(
                    movil,
                    conectorMovilOriginal);

            if (conexionDeslizante.ExtremoOpuestoConectado &&
                !conexionDeslizante.EsValida &&
                !conexionDeslizante.MoverSistemaCompleto)
            {
                message =
                    "El extremo opuesto del segundo tramo está conectado, pero no se pudo " +
                    "identificar un codo y un tramo adyacente recto para reproducir la " +
                    "alineación nativa de Revit.";

                MostrarError("Trazado MEP 3D", message);
                return Result.Failed;
            }

            string motivoAlineacion;
            XYZ vectorAlineacion = CalcularVectorAlineacionComoRevit(
                lineaMovil,
                puntoConectorMovilOriginal,
                referencia.PuntoAlineacion,
                conexionDeslizante,
                toleranciaGeometrica,
                out motivoAlineacion);

            if (vectorAlineacion == null)
            {
                message =
                    "No se pudo calcular el desplazamiento de alineación en planta.\n\n" +
                    motivoAlineacion;

                MostrarError("Trazado MEP 3D", message);
                return Result.Failed;
            }

            XYZ puntoMovilLibreAlineadoEsperado =
                puntoConectorMovilOriginal.Add(vectorAlineacion);

            using (TransactionGroup grupo = new TransactionGroup(
                doc,
                ejecutarConexion
                    ? "MYG - Alinear a aparato y conectar"
                    : "MYG - Mover y alinear a aparato"))
            {
                grupo.Start();

                using (Transaction transaccionAlinear = new Transaction(
                    doc,
                    "Alinear segundo tramo a conector o cara"))
                {
                    transaccionAlinear.Start();
                    ConfigurarFallosAlineacion(transaccionAlinear);

                    try
                    {
                        AplicarAlineacionComoRevit(
                            doc,
                            idMovilOriginal,
                            conexionDeslizante,
                            vectorAlineacion,
                            toleranciaGeometrica,
                            longitudMinima);

                        doc.Regenerate();

                        MEPCurve movilAlineado = doc.GetElement(
                            idMovilOriginal) as MEPCurve;

                        LocationCurve ubicacionAlineada = movilAlineado == null
                            ? null
                            : movilAlineado.Location as LocationCurve;

                        Line lineaAlineada = ubicacionAlineada == null
                            ? null
                            : ubicacionAlineada.Curve as Line;

                        if (lineaAlineada == null)
                        {
                            throw new InvalidOperationException(
                                "No se pudo validar el segundo tramo después de alinearlo.");
                        }

                        if (Math.Abs(
                            lineaAlineada.Length -
                            longitudMovilAntesAlinear) >
                            toleranciaGeometrica)
                        {
                            throw new InvalidOperationException(
                                "La fase de alineación modificó la longitud del segundo tramo.");
                        }

                        double paralelismo = Math.Abs(
                            lineaAlineada.Direction.Normalize().DotProduct(
                                direccionMovilAntesAlinear));

                        if (paralelismo < 0.999999)
                        {
                            throw new InvalidOperationException(
                                "La fase de alineación modificó la dirección del segundo tramo.");
                        }

                        double desfasePlanta = DistanciaPuntoALineaEnPlanta(
                            referencia.PuntoAlineacion,
                            lineaAlineada);

                        if (desfasePlanta > toleranciaGeometrica)
                        {
                            throw new InvalidOperationException(
                                "El segundo tramo no quedó alineado con la referencia. Desfase: " +
                                InternoAMm(desfasePlanta).ToString("0.###") +
                                " mm.");
                        }

                        TransactionStatus estado =
                            transaccionAlinear.Commit();

                        if (estado != TransactionStatus.Committed)
                        {
                            throw new InvalidOperationException(
                                "Revit no pudo completar la fase de alineación.");
                        }
                    }
                    catch (Exception ex)
                    {
                        try
                        {
                            if (transaccionAlinear.GetStatus() ==
                                TransactionStatus.Started)
                            {
                                transaccionAlinear.RollBack();
                            }
                        }
                        catch
                        {
                        }

                        try
                        {
                            grupo.RollBack();
                        }
                        catch
                        {
                        }

                        message =
                            "No se pudo completar la alineación con el aparato.\n\n" +
                            ex.Message;

                        MostrarError("Trazado MEP 3D", message);
                        return Result.Failed;
                    }
                }

                // El botón "Mover y alinear" termina aquí.
                if (!ejecutarConexion)
                {
                    grupo.Assimilate();

                    if (config.SeleccionarResultado)
                    {
                        uidoc.Selection.SetElementIds(
                            ObtenerIdsResultadoAlineacion(
                                idMovilOriginal,
                                conexionDeslizante));
                    }

                    return Result.Succeeded;
                }

                // Si la familia no expone un conector conectable, se conserva la
                // alineación al centro de cara y se finaliza sin generar TRIM.
                if (!referencia.PuedeConectar ||
                    referencia.ConectorDestino == null ||
                    referencia.PuntoConexion == null)
                {
                    grupo.Assimilate();

                    if (config.SeleccionarResultado)
                    {
                        uidoc.Selection.SetElementIds(
                            ObtenerIdsResultadoAlineacion(
                                idMovilOriginal,
                                conexionDeslizante));
                    }

                    return Result.Succeeded;
                }

                using (Transaction transaccionConexion = new Transaction(
                    doc,
                    "TRIM hacia conector de aparato"))
                {
                    transaccionConexion.Start();
                    ConfigurarFallosAlineacion(transaccionConexion);

                    try
                    {
                        Element destinoActual = doc.GetElement(
                            idDestinoOriginal);

                        MEPCurve movilActual = doc.GetElement(
                            idMovilOriginal) as MEPCurve;

                        if (destinoActual == null || movilActual == null)
                        {
                            throw new InvalidOperationException(
                                "No se pudieron recuperar los elementos después de alinearlos.");
                        }

                        Connector conectorDestinoActual =
                            BuscarConectorMasCercano(
                                destinoActual,
                                referencia.PuntoConexion,
                                referencia.ConectorDestino.Domain,
                                false);

                        Connector conectorMovilActual =
                            ObtenerConectorExtremoMasCercano(
                                movilActual,
                                puntoMovilLibreAlineadoEsperado);

                        if (conectorDestinoActual == null ||
                            conectorMovilActual == null)
                        {
                            throw new InvalidOperationException(
                                "No se pudieron recuperar los conectores para la conexión.");
                        }

                        LocationCurve ubicacionActual =
                            movilActual.Location as LocationCurve;

                        Line lineaActual = ubicacionActual == null
                            ? null
                            : ubicacionActual.Curve as Line;

                        if (lineaActual == null)
                        {
                            throw new InvalidOperationException(
                                "El segundo tramo dejó de ser recto.");
                        }

                        int indiceConexion = ObtenerIndiceExtremoMasCercano(
                            lineaActual,
                            conectorMovilActual.Origin);

                        int indiceFijo = indiceConexion == 0 ? 1 : 0;
                        XYZ puntoFijo = lineaActual.GetEndPoint(indiceFijo);
                        XYZ puntoConexion = conectorDestinoActual.Origin;

                        if (puntoFijo.DistanceTo(puntoConexion) <=
                            longitudMinima)
                        {
                            throw new InvalidOperationException(
                                "El tramo resultante sería menor que la longitud mínima admitida por Revit.");
                        }

                        Line nuevaLinea = indiceConexion == 0
                            ? Line.CreateBound(puntoConexion, puntoFijo)
                            : Line.CreateBound(puntoFijo, puntoConexion);

                        ubicacionActual.Curve = nuevaLinea;
                        doc.Regenerate();

                        destinoActual = doc.GetElement(
                            idDestinoOriginal);

                        movilActual = doc.GetElement(
                            idMovilOriginal) as MEPCurve;

                        conectorDestinoActual = BuscarConectorMasCercano(
                            destinoActual,
                            puntoConexion,
                            referencia.ConectorDestino.Domain,
                            false);

                        conectorMovilActual = ObtenerConectorExtremoMasCercano(
                            movilActual,
                            puntoConexion);

                        if (conectorDestinoActual == null ||
                            conectorMovilActual == null)
                        {
                            throw new InvalidOperationException(
                                "No se pudieron recuperar los conectores después del TRIM.");
                        }

                        if (conectorDestinoActual.Origin.DistanceTo(
                            conectorMovilActual.Origin) >
                            toleranciaGeometrica)
                        {
                            throw new InvalidOperationException(
                                "Los conectores no coincidieron después del TRIM.");
                        }

                        ConectarConectores(
                            doc,
                            conectorDestinoActual,
                            conectorMovilActual);

                        TransactionStatus estadoConexion =
                            transaccionConexion.Commit();

                        if (estadoConexion != TransactionStatus.Committed)
                        {
                            throw new InvalidOperationException(
                                "Revit no pudo completar la conexión con el aparato.");
                        }
                    }
                    catch (Exception ex)
                    {
                        try
                        {
                            if (transaccionConexion.GetStatus() ==
                                TransactionStatus.Started)
                            {
                                transaccionConexion.RollBack();
                            }
                        }
                        catch
                        {
                        }

                        try
                        {
                            grupo.RollBack();
                        }
                        catch
                        {
                        }

                        message =
                            "No se pudo completar el TRIM hacia el conector del aparato.\n\n" +
                            ex.Message;

                        MostrarError("Trazado MEP 3D", message);
                        return Result.Failed;
                    }
                }

                grupo.Assimilate();
            }

            if (config.SeleccionarResultado)
            {
                uidoc.Selection.SetElementIds(
                    ObtenerIdsResultadoAlineacion(
                        idMovilOriginal,
                        conexionDeslizante));
            }

            return Result.Succeeded;
        }

        private static ICollection<ElementId> ObtenerIdsResultadoAlineacion(
            ElementId idMovil,
            MEP3DConexionDeslizanteData conexion)
        {
            List<ElementId> ids = new List<ElementId>();

            if (idMovil != null &&
                idMovil != ElementId.InvalidElementId)
            {
                ids.Add(idMovil);
            }

            if (conexion != null &&
                conexion.MoverSistemaCompleto &&
                conexion.SistemaConectadoIds != null)
            {
                ids.AddRange(
                    conexion.SistemaConectadoIds
                        .Where(x =>
                            x != null &&
                            x != ElementId.InvalidElementId));
            }

            if (conexion != null && conexion.EsValida)
            {
                if (conexion.AccesorioId != null &&
                    conexion.AccesorioId != ElementId.InvalidElementId)
                {
                    ids.Add(conexion.AccesorioId);
                }

                if (conexion.TramoAdyacenteId != null &&
                    conexion.TramoAdyacenteId != ElementId.InvalidElementId)
                {
                    ids.Add(conexion.TramoAdyacenteId);
                }
            }

            return ids.Distinct().ToList();
        }

        private static void AplicarAlineacionComoRevit(
            Document doc,
            ElementId idMovilOriginal,
            MEP3DConexionDeslizanteData conexionDeslizante,
            XYZ vectorAlineacion,
            double toleranciaGeometrica,
            double longitudMinima)
        {
            if (doc == null ||
                idMovilOriginal == null ||
                idMovilOriginal == ElementId.InvalidElementId)
            {
                throw new InvalidOperationException(
                    "No se recibió un tramo móvil válido.");
            }

            if (conexionDeslizante != null &&
                conexionDeslizante.MoverSistemaCompleto)
            {
                MoverSistemaConectadoSeguro(
                    doc,
                    idMovilOriginal,
                    conexionDeslizante.SistemaConectadoIds,
                    vectorAlineacion,
                    toleranciaGeometrica);

                return;
            }

            if (conexionDeslizante != null &&
                conexionDeslizante.EsValida)
            {
                MEPCurve movilActual = doc.GetElement(
                    idMovilOriginal) as MEPCurve;

                FamilyInstance accesorioActual = doc.GetElement(
                    conexionDeslizante.AccesorioId) as FamilyInstance;

                MEPCurve adyacenteActual = doc.GetElement(
                    conexionDeslizante.TramoAdyacenteId) as MEPCurve;

                if (movilActual == null ||
                    accesorioActual == null ||
                    adyacenteActual == null)
                {
                    throw new InvalidOperationException(
                        "No se pudieron recuperar el segundo tramo, el codo y el tramo adyacente.");
                }

                if (accesorioActual.Pinned || adyacenteActual.Pinned)
                {
                    throw new InvalidOperationException(
                        "El codo o el tramo adyacente está fijado.");
                }

                Connector conectorAccesorioAdyacente =
                    BuscarConectorMasCercanoSinFiltroDominio(
                        accesorioActual,
                        conexionDeslizante.PuntoAccesorioAdyacenteOriginal);

                Connector conectorTramoAdyacente =
                    ObtenerConectorExtremoMasCercano(
                        adyacenteActual,
                        conexionDeslizante.PuntoTramoAdyacenteOriginal);

                if (conectorAccesorioAdyacente == null ||
                    conectorTramoAdyacente == null)
                {
                    throw new InvalidOperationException(
                        "No se pudieron recuperar los conectores entre el codo y el tramo adyacente.");
                }

                try
                {
                    if (conectorAccesorioAdyacente.IsConnectedTo(
                        conectorTramoAdyacente))
                    {
                        conectorAccesorioAdyacente.DisconnectFrom(
                            conectorTramoAdyacente);
                    }
                }
                catch
                {
                    try
                    {
                        conectorTramoAdyacente.DisconnectFrom(
                            conectorAccesorioAdyacente);
                    }
                    catch
                    {
                    }
                }

                doc.Regenerate();

                List<ElementId> idsTrasladar = new List<ElementId>()
                {
                    idMovilOriginal,
                    conexionDeslizante.AccesorioId
                };

                if (vectorAlineacion != null &&
                    vectorAlineacion.GetLength() > EPS)
                {
                    ElementTransformUtils.MoveElements(
                        doc,
                        idsTrasladar,
                        vectorAlineacion);
                }

                doc.Regenerate();

                accesorioActual = doc.GetElement(
                    conexionDeslizante.AccesorioId) as FamilyInstance;

                adyacenteActual = doc.GetElement(
                    conexionDeslizante.TramoAdyacenteId) as MEPCurve;

                XYZ puntoAccesorioAdyacenteEsperado =
                    conexionDeslizante.PuntoAccesorioAdyacenteOriginal.Add(
                        vectorAlineacion);

                conectorAccesorioAdyacente =
                    BuscarConectorMasCercanoSinFiltroDominio(
                        accesorioActual,
                        puntoAccesorioAdyacenteEsperado);

                if (conectorAccesorioAdyacente == null)
                {
                    throw new InvalidOperationException(
                        "No se pudo recuperar el conector del codo después de alinearlo.");
                }

                LocationCurve ubicacionAdyacente =
                    adyacenteActual.Location as LocationCurve;

                Line lineaAdyacente = ubicacionAdyacente == null
                    ? null
                    : ubicacionAdyacente.Curve as Line;

                if (lineaAdyacente == null)
                {
                    throw new InvalidOperationException(
                        "El tramo adyacente no es recto.");
                }

                int indiceConexionAdyacente =
                    conexionDeslizante.IndiceConexionTramoAdyacente;

                int indiceFijoAdyacente =
                    indiceConexionAdyacente == 0 ? 1 : 0;

                XYZ puntoFijoAdyacente = lineaAdyacente.GetEndPoint(
                    indiceFijoAdyacente);

                XYZ puntoNuevoAdyacente =
                    conectorAccesorioAdyacente.Origin;

                double distanciaAlEjeAdyacente =
                    DistanciaPuntoALineaInfinita(
                        puntoNuevoAdyacente,
                        lineaAdyacente);

                if (distanciaAlEjeAdyacente >
                    toleranciaGeometrica)
                {
                    throw new InvalidOperationException(
                        "El codo saldría del eje del tramo adyacente. Desfase: " +
                        InternoAMm(distanciaAlEjeAdyacente).ToString("0.###") +
                        " mm.");
                }

                if (puntoFijoAdyacente.DistanceTo(
                    puntoNuevoAdyacente) <= longitudMinima)
                {
                    throw new InvalidOperationException(
                        "El tramo adyacente quedaría por debajo de la longitud mínima.");
                }

                Line nuevaLineaAdyacente =
                    indiceConexionAdyacente == 0
                        ? Line.CreateBound(
                            puntoNuevoAdyacente,
                            puntoFijoAdyacente)
                        : Line.CreateBound(
                            puntoFijoAdyacente,
                            puntoNuevoAdyacente);

                ubicacionAdyacente.Curve = nuevaLineaAdyacente;
                doc.Regenerate();

                adyacenteActual = doc.GetElement(
                    conexionDeslizante.TramoAdyacenteId) as MEPCurve;

                conectorTramoAdyacente =
                    ObtenerConectorExtremoMasCercano(
                        adyacenteActual,
                        puntoNuevoAdyacente);

                accesorioActual = doc.GetElement(
                    conexionDeslizante.AccesorioId) as FamilyInstance;

                conectorAccesorioAdyacente =
                    BuscarConectorMasCercanoSinFiltroDominio(
                        accesorioActual,
                        puntoNuevoAdyacente);

                if (conectorTramoAdyacente == null ||
                    conectorAccesorioAdyacente == null)
                {
                    throw new InvalidOperationException(
                        "No se pudieron recuperar los conectores para restaurar la unión inferior.");
                }

                if (conectorTramoAdyacente.Origin.DistanceTo(
                    conectorAccesorioAdyacente.Origin) >
                    toleranciaGeometrica)
                {
                    throw new InvalidOperationException(
                        "El codo y el tramo adyacente no coincidieron después de la alineación.");
                }

                try
                {
                    if (!conectorAccesorioAdyacente.IsConnectedTo(
                        conectorTramoAdyacente))
                    {
                        conectorAccesorioAdyacente.ConnectTo(
                            conectorTramoAdyacente);
                    }
                }
                catch
                {
                    conectorTramoAdyacente.ConnectTo(
                        conectorAccesorioAdyacente);
                }
            }
            else
            {
                if (vectorAlineacion != null &&
                    vectorAlineacion.GetLength() > EPS)
                {
                    ElementTransformUtils.MoveElement(
                        doc,
                        idMovilOriginal,
                        vectorAlineacion);
                }
            }
        }

        private static bool TryObtenerOrigenConector(
            Connector conector,
            out XYZ origen)
        {
            origen = null;

            if (conector == null)
                return false;

            try
            {
                origen = conector.Origin;
                return EsPuntoValido(origen);
            }
            catch
            {
                origen = null;
                return false;
            }
        }

        private static XYZ ObtenerPuntoConectorSuperficieRapido(
            IList<Connector> conectores,
            XYZ puntoReferencia)
        {
            if (conectores == null || conectores.Count == 0)
                return null;

            XYZ mejor = null;
            double mejorDistancia = double.MaxValue;

            foreach (Connector conector in conectores)
            {
                if (conector == null)
                    continue;

                XYZ punto = null;

                try
                {
                    Transform sistema = conector.CoordinateSystem;

                    if (sistema != null)
                        punto = sistema.Origin;
                }
                catch
                {
                    punto = null;
                }

                if (!EsPuntoValido(punto))
                    continue;

                double distancia = EsPuntoValido(puntoReferencia)
                    ? punto.DistanceTo(puntoReferencia)
                    : 0.0;

                if (distancia < mejorDistancia)
                {
                    mejorDistancia = distancia;
                    mejor = punto;
                }
            }

            return mejor;
        }

        private static XYZ ObtenerPuntoConectorCaraDesdeFamilia(
            Document documentoProyecto,
            Element elemento,
            XYZ puntoClick,
            XYZ puntoAlternativo)
        {
            FamilyInstance instancia = elemento as FamilyInstance;

            if (documentoProyecto == null ||
                instancia == null ||
                instancia.Symbol == null ||
                instancia.Symbol.Family == null)
            {
                return null;
            }

            try
            {
                if (instancia.Symbol.Family.IsInPlace)
                    return null;
            }
            catch
            {
            }

            Transform transformacionInstancia = null;

            try
            {
                transformacionInstancia = instancia.GetTransform();
            }
            catch
            {
                transformacionInstancia = null;
            }

            if (transformacionInstancia == null)
                transformacionInstancia = Transform.Identity;

            XYZ referencia = EsPuntoValido(puntoClick)
                ? puntoClick
                : puntoAlternativo;

            if (!EsPuntoValido(referencia))
                referencia = ObtenerCentroElemento(elemento);

            string claveCache = ObtenerClaveCacheConectoresFamilia(
                documentoProyecto,
                instancia);

            List<MEP3DPuntoConectorFamiliaData> puntosLocales =
                ObtenerPuntosConectoresFamiliaDesdeCache(claveCache);

            if (puntosLocales == null)
            {
                puntosLocales = CargarPuntosConectoresFamilia(
                    documentoProyecto,
                    instancia);

                GuardarPuntosConectoresFamiliaEnCache(
                    claveCache,
                    puntosLocales);
            }

            if (puntosLocales == null || puntosLocales.Count == 0)
                return null;

            XYZ mejorPunto = null;
            double mejorPuntaje = double.MaxValue;

            foreach (MEP3DPuntoConectorFamiliaData dato in puntosLocales)
            {
                if (dato == null || !EsPuntoValido(dato.PuntoLocal))
                    continue;

                XYZ puntoProyecto = null;

                try
                {
                    puntoProyecto = transformacionInstancia.OfPoint(
                        dato.PuntoLocal);
                }
                catch
                {
                    puntoProyecto = null;
                }

                if (!EsPuntoValido(puntoProyecto))
                    continue;

                double puntaje = EsPuntoValido(referencia)
                    ? puntoProyecto.DistanceTo(referencia)
                    : 0.0;

                if (dato.EsPrimario)
                    puntaje -= MmAInterno(0.1);

                if (puntaje < mejorPuntaje)
                {
                    mejorPuntaje = puntaje;
                    mejorPunto = puntoProyecto;
                }
            }

            return mejorPunto;
        }

        private static string ObtenerClaveCacheConectoresFamilia(
            Document documentoProyecto,
            FamilyInstance instancia)
        {
            if (documentoProyecto == null ||
                instancia == null ||
                instancia.Symbol == null ||
                instancia.Symbol.Family == null)
            {
                return null;
            }

            string documento = "";
            string familia = "";
            string simbolo = "";

            try
            {
                documento = documentoProyecto.GetHashCode().ToString();
            }
            catch
            {
                documento = documentoProyecto.Title ?? "";
            }

            try
            {
                familia = instancia.Symbol.Family.UniqueId ?? "";
            }
            catch
            {
                familia = instancia.Symbol.Family.Name ?? "";
            }

            try
            {
                simbolo = instancia.Symbol.UniqueId ?? "";
            }
            catch
            {
                simbolo = instancia.Symbol.Id.Value.ToString();
            }

            return documento + "|" + familia + "|" + simbolo;
        }

        private static List<MEP3DPuntoConectorFamiliaData>
            ObtenerPuntosConectoresFamiliaDesdeCache(
                string clave)
        {
            if (string.IsNullOrWhiteSpace(clave))
                return null;

            lock (CacheConectoresFamiliaSync)
            {
                MEP3DConectorFamiliaCacheData entrada;

                if (!CacheConectoresFamilia.TryGetValue(
                    clave,
                    out entrada) ||
                    entrada == null)
                {
                    return null;
                }

                entrada.OrdenUso = ++_ordenUsoCacheConectoresFamilia;

                return entrada.Puntos;
            }
        }

        private static void GuardarPuntosConectoresFamiliaEnCache(
            string clave,
            List<MEP3DPuntoConectorFamiliaData> puntos)
        {
            if (string.IsNullOrWhiteSpace(clave))
                return;

            if (puntos == null)
                puntos = new List<MEP3DPuntoConectorFamiliaData>();

            lock (CacheConectoresFamiliaSync)
            {
                CacheConectoresFamilia[clave] =
                    new MEP3DConectorFamiliaCacheData()
                    {
                        Puntos = puntos,
                        OrdenUso = ++_ordenUsoCacheConectoresFamilia
                    };

                if (CacheConectoresFamilia.Count <=
                    MAX_CACHE_CONECTORES_FAMILIA)
                {
                    return;
                }

                string claveAntigua = CacheConectoresFamilia
                    .OrderBy(x => x.Value == null
                        ? long.MinValue
                        : x.Value.OrdenUso)
                    .Select(x => x.Key)
                    .FirstOrDefault();

                if (!string.IsNullOrWhiteSpace(claveAntigua))
                    CacheConectoresFamilia.Remove(claveAntigua);
            }
        }

        private static List<MEP3DPuntoConectorFamiliaData>
            CargarPuntosConectoresFamilia(
                Document documentoProyecto,
                FamilyInstance instancia)
        {
            List<MEP3DPuntoConectorFamiliaData> resultado =
                new List<MEP3DPuntoConectorFamiliaData>();

            if (documentoProyecto == null ||
                instancia == null ||
                instancia.Symbol == null ||
                instancia.Symbol.Family == null)
            {
                return resultado;
            }

            Document documentoFamilia = null;
            bool cerrarDocumento = false;

            try
            {
                documentoFamilia = documentoProyecto.EditFamily(
                    instancia.Symbol.Family);

                cerrarDocumento = documentoFamilia != null;

                if (documentoFamilia == null ||
                    !documentoFamilia.IsFamilyDocument)
                {
                    return resultado;
                }

                IEnumerable<ConnectorElement> conectoresFamilia =
                    new FilteredElementCollector(documentoFamilia)
                        .OfClass(typeof(ConnectorElement))
                        .Cast<ConnectorElement>();

                foreach (ConnectorElement conectorFamilia in conectoresFamilia)
                {
                    if (conectorFamilia == null)
                        continue;

                    XYZ puntoLocal = null;

                    try
                    {
                        puntoLocal = conectorFamilia.Origin;
                    }
                    catch
                    {
                        puntoLocal = null;
                    }

                    if (!EsPuntoValido(puntoLocal))
                        continue;

                    bool esPrimario = false;

                    try
                    {
                        esPrimario = conectorFamilia.IsPrimary;
                    }
                    catch
                    {
                    }

                    resultado.Add(
                        new MEP3DPuntoConectorFamiliaData()
                        {
                            PuntoLocal = puntoLocal,
                            EsPrimario = esPrimario
                        });
                }
            }
            catch
            {
                resultado.Clear();
            }
            finally
            {
                if (cerrarDocumento && documentoFamilia != null)
                {
                    try
                    {
                        documentoFamilia.Close(false);
                    }
                    catch
                    {
                    }
                }
            }

            return resultado;
        }

        private static bool EsConectorDeSuperficie(
            Connector conector)
        {
            if (conector == null)
                return false;

            try
            {
                string nombreTipo = conector.ConnectorType.ToString();

                return nombreTipo.IndexOf(
                    "Surface",
                    StringComparison.OrdinalIgnoreCase) >= 0;
            }
            catch
            {
                return false;
            }
        }

        private static bool EstaConectadoSeguro(
            Connector conector)
        {
            if (conector == null)
                return false;

            try
            {
                return conector.IsConnected;
            }
            catch
            {
                // Algunos conectores de superficie/By Face no permiten consultar
                // ConnectionStatus. Para tareas de alineación se consideran utilizables.
                return false;
            }
        }

        private static bool EstaLibreSeguro(
            Connector conector)
        {
            return !EstaConectadoSeguro(conector);
        }

        private static bool EsPuntoValido(
            XYZ punto)
        {
            if (punto == null)
                return false;

            return !double.IsNaN(punto.X) &&
                   !double.IsNaN(punto.Y) &&
                   !double.IsNaN(punto.Z) &&
                   !double.IsInfinity(punto.X) &&
                   !double.IsInfinity(punto.Y) &&
                   !double.IsInfinity(punto.Z);
        }

        private static XYZ ObtenerCentroElemento(
            Element elemento)
        {
            if (elemento == null)
                return null;

            try
            {
                BoundingBoxXYZ caja = elemento.get_BoundingBox(null);

                if (caja != null)
                {
                    return caja.Min.Add(caja.Max).Multiply(0.5);
                }
            }
            catch
            {
            }

            LocationPoint punto = elemento.Location as LocationPoint;

            if (punto != null)
                return punto.Point;

            LocationCurve curva = elemento.Location as LocationCurve;

            if (curva != null && curva.Curve != null)
                return curva.Curve.Evaluate(0.5, true);

            return null;
        }

        private static XYZ ObtenerCentroCaraAsociadaAlConector(
            Element elemento,
            Connector conector,
            XYZ puntoClick)
        {
            if (elemento == null)
                return null;

            XYZ puntoDesdeFamilia = ObtenerPuntoConectorSuperficieRapido(
                conector == null
                    ? new List<Connector>()
                    : new List<Connector>() { conector },
                puntoClick);

            if (!EsPuntoValido(puntoDesdeFamilia))
            {
                puntoDesdeFamilia = ObtenerPuntoConectorCaraDesdeFamilia(
                    elemento.Document,
                    elemento,
                    puntoClick,
                    ObtenerCentroElemento(elemento));
            }

            if (EsPuntoValido(puntoDesdeFamilia))
                return puntoDesdeFamilia;

            XYZ centroCara = ObtenerCentroCaraMasCercana(
                elemento,
                puntoClick);

            if (EsPuntoValido(centroCara))
                return centroCara;

            XYZ origenSeguro;

            if (TryObtenerOrigenConector(conector, out origenSeguro))
                return origenSeguro;

            return ObtenerCentroElemento(elemento);
        }

        private static XYZ ObtenerCentroCaraMasCercana(
            Element elemento,
            XYZ puntoReferencia)
        {
            if (elemento == null)
                return null;

            List<Face> caras = ObtenerCarasElemento(elemento);

            if (caras.Count == 0)
                return null;

            XYZ centroElemento = ObtenerCentroElemento(elemento);
            XYZ puntoBase = EsPuntoValido(puntoReferencia)
                ? puntoReferencia
                : centroElemento;

            XYZ mejor = null;
            double mejorPuntaje = double.MaxValue;

            foreach (Face cara in caras)
            {
                XYZ centro = ObtenerCentroAproximadoCara(cara);

                if (!EsPuntoValido(centro))
                    continue;

                double distancia = EsPuntoValido(puntoBase)
                    ? centro.DistanceTo(puntoBase)
                    : 0.0;

                double area = 0.0;

                try
                {
                    area = cara.Area;
                }
                catch
                {
                    area = 0.0;
                }

                double puntaje = distancia - area * 0.0001;

                if (puntaje < mejorPuntaje)
                {
                    mejorPuntaje = puntaje;
                    mejor = centro;
                }
            }

            return mejor;
        }

        private static List<Face> ObtenerCarasElemento(
            Element elemento)
        {
            List<Face> caras = new List<Face>();

            if (elemento == null)
                return caras;

            try
            {
                Options opciones = new Options()
                {
                    // Solo se requiere geometría para un respaldo visual; no se usan
                    // referencias estables. Desactivar estas opciones reduce mucho el
                    // costo de extracción en familias complejas.
                    ComputeReferences = false,
                    IncludeNonVisibleObjects = false,
                    DetailLevel = ViewDetailLevel.Medium
                };

                GeometryElement geometria = elemento.get_Geometry(
                    opciones);

                RecopilarCarasGeometria(
                    geometria,
                    caras);
            }
            catch
            {
            }

            return caras;
        }

        private static void RecopilarCarasGeometria(
            GeometryElement geometria,
            List<Face> caras)
        {
            if (geometria == null || caras == null)
                return;

            foreach (GeometryObject objeto in geometria)
            {
                Solid solido = objeto as Solid;

                if (solido != null)
                {
                    foreach (Face cara in solido.Faces)
                    {
                        if (cara != null)
                            caras.Add(cara);
                    }

                    continue;
                }

                GeometryInstance instancia =
                    objeto as GeometryInstance;

                if (instancia != null)
                {
                    GeometryElement geometriaInstancia = null;

                    try
                    {
                        geometriaInstancia =
                            instancia.GetInstanceGeometry();
                    }
                    catch
                    {
                    }

                    RecopilarCarasGeometria(
                        geometriaInstancia,
                        caras);
                }
            }
        }

        private static XYZ ObtenerCentroAproximadoCara(
            Face cara)
        {
            if (cara == null)
                return null;

            // Ruta rápida: evaluar el centro del dominio UV evita triangular toda la
            // cara. Para el respaldo geométrico es suficiente y es mucho más ligero.
            try
            {
                BoundingBoxUV cajaUv = cara.GetBoundingBox();

                if (cajaUv != null &&
                    cajaUv.Min != null &&
                    cajaUv.Max != null)
                {
                    UV centroUv = new UV(
                        (cajaUv.Min.U + cajaUv.Max.U) * 0.5,
                        (cajaUv.Min.V + cajaUv.Max.V) * 0.5);

                    XYZ evaluado = cara.Evaluate(centroUv);

                    if (EsPuntoValido(evaluado))
                        return evaluado;
                }
            }
            catch
            {
            }

            // Respaldo para caras cuyo dominio UV no permite una evaluación directa.
            try
            {
                Mesh malla = cara.Triangulate();

                if (malla != null &&
                    malla.Vertices != null &&
                    malla.Vertices.Count > 0)
                {
                    XYZ suma = XYZ.Zero;

                    foreach (XYZ vertice in malla.Vertices)
                    {
                        suma = suma.Add(vertice);
                    }

                    return suma.Divide(
                        malla.Vertices.Count);
                }
            }
            catch
            {
            }

            try
            {
                BoundingBoxUV caja = cara.GetBoundingBox();

                if (caja != null)
                {
                    UV centroUv = new UV(
                        (caja.Min.U + caja.Max.U) * 0.5,
                        (caja.Min.V + caja.Max.V) * 0.5);

                    return cara.Evaluate(centroUv);
                }
            }
            catch
            {
            }

            return null;
        }

        private static XYZ ObtenerNormalAproximadaCara(
            Face cara)
        {
            if (cara == null)
                return null;

            PlanarFace plana = cara as PlanarFace;

            if (plana != null)
                return plana.FaceNormal;

            try
            {
                BoundingBoxUV caja = cara.GetBoundingBox();

                if (caja != null)
                {
                    UV centroUv = new UV(
                        (caja.Min.U + caja.Max.U) * 0.5,
                        (caja.Min.V + caja.Max.V) * 0.5);

                    return cara.ComputeNormal(centroUv);
                }
            }
            catch
            {
            }

            return null;
        }

        private sealed class MEP3DConexionDeslizanteData
        {
            public bool EsValida { get; set; }
            public bool ExtremoOpuestoConectado { get; set; }

            // Cuando el extremo opuesto está conectado a cualquier elemento MEP,
            // la alineación traslada todo el sistema conectado como un único bloque.
            // De esta forma no se exige que exista un codo ni un tramo adyacente recto.
            public bool MoverSistemaCompleto { get; set; }
            public HashSet<ElementId> SistemaConectadoIds { get; set; }

            public ElementId AccesorioId { get; set; }
            public ElementId TramoAdyacenteId { get; set; }
            public XYZ PuntoMovilOpuestoOriginal { get; set; }
            public XYZ PuntoAccesorioMovilOriginal { get; set; }
            public XYZ PuntoAccesorioAdyacenteOriginal { get; set; }
            public XYZ PuntoTramoAdyacenteOriginal { get; set; }
            public int IndiceConexionTramoAdyacente { get; set; }
            public XYZ DireccionDeslizamiento { get; set; }

            public MEP3DConexionDeslizanteData()
            {
                EsValida = false;
                ExtremoOpuestoConectado = false;
                MoverSistemaCompleto = false;
                SistemaConectadoIds = new HashSet<ElementId>();
                AccesorioId = ElementId.InvalidElementId;
                TramoAdyacenteId = ElementId.InvalidElementId;
                IndiceConexionTramoAdyacente = -1;
                DireccionDeslizamiento = null;
            }
        }

        private static Result EjecutarTrimMismoPlanoConAccesorio(
            UIDocument uidoc,
            MEPCurve destino,
            MEPCurve movil,
            ConnectorPair par,
            MEP3DSettingsData config,
            bool ejecutarTrim,
            ref string message)
        {
            Document doc = uidoc.Document;

            if (destino == null || movil == null || par == null)
            {
                message = "No se pudieron leer los tramos MEP seleccionados.";
                return Result.Failed;
            }

            if (par.Destino == null || par.Movil == null)
            {
                message = "No se pudieron identificar los conectores de los extremos.";
                MostrarError("Trazado MEP 3D", message);
                return Result.Failed;
            }

            if (par.Destino.ConnectorType != ConnectorType.End ||
                par.Movil.ConnectorType != ConnectorType.End)
            {
                message =
                    "Mover, alinear y conectar solo admite conectores de extremo " +
                    "en tramos MEP rectos.";

                MostrarError("Trazado MEP 3D", message);
                return Result.Failed;
            }

            if (par.Destino.IsConnected || par.Movil.IsConnected)
            {
                message = "Los dos extremos que se unirán deben estar libres.";
                MostrarError("Trazado MEP 3D", message);
                return Result.Failed;
            }

            if (destino.Pinned || movil.Pinned)
            {
                message = "No se puede ejecutar la operación porque uno de los tramos está fijado.";
                MostrarError("Trazado MEP 3D", message);
                return Result.Failed;
            }

            LocationCurve ubicacionDestino = destino.Location as LocationCurve;
            LocationCurve ubicacionMovil = movil.Location as LocationCurve;

            Line lineaDestino = ubicacionDestino == null
                ? null
                : ubicacionDestino.Curve as Line;

            Line lineaMovil = ubicacionMovil == null
                ? null
                : ubicacionMovil.Curve as Line;

            if (lineaDestino == null || lineaMovil == null)
            {
                message = ejecutarTrim
                    ? "Mover, alinear y conectar solo está disponible para tramos MEP rectos."
                    : "Mover y alinear solo está disponible para tramos MEP rectos.";

                MostrarError("Trazado MEP 3D", message);
                return Result.Failed;
            }

            ElementId idDestinoOriginal = destino.Id;
            ElementId idMovilOriginal = movil.Id;

            XYZ puntoConectorDestinoOriginal = par.Destino.Origin;
            XYZ puntoConectorMovilOriginal = par.Movil.Origin;

            int indiceConexionDestino = ObtenerIndiceExtremoMasCercano(
                lineaDestino,
                puntoConectorDestinoOriginal);

            int indiceConexionMovil = ObtenerIndiceExtremoMasCercano(
                lineaMovil,
                puntoConectorMovilOriginal);

            int indiceFijoDestino = indiceConexionDestino == 0 ? 1 : 0;
            int indiceFijoMovil = indiceConexionMovil == 0 ? 1 : 0;

            double tolerancia = MmAInterno(config.ToleranciaConexionMm);
            double toleranciaGeometrica = Math.Max(
                tolerancia,
                MmAInterno(1.0));

            double longitudMinima = Math.Max(
                doc.Application.ShortCurveTolerance * 1.05,
                MmAInterno(2.0));

            double longitudMovilAntesAlinear = lineaMovil.Length;
            XYZ direccionMovilAntesAlinear = lineaMovil.Direction.Normalize();

            MEP3DConexionDeslizanteData conexionDeslizante =
                ObtenerConexionDeslizanteParaAlineacion(
                    movil,
                    par.Movil);

            if (conexionDeslizante.ExtremoOpuestoConectado &&
                !conexionDeslizante.EsValida &&
                !conexionDeslizante.MoverSistemaCompleto)
            {
                message =
                    "El extremo opuesto del segundo tramo está conectado, pero no se pudo " +
                    "identificar una forma válida de mover su sistema conectado.";

                MostrarError("Trazado MEP 3D", message);
                return Result.Failed;
            }

            string motivoAlineacion;
            XYZ vectorAlineacion = CalcularVectorAlineacionComoRevit(
                lineaMovil,
                puntoConectorMovilOriginal,
                puntoConectorDestinoOriginal,
                conexionDeslizante,
                toleranciaGeometrica,
                out motivoAlineacion);

            if (vectorAlineacion == null)
            {
                message =
                    "No se pudo calcular el desplazamiento de alineación en planta.\n\n" +
                    motivoAlineacion;

                MostrarError("Trazado MEP 3D", message);
                return Result.Failed;
            }

            FamilyInstance accesorioSuperior = null;

            // =============================================================
            // BOTÓN: MOVER Y ALINEAR
            // =============================================================
            // En este caso sí se confirma la alineación como una operación
            // independiente, porque no habrá un TRIM posterior que complete
            // o estabilice el estado geométrico del sistema.
            if (!ejecutarTrim)
            {
                using (Transaction transaccionAlinear = new Transaction(
                    doc,
                    "MYG - Mover y alinear como Revit"))
                {
                    transaccionAlinear.Start();
                    ConfigurarFallosAlineacion(transaccionAlinear);

                    try
                    {
                        AplicarAlineacionComoRevit(
                            doc,
                            idMovilOriginal,
                            conexionDeslizante,
                            vectorAlineacion,
                            toleranciaGeometrica,
                            longitudMinima);

                        doc.Regenerate();

                        MEPCurve movilAlineado = doc.GetElement(
                            idMovilOriginal) as MEPCurve;

                        LocationCurve ubicacionMovilAlineado =
                            movilAlineado == null
                                ? null
                                : movilAlineado.Location as LocationCurve;

                        Line lineaMovilAlineada =
                            ubicacionMovilAlineado == null
                                ? null
                                : ubicacionMovilAlineado.Curve as Line;

                        if (lineaMovilAlineada == null)
                        {
                            throw new InvalidOperationException(
                                "No se pudo validar el segundo tramo después de alinearlo.");
                        }

                        if (Math.Abs(
                            lineaMovilAlineada.Length -
                            longitudMovilAntesAlinear) >
                            toleranciaGeometrica)
                        {
                            throw new InvalidOperationException(
                                "La fase de alineación modificó la longitud del segundo tramo.");
                        }

                        double paralelismo = Math.Abs(
                            lineaMovilAlineada.Direction.Normalize().DotProduct(
                                direccionMovilAntesAlinear));

                        if (paralelismo < 0.999999)
                        {
                            throw new InvalidOperationException(
                                "La fase de alineación modificó la dirección del segundo tramo.");
                        }

                        double distanciaReferenciaPlanta =
                            DistanciaPuntoALineaEnPlanta(
                                puntoConectorDestinoOriginal,
                                lineaMovilAlineada);

                        if (distanciaReferenciaPlanta > toleranciaGeometrica)
                        {
                            throw new InvalidOperationException(
                                "El segundo tramo no quedó alineado con la referencia en planta. " +
                                "Desfase: " +
                                InternoAMm(distanciaReferenciaPlanta).ToString("0.###") +
                                " mm.");
                        }

                        TransactionStatus estadoAlinear =
                            transaccionAlinear.Commit();

                        // Commit puede devolver Pending durante el procesamiento de
                        // fallos. Eso no significa que la alineación haya fracasado.
                        // Solo se considera fallo real cuando Revit la revierte.
                        if (estadoAlinear == TransactionStatus.RolledBack)
                        {
                            throw new InvalidOperationException(
                                "Revit revirtió la fase de alineación.");
                        }
                    }
                    catch (Exception ex)
                    {
                        try
                        {
                            if (transaccionAlinear.GetStatus() ==
                                TransactionStatus.Started)
                            {
                                transaccionAlinear.RollBack();
                            }
                        }
                        catch
                        {
                        }

                        message =
                            "No se pudo completar MOVER Y ALINEAR.\n\n" +
                            ex.Message;

                        MostrarError("Trazado MEP 3D", message);
                        return Result.Failed;
                    }
                }

                if (config.SeleccionarResultado)
                {
                    List<ElementId> seleccionAlineada = new List<ElementId>()
                    {
                        idMovilOriginal
                    };

                    if (conexionDeslizante.MoverSistemaCompleto &&
                        conexionDeslizante.SistemaConectadoIds != null)
                    {
                        seleccionAlineada.AddRange(
                            conexionDeslizante.SistemaConectadoIds
                                .Where(x =>
                                    x != null &&
                                    x != ElementId.InvalidElementId));
                    }

                    if (conexionDeslizante.EsValida)
                    {
                        seleccionAlineada.Add(
                            conexionDeslizante.AccesorioId);
                        seleccionAlineada.Add(
                            conexionDeslizante.TramoAdyacenteId);
                    }

                    uidoc.Selection.SetElementIds(
                        seleccionAlineada
                            .Where(x =>
                                x != null &&
                                x != ElementId.InvalidElementId)
                            .Distinct()
                            .ToList());
                }

                return Result.Succeeded;
            }

            // =============================================================
            // BOTÓN: MOVER, ALINEAR Y CONECTAR
            // =============================================================
            // La alineación y el TRIM se ejecutan dentro de UNA SOLA transacción.
            // Antes se confirmaba la alineación en una transacción independiente.
            // Revit podía rechazar ese estado intermedio aunque el TRIM posterior
            // fuese perfectamente válido, provocando un falso mensaje de error.
            using (Transaction transaccionCompleta = new Transaction(
                doc,
                "MYG - Alinear, TRIM y conectar"))
            {
                transaccionCompleta.Start();
                ConfigurarFallosAlineacion(transaccionCompleta);

                try
                {
                    // ---------------------------------------------------------
                    // FASE 1: MOVER Y ALINEAR, SIN COMMIT INTERMEDIO
                    // ---------------------------------------------------------
                    AplicarAlineacionComoRevit(
                        doc,
                        idMovilOriginal,
                        conexionDeslizante,
                        vectorAlineacion,
                        toleranciaGeometrica,
                        longitudMinima);

                    doc.Regenerate();

                    MEPCurve movilAlineado = doc.GetElement(
                        idMovilOriginal) as MEPCurve;

                    LocationCurve ubicacionMovilAlineado =
                        movilAlineado == null
                            ? null
                            : movilAlineado.Location as LocationCurve;

                    Line lineaMovilAlineada =
                        ubicacionMovilAlineado == null
                            ? null
                            : ubicacionMovilAlineado.Curve as Line;

                    if (lineaMovilAlineada == null)
                    {
                        throw new InvalidOperationException(
                            "No se pudo validar el segundo tramo después de alinearlo.");
                    }

                    if (Math.Abs(
                        lineaMovilAlineada.Length -
                        longitudMovilAntesAlinear) >
                        toleranciaGeometrica)
                    {
                        throw new InvalidOperationException(
                            "La alineación modificó la longitud del segundo tramo.");
                    }

                    double paralelismo = Math.Abs(
                        lineaMovilAlineada.Direction.Normalize().DotProduct(
                            direccionMovilAntesAlinear));

                    if (paralelismo < 0.999999)
                    {
                        throw new InvalidOperationException(
                            "La alineación modificó la dirección del segundo tramo.");
                    }

                    double distanciaReferenciaPlanta =
                        DistanciaPuntoALineaEnPlanta(
                            puntoConectorDestinoOriginal,
                            lineaMovilAlineada);

                    if (distanciaReferenciaPlanta > toleranciaGeometrica)
                    {
                        throw new InvalidOperationException(
                            "El segundo tramo no quedó alineado con la referencia en planta. " +
                            "Desfase: " +
                            InternoAMm(distanciaReferenciaPlanta).ToString("0.###") +
                            " mm.");
                    }

                    // ---------------------------------------------------------
                    // FASE 2: TRIM / EXTEND TO CORNER, MISMA TRANSACCIÓN
                    // ---------------------------------------------------------
                    MEPCurve destinoActual = doc.GetElement(
                        idDestinoOriginal) as MEPCurve;

                    MEPCurve movilActual = doc.GetElement(
                        idMovilOriginal) as MEPCurve;

                    if (destinoActual == null || movilActual == null)
                    {
                        throw new InvalidOperationException(
                            "Revit reemplazó inesperadamente uno de los tramos.");
                    }

                    LocationCurve ubicacionDestinoActual =
                        destinoActual.Location as LocationCurve;

                    LocationCurve ubicacionMovilActual =
                        movilActual.Location as LocationCurve;

                    Line lineaDestinoActual =
                        ubicacionDestinoActual == null
                            ? null
                            : ubicacionDestinoActual.Curve as Line;

                    Line lineaMovilActual =
                        ubicacionMovilActual == null
                            ? null
                            : ubicacionMovilActual.Curve as Line;

                    if (lineaDestinoActual == null ||
                        lineaMovilActual == null)
                    {
                        throw new InvalidOperationException(
                            "No se pudieron recuperar los ejes rectos para ejecutar TRIM.");
                    }

                    XYZ puntoInterseccion;
                    string motivoInterseccion;

                    if (!CalcularInterseccionLineas3D(
                        lineaDestinoActual,
                        lineaMovilActual,
                        toleranciaGeometrica,
                        out puntoInterseccion,
                        out motivoInterseccion))
                    {
                        throw new InvalidOperationException(
                            "Los ejes no se pueden unir mediante TRIM. " +
                            motivoInterseccion);
                    }

                    XYZ puntoFijoDestinoActual =
                        lineaDestinoActual.GetEndPoint(
                            indiceFijoDestino);

                    XYZ puntoFijoMovilActual =
                        lineaMovilActual.GetEndPoint(
                            indiceFijoMovil);

                    XYZ direccionHaciaLibreDestino =
                        lineaDestinoActual.GetEndPoint(
                            indiceConexionDestino).Subtract(
                                puntoFijoDestinoActual);

                    XYZ direccionHaciaLibreMovil =
                        lineaMovilActual.GetEndPoint(
                            indiceConexionMovil).Subtract(
                                puntoFijoMovilActual);

                    if (direccionHaciaLibreDestino.GetLength() < EPS ||
                        direccionHaciaLibreMovil.GetLength() < EPS)
                    {
                        throw new InvalidOperationException(
                            "Uno de los tramos tiene una dirección no válida para TRIM.");
                    }

                    double avanceDestino = puntoInterseccion.Subtract(
                        puntoFijoDestinoActual).DotProduct(
                            direccionHaciaLibreDestino.Normalize());

                    double avanceMovil = puntoInterseccion.Subtract(
                        puntoFijoMovilActual).DotProduct(
                            direccionHaciaLibreMovil.Normalize());

                    if (avanceDestino <= longitudMinima)
                    {
                        throw new InvalidOperationException(
                            "El punto de TRIM queda sobre o detrás del extremo fijo del primer tramo.");
                    }

                    if (avanceMovil <= longitudMinima)
                    {
                        throw new InvalidOperationException(
                            "El punto de TRIM queda sobre o detrás del extremo conectado del segundo tramo.");
                    }

                    Line nuevaLineaDestino =
                        indiceConexionDestino == 0
                            ? Line.CreateBound(
                                puntoInterseccion,
                                puntoFijoDestinoActual)
                            : Line.CreateBound(
                                puntoFijoDestinoActual,
                                puntoInterseccion);

                    Line nuevaLineaMovil =
                        indiceConexionMovil == 0
                            ? Line.CreateBound(
                                puntoInterseccion,
                                puntoFijoMovilActual)
                            : Line.CreateBound(
                                puntoFijoMovilActual,
                                puntoInterseccion);

                    ubicacionDestinoActual.Curve = nuevaLineaDestino;
                    ubicacionMovilActual.Curve = nuevaLineaMovil;
                    doc.Regenerate();

                    destinoActual = doc.GetElement(
                        idDestinoOriginal) as MEPCurve;

                    movilActual = doc.GetElement(
                        idMovilOriginal) as MEPCurve;

                    Connector conectorDestinoSuperior =
                        ObtenerConectorExtremoMasCercano(
                            destinoActual,
                            puntoInterseccion);

                    Connector conectorMovilSuperior =
                        ObtenerConectorExtremoMasCercano(
                            movilActual,
                            puntoInterseccion);

                    if (conectorDestinoSuperior == null ||
                        conectorMovilSuperior == null)
                    {
                        throw new InvalidOperationException(
                            "No se pudieron recuperar los conectores después del TRIM.");
                    }

                    accesorioSuperior =
                        CrearConexionConAccesorioRobusta(
                            doc,
                            conectorDestinoSuperior,
                            conectorMovilSuperior);

                    TransactionStatus estadoCompleto =
                        transaccionCompleta.Commit();

                    if (estadoCompleto == TransactionStatus.RolledBack)
                    {
                        throw new InvalidOperationException(
                            "Revit revirtió la operación final de alineación, TRIM y conexión.");
                    }
                }
                catch (Exception ex)
                {
                    try
                    {
                        if (transaccionCompleta.GetStatus() ==
                            TransactionStatus.Started)
                        {
                            transaccionCompleta.RollBack();
                        }
                    }
                    catch
                    {
                    }

                    message =
                        "No se pudo completar MOVER, ALINEAR Y CONECTAR.\n\n" +
                        ex.Message;

                    MostrarError("Trazado MEP 3D", message);
                    return Result.Failed;
                }
            }

            if (config.SeleccionarResultado)
            {
                List<ElementId> seleccion = new List<ElementId>()
                {
                    idDestinoOriginal,
                    idMovilOriginal
                };

                if (conexionDeslizante.MoverSistemaCompleto &&
                    conexionDeslizante.SistemaConectadoIds != null)
                {
                    seleccion.AddRange(
                        conexionDeslizante.SistemaConectadoIds
                            .Where(x =>
                                x != null &&
                                x != ElementId.InvalidElementId));
                }

                if (conexionDeslizante.EsValida)
                {
                    seleccion.Add(conexionDeslizante.AccesorioId);
                    seleccion.Add(conexionDeslizante.TramoAdyacenteId);
                }

                if (accesorioSuperior != null)
                    seleccion.Add(accesorioSuperior.Id);

                uidoc.Selection.SetElementIds(
                    seleccion
                        .Where(x =>
                            x != null &&
                            x != ElementId.InvalidElementId)
                        .Distinct()
                        .ToList());
            }

            return Result.Succeeded;
        }


        private static MEP3DConexionDeslizanteData
            ObtenerConexionDeslizanteParaAlineacion(
                MEPCurve movil,
                Connector conectorLibre)
        {
            MEP3DConexionDeslizanteData resultado =
                new MEP3DConexionDeslizanteData();

            if (movil == null || conectorLibre == null)
                return resultado;

            Connector conectorOpuesto = ObtenerConectorExtremoOpuesto(
                movil,
                conectorLibre);

            if (conectorOpuesto == null)
                return resultado;

            resultado.PuntoMovilOpuestoOriginal =
                conectorOpuesto.Origin;

            bool extremoOpuestoConectado = false;

            try
            {
                extremoOpuestoConectado =
                    conectorOpuesto.IsConnected;
            }
            catch
            {
                extremoOpuestoConectado = false;
            }

            resultado.ExtremoOpuestoConectado =
                extremoOpuestoConectado;

            if (!extremoOpuestoConectado)
                return resultado;

            // El extremo opuesto puede estar conectado a un codo, tee, unión,
            // accesorio, aparato, equipo o cualquier otra familia con conectores.
            // Para evitar deformar algún tramo, toda la red física conectada al
            // segundo elemento se traslada como un único bloque rígido.
            resultado.SistemaConectadoIds =
                RecopilarSistemaFisicoConectado(
                    movil.Document,
                    movil,
                    ElementId.InvalidElementId);

            if (resultado.SistemaConectadoIds == null)
            {
                resultado.SistemaConectadoIds =
                    new HashSet<ElementId>();
            }

            resultado.SistemaConectadoIds.Add(movil.Id);
            resultado.MoverSistemaCompleto = true;

            return resultado;
        }

        private sealed class MEP3DConexionInternaSistemaData
        {
            public ElementId PropietarioAId { get; set; }
            public ElementId PropietarioBId { get; set; }
            public XYZ OrigenA { get; set; }
            public XYZ OrigenB { get; set; }
            public Domain Dominio { get; set; }
            public ConnectorProfileType FormaA { get; set; }
            public ConnectorProfileType FormaB { get; set; }
            public ConnectorType TipoA { get; set; }
            public ConnectorType TipoB { get; set; }
            public Connector ConectorAOriginal { get; set; }
            public Connector ConectorBOriginal { get; set; }
        }

        // Mueve toda la red MEP físicamente conectada como un único bloque rígido.
        // IMPORTANTE: no se desconecta ninguna unión interna y no se intenta mover
        // elementos uno por uno. Todas las conexiones permanecen activas durante
        // una sola llamada atómica a ElementTransformUtils.MoveElements, equivalente
        // a seleccionar el sistema completo y utilizar la herramienta Mover de Revit.
        private static void MoverSistemaConectadoSeguro(
            Document doc,
            ElementId idMovilOriginal,
            IEnumerable<ElementId> idsSistemaRecibidos,
            XYZ vectorMovimiento,
            double tolerancia)
        {
            if (doc == null)
                throw new InvalidOperationException(
                    "No se recibió un documento válido.");

            if (idMovilOriginal == null ||
                idMovilOriginal == ElementId.InvalidElementId ||
                doc.GetElement(idMovilOriginal) == null)
            {
                throw new InvalidOperationException(
                    "No se recibió un segundo elemento válido para mover.");
            }

            if (vectorMovimiento == null ||
                vectorMovimiento.GetLength() <= EPS)
            {
                return;
            }

            HashSet<ElementId> idsSistema = new HashSet<ElementId>();

            if (idsSistemaRecibidos != null)
            {
                foreach (ElementId id in idsSistemaRecibidos)
                {
                    if (id == null ||
                        id == ElementId.InvalidElementId ||
                        doc.GetElement(id) == null)
                    {
                        continue;
                    }

                    idsSistema.Add(id);
                }
            }

            idsSistema.Add(idMovilOriginal);

            // Evita enviar simultáneamente a MoveElements una familia anidada y su
            // supercomponente, un miembro y su grupo, o un miembro y su ensamblaje.
            // En esos casos se mueve solamente el elemento raíz correspondiente.
            List<ElementId> idsMovimiento =
                NormalizarIdsSistemaParaMovimiento(
                    doc,
                    idsSistema);

            if (idsMovimiento == null || idsMovimiento.Count == 0)
            {
                throw new InvalidOperationException(
                    "No se encontraron elementos movibles en el sistema conectado.");
            }

            // Quita duplicados después de normalizar y confirma que los elementos
            // todavía existan en el documento.
            idsMovimiento = idsMovimiento
                .Where(x =>
                    x != null &&
                    x != ElementId.InvalidElementId &&
                    doc.GetElement(x) != null)
                .Distinct()
                .ToList();

            if (idsMovimiento.Count == 0)
            {
                throw new InvalidOperationException(
                    "No se encontraron elementos válidos para trasladar.");
            }

            // Se conserva el estado Pinned. Para reproducir el comportamiento de
            // Mover, los elementos fijados se desfijan solo durante esta transacción
            // y se vuelven a fijar inmediatamente después del desplazamiento.
            Dictionary<ElementId, bool> estadosPinned =
                new Dictionary<ElementId, bool>();

            foreach (ElementId id in idsMovimiento)
            {
                Element elemento = doc.GetElement(id);

                if (elemento == null)
                    continue;

                bool estabaFijado = false;

                try
                {
                    estabaFijado = elemento.Pinned;
                }
                catch
                {
                    estabaFijado = false;
                }

                estadosPinned[id] = estabaFijado;

                if (!estabaFijado)
                    continue;

                try
                {
                    elemento.Pinned = false;
                }
                catch (Exception ex)
                {
                    string categoria = elemento.Category == null
                        ? "Sin categoría"
                        : elemento.Category.Name;

                    throw new InvalidOperationException(
                        "No se puede mover el sistema porque el elemento " +
                        elemento.Id.Value + " (" + categoria +
                        ") está fijado y Revit no permitió desfijarlo. " +
                        ex.Message);
                }
            }

            try
            {
                // ÚNICO movimiento. No se desconectan conectores, no se editan
                // LocationCurve y no existe respaldo elemento por elemento.
                ElementTransformUtils.MoveElements(
                    doc,
                    idsMovimiento,
                    vectorMovimiento);

                doc.Regenerate();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(
                    "Revit no pudo mover todo el sistema conectado como un solo " +
                    "bloque. No se modificó ninguna conexión interna. Revisa si " +
                    "algún elemento pertenece a un grupo no editable, está hospedado " +
                    "en una cara que no puede trasladarse, tiene una restricción o " +
                    "está controlado por una cota bloqueada. Detalle: " +
                    ex.Message);
            }
            finally
            {
                // Restaura el estado fijado original sin alterar la geometría.
                foreach (KeyValuePair<ElementId, bool> dato in estadosPinned)
                {
                    if (!dato.Value)
                        continue;

                    Element elemento = doc.GetElement(dato.Key);

                    if (elemento == null)
                        continue;

                    try
                    {
                        elemento.Pinned = true;
                    }
                    catch
                    {
                        // Si Revit no permite restaurarlo aquí, el TransactionGroup
                        // superior revertirá la operación cuando corresponda.
                    }
                }
            }
        }

        private static List<ElementId> NormalizarIdsSistemaParaMovimiento(
            Document doc,
            IEnumerable<ElementId> ids)
        {
            HashSet<ElementId> resultado = new HashSet<ElementId>();

            if (doc == null || ids == null)
                return resultado.ToList();

            foreach (ElementId idOriginal in ids)
            {
                if (idOriginal == null ||
                    idOriginal == ElementId.InvalidElementId)
                {
                    continue;
                }

                Element elemento = doc.GetElement(idOriginal);

                if (elemento == null)
                    continue;

                ElementId idNormalizado = ObtenerIdRaizMovible(
                    doc,
                    elemento);

                if (idNormalizado != null &&
                    idNormalizado != ElementId.InvalidElementId &&
                    doc.GetElement(idNormalizado) != null)
                {
                    resultado.Add(idNormalizado);
                }
            }

            return resultado.ToList();
        }

        private static ElementId ObtenerIdRaizMovible(
            Document doc,
            Element elemento)
        {
            if (doc == null || elemento == null)
                return ElementId.InvalidElementId;

            Element actual = elemento;

            try
            {
                FamilyInstance familia = actual as FamilyInstance;

                while (familia != null &&
                       familia.SuperComponent != null)
                {
                    actual = familia.SuperComponent;
                    familia = actual as FamilyInstance;
                }
            }
            catch
            {
            }

            try
            {
                if (actual.GroupId != null &&
                    actual.GroupId != ElementId.InvalidElementId &&
                    doc.GetElement(actual.GroupId) != null)
                {
                    return actual.GroupId;
                }
            }
            catch
            {
            }

            try
            {
                if (actual.AssemblyInstanceId != null &&
                    actual.AssemblyInstanceId != ElementId.InvalidElementId &&
                    doc.GetElement(actual.AssemblyInstanceId) != null)
                {
                    return actual.AssemblyInstanceId;
                }
            }
            catch
            {
            }

            return actual.Id;
        }

        private static void MoverElementoConTraslacionSegura(
            Document doc,
            ElementId id,
            XYZ vector)
        {
            Element elemento = doc == null ? null : doc.GetElement(id);

            if (elemento == null)
                return;

            Exception ultimoError = null;

            try
            {
                Location ubicacion = elemento.Location;

                if (ubicacion != null && ubicacion.Move(vector))
                    return;
            }
            catch (Exception ex)
            {
                ultimoError = ex;
            }

            try
            {
                ElementTransformUtils.MoveElement(
                    doc,
                    id,
                    vector);

                return;
            }
            catch (Exception ex)
            {
                ultimoError = ex;
            }

            string categoria = elemento.Category == null
                ? "Sin categoría"
                : elemento.Category.Name;

            throw new InvalidOperationException(
                "No se pudo mover el elemento " +
                elemento.Id.Value +
                " (" + categoria + "). " +
                (ultimoError == null ? "" : ultimoError.Message));
        }

        private static List<MEP3DConexionInternaSistemaData>
            CapturarConexionesInternasSistema(
                Document doc,
                HashSet<ElementId> idsSistema)
        {
            List<MEP3DConexionInternaSistemaData> resultado =
                new List<MEP3DConexionInternaSistemaData>();

            HashSet<string> claves = new HashSet<string>();

            if (doc == null || idsSistema == null)
                return resultado;

            foreach (ElementId id in idsSistema)
            {
                Element elemento = doc.GetElement(id);

                if (elemento == null)
                    continue;

                foreach (Connector conector in ObtenerConectoresFisicos(elemento))
                {
                    if (conector == null ||
                        conector.ConnectorType == ConnectorType.Logical)
                    {
                        continue;
                    }

                    XYZ origenA;

                    if (!TryObtenerOrigenConector(conector, out origenA))
                        continue;

                    ConnectorSet referencias;

                    try
                    {
                        referencias = conector.AllRefs;
                    }
                    catch
                    {
                        continue;
                    }

                    foreach (Connector referencia in referencias)
                    {
                        if (referencia == null ||
                            referencia.Owner == null ||
                            referencia.Owner.Id == elemento.Id ||
                            !idsSistema.Contains(referencia.Owner.Id))
                        {
                            continue;
                        }

                        bool conectados = false;

                        try
                        {
                            conectados = conector.IsConnectedTo(referencia);
                        }
                        catch
                        {
                            conectados = EstaConectadoSeguro(conector) &&
                                         EstaConectadoSeguro(referencia);
                        }

                        if (!conectados)
                            continue;

                        XYZ origenB;

                        if (!TryObtenerOrigenConector(referencia, out origenB))
                            continue;

                        string clave = CrearClaveConexionInterna(
                            elemento.Id,
                            referencia.Owner.Id,
                            origenA,
                            origenB);

                        if (!claves.Add(clave))
                            continue;

                        resultado.Add(new MEP3DConexionInternaSistemaData()
                        {
                            PropietarioAId = elemento.Id,
                            PropietarioBId = referencia.Owner.Id,
                            OrigenA = origenA,
                            OrigenB = origenB,
                            Dominio = conector.Domain,
                            FormaA = conector.Shape,
                            FormaB = referencia.Shape,
                            TipoA = conector.ConnectorType,
                            TipoB = referencia.ConnectorType,
                            ConectorAOriginal = conector,
                            ConectorBOriginal = referencia
                        });
                    }
                }
            }

            return resultado;
        }

        private static string CrearClaveConexionInterna(
            ElementId idA,
            ElementId idB,
            XYZ puntoA,
            XYZ puntoB)
        {
            long a = idA == null ? -1 : idA.Value;
            long b = idB == null ? -1 : idB.Value;

            string pa = CuantizarPuntoConexion(puntoA);
            string pb = CuantizarPuntoConexion(puntoB);

            if (a < b || (a == b && string.CompareOrdinal(pa, pb) <= 0))
                return a + "|" + b + "|" + pa + "|" + pb;

            return b + "|" + a + "|" + pb + "|" + pa;
        }

        private static string CuantizarPuntoConexion(XYZ punto)
        {
            if (punto == null)
                return "null";

            const double factor = 1000000.0;

            long x = (long)Math.Round(punto.X * factor);
            long y = (long)Math.Round(punto.Y * factor);
            long z = (long)Math.Round(punto.Z * factor);

            return x + "," + y + "," + z;
        }

        private static void DesconectarConexionesInternasSistema(
            IEnumerable<MEP3DConexionInternaSistemaData> conexiones)
        {
            if (conexiones == null)
                return;

            foreach (MEP3DConexionInternaSistemaData dato in conexiones)
            {
                if (dato == null ||
                    dato.ConectorAOriginal == null ||
                    dato.ConectorBOriginal == null)
                {
                    continue;
                }

                try
                {
                    if (dato.ConectorAOriginal.IsConnectedTo(
                        dato.ConectorBOriginal))
                    {
                        dato.ConectorAOriginal.DisconnectFrom(
                            dato.ConectorBOriginal);
                    }
                }
                catch
                {
                    try
                    {
                        dato.ConectorBOriginal.DisconnectFrom(
                            dato.ConectorAOriginal);
                    }
                    catch
                    {
                    }
                }
            }
        }

        private static void ReconectarConexionesInternasSistema(
            Document doc,
            IEnumerable<MEP3DConexionInternaSistemaData> conexiones,
            XYZ vectorMovimiento,
            double tolerancia)
        {
            if (doc == null || conexiones == null)
                return;

            foreach (MEP3DConexionInternaSistemaData dato in conexiones)
            {
                if (dato == null)
                    continue;

                Element propietarioA = doc.GetElement(dato.PropietarioAId);
                Element propietarioB = doc.GetElement(dato.PropietarioBId);

                if (propietarioA == null || propietarioB == null)
                    continue;

                XYZ esperadoA = dato.OrigenA.Add(vectorMovimiento);
                XYZ esperadoB = dato.OrigenB.Add(vectorMovimiento);

                Connector conectorA = BuscarConectorInternoTrasMovimiento(
                    propietarioA,
                    esperadoA,
                    dato.Dominio,
                    dato.FormaA,
                    dato.TipoA,
                    tolerancia);

                Connector conectorB = BuscarConectorInternoTrasMovimiento(
                    propietarioB,
                    esperadoB,
                    dato.Dominio,
                    dato.FormaB,
                    dato.TipoB,
                    tolerancia);

                if (conectorA == null || conectorB == null)
                {
                    throw new InvalidOperationException(
                        "No se pudo recuperar una conexión interna del sistema " +
                        "después de moverlo.");
                }

                try
                {
                    if (conectorA.IsConnectedTo(conectorB))
                        continue;
                }
                catch
                {
                }

                try
                {
                    conectorA.ConnectTo(conectorB);
                }
                catch
                {
                    try
                    {
                        conectorB.ConnectTo(conectorA);
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidOperationException(
                            "No se pudo restaurar una conexión interna del sistema. " +
                            ex.Message);
                    }
                }
            }
        }

        private static Connector BuscarConectorInternoTrasMovimiento(
            Element propietario,
            XYZ puntoEsperado,
            Domain dominio,
            ConnectorProfileType forma,
            ConnectorType tipo,
            double tolerancia)
        {
            Connector mejor = null;
            double mejorDistancia = double.MaxValue;

            foreach (Connector conector in ObtenerConectoresFisicos(propietario))
            {
                if (conector == null || conector.Domain != dominio)
                    continue;

                XYZ origen;

                if (!TryObtenerOrigenConector(conector, out origen))
                    continue;

                double penalidadForma = conector.Shape == forma ? 0.0 : tolerancia;
                double penalidadTipo = conector.ConnectorType == tipo ? 0.0 : tolerancia;
                double distancia = origen.DistanceTo(puntoEsperado) +
                                   penalidadForma +
                                   penalidadTipo;

                if (distancia < mejorDistancia)
                {
                    mejorDistancia = distancia;
                    mejor = conector;
                }
            }

            if (mejor == null)
                return null;

            XYZ origenMejor;

            if (!TryObtenerOrigenConector(mejor, out origenMejor))
                return null;

            return origenMejor.DistanceTo(puntoEsperado) <=
                   Math.Max(tolerancia * 4.0, MmAInterno(10.0))
                ? mejor
                : null;
        }

        private static XYZ CalcularVectorAlineacionComoRevit(
            Line lineaMovil,
            XYZ puntoMovilLibre,
            XYZ puntoReferencia,
            MEP3DConexionDeslizanteData conexion,
            double tolerancia,
            out string motivo)
        {
            motivo = "";

            if (lineaMovil == null ||
                puntoMovilLibre == null ||
                puntoReferencia == null)
            {
                motivo = "No se recibió geometría válida.";
                return null;
            }

            XYZ direccionMovil3D = lineaMovil.Direction.Normalize();
            XYZ direccionMovilXY = new XYZ(
                direccionMovil3D.X,
                direccionMovil3D.Y,
                0.0);

            XYZ puntoMovilXY = new XYZ(
                puntoMovilLibre.X,
                puntoMovilLibre.Y,
                0.0);

            XYZ puntoReferenciaXY = new XYZ(
                puntoReferencia.X,
                puntoReferencia.Y,
                0.0);

            // Cuando existe codo y tramo adyacente, la traslación se restringe al
            // eje de ese tramo. Es exactamente el comportamiento de Alinear en Revit:
            // el codo se desliza sobre el tramo adyacente, que solo cambia de longitud.
            if (conexion != null &&
                conexion.EsValida &&
                conexion.DireccionDeslizamiento != null)
            {
                XYZ direccionDeslizamientoXY = new XYZ(
                    conexion.DireccionDeslizamiento.X,
                    conexion.DireccionDeslizamiento.Y,
                    0.0);

                if (direccionDeslizamientoXY.GetLength() < EPS)
                {
                    motivo =
                        "El tramo adyacente no tiene dirección utilizable en planta.";
                    return null;
                }

                direccionDeslizamientoXY =
                    direccionDeslizamientoXY.Normalize();

                if (direccionMovilXY.GetLength() < EPS)
                {
                    XYZ delta = puntoReferenciaXY.Subtract(
                        puntoMovilXY);

                    double parametro = delta.DotProduct(
                        direccionDeslizamientoXY);

                    XYZ vector = direccionDeslizamientoXY.Multiply(
                        parametro);

                    XYZ residual = delta.Subtract(vector);

                    if (residual.GetLength() > tolerancia)
                    {
                        motivo =
                            "El segundo tramo es vertical y no puede llegar al punto de " +
                            "referencia desplazándose únicamente sobre el eje del tramo adyacente.";
                        return null;
                    }

                    return new XYZ(vector.X, vector.Y, 0.0);
                }

                direccionMovilXY = direccionMovilXY.Normalize();

                double denominador = ProductoCruzado2D(
                    direccionDeslizamientoXY,
                    direccionMovilXY);

                if (Math.Abs(denominador) < 1e-10)
                {
                    double distanciaActual = DistanciaPuntoALineaEnPlanta(
                        puntoReferencia,
                        lineaMovil);

                    if (distanciaActual <= tolerancia)
                        return XYZ.Zero;

                    motivo =
                        "El eje de desplazamiento es paralelo al segundo tramo; " +
                        "no puede trasladarlo hasta la referencia sin cambiar su dirección.";
                    return null;
                }

                XYZ deltaReferencia = puntoReferenciaXY.Subtract(
                    puntoMovilXY);

                double parametroDeslizamiento = ProductoCruzado2D(
                    deltaReferencia,
                    direccionMovilXY) /
                    denominador;

                XYZ vectorAlineacion = direccionDeslizamientoXY.Multiply(
                    parametroDeslizamiento);

                return new XYZ(
                    vectorAlineacion.X,
                    vectorAlineacion.Y,
                    0.0);
            }

            // Tramo libre: se aplica la traslación perpendicular mínima que hace que
            // su eje pase por el conector de referencia, igual que Alinear en planta.
            if (direccionMovilXY.GetLength() < EPS)
            {
                XYZ delta = puntoReferenciaXY.Subtract(
                    puntoMovilXY);

                return new XYZ(delta.X, delta.Y, 0.0);
            }

            direccionMovilXY = direccionMovilXY.Normalize();

            double parametroProyeccion = puntoReferenciaXY.Subtract(
                puntoMovilXY).DotProduct(direccionMovilXY);

            XYZ puntoProyectado = puntoMovilXY.Add(
                direccionMovilXY.Multiply(parametroProyeccion));

            XYZ vectorMinimo = puntoReferenciaXY.Subtract(
                puntoProyectado);

            return new XYZ(vectorMinimo.X, vectorMinimo.Y, 0.0);
        }

        private static bool CalcularInterseccionLineas3D(
            Line lineaA,
            Line lineaB,
            double tolerancia,
            out XYZ puntoInterseccion,
            out string motivo)
        {
            puntoInterseccion = null;
            motivo = "";

            if (lineaA == null || lineaB == null)
            {
                motivo = "No se recibieron líneas válidas.";
                return false;
            }

            XYZ p1 = lineaA.GetEndPoint(0);
            XYZ p2 = lineaB.GetEndPoint(0);
            XYZ d1 = lineaA.Direction.Normalize();
            XYZ d2 = lineaB.Direction.Normalize();

            double a = d1.DotProduct(d1);
            double b = d1.DotProduct(d2);
            double c = d2.DotProduct(d2);
            XYZ w0 = p1.Subtract(p2);
            double d = d1.DotProduct(w0);
            double e = d2.DotProduct(w0);
            double denominador = a * c - b * b;

            if (Math.Abs(denominador) < 1e-12)
            {
                double distancia = DistanciaPuntoALineaInfinita(
                    p2,
                    lineaA);

                if (distancia > tolerancia)
                {
                    motivo =
                        "Los tramos son paralelos y no son colineales. Separación: " +
                        InternoAMm(distancia).ToString("0.###") +
                        " mm.";
                    return false;
                }

                XYZ puntoA = ProyectarPuntoSobreLineaInfinita(
                    lineaA.GetEndPoint(1),
                    lineaB);

                puntoInterseccion = lineaA.GetEndPoint(1).Add(
                    puntoA).Multiply(0.5);
                return true;
            }

            double parametroA = (b * e - c * d) /
                denominador;

            double parametroB = (a * e - b * d) /
                denominador;

            XYZ puntoAlinea = p1.Add(
                d1.Multiply(parametroA));

            XYZ puntoBlinea = p2.Add(
                d2.Multiply(parametroB));

            double separacion = puntoAlinea.DistanceTo(
                puntoBlinea);

            if (separacion > tolerancia)
            {
                motivo =
                    "Los ejes son alabeados y no se intersectan en 3D. Separación mínima: " +
                    InternoAMm(separacion).ToString("0.###") +
                    " mm.";
                return false;
            }

            puntoInterseccion = puntoAlinea.Add(
                puntoBlinea).Multiply(0.5);
            return true;
        }

        private static XYZ ProyectarPuntoSobreLineaInfinita(
            XYZ punto,
            Line linea)
        {
            if (punto == null || linea == null)
                return punto;

            XYZ origen = linea.GetEndPoint(0);
            XYZ direccion = linea.Direction.Normalize();

            double parametro = punto.Subtract(
                origen).DotProduct(direccion);

            return origen.Add(
                direccion.Multiply(parametro));
        }

        private static double DistanciaPuntoALineaInfinita(
            XYZ punto,
            Line linea)
        {
            if (punto == null || linea == null)
                return double.MaxValue;

            XYZ proyectado = ProyectarPuntoSobreLineaInfinita(
                punto,
                linea);

            return punto.DistanceTo(proyectado);
        }

        private static double DistanciaPuntoALineaEnPlanta(
            XYZ punto,
            Line linea)
        {
            if (punto == null || linea == null)
                return double.MaxValue;

            XYZ p0 = linea.GetEndPoint(0);
            XYZ p1 = linea.GetEndPoint(1);

            XYZ origenXY = new XYZ(p0.X, p0.Y, 0.0);
            XYZ finXY = new XYZ(p1.X, p1.Y, 0.0);
            XYZ puntoXY = new XYZ(punto.X, punto.Y, 0.0);

            XYZ direccion = finXY.Subtract(origenXY);

            if (direccion.GetLength() < EPS)
                return puntoXY.DistanceTo(origenXY);

            direccion = direccion.Normalize();

            double parametro = puntoXY.Subtract(
                origenXY).DotProduct(direccion);

            XYZ proyectado = origenXY.Add(
                direccion.Multiply(parametro));

            return puntoXY.DistanceTo(proyectado);
        }

        private static double ProductoCruzado2D(
            XYZ a,
            XYZ b)
        {
            if (a == null || b == null)
                return 0.0;

            return a.X * b.Y - a.Y * b.X;
        }

        private static Connector BuscarConectorMasCercanoSinFiltroDominio(
            Element elemento,
            XYZ punto)
        {
            if (elemento == null || punto == null)
                return null;

            return ObtenerConectoresFisicos(elemento)
                .OrderBy(x => x.Origin.DistanceTo(punto))
                .FirstOrDefault();
        }

        private static Connector ObtenerConectorExtremoOpuesto(
            MEPCurve curva,
            Connector conectorSeleccionado)
        {
            if (curva == null || conectorSeleccionado == null)
                return null;

            return ObtenerConectoresFisicos(curva)
                .Where(x => x.ConnectorType == ConnectorType.End)
                .OrderByDescending(x => x.Origin.DistanceTo(
                    conectorSeleccionado.Origin))
                .FirstOrDefault();
        }

        private static Connector ObtenerConectorExtremoOpuestoPorPunto(
            MEPCurve curva,
            XYZ puntoDelOtroExtremo)
        {
            if (curva == null || puntoDelOtroExtremo == null)
                return null;

            return ObtenerConectoresFisicos(curva)
                .Where(x => x.ConnectorType == ConnectorType.End)
                .OrderByDescending(x => x.Origin.DistanceTo(
                    puntoDelOtroExtremo))
                .FirstOrDefault();
        }

        private static Connector ObtenerConectorExternoConectado(
            Connector conector,
            ElementId excluirPropietarioId)
        {
            if (conector == null)
                return null;

            ConnectorSet referencias;

            try
            {
                referencias = conector.AllRefs;
            }
            catch
            {
                return null;
            }

            foreach (Connector referencia in referencias)
            {
                if (referencia == null || referencia.Owner == null)
                    continue;

                if (referencia.Owner.Id == excluirPropietarioId)
                    continue;

                if (referencia.ConnectorType == ConnectorType.Logical)
                    continue;

                try
                {
                    if (conector.IsConnectedTo(referencia))
                        return referencia;
                }
                catch
                {
                }
            }

            return null;
        }

        private static FamilyInstance CrearConexionConAccesorioRobusta(
            Document doc,
            Connector a,
            Connector b)
        {
            if (doc == null || a == null || b == null)
                throw new ArgumentNullException("Conector nulo.");

            try
            {
                if (a.IsConnectedTo(b))
                    return null;
            }
            catch
            {
            }

            Exception ultimoError = null;
            XYZ direccionA = ObtenerDireccionExterior(a.Owner, a).Normalize();
            XYZ direccionB = ObtenerDireccionExterior(b.Owner, b).Normalize();
            double producto = LimitarProducto(
                direccionA.DotProduct(direccionB));

            if (Math.Abs(producto) < 0.9990)
            {
                try
                {
                    FamilyInstance codo = doc.Create.NewElbowFitting(a, b);

                    if (codo != null)
                        return codo;
                }
                catch (Exception ex)
                {
                    ultimoError = ex;
                }
            }

            try
            {
                FamilyInstance union = doc.Create.NewUnionFitting(a, b);

                if (union != null)
                    return union;
            }
            catch (Exception ex)
            {
                ultimoError = ex;
            }

            try
            {
                FamilyInstance transicion = doc.Create.NewTransitionFitting(a, b);

                if (transicion != null)
                    return transicion;
            }
            catch (Exception ex)
            {
                ultimoError = ex;
            }

            try
            {
                a.ConnectTo(b);

                if (a.IsConnectedTo(b))
                    return null;
            }
            catch (Exception ex)
            {
                ultimoError = ex;
            }

            throw new InvalidOperationException(
                "Revit no pudo conectar los dos conectores. " +
                (ultimoError == null ? "" : ultimoError.Message));
        }

        private static void CopiarDimensionesMEP(
            MEPCurve origen,
            MEPCurve destino)
        {
            if (origen == null || destino == null)
                return;

            CopiarParametroDouble(
                origen,
                destino,
                BuiltInParameter.RBS_PIPE_DIAMETER_PARAM);

            CopiarParametroDouble(
                origen,
                destino,
                BuiltInParameter.RBS_CURVE_DIAMETER_PARAM);

            CopiarParametroDouble(
                origen,
                destino,
                BuiltInParameter.RBS_CURVE_WIDTH_PARAM);

            CopiarParametroDouble(
                origen,
                destino,
                BuiltInParameter.RBS_CURVE_HEIGHT_PARAM);

            CopiarParametroDouble(
                origen,
                destino,
                BuiltInParameter.RBS_CONDUIT_DIAMETER_PARAM);

            CopiarParametroDouble(
                origen,
                destino,
                BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM);

            CopiarParametroDouble(
                origen,
                destino,
                BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM);
        }

        private static void CopiarParametroDouble(
            Element origen,
            Element destino,
            BuiltInParameter parametro)
        {
            try
            {
                Parameter pOrigen = origen.get_Parameter(parametro);
                Parameter pDestino = destino.get_Parameter(parametro);

                if (pOrigen == null || pDestino == null || pDestino.IsReadOnly)
                    return;

                if (pOrigen.StorageType != StorageType.Double ||
                    pDestino.StorageType != StorageType.Double)
                {
                    return;
                }

                pDestino.Set(pOrigen.AsDouble());
            }
            catch
            {
            }
        }

        private static bool CalcularPuntoAlineadoConPendiente(
            XYZ puntoFijoMovil,
            XYZ puntoConexionMovil,
            XYZ puntoFijoDestino,
            XYZ puntoConexionDestino,
            double tolerancia,
            out XYZ puntoUnion,
            out string motivo)
        {
            puntoUnion = null;
            motivo = "";

            if (puntoFijoMovil == null || puntoConexionMovil == null ||
                puntoFijoDestino == null || puntoConexionDestino == null)
            {
                motivo = "No se pudieron leer los puntos extremos de los tramos.";
                return false;
            }

            XYZ vectorMovilOriginal = puntoConexionMovil.Subtract(puntoFijoMovil);
            XYZ vectorDestino = puntoConexionDestino.Subtract(puntoFijoDestino);

            if (vectorMovilOriginal.GetLength() < EPS ||
                vectorDestino.GetLength() < EPS)
            {
                motivo = "Uno de los tramos tiene una dirección no válida.";
                return false;
            }

            XYZ direccionDestino = vectorDestino.Normalize();

            double horizontalMovil = Math.Sqrt(
                (vectorMovilOriginal.X * vectorMovilOriginal.X) +
                (vectorMovilOriginal.Y * vectorMovilOriginal.Y));

            // CASO 1: tramo móvil vertical. Se mantiene vertical y se busca el punto de
            // la línea destino cuya proyección XY coincida con el extremo fijo móvil.
            if (horizontalMovil < EPS)
            {
                double denominadorXY =
                    (direccionDestino.X * direccionDestino.X) +
                    (direccionDestino.Y * direccionDestino.Y);

                if (denominadorXY < 1.0e-12)
                {
                    double separacionXY = Math.Sqrt(
                        Math.Pow(puntoFijoDestino.X - puntoFijoMovil.X, 2.0) +
                        Math.Pow(puntoFijoDestino.Y - puntoFijoMovil.Y, 2.0));

                    if (separacionXY > tolerancia)
                    {
                        motivo =
                            "El tramo móvil y el tramo destino son verticales pero no comparten el mismo eje XY.";
                        return false;
                    }

                    puntoUnion = puntoConexionDestino;
                    return true;
                }

                double parametroVertical = -(
                    ((puntoFijoDestino.X - puntoFijoMovil.X) * direccionDestino.X) +
                    ((puntoFijoDestino.Y - puntoFijoMovil.Y) * direccionDestino.Y)) /
                    denominadorXY;

                if (parametroVertical <= EPS)
                {
                    motivo =
                        "El punto alineado queda detrás del extremo fijo del tramo destino.";
                    return false;
                }

                XYZ candidatoVertical = puntoFijoDestino.Add(
                    direccionDestino.Multiply(parametroVertical));

                double separacionVerticalXY = Math.Sqrt(
                    Math.Pow(candidatoVertical.X - puntoFijoMovil.X, 2.0) +
                    Math.Pow(candidatoVertical.Y - puntoFijoMovil.Y, 2.0));

                if (separacionVerticalXY > tolerancia)
                {
                    motivo =
                        "No existe un punto del tramo destino que permita mantener vertical el tramo móvil.";
                    return false;
                }

                puntoUnion = candidatoVertical;
                return true;
            }

            double pendienteOriginal = vectorMovilOriginal.Z / horizontalMovil;

            // CASO 2: pendiente 0 %. El punto de unión debe quedar exactamente en la
            // elevación del extremo fijo móvil. El tramo móvil gira solo en planta.
            if (Math.Abs(pendienteOriginal) < 1.0e-10)
            {
                if (Math.Abs(direccionDestino.Z) > 1.0e-12)
                {
                    double parametroHorizontal =
                        (puntoFijoMovil.Z - puntoFijoDestino.Z) /
                        direccionDestino.Z;

                    if (parametroHorizontal <= EPS)
                    {
                        motivo =
                            "La prolongación del tramo destino no alcanza el plano horizontal del tramo móvil " +
                            "en la dirección de su extremo libre.";
                        return false;
                    }

                    XYZ candidatoHorizontal = puntoFijoDestino.Add(
                        direccionDestino.Multiply(parametroHorizontal));

                    double longitudHorizontal = Math.Sqrt(
                        Math.Pow(candidatoHorizontal.X - puntoFijoMovil.X, 2.0) +
                        Math.Pow(candidatoHorizontal.Y - puntoFijoMovil.Y, 2.0));

                    if (longitudHorizontal < EPS)
                    {
                        motivo =
                            "El punto de unión coincide en planta con el extremo fijo del tramo móvil.";
                        return false;
                    }

                    // Se fuerza matemáticamente la misma cota para evitar pendientes residuales.
                    puntoUnion = new XYZ(
                        candidatoHorizontal.X,
                        candidatoHorizontal.Y,
                        puntoFijoMovil.Z);

                    return true;
                }

                if (Math.Abs(puntoFijoDestino.Z - puntoFijoMovil.Z) > tolerancia)
                {
                    motivo =
                        "El tramo destino es horizontal y está en otra elevación. " +
                        "No puede alcanzarse manteniendo 0 % de pendiente.";
                    return false;
                }

                // Ambos tramos están en el mismo plano horizontal. Se utiliza el extremo
                // libre actual del destino y el móvil gira hacia él alrededor de su extremo fijo.
                puntoUnion = new XYZ(
                    puntoConexionDestino.X,
                    puntoConexionDestino.Y,
                    puntoFijoMovil.Z);

                return true;
            }

            // CASO 3: pendiente distinta de 0 %. Se busca sobre la línea infinita del
            // destino un punto P que cumpla exactamente:
            // (P.Z - fijo.Z) / distanciaHorizontal(P, fijo) = pendienteOriginal.
            double x0 = puntoFijoDestino.X - puntoFijoMovil.X;
            double y0 = puntoFijoDestino.Y - puntoFijoMovil.Y;
            double z0 = puntoFijoDestino.Z - puntoFijoMovil.Z;

            double dx = direccionDestino.X;
            double dy = direccionDestino.Y;
            double dz = direccionDestino.Z;

            double pendienteCuadrada = pendienteOriginal * pendienteOriginal;

            double coefA =
                (dz * dz) -
                pendienteCuadrada * ((dx * dx) + (dy * dy));

            double coefB = 2.0 * (
                (z0 * dz) -
                pendienteCuadrada * ((x0 * dx) + (y0 * dy)));

            double coefC =
                (z0 * z0) -
                pendienteCuadrada * ((x0 * x0) + (y0 * y0));

            List<double> parametros = new List<double>();

            if (Math.Abs(coefA) < 1.0e-12)
            {
                if (Math.Abs(coefB) < 1.0e-12)
                {
                    motivo =
                        "No se encontró una solución geométrica única que conserve la pendiente del tramo móvil.";
                    return false;
                }

                parametros.Add(-coefC / coefB);
            }
            else
            {
                double discriminante = (coefB * coefB) - (4.0 * coefA * coefC);

                if (discriminante < -1.0e-10)
                {
                    motivo =
                        "La línea del tramo destino no puede alcanzarse conservando la pendiente original del tramo móvil.";
                    return false;
                }

                if (discriminante < 0.0)
                    discriminante = 0.0;

                double raiz = Math.Sqrt(discriminante);

                parametros.Add((-coefB + raiz) / (2.0 * coefA));

                if (raiz > 1.0e-10)
                    parametros.Add((-coefB - raiz) / (2.0 * coefA));
            }

            XYZ mejorPunto = null;
            double mejorPuntaje = double.MaxValue;

            foreach (double parametro in parametros)
            {
                // El destino solo puede alargarse o recortarse por el extremo escogido;
                // nunca se invierte atravesando su extremo fijo.
                if (parametro <= EPS)
                    continue;

                XYZ candidato = puntoFijoDestino.Add(
                    direccionDestino.Multiply(parametro));

                XYZ vectorNuevoMovil = candidato.Subtract(puntoFijoMovil);

                double horizontalNuevo = Math.Sqrt(
                    (vectorNuevoMovil.X * vectorNuevoMovil.X) +
                    (vectorNuevoMovil.Y * vectorNuevoMovil.Y));

                if (horizontalNuevo < EPS)
                    continue;

                double pendienteNueva = vectorNuevoMovil.Z / horizontalNuevo;
                double toleranciaPendiente = Math.Max(
                    1.0e-8,
                    Math.Abs(pendienteOriginal) * 1.0e-6);

                // La ecuación cuadrática conserva el valor absoluto; esta verificación
                // elimina la raíz con el signo de pendiente contrario.
                if (Math.Abs(pendienteNueva - pendienteOriginal) > toleranciaPendiente)
                    continue;

                double puntaje =
                    candidato.DistanceTo(puntoConexionDestino) +
                    candidato.DistanceTo(puntoConexionMovil);

                if (puntaje < mejorPuntaje)
                {
                    mejorPuntaje = puntaje;
                    mejorPunto = candidato;
                }
            }

            if (mejorPunto == null)
            {
                motivo =
                    "Las soluciones posibles invertirían el tramo destino o cambiarían el signo de la pendiente móvil.";
                return false;
            }

            puntoUnion = mejorPunto;
            return true;
        }

        private static int ObtenerIndiceExtremoMasCercano(
            Line linea,
            XYZ punto)
        {
            if (linea == null || punto == null)
                return 0;

            double distancia0 = linea.GetEndPoint(0).DistanceTo(punto);
            double distancia1 = linea.GetEndPoint(1).DistanceTo(punto);

            return distancia0 <= distancia1 ? 0 : 1;
        }

        private static Result EjecutarVoltearMultiple(
            UIDocument uidoc,
            ref string message)
        {
            Document doc = uidoc.Document;
            MEP3DSettingsData config = MEP3DSettings.Obtener();

            List<FamilyInstance> familias = ObtenerFamiliasParaVoltear(
                uidoc,
                config.UsarSeleccionActual);

            if (familias.Count == 0)
            {
                message = "No se seleccionaron familias que permitan volteo o giro.";
                return Result.Cancelled;
            }

            int modificadas = 0;
            List<string> omitidas = new List<string>();

            using (Transaction transaccion = new Transaction(
                doc,
                "MYG - Voltear familias múltiples"))
            {
                transaccion.Start();
                ConfigurarFallos(transaccion);

                foreach (FamilyInstance familia in familias)
                {
                    SubTransaction sub = new SubTransaction(doc);
                    sub.Start();

                    try
                    {
                        bool cambio = AplicarVolteo(
                            familia,
                            config.ModoVolteo);

                        if (cambio)
                        {
                            sub.Commit();
                            modificadas++;
                        }
                        else
                        {
                            sub.RollBack();

                            if (omitidas.Count < 12)
                            {
                                omitidas.Add(
                                    "Elemento " + familia.Id.Value +
                                    ": la familia no permite ese modo de volteo.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        try
                        {
                            sub.RollBack();
                        }
                        catch
                        {
                        }

                        if (omitidas.Count < 12)
                        {
                            omitidas.Add(
                                "Elemento " + familia.Id.Value + ": " + ex.Message);
                        }
                    }
                }

                transaccion.Commit();
            }

            if (config.SeleccionarResultado && modificadas > 0)
            {
                uidoc.Selection.SetElementIds(
                    familias.Select(x => x.Id).ToList());
            }

            return modificadas > 0
                ? Result.Succeeded
                : Result.Failed;
        }

        private static List<Element> ObtenerElementosParaBloom(
            UIDocument uidoc,
            bool usarSeleccionActual)
        {
            Document doc = uidoc.Document;
            List<Element> elementos = new List<Element>();

            if (usarSeleccionActual)
            {
                foreach (ElementId id in uidoc.Selection.GetElementIds())
                {
                    Element elemento = doc.GetElement(id);

                    if (elemento != null && TieneConectoresFisicos(elemento))
                        elementos.Add(elemento);
                }
            }

            if (elementos.Count > 0)
                return elementos
                    .GroupBy(x => x.Id)
                    .Select(x => x.First())
                    .ToList();

            IList<Reference> referencias = uidoc.Selection.PickObjects(
                ObjectType.Element,
                new MEP3DConnectorOwnerSelectionFilter(),
                "Selecciona accesorios, equipos, familias o tramos con conectores MEP.");

            foreach (Reference referencia in referencias)
            {
                Element elemento = doc.GetElement(referencia.ElementId);

                if (elemento != null && TieneConectoresFisicos(elemento))
                    elementos.Add(elemento);
            }

            return elementos
                .GroupBy(x => x.Id)
                .Select(x => x.First())
                .ToList();
        }

        private static List<FamilyInstance> ObtenerFamiliasParaVoltear(
            UIDocument uidoc,
            bool usarSeleccionActual)
        {
            Document doc = uidoc.Document;
            List<FamilyInstance> familias = new List<FamilyInstance>();

            if (usarSeleccionActual)
            {
                foreach (ElementId id in uidoc.Selection.GetElementIds())
                {
                    FamilyInstance familia = doc.GetElement(id) as FamilyInstance;

                    if (familia != null && PermiteAlgunaOperacionVolteo(familia))
                        familias.Add(familia);
                }
            }

            if (familias.Count > 0)
                return familias;

            IList<Reference> referencias = uidoc.Selection.PickObjects(
                ObjectType.Element,
                new MEP3DFlippableFamilySelectionFilter(),
                "Selecciona las familias que deseas voltear.");

            foreach (Reference referencia in referencias)
            {
                FamilyInstance familia = doc.GetElement(
                    referencia.ElementId) as FamilyInstance;

                if (familia != null && PermiteAlgunaOperacionVolteo(familia))
                    familias.Add(familia);
            }

            return familias
                .GroupBy(x => x.Id)
                .Select(x => x.First())
                .ToList();
        }

        private static bool AplicarVolteo(
            FamilyInstance familia,
            MEP3DFlipMode modo)
        {
            if (familia == null)
                return false;

            bool cambio = false;

            if (modo == MEP3DFlipMode.Cara)
            {
                if (familia.CanFlipFacing)
                    cambio = familia.flipFacing();
            }
            else if (modo == MEP3DFlipMode.Mano)
            {
                if (familia.CanFlipHand)
                    cambio = familia.flipHand();
            }
            else if (modo == MEP3DFlipMode.CaraYMano)
            {
                bool cambioCara = false;
                bool cambioMano = false;

                if (familia.CanFlipFacing)
                    cambioCara = familia.flipFacing();

                if (familia.CanFlipHand)
                    cambioMano = familia.flipHand();

                cambio = cambioCara || cambioMano;
            }
            else if (modo == MEP3DFlipMode.Girar180)
            {
                if (familia.CanRotate)
                    cambio = familia.rotate();
            }

            return cambio;
        }

        private static bool PermiteAlgunaOperacionVolteo(
            FamilyInstance familia)
        {
            return familia != null &&
                   (familia.CanFlipFacing ||
                    familia.CanFlipHand ||
                    familia.CanRotate);
        }

        private static MEPCurve CrearTramoDesdeConector(
            Document doc,
            Element propietario,
            Connector conector,
            XYZ inicio,
            XYZ fin,
            MEP3DSettingsData config)
        {
            MEPCurve curvaOrigen = propietario as MEPCurve;

            if (curvaOrigen != null)
                return ClonarTipoDeTramo(doc, curvaOrigen, inicio, fin);

            ElementId nivelId = ObtenerNivelId(
                doc,
                propietario,
                inicio.Z);

            if (conector.Domain == Domain.DomainPiping)
            {
                if (!config.HabilitarTuberias)
                    return null;

                ElementId tipoSistemaId = ObtenerTipoSistemaTuberia(
                    doc,
                    conector);

                ElementId tipoId = ObtenerPrimerTipoId<PipeType>(doc);

                ValidarId(tipoSistemaId, "tipo de sistema de tubería");
                ValidarId(tipoId, "tipo de tubería");
                ValidarId(nivelId, "nivel");

                return Pipe.Create(
                    doc,
                    tipoSistemaId,
                    tipoId,
                    nivelId,
                    inicio,
                    fin);
            }

            if (conector.Domain == Domain.DomainHvac)
            {
                if (!config.HabilitarDuctos)
                    return null;

                ElementId tipoSistemaId = ObtenerTipoSistemaDucto(
                    doc,
                    conector);

                ElementId tipoId = ObtenerPrimerTipoId<DuctType>(doc);

                ValidarId(tipoSistemaId, "tipo de sistema de ducto");
                ValidarId(tipoId, "tipo de ducto");
                ValidarId(nivelId, "nivel");

                return Duct.Create(
                    doc,
                    tipoSistemaId,
                    tipoId,
                    nivelId,
                    inicio,
                    fin);
            }

            if (conector.Domain == Domain.DomainCableTrayConduit)
            {
                if (conector.Shape == ConnectorProfileType.Round)
                {
                    if (!config.HabilitarConduits)
                        return null;

                    ElementId tipoId = ObtenerPrimerTipoId<ConduitType>(doc);
                    ValidarId(tipoId, "tipo de conduit");
                    ValidarId(nivelId, "nivel");

                    return Conduit.Create(
                        doc,
                        tipoId,
                        inicio,
                        fin,
                        nivelId);
                }

                if (!config.HabilitarBandejas)
                    return null;

                ElementId tipoBandejaId = ObtenerPrimerTipoId<CableTrayType>(doc);
                ValidarId(tipoBandejaId, "tipo de bandeja");
                ValidarId(nivelId, "nivel");

                return CableTray.Create(
                    doc,
                    tipoBandejaId,
                    inicio,
                    fin,
                    nivelId);
            }

            return null;
        }

        private static MEPCurve ClonarTipoDeTramo(
            Document doc,
            MEPCurve origen,
            XYZ inicio,
            XYZ fin)
        {
            if (origen == null)
                throw new ArgumentNullException("origen");

            ElementId nivelId = ObtenerNivelId(
                doc,
                origen,
                inicio.Z);

            Pipe tuberia = origen as Pipe;

            if (tuberia != null)
            {
                ElementId sistemaId = ObtenerTipoSistemaTuberia(
                    doc,
                    tuberia.MEPSystem);

                ValidarId(sistemaId, "tipo de sistema de tubería");

                return Pipe.Create(
                    doc,
                    sistemaId,
                    tuberia.GetTypeId(),
                    nivelId,
                    inicio,
                    fin);
            }

            Duct ducto = origen as Duct;

            if (ducto != null)
            {
                ElementId sistemaId = ObtenerTipoSistemaDucto(
                    doc,
                    ducto.MEPSystem);

                ValidarId(sistemaId, "tipo de sistema de ducto");

                return Duct.Create(
                    doc,
                    sistemaId,
                    ducto.GetTypeId(),
                    nivelId,
                    inicio,
                    fin);
            }

            Conduit conduit = origen as Conduit;

            if (conduit != null)
            {
                return Conduit.Create(
                    doc,
                    conduit.GetTypeId(),
                    inicio,
                    fin,
                    nivelId);
            }

            CableTray bandeja = origen as CableTray;

            if (bandeja != null)
            {
                return CableTray.Create(
                    doc,
                    bandeja.GetTypeId(),
                    inicio,
                    fin,
                    nivelId);
            }

            throw new InvalidOperationException(
                "El tipo de tramo MEP seleccionado todavía no está soportado.");
        }

        private static ElementId ObtenerTipoSistemaTuberia(
            Document doc,
            Connector conector)
        {
            try
            {
                if (conector != null && conector.MEPSystem != null)
                {
                    ElementId id = conector.MEPSystem.GetTypeId();

                    if (id != null && id != ElementId.InvalidElementId)
                        return id;
                }
            }
            catch
            {
            }

            return ObtenerPrimerTipoId<PipingSystemType>(doc);
        }

        private static ElementId ObtenerTipoSistemaTuberia(
            Document doc,
            MEPSystem sistema)
        {
            try
            {
                if (sistema != null)
                {
                    ElementId id = sistema.GetTypeId();

                    if (id != null && id != ElementId.InvalidElementId)
                        return id;
                }
            }
            catch
            {
            }

            return ObtenerPrimerTipoId<PipingSystemType>(doc);
        }

        private static ElementId ObtenerTipoSistemaDucto(
            Document doc,
            Connector conector)
        {
            try
            {
                if (conector != null && conector.MEPSystem != null)
                {
                    ElementId id = conector.MEPSystem.GetTypeId();

                    if (id != null && id != ElementId.InvalidElementId)
                        return id;
                }
            }
            catch
            {
            }

            return ObtenerPrimerTipoId<MechanicalSystemType>(doc);
        }

        private static ElementId ObtenerTipoSistemaDucto(
            Document doc,
            MEPSystem sistema)
        {
            try
            {
                if (sistema != null)
                {
                    ElementId id = sistema.GetTypeId();

                    if (id != null && id != ElementId.InvalidElementId)
                        return id;
                }
            }
            catch
            {
            }

            return ObtenerPrimerTipoId<MechanicalSystemType>(doc);
        }

        private static ElementId ObtenerPrimerTipoId<T>(Document doc)
            where T : ElementType
        {
            Element elemento = new FilteredElementCollector(doc)
                .OfClass(typeof(T))
                .FirstElement();

            return elemento == null
                ? ElementId.InvalidElementId
                : elemento.Id;
        }

        private static ElementId ObtenerNivelId(
            Document doc,
            Element elemento,
            double elevacion)
        {
            try
            {
                MEPCurve curva = elemento as MEPCurve;

                if (curva != null && curva.ReferenceLevel != null)
                    return curva.ReferenceLevel.Id;
            }
            catch
            {
            }

            try
            {
                if (elemento != null &&
                    elemento.LevelId != null &&
                    elemento.LevelId != ElementId.InvalidElementId &&
                    doc.GetElement(elemento.LevelId) is Level)
                {
                    return elemento.LevelId;
                }
            }
            catch
            {
            }

            List<Level> niveles = new FilteredElementCollector(doc)
                .OfClass(typeof(Level))
                .Cast<Level>()
                .OrderBy(x => x.Elevation)
                .ToList();

            if (niveles.Count == 0)
                return ElementId.InvalidElementId;

            Level inferior = niveles
                .Where(x => x.Elevation <= elevacion + MmAInterno(5.0))
                .OrderByDescending(x => x.Elevation)
                .FirstOrDefault();

            if (inferior != null)
                return inferior.Id;

            return niveles
                .OrderBy(x => Math.Abs(x.Elevation - elevacion))
                .First()
                .Id;
        }

        private static void AplicarTamanoDesdeConector(
            MEPCurve curva,
            Connector origen)
        {
            if (curva == null || origen == null)
                return;

            try
            {
                if (curva is Pipe)
                {
                    EstablecerParametro(
                        curva,
                        BuiltInParameter.RBS_PIPE_DIAMETER_PARAM,
                        origen.Radius * 2.0);

                    return;
                }

                if (curva is Conduit)
                {
                    EstablecerParametro(
                        curva,
                        BuiltInParameter.RBS_CONDUIT_DIAMETER_PARAM,
                        origen.Radius * 2.0);

                    return;
                }

                if (curva is CableTray)
                {
                    EstablecerParametro(
                        curva,
                        BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM,
                        origen.Width);

                    EstablecerParametro(
                        curva,
                        BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM,
                        origen.Height);

                    return;
                }

                if (curva is Duct)
                {
                    if (origen.Shape == ConnectorProfileType.Round)
                    {
                        EstablecerParametro(
                            curva,
                            BuiltInParameter.RBS_CURVE_DIAMETER_PARAM,
                            origen.Radius * 2.0);
                    }
                    else
                    {
                        EstablecerParametro(
                            curva,
                            BuiltInParameter.RBS_CURVE_WIDTH_PARAM,
                            origen.Width);

                        EstablecerParametro(
                            curva,
                            BuiltInParameter.RBS_CURVE_HEIGHT_PARAM,
                            origen.Height);
                    }
                }
            }
            catch
            {
                // El tramo permanece con el tamaño por defecto del tipo.
            }
        }

        private static void EstablecerParametro(
            Element elemento,
            BuiltInParameter parametro,
            double valor)
        {
            Parameter p = elemento.get_Parameter(parametro);

            if (p != null && !p.IsReadOnly && p.StorageType == StorageType.Double)
                p.Set(valor);
        }

        private static Connector ObtenerConectorExtremoMasCercano(
            MEPCurve curva,
            XYZ punto)
        {
            return ObtenerConectoresFisicos(curva)
                .Where(x => x.ConnectorType == ConnectorType.End)
                .OrderBy(x => x.Origin.DistanceTo(punto))
                .FirstOrDefault();
        }

        private static Connector BuscarConectorMasCercano(
            Element elemento,
            XYZ punto,
            Domain dominio,
            bool soloLibres)
        {
            return ObtenerConectoresFisicos(elemento)
                .Where(x => x.Domain == dominio)
                .Where(x => !soloLibres || EstaLibreSeguro(x))
                .OrderBy(x => x.Origin.DistanceTo(punto))
                .FirstOrDefault();
        }

        private static ConnectorPair BuscarMejorParConectores(
            Element destino,
            Element movil,
            bool soloLibres)
        {
            List<Connector> conectoresDestino = ObtenerConectoresFisicos(destino)
                .Where(x => !soloLibres || EstaLibreSeguro(x))
                .ToList();

            List<Connector> conectoresMovil = ObtenerConectoresFisicos(movil)
                .Where(x => !soloLibres || EstaLibreSeguro(x))
                .ToList();

            ConnectorPair mejor = null;
            double mejorPuntaje = double.MaxValue;

            foreach (Connector a in conectoresDestino)
            {
                foreach (Connector b in conectoresMovil)
                {
                    if (!ConectoresCompatibles(a, b))
                        continue;

                    double distancia = a.Origin.DistanceTo(b.Origin);
                    double penalidadForma = a.Shape == b.Shape ? 0.0 : 1000.0;
                    double puntaje = distancia + penalidadForma;

                    if (puntaje < mejorPuntaje)
                    {
                        mejorPuntaje = puntaje;
                        mejor = new ConnectorPair()
                        {
                            Destino = a,
                            Movil = b
                        };
                    }
                }
            }

            return mejor;
        }

        private static bool ConectoresCompatibles(
            Connector a,
            Connector b)
        {
            if (a == null || b == null)
                return false;

            if (a.Owner == null || b.Owner == null)
                return false;

            if (a.Owner.Id == b.Owner.Id)
                return false;

            if (a.Domain != b.Domain)
                return false;

            if (a.ConnectorType == ConnectorType.Logical ||
                b.ConnectorType == ConnectorType.Logical)
            {
                return false;
            }

            return true;
        }

        private static void ConectarConectores(
            Document doc,
            Connector a,
            Connector b)
        {
            if (a == null || b == null)
                throw new ArgumentNullException("Conector nulo.");

            try
            {
                if (a.IsConnectedTo(b))
                    return;
            }
            catch
            {
            }

            Exception ultimoError = null;

            try
            {
                a.ConnectTo(b);
                return;
            }
            catch (Exception ex)
            {
                ultimoError = ex;
            }

            XYZ da = ObtenerDireccionExterior(a.Owner, a);
            XYZ db = ObtenerDireccionExterior(b.Owner, b);
            double producto = LimitarProducto(da.DotProduct(db));

            if (Math.Abs(producto) < 0.25)
            {
                try
                {
                    doc.Create.NewElbowFitting(a, b);
                    return;
                }
                catch (Exception ex)
                {
                    ultimoError = ex;
                }
            }

            if (producto < -0.75)
            {
                try
                {
                    doc.Create.NewUnionFitting(a, b);
                    return;
                }
                catch (Exception ex)
                {
                    ultimoError = ex;
                }

                try
                {
                    doc.Create.NewTransitionFitting(a, b);
                    return;
                }
                catch (Exception ex)
                {
                    ultimoError = ex;
                }
            }

            throw new InvalidOperationException(
                "Revit no pudo conectar los conectores seleccionados. " +
                (ultimoError == null ? "" : ultimoError.Message));
        }

        private static List<Connector> ObtenerConectoresFisicos(
            Element elemento)
        {
            List<Connector> resultado = new List<Connector>();

            if (elemento == null)
                return resultado;

            ConnectorManager manager = null;

            MEPCurve curva = elemento as MEPCurve;

            if (curva != null)
            {
                manager = curva.ConnectorManager;
            }
            else
            {
                FamilyInstance familia = elemento as FamilyInstance;

                if (familia != null && familia.MEPModel != null)
                    manager = familia.MEPModel.ConnectorManager;
            }

            if (manager == null)
                return resultado;

            try
            {
                foreach (Connector conector in manager.Connectors)
                {
                    if (conector == null)
                        continue;

                    if (conector.ConnectorType == ConnectorType.Logical)
                        continue;

                    resultado.Add(conector);
                }
            }
            catch
            {
            }

            return resultado;
        }

        private static bool TieneConectoresFisicos(Element elemento)
        {
            return ObtenerConectoresFisicos(elemento).Count > 0;
        }

        private static XYZ ObtenerDireccionExterior(
            Element propietario,
            Connector conector)
        {
            if (propietario == null || conector == null)
                return XYZ.BasisX;

            LocationCurve locationCurve = propietario.Location as LocationCurve;

            if (locationCurve != null && locationCurve.Curve != null)
            {
                Curve curva = locationCurve.Curve;
                XYZ p0 = curva.GetEndPoint(0);
                XYZ p1 = curva.GetEndPoint(1);

                if (conector.Origin.DistanceTo(p0) <=
                    conector.Origin.DistanceTo(p1))
                {
                    XYZ d0 = p0.Subtract(p1);

                    if (d0.GetLength() > EPS)
                        return d0.Normalize();
                }
                else
                {
                    XYZ d1 = p1.Subtract(p0);

                    if (d1.GetLength() > EPS)
                        return d1.Normalize();
                }
            }

            XYZ direccion = XYZ.BasisX;

            try
            {
                direccion = conector.CoordinateSystem.BasisZ;
            }
            catch
            {
            }

            if (direccion == null || direccion.GetLength() < EPS)
                direccion = XYZ.BasisX;

            direccion = direccion.Normalize();

            try
            {
                BoundingBoxXYZ caja = propietario.get_BoundingBox(null);

                if (caja != null)
                {
                    XYZ centro = caja.Min.Add(caja.Max).Multiply(0.5);
                    XYZ radial = conector.Origin.Subtract(centro);

                    if (radial.GetLength() > EPS &&
                        radial.DotProduct(direccion) < 0.0)
                    {
                        direccion = direccion.Negate();
                    }
                }
            }
            catch
            {
            }

            return direccion.Normalize();
        }

        private static XYZ CalcularDireccionCodo(
            View vista,
            XYZ direccionOrigen,
            MEP3DOperation operacion)
        {
            XYZ normal = direccionOrigen.Normalize();
            XYZ referencia;

            if (operacion == MEP3DOperation.CodoArriba)
            {
                referencia = XYZ.BasisZ;
            }
            else if (operacion == MEP3DOperation.CodoAbajo)
            {
                referencia = XYZ.BasisZ.Negate();
            }
            else
            {
                XYZ derechaVista = vista == null
                    ? XYZ.BasisX
                    : vista.RightDirection;

                referencia = operacion == MEP3DOperation.CodoDerecha
                    ? derechaVista
                    : derechaVista.Negate();
            }

            XYZ proyectada = ProyectarPerpendicular(
                referencia,
                normal);

            if (proyectada.GetLength() < EPS)
            {
                XYZ alternativa = vista == null
                    ? XYZ.BasisY
                    : vista.UpDirection;

                proyectada = ProyectarPerpendicular(
                    alternativa,
                    normal);
            }

            if (proyectada.GetLength() < EPS)
            {
                XYZ alternativa = Math.Abs(normal.DotProduct(XYZ.BasisX)) < 0.90
                    ? XYZ.BasisX
                    : XYZ.BasisY;

                proyectada = ProyectarPerpendicular(
                    alternativa,
                    normal);
            }

            return proyectada.GetLength() < EPS
                ? null
                : proyectada.Normalize();
        }

        private static XYZ ProyectarPerpendicular(
            XYZ vector,
            XYZ normal)
        {
            XYZ n = normal.Normalize();
            return vector.Subtract(n.Multiply(vector.DotProduct(n)));
        }

        private static void RotarElementosParaAlinear(
            Document doc,
            ICollection<ElementId> ids,
            XYZ centro,
            XYZ direccionActual,
            XYZ direccionDeseada)
        {
            XYZ actual = direccionActual.Normalize();
            XYZ deseada = direccionDeseada.Normalize();
            double producto = LimitarProducto(actual.DotProduct(deseada));

            if (producto > 0.999999)
                return;

            XYZ eje = actual.CrossProduct(deseada);
            double angulo;

            if (eje.GetLength() < EPS)
            {
                XYZ referencia = Math.Abs(actual.DotProduct(XYZ.BasisZ)) < 0.90
                    ? XYZ.BasisZ
                    : XYZ.BasisX;

                eje = actual.CrossProduct(referencia);

                if (eje.GetLength() < EPS)
                    eje = actual.CrossProduct(XYZ.BasisY);

                angulo = Math.PI;
            }
            else
            {
                eje = eje.Normalize();
                angulo = Math.Acos(producto);
            }

            Line lineaEje = Line.CreateUnbound(centro, eje.Normalize());

            ElementTransformUtils.RotateElements(
                doc,
                ids,
                lineaEje,
                angulo);
        }

        private static HashSet<ElementId> RecopilarSistemaFisicoConectado(
            Document doc,
            Element inicio,
            ElementId excluir)
        {
            HashSet<ElementId> visitados =
                new HashSet<ElementId>();

            Queue<ElementId> pendientes =
                new Queue<ElementId>();

            if (doc == null ||
                inicio == null ||
                inicio.Id == ElementId.InvalidElementId)
            {
                return visitados;
            }

            visitados.Add(inicio.Id);
            pendientes.Enqueue(inicio.Id);

            while (pendientes.Count > 0)
            {
                if (visitados.Count >= MAX_ELEMENTOS_RAMAL)
                {
                    throw new InvalidOperationException(
                        "El sistema conectado supera el límite de " +
                        MAX_ELEMENTOS_RAMAL +
                        " elementos. Se canceló para evitar mover una red incompleta.");
                }

                ElementId actualId = pendientes.Dequeue();
                Element actual = doc.GetElement(actualId);

                if (actual == null)
                    continue;

                foreach (Connector conector in
                    ObtenerConectoresFisicos(actual))
                {
                    if (conector == null)
                        continue;

                    ConnectorSet referencias;

                    try
                    {
                        referencias = conector.AllRefs;
                    }
                    catch
                    {
                        continue;
                    }

                    foreach (Connector referencia in referencias)
                    {
                        if (referencia == null ||
                            referencia.Owner == null)
                        {
                            continue;
                        }

                        Element propietario = referencia.Owner;

                        if (propietario.Document == null ||
                            !propietario.Document.Equals(doc))
                        {
                            continue;
                        }

                        if (propietario.Id == actual.Id ||
                            propietario.Id == excluir)
                        {
                            continue;
                        }

                        // Se admite cualquier categoría siempre que el elemento
                        // exponga conectores físicos mediante la API de Revit.
                        if (!TieneConectoresFisicos(propietario))
                            continue;

                        if (visitados.Add(propietario.Id))
                            pendientes.Enqueue(propietario.Id);
                    }
                }
            }

            return visitados;
        }

        private static HashSet<ElementId> RecopilarRamalConectado(
            Document doc,
            Element inicio,
            ElementId excluir)
        {
            HashSet<ElementId> visitados = new HashSet<ElementId>();
            Queue<ElementId> pendientes = new Queue<ElementId>();

            visitados.Add(inicio.Id);
            pendientes.Enqueue(inicio.Id);

            while (pendientes.Count > 0 &&
                   visitados.Count < MAX_ELEMENTOS_RAMAL)
            {
                ElementId actualId = pendientes.Dequeue();
                Element actual = doc.GetElement(actualId);

                if (actual == null)
                    continue;

                foreach (Connector conector in ObtenerConectoresFisicos(actual))
                {
                    ConnectorSet referencias;

                    try
                    {
                        referencias = conector.AllRefs;
                    }
                    catch
                    {
                        continue;
                    }

                    foreach (Connector referencia in referencias)
                    {
                        if (referencia == null || referencia.Owner == null)
                            continue;

                        Element propietario = referencia.Owner;

                        if (propietario.Document == null ||
                            !propietario.Document.Equals(doc))
                        {
                            continue;
                        }

                        if (propietario.Id == excluir ||
                            propietario.Id == actual.Id)
                        {
                            continue;
                        }

                        if (!(propietario is MEPCurve) &&
                            !(propietario is FamilyInstance))
                        {
                            continue;
                        }

                        if (visitados.Add(propietario.Id))
                            pendientes.Enqueue(propietario.Id);
                    }
                }
            }

            return visitados;
        }

        private static XYZ ObtenerCentroCurva(MEPCurve curva)
        {
            LocationCurve location = curva == null
                ? null
                : curva.Location as LocationCurve;

            if (location != null && location.Curve != null)
                return location.Curve.Evaluate(0.5, true);

            return XYZ.Zero;
        }

        private static void ConfigurarFallos(Transaction transaccion)
        {
            try
            {
                FailureHandlingOptions opciones = transaccion.GetFailureHandlingOptions();
                opciones.SetFailuresPreprocessor(new MEP3DWarningsPreprocessor());
                transaccion.SetFailureHandlingOptions(opciones);
            }
            catch
            {
            }
        }

        private static void ConfigurarFallosAlineacion(
            Transaction transaccion)
        {
            try
            {
                FailureHandlingOptions opciones = transaccion
                    .GetFailureHandlingOptions();

                opciones.SetFailuresPreprocessor(
                    new MEP3DMoveAlignFailuresPreprocessor());

                opciones.SetClearAfterRollback(true);
                transaccion.SetFailureHandlingOptions(opciones);
            }
            catch
            {
            }
        }

        private static void ValidarId(
            ElementId id,
            string descripcion)
        {
            if (id == null || id == ElementId.InvalidElementId)
            {
                throw new InvalidOperationException(
                    "No se encontró un " + descripcion + " válido en el proyecto.");
            }
        }

        private static double LimitarProducto(double producto)
        {
            if (producto < -1.0)
                return -1.0;

            if (producto > 1.0)
                return 1.0;

            return producto;
        }

        private static double MmAInterno(double mm)
        {
            return UnitUtils.ConvertToInternalUnits(
                mm,
                UnitTypeId.Millimeters);
        }

        private static double InternoAMm(double pies)
        {
            return UnitUtils.ConvertFromInternalUnits(
                pies,
                UnitTypeId.Millimeters);
        }

        private static void MostrarError(
            string titulo,
            string texto)
        {
            try
            {
                TaskDialog.Show(titulo, texto ?? "Error desconocido.");
            }
            catch
            {
            }
        }

        private sealed class ConnectorPair
        {
            public Connector Destino { get; set; }
            public Connector Movil { get; set; }
        }

        private sealed class RevitWindowHandle : System.Windows.Forms.IWin32Window
        {
            private readonly IntPtr _handle;

            public RevitWindowHandle(IntPtr handle)
            {
                _handle = handle;
            }

            public IntPtr Handle
            {
                get { return _handle; }
            }
        }
    }

    internal sealed class MEP3DMoveAlignFailuresPreprocessor : IFailuresPreprocessor
    {
        public FailureProcessingResult PreprocessFailures(
            FailuresAccessor failuresAccessor)
        {
            IList<FailureMessageAccessor> mensajes = failuresAccessor
                .GetFailureMessages();

            bool existeError = false;

            foreach (FailureMessageAccessor mensaje in mensajes)
            {
                if (mensaje.GetSeverity() == FailureSeverity.Warning)
                {
                    failuresAccessor.DeleteWarning(mensaje);
                }
                else if (mensaje.GetSeverity() == FailureSeverity.Error)
                {
                    existeError = true;
                }
            }

            return existeError
                ? FailureProcessingResult.ProceedWithRollBack
                : FailureProcessingResult.Continue;
        }
    }

    internal sealed class MEP3DWarningsPreprocessor : IFailuresPreprocessor
    {
        public FailureProcessingResult PreprocessFailures(
            FailuresAccessor failuresAccessor)
        {
            IList<FailureMessageAccessor> mensajes = failuresAccessor
                .GetFailureMessages();

            foreach (FailureMessageAccessor mensaje in mensajes)
            {
                if (mensaje.GetSeverity() == FailureSeverity.Warning)
                    failuresAccessor.DeleteWarning(mensaje);
            }

            return FailureProcessingResult.Continue;
        }
    }

    internal sealed class MEP3DDestinationSelectionFilter : ISelectionFilter
    {
        public bool AllowElement(Element element)
        {
            if (element == null || element is RevitLinkInstance)
                return false;

            // La primera selección puede ser:
            // - un tramo MEP;
            // - un aparato/familia con conectores;
            // - una familia sin ConnectorManager, usando el centro de su cara.
            return element is MEPCurve ||
                   element is FamilyInstance;
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            return true;
        }
    }

    internal sealed class MEP3DConnectorOwnerSelectionFilter : ISelectionFilter
    {
        public bool AllowElement(Element element)
        {
            if (element == null || element is RevitLinkInstance)
                return false;

            return element is MEPCurve ||
                   (element is FamilyInstance &&
                    ((FamilyInstance)element).MEPModel != null);
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            return true;
        }
    }

    internal sealed class MEP3DCurveSelectionFilter : ISelectionFilter
    {
        public bool AllowElement(Element element)
        {
            return element is Pipe ||
                   element is Duct ||
                   element is Conduit ||
                   element is CableTray;
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            return true;
        }
    }

    internal sealed class MEP3DFlippableFamilySelectionFilter : ISelectionFilter
    {
        public bool AllowElement(Element element)
        {
            FamilyInstance familia = element as FamilyInstance;

            return familia != null &&
                   (familia.CanFlipFacing ||
                    familia.CanFlipHand ||
                    familia.CanRotate);
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            return true;
        }
    }
}

