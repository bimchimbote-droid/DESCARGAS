﻿/*
=========================================================
MYG - Cables DirectShape por Circuitos
VERSIÓN V39 - CONDUITS + COLORES + SIN RETORNO DE GRUPOS

Base tomada desde:
EjecutarEleCablesDirectShapeHandler_v37_conduits_colores.cs

Cambios:
- Mantiene categoría OST_Conduit.
- Mantiene relleno del cable con color del circuito/Excel.
- Mantiene contorno negro.
- Mantiene optimización V35.
- No altera geometría ni creación de DirectShape.
- Se descarta la corrección agresiva de V38.
- Nueva corrección conservadora: solo invierte un tramo vertical completo
  si eso reduce cruces globales; no reordena grupos por circuito en cada curva.
=========================================================
*/

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using OfficeOpenXml;

namespace MYG_Addin
{
    public enum EleCablesDSRequest
    {
        None,
        SeleccionarBandejas,
        GenerarDirectShape,
        BorrarDirectShape
    }

    public class EjecutarEleCablesDirectShapeHandler : IExternalEventHandler
    {
        private const string AppId = "MYG_CABLES_DIRECTSHAPE_53";
        private const string MarcaGenerado = "MYG_CABLES_DS";

        // =========================================================
        // OPT V35:
        // Caché temporal por ejecución.
        // La detección de cruces llama muchas veces a ObtenerPuertosDeAccesorio.
        // Esa función vuelve a leer conectores y referencias MEP del accesorio.
        // Como los puertos/conectores no cambian durante EjecutarGenerar,
        // se cachean por Id de accesorio. Los CableInstancia quedan por referencia,
        // por eso si cambia su Offset, el cálculo sigue usando el valor actualizado.
        // =========================================================
        private readonly Dictionary<long, List<PuertoFitting>> _cachePuertosAccesorio =
            new Dictionary<long, List<PuertoFitting>>();

        public EleCablesDSRequest Request { get; set; } = EleCablesDSRequest.None;

        public EleCablesDirectShapeForm Form { get; set; }

        public List<ElementId> ElementosIds { get; set; } = new List<ElementId>();

        public string RutaExcelCircuitos { get; set; } = "";
        public string ParametroCircuitos { get; set; } = "ELE_Circuitos";
        public string ParametroNCables { get; set; } = "ELE_N°Cables";

        public double DiametroCableMmDefault { get; set; } = 10.0;
        public double SeparacionCableMm { get; set; } = 3.0;
        public double MargenLateralMm { get; set; } = 15.0;
        public double MargenFondoMm { get; set; } = 15.0;
        public int MaxCablesPorElemento { get; set; } = 120;

        public bool CrearTramosRectos { get; set; } = true;
        public bool CrearCurvasEnUniones { get; set; } = true;
        public bool ActualizarParametroNCables { get; set; } = true;
        public bool BorrarAnteriores { get; set; } = true;
        public bool SeleccionarResultado { get; set; } = true;
        public bool ForzarRutasAmbiguas { get; set; } = true;

        public string GetName()
        {
            return "MYG - Cables DirectShape por circuitos";
        }

        public void Execute(UIApplication app)
        {
            try
            {
                UIDocument uidoc = app.ActiveUIDocument;

                if (uidoc == null || uidoc.Document == null)
                    return;

                Document doc = uidoc.Document;

                if (Request == EleCablesDSRequest.SeleccionarBandejas)
                {
                    EjecutarSeleccionar(uidoc, doc);
                }
                else if (Request == EleCablesDSRequest.GenerarDirectShape)
                {
                    EjecutarGenerar(uidoc, doc);
                }
                else if (Request == EleCablesDSRequest.BorrarDirectShape)
                {
                    EjecutarBorrar(uidoc, doc, true);
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
            }
            catch (Exception ex)
            {
                TaskDialog.Show("MYG - Error", ex.ToString());
            }
            finally
            {
                Request = EleCablesDSRequest.None;
            }
        }

        private void EjecutarSeleccionar(UIDocument uidoc, Document doc)
        {
            IList<Reference> refs = uidoc.Selection.PickObjects(
                ObjectType.Element,
                new FiltroBandejaCableYAccesorio(),
                "Selecciona SOLO las bandejas y/o accesorios donde quieres crear cables");

            if (refs == null || refs.Count == 0)
                return;

            ElementosIds.Clear();

            List<Element> elementos = new List<Element>();

            foreach (Reference r in refs)
            {
                if (r == null)
                    continue;

                Element e = doc.GetElement(r.ElementId);

                if (e == null)
                    continue;

                if (ElementosIds.Any(x => x.Value == e.Id.Value))
                    continue;

                ElementosIds.Add(e.Id);
                elementos.Add(e);
            }

            if (Form != null && !Form.IsDisposed)
                Form.SetElementosSeleccionados(elementos);
        }

        private void EjecutarGenerar(UIDocument uidoc, Document doc)
        {
            // OPT V35: limpiar caché en cada ejecución para no mezclar selecciones anteriores.
            _cachePuertosAccesorio.Clear();

            if (string.IsNullOrWhiteSpace(RutaExcelCircuitos) || !File.Exists(RutaExcelCircuitos))
            {
                TaskDialog.Show("MYG", "Selecciona un Excel maestro válido.");
                return;
            }

            if (string.IsNullOrWhiteSpace(ParametroCircuitos))
                ParametroCircuitos = "ELE_Circuitos";

            if (string.IsNullOrWhiteSpace(ParametroNCables))
                ParametroNCables = "ELE_N°Cables";

            Dictionary<string, List<CableDef>> maestro = CargarCircuitosDesdeExcel(RutaExcelCircuitos);

            if (maestro.Count == 0)
            {
                TaskDialog.Show(
                    "MYG",
                    "No se encontraron circuitos activos en la hoja Circuitos_Master.");
                return;
            }

            HashSet<ElementId> seleccionIds = ObtenerIdsBaseDesdeVentanaOSeleccion(uidoc, doc);

            if (seleccionIds.Count == 0)
            {
                TaskDialog.Show(
                    "MYG",
                    "Selecciona bandejas rectas y/o accesorios de bandeja.");
                return;
            }

            HashSet<ElementId> bandejaIds = new HashSet<ElementId>(new ElementIdComparer());
            HashSet<ElementId> accesorioIds = new HashSet<ElementId>(new ElementIdComparer());

            foreach (ElementId id in seleccionIds)
            {
                Element e = doc.GetElement(id);

                if (e == null)
                    continue;

                if (EsBandejaCable(e))
                    bandejaIds.Add(id);
                else if (EsAccesorioBandeja(e))
                    accesorioIds.Add(id);
            }

            Dictionary<ElementId, List<CableInstancia>> cablesPorBandeja =
                new Dictionary<ElementId, List<CableInstancia>>(new ElementIdComparer());

            int bandejasSinCircuitos = 0;
            int circuitosNoEncontrados = 0;
            List<string> advertencias = new List<string>();

            foreach (ElementId id in bandejaIds)
            {
                Element bandeja = doc.GetElement(id);

                if (bandeja == null)
                    continue;

                string textoCircuitos = ObtenerParametroTexto(bandeja, ParametroCircuitos);

                if (string.IsNullOrWhiteSpace(textoCircuitos))
                {
                    bandejasSinCircuitos++;
                    continue;
                }

                List<string> circuitos = ExpandirTextoCircuitos(textoCircuitos);

                if (circuitos.Count == 0)
                {
                    bandejasSinCircuitos++;
                    continue;
                }

                List<CableInstancia> lista = CrearInstanciasDesdeCircuitos(
                    circuitos,
                    maestro,
                    bandeja.Id,
                    out int noEncontrados);

                circuitosNoEncontrados += noEncontrados;

                if (lista.Count == 0)
                    continue;

                AsignarOffsetsACables(doc, bandeja, lista);

                cablesPorBandeja[id] = lista;
            }

            if (cablesPorBandeja.Count == 0)
            {
                TaskDialog.Show(
                    "MYG",
                    "No hay bandejas seleccionadas con el parámetro '" +
                    ParametroCircuitos + "' y circuitos válidos en Excel.");
                return;
            }

            // V14: alinea los carriles por identidad de cable en toda la selección.
            // Así el mismo CableKey conserva el mismo orden/carril relativo en todos los tramos,
            // aunque ELE_Circuitos haya sido escrito en distinto orden por bandeja.
            ReasignarOffsetsGlobalesPorIdentidad(doc, cablesPorBandeja, accesorioIds);

            // V18:
            // Primero se asigna el orden ascendente por circuito.
            // Luego, si una T/codo genera cruces, se reordena el carril EN LA BANDEJA COMPLETA,
            // no solo dentro del accesorio. Así el cable sigue continuo y además se reducen cruces.
            OptimizarCarrilesGlobalesSinCruceManteniendoContinuidad(
                doc,
                cablesPorBandeja,
                accesorioIds,
                bandejaIds);

            // V21:
            // Refuerzo especial para codos/T en cualquier orientación.
            // Primero mantiene continuidad por CableKey y luego prueba reordenar
            // carriles en la BANDEJA COMPLETA de cada puerto conectado.
            // La evaluación ya no usa solo la línea recta entre conectores,
            // sino el recorrido segmentado real que se dibuja en el accesorio.
            ForzarSinCrucesPorRecorridoSegmentadoEnAccesorios(
                doc,
                cablesPorBandeja,
                accesorioIds,
                bandejaIds);

            // V27:
            // Partiendo de la base estable V24, se agrega SOLO una pasada final de orden.
            // No modifica geometría, Excel, colores ni creación de DirectShape.
            // Únicamente intercambia carriles completos dentro de cada bandeja si eso
            // reduce cruces reales en los accesorios/codos/T seleccionados.
            ForzarOrdenFinalSoloSiReduceCruces(
                doc,
                cablesPorBandeja,
                accesorioIds,
                bandejaIds);

            // V29:
            // Corrección puntual sobre V27 para codos/curvas inclinadas.
            // No modifica la geometría ni los parámetros; solo fuerza el orden de carriles
            // cuando todavía queda un cruce real en 3D dentro de un accesorio de 2 puertos.
            ForzarCodosInclinadosSinCruce3DEstrictoV29(
                doc,
                cablesPorBandeja,
                accesorioIds,
                bandejaIds);

            // V39:
            // Corrección conservadora para bajadas/subidas.
            // NO reordena cada tramo vertical por circuito, porque eso puede
            // invertir un grupo y luego regresarlo en la siguiente curva.
            // Solo corrige cuando un tramo vertical queda completamente invertido
            // respecto a una bandeja horizontal/inclinada vecina.
            CorregirSoloInversionCompletaEnTramosVerticales(
                doc,
                cablesPorBandeja,
                accesorioIds,
                bandejaIds);

            if (Form != null && !Form.IsDisposed)
            {
                Form.MostrarResultado("Generando cables DirectShape individuales...");
                Form.AgregarResultado("Circuitos maestros cargados: " + maestro.Count);
                Form.AgregarResultado("Bandejas válidas: " + cablesPorBandeja.Count);
                Form.AgregarResultado("Accesorios seleccionados: " + accesorioIds.Count);
            }

            List<ElementId> creados = new List<ElementId>();
            int rectosCreados = 0;
            int unionesCreadas = 0;
            int accesoriosProcesados = 0;
            int accesoriosSinPares = 0;
            int ambiguos = 0;

            using (Transaction t = new Transaction(doc, "MYG - Cables DirectShape por circuitos"))
            {
                t.Start();

                if (BorrarAnteriores)
                {
                    int borrados = BorrarDirectShapesPrevios(doc);

                    if (Form != null && !Form.IsDisposed)
                        Form.AgregarResultado("DirectShape anteriores borrados: " + borrados);
                }

                if (ActualizarParametroNCables)
                {
                    foreach (KeyValuePair<ElementId, List<CableInstancia>> kvp in cablesPorBandeja)
                    {
                        Element bandeja = doc.GetElement(kvp.Key);

                        if (bandeja == null)
                            continue;

                        SetParametroEntero(bandeja, ParametroNCables, kvp.Value.Count);
                    }
                }

                if (CrearTramosRectos)
                {
                    foreach (KeyValuePair<ElementId, List<CableInstancia>> kvp in cablesPorBandeja)
                    {
                        Element bandeja = doc.GetElement(kvp.Key);

                        if (bandeja == null)
                            continue;

                        List<ElementId> idsCreados = CrearDirectShapesRectosEnBandeja(
                            doc,
                            bandeja,
                            kvp.Value);

                        creados.AddRange(idsCreados);
                        rectosCreados += idsCreados.Count;
                    }
                }

                if (CrearCurvasEnUniones)
                {
                    foreach (ElementId idAcc in accesorioIds)
                    {
                        Element accesorio = doc.GetElement(idAcc);

                        if (accesorio == null)
                            continue;

                        List<PuertoFitting> puertos = ObtenerPuertosDeAccesorio(
                            doc,
                            accesorio,
                            cablesPorBandeja,
                            bandejaIds);

                        if (puertos.Count < 2)
                            continue;

                        accesoriosProcesados++;

                        int ambiguosAccesorio = 0;

                        List<ParCableFitting> pares = InferirParesPorIdentidad(
                            puertos,
                            out ambiguosAccesorio);

                        ambiguos += ambiguosAccesorio;

                        if (pares.Count == 0)
                        {
                            accesoriosSinPares++;
                            continue;
                        }

                        List<ElementId> idsCreados = CrearDirectShapesEnAccesorio(
                            doc,
                            accesorio,
                            pares);

                        creados.AddRange(idsCreados);
                        unionesCreadas += idsCreados.Count;
                    }
                }

                t.Commit();
            }

            if (SeleccionarResultado && creados.Count > 0)
                uidoc.Selection.SetElementIds(creados);

            if (Form != null && !Form.IsDisposed)
            {
                Form.AgregarResultado("Cables rectos creados: " + rectosCreados);
                Form.AgregarResultado("Cables en accesorios creados: " + unionesCreadas);
                Form.AgregarResultado("Accesorios procesados: " + accesoriosProcesados);
                Form.AgregarResultado("Accesorios sin pares: " + accesoriosSinPares);
                Form.AgregarResultado("Bandejas sin ELE_Circuitos: " + bandejasSinCircuitos);
                Form.AgregarResultado("Circuitos no encontrados en Excel: " + circuitosNoEncontrados);
                Form.AgregarResultado("Cables ambiguos en accesorios: " + ambiguos);
                Form.AgregarResultado("Total DirectShape individuales: " + creados.Count);
            }

            string mensaje =
                "Proceso finalizado.\n\n" +
                "Cables rectos creados: " + rectosCreados + "\n" +
                "Cables en accesorios creados: " + unionesCreadas + "\n" +
                "Total DirectShape individuales: " + creados.Count + "\n\n" +
                "Bandejas sin '" + ParametroCircuitos + "': " + bandejasSinCircuitos + "\n" +
                "Circuitos no encontrados en Excel: " + circuitosNoEncontrados + "\n" +
                "Cables ambiguos en accesorios: " + ambiguos + "\n\n" +
                "Parámetro usado en bandeja: " + ParametroCircuitos;

            TaskDialog.Show("MYG - Cables DirectShape", mensaje);
        }

        private void EjecutarBorrar(UIDocument uidoc, Document doc, bool mostrarDialogo)
        {
            int borrados = 0;

            using (Transaction t = new Transaction(doc, "MYG - Borrar cables DirectShape"))
            {
                t.Start();
                borrados = BorrarDirectShapesPrevios(doc);
                t.Commit();
            }

            if (Form != null && !Form.IsDisposed)
                Form.MostrarResultado("DirectShape de cables borrados: " + borrados);

            if (mostrarDialogo)
                TaskDialog.Show("MYG - Cables DirectShape", "DirectShape de cables borrados: " + borrados);
        }

        private Dictionary<string, List<CableDef>> CargarCircuitosDesdeExcel(string ruta)
        {
            Dictionary<string, List<CableDef>> resultado =
                new Dictionary<string, List<CableDef>>(StringComparer.OrdinalIgnoreCase);

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (ExcelPackage package = new ExcelPackage(new FileInfo(ruta)))
            {
                ExcelWorksheet ws = null;

                foreach (ExcelWorksheet s in package.Workbook.Worksheets)
                {
                    if (s == null)
                        continue;

                    if (string.Equals(s.Name, "Circuitos_Master", StringComparison.OrdinalIgnoreCase))
                    {
                        ws = s;
                        break;
                    }
                }

                if (ws == null && package.Workbook.Worksheets.Count > 0)
                    ws = package.Workbook.Worksheets.FirstOrDefault();

                if (ws == null || ws.Dimension == null)
                    return resultado;

                Dictionary<string, int> col = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

                int lastCol = ws.Dimension.End.Column;
                int lastRow = ws.Dimension.End.Row;

                for (int c = 1; c <= lastCol; c++)
                {
                    string h = NormalizarHeader(Convert.ToString(ws.Cells[1, c].Text));

                    if (!string.IsNullOrWhiteSpace(h) && !col.ContainsKey(h))
                        col[h] = c;
                }

                int colCircuito = BuscarCol(col, "CIRCUITO");
                int colNombre = BuscarCol(col, "NOMBRECIRCUITO", "NOMBRE_CIRCUITO", "NOMBRE");
                int colSistema = BuscarCol(col, "SISTEMA");
                int colTipo = BuscarCol(col, "TIPOCABLE", "TIPO_CABLE", "CABLE");
                int colCantidad = BuscarCol(col, "CANTIDAD", "NUMERO", "N");
                int colDiametro = BuscarCol(col, "DIAMETRO_MM", "DIAMETROMM", "DIAMETRO");
                int colColor = BuscarCol(col, "COLORRGB", "COLOR_RGB", "RGB", "COLOR");
                int colActivo = BuscarCol(col, "ACTIVO");

                if (colCircuito <= 0 || colTipo <= 0 || colCantidad <= 0)
                    return resultado;

                for (int r = 2; r <= lastRow; r++)
                {
                    string circuito = NormalizarCircuito(LeerTexto(ws, r, colCircuito));

                    if (string.IsNullOrWhiteSpace(circuito))
                        continue;

                    string activo = colActivo > 0 ? LeerTexto(ws, r, colActivo).Trim().ToUpperInvariant() : "SI";

                    if (activo == "NO" || activo == "0" || activo == "FALSE" || activo == "FALSO")
                        continue;

                    string tipo = LeerTexto(ws, r, colTipo).Trim();

                    if (string.IsNullOrWhiteSpace(tipo))
                        continue;

                    int cantidad = LeerEntero(ws, r, colCantidad);

                    if (cantidad <= 0)
                        continue;

                    CableDef def = new CableDef
                    {
                        Circuito = circuito,
                        NombreCircuito = colNombre > 0 ? LeerTexto(ws, r, colNombre).Trim() : "",
                        Sistema = colSistema > 0 ? LeerTexto(ws, r, colSistema).Trim() : "",
                        TipoCable = tipo,
                        Cantidad = cantidad,
                        DiametroMm = colDiametro > 0 ? LeerDouble(ws, r, colDiametro, DiametroCableMmDefault) : DiametroCableMmDefault,
                        Color = colColor > 0 ? ParseColor(LeerTexto(ws, r, colColor)) : ColorPorSistema(colSistema > 0 ? LeerTexto(ws, r, colSistema) : "")
                    };

                    if (def.DiametroMm <= 0)
                        def.DiametroMm = DiametroCableMmDefault;

                    if (!resultado.ContainsKey(circuito))
                        resultado[circuito] = new List<CableDef>();

                    resultado[circuito].Add(def);
                }
            }

            return resultado;
        }

        private List<CableInstancia> CrearInstanciasDesdeCircuitos(
            List<string> circuitos,
            Dictionary<string, List<CableDef>> maestro,
            ElementId bandejaId,
            out int circuitosNoEncontrados)
        {
            circuitosNoEncontrados = 0;

            List<CableInstancia> lista = new List<CableInstancia>();
            int orden = 0;

            foreach (string circuitoOriginal in circuitos)
            {
                string circuito = NormalizarCircuito(circuitoOriginal);

                if (string.IsNullOrWhiteSpace(circuito))
                    continue;

                if (!maestro.ContainsKey(circuito))
                {
                    circuitosNoEncontrados++;
                    continue;
                }

                List<CableDef> defs = maestro[circuito];

                foreach (CableDef def in defs)
                {
                    for (int i = 1; i <= def.Cantidad; i++)
                    {
                        CableInstancia cable = new CableInstancia
                        {
                            Key = CrearCableKey(def.Circuito, def.TipoCable, i),
                            Circuito = def.Circuito,
                            NombreCircuito = def.NombreCircuito,
                            Sistema = def.Sistema,
                            TipoCable = def.TipoCable,
                            DiametroMm = def.DiametroMm,
                            Color = def.Color,
                            IndiceEnTipo = i,
                            CantidadTipo = def.Cantidad,
                            Orden = orden,
                            BandejaId = bandejaId
                        };

                        orden++;
                        lista.Add(cable);
                    }
                }
            }

            if (lista.Count > MaxCablesPorElemento)
            {
                lista = lista.Take(MaxCablesPorElemento).ToList();
            }

            return lista;
        }

        private void AsignarOffsetsACables(Document doc, Element bandeja, List<CableInstancia> cables)
        {
            if (bandeja == null || cables == null || cables.Count == 0)
                return;

            LocationCurve lc = bandeja.Location as LocationCurve;

            if (lc == null || lc.Curve == null)
                return;

            double ancho;
            double alto;
            ObtenerDimensionesBandeja(doc, bandeja, out ancho, out alto);

            XYZ tangent = ObtenerTangenteInicio(lc.Curve);

            if (EsVectorCero(tangent))
                tangent = ObtenerDireccionPrincipal(bandeja);

            if (EsVectorCero(tangent))
                tangent = XYZ.BasisX;

            tangent = tangent.Normalize();

            XYZ lateral;
            XYZ vertical;
            CalcularBaseLocalDesdeBandeja(doc, bandeja, lc.Curve, tangent, out lateral, out vertical);

            int cantidad = cables.Count;
            double radioMax = MmToFeet(cables.Max(x => Math.Max(x.DiametroMm, 1.0)) / 2.0);
            double separacion = MmToFeet(SeparacionCableMm);
            double margenLateral = MmToFeet(MargenLateralMm);
            double margenFondo = MmToFeet(MargenFondoMm);

            double paso = radioMax * 2.0 + separacion;
            double anchoUtil = Math.Max(ancho - 2.0 * margenLateral, radioMax * 2.0);
            int porFila = Math.Max(1, (int)Math.Floor((anchoUtil + separacion) / paso));

            for (int i = 0; i < cables.Count; i++)
            {
                int fila = i / porFila;
                int columna = i % porFila;

                int restantes = cantidad - fila * porFila;
                int cantidadFila = Math.Min(porFila, restantes);

                double anchoFila = (cantidadFila - 1) * paso;
                double x = -anchoFila / 2.0 + columna * paso;
                double z = -alto / 2.0 + margenFondo + radioMax + fila * paso;

                cables[i].Offset = lateral * x + vertical * z;
                cables[i].DireccionBandeja = tangent;
                cables[i].VectorLateral = lateral;
                cables[i].VectorVertical = vertical;
            }
        }

        // =========================================================
        // V14 - ORDEN GLOBAL POR IDENTIDAD DE CABLE
        //
        // Cada bandeja antes calculaba sus offsets con su propia lista local.
        // Si dos tramos tenían ELE_Circuitos en distinto orden, el mismo cable
        // llegaba a la T en carriles diferentes. Eso mantenía identidad, pero cruzaba.
        //
        // Esta rutina recalcula los offsets usando una lista global de CableKey
        // para toda la selección: C01 siempre ocupa el mismo carril relativo,
        // C02 el siguiente, etc.
        // =========================================================
        // =========================================================
        // V19 - ORDEN ASCENDENTE + COMPACTACIÓN POR TRAMO
        //
        // Problema anterior:
        // El orden global reservaba carriles para todos los circuitos de la red.
        // Cuando algunos cables se desviaban hacia otra rama, los tramos siguientes
        // conservaban huecos porque seguían usando el índice global absoluto.
        //
        // Criterio nuevo:
        // 1. Se mantiene un orden global ascendente por identidad de cable:
        //    C01, C02, C03, etc.
        // 2. En cada bandeja se toman solo los cables que realmente pasan por ese tramo.
        // 3. Esos cables se compactan nuevamente sin huecos, manteniendo el orden ascendente.
        // 4. Los accesorios usan los mismos offsets de cada tramo, por eso la continuidad
        //    se mantiene en la unión/T/codo.
        // =========================================================
        private void ReasignarOffsetsGlobalesPorIdentidad(
            Document doc,
            Dictionary<ElementId, List<CableInstancia>> cablesPorBandeja,
            HashSet<ElementId> accesorioIds)
        {
            if (doc == null || cablesPorBandeja == null || cablesPorBandeja.Count == 0)
                return;

            Dictionary<string, CableInstancia> muestraPorKey =
                new Dictionary<string, CableInstancia>(StringComparer.OrdinalIgnoreCase);

            foreach (KeyValuePair<ElementId, List<CableInstancia>> kvp in cablesPorBandeja)
            {
                if (kvp.Value == null)
                    continue;

                foreach (CableInstancia c in kvp.Value)
                {
                    if (c == null || string.IsNullOrWhiteSpace(c.Key))
                        continue;

                    if (!muestraPorKey.ContainsKey(c.Key))
                        muestraPorKey[c.Key] = c;
                }
            }

            List<CableInstancia> ordenGlobal = muestraPorKey.Values
                .OrderBy(x => ObtenerOrdenCircuito(x.Circuito))
                .ThenBy(x => NormalizarTextoSeguro(x.Circuito))
                .ThenBy(x => NormalizarTextoSeguro(x.TipoCable))
                .ThenBy(x => x.IndiceEnTipo)
                .ThenBy(x => NormalizarTextoSeguro(x.Key))
                .ToList();

            if (ordenGlobal.Count == 0)
                return;

            Dictionary<string, int> indiceGlobalPorKey =
                new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            for (int i = 0; i < ordenGlobal.Count; i++)
            {
                if (!string.IsNullOrWhiteSpace(ordenGlobal[i].Key) &&
                    !indiceGlobalPorKey.ContainsKey(ordenGlobal[i].Key))
                {
                    indiceGlobalPorKey[ordenGlobal[i].Key] = i;
                }
            }

            double diametroMaxMm = DiametroCableMmDefault;

            foreach (CableInstancia c in ordenGlobal)
            {
                if (c != null)
                    diametroMaxMm = Math.Max(diametroMaxMm, c.DiametroMm);
            }

            double radioMax = MmToFeet(Math.Max(diametroMaxMm, 1.0) / 2.0);
            double separacion = MmToFeet(SeparacionCableMm);
            double margenLateral = MmToFeet(MargenLateralMm);
            double margenFondo = MmToFeet(MargenFondoMm);

            foreach (KeyValuePair<ElementId, List<CableInstancia>> kvp in cablesPorBandeja)
            {
                Element bandeja = doc.GetElement(kvp.Key);

                if (bandeja == null || kvp.Value == null || kvp.Value.Count == 0)
                    continue;

                LocationCurve lc = bandeja.Location as LocationCurve;

                if (lc == null || lc.Curve == null)
                    continue;

                double ancho;
                double alto;
                ObtenerDimensionesBandeja(doc, bandeja, out ancho, out alto);

                XYZ tangent = ObtenerTangenteInicio(lc.Curve);

                if (EsVectorCero(tangent))
                    tangent = ObtenerDireccionPrincipal(bandeja);

                tangent = CanonicalizarDireccionEnPlanta(tangent);

                if (EsVectorCero(tangent))
                    tangent = XYZ.BasisX;

                tangent = tangent.Normalize();

                XYZ lateral;
                XYZ vertical;
                CalcularBaseLocalDesdeBandeja(doc, bandeja, lc.Curve, tangent, out lateral, out vertical);

                double paso = radioMax * 2.0 + separacion;
                double anchoUtil = Math.Max(ancho - 2.0 * margenLateral, radioMax * 2.0);
                int porFila = Math.Max(1, (int)Math.Floor((anchoUtil + separacion) / paso));

                // V19:
                // La lista local se ordena por el índice global, pero se compacta con índice local.
                // Así, si en una rama quedan solo C07-C10, ya no ocupan los carriles 7-10;
                // ocupan los carriles 0-3, manteniendo el orden ascendente entre ellos.
                List<CableInstancia> cablesLocales = kvp.Value
                    .Where(x => x != null)
                    .OrderBy(x => ObtenerIndiceGlobalSeguro(x, indiceGlobalPorKey))
                    .ThenBy(x => ObtenerOrdenCircuito(x.Circuito))
                    .ThenBy(x => NormalizarTextoSeguro(x.Circuito))
                    .ThenBy(x => NormalizarTextoSeguro(x.TipoCable))
                    .ThenBy(x => x.IndiceEnTipo)
                    .ThenBy(x => NormalizarTextoSeguro(x.Key))
                    .ToList();

                int cantidadLocal = cablesLocales.Count;

                for (int i = 0; i < cablesLocales.Count; i++)
                {
                    CableInstancia cable = cablesLocales[i];

                    int indiceGlobal = ObtenerIndiceGlobalSeguro(cable, indiceGlobalPorKey);
                    int fila = i / porFila;
                    int columna = i % porFila;

                    int restantes = cantidadLocal - fila * porFila;
                    int cantidadFila = Math.Min(porFila, Math.Max(restantes, 1));

                    double anchoFila = (cantidadFila - 1) * paso;
                    double x = -anchoFila / 2.0 + columna * paso;
                    double z = -alto / 2.0 + margenFondo + radioMax + fila * paso;

                    cable.Offset = lateral * x + vertical * z;
                    cable.DireccionBandeja = tangent;
                    cable.VectorLateral = lateral;
                    cable.VectorVertical = vertical;
                    cable.Orden = indiceGlobal;
                }

                // Reordena físicamente la lista para que el resto de métodos trabaje
                // con la misma secuencia compacta del tramo.
                kvp.Value.Sort(delegate (CableInstancia a, CableInstancia b)
                {
                    int ia = ObtenerIndiceGlobalSeguro(a, indiceGlobalPorKey);
                    int ib = ObtenerIndiceGlobalSeguro(b, indiceGlobalPorKey);

                    if (ia != ib)
                        return ia.CompareTo(ib);

                    int ca = ObtenerOrdenCircuito(a == null ? "" : a.Circuito);
                    int cb = ObtenerOrdenCircuito(b == null ? "" : b.Circuito);

                    if (ca != cb)
                        return ca.CompareTo(cb);

                    return string.Compare(
                        ObtenerCableKeySeguro(a),
                        ObtenerCableKeySeguro(b),
                        StringComparison.OrdinalIgnoreCase);
                });
            }
        }

        private int ObtenerIndiceGlobalSeguro(
            CableInstancia cable,
            Dictionary<string, int> indiceGlobalPorKey)
        {
            if (cable == null)
                return int.MaxValue;

            if (!string.IsNullOrWhiteSpace(cable.Key) &&
                indiceGlobalPorKey != null &&
                indiceGlobalPorKey.ContainsKey(cable.Key))
            {
                return indiceGlobalPorKey[cable.Key];
            }

            return Math.Max(cable.Orden, 0);
        }

        private XYZ CanonicalizarDireccionEnPlanta(XYZ direccion)
        {
            if (EsVectorCero(direccion))
                return XYZ.BasisX;

            XYZ dir = direccion.Normalize();

            // Evita que una bandeja dibujada en sentido contrario invierta
            // izquierda/derecha de carriles.
            if (Math.Abs(dir.X) >= Math.Abs(dir.Y))
            {
                if (dir.X < 0.0)
                    dir = -dir;
            }
            else
            {
                if (dir.Y < 0.0)
                    dir = -dir;
            }

            return dir;
        }

        private int ObtenerOrdenCircuito(string circuito)
        {
            if (string.IsNullOrWhiteSpace(circuito))
                return int.MaxValue;

            string texto = circuito.Trim().ToUpperInvariant();
            string digitos = "";

            foreach (char ch in texto)
            {
                if (char.IsDigit(ch))
                    digitos += ch;
            }

            int n;

            if (int.TryParse(digitos, out n))
                return n;

            return int.MaxValue;
        }

        private string NormalizarTextoSeguro(string texto)
        {
            if (texto == null)
                return "";

            return texto.Trim().ToUpperInvariant();
        }


        // =========================================================
        // V39 - CORRECCIÓN CONSERVADORA DE BAJADAS / SUBIDAS
        //
        // Problema de V38:
        // Reordenar cada tramo vertical por circuito podía provocar:
        // - un grupo se invierte en una curva;
        // - el mismo grupo vuelve a su orden anterior en la siguiente;
        // - se generan cruces innecesarios.
        //
        // Criterio V39:
        // - NO reordena grupos por circuito en cada tramo vertical.
        // - NO mueve cables individuales.
        // - Solo si detecta que TODO el tramo vertical está invertido
        //   respecto a una bandeja vecina conectada, invierte el orden completo
        //   de carriles una sola vez.
        // - Así se conserva continuidad y se evita el efecto de "invierte y regresa".
        // =========================================================
        private void CorregirSoloInversionCompletaEnTramosVerticales(
            Document doc,
            Dictionary<ElementId, List<CableInstancia>> cablesPorBandeja,
            HashSet<ElementId> accesorioIds,
            HashSet<ElementId> bandejaIds)
        {
            if (doc == null || cablesPorBandeja == null || cablesPorBandeja.Count == 0)
                return;

            if (accesorioIds == null || accesorioIds.Count == 0)
                return;

            int crucesBase = ContarCrucesGlobalesEnAccesoriosPorRecorridoSegmentado(
                doc,
                cablesPorBandeja,
                accesorioIds,
                bandejaIds);

            double penalBase = CalcularPenalizacionOrdenAscendente(cablesPorBandeja);

            foreach (KeyValuePair<ElementId, List<CableInstancia>> kvp in cablesPorBandeja)
            {
                Element bandeja = doc.GetElement(kvp.Key);

                if (bandeja == null)
                    continue;

                if (!EsTramoVerticalOInclinacionFuerte(bandeja))
                    continue;

                List<CableInstancia> cables = kvp.Value;

                if (cables == null || cables.Count <= 1)
                    continue;

                // No tocar tramos donde hay varias filas en altura.
                // El swap completo es seguro principalmente cuando es una sola fila de cables.
                if (TieneMultiplesFilasDeCables(cables))
                    continue;

                List<EstadoOffsetCable> estado = GuardarOffsetsCables(cables);

                InvertirOffsetsEnBandeja(cables);

                int crucesNuevo = ContarCrucesGlobalesEnAccesoriosPorRecorridoSegmentado(
                    doc,
                    cablesPorBandeja,
                    accesorioIds,
                    bandejaIds);

                double penalNuevo = CalcularPenalizacionOrdenAscendente(cablesPorBandeja);

                bool aceptar =
                    crucesNuevo < crucesBase ||
                    (crucesNuevo == crucesBase && penalNuevo < penalBase);

                if (aceptar)
                {
                    crucesBase = crucesNuevo;
                    penalBase = penalNuevo;
                }
                else
                {
                    RestaurarOffsetsCables(estado);
                }
            }
        }

        private bool EsTramoVerticalOInclinacionFuerte(Element bandeja)
        {
            if (bandeja == null)
                return false;

            XYZ dir = XYZ.Zero;

            LocationCurve lc = bandeja.Location as LocationCurve;

            if (lc != null && lc.Curve != null)
                dir = ObtenerTangenteInicio(lc.Curve);

            if (EsVectorCero(dir))
                dir = ObtenerDireccionPrincipal(bandeja);

            if (EsVectorCero(dir))
                return false;

            dir = dir.Normalize();

            // Solo tramos claramente verticales/inclinados fuertes.
            // No se toca una curva casi horizontal para evitar cambios innecesarios.
            return Math.Abs(dir.DotProduct(XYZ.BasisZ)) >= 0.55;
        }

        private bool TieneMultiplesFilasDeCables(List<CableInstancia> cables)
        {
            if (cables == null || cables.Count <= 1)
                return false;

            XYZ vertical = XYZ.Zero;

            foreach (CableInstancia c in cables)
            {
                if (c != null && !EsVectorCero(c.VectorVertical))
                {
                    vertical = c.VectorVertical.Normalize();
                    break;
                }
            }

            if (EsVectorCero(vertical))
                return false;

            double min = double.MaxValue;
            double max = double.MinValue;

            foreach (CableInstancia c in cables)
            {
                if (c == null || c.Offset == null)
                    continue;

                double v = c.Offset.DotProduct(vertical);

                min = Math.Min(min, v);
                max = Math.Max(max, v);
            }

            // Si varía más de medio paso típico, probablemente hay varias filas.
            double tolerancia = MmToFeet(Math.Max(DiametroCableMmDefault, 1.0) * 0.75);

            return (max - min) > tolerancia;
        }


        private List<ElementId> CrearDirectShapesRectosEnBandeja(
            Document doc,
            Element bandeja,
            List<CableInstancia> cables)
        {
            List<ElementId> creados = new List<ElementId>();

            if (bandeja == null || cables == null || cables.Count == 0)
                return creados;

            LocationCurve lc = bandeja.Location as LocationCurve;

            if (lc == null || lc.Curve == null)
                return creados;

            Curve curvaBase = lc.Curve;

            foreach (CableInstancia cable in cables)
            {
                try
                {
                    double radio = MmToFeet(Math.Max(cable.DiametroMm, DiametroCableMmDefault) / 2.0);
                    Curve curvaCable = curvaBase.CreateTransformed(Transform.CreateTranslation(cable.Offset));

                    // V10:
                    // Se regresa a la lógica estable anterior de creación geométrica:
                    // el cable se genera por pequeños cilindros consecutivos sobre la curva.
                    // Esto evita deformaciones raras de CreateSweptGeometry en algunos tramos.
                    List<Solid> solidos = CrearSolidosCablePorCurvaV10(curvaCable, radio);

                    if (solidos == null || solidos.Count == 0)
                        continue;

                    DirectShape ds = CrearDirectShapeIndividual(
                        doc,
                        solidos,
                        cable,
                        bandeja.Id,
                        "RECTO",
                        curvaCable.Length);

                    if (ds != null)
                    {
                        AplicarOverrideGrafico(doc, ds.Id, cable.Color);
                        creados.Add(ds.Id);
                    }
                }
                catch
                {
                }
            }

            return creados;
        }


        private List<PuertoFitting> ObtenerPuertosDeAccesorio(
            Document doc,
            Element accesorio,
            Dictionary<ElementId, List<CableInstancia>> cablesPorBandeja,
            HashSet<ElementId> bandejasSeleccionadas)
        {
            List<PuertoFitting> puertos = new List<PuertoFitting>();

            if (accesorio == null)
                return puertos;

            // OPT V35:
            // Reutiliza puertos ya calculados. Esto no altera la lógica porque:
            // - Punto, dirección y bandeja conectada del puerto no cambian durante la ejecución.
            // - PuertoFitting.Cables apunta a la misma lista de CableInstancia.
            // - Si una rutina intercambia Offset entre cables, el puerto cacheado lo lee actualizado.
            long cacheKey = accesorio.Id.Value;
            List<PuertoFitting> puertosCacheados;

            if (_cachePuertosAccesorio.TryGetValue(cacheKey, out puertosCacheados))
                return puertosCacheados;

            XYZ centro = ObtenerCentroElemento(accesorio);
            List<Connector> conectores = ObtenerConectores(accesorio);

            foreach (Connector cAcc in conectores)
            {
                ConnectorSet refs = null;

                try
                {
                    refs = cAcc.AllRefs;
                }
                catch
                {
                    continue;
                }

                if (refs == null)
                    continue;

                foreach (Connector cOtro in refs)
                {
                    if (!EsConectorValido(cAcc, cOtro))
                        continue;

                    Element tray = cOtro.Owner as Element;

                    if (tray == null)
                        continue;

                    if (!EsBandejaCable(tray))
                        continue;

                    if (!bandejasSeleccionadas.Contains(tray.Id))
                        continue;

                    if (!cablesPorBandeja.ContainsKey(tray.Id))
                        continue;

                    List<CableInstancia> cables = cablesPorBandeja[tray.Id];

                    if (cables == null || cables.Count == 0)
                        continue;

                    XYZ punto = ObtenerOrigenSeguro(cAcc);
                    XYZ dirCentro = punto - centro;

                    if (EsVectorCero(dirCentro))
                        dirCentro = XYZ.BasisX;

                    dirCentro = dirCentro.Normalize();

                    XYZ dirTray = ObtenerDireccionPrincipal(tray);

                    if (EsVectorCero(dirTray))
                        dirTray = -dirCentro;

                    dirTray = dirTray.Normalize();

                    XYZ haciaInterior = centro - punto;
                    XYZ dirHaciaInterior = dirTray;

                    if (!EsVectorCero(haciaInterior))
                    {
                        haciaInterior = haciaInterior.Normalize();

                        if (dirHaciaInterior.DotProduct(haciaInterior) < 0)
                            dirHaciaInterior = -dirHaciaInterior;
                    }

                    PuertoFitting puerto = new PuertoFitting
                    {
                        BandejaId = tray.Id,
                        Punto = punto,
                        DireccionDesdeCentro = dirCentro,
                        DireccionHaciaInterior = dirHaciaInterior.Normalize(),
                        Cables = cables
                    };

                    puertos.Add(puerto);
                }
            }

            puertos = puertos
                .GroupBy(x => x.BandejaId.Value)
                .Select(g => g.First())
                .ToList();

            // OPT V35: guarda los puertos para las siguientes evaluaciones de cruces.
            if (!_cachePuertosAccesorio.ContainsKey(cacheKey))
                _cachePuertosAccesorio[cacheKey] = puertos;

            return puertos;
        }

        private List<ParCableFitting> InferirParesPorIdentidad(
            List<PuertoFitting> puertos,
            out int ambiguos)
        {
            ambiguos = 0;
            List<ParCableFitting> pares = new List<ParCableFitting>();

            if (puertos == null || puertos.Count < 2)
                return pares;

            Dictionary<string, List<CableEnPuerto>> mapa =
                new Dictionary<string, List<CableEnPuerto>>(StringComparer.OrdinalIgnoreCase);

            foreach (PuertoFitting p in puertos)
            {
                foreach (CableInstancia c in p.Cables)
                {
                    if (!mapa.ContainsKey(c.Key))
                        mapa[c.Key] = new List<CableEnPuerto>();

                    mapa[c.Key].Add(new CableEnPuerto
                    {
                        Puerto = p,
                        Cable = c
                    });
                }
            }

            foreach (KeyValuePair<string, List<CableEnPuerto>> kvp in mapa)
            {
                List<CableEnPuerto> lista = kvp.Value;

                if (lista.Count == 2)
                {
                    pares.Add(new ParCableFitting
                    {
                        A = lista[0].Puerto,
                        CableA = lista[0].Cable,
                        B = lista[1].Puerto,
                        CableB = lista[1].Cable
                    });
                }
                else if (lista.Count > 2)
                {
                    ambiguos++;

                    if (ForzarRutasAmbiguas)
                    {
                        CableEnPuerto a;
                        CableEnPuerto b;

                        ObtenerParMasOpuesto(lista, out a, out b);

                        if (a != null && b != null)
                        {
                            pares.Add(new ParCableFitting
                            {
                                A = a.Puerto,
                                CableA = a.Cable,
                                B = b.Puerto,
                                CableB = b.Cable
                            });
                        }
                    }
                }
            }

            // V13 - CONTINUIDAD POR IDENTIDAD:
            // No se reordenan ni se invierten CableA/CableB dentro del accesorio.
            // La versión anterior intentaba evitar cruces intercambiando carriles,
            // pero eso podía romper la continuidad con el tramo recto.
            // Aquí se respeta estrictamente el mismo CableKey que viene desde cada tramo.
            return pares;
        }

        private void ObtenerParMasOpuesto(
            List<CableEnPuerto> lista,
            out CableEnPuerto a,
            out CableEnPuerto b)
        {
            a = null;
            b = null;

            if (lista == null || lista.Count < 2)
                return;

            double mejor = double.MaxValue;

            for (int i = 0; i < lista.Count; i++)
            {
                for (int j = i + 1; j < lista.Count; j++)
                {
                    XYZ d1 = lista[i].Puerto.DireccionDesdeCentro;
                    XYZ d2 = lista[j].Puerto.DireccionDesdeCentro;

                    double dot = 0.0;

                    try
                    {
                        dot = d1.Normalize().DotProduct(d2.Normalize());
                    }
                    catch
                    {
                    }

                    if (dot < mejor)
                    {
                        mejor = dot;
                        a = lista[i];
                        b = lista[j];
                    }
                }
            }
        }

        private List<ParCableFitting> ReordenarParesParaEvitarCruces(List<ParCableFitting> pares)
        {
            if (pares == null || pares.Count <= 2)
                return pares;

            List<ParCableFitting> resultado = new List<ParCableFitting>();

            var grupos = pares.GroupBy(x =>
                x.A.BandejaId.Value < x.B.BandejaId.Value
                    ? x.A.BandejaId.Value + "|" + x.B.BandejaId.Value
                    : x.B.BandejaId.Value + "|" + x.A.BandejaId.Value);

            foreach (var grupo in grupos)
            {
                List<ParCableFitting> lista = grupo.ToList();

                if (lista.Count <= 2)
                {
                    resultado.AddRange(lista);
                    continue;
                }

                int crucesNormal = ContarCrucesPares(lista);
                List<ParCableFitting> invertida = InvertirOrdenB(lista);
                int crucesInvertida = ContarCrucesPares(invertida);

                if (crucesInvertida < crucesNormal)
                    resultado.AddRange(invertida);
                else
                    resultado.AddRange(lista);
            }

            return resultado;
        }

        private List<ParCableFitting> InvertirOrdenB(List<ParCableFitting> lista)
        {
            List<ParCableFitting> res = new List<ParCableFitting>();

            List<CableInstancia> cablesB = lista.Select(x => x.CableB).Reverse().ToList();

            for (int i = 0; i < lista.Count; i++)
            {
                ParCableFitting p = lista[i];

                res.Add(new ParCableFitting
                {
                    A = p.A,
                    CableA = p.CableA,
                    B = p.B,
                    CableB = cablesB[i]
                });
            }

            return res;
        }

        private int ContarCrucesPares(List<ParCableFitting> lista)
        {
            int cruces = 0;

            for (int i = 0; i < lista.Count; i++)
            {
                XYZ a1 = lista[i].A.Punto + ObtenerOffsetPar(lista[i], true);
                XYZ b1 = lista[i].B.Punto + ObtenerOffsetPar(lista[i], false);

                for (int j = i + 1; j < lista.Count; j++)
                {
                    XYZ a2 = lista[j].A.Punto + ObtenerOffsetPar(lista[j], true);
                    XYZ b2 = lista[j].B.Punto + ObtenerOffsetPar(lista[j], false);

                    if (SegmentosCruzadosXY(a1, b1, a2, b2))
                        cruces++;
                }
            }

            return cruces;
        }

        private bool SegmentosCruzadosXY(XYZ a, XYZ b, XYZ c, XYZ d)
        {
            double o1 = OrientacionXY(a, b, c);
            double o2 = OrientacionXY(a, b, d);
            double o3 = OrientacionXY(c, d, a);
            double o4 = OrientacionXY(c, d, b);

            return (o1 * o2 < 0.0) && (o3 * o4 < 0.0);
        }

        private double OrientacionXY(XYZ a, XYZ b, XYZ c)
        {
            return (b.X - a.X) * (c.Y - a.Y) - (b.Y - a.Y) * (c.X - a.X);
        }

        // =========================================================
        // V11 - ORDENAMIENTO AUTOMÁTICO DE CARRILES EN ACCESORIOS
        // Detecta hacia dónde va cada cable dentro del accesorio y le asigna
        // carriles/offsets ordenados por dirección de salida para evitar cruces.
        // =========================================================

        private List<ParCableFitting> PrepararParesConCarrilesSinCruce(
            List<ParCableFitting> pares)
        {
            if (pares == null || pares.Count <= 1)
                return pares;

            List<PuertoFitting> puertos = ObtenerPuertosUnicosDesdePares(pares);

            foreach (PuertoFitting puerto in puertos)
                AsignarCarrilesEnPuerto(pares, puerto, false);

            int mejorCruces = ContarCrucesPares(pares);

            // Segunda pasada: para cada puerto prueba el orden invertido.
            // Se conserva únicamente si reduce cruces.
            foreach (PuertoFitting puerto in puertos)
            {
                List<EstadoOffsetPar> estadoAnterior = GuardarEstadoOffsetsPuerto(pares, puerto);

                AsignarCarrilesEnPuerto(pares, puerto, true);

                int crucesInvertido = ContarCrucesPares(pares);

                if (crucesInvertido <= mejorCruces)
                {
                    mejorCruces = crucesInvertido;
                }
                else
                {
                    RestaurarEstadoOffsetsPuerto(estadoAnterior);
                }
            }

            return pares;
        }

        // =========================================================
        // V13 - CONTINUIDAD FORZADA POR IDENTIDAD CON TRAMOS RECTOS
        // El accesorio ya no inventa/reordena offsets para el punto inicial/final.
        // Usa exactamente CableA.Offset y CableB.Offset, que son los offsets reales
        // con los que se creó el DirectShape recto en cada bandeja.
        // Esto hace que el cable llegue continuo al conector de la T/codo.
        // =========================================================
        private List<ParCableFitting> PrepararParesConContinuidadForzada(
            List<ParCableFitting> pares)
        {
            if (pares == null)
                return pares;

            foreach (ParCableFitting par in pares)
            {
                if (par == null)
                    continue;

                if (par.CableA != null && par.CableA.Offset != null)
                {
                    par.OffsetA = par.CableA.Offset;
                    par.TieneOffsetA = true;
                }
                else
                {
                    par.TieneOffsetA = false;
                    par.OffsetA = XYZ.Zero;
                }

                if (par.CableB != null && par.CableB.Offset != null)
                {
                    par.OffsetB = par.CableB.Offset;
                    par.TieneOffsetB = true;
                }
                else
                {
                    par.TieneOffsetB = false;
                    par.OffsetB = XYZ.Zero;
                }
            }

            return pares;
        }

        // =========================================================
        // V17 - ORDEN ASCENDENTE + CORRECCIÓN AUTOMÁTICA DE CRUCES
        //
        // 1) Primero conserva la regla global ascendente de circuitos:
        //    C01, C02, C03...
        // 2) Luego revisa si dentro de la T/codo los segmentos se cruzan.
        // 3) Si hay cruce, prueba inversiones de carriles por puerto y
        //    pequeños intercambios locales, conservando la menor alteración
        //    posible respecto a la continuidad original.
        //
        // No cambia Excel, no cambia CableKey, no cambia circuito.
        // Solo mueve el offset gráfico dentro del accesorio si eso reduce cruces.
        // =========================================================
        private List<ParCableFitting> PrepararParesConOrdenAscendenteYCorreccionCruces(
            List<ParCableFitting> pares)
        {
            pares = PrepararParesConContinuidadForzada(pares);

            if (pares == null || pares.Count <= 1)
                return pares;

            int crucesIniciales = ContarCrucesPares(pares);

            if (crucesIniciales <= 0)
                return pares;

            List<EstadoOffsetPar> estadoInicial = GuardarEstadoOffsetsTodosPares(pares);
            List<EstadoOffsetPar> mejorEstado = GuardarEstadoOffsetsTodosPares(pares);

            int mejorCruces = crucesIniciales;
            double mejorPenalizacion = CalcularPenalizacionContinuidad(pares);

            List<PuertoFitting> puertos = ObtenerPuertosUnicosDesdePares(pares);

            if (puertos.Count > 0 && puertos.Count <= 8)
            {
                int combinaciones = 1 << puertos.Count;

                for (int mask = 1; mask < combinaciones; mask++)
                {
                    RestaurarEstadoOffsetsPuerto(estadoInicial);

                    for (int i = 0; i < puertos.Count; i++)
                    {
                        if ((mask & (1 << i)) != 0)
                            InvertirOrdenOffsetsEnPuerto(pares, puertos[i]);
                    }

                    int cruces = ContarCrucesPares(pares);
                    double penalizacion = CalcularPenalizacionContinuidad(pares);

                    if (cruces < mejorCruces ||
                        (cruces == mejorCruces && penalizacion < mejorPenalizacion))
                    {
                        mejorCruces = cruces;
                        mejorPenalizacion = penalizacion;
                        mejorEstado = GuardarEstadoOffsetsTodosPares(pares);

                        if (mejorCruces == 0)
                            break;
                    }
                }
            }

            RestaurarEstadoOffsetsPuerto(mejorEstado);

            if (mejorCruces > 0)
            {
                MejorarCrucesPorIntercambiosLocales(pares, 20);

                int crucesLocales = ContarCrucesPares(pares);
                double penalizacionLocal = CalcularPenalizacionContinuidad(pares);

                if (crucesLocales < mejorCruces ||
                    (crucesLocales == mejorCruces && penalizacionLocal < mejorPenalizacion))
                {
                    mejorCruces = crucesLocales;
                    mejorPenalizacion = penalizacionLocal;
                    mejorEstado = GuardarEstadoOffsetsTodosPares(pares);
                }
                else
                {
                    RestaurarEstadoOffsetsPuerto(mejorEstado);
                }
            }

            int crucesFinales = ContarCrucesPares(pares);

            if (crucesFinales > crucesIniciales)
                RestaurarEstadoOffsetsPuerto(estadoInicial);

            return pares;
        }

        private List<EstadoOffsetPar> GuardarEstadoOffsetsTodosPares(
            List<ParCableFitting> pares)
        {
            List<EstadoOffsetPar> estado = new List<EstadoOffsetPar>();

            if (pares == null)
                return estado;

            foreach (ParCableFitting par in pares)
            {
                if (par == null)
                    continue;

                estado.Add(new EstadoOffsetPar
                {
                    Par = par,
                    EsA = true,
                    TieneOffset = par.TieneOffsetA,
                    Offset = par.OffsetA
                });

                estado.Add(new EstadoOffsetPar
                {
                    Par = par,
                    EsA = false,
                    TieneOffset = par.TieneOffsetB,
                    Offset = par.OffsetB
                });
            }

            return estado;
        }

        private void InvertirOrdenOffsetsEnPuerto(
            List<ParCableFitting> pares,
            PuertoFitting puerto)
        {
            if (pares == null || puerto == null)
                return;

            List<LadoParPuerto> lados = ObtenerLadosDePuerto(pares, puerto);

            if (lados.Count <= 1)
                return;

            XYZ lateral = ObtenerVectorLateralDePuerto(puerto, lados);

            if (EsVectorCero(lateral))
                return;

            lateral = lateral.Normalize();

            lados = lados
                .OrderBy(x => ObtenerOffsetDeLado(x).DotProduct(lateral))
                .ThenBy(x => ObtenerOrdenCircuito(x.Cable == null ? "" : x.Cable.Circuito))
                .ThenBy(x => ObtenerCableKeySeguro(x.Cable))
                .ToList();

            List<XYZ> offsets = lados
                .Select(x => ObtenerOffsetDeLado(x))
                .Reverse()
                .ToList();

            for (int i = 0; i < lados.Count; i++)
                SetOffsetDeLado(lados[i], offsets[i]);
        }

        private void MejorarCrucesPorIntercambiosLocales(
            List<ParCableFitting> pares,
            int maxIteraciones)
        {
            if (pares == null || pares.Count <= 1)
                return;

            List<PuertoFitting> puertos = ObtenerPuertosUnicosDesdePares(pares);

            if (puertos.Count == 0)
                return;

            int iteracion = 0;
            bool huboCambio = true;

            while (huboCambio && iteracion < maxIteraciones)
            {
                iteracion++;
                huboCambio = false;

                foreach (PuertoFitting puerto in puertos)
                {
                    List<LadoParPuerto> lados = ObtenerLadosDePuerto(pares, puerto);

                    if (lados.Count <= 1)
                        continue;

                    XYZ lateral = ObtenerVectorLateralDePuerto(puerto, lados);

                    if (EsVectorCero(lateral))
                        continue;

                    lateral = lateral.Normalize();

                    lados = lados
                        .OrderBy(x => ObtenerOffsetDeLado(x).DotProduct(lateral))
                        .ThenBy(x => ObtenerOrdenCircuito(x.Cable == null ? "" : x.Cable.Circuito))
                        .ThenBy(x => ObtenerCableKeySeguro(x.Cable))
                        .ToList();

                    bool mejoroEnPuerto = true;

                    while (mejoroEnPuerto)
                    {
                        mejoroEnPuerto = false;

                        int crucesBase = ContarCrucesPares(pares);
                        double penalizacionBase = CalcularPenalizacionContinuidad(pares);

                        for (int i = 0; i < lados.Count; i++)
                        {
                            for (int j = i + 1; j < lados.Count; j++)
                            {
                                XYZ offsetI = ObtenerOffsetDeLado(lados[i]);
                                XYZ offsetJ = ObtenerOffsetDeLado(lados[j]);

                                SetOffsetDeLado(lados[i], offsetJ);
                                SetOffsetDeLado(lados[j], offsetI);

                                int crucesNuevo = ContarCrucesPares(pares);
                                double penalizacionNueva = CalcularPenalizacionContinuidad(pares);

                                bool aceptar =
                                    crucesNuevo < crucesBase ||
                                    (crucesNuevo == crucesBase && penalizacionNueva < penalizacionBase);

                                if (aceptar)
                                {
                                    huboCambio = true;
                                    mejoroEnPuerto = true;
                                    crucesBase = crucesNuevo;
                                    penalizacionBase = penalizacionNueva;
                                }
                                else
                                {
                                    SetOffsetDeLado(lados[i], offsetI);
                                    SetOffsetDeLado(lados[j], offsetJ);
                                }
                            }
                        }
                    }
                }
            }
        }

        private XYZ ObtenerOffsetDeLado(LadoParPuerto lado)
        {
            if (lado == null || lado.Par == null)
                return XYZ.Zero;

            return ObtenerOffsetPar(lado.Par, lado.EsA);
        }

        private void SetOffsetDeLado(LadoParPuerto lado, XYZ offset)
        {
            if (lado == null || lado.Par == null || offset == null)
                return;

            if (lado.EsA)
            {
                lado.Par.OffsetA = offset;
                lado.Par.TieneOffsetA = true;
            }
            else
            {
                lado.Par.OffsetB = offset;
                lado.Par.TieneOffsetB = true;
            }
        }

        private double CalcularPenalizacionContinuidad(
            List<ParCableFitting> pares)
        {
            if (pares == null)
                return 0.0;

            double penalizacion = 0.0;

            foreach (ParCableFitting par in pares)
            {
                if (par == null)
                    continue;

                if (par.CableA != null && par.CableA.Offset != null)
                    penalizacion += ObtenerOffsetPar(par, true).DistanceTo(par.CableA.Offset);

                if (par.CableB != null && par.CableB.Offset != null)
                    penalizacion += ObtenerOffsetPar(par, false).DistanceTo(par.CableB.Offset);
            }

            return penalizacion;
        }


        private List<PuertoFitting> ObtenerPuertosUnicosDesdePares(List<ParCableFitting> pares)
        {
            List<PuertoFitting> puertos = new List<PuertoFitting>();
            HashSet<long> usados = new HashSet<long>();

            foreach (ParCableFitting par in pares)
            {
                if (par == null)
                    continue;

                if (par.A != null && par.A.BandejaId != null && !usados.Contains(par.A.BandejaId.Value))
                {
                    usados.Add(par.A.BandejaId.Value);
                    puertos.Add(par.A);
                }

                if (par.B != null && par.B.BandejaId != null && !usados.Contains(par.B.BandejaId.Value))
                {
                    usados.Add(par.B.BandejaId.Value);
                    puertos.Add(par.B);
                }
            }

            return puertos;
        }

        private void AsignarCarrilesEnPuerto(
            List<ParCableFitting> pares,
            PuertoFitting puerto,
            bool invertirCarriles)
        {
            if (pares == null || puerto == null)
                return;

            List<LadoParPuerto> lados = ObtenerLadosDePuerto(pares, puerto);

            if (lados.Count <= 1)
                return;

            XYZ lateral = ObtenerVectorLateralDePuerto(puerto, lados);

            if (EsVectorCero(lateral))
                return;

            lateral = lateral.Normalize();

            List<XYZ> carriles = ObtenerCarrilesDisponiblesPuerto(puerto, lateral);

            if (carriles.Count == 0)
                return;

            if (invertirCarriles)
                carriles.Reverse();

            lados = lados
                .OrderBy(x => ScoreDestinoEnPuerto(x, lateral))
                .ThenBy(x => ObtenerCableKeySeguro(x.Cable))
                .ToList();

            int n = Math.Min(lados.Count, carriles.Count);

            for (int i = 0; i < n; i++)
            {
                LadoParPuerto lado = lados[i];
                XYZ offset = carriles[i];

                if (lado.EsA)
                {
                    lado.Par.OffsetA = offset;
                    lado.Par.TieneOffsetA = true;
                }
                else
                {
                    lado.Par.OffsetB = offset;
                    lado.Par.TieneOffsetB = true;
                }
            }
        }

        private List<LadoParPuerto> ObtenerLadosDePuerto(
            List<ParCableFitting> pares,
            PuertoFitting puerto)
        {
            List<LadoParPuerto> lados = new List<LadoParPuerto>();

            foreach (ParCableFitting par in pares)
            {
                if (par == null || puerto == null)
                    continue;

                if (MismoPuerto(par.A, puerto))
                {
                    lados.Add(new LadoParPuerto
                    {
                        Par = par,
                        EsA = true,
                        Puerto = par.A,
                        OtroPuerto = par.B,
                        Cable = par.CableA
                    });
                }

                if (MismoPuerto(par.B, puerto))
                {
                    lados.Add(new LadoParPuerto
                    {
                        Par = par,
                        EsA = false,
                        Puerto = par.B,
                        OtroPuerto = par.A,
                        Cable = par.CableB
                    });
                }
            }

            return lados;
        }

        private bool MismoPuerto(PuertoFitting a, PuertoFitting b)
        {
            if (a == null || b == null || a.BandejaId == null || b.BandejaId == null)
                return false;

            return a.BandejaId.Value == b.BandejaId.Value;
        }

        private XYZ ObtenerVectorLateralDePuerto(
            PuertoFitting puerto,
            List<LadoParPuerto> lados)
        {
            if (lados != null)
            {
                foreach (LadoParPuerto lado in lados)
                {
                    if (lado != null && lado.Cable != null && !EsVectorCero(lado.Cable.VectorLateral))
                        return lado.Cable.VectorLateral.Normalize();
                }
            }

            if (puerto != null && puerto.Cables != null)
            {
                foreach (CableInstancia c in puerto.Cables)
                {
                    if (c != null && !EsVectorCero(c.VectorLateral))
                        return c.VectorLateral.Normalize();
                }
            }

            if (puerto != null && !EsVectorCero(puerto.DireccionHaciaInterior))
            {
                XYZ lateral;
                XYZ vertical;
                CalcularBaseLocal(puerto.DireccionHaciaInterior, out lateral, out vertical);
                return lateral;
            }

            return XYZ.Zero;
        }

        private List<XYZ> ObtenerCarrilesDisponiblesPuerto(
            PuertoFitting puerto,
            XYZ lateral)
        {
            List<XYZ> carriles = new List<XYZ>();

            if (puerto == null || puerto.Cables == null || lateral == null)
                return carriles;

            foreach (CableInstancia c in puerto.Cables)
            {
                if (c == null || c.Offset == null)
                    continue;

                carriles.Add(c.Offset);
            }

            carriles = carriles
                .OrderBy(x => x.DotProduct(lateral))
                .ToList();

            return carriles;
        }

        private double ScoreDestinoEnPuerto(LadoParPuerto lado, XYZ lateral)
        {
            if (lado == null || lado.Puerto == null || lado.OtroPuerto == null || lateral == null)
                return 0.0;

            XYZ v = lado.OtroPuerto.Punto - lado.Puerto.Punto;

            if (EsVectorCero(v))
                return 0.0;

            return v.DotProduct(lateral);
        }

        private string ObtenerCableKeySeguro(CableInstancia cable)
        {
            if (cable == null || string.IsNullOrWhiteSpace(cable.Key))
                return "";

            return cable.Key;
        }

        private XYZ ObtenerOffsetPar(ParCableFitting par, bool ladoA)
        {
            if (par == null)
                return XYZ.Zero;

            if (ladoA)
            {
                if (par.TieneOffsetA && par.OffsetA != null)
                    return par.OffsetA;

                if (par.CableA != null && par.CableA.Offset != null)
                    return par.CableA.Offset;
            }
            else
            {
                if (par.TieneOffsetB && par.OffsetB != null)
                    return par.OffsetB;

                if (par.CableB != null && par.CableB.Offset != null)
                    return par.CableB.Offset;
            }

            return XYZ.Zero;
        }

        private List<EstadoOffsetPar> GuardarEstadoOffsetsPuerto(
            List<ParCableFitting> pares,
            PuertoFitting puerto)
        {
            List<EstadoOffsetPar> estado = new List<EstadoOffsetPar>();
            List<LadoParPuerto> lados = ObtenerLadosDePuerto(pares, puerto);

            foreach (LadoParPuerto lado in lados)
            {
                if (lado == null || lado.Par == null)
                    continue;

                estado.Add(new EstadoOffsetPar
                {
                    Par = lado.Par,
                    EsA = lado.EsA,
                    TieneOffset = lado.EsA ? lado.Par.TieneOffsetA : lado.Par.TieneOffsetB,
                    Offset = lado.EsA ? lado.Par.OffsetA : lado.Par.OffsetB
                });
            }

            return estado;
        }

        private void RestaurarEstadoOffsetsPuerto(List<EstadoOffsetPar> estado)
        {
            if (estado == null)
                return;

            foreach (EstadoOffsetPar item in estado)
            {
                if (item == null || item.Par == null)
                    continue;

                if (item.EsA)
                {
                    item.Par.TieneOffsetA = item.TieneOffset;
                    item.Par.OffsetA = item.Offset;
                }
                else
                {
                    item.Par.TieneOffsetB = item.TieneOffset;
                    item.Par.OffsetB = item.Offset;
                }
            }
        }


        // =========================================================
        // V18 - CONTINUIDAD + SIN CRUCES
        //
        // La versión V17 corregía cruces cambiando offsets solo dentro de la T/codo.
        // Eso evitaba cruces, pero rompía la continuidad con los tramos rectos.
        //
        // Esta versión corrige el problema desde el origen:
        // - mantiene el orden ascendente como punto de partida;
        // - calcula los cruces en accesorios seleccionados;
        // - si hay cruces, intercambia carriles en la BANDEJA COMPLETA;
        // - por eso el tramo recto y el accesorio usan el mismo Offset;
        // - resultado: continuidad visual + reducción de cruces.
        // =========================================================
        private void OptimizarCarrilesGlobalesSinCruceManteniendoContinuidad(
            Document doc,
            Dictionary<ElementId, List<CableInstancia>> cablesPorBandeja,
            HashSet<ElementId> accesorioIds,
            HashSet<ElementId> bandejaIds)
        {
            if (doc == null || cablesPorBandeja == null || cablesPorBandeja.Count == 0)
                return;

            if (accesorioIds == null || accesorioIds.Count == 0)
                return;

            int mejorCruces = ContarCrucesGlobalesEnAccesorios(
                doc,
                cablesPorBandeja,
                accesorioIds,
                bandejaIds);

            double mejorPenalizacion = CalcularPenalizacionOrdenAscendente(cablesPorBandeja);

            if (mejorCruces <= 0)
                return;

            // 1) Primer intento: invertir carriles completos por bandeja.
            foreach (KeyValuePair<ElementId, List<CableInstancia>> kvp in cablesPorBandeja)
            {
                List<CableInstancia> cables = kvp.Value;

                if (cables == null || cables.Count <= 1)
                    continue;

                List<EstadoOffsetCable> estado = GuardarOffsetsCables(cables);

                InvertirOffsetsEnBandeja(cables);

                int cruces = ContarCrucesGlobalesEnAccesorios(
                    doc,
                    cablesPorBandeja,
                    accesorioIds,
                    bandejaIds);

                double penalizacion = CalcularPenalizacionOrdenAscendente(cablesPorBandeja);

                if (cruces < mejorCruces ||
                    (cruces == mejorCruces && penalizacion < mejorPenalizacion))
                {
                    mejorCruces = cruces;
                    mejorPenalizacion = penalizacion;

                    if (mejorCruces <= 0)
                        return;
                }
                else
                {
                    RestaurarOffsetsCables(estado);
                }
            }

            // 2) Segundo intento: swaps locales de carriles en cada bandeja.
            // Esto mueve el carril del cable en toda la bandeja, no solo en el accesorio.
            bool huboCambio = true;
            int iteracion = 0;
            int maxIteraciones = 25;

            while (huboCambio && iteracion < maxIteraciones && mejorCruces > 0)
            {
                iteracion++;
                huboCambio = false;

                foreach (KeyValuePair<ElementId, List<CableInstancia>> kvp in cablesPorBandeja)
                {
                    List<CableInstancia> cables = ObtenerCablesOrdenadosPorCarril(kvp.Value);

                    if (cables == null || cables.Count <= 1)
                        continue;

                    // Seguridad para que no se vuelva pesado con demasiados cables.
                    int limite = Math.Min(cables.Count, 60);

                    for (int i = 0; i < limite; i++)
                    {
                        for (int j = i + 1; j < limite; j++)
                        {
                            CableInstancia a = cables[i];
                            CableInstancia b = cables[j];

                            if (a == null || b == null)
                                continue;

                            XYZ offsetA = a.Offset;
                            XYZ offsetB = b.Offset;

                            a.Offset = offsetB;
                            b.Offset = offsetA;

                            int cruces = ContarCrucesGlobalesEnAccesorios(
                                doc,
                                cablesPorBandeja,
                                accesorioIds,
                                bandejaIds);

                            double penalizacion = CalcularPenalizacionOrdenAscendente(cablesPorBandeja);

                            bool aceptar =
                                cruces < mejorCruces ||
                                (cruces == mejorCruces && penalizacion < mejorPenalizacion);

                            if (aceptar)
                            {
                                mejorCruces = cruces;
                                mejorPenalizacion = penalizacion;
                                huboCambio = true;

                                if (mejorCruces <= 0)
                                    return;
                            }
                            else
                            {
                                a.Offset = offsetA;
                                b.Offset = offsetB;
                            }
                        }
                    }
                }
            }
        }

        private int ContarCrucesGlobalesEnAccesorios(
            Document doc,
            Dictionary<ElementId, List<CableInstancia>> cablesPorBandeja,
            HashSet<ElementId> accesorioIds,
            HashSet<ElementId> bandejaIds)
        {
            if (doc == null || accesorioIds == null || cablesPorBandeja == null)
                return 0;

            int total = 0;

            foreach (ElementId idAcc in accesorioIds)
            {
                Element accesorio = doc.GetElement(idAcc);

                if (accesorio == null)
                    continue;

                List<PuertoFitting> puertos = ObtenerPuertosDeAccesorio(
                    doc,
                    accesorio,
                    cablesPorBandeja,
                    bandejaIds);

                if (puertos == null || puertos.Count < 2)
                    continue;

                int ambiguos;
                List<ParCableFitting> pares = InferirParesPorIdentidad(
                    puertos,
                    out ambiguos);

                pares = PrepararParesConContinuidadForzada(pares);

                total += ContarCrucesPares(pares);
            }

            return total;
        }

        private List<EstadoOffsetCable> GuardarOffsetsCables(List<CableInstancia> cables)
        {
            List<EstadoOffsetCable> estado = new List<EstadoOffsetCable>();

            if (cables == null)
                return estado;

            foreach (CableInstancia c in cables)
            {
                if (c == null)
                    continue;

                estado.Add(new EstadoOffsetCable
                {
                    Cable = c,
                    Offset = c.Offset
                });
            }

            return estado;
        }

        private void RestaurarOffsetsCables(List<EstadoOffsetCable> estado)
        {
            if (estado == null)
                return;

            foreach (EstadoOffsetCable e in estado)
            {
                if (e == null || e.Cable == null)
                    continue;

                e.Cable.Offset = e.Offset;
            }
        }

        private void InvertirOffsetsEnBandeja(List<CableInstancia> cables)
        {
            List<CableInstancia> ordenados = ObtenerCablesOrdenadosPorCarril(cables);

            if (ordenados == null || ordenados.Count <= 1)
                return;

            List<XYZ> offsets = ordenados
                .Select(x => x.Offset)
                .Reverse()
                .ToList();

            for (int i = 0; i < ordenados.Count; i++)
                ordenados[i].Offset = offsets[i];
        }

        private List<CableInstancia> ObtenerCablesOrdenadosPorCarril(List<CableInstancia> cables)
        {
            if (cables == null)
                return new List<CableInstancia>();

            XYZ lateral = XYZ.Zero;

            foreach (CableInstancia c in cables)
            {
                if (c != null && !EsVectorCero(c.VectorLateral))
                {
                    lateral = c.VectorLateral.Normalize();
                    break;
                }
            }

            if (EsVectorCero(lateral))
                lateral = XYZ.BasisX;

            return cables
                .Where(x => x != null)
                .OrderBy(x => x.Offset.DotProduct(lateral))
                .ThenBy(x => ObtenerOrdenCircuito(x.Circuito))
                .ThenBy(x => ObtenerCableKeySeguro(x))
                .ToList();
        }


        // =========================================================
        // V21 - CODO/T SIN CRUCES SEGÚN RECORRIDO SEGMENTADO REAL
        //
        // Problema detectado:
        // En algunos codos, por la posición/orientación de la familia, la prueba
        // de cruce con línea recta no detectaba que los cables se cruzaban dentro
        // de la curva segmentada. Por eso un codo salía bien y otro no.
        //
        // Criterio:
        // - No se corrige solo dentro del accesorio porque rompe continuidad.
        // - Se intercambian carriles en la bandeja completa del puerto destino.
        // - Se prueba normal/invertido y ambos sentidos fuente/destino.
        // - Se acepta solo si reduce los cruces del recorrido segmentado real.
        // =========================================================
        private void ForzarSinCrucesPorRecorridoSegmentadoEnAccesorios(
            Document doc,
            Dictionary<ElementId, List<CableInstancia>> cablesPorBandeja,
            HashSet<ElementId> accesorioIds,
            HashSet<ElementId> bandejaIds)
        {
            if (doc == null || cablesPorBandeja == null || cablesPorBandeja.Count == 0)
                return;

            if (accesorioIds == null || accesorioIds.Count == 0)
                return;

            int mejorCruces = ContarCrucesGlobalesEnAccesoriosPorRecorridoSegmentado(
                doc,
                cablesPorBandeja,
                accesorioIds,
                bandejaIds);

            double mejorPenalizacion = CalcularPenalizacionOrdenAscendente(cablesPorBandeja);

            if (mejorCruces <= 0)
                return;

            bool huboCambio = true;
            int iteracion = 0;
            int maxIteraciones = 12;

            while (huboCambio && iteracion < maxIteraciones && mejorCruces > 0)
            {
                iteracion++;
                huboCambio = false;

                foreach (ElementId idAcc in accesorioIds)
                {
                    Element accesorio = doc.GetElement(idAcc);

                    if (accesorio == null)
                        continue;

                    List<PuertoFitting> puertos = ObtenerPuertosDeAccesorio(
                        doc,
                        accesorio,
                        cablesPorBandeja,
                        bandejaIds);

                    if (puertos == null || puertos.Count < 2)
                        continue;

                    int ambiguos;
                    List<ParCableFitting> pares = InferirParesPorIdentidad(
                        puertos,
                        out ambiguos);

                    pares = PrepararParesConContinuidadForzada(pares);

                    if (pares == null || pares.Count <= 1)
                        continue;

                    List<List<ParCableFitting>> grupos = AgruparParesPorParDePuertos(pares);

                    foreach (List<ParCableFitting> grupo in grupos)
                    {
                        if (grupo == null || grupo.Count <= 1)
                            continue;

                        PuertoFitting puertoA = grupo[0].A;
                        PuertoFitting puertoB = grupo[0].B;

                        if (puertoA == null || puertoB == null)
                            continue;

                        List<EstadoOffsetCable> estadoBase = GuardarOffsetsTodosLosCables(cablesPorBandeja);
                        int baseCruces = ContarCrucesGlobalesEnAccesoriosPorRecorridoSegmentado(
                            doc,
                            cablesPorBandeja,
                            accesorioIds,
                            bandejaIds);
                        double basePenalizacion = CalcularPenalizacionOrdenAscendente(cablesPorBandeja);

                        List<EstadoOffsetCable> mejorEstadoLocal = GuardarOffsetsTodosLosCables(cablesPorBandeja);
                        int mejorCrucesLocal = baseCruces;
                        double mejorPenalizacionLocal = basePenalizacion;

                        // Prueba 1: A manda el orden, B se reacomoda.
                        for (int inv = 0; inv <= 1; inv++)
                        {
                            RestaurarOffsetsTodosLosCables(estadoBase);
                            AplicarOrdenDeUnPuertoEnOtroPorCableKey(
                                grupo,
                                puertoA,
                                puertoB,
                                inv == 1);

                            int cruces = ContarCrucesGlobalesEnAccesoriosPorRecorridoSegmentado(
                                doc,
                                cablesPorBandeja,
                                accesorioIds,
                                bandejaIds);
                            double penalizacion = CalcularPenalizacionOrdenAscendente(cablesPorBandeja);

                            if (cruces < mejorCrucesLocal ||
                                (cruces == mejorCrucesLocal && penalizacion < mejorPenalizacionLocal))
                            {
                                mejorCrucesLocal = cruces;
                                mejorPenalizacionLocal = penalizacion;
                                mejorEstadoLocal = GuardarOffsetsTodosLosCables(cablesPorBandeja);
                            }
                        }

                        // Prueba 2: B manda el orden, A se reacomoda.
                        for (int inv = 0; inv <= 1; inv++)
                        {
                            RestaurarOffsetsTodosLosCables(estadoBase);
                            AplicarOrdenDeUnPuertoEnOtroPorCableKey(
                                grupo,
                                puertoB,
                                puertoA,
                                inv == 1);

                            int cruces = ContarCrucesGlobalesEnAccesoriosPorRecorridoSegmentado(
                                doc,
                                cablesPorBandeja,
                                accesorioIds,
                                bandejaIds);
                            double penalizacion = CalcularPenalizacionOrdenAscendente(cablesPorBandeja);

                            if (cruces < mejorCrucesLocal ||
                                (cruces == mejorCrucesLocal && penalizacion < mejorPenalizacionLocal))
                            {
                                mejorCrucesLocal = cruces;
                                mejorPenalizacionLocal = penalizacion;
                                mejorEstadoLocal = GuardarOffsetsTodosLosCables(cablesPorBandeja);
                            }
                        }

                        if (mejorCrucesLocal < baseCruces ||
                            (mejorCrucesLocal == baseCruces && mejorPenalizacionLocal < basePenalizacion))
                        {
                            RestaurarOffsetsTodosLosCables(mejorEstadoLocal);
                            huboCambio = true;
                            mejorCruces = mejorCrucesLocal;
                            mejorPenalizacion = mejorPenalizacionLocal;

                            if (mejorCruces <= 0)
                                return;
                        }
                        else
                        {
                            RestaurarOffsetsTodosLosCables(estadoBase);
                        }
                    }
                }
            }
        }

        private List<List<ParCableFitting>> AgruparParesPorParDePuertos(
            List<ParCableFitting> pares)
        {
            Dictionary<string, List<ParCableFitting>> grupos =
                new Dictionary<string, List<ParCableFitting>>(StringComparer.OrdinalIgnoreCase);

            if (pares == null)
                return new List<List<ParCableFitting>>();

            foreach (ParCableFitting par in pares)
            {
                if (par == null || par.A == null || par.B == null ||
                    par.A.BandejaId == null || par.B.BandejaId == null)
                    continue;

                long a = par.A.BandejaId.Value;
                long b = par.B.BandejaId.Value;
                string key = a < b ? a + "|" + b : b + "|" + a;

                if (!grupos.ContainsKey(key))
                    grupos[key] = new List<ParCableFitting>();

                grupos[key].Add(par);
            }

            return grupos.Values.ToList();
        }

        private void AplicarOrdenDeUnPuertoEnOtroPorCableKey(
            List<ParCableFitting> grupo,
            PuertoFitting puertoFuente,
            PuertoFitting puertoDestino,
            bool invertirCarrilesDestino)
        {
            if (grupo == null || grupo.Count <= 1 || puertoFuente == null || puertoDestino == null)
                return;

            List<LadoParPuerto> ladosFuente = new List<LadoParPuerto>();
            List<LadoParPuerto> ladosDestino = new List<LadoParPuerto>();

            foreach (ParCableFitting par in grupo)
            {
                LadoParPuerto lf = ObtenerLadoDeParEnPuerto(par, puertoFuente);
                LadoParPuerto ld = ObtenerLadoDeParEnPuerto(par, puertoDestino);

                if (lf != null && ld != null && lf.Cable != null && ld.Cable != null)
                {
                    ladosFuente.Add(lf);
                    ladosDestino.Add(ld);
                }
            }

            if (ladosFuente.Count <= 1 || ladosDestino.Count <= 1)
                return;

            XYZ lateralFuente = ObtenerVectorLateralDePuerto(puertoFuente, ladosFuente);
            XYZ lateralDestino = ObtenerVectorLateralDePuerto(puertoDestino, ladosDestino);

            if (EsVectorCero(lateralFuente) || EsVectorCero(lateralDestino))
                return;

            lateralFuente = lateralFuente.Normalize();
            lateralDestino = lateralDestino.Normalize();

            List<LadoParPuerto> ordenFuente = ladosFuente
                .OrderBy(x => ObtenerOffsetDeLado(x).DotProduct(lateralFuente))
                .ThenBy(x => ObtenerOrdenCircuito(x.Cable == null ? "" : x.Cable.Circuito))
                .ThenBy(x => ObtenerCableKeySeguro(x.Cable))
                .ToList();

            List<XYZ> carrilesDestino = ladosDestino
                .Select(x => ObtenerOffsetDeLado(x))
                .OrderBy(x => x.DotProduct(lateralDestino))
                .ToList();

            if (invertirCarrilesDestino)
                carrilesDestino.Reverse();

            Dictionary<string, LadoParPuerto> ladoDestinoPorKey =
                new Dictionary<string, LadoParPuerto>(StringComparer.OrdinalIgnoreCase);

            foreach (LadoParPuerto lado in ladosDestino)
            {
                string key = ObtenerCableKeySeguro(lado.Cable);

                if (string.IsNullOrWhiteSpace(key))
                    continue;

                if (!ladoDestinoPorKey.ContainsKey(key))
                    ladoDestinoPorKey[key] = lado;
            }

            int n = Math.Min(ordenFuente.Count, carrilesDestino.Count);

            for (int i = 0; i < n; i++)
            {
                string key = ObtenerCableKeySeguro(ordenFuente[i].Cable);

                if (string.IsNullOrWhiteSpace(key))
                    continue;

                LadoParPuerto destino;

                if (!ladoDestinoPorKey.TryGetValue(key, out destino))
                    continue;

                XYZ nuevoOffset = carrilesDestino[i];
                SetOffsetDeLado(destino, nuevoOffset);

                // Clave: mover también el offset real del CableInstancia.
                // Así el tramo recto completo y el accesorio siguen continuos.
                if (destino.Cable != null)
                    destino.Cable.Offset = nuevoOffset;
            }
        }

        private LadoParPuerto ObtenerLadoDeParEnPuerto(
            ParCableFitting par,
            PuertoFitting puerto)
        {
            if (par == null || puerto == null)
                return null;

            if (MismoPuerto(par.A, puerto))
            {
                return new LadoParPuerto
                {
                    Par = par,
                    EsA = true,
                    Puerto = par.A,
                    OtroPuerto = par.B,
                    Cable = par.CableA
                };
            }

            if (MismoPuerto(par.B, puerto))
            {
                return new LadoParPuerto
                {
                    Par = par,
                    EsA = false,
                    Puerto = par.B,
                    OtroPuerto = par.A,
                    Cable = par.CableB
                };
            }

            return null;
        }

        // =========================================================
        // V27 - PASADA FINAL SOLO DE ORDEN / SIN TOCAR GEOMETRÍA
        //
        // Base: V24 estable.
        // Objetivo: corregir únicamente cruces generados por orden de carriles.
        //
        // Criterio:
        // - No cambia Excel.
        // - No cambia tipos, colores ni parámetros.
        // - No cambia la geometría de curvas/codos.
        // - No cambia la forma de crear DirectShapes.
        // - Solo intercambia Offset entre cables dentro de una misma bandeja.
        //   Como el Offset pertenece al CableInstancia, se mantiene continuidad
        //   entre el tramo recto y el accesorio.
        // - Acepta cambios SOLO si disminuye el número de cruces detectado
        //   en el recorrido segmentado real del accesorio.
        // =========================================================
        private void ForzarOrdenFinalSoloSiReduceCruces(
            Document doc,
            Dictionary<ElementId, List<CableInstancia>> cablesPorBandeja,
            HashSet<ElementId> accesorioIds,
            HashSet<ElementId> bandejaIds)
        {
            if (doc == null || cablesPorBandeja == null || cablesPorBandeja.Count == 0)
                return;

            if (accesorioIds == null || accesorioIds.Count == 0)
                return;

            int mejorCruces = ContarCrucesGlobalesEnAccesoriosPorRecorridoSegmentado(
                doc,
                cablesPorBandeja,
                accesorioIds,
                bandejaIds);

            if (mejorCruces <= 0)
                return;

            bool huboCambio = true;
            int iteracion = 0;
            int maxIteraciones = 40;

            // OPT V35:
            // Las bandejas del diccionario no cambian durante esta rutina.
            // Antes se recreaba esta lista en cada iteración externa.
            List<ElementId> idsBandejas = cablesPorBandeja.Keys
                .OrderBy(x => x.Value)
                .ToList();

            while (huboCambio && iteracion < maxIteraciones && mejorCruces > 0)
            {
                iteracion++;
                huboCambio = false;

                foreach (ElementId idBandeja in idsBandejas)
                {
                    if (!cablesPorBandeja.ContainsKey(idBandeja))
                        continue;

                    List<CableInstancia> cablesBandeja = cablesPorBandeja[idBandeja];

                    if (cablesBandeja == null || cablesBandeja.Count <= 1)
                        continue;

                    // Primero prueba inversión completa del orden de carriles de la bandeja.
                    List<EstadoOffsetCable> estadoInversion = GuardarOffsetsCables(cablesBandeja);

                    InvertirOffsetsEnBandeja(cablesBandeja);

                    int crucesInvertido = ContarCrucesGlobalesEnAccesoriosPorRecorridoSegmentado(
                        doc,
                        cablesPorBandeja,
                        accesorioIds,
                        bandejaIds);

                    if (crucesInvertido < mejorCruces)
                    {
                        mejorCruces = crucesInvertido;
                        huboCambio = true;

                        if (mejorCruces <= 0)
                            return;
                    }
                    else
                    {
                        RestaurarOffsetsCables(estadoInversion);
                    }

                    // Luego prueba swaps de carril. Se evalúa por recorrido real segmentado.
                    List<CableInstancia> cablesOrdenados = ObtenerCablesOrdenadosPorCarril(cablesBandeja);

                    if (cablesOrdenados == null || cablesOrdenados.Count <= 1)
                        continue;

                    int limite = Math.Min(cablesOrdenados.Count, 120);

                    bool cambioEnBandeja = true;
                    int iteracionBandeja = 0;

                    while (cambioEnBandeja && iteracionBandeja < 8 && mejorCruces > 0)
                    {
                        iteracionBandeja++;
                        cambioEnBandeja = false;

                        cablesOrdenados = ObtenerCablesOrdenadosPorCarril(cablesBandeja);

                        limite = Math.Min(cablesOrdenados.Count, 120);

                        for (int i = 0; i < limite; i++)
                        {
                            for (int j = i + 1; j < limite; j++)
                            {
                                CableInstancia a = cablesOrdenados[i];
                                CableInstancia b = cablesOrdenados[j];

                                if (a == null || b == null)
                                    continue;

                                XYZ offsetA = a.Offset;
                                XYZ offsetB = b.Offset;

                                a.Offset = offsetB;
                                b.Offset = offsetA;

                                int crucesNuevo = ContarCrucesGlobalesEnAccesoriosPorRecorridoSegmentado(
                                    doc,
                                    cablesPorBandeja,
                                    accesorioIds,
                                    bandejaIds);

                                if (crucesNuevo < mejorCruces)
                                {
                                    mejorCruces = crucesNuevo;
                                    huboCambio = true;
                                    cambioEnBandeja = true;

                                    if (mejorCruces <= 0)
                                        return;
                                }
                                else
                                {
                                    a.Offset = offsetA;
                                    b.Offset = offsetB;
                                }
                            }
                        }
                    }
                }
            }
        }


        private int ContarCrucesGlobalesEnAccesoriosPorRecorridoSegmentado(
            Document doc,
            Dictionary<ElementId, List<CableInstancia>> cablesPorBandeja,
            HashSet<ElementId> accesorioIds,
            HashSet<ElementId> bandejaIds)
        {
            if (doc == null || accesorioIds == null || cablesPorBandeja == null)
                return 0;

            int total = 0;

            foreach (ElementId idAcc in accesorioIds)
            {
                Element accesorio = doc.GetElement(idAcc);

                if (accesorio == null)
                    continue;

                List<PuertoFitting> puertos = ObtenerPuertosDeAccesorio(
                    doc,
                    accesorio,
                    cablesPorBandeja,
                    bandejaIds);

                if (puertos == null || puertos.Count < 2)
                    continue;

                int ambiguos;
                List<ParCableFitting> pares = InferirParesPorIdentidad(
                    puertos,
                    out ambiguos);

                pares = PrepararParesConContinuidadForzada(pares);

                total += ContarCrucesParesPorRecorridoSegmentado(pares);
            }

            return total;
        }

        private int ContarCrucesParesPorRecorridoSegmentado(List<ParCableFitting> pares)
        {
            if (pares == null || pares.Count <= 1)
                return 0;

            int cruces = 0;
            List<List<XYZ>> rutas = new List<List<XYZ>>();

            foreach (ParCableFitting par in pares)
            {
                if (par == null || par.A == null || par.B == null)
                {
                    rutas.Add(new List<XYZ>());
                    continue;
                }

                XYZ pInicio = par.A.Punto + ObtenerOffsetPar(par, true);
                XYZ pFin = par.B.Punto + ObtenerOffsetPar(par, false);

                List<XYZ> ruta = CrearPuntosRecorridoAccesorioV10(
                    pInicio,
                    par.A.DireccionHaciaInterior,
                    pFin,
                    par.B.DireccionHaciaInterior);

                rutas.Add(ruta);
            }

            for (int i = 0; i < rutas.Count; i++)
            {
                for (int j = i + 1; j < rutas.Count; j++)
                {
                    if (RutasCruzadasXY(rutas[i], rutas[j]))
                        cruces++;
                }
            }

            return cruces;
        }

        private bool RutasCruzadasXY(List<XYZ> a, List<XYZ> b)
        {
            // V22:
            // Antes se revisaban cruces solo en planta XY.
            // Eso fallaba en codos de subida/bajada porque el accesorio trabaja
            // en un plano vertical o inclinado. Ahora se elige automáticamente
            // el mejor plano de análisis para cada par de rutas: XY, XZ o YZ.
            return RutasCruzadasEnMejorPlano(a, b);
        }

        private bool RutasCruzadasEnMejorPlano(List<XYZ> a, List<XYZ> b)
        {
            if (a == null || b == null || a.Count < 2 || b.Count < 2)
                return false;

            PlanoCruce plano = ObtenerMejorPlanoCruce(a, b);

            double toleranciaExtremo = MmToFeet(2.0);

            for (int i = 0; i < a.Count - 1; i++)
            {
                XYZ a1 = a[i];
                XYZ a2 = a[i + 1];

                if (a1 == null || a2 == null)
                    continue;

                if (a1.DistanceTo(a2) < MmToFeet(0.5))
                    continue;

                for (int j = 0; j < b.Count - 1; j++)
                {
                    XYZ b1 = b[j];
                    XYZ b2 = b[j + 1];

                    if (b1 == null || b2 == null)
                        continue;

                    if (b1.DistanceTo(b2) < MmToFeet(0.5))
                        continue;

                    if (a1.DistanceTo(b1) <= toleranciaExtremo ||
                        a1.DistanceTo(b2) <= toleranciaExtremo ||
                        a2.DistanceTo(b1) <= toleranciaExtremo ||
                        a2.DistanceTo(b2) <= toleranciaExtremo)
                    {
                        continue;
                    }

                    Punto2D aa1 = ProyectarAPlano(a1, plano);
                    Punto2D aa2 = ProyectarAPlano(a2, plano);
                    Punto2D bb1 = ProyectarAPlano(b1, plano);
                    Punto2D bb2 = ProyectarAPlano(b2, plano);

                    if (SegmentosCruzados2D(aa1, aa2, bb1, bb2))
                        return true;
                }
            }

            return false;
        }

        private PlanoCruce ObtenerMejorPlanoCruce(List<XYZ> a, List<XYZ> b)
        {
            // El plano se elige por la extensión dominante de las dos rutas.
            // Si el recorrido es vertical, normalmente XZ o YZ gana sobre XY.
            List<XYZ> puntos = new List<XYZ>();

            if (a != null)
                puntos.AddRange(a.Where(x => x != null));

            if (b != null)
                puntos.AddRange(b.Where(x => x != null));

            if (puntos.Count < 2)
                return PlanoCruce.XY;

            double minX = puntos.Min(p => p.X);
            double maxX = puntos.Max(p => p.X);
            double minY = puntos.Min(p => p.Y);
            double maxY = puntos.Max(p => p.Y);
            double minZ = puntos.Min(p => p.Z);
            double maxZ = puntos.Max(p => p.Z);

            double dx = Math.Abs(maxX - minX);
            double dy = Math.Abs(maxY - minY);
            double dz = Math.Abs(maxZ - minZ);

            double areaXY = dx * dy;
            double areaXZ = dx * dz;
            double areaYZ = dy * dz;

            if (areaXZ >= areaXY && areaXZ >= areaYZ)
                return PlanoCruce.XZ;

            if (areaYZ >= areaXY && areaYZ >= areaXZ)
                return PlanoCruce.YZ;

            return PlanoCruce.XY;
        }

        private Punto2D ProyectarAPlano(XYZ p, PlanoCruce plano)
        {
            if (p == null)
                return new Punto2D(0.0, 0.0);

            if (plano == PlanoCruce.XZ)
                return new Punto2D(p.X, p.Z);

            if (plano == PlanoCruce.YZ)
                return new Punto2D(p.Y, p.Z);

            return new Punto2D(p.X, p.Y);
        }

        private bool SegmentosCruzados2D(Punto2D a, Punto2D b, Punto2D c, Punto2D d)
        {
            double o1 = Orientacion2D(a, b, c);
            double o2 = Orientacion2D(a, b, d);
            double o3 = Orientacion2D(c, d, a);
            double o4 = Orientacion2D(c, d, b);

            return (o1 * o2 < 0.0) && (o3 * o4 < 0.0);
        }

        private double Orientacion2D(Punto2D a, Punto2D b, Punto2D c)
        {
            return (b.U - a.U) * (c.V - a.V) - (b.V - a.V) * (c.U - a.U);
        }

        private enum PlanoCruce
        {
            XY,
            XZ,
            YZ
        }

        private struct Punto2D
        {
            public double U;
            public double V;

            public Punto2D(double u, double v)
            {
                U = u;
                V = v;
            }
        }

        private List<EstadoOffsetCable> GuardarOffsetsTodosLosCables(
            Dictionary<ElementId, List<CableInstancia>> cablesPorBandeja)
        {
            List<EstadoOffsetCable> estado = new List<EstadoOffsetCable>();

            if (cablesPorBandeja == null)
                return estado;

            foreach (KeyValuePair<ElementId, List<CableInstancia>> kvp in cablesPorBandeja)
            {
                if (kvp.Value == null)
                    continue;

                foreach (CableInstancia cable in kvp.Value)
                {
                    if (cable == null)
                        continue;

                    estado.Add(new EstadoOffsetCable
                    {
                        Cable = cable,
                        Offset = cable.Offset
                    });
                }
            }

            return estado;
        }

        private void RestaurarOffsetsTodosLosCables(List<EstadoOffsetCable> estado)
        {
            if (estado == null)
                return;

            foreach (EstadoOffsetCable item in estado)
            {
                if (item == null || item.Cable == null)
                    continue;

                item.Cable.Offset = item.Offset;
            }
        }

        private double CalcularPenalizacionOrdenAscendente(
            Dictionary<ElementId, List<CableInstancia>> cablesPorBandeja)
        {
            if (cablesPorBandeja == null)
                return 0.0;

            double penalizacion = 0.0;

            foreach (KeyValuePair<ElementId, List<CableInstancia>> kvp in cablesPorBandeja)
            {
                List<CableInstancia> cables = ObtenerCablesOrdenadosPorCarril(kvp.Value);

                if (cables == null || cables.Count <= 1)
                    continue;

                List<CableInstancia> ordenAscendente = cables
                    .OrderBy(x => ObtenerOrdenCircuito(x.Circuito))
                    .ThenBy(x => NormalizarTextoSeguro(x.Circuito))
                    .ThenBy(x => NormalizarTextoSeguro(x.TipoCable))
                    .ThenBy(x => x.IndiceEnTipo)
                    .ThenBy(x => ObtenerCableKeySeguro(x))
                    .ToList();

                Dictionary<string, int> indiceEsperado = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

                for (int i = 0; i < ordenAscendente.Count; i++)
                {
                    string key = ObtenerCableKeySeguro(ordenAscendente[i]);

                    if (!string.IsNullOrWhiteSpace(key) && !indiceEsperado.ContainsKey(key))
                        indiceEsperado[key] = i;
                }

                for (int i = 0; i < cables.Count; i++)
                {
                    string key = ObtenerCableKeySeguro(cables[i]);

                    if (string.IsNullOrWhiteSpace(key))
                        continue;

                    int esperado;

                    if (indiceEsperado.TryGetValue(key, out esperado))
                        penalizacion += Math.Abs(i - esperado);
                }
            }

            return penalizacion;
        }


        private List<ElementId> CrearDirectShapesEnAccesorio(
            Document doc,
            Element accesorio,
            List<ParCableFitting> pares)
        {
            List<ElementId> creados = new List<ElementId>();

            if (accesorio == null || pares == null || pares.Count == 0)
                return creados;

            // V12:
            // Se fuerza la continuidad real con los tramos rectos.
            // Cada accesorio toma exactamente el mismo offset del cable en la bandeja
            // conectada, para que el extremo del cable en la T/codo coincida con el
            // extremo del cable recto.
            // OJO: no se cambian circuitos, Excel ni DirectShapes individuales.
            // V18:
            // No se corrige el cruce solo dentro del accesorio porque eso rompe continuidad
            // con los tramos rectos. La corrección se hace antes, moviendo el carril del
            // cable en toda la bandeja. Aquí solo se fuerza continuidad exacta.
            pares = PrepararParesConContinuidadForzada(pares);

            // V20:
            // Se desactiva el codo suave para TODOS los accesorios.
            // Motivo: cuando algunos cables se crean por arco liso y otros por segmentos,
            // aparecen cruces visuales en curvas/codos. Desde esta versión todos los
            // recorridos de accesorios se crean segmentados con CrearSolidosCablePorPuntosV10.
            bool usarCodoSuave = false;

            foreach (ParCableFitting par in pares)
            {
                if (par == null || par.A == null || par.B == null ||
                    par.CableA == null || par.CableB == null)
                    continue;

                try
                {
                    CableInstancia cableInfo = par.CableA;
                    double radio = MmToFeet(Math.Max(cableInfo.DiametroMm, DiametroCableMmDefault) / 2.0);

                    XYZ pInicio = par.A.Punto + ObtenerOffsetPar(par, true);
                    XYZ pFin = par.B.Punto + ObtenerOffsetPar(par, false);

                    List<Solid> solidos = new List<Solid>();
                    List<XYZ> puntosLongitud = CrearPuntosRecorridoAccesorioV10(
                        pInicio,
                        par.A.DireccionHaciaInterior,
                        pFin,
                        par.B.DireccionHaciaInterior);

                    // V20:
                    // Todos los accesorios se generan por puntos/segmentos.
                    // La ruta suave queda desactivada para evitar cruces en codos.
                    if (usarCodoSuave)
                    {
                        solidos = CrearSolidosCableCodoSuaveV10(
                            pInicio,
                            par.A.DireccionHaciaInterior,
                            pFin,
                            par.B.DireccionHaciaInterior,
                            radio);
                    }

                    if (solidos == null || solidos.Count == 0)
                    {
                        solidos = CrearSolidosCablePorPuntosV10(puntosLongitud, radio);
                    }

                    if (solidos == null || solidos.Count == 0)
                        continue;

                    double longitud = CalcularLongitudPuntosV10(puntosLongitud);

                    if (longitud <= 0.0)
                        longitud = pInicio.DistanceTo(pFin);

                    DirectShape ds = CrearDirectShapeIndividual(
                        doc,
                        solidos,
                        cableInfo,
                        accesorio.Id,
                        "ACCESORIO",
                        longitud);

                    if (ds != null)
                    {
                        AplicarOverrideGrafico(doc, ds.Id, cableInfo.Color);
                        creados.Add(ds.Id);
                    }
                }
                catch
                {
                }
            }

            return creados;
        }


        private CurveLoop CrearRecorridoConContinuidad(
            XYZ puntoInicio,
            XYZ dirInicioInterior,
            XYZ puntoFin,
            XYZ dirFinInterior,
            XYZ centroAccesorio)
        {
            CurveLoop loop = new CurveLoop();

            if (puntoInicio == null || puntoFin == null)
                return loop;

            double distancia = puntoInicio.DistanceTo(puntoFin);

            if (distancia < MmToFeet(1.0))
                return loop;

            XYZ dIni = dirInicioInterior;
            XYZ dFin = dirFinInterior;

            if (EsVectorCero(dIni))
                dIni = puntoFin - puntoInicio;

            if (EsVectorCero(dFin))
                dFin = puntoInicio - puntoFin;

            if (EsVectorCero(dIni))
                dIni = XYZ.BasisX;

            if (EsVectorCero(dFin))
                dFin = -XYZ.BasisX;

            dIni = dIni.Normalize();
            dFin = dFin.Normalize();

            double lead = Math.Min(distancia * 0.22, MmToFeet(100.0));
            lead = Math.Max(lead, MmToFeet(20.0));

            XYZ p1 = puntoInicio;
            XYZ p2 = puntoInicio + dIni * lead;
            XYZ p4 = puntoFin;
            XYZ p3 = puntoFin + dFin * lead;

            if (p1.DistanceTo(p2) > MmToFeet(1.0))
                loop.Append(Line.CreateBound(p1, p2));

            Curve curvaIntermedia = null;

            XYZ pm = (p2 + p3) * 0.5;

            XYZ empuje = centroAccesorio - pm;

            if (!EsVectorCero(empuje))
            {
                empuje = empuje.Normalize();
                pm = pm + empuje * Math.Min(distancia * 0.08, MmToFeet(35.0));
            }

            try
            {
                if (p2.DistanceTo(p3) > MmToFeet(1.0))
                    curvaIntermedia = Arc.Create(p2, p3, pm);
            }
            catch
            {
                try
                {
                    curvaIntermedia = Line.CreateBound(p2, p3);
                }
                catch
                {
                    curvaIntermedia = null;
                }
            }

            if (curvaIntermedia != null)
                loop.Append(curvaIntermedia);

            if (p3.DistanceTo(p4) > MmToFeet(1.0))
                loop.Append(Line.CreateBound(p3, p4));

            return loop;
        }
        private DirectShape CrearDirectShapeIndividual(
            Document doc,
            Solid solid,
            CableInstancia cable,
            ElementId origenId,
            string tramoTipo,
            double longitudFt)
        {
            if (solid == null)
                return null;

            List<Solid> solidos = new List<Solid>();
            solidos.Add(solid);

            return CrearDirectShapeIndividual(
                doc,
                solidos,
                cable,
                origenId,
                tramoTipo,
                longitudFt);
        }

        private DirectShape CrearDirectShapeIndividual(
            Document doc,
            List<Solid> solidos,
            CableInstancia cable,
            ElementId origenId,
            string tramoTipo,
            double longitudFt)
        {
            if (solidos == null || solidos.Count == 0 || cable == null)
                return null;

            try
            {
                List<GeometryObject> geometria = new List<GeometryObject>();

                foreach (Solid s in solidos)
                {
                    if (s == null)
                        continue;

                    if (s.Volume <= 0)
                        continue;

                    geometria.Add(s);
                }

                if (geometria.Count == 0)
                    return null;

                DirectShape ds = DirectShape.CreateElement(
                    doc,
                    new ElementId(BuiltInCategory.OST_Conduit));

                ds.ApplicationId = AppId;
                ds.ApplicationDataId = cable.Key + "|" + (origenId == null ? "" : origenId.Value.ToString());

                try
                {
                    ds.Name = cable.Circuito + " - " + cable.TipoCable + " - " + tramoTipo;
                }
                catch
                {
                }

                ds.SetShape(geometria);

                string comentario =
                    "Generado por: " + MarcaGenerado + "\n" +
                    "Circuito: " + cable.Circuito + "\n" +
                    "NombreCircuito: " + cable.NombreCircuito + "\n" +
                    "Sistema: " + cable.Sistema + "\n" +
                    "TipoCable: " + cable.TipoCable + "\n" +
                    "Cable: " + cable.IndiceEnTipo + "/" + cable.CantidadTipo + "\n" +
                    "TramoTipo: " + tramoTipo + "\n" +
                    "OrigenId: " + (origenId == null ? "" : origenId.Value.ToString()) + "\n" +
                    "Longitud_m: " + FeetToMeters(longitudFt).ToString("0.000", CultureInfo.InvariantCulture);

                SetParametroBuiltInTexto(ds, BuiltInParameter.ALL_MODEL_MARK, MarcaGenerado);
                SetParametroBuiltInTexto(ds, BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS, comentario);

                SetParametroTextoSiExiste(ds, "ELE_NumeroCircuito", cable.Circuito);
                SetParametroTextoSiExiste(ds, "ELE_NombreCircuito", cable.NombreCircuito);
                SetParametroTextoSiExiste(ds, "ELE_Sistema", cable.Sistema);
                SetParametroTextoSiExiste(ds, "ELE_TipoCable", cable.TipoCable);
                SetParametroTextoSiExiste(ds, "ELE_GeneradoPor", MarcaGenerado);
                SetParametroTextoSiExiste(ds, "ELE_TramoTipo", tramoTipo);
                SetParametroTextoSiExiste(ds, "ELE_CableKey", cable.Key);
                SetParametroEntero(ds, "ELE_IndiceCable", cable.IndiceEnTipo);
                SetParametroEntero(ds, "ELE_CantidadTipo", cable.CantidadTipo);
                SetParametroDoubleMetrosSiExiste(ds, "ELE_Longitud", FeetToMeters(longitudFt));

                if (origenId != null)
                    SetParametroTextoSiExiste(ds, "ELE_ElementoBandejaId", origenId.Value.ToString());

                return ds;
            }
            catch
            {
                return null;
            }
        }


        private Solid CrearSolidoCablePorBarrido(Curve path, double radius)
        {
            if (path == null)
                return null;

            CurveLoop recorrido = new CurveLoop();
            recorrido.Append(path);

            return CrearSolidoCablePorBarrido(recorrido, radius);
        }

        private Solid CrearSolidoCablePorBarrido(CurveLoop recorrido, double radius)
        {
            if (recorrido == null || radius <= 0)
                return null;

            try
            {
                Curve primera = null;

                foreach (Curve c in recorrido)
                {
                    primera = c;
                    break;
                }

                if (primera == null)
                    return null;

                XYZ start = primera.GetEndPoint(0);
                XYZ tangent = ObtenerTangenteInicio(primera);

                if (EsVectorCero(tangent))
                    tangent = primera.GetEndPoint(1) - primera.GetEndPoint(0);

                if (EsVectorCero(tangent))
                    return null;

                tangent = tangent.Normalize();

                XYZ bx = ObtenerVectorPerpendicular(tangent);
                XYZ by = tangent.CrossProduct(bx);

                if (EsVectorCero(by))
                    by = XYZ.BasisZ;

                by = by.Normalize();

                XYZ p0 = start + bx * radius;
                XYZ p1 = start + by * radius;
                XYZ p2 = start - bx * radius;
                XYZ p3 = start - by * radius;

                CurveLoop perfil = new CurveLoop();
                perfil.Append(Arc.Create(p0, p2, p1));
                perfil.Append(Arc.Create(p2, p0, p3));

                List<CurveLoop> perfiles = new List<CurveLoop>();
                perfiles.Add(perfil);

                return GeometryCreationUtilities.CreateSweptGeometry(
                    recorrido,
                    0,
                    0.0,
                    perfiles);
            }
            catch
            {
                return null;
            }
        }

        // =========================================================
        // V10 - GEOMETRÍA ESTABLE ANTERIOR PARA CREACIÓN DE CABLES
        // Mantiene Excel/circuitos, pero regresa la creación del sólido
        // a la lógica por puntos/cilindros que funcionaba sin deformar.
        // =========================================================

        private bool EsAccesorioConDosPuertosSeleccionados(List<ParCableFitting> pares)
        {
            if (pares == null || pares.Count == 0)
                return false;

            HashSet<long> puertos = new HashSet<long>();

            foreach (ParCableFitting par in pares)
            {
                if (par == null)
                    continue;

                if (par.A != null && par.A.BandejaId != null)
                    puertos.Add(par.A.BandejaId.Value);

                if (par.B != null && par.B.BandejaId != null)
                    puertos.Add(par.B.BandejaId.Value);
            }

            return puertos.Count <= 2;
        }

        private List<Solid> CrearSolidosCableCodoSuaveV10(
            XYZ puntoInicio,
            XYZ dirInicioInterior,
            XYZ puntoFin,
            XYZ dirFinInterior,
            double radius)
        {
            List<Solid> solidos = new List<Solid>();

            if (puntoInicio == null || puntoFin == null || radius <= 0)
                return solidos;

            double distancia = puntoInicio.DistanceTo(puntoFin);

            if (distancia < MmToFeet(1.0))
                return solidos;

            XYZ dIni = dirInicioInterior;
            XYZ dFinInterior = dirFinInterior;

            if (EsVectorCero(dIni))
                dIni = puntoFin - puntoInicio;

            if (EsVectorCero(dFinInterior))
                dFinInterior = puntoInicio - puntoFin;

            if (EsVectorCero(dIni))
                dIni = XYZ.BasisX;

            if (EsVectorCero(dFinInterior))
                dFinInterior = -XYZ.BasisX;

            dIni = dIni.Normalize();
            dFinInterior = dFinInterior.Normalize();

            XYZ dFinRecorrido = -dFinInterior;

            if (EsVectorCero(dFinRecorrido))
                dFinRecorrido = puntoFin - puntoInicio;

            dFinRecorrido = dFinRecorrido.Normalize();

            double dot = dIni.DotProduct(dFinRecorrido);

            if (dot > 0.96)
            {
                try
                {
                    Solid sLineal = CrearSolidoCablePorBarridoSuaveV10(
                        Line.CreateBound(puntoInicio, puntoFin),
                        radius);

                    if (sLineal != null && sLineal.Volume > 0)
                    {
                        solidos.Add(sLineal);
                        return solidos;
                    }
                }
                catch
                {
                }
            }

            try
            {
                Curve arco = CrearArcoCodoPorTangentesV10(
                    puntoInicio,
                    dIni,
                    puntoFin,
                    dFinRecorrido);

                if (arco != null)
                {
                    Solid s = CrearSolidoCablePorBarridoSuaveV10(arco, radius);

                    if (s != null && s.Volume > 0)
                    {
                        solidos.Add(s);
                        return solidos;
                    }
                }
            }
            catch
            {
            }

            List<XYZ> puntos = CrearPuntosRecorridoAccesorioV10(
                puntoInicio,
                dirInicioInterior,
                puntoFin,
                dirFinInterior);

            return CrearSolidosCablePorPuntosV10(puntos, radius);
        }

        private Curve CrearArcoCodoPorTangentesV10(
            XYZ pInicio,
            XYZ tangenteInicio,
            XYZ pFin,
            XYZ tangenteFinRecorrido)
        {
            if (pInicio == null || pFin == null)
                return null;

            if (EsVectorCero(tangenteInicio) || EsVectorCero(tangenteFinRecorrido))
                return null;

            XYZ t1 = tangenteInicio.Normalize();
            XYZ t2 = tangenteFinRecorrido.Normalize();

            double distancia = pInicio.DistanceTo(pFin);

            if (distancia < MmToFeet(1.0))
                return null;

            if (Math.Abs(t1.DotProduct(t2)) > 0.985)
                return Line.CreateBound(pInicio, pFin);

            XYZ eje = t1.CrossProduct(t2);

            if (EsVectorCero(eje))
                eje = XYZ.BasisZ;

            eje = eje.Normalize();

            XYZ mejorCentro = XYZ.Zero;
            double mejorScore = double.MaxValue;

            XYZ[] normalesInicio = new XYZ[]
            {
                eje.CrossProduct(t1),
                t1.CrossProduct(eje)
            };

            XYZ[] normalesFin = new XYZ[]
            {
                eje.CrossProduct(t2),
                t2.CrossProduct(eje)
            };

            for (int i = 0; i < normalesInicio.Length; i++)
            {
                XYZ n1 = normalesInicio[i];

                if (EsVectorCero(n1))
                    continue;

                n1 = n1.Normalize();

                for (int j = 0; j < normalesFin.Length; j++)
                {
                    XYZ n2 = normalesFin[j];

                    if (EsVectorCero(n2))
                        continue;

                    n2 = n2.Normalize();

                    XYZ c1;
                    XYZ c2;
                    double distanciaLineas;

                    if (!ObtenerPuntosMasCercanosEntreLineasV10(
                        pInicio,
                        n1,
                        pFin,
                        n2,
                        out c1,
                        out c2,
                        out distanciaLineas))
                    {
                        continue;
                    }

                    XYZ centro = (c1 + c2) * 0.5;
                    double r1 = centro.DistanceTo(pInicio);
                    double r2 = centro.DistanceTo(pFin);

                    if (r1 < MmToFeet(5.0) || r2 < MmToFeet(5.0))
                        continue;

                    XYZ u = (pInicio - centro).Normalize();
                    XYZ v = (pFin - centro).Normalize();

                    XYZ ejeLocal = u.CrossProduct(v);

                    if (EsVectorCero(ejeLocal))
                        continue;

                    ejeLocal = ejeLocal.Normalize();

                    XYZ tangenteCalcInicio = ejeLocal.CrossProduct(u);

                    if (!EsVectorCero(tangenteCalcInicio) && tangenteCalcInicio.Normalize().DotProduct(t1) < 0)
                        ejeLocal = -ejeLocal;

                    XYZ tanIni = ejeLocal.CrossProduct(u);
                    XYZ tanFin = ejeLocal.CrossProduct(v);

                    double aIni = EsVectorCero(tanIni) ? 0.0 : tanIni.Normalize().DotProduct(t1);
                    double aFin = EsVectorCero(tanFin) ? 0.0 : tanFin.Normalize().DotProduct(t2);

                    double score = distanciaLineas * 20.0 + Math.Abs(r1 - r2) * 10.0 +
                                   (1.0 - aIni) * 2.0 + (1.0 - aFin) * 2.0;

                    double radioProm = (r1 + r2) * 0.5;

                    if (radioProm > distancia * 3.0)
                        score += radioProm;

                    if (score < mejorScore)
                    {
                        mejorScore = score;
                        mejorCentro = centro;
                    }
                }
            }

            if (!EsPuntoValidoV10(mejorCentro))
                return null;

            try
            {
                XYZ u = pInicio - mejorCentro;
                XYZ v = pFin - mejorCentro;

                if (EsVectorCero(u) || EsVectorCero(v))
                    return null;

                double radio = (u.GetLength() + v.GetLength()) * 0.5;

                u = u.Normalize();
                v = v.Normalize();

                XYZ medioDir = u + v;

                if (EsVectorCero(medioDir))
                    return null;

                medioDir = medioDir.Normalize();

                XYZ puntoMedioArco = mejorCentro + medioDir * radio;

                Curve prueba = Arc.Create(pInicio, pFin, puntoMedioArco);
                XYZ tanPrueba = ObtenerTangenteInicio(prueba);

                if (!EsVectorCero(tanPrueba) && tanPrueba.Normalize().DotProduct(t1) < 0)
                {
                    puntoMedioArco = mejorCentro - medioDir * radio;
                    prueba = Arc.Create(pInicio, pFin, puntoMedioArco);
                }

                return prueba;
            }
            catch
            {
                return null;
            }
        }

        private Solid CrearSolidoCablePorBarridoSuaveV10(
            Curve path,
            double radius)
        {
            if (path == null || radius <= 0)
                return null;

            try
            {
                CurveLoop recorrido = new CurveLoop();
                recorrido.Append(path);

                return CrearSolidoCablePorBarridoSuaveV10(recorrido, radius);
            }
            catch
            {
                return null;
            }
        }

        private Solid CrearSolidoCablePorBarridoSuaveV10(
            CurveLoop recorrido,
            double radius)
        {
            if (recorrido == null || radius <= 0)
                return null;

            try
            {
                Curve primera = null;

                foreach (Curve c in recorrido)
                {
                    primera = c;
                    break;
                }

                if (primera == null)
                    return null;

                XYZ start = primera.GetEndPoint(0);
                XYZ tangent = ObtenerTangenteInicio(primera);

                if (EsVectorCero(tangent))
                {
                    XYZ end = primera.GetEndPoint(1);
                    tangent = end - start;
                }

                if (EsVectorCero(tangent))
                    return null;

                tangent = tangent.Normalize();

                XYZ lateral;
                XYZ vertical;
                CalcularBaseLocal(tangent, out lateral, out vertical);

                CurveLoop perfil = CrearPerfilCircularV10(start, lateral, vertical, radius);

                if (perfil == null)
                    return null;

                List<CurveLoop> perfiles = new List<CurveLoop>();
                perfiles.Add(perfil);

                Solid s = GeometryCreationUtilities.CreateSweptGeometry(
                    recorrido,
                    0,
                    0.0,
                    perfiles);

                return s;
            }
            catch
            {
                return null;
            }
        }

        private bool ObtenerPuntosMasCercanosEntreLineasV10(
            XYZ p1,
            XYZ d1,
            XYZ p2,
            XYZ d2,
            out XYZ c1,
            out XYZ c2,
            out double distancia)
        {
            c1 = p1;
            c2 = p2;
            distancia = double.MaxValue;

            if (p1 == null || p2 == null || EsVectorCero(d1) || EsVectorCero(d2))
                return false;

            XYZ u = d1.Normalize();
            XYZ v = d2.Normalize();
            XYZ w0 = p1 - p2;

            double a = u.DotProduct(u);
            double b = u.DotProduct(v);
            double c = v.DotProduct(v);
            double d = u.DotProduct(w0);
            double e = v.DotProduct(w0);
            double den = a * c - b * b;

            if (Math.Abs(den) < 0.0000001)
                return false;

            double s = (b * e - c * d) / den;
            double t = (a * e - b * d) / den;

            c1 = p1 + u * s;
            c2 = p2 + v * t;
            distancia = c1.DistanceTo(c2);

            return true;
        }

        private List<XYZ> CrearPuntosRecorridoAccesorioV10(
            XYZ puntoInicio,
            XYZ dirInicioInterior,
            XYZ puntoFin,
            XYZ dirFinInterior)
        {
            List<XYZ> puntos = new List<XYZ>();

            if (puntoInicio == null || puntoFin == null)
                return puntos;

            double distancia = puntoInicio.DistanceTo(puntoFin);

            if (distancia < MmToFeet(1.0))
                return puntos;

            XYZ dIni = dirInicioInterior;
            XYZ dFin = dirFinInterior;

            if (EsVectorCero(dIni))
                dIni = puntoFin - puntoInicio;

            if (EsVectorCero(dFin))
                dFin = puntoInicio - puntoFin;

            if (EsVectorCero(dIni))
                dIni = XYZ.BasisX;

            if (EsVectorCero(dFin))
                dFin = -XYZ.BasisX;

            dIni = dIni.Normalize();
            dFin = dFin.Normalize();

            double dot = dIni.DotProduct(dFin);

            if (dot < -0.94)
            {
                puntos.Add(puntoInicio);
                puntos.Add(puntoFin);
                return puntos;
            }

            double lead = Math.Min(distancia * 0.22, MmToFeet(90.0));
            lead = Math.Max(lead, MmToFeet(12.0));

            XYZ p1 = puntoInicio;
            XYZ p2 = puntoInicio + dIni * lead;
            XYZ p4 = puntoFin;
            XYZ p3 = puntoFin + dFin * lead;

            XYZ pc = CalcularInterseccionAproximadaRayosV10(p2, dIni, p3, dFin);

            if (!EsPuntoValidoV10(pc))
                pc = (p2 + p3) * 0.5;

            double maxDist = Math.Max(distancia * 0.85, MmToFeet(150.0));
            XYZ pm = (p2 + p3) * 0.5;

            if (pc.DistanceTo(pm) > maxDist)
                pc = pm;

            puntos.Add(p1);

            if (puntos[puntos.Count - 1].DistanceTo(p2) > MmToFeet(0.5))
                puntos.Add(p2);

            int divisiones = 8;

            for (int i = 1; i < divisiones; i++)
            {
                double t = (double)i / (double)divisiones;
                XYZ q = BezierCuadraticaV10(p2, pc, p3, t);

                if (puntos[puntos.Count - 1].DistanceTo(q) > MmToFeet(0.5))
                    puntos.Add(q);
            }

            if (puntos[puntos.Count - 1].DistanceTo(p3) > MmToFeet(0.5))
                puntos.Add(p3);

            if (puntos[puntos.Count - 1].DistanceTo(p4) > MmToFeet(0.5))
                puntos.Add(p4);

            return puntos;
        }

        private XYZ BezierCuadraticaV10(
            XYZ p0,
            XYZ p1,
            XYZ p2,
            double t)
        {
            double u = 1.0 - t;
            return p0 * (u * u) + p1 * (2.0 * u * t) + p2 * (t * t);
        }

        private XYZ CalcularInterseccionAproximadaRayosV10(
            XYZ p1,
            XYZ d1,
            XYZ p2,
            XYZ d2)
        {
            if (p1 == null || p2 == null || EsVectorCero(d1) || EsVectorCero(d2))
                return (p1 + p2) * 0.5;

            XYZ u = d1.Normalize();
            XYZ v = d2.Normalize();
            XYZ w0 = p1 - p2;

            double a = u.DotProduct(u);
            double b = u.DotProduct(v);
            double c = v.DotProduct(v);
            double d = u.DotProduct(w0);
            double e = v.DotProduct(w0);
            double den = a * c - b * b;

            if (Math.Abs(den) < 0.0000001)
                return (p1 + p2) * 0.5;

            double s = (b * e - c * d) / den;
            double t = (a * e - b * d) / den;

            if (s < 0.0)
                s = 0.0;

            if (t < 0.0)
                t = 0.0;

            XYZ q1 = p1 + u * s;
            XYZ q2 = p2 + v * t;

            return (q1 + q2) * 0.5;
        }

        private List<Solid> CrearSolidosCablePorCurvaV10(Curve curva, double radius)
        {
            List<XYZ> puntos = ObtenerPuntosDeCurvaV10(curva);
            return CrearSolidosCablePorPuntosV10(puntos, radius);
        }

        private List<Solid> CrearSolidosCablePorPuntosV10(
            List<XYZ> puntos,
            double radius)
        {
            List<Solid> solidos = new List<Solid>();

            if (puntos == null || puntos.Count < 2 || radius <= 0)
                return solidos;

            for (int i = 0; i < puntos.Count - 1; i++)
            {
                XYZ a = puntos[i];
                XYZ b = puntos[i + 1];

                if (a == null || b == null)
                    continue;

                Solid s = CrearSolidoCilindroEntrePuntosV10(a, b, radius);

                if (s != null && s.Volume > 0)
                    solidos.Add(s);
            }

            return solidos;
        }

        private Solid CrearSolidoCilindroEntrePuntosV10(
            XYZ a,
            XYZ b,
            double radius)
        {
            if (a == null || b == null || radius <= 0)
                return null;

            XYZ vector = b - a;
            double longitud = vector.GetLength();

            if (longitud < MmToFeet(1.0))
                return null;

            XYZ dir = vector.Normalize();

            try
            {
                XYZ lateral;
                XYZ vertical;
                CalcularBaseLocal(dir, out lateral, out vertical);

                CurveLoop perfil = CrearPerfilCircularV10(a, lateral, vertical, radius);

                if (perfil == null)
                    return null;

                List<CurveLoop> perfiles = new List<CurveLoop>();
                perfiles.Add(perfil);

                Solid s = GeometryCreationUtilities.CreateExtrusionGeometry(
                    perfiles,
                    dir,
                    longitud);

                return s;
            }
            catch
            {
                return null;
            }
        }

        private CurveLoop CrearPerfilCircularV10(
            XYZ centro,
            XYZ lateral,
            XYZ vertical,
            double radius)
        {
            if (centro == null || radius <= 0)
                return null;

            if (EsVectorCero(lateral))
                lateral = XYZ.BasisX;

            if (EsVectorCero(vertical))
                vertical = XYZ.BasisZ;

            lateral = lateral.Normalize();
            vertical = vertical.Normalize();

            XYZ p0 = centro + lateral * radius;
            XYZ p1 = centro + vertical * radius;
            XYZ p2 = centro - lateral * radius;
            XYZ p3 = centro - vertical * radius;

            CurveLoop perfil = new CurveLoop();
            perfil.Append(Arc.Create(p0, p2, p1));
            perfil.Append(Arc.Create(p2, p0, p3));

            return perfil;
        }

        private List<XYZ> ObtenerPuntosDeCurvaV10(Curve curva)
        {
            List<XYZ> puntos = new List<XYZ>();

            if (curva == null)
                return puntos;

            try
            {
                Line linea = curva as Line;

                if (linea != null)
                {
                    puntos.Add(linea.GetEndPoint(0));
                    puntos.Add(linea.GetEndPoint(1));
                    return puntos;
                }
            }
            catch
            {
            }

            try
            {
                IList<XYZ> tess = curva.Tessellate();

                if (tess != null && tess.Count >= 2)
                {
                    foreach (XYZ p in tess)
                    {
                        if (p == null)
                            continue;

                        if (puntos.Count == 0 || puntos[puntos.Count - 1].DistanceTo(p) > MmToFeet(0.5))
                            puntos.Add(p);
                    }
                }
            }
            catch
            {
            }

            if (puntos.Count < 2)
            {
                try
                {
                    puntos.Clear();
                    puntos.Add(curva.GetEndPoint(0));
                    puntos.Add(curva.GetEndPoint(1));
                }
                catch
                {
                }
            }

            return puntos;
        }

        private double CalcularLongitudPuntosV10(List<XYZ> puntos)
        {
            double total = 0.0;

            if (puntos == null || puntos.Count < 2)
                return total;

            for (int i = 0; i < puntos.Count - 1; i++)
            {
                if (puntos[i] != null && puntos[i + 1] != null)
                    total += puntos[i].DistanceTo(puntos[i + 1]);
            }

            return total;
        }

        private bool EsPuntoValidoV10(XYZ p)
        {
            if (p == null)
                return false;

            return p.GetLength() > 0.000001;
        }


        private HashSet<ElementId> ObtenerIdsBaseDesdeVentanaOSeleccion(UIDocument uidoc, Document doc)
        {
            HashSet<ElementId> ids = new HashSet<ElementId>(new ElementIdComparer());

            if (ElementosIds != null)
            {
                foreach (ElementId id in ElementosIds)
                {
                    if (id == null || id == ElementId.InvalidElementId)
                        continue;

                    Element e = doc.GetElement(id);

                    if (e == null)
                        continue;

                    if (EsBandejaCable(e) || EsAccesorioBandeja(e))
                        ids.Add(id);
                }
            }

            if (ids.Count > 0)
                return ids;

            ICollection<ElementId> seleccionActual = uidoc.Selection.GetElementIds();

            if (seleccionActual != null)
            {
                foreach (ElementId id in seleccionActual)
                {
                    Element e = doc.GetElement(id);

                    if (e == null)
                        continue;

                    if (EsBandejaCable(e) || EsAccesorioBandeja(e))
                        ids.Add(id);
                }
            }

            return ids;
        }

        private int BorrarDirectShapesPrevios(Document doc)
        {
            List<ElementId> borrar = new List<ElementId>();

            FilteredElementCollector collector = new FilteredElementCollector(doc)
                .OfClass(typeof(DirectShape));

            foreach (Element e in collector)
            {
                DirectShape ds = e as DirectShape;

                if (ds == null)
                    continue;

                bool esMio = false;

                try
                {
                    if (string.Equals(ds.ApplicationId, AppId, StringComparison.OrdinalIgnoreCase))
                        esMio = true;
                }
                catch
                {
                }

                if (!esMio)
                {
                    Parameter pMark = ds.get_Parameter(BuiltInParameter.ALL_MODEL_MARK);

                    if (pMark != null)
                    {
                        string mark = pMark.AsString();

                        if (!string.IsNullOrWhiteSpace(mark) &&
                            mark.ToUpperInvariant().Contains(MarcaGenerado))
                        {
                            esMio = true;
                        }
                    }
                }

                if (esMio)
                    borrar.Add(ds.Id);
            }

            if (borrar.Count > 0)
                doc.Delete(borrar);

            return borrar.Count;
        }

        private List<string> ExpandirTextoCircuitos(string texto)
        {
            List<string> resultado = new List<string>();

            if (string.IsNullOrWhiteSpace(texto))
                return resultado;

            string normal = texto.Replace("\r", ";").Replace("\n", ";").Replace(",", ";").Replace("|", ";").Replace("/", ";");
            string[] partes = normal.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string parte0 in partes)
            {
                string parte = parte0.Trim();

                if (string.IsNullOrWhiteSpace(parte))
                    continue;

                if (parte.Contains("-"))
                {
                    List<string> exp = ExpandirRangoCircuitos(parte);

                    foreach (string c in exp)
                    {
                        if (!resultado.Contains(c, StringComparer.OrdinalIgnoreCase))
                            resultado.Add(c);
                    }
                }
                else
                {
                    string c = NormalizarCircuito(parte);

                    if (!string.IsNullOrWhiteSpace(c) &&
                        !resultado.Contains(c, StringComparer.OrdinalIgnoreCase))
                    {
                        resultado.Add(c);
                    }
                }
            }

            return resultado;
        }

        private List<string> ExpandirRangoCircuitos(string texto)
        {
            List<string> resultado = new List<string>();

            string[] p = texto.Split(new char[] { '-' }, StringSplitOptions.RemoveEmptyEntries);

            if (p.Length != 2)
            {
                string c = NormalizarCircuito(texto);

                if (!string.IsNullOrWhiteSpace(c))
                    resultado.Add(c);

                return resultado;
            }

            string a = NormalizarCircuito(p[0]);
            string b = NormalizarCircuito(p[1]);

            string prefA;
            int numA;
            int digA;

            string prefB;
            int numB;
            int digB;

            if (!SepararPrefijoNumero(a, out prefA, out numA, out digA) ||
                !SepararPrefijoNumero(b, out prefB, out numB, out digB) ||
                !string.Equals(prefA, prefB, StringComparison.OrdinalIgnoreCase))
            {
                resultado.Add(a);
                resultado.Add(b);
                return resultado;
            }

            int ini = Math.Min(numA, numB);
            int fin = Math.Max(numA, numB);
            int dig = Math.Max(digA, digB);

            for (int i = ini; i <= fin; i++)
            {
                resultado.Add(prefA.ToUpperInvariant() + i.ToString(new string('0', dig)));
            }

            return resultado;
        }

        private bool SepararPrefijoNumero(string texto, out string prefijo, out int numero, out int digitos)
        {
            prefijo = "";
            numero = 0;
            digitos = 0;

            if (string.IsNullOrWhiteSpace(texto))
                return false;

            string s = texto.Trim().ToUpperInvariant();

            int idx = s.Length - 1;

            while (idx >= 0 && char.IsDigit(s[idx]))
                idx--;

            if (idx == s.Length - 1)
                return false;

            prefijo = s.Substring(0, idx + 1);
            string numText = s.Substring(idx + 1);
            digitos = numText.Length;

            return int.TryParse(numText, out numero);
        }

        private string CrearCableKey(string circuito, string tipoCable, int indice)
        {
            return NormalizarCircuito(circuito) + "|" +
                   NormalizarClave(tipoCable) + "|" +
                   indice.ToString("000");
        }

        private string NormalizarCircuito(string texto)
        {
            if (texto == null)
                return "";

            return texto.Trim().Replace(" ", "").ToUpperInvariant();
        }

        private string NormalizarClave(string texto)
        {
            if (texto == null)
                return "";

            return texto.Trim().ToUpperInvariant()
                .Replace(" ", "")
                .Replace("-", "")
                .Replace("_", "")
                .Replace(".", "")
                .Replace(",", "");
        }

        private string NormalizarHeader(string texto)
        {
            return NormalizarClave(texto);
        }

        private int BuscarCol(Dictionary<string, int> col, params string[] nombres)
        {
            foreach (string n in nombres)
            {
                string key = NormalizarHeader(n);

                if (col.ContainsKey(key))
                    return col[key];
            }

            return -1;
        }

        private string LeerTexto(ExcelWorksheet ws, int row, int col)
        {
            if (ws == null || col <= 0)
                return "";

            try
            {
                return Convert.ToString(ws.Cells[row, col].Text);
            }
            catch
            {
                return "";
            }
        }

        private int LeerEntero(ExcelWorksheet ws, int row, int col)
        {
            double d = LeerDouble(ws, row, col, 0.0);
            return (int)Math.Round(d);
        }

        private double LeerDouble(ExcelWorksheet ws, int row, int col, double defecto)
        {
            if (ws == null || col <= 0)
                return defecto;

            try
            {
                object v = ws.Cells[row, col].Value;

                if (v is double)
                    return (double)v;

                if (v is int)
                    return Convert.ToDouble(v);

                string s = Convert.ToString(ws.Cells[row, col].Text);

                if (string.IsNullOrWhiteSpace(s))
                    return defecto;

                s = s.Trim().Replace(",", ".");

                double d;

                if (double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out d))
                    return d;
            }
            catch
            {
            }

            return defecto;
        }

        private Autodesk.Revit.DB.Color ParseColor(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return new Autodesk.Revit.DB.Color(220, 30, 30);

            try
            {
                string s = texto.Trim().Replace(";", ",").Replace("|", ",");
                string[] p = s.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                if (p.Length >= 3)
                {
                    byte r = Convert.ToByte(Math.Max(0, Math.Min(255, int.Parse(p[0].Trim()))));
                    byte g = Convert.ToByte(Math.Max(0, Math.Min(255, int.Parse(p[1].Trim()))));
                    byte b = Convert.ToByte(Math.Max(0, Math.Min(255, int.Parse(p[2].Trim()))));
                    return new Autodesk.Revit.DB.Color(r, g, b);
                }
            }
            catch
            {
            }

            return new Autodesk.Revit.DB.Color(220, 30, 30);
        }

        private Autodesk.Revit.DB.Color ColorPorSistema(string sistema)
        {
            string s = (sistema ?? "").Trim().ToUpperInvariant();

            if (s.Contains("ILUMIN"))
                return new Autodesk.Revit.DB.Color(255, 190, 0);

            if (s.Contains("TOMAC") || s.Contains("FUERZA"))
                return new Autodesk.Revit.DB.Color(0, 112, 192);

            if (s.Contains("DATA") || s.Contains("COMUNIC"))
                return new Autodesk.Revit.DB.Color(0, 176, 80);

            if (s.Contains("CCTV"))
                return new Autodesk.Revit.DB.Color(112, 48, 160);

            if (s.Contains("ALARMA"))
                return new Autodesk.Revit.DB.Color(255, 0, 0);

            return new Autodesk.Revit.DB.Color(220, 30, 30);
        }

        private string ObtenerParametroTexto(Element e, string nombreParametro)
        {
            if (e == null || string.IsNullOrWhiteSpace(nombreParametro))
                return "";

            Parameter p = e.LookupParameter(nombreParametro);

            if (p == null)
                return "";

            try
            {
                if (p.StorageType == StorageType.String)
                    return p.AsString();

                return p.AsValueString();
            }
            catch
            {
                return "";
            }
        }

        private void SetParametroTextoSiExiste(Element e, string nombreParametro, string valor)
        {
            if (e == null || string.IsNullOrWhiteSpace(nombreParametro))
                return;

            Parameter p = e.LookupParameter(nombreParametro);

            if (p == null || p.IsReadOnly)
                return;

            try
            {
                if (p.StorageType == StorageType.String)
                    p.Set(valor ?? "");
                else
                    p.SetValueString(valor ?? "");
            }
            catch
            {
            }
        }

        private void SetParametroEntero(Element e, string nombreParametro, int valor)
        {
            if (e == null || string.IsNullOrWhiteSpace(nombreParametro))
                return;

            Parameter p = e.LookupParameter(nombreParametro);

            if (p == null || p.IsReadOnly)
                return;

            try
            {
                if (p.StorageType == StorageType.Integer)
                    p.Set(valor);
                else if (p.StorageType == StorageType.Double)
                    p.Set(valor);
                else if (p.StorageType == StorageType.String)
                    p.Set(valor.ToString());
            }
            catch
            {
            }
        }

        private void SetParametroDoubleMetrosSiExiste(Element e, string nombreParametro, double valorMetros)
        {
            if (e == null || string.IsNullOrWhiteSpace(nombreParametro))
                return;

            Parameter p = e.LookupParameter(nombreParametro);

            if (p == null || p.IsReadOnly)
                return;

            try
            {
                if (p.StorageType == StorageType.Double)
                {
                    p.Set(valorMetros / 0.3048);
                }
                else if (p.StorageType == StorageType.String)
                {
                    p.Set(valorMetros.ToString("0.000", CultureInfo.InvariantCulture));
                }
            }
            catch
            {
            }
        }

        private void SetParametroBuiltInTexto(Element e, BuiltInParameter bip, string valor)
        {
            if (e == null)
                return;

            try
            {
                Parameter p = e.get_Parameter(bip);

                if (p == null || p.IsReadOnly)
                    return;

                if (p.StorageType == StorageType.String)
                    p.Set(valor ?? "");
            }
            catch
            {
            }
        }

        private void AplicarOverrideGrafico(Document doc, ElementId id, Autodesk.Revit.DB.Color color)
        {
            if (doc == null || id == null)
                return;

            View view = doc.ActiveView;

            if (view == null || view.IsTemplate)
                return;

            try
            {
                OverrideGraphicSettings ogs = new OverrideGraphicSettings();

                Autodesk.Revit.DB.Color colorContorno = new Autodesk.Revit.DB.Color(0, 0, 0);
                ElementId solidFillId = ObtenerSolidFillPatternId(doc);

                // =========================================================
                // V36 - COLORES:
                // Relleno: color del cable/circuito desde Excel.
                // Contorno: negro.
                // Se aplica tanto en proyección como en corte.
                // =========================================================

                // CONTORNO NEGRO
                ogs.SetProjectionLineColor(colorContorno);
                ogs.SetCutLineColor(colorContorno);

                try
                {
                    ogs.SetProjectionLineWeight(1);
                    ogs.SetCutLineWeight(1);
                }
                catch
                {
                }

                // RELLENO DEL COLOR DEL CABLE
                if (solidFillId != null && solidFillId != ElementId.InvalidElementId)
                {
                    // Superficie / proyección
                    ogs.SetSurfaceForegroundPatternId(solidFillId);
                    ogs.SetSurfaceForegroundPatternColor(color);
                    ogs.SetSurfaceBackgroundPatternId(solidFillId);
                    ogs.SetSurfaceBackgroundPatternColor(color);

                    // Corte
                    ogs.SetCutForegroundPatternId(solidFillId);
                    ogs.SetCutForegroundPatternColor(color);
                    ogs.SetCutBackgroundPatternId(solidFillId);
                    ogs.SetCutBackgroundPatternColor(color);
                }

                // 0 = sin transparencia, para que el relleno se vea sólido
                ogs.SetSurfaceTransparency(0);

                view.SetElementOverrides(id, ogs);
            }
            catch
            {
            }
        }

        private ElementId ObtenerSolidFillPatternId(Document doc)
        {
            if (doc == null)
                return ElementId.InvalidElementId;

            try
            {
                FillPatternElement solidFill = new FilteredElementCollector(doc)
                    .OfClass(typeof(FillPatternElement))
                    .Cast<FillPatternElement>()
                    .FirstOrDefault(x =>
                    {
                        FillPattern fp = x.GetFillPattern();
                        return fp != null && fp.IsSolidFill;
                    });

                if (solidFill != null)
                    return solidFill.Id;
            }
            catch
            {
            }

            return ElementId.InvalidElementId;
        }

        private void ObtenerDimensionesBandeja(Document doc, Element e, out double ancho, out double alto)
        {
            ancho = 0.0;
            alto = 0.0;

            string[] nombresAncho = new string[] { "Anchura", "Ancho", "Width" };
            string[] nombresAlto = new string[] { "Altura", "Height" };

            foreach (string nombre in nombresAncho)
            {
                ancho = ObtenerParametroDoubleElementoOTipo(doc, e, nombre);

                if (ancho > 0)
                    break;
            }

            foreach (string nombre in nombresAlto)
            {
                alto = ObtenerParametroDoubleElementoOTipo(doc, e, nombre);

                if (alto > 0)
                    break;
            }

            if (ancho <= 0)
                ancho = MmToFeet(300.0);

            if (alto <= 0)
                alto = MmToFeet(100.0);
        }

        private double ObtenerParametroDoubleElementoOTipo(Document doc, Element e, string nombre)
        {
            if (e == null || string.IsNullOrWhiteSpace(nombre))
                return 0.0;

            Parameter p = e.LookupParameter(nombre);

            if (p != null && p.StorageType == StorageType.Double)
            {
                try
                {
                    double v = p.AsDouble();

                    if (v > 0)
                        return v;
                }
                catch
                {
                }
            }

            try
            {
                ElementId tipoId = e.GetTypeId();

                if (tipoId != null && tipoId != ElementId.InvalidElementId)
                {
                    Element tipo = doc.GetElement(tipoId);

                    if (tipo != null)
                    {
                        Parameter pt = tipo.LookupParameter(nombre);

                        if (pt != null && pt.StorageType == StorageType.Double)
                        {
                            double v = pt.AsDouble();

                            if (v > 0)
                                return v;
                        }
                    }
                }
            }
            catch
            {
            }

            return 0.0;
        }

        private List<Connector> ObtenerConectores(Element e)
        {
            List<Connector> lista = new List<Connector>();

            if (e == null)
                return lista;

            MEPCurve mepCurve = e as MEPCurve;

            if (mepCurve != null)
            {
                try
                {
                    ConnectorSet set = mepCurve.ConnectorManager.Connectors;

                    foreach (Connector c in set)
                        lista.Add(c);
                }
                catch
                {
                }

                return lista;
            }

            FamilyInstance fi = e as FamilyInstance;

            if (fi != null)
            {
                try
                {
                    if (fi.MEPModel != null && fi.MEPModel.ConnectorManager != null)
                    {
                        ConnectorSet set = fi.MEPModel.ConnectorManager.Connectors;

                        foreach (Connector c in set)
                            lista.Add(c);
                    }
                }
                catch
                {
                }

                return lista;
            }

            return lista;
        }

        private bool EsConectorValido(Connector a, Connector b)
        {
            if (a == null || b == null)
                return false;

            if (b.Owner == null)
                return false;

            try
            {
                if (a.Owner != null && a.Owner.Id.Value == b.Owner.Id.Value)
                    return false;
            }
            catch
            {
                return false;
            }

            try
            {
                if (a.ConnectorType == ConnectorType.Logical ||
                    b.ConnectorType == ConnectorType.Logical)
                    return false;
            }
            catch
            {
            }

            return true;
        }

        private bool EsBandejaCable(Element e)
        {
            if (e == null || e.Category == null)
                return false;

            try
            {
                BuiltInCategory bic = (BuiltInCategory)(int)e.Category.Id.Value;
                return bic == BuiltInCategory.OST_CableTray;
            }
            catch
            {
                return false;
            }
        }

        private bool EsAccesorioBandeja(Element e)
        {
            if (e == null || e.Category == null)
                return false;

            try
            {
                BuiltInCategory bic = (BuiltInCategory)(int)e.Category.Id.Value;
                return bic == BuiltInCategory.OST_CableTrayFitting;
            }
            catch
            {
                return false;
            }
        }

        private XYZ ObtenerDireccionPrincipal(Element e)
        {
            if (e == null)
                return XYZ.Zero;

            LocationCurve lc = e.Location as LocationCurve;

            if (lc != null && lc.Curve != null)
            {
                try
                {
                    XYZ p0 = lc.Curve.GetEndPoint(0);
                    XYZ p1 = lc.Curve.GetEndPoint(1);
                    XYZ v = p1 - p0;

                    if (!EsVectorCero(v))
                        return v.Normalize();
                }
                catch
                {
                }
            }

            List<Connector> conectores = ObtenerConectores(e);

            if (conectores.Count >= 2)
            {
                XYZ p0 = ObtenerOrigenSeguro(conectores[0]);
                XYZ p1 = ObtenerOrigenSeguro(conectores[1]);
                XYZ v = p1 - p0;

                if (!EsVectorCero(v))
                    return v.Normalize();
            }

            return XYZ.Zero;
        }

        private XYZ ObtenerCentroElemento(Element e)
        {
            if (e == null)
                return XYZ.Zero;

            LocationPoint lp = e.Location as LocationPoint;

            if (lp != null)
                return lp.Point;

            LocationCurve lc = e.Location as LocationCurve;

            if (lc != null && lc.Curve != null)
            {
                try
                {
                    return (lc.Curve.GetEndPoint(0) + lc.Curve.GetEndPoint(1)) * 0.5;
                }
                catch
                {
                }
            }

            BoundingBoxXYZ bb = null;

            try
            {
                bb = e.get_BoundingBox(null);
            }
            catch
            {
            }

            if (bb != null)
                return (bb.Min + bb.Max) * 0.5;

            return XYZ.Zero;
        }

        private XYZ ObtenerOrigenSeguro(Connector c)
        {
            if (c == null)
                return XYZ.Zero;

            try
            {
                return c.Origin;
            }
            catch
            {
                return XYZ.Zero;
            }
        }

        private XYZ ObtenerTangenteInicio(Curve curva)
        {
            if (curva == null)
                return XYZ.Zero;

            try
            {
                Transform d = curva.ComputeDerivatives(0.0, true);

                if (d != null && !EsVectorCero(d.BasisX))
                    return d.BasisX.Normalize();
            }
            catch
            {
            }

            try
            {
                XYZ p0 = curva.GetEndPoint(0);
                XYZ p1 = curva.GetEndPoint(1);
                XYZ v = p1 - p0;

                if (!EsVectorCero(v))
                    return v.Normalize();
            }
            catch
            {
            }

            return XYZ.Zero;
        }

        // =========================================================
        // V24 - BASE LOCAL FORZADA PARALELA A LA SUPERFICIE DE BANDEJA
        //
        // Problema corregido:
        // En tramos verticales o inclinados algunos cables se distribuían usando
        // el eje de profundidad/altura de la bandeja como si fuera el eje lateral.
        // Eso hacía que la serie saliera perpendicular a la superficie de apoyo.
        //
        // Criterio V24:
        // 1. El eje de recorrido siempre es la dirección real del tramo.
        // 2. El eje lateral se toma de los conectores de la bandeja cuando existe.
        //    En bandejas/codos MEP, ese eje suele conservar la orientación real
        //    de la sección, aunque el tramo esté inclinado o vertical.
        // 3. Si los conectores no dan una base clara, se usa una evaluación con
        //    el bounding box y las dimensiones Anchura/Altura.
        // 4. El eje lateral elegido debe corresponder a la anchura de la bandeja,
        //    no a su altura/profundidad.
        // 5. La vertical local queda perpendicular al recorrido y al lateral,
        //    para que las filas adicionales se apilen dentro de la sección.
        //
        // Esto mantiene el ordenamiento/continuidad existente y solo corrige la
        // base geométrica de distribución de offsets.
        // =========================================================
        private void CalcularBaseLocalDesdeBandeja(
            Document doc,
            Element bandeja,
            Curve curva,
            XYZ direccionTramo,
            out XYZ lateral,
            out XYZ vertical)
        {
            CalcularBaseLocal(direccionTramo, out lateral, out vertical);

            if (bandeja == null)
                return;

            XYZ dir = direccionTramo;

            if (EsVectorCero(dir) && curva != null)
                dir = ObtenerTangenteInicio(curva);

            if (EsVectorCero(dir))
                dir = ObtenerDireccionPrincipal(bandeja);

            if (EsVectorCero(dir))
                return;

            dir = dir.Normalize();

            double ancho;
            double alto;
            ObtenerDimensionesBandeja(doc, bandeja, out ancho, out alto);

            if (ancho <= 0.0)
                ancho = MmToFeet(300.0);

            if (alto <= 0.0)
                alto = MmToFeet(100.0);

            List<XYZ> candidatos = new List<XYZ>();

            // 1) Prioridad: ejes de conectores MEP. Son los más confiables
            // para subidas, bajadas e inclinados.
            AgregarCandidatosDesdeConectores(bandeja, dir, candidatos);

            // 2) Respaldo: base estable previa y ejes globales proyectados.
            AgregarCandidatoBase(candidatos, lateral, dir);
            AgregarCandidatoBase(candidatos, vertical, dir);
            AgregarCandidatoBase(candidatos, XYZ.BasisX, dir);
            AgregarCandidatoBase(candidatos, XYZ.BasisY, dir);
            AgregarCandidatoBase(candidatos, XYZ.BasisZ, dir);

            XYZ mejor = ElegirEjeLateralParaleloSuperficie(
                doc,
                bandeja,
                candidatos,
                dir,
                ancho,
                alto,
                lateral);

            if (EsVectorCero(mejor))
                return;

            mejor = mejor.Normalize();

            // Mantener el signo más parecido a la base previa para no invertir
            // el orden de cables entre tramos consecutivos.
            if (!EsVectorCero(lateral) && mejor.DotProduct(lateral.Normalize()) < 0.0)
                mejor = -mejor;

            XYZ nuevaVertical = dir.CrossProduct(mejor);

            if (EsVectorCero(nuevaVertical))
                return;

            nuevaVertical = nuevaVertical.Normalize();

            // En tramos horizontales se mantiene el apilamiento hacia arriba.
            // En verticales/inclinados no se fuerza Z porque la superficie puede
            // estar en otro plano.
            double componenteVertical = Math.Abs(dir.DotProduct(XYZ.BasisZ));

            if (componenteVertical < 0.60 && nuevaVertical.DotProduct(XYZ.BasisZ) < 0.0)
            {
                mejor = -mejor;
                nuevaVertical = -nuevaVertical;
            }

            lateral = mejor;
            vertical = nuevaVertical;
        }

        private void AgregarCandidatosDesdeConectores(
            Element e,
            XYZ direccionTramo,
            List<XYZ> candidatos)
        {
            if (e == null || candidatos == null)
                return;

            List<Connector> conectores = ObtenerConectores(e);

            foreach (Connector c in conectores)
            {
                if (c == null)
                    continue;

                Transform cs = null;

                try
                {
                    cs = c.CoordinateSystem;
                }
                catch
                {
                    cs = null;
                }

                if (cs == null)
                    continue;

                AgregarCandidatoBase(candidatos, cs.BasisX, direccionTramo);
                AgregarCandidatoBase(candidatos, cs.BasisY, direccionTramo);
                AgregarCandidatoBase(candidatos, cs.BasisZ, direccionTramo);
            }
        }

        private void AgregarCandidatoBase(
            List<XYZ> candidatos,
            XYZ eje,
            XYZ direccionTramo)
        {
            if (candidatos == null || EsVectorCero(eje))
                return;

            XYZ dir = direccionTramo;

            if (EsVectorCero(dir))
                dir = XYZ.BasisX;

            dir = dir.Normalize();

            XYZ candidato = eje - dir * eje.DotProduct(dir);

            if (EsVectorCero(candidato))
                return;

            candidato = candidato.Normalize();

            foreach (XYZ existente in candidatos)
            {
                if (existente == null)
                    continue;

                double paralelo = Math.Abs(existente.Normalize().DotProduct(candidato));

                if (paralelo > 0.985)
                    return;
            }

            candidatos.Add(candidato);
        }

        private XYZ ElegirEjeLateralParaleloSuperficie(
            Document doc,
            Element bandeja,
            List<XYZ> candidatos,
            XYZ direccionTramo,
            double ancho,
            double alto,
            XYZ lateralBase)
        {
            if (candidatos == null || candidatos.Count == 0)
                return lateralBase;

            BoundingBoxXYZ bb = null;

            try
            {
                bb = bandeja.get_BoundingBox(null);
            }
            catch
            {
                bb = null;
            }

            XYZ mejor = XYZ.Zero;
            double mejorScore = double.MaxValue;

            foreach (XYZ cand0 in candidatos)
            {
                if (EsVectorCero(cand0))
                    continue;

                XYZ cand = cand0.Normalize();

                if (!EsVectorCero(direccionTramo))
                {
                    double dotDir = Math.Abs(cand.DotProduct(direccionTramo.Normalize()));

                    if (dotDir > 0.10)
                        continue;
                }

                double span = ObtenerSpanEnBoundingBox(bb, cand);

                // Si no se pudo evaluar span, no se descarta; se usa un valor
                // neutro para que los conectores sigan siendo considerados.
                if (span <= 0.0)
                    span = ancho;

                // La anchura debe ser claramente mayor que la altura. Si el span
                // se parece demasiado a la altura, probablemente es profundidad.
                double errorAncho = Math.Abs(span - ancho);
                double errorAlto = Math.Abs(span - alto);

                double score = errorAncho;

                if (errorAlto < errorAncho)
                    score += ancho * 2.0;

                // Penaliza ejes cuyo span sea exageradamente grande por efectos
                // del bounding box en tramos inclinados/curvos.
                if (span > ancho * 1.80)
                    score += (span - ancho * 1.80) * 2.0;

                // Favorece continuidad con la base estable anterior.
                if (!EsVectorCero(lateralBase))
                {
                    double continuidad = Math.Abs(cand.DotProduct(lateralBase.Normalize()));
                    score -= continuidad * ancho * 0.25;
                }

                if (score < mejorScore)
                {
                    mejorScore = score;
                    mejor = cand;
                }
            }

            if (EsVectorCero(mejor))
                return lateralBase;

            return mejor.Normalize();
        }

        private double ObtenerSpanEnBoundingBox(BoundingBoxXYZ bb, XYZ eje)
        {
            if (bb == null || EsVectorCero(eje))
                return 0.0;

            XYZ a = bb.Min;
            XYZ b = bb.Max;

            XYZ[] pts = new XYZ[]
            {
                new XYZ(a.X, a.Y, a.Z),
                new XYZ(b.X, a.Y, a.Z),
                new XYZ(a.X, b.Y, a.Z),
                new XYZ(b.X, b.Y, a.Z),
                new XYZ(a.X, a.Y, b.Z),
                new XYZ(b.X, a.Y, b.Z),
                new XYZ(a.X, b.Y, b.Z),
                new XYZ(b.X, b.Y, b.Z)
            };

            XYZ u = eje.Normalize();

            double min = double.MaxValue;
            double max = double.MinValue;

            foreach (XYZ p in pts)
            {
                double d = p.DotProduct(u);

                if (d < min)
                    min = d;

                if (d > max)
                    max = d;
            }

            if (max <= min)
                return 0.0;

            return max - min;
        }

        private XYZ CanonicalizarVectorLateral(XYZ v)
        {
            if (EsVectorCero(v))
                return XYZ.BasisX;

            XYZ r = v.Normalize();

            double ax = Math.Abs(r.X);
            double ay = Math.Abs(r.Y);
            double az = Math.Abs(r.Z);

            if (ax >= ay && ax >= az)
            {
                if (r.X < 0.0)
                    r = -r;
            }
            else if (ay >= ax && ay >= az)
            {
                if (r.Y < 0.0)
                    r = -r;
            }
            else
            {
                if (r.Z < 0.0)
                    r = -r;
            }

            return r;
        }

        private void CalcularBaseLocal(XYZ direccionTramo, out XYZ lateral, out XYZ vertical)
        {
            XYZ dir = direccionTramo;

            if (EsVectorCero(dir))
                dir = XYZ.BasisX;

            dir = dir.Normalize();

            XYZ upBase = XYZ.BasisZ;

            if (Math.Abs(dir.DotProduct(upBase)) > 0.95)
                upBase = XYZ.BasisX;

            lateral = upBase.CrossProduct(dir);

            if (EsVectorCero(lateral))
                lateral = XYZ.BasisY;

            lateral = lateral.Normalize();

            vertical = dir.CrossProduct(lateral);

            if (EsVectorCero(vertical))
                vertical = XYZ.BasisZ;

            vertical = vertical.Normalize();

            if (vertical.DotProduct(XYZ.BasisZ) < 0)
                vertical = -vertical;
        }

        private XYZ ObtenerVectorPerpendicular(XYZ tangent)
        {
            if (EsVectorCero(tangent))
                return XYZ.BasisX;

            XYZ lateral;
            XYZ vertical;

            CalcularBaseLocal(tangent, out lateral, out vertical);

            if (EsVectorCero(lateral))
                lateral = XYZ.BasisX;

            return lateral.Normalize();
        }

        private double CalcularLongitudCurveLoop(CurveLoop loop)
        {
            double total = 0.0;

            if (loop == null)
                return total;

            foreach (Curve c in loop)
            {
                if (c != null)
                    total += c.Length;
            }

            return total;
        }

        private bool EsVectorCero(XYZ v)
        {
            if (v == null)
                return true;

            return v.GetLength() < 0.000001;
        }

        private double MmToFeet(double mm)
        {
            return mm / 304.8;
        }

        private double FeetToMeters(double ft)
        {
            return ft * 0.3048;
        }

        private class CableDef
        {
            public string Circuito { get; set; }
            public string NombreCircuito { get; set; }
            public string Sistema { get; set; }
            public string TipoCable { get; set; }
            public int Cantidad { get; set; }
            public double DiametroMm { get; set; }
            public Autodesk.Revit.DB.Color Color { get; set; }
        }


        // =========================================================
        // V29 - CORRECCIÓN PUNTUAL SOBRE V27
        //
        // Problema:
        // En algunos codos/curvas inclinadas quedaba un único cruce porque
        // la detección anterior podía no captarlo con suficiente fuerza.
        //
        // Criterio:
        // - Parte de V27.
        // - No toca geometría.
        // - No toca Excel, parámetros, colores ni DirectShapes.
        // - Solo intercambia offsets/carriles completos en las bandejas conectadas.
        // - Evalúa cruces con el recorrido segmentado real en 3D.
        // =========================================================
        private void ForzarCodosInclinadosSinCruce3DEstrictoV29(
            Document doc,
            Dictionary<ElementId, List<CableInstancia>> cablesPorBandeja,
            HashSet<ElementId> accesorioIds,
            HashSet<ElementId> bandejaIds)
        {
            if (doc == null || cablesPorBandeja == null || cablesPorBandeja.Count == 0)
                return;

            if (accesorioIds == null || accesorioIds.Count == 0)
                return;

            int mejorCrucesGlobal = ContarCrucesGlobalesEnAccesoriosPorRecorrido3DEstrictoV29(
                doc,
                cablesPorBandeja,
                accesorioIds,
                bandejaIds);

            if (mejorCrucesGlobal <= 0)
                return;

            double mejorPenalizacionGlobal = CalcularPenalizacionOrdenAscendente(cablesPorBandeja);

            bool huboCambio = true;
            int iteracion = 0;
            int maxIteraciones = 20;

            // OPT V35:
            // El orden de accesorios no cambia durante esta rutina.
            // Se evita ejecutar OrderBy(...).ToList() en cada iteración.
            List<ElementId> accesoriosOrdenadosV29 = accesorioIds
                .OrderBy(x => x.Value)
                .ToList();

            while (huboCambio && iteracion < maxIteraciones && mejorCrucesGlobal > 0)
            {
                iteracion++;
                huboCambio = false;

                foreach (ElementId idAcc in accesoriosOrdenadosV29)
                {
                    Element accesorio = doc.GetElement(idAcc);

                    if (accesorio == null)
                        continue;

                    List<PuertoFitting> puertos = ObtenerPuertosDeAccesorio(
                        doc,
                        accesorio,
                        cablesPorBandeja,
                        bandejaIds);

                    if (puertos == null || puertos.Count != 2)
                        continue;

                    int ambiguos;
                    List<ParCableFitting> pares = InferirParesPorIdentidad(puertos, out ambiguos);
                    pares = PrepararParesConContinuidadForzada(pares);

                    if (pares == null || pares.Count <= 1)
                        continue;

                    int crucesLocalInicial = ContarCrucesParesPorRecorrido3DEstrictoV29(pares);

                    if (crucesLocalInicial <= 0)
                        continue;

                    List<EstadoOffsetCable> estadoBase = GuardarOffsetsTodosLosCables(cablesPorBandeja);
                    List<EstadoOffsetCable> mejorEstado = GuardarOffsetsTodosLosCables(cablesPorBandeja);

                    int mejorCrucesLocal = crucesLocalInicial;
                    int mejorCrucesTotal = mejorCrucesGlobal;
                    double mejorPenalizacion = mejorPenalizacionGlobal;

                    PuertoFitting puertoA = puertos[0];
                    PuertoFitting puertoB = puertos[1];

                    // 1) Prueba ordenar el puerto B según el puerto A, normal e invertido.
                    for (int invertir = 0; invertir <= 1; invertir++)
                    {
                        RestaurarOffsetsTodosLosCables(estadoBase);

                        AplicarOrdenDeUnPuertoEnOtroPorCableKey(
                            pares,
                            puertoA,
                            puertoB,
                            invertir == 1);

                        int local = ContarCrucesAccesorio3DEstrictoV29(
                            doc,
                            idAcc,
                            cablesPorBandeja,
                            bandejaIds);

                        int total = ContarCrucesGlobalesEnAccesoriosPorRecorrido3DEstrictoV29(
                            doc,
                            cablesPorBandeja,
                            accesorioIds,
                            bandejaIds);

                        double penalizacion = CalcularPenalizacionOrdenAscendente(cablesPorBandeja);

                        if (EsMejorEstadoCrucesV29(
                            local,
                            total,
                            penalizacion,
                            mejorCrucesLocal,
                            mejorCrucesTotal,
                            mejorPenalizacion))
                        {
                            mejorCrucesLocal = local;
                            mejorCrucesTotal = total;
                            mejorPenalizacion = penalizacion;
                            mejorEstado = GuardarOffsetsTodosLosCables(cablesPorBandeja);
                        }
                    }

                    // 2) Prueba ordenar el puerto A según el puerto B, normal e invertido.
                    for (int invertir = 0; invertir <= 1; invertir++)
                    {
                        RestaurarOffsetsTodosLosCables(estadoBase);

                        AplicarOrdenDeUnPuertoEnOtroPorCableKey(
                            pares,
                            puertoB,
                            puertoA,
                            invertir == 1);

                        int local = ContarCrucesAccesorio3DEstrictoV29(
                            doc,
                            idAcc,
                            cablesPorBandeja,
                            bandejaIds);

                        int total = ContarCrucesGlobalesEnAccesoriosPorRecorrido3DEstrictoV29(
                            doc,
                            cablesPorBandeja,
                            accesorioIds,
                            bandejaIds);

                        double penalizacion = CalcularPenalizacionOrdenAscendente(cablesPorBandeja);

                        if (EsMejorEstadoCrucesV29(
                            local,
                            total,
                            penalizacion,
                            mejorCrucesLocal,
                            mejorCrucesTotal,
                            mejorPenalizacion))
                        {
                            mejorCrucesLocal = local;
                            mejorCrucesTotal = total;
                            mejorPenalizacion = penalizacion;
                            mejorEstado = GuardarOffsetsTodosLosCables(cablesPorBandeja);
                        }
                    }

                    // 3) Si aún queda cruce, prueba swaps de carril completos en las 2 bandejas conectadas.
                    RestaurarOffsetsTodosLosCables(mejorEstado);

                    bool cambioLocal = true;
                    int iterLocal = 0;

                    while (cambioLocal && iterLocal < 8 && mejorCrucesLocal > 0)
                    {
                        iterLocal++;
                        cambioLocal = false;

                        foreach (PuertoFitting puerto in puertos)
                        {
                            if (puerto == null || puerto.BandejaId == null)
                                continue;

                            if (!cablesPorBandeja.ContainsKey(puerto.BandejaId))
                                continue;

                            List<CableInstancia> cables = ObtenerCablesOrdenadosPorCarril(
                                cablesPorBandeja[puerto.BandejaId]);

                            if (cables == null || cables.Count <= 1)
                                continue;

                            int limite = Math.Min(cables.Count, 120);

                            for (int i = 0; i < limite; i++)
                            {
                                for (int j = i + 1; j < limite; j++)
                                {
                                    CableInstancia ca = cables[i];
                                    CableInstancia cb = cables[j];

                                    if (ca == null || cb == null)
                                        continue;

                                    XYZ offA = ca.Offset;
                                    XYZ offB = cb.Offset;

                                    ca.Offset = offB;
                                    cb.Offset = offA;

                                    int local = ContarCrucesAccesorio3DEstrictoV29(
                                        doc,
                                        idAcc,
                                        cablesPorBandeja,
                                        bandejaIds);

                                    int total = ContarCrucesGlobalesEnAccesoriosPorRecorrido3DEstrictoV29(
                                        doc,
                                        cablesPorBandeja,
                                        accesorioIds,
                                        bandejaIds);

                                    double penalizacion = CalcularPenalizacionOrdenAscendente(cablesPorBandeja);

                                    if (EsMejorEstadoCrucesV29(
                                        local,
                                        total,
                                        penalizacion,
                                        mejorCrucesLocal,
                                        mejorCrucesTotal,
                                        mejorPenalizacion))
                                    {
                                        mejorCrucesLocal = local;
                                        mejorCrucesTotal = total;
                                        mejorPenalizacion = penalizacion;
                                        mejorEstado = GuardarOffsetsTodosLosCables(cablesPorBandeja);
                                        cambioLocal = true;
                                        huboCambio = true;

                                        if (mejorCrucesLocal <= 0)
                                            break;
                                    }
                                    else
                                    {
                                        ca.Offset = offA;
                                        cb.Offset = offB;
                                    }
                                }

                                if (mejorCrucesLocal <= 0)
                                    break;
                            }
                        }
                    }

                    if (mejorCrucesLocal < crucesLocalInicial)
                    {
                        RestaurarOffsetsTodosLosCables(mejorEstado);
                        mejorCrucesGlobal = mejorCrucesTotal;
                        mejorPenalizacionGlobal = mejorPenalizacion;
                        huboCambio = true;

                        if (mejorCrucesGlobal <= 0)
                            return;
                    }
                    else
                    {
                        RestaurarOffsetsTodosLosCables(estadoBase);
                    }
                }
            }
        }

        private bool EsMejorEstadoCrucesV29(
            int localNuevo,
            int totalNuevo,
            double penalizacionNueva,
            int localActual,
            int totalActual,
            double penalizacionActual)
        {
            if (localNuevo < localActual)
                return true;

            if (localNuevo > localActual)
                return false;

            if (totalNuevo < totalActual)
                return true;

            if (totalNuevo > totalActual)
                return false;

            return penalizacionNueva < penalizacionActual;
        }

        private int ContarCrucesGlobalesEnAccesoriosPorRecorrido3DEstrictoV29(
            Document doc,
            Dictionary<ElementId, List<CableInstancia>> cablesPorBandeja,
            HashSet<ElementId> accesorioIds,
            HashSet<ElementId> bandejaIds)
        {
            if (doc == null || accesorioIds == null || cablesPorBandeja == null)
                return 0;

            int total = 0;

            foreach (ElementId idAcc in accesorioIds)
            {
                total += ContarCrucesAccesorio3DEstrictoV29(
                    doc,
                    idAcc,
                    cablesPorBandeja,
                    bandejaIds);
            }

            return total;
        }

        private int ContarCrucesAccesorio3DEstrictoV29(
            Document doc,
            ElementId idAccesorio,
            Dictionary<ElementId, List<CableInstancia>> cablesPorBandeja,
            HashSet<ElementId> bandejaIds)
        {
            if (doc == null || idAccesorio == null || cablesPorBandeja == null)
                return 0;

            Element accesorio = doc.GetElement(idAccesorio);

            if (accesorio == null)
                return 0;

            List<PuertoFitting> puertos = ObtenerPuertosDeAccesorio(
                doc,
                accesorio,
                cablesPorBandeja,
                bandejaIds);

            if (puertos == null || puertos.Count < 2)
                return 0;

            int ambiguos;
            List<ParCableFitting> pares = InferirParesPorIdentidad(puertos, out ambiguos);
            pares = PrepararParesConContinuidadForzada(pares);

            return ContarCrucesParesPorRecorrido3DEstrictoV29(pares);
        }

        private int ContarCrucesParesPorRecorrido3DEstrictoV29(
            List<ParCableFitting> pares)
        {
            if (pares == null || pares.Count <= 1)
                return 0;

            List<List<XYZ>> rutas = new List<List<XYZ>>();

            foreach (ParCableFitting par in pares)
            {
                if (par == null || par.A == null || par.B == null)
                {
                    rutas.Add(new List<XYZ>());
                    continue;
                }

                XYZ pInicio = par.A.Punto + ObtenerOffsetPar(par, true);
                XYZ pFin = par.B.Punto + ObtenerOffsetPar(par, false);

                List<XYZ> ruta = CrearPuntosRecorridoAccesorioV10(
                    pInicio,
                    par.A.DireccionHaciaInterior,
                    pFin,
                    par.B.DireccionHaciaInterior);

                rutas.Add(ruta);
            }

            int cruces = 0;

            for (int i = 0; i < rutas.Count; i++)
            {
                for (int j = i + 1; j < rutas.Count; j++)
                {
                    if (RutasCruzadas3DEstrictoV29(rutas[i], rutas[j]))
                        cruces++;
                }
            }

            return cruces;
        }

        private bool RutasCruzadas3DEstrictoV29(
            List<XYZ> rutaA,
            List<XYZ> rutaB)
        {
            if (rutaA == null || rutaB == null || rutaA.Count < 2 || rutaB.Count < 2)
                return false;

            double toleranciaDistancia = MmToFeet(1.5);
            double toleranciaSegmento = MmToFeet(0.5);

            for (int i = 0; i < rutaA.Count - 1; i++)
            {
                XYZ a0 = rutaA[i];
                XYZ a1 = rutaA[i + 1];

                if (a0 == null || a1 == null)
                    continue;

                XYZ va = a1 - a0;

                if (EsVectorCero(va) || va.GetLength() < toleranciaSegmento)
                    continue;

                XYZ da = va.Normalize();

                for (int j = 0; j < rutaB.Count - 1; j++)
                {
                    XYZ b0 = rutaB[j];
                    XYZ b1 = rutaB[j + 1];

                    if (b0 == null || b1 == null)
                        continue;

                    XYZ vb = b1 - b0;

                    if (EsVectorCero(vb) || vb.GetLength() < toleranciaSegmento)
                        continue;

                    XYZ db = vb.Normalize();

                    // Si son casi paralelos, no se considera cruce;
                    // pueden ser cables vecinos dentro de la misma bandeja.
                    double anguloCruz = da.CrossProduct(db).GetLength();

                    if (anguloCruz < 0.08)
                        continue;

                    double distancia = DistanciaMinimaSegmentos3DV29(a0, a1, b0, b1);

                    if (distancia <= toleranciaDistancia)
                        return true;
                }
            }

            return false;
        }

        private double DistanciaMinimaSegmentos3DV29(
            XYZ p1,
            XYZ q1,
            XYZ p2,
            XYZ q2)
        {
            XYZ d1 = q1 - p1;
            XYZ d2 = q2 - p2;
            XYZ r = p1 - p2;

            double a = d1.DotProduct(d1);
            double e = d2.DotProduct(d2);
            double f = d2.DotProduct(r);

            double s;
            double t;

            double eps = 0.000000001;

            if (a <= eps && e <= eps)
                return p1.DistanceTo(p2);

            if (a <= eps)
            {
                s = 0.0;
                t = Clamp01V29(f / e);
            }
            else
            {
                double c = d1.DotProduct(r);

                if (e <= eps)
                {
                    t = 0.0;
                    s = Clamp01V29(-c / a);
                }
                else
                {
                    double b = d1.DotProduct(d2);
                    double denom = a * e - b * b;

                    if (Math.Abs(denom) > eps)
                        s = Clamp01V29((b * f - c * e) / denom);
                    else
                        s = 0.0;

                    t = (b * s + f) / e;

                    if (t < 0.0)
                    {
                        t = 0.0;
                        s = Clamp01V29(-c / a);
                    }
                    else if (t > 1.0)
                    {
                        t = 1.0;
                        s = Clamp01V29((b - c) / a);
                    }
                }
            }

            XYZ c1 = p1 + d1 * s;
            XYZ c2 = p2 + d2 * t;

            return c1.DistanceTo(c2);
        }

        private double Clamp01V29(double v)
        {
            if (v < 0.0)
                return 0.0;

            if (v > 1.0)
                return 1.0;

            return v;
        }


        private class CableInstancia
        {
            public string Key { get; set; }
            public string Circuito { get; set; }
            public string NombreCircuito { get; set; }
            public string Sistema { get; set; }
            public string TipoCable { get; set; }
            public double DiametroMm { get; set; }
            public Autodesk.Revit.DB.Color Color { get; set; }
            public int IndiceEnTipo { get; set; }
            public int CantidadTipo { get; set; }
            public int Orden { get; set; }
            public ElementId BandejaId { get; set; }
            public XYZ Offset { get; set; }
            public XYZ DireccionBandeja { get; set; }
            public XYZ VectorLateral { get; set; }
            public XYZ VectorVertical { get; set; }
        }

        private class PuertoFitting
        {
            public ElementId BandejaId { get; set; }
            public XYZ Punto { get; set; }
            public XYZ DireccionDesdeCentro { get; set; }
            public XYZ DireccionHaciaInterior { get; set; }
            public List<CableInstancia> Cables { get; set; }
        }

        private class CableEnPuerto
        {
            public PuertoFitting Puerto { get; set; }
            public CableInstancia Cable { get; set; }
        }

        private class ParCableFitting
        {
            public PuertoFitting A { get; set; }
            public CableInstancia CableA { get; set; }
            public PuertoFitting B { get; set; }
            public CableInstancia CableB { get; set; }

            // V11: offsets gráficos asignados solo para el accesorio.
            // No modifican el orden ni la información del cable en el tramo recto.
            public bool TieneOffsetA { get; set; }
            public XYZ OffsetA { get; set; }
            public bool TieneOffsetB { get; set; }
            public XYZ OffsetB { get; set; }
        }

        private class LadoParPuerto
        {
            public ParCableFitting Par { get; set; }
            public bool EsA { get; set; }
            public PuertoFitting Puerto { get; set; }
            public PuertoFitting OtroPuerto { get; set; }
            public CableInstancia Cable { get; set; }
        }


        private class EstadoOffsetCable
        {
            public CableInstancia Cable { get; set; }
            public XYZ Offset { get; set; }
        }

        private class EstadoOffsetPar
        {
            public ParCableFitting Par { get; set; }
            public bool EsA { get; set; }
            public bool TieneOffset { get; set; }
            public XYZ Offset { get; set; }
        }

        private class ElementIdComparer : IEqualityComparer<ElementId>
        {
            public bool Equals(ElementId x, ElementId y)
            {
                if (x == null && y == null)
                    return true;

                if (x == null || y == null)
                    return false;

                return x.Value == y.Value;
            }

            public int GetHashCode(ElementId obj)
            {
                if (obj == null)
                    return 0;

                return obj.Value.GetHashCode();
            }
        }

        private class FiltroBandejaCableYAccesorio : ISelectionFilter
        {
            public bool AllowElement(Element elem)
            {
                if (elem == null || elem.Category == null)
                    return false;

                try
                {
                    BuiltInCategory bic = (BuiltInCategory)(int)elem.Category.Id.Value;

                    if (bic == BuiltInCategory.OST_CableTray)
                        return true;

                    if (bic == BuiltInCategory.OST_CableTrayFitting)
                        return true;
                }
                catch
                {
                    return false;
                }

                return false;
            }

            public bool AllowReference(Reference reference, XYZ position)
            {
                return false;
            }
        }
    }
}
