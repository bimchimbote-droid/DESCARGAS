using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{


    // =====================================
    // VENTANA 5.3 - CABLES DIRECTSHAPE EN BANDEJAS CON EXCEL
    // =====================================

    public class EleCablesDirectShapeForm : System.Windows.Forms.Form
    {
        private readonly EjecutarEleCablesDirectShapeHandler _handler;
        private readonly Autodesk.Revit.UI.ExternalEvent _externalEvent;

        private System.Collections.Generic.List<Autodesk.Revit.DB.ElementId> elementosIds;

        private System.Windows.Forms.Button btnSeleccionar;
        private System.Windows.Forms.Button btnBuscarExcel;
        private System.Windows.Forms.Button btnGenerar;
        private System.Windows.Forms.Button btnBorrar;

        private System.Windows.Forms.ListBox lstElementos;
        private System.Windows.Forms.RichTextBox txtResultado;

        private System.Windows.Forms.TextBox txtRutaExcel;
        private System.Windows.Forms.TextBox txtParametroCircuitos;
        private System.Windows.Forms.TextBox txtParametroNCables;

        private System.Windows.Forms.NumericUpDown nudDiametroMmDefault;
        private System.Windows.Forms.NumericUpDown nudSeparacionMm;
        private System.Windows.Forms.NumericUpDown nudMargenLateralMm;
        private System.Windows.Forms.NumericUpDown nudMargenFondoMm;
        private System.Windows.Forms.NumericUpDown nudMaxCables;

        private System.Windows.Forms.CheckBox chkCrearRectos;
        private System.Windows.Forms.CheckBox chkCrearUniones;
        private System.Windows.Forms.CheckBox chkActualizarNCables;
        private System.Windows.Forms.CheckBox chkBorrarAnteriores;
        private System.Windows.Forms.CheckBox chkSeleccionarResultado;
        private System.Windows.Forms.CheckBox chkForzarRutasAmbiguas;

        public EleCablesDirectShapeForm(
            EjecutarEleCablesDirectShapeHandler handler,
            Autodesk.Revit.UI.ExternalEvent externalEvent)
        {
            _handler = handler;
            _externalEvent = externalEvent;

            elementosIds = new System.Collections.Generic.List<Autodesk.Revit.DB.ElementId>();

            this.Text = "MEP 5.3 - Cables DirectShape por Circuitos";
            this.Width = 760;
            this.Height = 820;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = true;
            this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;

            InicializarComponentes();
        }

        private void InicializarComponentes()
        {
            System.Windows.Forms.Label lblAutor = new System.Windows.Forms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  MEP - Cables DirectShape por Circuitos",
                Left = 20,
                Top = 10,
                Width = 700,
                Height = 20,
                Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.Gray
            };

            System.Windows.Forms.Label lblTitulo = new System.Windows.Forms.Label()
            {
                Text = "01. SELECCIÓN DE BANDEJAS Y ACCESORIOS",
                Left = 20,
                Top = 42,
                Width = 700,
                Height = 22,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            System.Windows.Forms.Label lblInfo = new System.Windows.Forms.Label()
            {
                Text = "Selecciona solo las bandejas y accesorios donde quieres crear cables. Cada tramo debe tener el parámetro ELE_Circuitos.",
                Left = 20,
                Top = 68,
                Width = 700,
                Height = 34,
                ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
            };

            btnSeleccionar = CrearBoton(
                "SELECCIONAR BANDEJAS",
                20,
                110,
                210,
                System.Drawing.Color.FromArgb(90, 90, 90));

            lstElementos = new System.Windows.Forms.ListBox()
            {
                Left = 250,
                Top = 108,
                Width = 460,
                Height = 88,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                BackColor = System.Drawing.Color.White
            };

            System.Windows.Forms.Label lblExcel = new System.Windows.Forms.Label()
            {
                Text = "02. EXCEL MAESTRO DE CIRCUITOS",
                Left = 20,
                Top = 214,
                Width = 700,
                Height = 22,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            System.Windows.Forms.Label lblRuta = new System.Windows.Forms.Label()
            {
                Text = "Ruta Excel:",
                Left = 20,
                Top = 250,
                Width = 90,
                Height = 22
            };

            txtRutaExcel = new System.Windows.Forms.TextBox()
            {
                Left = 110,
                Top = 247,
                Width = 470,
                Height = 24,
                Text = "",
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            };

            btnBuscarExcel = CrearBoton(
                "BUSCAR EXCEL",
                595,
                244,
                115,
                System.Drawing.Color.FromArgb(0, 120, 215));

            System.Windows.Forms.Label lblConfig = new System.Windows.Forms.Label()
            {
                Text = "03. PARÁMETROS DE REVIT",
                Left = 20,
                Top = 292,
                Width = 700,
                Height = 22,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            System.Windows.Forms.Label lblParametroCircuitos = new System.Windows.Forms.Label()
            {
                Text = "Parámetro circuitos:",
                Left = 20,
                Top = 328,
                Width = 155,
                Height = 22
            };

            txtParametroCircuitos = new System.Windows.Forms.TextBox()
            {
                Left = 180,
                Top = 325,
                Width = 210,
                Height = 24,
                Text = "ELE_Circuitos",
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            };

            System.Windows.Forms.Label lblParametroNCables = new System.Windows.Forms.Label()
            {
                Text = "Parámetro N° cables:",
                Left = 415,
                Top = 328,
                Width = 150,
                Height = 22
            };

            txtParametroNCables = new System.Windows.Forms.TextBox()
            {
                Left = 565,
                Top = 325,
                Width = 145,
                Height = 24,
                Text = "ELE_N°Cables",
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            };

            chkActualizarNCables = new System.Windows.Forms.CheckBox()
            {
                Text = "Actualizar ELE_N°Cables automáticamente según Excel",
                Left = 20,
                Top = 360,
                Width = 450,
                Height = 24,
                Checked = true
            };

            System.Windows.Forms.Label lblConfigCable = new System.Windows.Forms.Label()
            {
                Text = "04. CONFIGURACIÓN GRÁFICA DE CABLES",
                Left = 20,
                Top = 402,
                Width = 700,
                Height = 22,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            System.Windows.Forms.Label lblDiametro = new System.Windows.Forms.Label()
            {
                Text = "Diámetro default (mm):",
                Left = 20,
                Top = 438,
                Width = 165,
                Height = 22
            };

            nudDiametroMmDefault = new System.Windows.Forms.NumericUpDown()
            {
                Left = 190,
                Top = 435,
                Width = 75,
                Height = 24,
                DecimalPlaces = 1,
                Increment = 0.5M,
                Minimum = 1,
                Maximum = 100,
                Value = 10
            };

            System.Windows.Forms.Label lblSeparacion = new System.Windows.Forms.Label()
            {
                Text = "Separación (mm):",
                Left = 295,
                Top = 438,
                Width = 125,
                Height = 22
            };

            nudSeparacionMm = new System.Windows.Forms.NumericUpDown()
            {
                Left = 425,
                Top = 435,
                Width = 75,
                Height = 24,
                DecimalPlaces = 1,
                Increment = 0.5M,
                Minimum = 0,
                Maximum = 100,
                Value = 3
            };

            System.Windows.Forms.Label lblMax = new System.Windows.Forms.Label()
            {
                Text = "Máx/tramo:",
                Left = 530,
                Top = 438,
                Width = 80,
                Height = 22
            };

            nudMaxCables = new System.Windows.Forms.NumericUpDown()
            {
                Left = 615,
                Top = 435,
                Width = 75,
                Height = 24,
                Minimum = 1,
                Maximum = 500,
                Value = 120
            };

            System.Windows.Forms.Label lblMargenLat = new System.Windows.Forms.Label()
            {
                Text = "Margen lateral (mm):",
                Left = 20,
                Top = 474,
                Width = 165,
                Height = 22
            };

            nudMargenLateralMm = new System.Windows.Forms.NumericUpDown()
            {
                Left = 190,
                Top = 471,
                Width = 75,
                Height = 24,
                DecimalPlaces = 1,
                Increment = 1,
                Minimum = 0,
                Maximum = 300,
                Value = 15
            };

            System.Windows.Forms.Label lblMargenFondo = new System.Windows.Forms.Label()
            {
                Text = "Margen fondo (mm):",
                Left = 295,
                Top = 474,
                Width = 130,
                Height = 22
            };

            nudMargenFondoMm = new System.Windows.Forms.NumericUpDown()
            {
                Left = 425,
                Top = 471,
                Width = 75,
                Height = 24,
                DecimalPlaces = 1,
                Increment = 1,
                Minimum = 0,
                Maximum = 300,
                Value = 15
            };

            System.Windows.Forms.Label lblOpciones = new System.Windows.Forms.Label()
            {
                Text = "05. OPCIONES DE GENERACIÓN",
                Left = 20,
                Top = 516,
                Width = 700,
                Height = 22,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            chkCrearRectos = new System.Windows.Forms.CheckBox()
            {
                Text = "Crear cables en tramos rectos",
                Left = 20,
                Top = 548,
                Width = 250,
                Height = 24,
                Checked = true
            };

            chkCrearUniones = new System.Windows.Forms.CheckBox()
            {
                Text = "Crear continuidad en curvas / T / accesorios seleccionados",
                Left = 300,
                Top = 548,
                Width = 410,
                Height = 24,
                Checked = true
            };

            chkForzarRutasAmbiguas = new System.Windows.Forms.CheckBox()
            {
                Text = "Resolver rutas ambiguas por aproximación",
                Left = 20,
                Top = 576,
                Width = 330,
                Height = 24,
                Checked = true
            };

            chkBorrarAnteriores = new System.Windows.Forms.CheckBox()
            {
                Text = "Borrar DirectShape anteriores de esta herramienta",
                Left = 20,
                Top = 604,
                Width = 360,
                Height = 24,
                Checked = true
            };

            chkSeleccionarResultado = new System.Windows.Forms.CheckBox()
            {
                Text = "Seleccionar DirectShape creados en Revit",
                Left = 390,
                Top = 604,
                Width = 300,
                Height = 24,
                Checked = true
            };

            System.Windows.Forms.Label lblResultado = new System.Windows.Forms.Label()
            {
                Text = "06. RESULTADO",
                Left = 20,
                Top = 638,
                Width = 700,
                Height = 22,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            txtResultado = new System.Windows.Forms.RichTextBox()
            {
                Left = 20,
                Top = 665,
                Width = 690,
                Height = 55,
                ReadOnly = true,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                BackColor = System.Drawing.Color.White,
                Font = new System.Drawing.Font("Consolas", 8.5F),
                WordWrap = false,
                ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
            };

            btnBorrar = CrearBoton(
                "BORRAR DIRECTSHAPE",
                130,
                730,
                220,
                System.Drawing.Color.FromArgb(160, 55, 55));

            btnGenerar = CrearBoton(
                "GENERAR CABLES",
                390,
                730,
                240,
                System.Drawing.Color.FromArgb(0, 120, 215));

            btnBorrar.Height = 38;
            btnGenerar.Height = 38;

            btnSeleccionar.Click += (s, e) => Ejecutar(EleCablesDSRequest.SeleccionarBandejas);
            btnBuscarExcel.Click += (s, e) => BuscarExcel();
            btnBorrar.Click += (s, e) => Ejecutar(EleCablesDSRequest.BorrarDirectShape);
            btnGenerar.Click += (s, e) => EjecutarGeneracion();

            this.Controls.Add(lblAutor);
            this.Controls.Add(lblTitulo);
            this.Controls.Add(lblInfo);
            this.Controls.Add(btnSeleccionar);
            this.Controls.Add(lstElementos);

            this.Controls.Add(lblExcel);
            this.Controls.Add(lblRuta);
            this.Controls.Add(txtRutaExcel);
            this.Controls.Add(btnBuscarExcel);

            this.Controls.Add(lblConfig);
            this.Controls.Add(lblParametroCircuitos);
            this.Controls.Add(txtParametroCircuitos);
            this.Controls.Add(lblParametroNCables);
            this.Controls.Add(txtParametroNCables);
            this.Controls.Add(chkActualizarNCables);

            this.Controls.Add(lblConfigCable);
            this.Controls.Add(lblDiametro);
            this.Controls.Add(nudDiametroMmDefault);
            this.Controls.Add(lblSeparacion);
            this.Controls.Add(nudSeparacionMm);
            this.Controls.Add(lblMax);
            this.Controls.Add(nudMaxCables);
            this.Controls.Add(lblMargenLat);
            this.Controls.Add(nudMargenLateralMm);
            this.Controls.Add(lblMargenFondo);
            this.Controls.Add(nudMargenFondoMm);

            this.Controls.Add(lblOpciones);
            this.Controls.Add(chkCrearRectos);
            this.Controls.Add(chkCrearUniones);
            this.Controls.Add(chkForzarRutasAmbiguas);
            this.Controls.Add(chkBorrarAnteriores);
            this.Controls.Add(chkSeleccionarResultado);

            this.Controls.Add(lblResultado);
            this.Controls.Add(txtResultado);
            this.Controls.Add(btnBorrar);
            this.Controls.Add(btnGenerar);

            MostrarResultado("Carga el Excel maestro y selecciona bandejas/accesorios.");
        }

        private System.Windows.Forms.Button CrearBoton(
            string texto,
            int left,
            int top,
            int width,
            System.Drawing.Color color)
        {
            System.Windows.Forms.Button boton = new System.Windows.Forms.Button()
            {
                Text = texto,
                Left = left,
                Top = top,
                Width = width,
                Height = 32,
                BackColor = color,
                ForeColor = System.Drawing.Color.White,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                Cursor = System.Windows.Forms.Cursors.Hand
            };

            boton.FlatAppearance.BorderSize = 0;
            boton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(
                System.Math.Max(color.R - 15, 0),
                System.Math.Max(color.G - 15, 0),
                System.Math.Max(color.B - 15, 0));

            return boton;
        }

        private void BuscarExcel()
        {
            using (System.Windows.Forms.OpenFileDialog ofd = new System.Windows.Forms.OpenFileDialog())
            {
                ofd.Title = "Seleccionar Excel maestro de circuitos";
                ofd.Filter = "Archivos Excel (*.xlsx)|*.xlsx";
                ofd.Multiselect = false;

                if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    txtRutaExcel.Text = ofd.FileName;
                    MostrarResultado("Excel seleccionado: " + ofd.FileName);
                }
            }
        }

        private void Ejecutar(EleCablesDSRequest request)
        {
            _handler.Request = request;

            if (_externalEvent == null)
            {
                MostrarResultado("No se pudo crear el evento externo de Revit.");
                return;
            }

            _externalEvent.Raise();
        }

        private void EjecutarGeneracion()
        {
            if (elementosIds == null || elementosIds.Count == 0)
            {
                System.Windows.Forms.MessageBox.Show(
                    "Primero debes seleccionar las bandejas y/o accesorios.",
                    "MYG",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtRutaExcel.Text) ||
                !System.IO.File.Exists(txtRutaExcel.Text))
            {
                System.Windows.Forms.MessageBox.Show(
                    "Selecciona un Excel maestro válido.",
                    "MYG",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Warning);
                return;
            }

            _handler.ElementosIds = new System.Collections.Generic.List<Autodesk.Revit.DB.ElementId>(elementosIds);

            _handler.RutaExcelCircuitos = ObtenerTexto(txtRutaExcel.Text, "");
            _handler.ParametroCircuitos = ObtenerTexto(txtParametroCircuitos.Text, "ELE_Circuitos");
            _handler.ParametroNCables = ObtenerTexto(txtParametroNCables.Text, "ELE_N°Cables");

            _handler.DiametroCableMmDefault = (double)nudDiametroMmDefault.Value;
            _handler.SeparacionCableMm = (double)nudSeparacionMm.Value;
            _handler.MargenLateralMm = (double)nudMargenLateralMm.Value;
            _handler.MargenFondoMm = (double)nudMargenFondoMm.Value;
            _handler.MaxCablesPorElemento = (int)nudMaxCables.Value;

            _handler.CrearTramosRectos = chkCrearRectos.Checked;
            _handler.CrearCurvasEnUniones = chkCrearUniones.Checked;
            _handler.ActualizarParametroNCables = chkActualizarNCables.Checked;
            _handler.BorrarAnteriores = chkBorrarAnteriores.Checked;
            _handler.SeleccionarResultado = chkSeleccionarResultado.Checked;
            _handler.ForzarRutasAmbiguas = chkForzarRutasAmbiguas.Checked;

            Ejecutar(EleCablesDSRequest.GenerarDirectShape);
        }

        public void SetElementosSeleccionados(
            System.Collections.Generic.List<Autodesk.Revit.DB.Element> elementos)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new System.Action(() => SetElementosSeleccionados(elementos)));
                return;
            }

            elementosIds.Clear();
            lstElementos.Items.Clear();

            if (elementos != null)
            {
                foreach (Autodesk.Revit.DB.Element e in elementos)
                {
                    if (e == null)
                        continue;

                    if (e.Id == Autodesk.Revit.DB.ElementId.InvalidElementId)
                        continue;

                    elementosIds.Add(e.Id);

                    string categoria = "";
                    try
                    {
                        if (e.Category != null)
                            categoria = e.Category.Name;
                    }
                    catch
                    {
                    }

                    lstElementos.Items.Add(e.Id.Value + " - " + categoria + " - " + e.Name);
                }
            }

            MostrarResultado("Elementos seleccionados: " + elementosIds.Count);
        }

        public void MostrarResultado(string texto)
        {
            if (txtResultado == null || txtResultado.IsDisposed)
                return;

            if (this.InvokeRequired)
            {
                this.BeginInvoke(new System.Action(() => MostrarResultado(texto)));
                return;
            }

            txtResultado.Clear();
            txtResultado.SelectionColor = System.Drawing.Color.FromArgb(50, 50, 50);
            txtResultado.AppendText(texto ?? "");
            txtResultado.SelectionStart = 0;
            txtResultado.ScrollToCaret();
        }

        public void AgregarResultado(string texto)
        {
            if (txtResultado == null || txtResultado.IsDisposed)
                return;

            if (this.InvokeRequired)
            {
                this.BeginInvoke(new System.Action(() => AgregarResultado(texto)));
                return;
            }

            txtResultado.AppendText("\r\n" + (texto ?? ""));
            txtResultado.SelectionStart = txtResultado.TextLength;
            txtResultado.ScrollToCaret();
        }

        private static string ObtenerTexto(string texto, string defecto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return defecto;

            return texto.Trim();
        }
    }

}
