﻿using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;

namespace MYG_Addin
{
    // ============================================================
    // EXTERNAL EVENT HANDLER 5.8
    // INFORMACIÓN CABLES CIRCUITO - V21 CIERRE RESTAURA VISTA
    //
    // OBJETIVO:
    // Partiendo de 2 elementos MEP seleccionados, encontrar la
    // canalización modelada que los une y marcar:
    //
    // - Conduits / tubos rígidos
    // - Accesorios de conduit
    // - Tubos flexibles nativos (FlexPipe)
    // - Conductos flexibles nativos (FlexDuct), si se usaron como canalización
    // - Bandejas / accesorios de bandeja
    // - Cajas / dispositivos intermedios con 2 o más conectores
    //
    // Esta versión NO compara todos los sólidos entre sí.
    // Recorre la red por CONNECTORS, por lo que evita el bloqueo
    // de las versiones anteriores en modelos grandes.
    // ============================================================
    public class InformacionCablesCircuitoExternalEventHandler : IExternalEventHandler
    {
        public UIDocument UiDoc { get; set; }

        internal MYG_InformacionCablesCircuito58.InformacionCablesCircuitoForm Form
        {
            get;
            set;
        }

        // Vista donde MYG activó Propiedades de vista temporal.
        // Se conserva durante toda la vida de esta ventana modeless.
        private ElementId _vistaTemporalControlId =
            ElementId.InvalidElementId;

        // Permite distinguir si el modo temporal fue activado por MYG
        // o si ya estaba activo antes de abrir/usar la herramienta.
        private bool _modoTemporalActivadoPorMYG =
            false;

        // ============================================================
        // CONTROL VISUAL TEMPORAL
        // ============================================================
        // NO se crea ninguna vista nueva.
        //
        // En la primera ejecución se activa Temporary View Properties
        // sobre la vista ACTUAL y se aplica temporalmente un filtro de
        // Visibility/Graphics basado en el parámetro Comentarios.
        //
        // En las siguientes ejecuciones solo se marca Comentarios en
        // los nuevos elementos del recorrido y el mismo filtro los
        // colorea automáticamente.
        // ============================================================
        private const string NombreFiltroControlTemporal =
            "MYG_TEMP_CABLES_PROCESADOS";

        private const string ValorComentarioProcesado =
            "MYG_CABLES_PROCESADO";

        // Canalizaciones principales.
        private static readonly BuiltInCategory[] CategoriasCanalizacion =
        {
            BuiltInCategory.OST_Conduit,
            BuiltInCategory.OST_ConduitFitting,
            BuiltInCategory.OST_CableTray,
            BuiltInCategory.OST_CableTrayFitting
        };

        // Categorías que pueden ser seleccionadas como A / B
        // y que además pueden actuar como "caja puente" cuando
        // poseen 2 o más conectores físicos.
        private static readonly BuiltInCategory[] CategoriasDispositivos =
        {
            BuiltInCategory.OST_ElectricalEquipment,
            BuiltInCategory.OST_ElectricalFixtures,
            BuiltInCategory.OST_CommunicationDevices,
            BuiltInCategory.OST_DataDevices,
            BuiltInCategory.OST_FireAlarmDevices,
            BuiltInCategory.OST_LightingDevices,
            BuiltInCategory.OST_LightingFixtures,
            BuiltInCategory.OST_NurseCallDevices,
            BuiltInCategory.OST_SecurityDevices,
            BuiltInCategory.OST_TelephoneDevices,
            BuiltInCategory.OST_MechanicalEquipment
        };

        public string GetName()
        {
            return "MYG - Información cables circuito - Recorrido A-B + parámetros";
        }

        public void Execute(UIApplication app)
        {
            try
            {
                if (UiDoc == null)
                    UiDoc = app.ActiveUIDocument;

                if (UiDoc == null ||
                    UiDoc.Document == null)
                {
                    Terminar(
                        "No hay documento activo.");
                    return;
                }

                if (Form == null ||
                    Form.IsDisposed)
                {
                    return;
                }

                if (Form.OperacionSolicitada ==
                    MYG_InformacionCablesCircuito58.Operacion.CerrarYLiberarVistaTemporal)
                {
                    try
                    {
                        LimpiarControlVisualTemporal(
                            UiDoc.Document);
                    }
                    finally
                    {
                        // Aunque la vista no admita limpieza por alguna razón,
                        // nunca dejamos la ventana oculta y bloqueada.
                        Form.CerrarDesdeHandler();
                    }

                    return;
                }

                if (Form.OperacionSolicitada ==
                    MYG_InformacionCablesCircuito58.Operacion.CargarParametros)
                {
                    CargarParametrosEnVentana(
                        UiDoc.Document);

                    return;
                }

                if (Form.OperacionSolicitada ==
                    MYG_InformacionCablesCircuito58.Operacion.SeleccionarYDetectar)
                {
                    DetectarRuta();

                    return;
                }

                Form.SetProcesando(
                    false);
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                Terminar(
                    "Selección cancelada por el usuario.");
            }
            catch (Exception ex)
            {
                Terminar(
                    "ERROR\r\n" +
                    ex.GetType().Name +
                    ": " +
                    ex.Message);
            }
        }

        // ============================================================
        // PROCESO PRINCIPAL
        // ============================================================
        private void DetectarRuta()
        {
            System.Diagnostics.Stopwatch cronometroTotal =
                System.Diagnostics.Stopwatch.StartNew();

            Document doc =
                UiDoc.Document;

            List<MYG_InformacionCablesCircuito58.AsignacionParametro> asignaciones =
                Form.ObtenerAsignaciones();

            MYG_InformacionCablesCircuito58.ModoEscritura modoEscritura =
                Form.ModoSeleccionado;

            if (asignaciones == null ||
                asignaciones.Count == 0)
            {
                Terminar(
                    "No hay parámetros configurados para escribir.");

                return;
            }

            SelectorEquiposFiltro filtro =
                new SelectorEquiposFiltro();

            Reference refA =
                UiDoc.Selection.PickObject(
                    ObjectType.Element,
                    filtro,
                    "Seleccione el PRIMER elemento MEP.");

            Reference refB =
                UiDoc.Selection.PickObject(
                    ObjectType.Element,
                    filtro,
                    "Seleccione el SEGUNDO elemento MEP.");

            if (refA == null ||
                refB == null)
            {
                Terminar(
                    "Selección cancelada.");
                return;
            }

            if (refA.ElementId.Value ==
                refB.ElementId.Value)
            {
                Terminar(
                    "Debe seleccionar dos elementos diferentes.");
                return;
            }

            Element elementoA =
                doc.GetElement(
                    refA.ElementId);

            Element elementoB =
                doc.GetElement(
                    refB.ElementId);

            if (elementoA == null ||
                elementoB == null)
            {
                Terminar(
                    "No se pudieron recuperar los elementos seleccionados.");
                return;
            }

            double toleranciaSalto =
                UnitUtils.ConvertToInternalUnits(
                    Form.ToleranciaRutaMm,
                    UnitTypeId.Millimeters);

            double alcanceEquipo =
                UnitUtils.ConvertToInternalUnits(
                    Form.AlcanceEquipoMm,
                    UnitTypeId.Millimeters);

            // --------------------------------------------------------
            // La parte costosa se hace UNA sola vez:
            // recoger canalizaciones/cajas y sus conectores.
            // No hay comparación N x N de sólidos.
            // --------------------------------------------------------
            MapaRuta mapa =
                ConstruirMapaRuta(
                    doc,
                    elementoA.Id,
                    elementoB.Id);

            if (mapa.Nodos.Count == 0 ||
                mapa.Conectores.Count == 0)
            {
                Terminar(
                    "No se encontraron conduits, tubos flexibles, accesorios, bandejas o cajas con conectores para analizar.");
                return;
            }

            List<Anclaje> anclajesA =
                BuscarAnclajesExtremo(
                    elementoA,
                    mapa,
                    alcanceEquipo);

            List<Anclaje> anclajesB =
                BuscarAnclajesExtremo(
                    elementoB,
                    mapa,
                    alcanceEquipo);

            if (anclajesA.Count == 0 ||
                anclajesB.Count == 0)
            {
                string faltante =
                    anclajesA.Count == 0 &&
                    anclajesB.Count == 0
                        ? "A y B"
                        : (anclajesA.Count == 0
                            ? "A"
                            : "B");

                Terminar(
                    "RUTA NO ENCONTRADA\r\n" +
                    "No se encontró canalización próxima al elemento " +
                    faltante +
                    ".\r\n" +
                    "Elementos de red analizados: " +
                    mapa.Nodos.Count +
                    "\r\n" +
                    "Conectores analizados: " +
                    mapa.Conectores.Count +
                    "\r\n" +
                    "Alcance actual: " +
                    Form.AlcanceEquipoMm.ToString("0") +
                    " mm.");

                return;
            }

            // --------------------------------------------------------
            // 1° INTENTO:
            // conexiones físicas de Revit + tolerancia indicada.
            // --------------------------------------------------------
            ResultadoRuta resultado =
                BuscarRutaMasCorta(
                    mapa,
                    anclajesA,
                    anclajesB,
                    toleranciaSalto);

            double toleranciaUsada =
                toleranciaSalto;

            // --------------------------------------------------------
            // 2° INTENTO:
            // si hay pequeños huecos entre extremos de conduits/cajas,
            // reintentar hasta 100 mm.
            //
            // IMPORTANTE:
            // el salto se busca SOLO entre CONNECTOR.ORIGIN.
            // No une tubos que simplemente se crucen en el medio.
            // --------------------------------------------------------
            if (resultado == null)
            {
                double toleranciaAdaptativa =
                    Math.Max(
                        toleranciaSalto,
                        UnitUtils.ConvertToInternalUnits(
                            100.0,
                            UnitTypeId.Millimeters));

                if (toleranciaAdaptativa >
                    toleranciaSalto + 1e-9)
                {
                    resultado =
                        BuscarRutaMasCorta(
                            mapa,
                            anclajesA,
                            anclajesB,
                            toleranciaAdaptativa);

                    if (resultado != null)
                        toleranciaUsada =
                            toleranciaAdaptativa;
                }
            }

            if (resultado == null ||
                resultado.ElementIds == null ||
                resultado.ElementIds.Count == 0)
            {
                Terminar(
                    "RUTA NO ENCONTRADA\r\n" +
                    "La herramienta encontró los puntos de entrada de A y B, " +
                    "pero no existe continuidad por conectores entre ambos.\r\n\r\n" +
                    "Anclajes A: " +
                    FormatearAnclajes(
                        mapa,
                        anclajesA) +
                    "\r\n" +
                    "Anclajes B: " +
                    FormatearAnclajes(
                        mapa,
                        anclajesB) +
                    "\r\n\r\n" +
                    "Sugerencia de diagnóstico: revise si alguna caja/accesorio/tubo flexible del recorrido " +
                    "no tiene conectores MEP o si existe un hueco mayor a 100 mm entre extremos.");

                return;
            }

            List<Element> elementosRuta =
                resultado.ElementIds
                    .Select(id => doc.GetElement(id))
                    .Where(e => e != null)
                    .ToList();

            // ========================================================
            // SEGUNDA PASADA:
            // añadir cajas / aparatos / dispositivos que estén
            // FÍSICAMENTE SOBRE el recorrido ya encontrado.
            //
            // Esto resuelve familias que:
            // - tienen 0 o 1 conector útil;
            // - tienen conectores lógicos;
            // - no exponen bien AllRefs;
            // - visualmente están insertadas sobre el conduit/flexible.
            //
            // La ruta principal NO cambia. Solo se enriquecen los
            // elementos que recibirán la información del cable.
            // ========================================================
            double toleranciaDispositivos =
                Math.Max(
                    toleranciaUsada,
                    UnitUtils.ConvertToInternalUnits(
                        50.0,
                        UnitTypeId.Millimeters));

            int dispositivosAgregados;

            elementosRuta =
                AgregarDispositivosFisicosSobreRuta(
                    doc,
                    elementosRuta,
                    elementoA.Id,
                    elementoB.Id,
                    toleranciaDispositivos,
                    out dispositivosAgregados);

            double longitudMetros =
                UnitUtils.ConvertFromInternalUnits(
                    resultado.CostoInterno,
                    UnitTypeId.Meters);

            int escriturasRealizadas;
            int elementosConEscritura;
            int omitidos;

            AplicarAsignacionesParametros(
                doc,
                elementosRuta,
                asignaciones,
                modoEscritura,
                out escriturasRealizadas,
                out elementosConEscritura,
                out omitidos);

            // ========================================================
            // CONTROL TEMPORAL POR COMENTARIOS
            // ========================================================
            // Este es el único parámetro adicional que se modifica:
            //
            // Comentarios = MYG_CABLES_PROCESADO
            //
            // Sirve exclusivamente para el control visual solicitado.
            int comentariosMarcados =
                0;

            int comentariosOmitidos =
                0;

            MarcarComentariosProcesados(
                doc,
                elementosRuta,
                out comentariosMarcados,
                out comentariosOmitidos);

            string estadoControlTemporal =
                "";

            bool controlTemporalActivo =
                ConfigurarControlVisualTemporal(
                    doc,
                    UiDoc.ActiveView,
                    elementosRuta,
                    out estadoControlTemporal);

            if (Form.SeleccionarRecorrido)
            {
                List<ElementId> ids =
                    new List<ElementId>();

                ids.Add(
                    elementoA.Id);

                ids.AddRange(
                    elementosRuta.Select(
                        x => x.Id));

                ids.Add(
                    elementoB.Id);

                UiDoc.Selection.SetElementIds(
                    ids
                        .GroupBy(x => x.Value)
                        .Select(g => g.First())
                        .ToList());
            }

            string idsRuta =
                string.Join(
                    " > ",
                    elementosRuta.Select(
                        x => x.Id.Value.ToString()));

            Terminar(
                "RUTA POR CONECTORES DETECTADA\r\n" +

                "Inicio A: " +
                ObtenerNombreElemento(elementoA) +
                " [" +
                elementoA.Id.Value +
                "]\r\n" +
                "Fin B: " +
                ObtenerNombreElemento(elementoB) +
                " [" +
                elementoB.Id.Value +
                "]\r\n" +
                "Candidatos A: " +
                FormatearAnclajes(
                    mapa,
                    anclajesA) +
                "\r\n" +
                "Candidatos B: " +
                FormatearAnclajes(
                    mapa,
                    anclajesB) +
                "\r\n" +
                "Anclaje elegido A: ID " +
                resultado.IdAnclajeInicio +
                "\r\n" +
                "Anclaje elegido B: ID " +
                resultado.IdAnclajeFin +
                "\r\n" +
                "Tolerancia de salto usada: " +
                UnitUtils.ConvertFromInternalUnits(
                    toleranciaUsada,
                    UnitTypeId.Millimeters).ToString("0") +
                " mm\r\n" +
                "Elementos del recorrido: " +
                elementosRuta.Count +
                "\r\n" +
                "Cajas/dispositivos añadidos por proximidad física: " +
                dispositivosAgregados +
                "\r\n" +
                "Tipos: " +
                string.Join(
                    " > ",
                    elementosRuta.Select(
                        x => x.GetType().Name)) +
                "\r\n" +
                "Longitud aproximada del recorrido: " +
                longitudMetros.ToString("0.00") +
                " m\r\n" +
                "Modo de escritura: " +
                (modoEscritura ==
                    MYG_InformacionCablesCircuito58.ModoEscritura.Sumar
                        ? "SUMAR"
                        : "REEMPLAZAR") +
                "\r\n" +
                "Parámetros configurados: " +
                asignaciones.Count +
                "\r\n" +
                "Elementos modificados: " +
                elementosConEscritura +
                "\r\n" +
                "Valores escritos: " +
                escriturasRealizadas +
                (omitidos > 0
                    ? " | No aplicables/omitidos: " + omitidos
                    : "") +
                "\r\n" +
                "Asignaciones: " +
                string.Join(
                    " | ",
                    asignaciones.Select(
                        x => x.NombreParametro + "=" + x.Valor)) +
                "\r\n" +
                "Control temporal: " +
                (controlTemporalActivo
                    ? "ACTIVO"
                    : "NO ACTIVO") +
                "\r\n" +
                "Comentarios marcados: " +
                comentariosMarcados +
                (comentariosOmitidos > 0
                    ? " | Omitidos: " + comentariosOmitidos
                    : "") +
                "\r\n" +
                (!String.IsNullOrWhiteSpace(
                    estadoControlTemporal)
                    ? "Control visual: " +
                      estadoControlTemporal +
                      "\r\n"
                    : "") +
                "Tiempo total: " +
                cronometroTotal.ElapsedMilliseconds +
                " ms\r\n" +
                "IDs: " +
                idsRuta);
        }

        // ============================================================
        // V19 - CONTROL VISUAL TEMPORAL POR COMENTARIOS
        // ============================================================

        private static void MarcarComentariosProcesados(
            Document doc,
            IList<Element> elementosRuta,
            out int escritos,
            out int omitidos)
        {
            escritos =
                0;

            omitidos =
                0;

            if (doc == null ||
                elementosRuta == null ||
                elementosRuta.Count == 0)
            {
                return;
            }

            using (Transaction t =
                new Transaction(
                    doc,
                    "MYG - Marcar recorrido procesado"))
            {
                t.Start();

                foreach (Element elemento
                    in elementosRuta)
                {
                    if (elemento == null)
                        continue;

                    try
                    {
                        Parameter p =
                            elemento.get_Parameter(
                                BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);

                        if (p == null ||
                            p.IsReadOnly ||
                            p.StorageType !=
                                StorageType.String)
                        {
                            omitidos++;
                            continue;
                        }

                        p.Set(
                            ValorComentarioProcesado);

                        escritos++;
                    }
                    catch
                    {
                        omitidos++;
                    }
                }

                t.Commit();
            }
        }

        private bool ConfigurarControlVisualTemporal(
            Document doc,
            View vista,
            IList<Element> elementosRuta,
            out string estado)
        {
            estado =
                "";

            if (doc == null ||
                vista == null)
            {
                estado =
                    "No hay una vista activa válida.";

                return false;
            }

            if (vista.IsTemplate)
            {
                estado =
                    "La vista activa es una plantilla.";

                return false;
            }

            try
            {
                // ----------------------------------------------------
                // Obtener las categorías REALMENTE utilizadas por la
                // ruta y que admiten Comentarios.
                // ----------------------------------------------------
                HashSet<ElementId> categoriasRuta =
                    ObtenerCategoriasFiltrablesComentarios(
                        doc,
                        elementosRuta);

                if (categoriasRuta.Count == 0)
                {
                    estado =
                        "Ninguna categoría del recorrido permite filtrar por Comentarios.";

                    return false;
                }

                using (Transaction t =
                    new Transaction(
                        doc,
                        "MYG - Control temporal cables"))
                {
                    t.Start();

                    // =================================================
                    // PRIMERA EJECUCIÓN EN ESTA VISTA
                    // =================================================
                    // Activa Temporary View Properties SIN duplicar ni
                    // crear ninguna vista.
                    //
                    // Pasando vista.Id se activa el modo temporal
                    // conservando inicialmente la apariencia actual.
                    // =================================================
                    bool yaEstabaTemporal =
                        vista.IsTemporaryViewPropertiesModeEnabled();

                    if (!yaEstabaTemporal)
                    {
                        bool activado =
                            false;

                        try
                        {
                            if (vista.CanEnableTemporaryViewPropertiesMode())
                            {
                                activado =
                                    vista.EnableTemporaryViewPropertiesMode(
                                        vista.Id);
                            }
                        }
                        catch
                        {
                            activado =
                                false;
                        }

                        if (!activado)
                        {
                            t.RollBack();

                            estado =
                                "La vista actual no permite Propiedades de vista temporal.";

                            return false;
                        }

                        _modoTemporalActivadoPorMYG =
                            true;
                    }

                    // Guardar la vista exacta donde se aplicó el control,
                    // aunque después el usuario navegue a otra vista.
                    _vistaTemporalControlId =
                        vista.Id;

                    // Personalizar la banda temporal para que sea fácil
                    // reconocer que MYG está en modo de control.
                    try
                    {
                        TemporaryViewModes modos =
                            vista.TemporaryViewModes;

                        if (modos != null)
                        {
                            modos.CustomTitle =
                                "MYG - CONTROL CABLES";

                            modos.CustomColor =
                                new Autodesk.Revit.DB.Color(
                                    0,
                                    170,
                                    255);
                        }
                    }
                    catch
                    {
                        // No afecta el funcionamiento del filtro.
                    }

                    // -------------------------------------------------
                    // Crear o reutilizar UN SOLO filtro de parámetro.
                    //
                    // El FilterElement existe en el documento para poder
                    // ser usado por Visibility/Graphics, pero su
                    // APLICACIÓN y sus OVERRIDES en esta vista se hacen
                    // mientras Temporary View Properties está activo.
                    // Al salir del modo temporal, la apariencia original
                    // de la vista vuelve automáticamente.
                    // -------------------------------------------------
                    ParameterFilterElement filtro =
                        ObtenerOCrearFiltroComentarios(
                            doc,
                            categoriasRuta);

                    if (filtro == null)
                    {
                        t.RollBack();

                        estado =
                            "No se pudo crear el filtro temporal de Comentarios.";

                        return false;
                    }

                    // Ampliar categorías si una ejecución posterior usa
                    // una categoría diferente.
                    HashSet<ElementId> categoriasAcumuladas =
                        new HashSet<ElementId>(
                            filtro.GetCategories());

                    foreach (ElementId idCat
                        in categoriasRuta)
                    {
                        categoriasAcumuladas.Add(
                            idCat);
                    }

                    categoriasAcumuladas =
                        FiltrarCategoriasCompatiblesComentarios(
                            doc,
                            categoriasAcumuladas);

                    if (categoriasAcumuladas.Count > 0)
                    {
                        filtro.SetCategories(
                            categoriasAcumuladas.ToList());
                    }

                    ElementFilter reglaComentarios =
                        CrearReglaComentariosProcesados();

                    if (reglaComentarios != null)
                    {
                        filtro.SetElementFilter(
                            reglaComentarios);
                    }

                    OverrideGraphicSettings ogs =
                        CrearOverrideProcesado(
                            doc);

                    // SetFilterOverrides aplica el filtro si todavía
                    // no estaba aplicado a la vista.
                    vista.SetFilterOverrides(
                        filtro.Id,
                        ogs);

                    vista.SetFilterVisibility(
                        filtro.Id,
                        true);

                    try
                    {
                        vista.SetIsFilterEnabled(
                            filtro.Id,
                            true);
                    }
                    catch
                    {
                        // Compatibilidad: SetFilterVisibility +
                        // SetFilterOverrides ya son suficientes.
                    }

                    t.Commit();
                }

                try
                {
                    doc.Regenerate();

                    if (UiDoc != null)
                    {
                        UiDoc.RefreshActiveView();
                    }
                }
                catch
                {
                }

                estado =
                    "Los elementos con Comentarios = \"" +
                    ValorComentarioProcesado +
                    "\" se muestran en verde.";

                return true;
            }
            catch (Exception ex)
            {
                estado =
                    ex.GetType().Name +
                    ": " +
                    ex.Message;

                return false;
            }
        }

        private static ParameterFilterElement ObtenerOCrearFiltroComentarios(
            Document doc,
            ISet<ElementId> categorias)
        {
            ParameterFilterElement existente =
                new FilteredElementCollector(doc)
                    .OfClass(
                        typeof(ParameterFilterElement))
                    .Cast<ParameterFilterElement>()
                    .FirstOrDefault(
                        x =>
                            String.Equals(
                                x.Name,
                                NombreFiltroControlTemporal,
                                StringComparison.CurrentCultureIgnoreCase));

            ElementFilter regla =
                CrearReglaComentariosProcesados();

            if (existente != null)
            {
                return existente;
            }

            if (categorias == null ||
                categorias.Count == 0 ||
                regla == null)
            {
                return null;
            }

            return ParameterFilterElement.Create(
                doc,
                NombreFiltroControlTemporal,
                categorias.ToList(),
                regla);
        }

        private static ElementFilter CrearReglaComentariosProcesados()
        {
            try
            {
                ElementId idComentarios =
                    new ElementId(
                        BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);

                FilterRule regla =
                    ParameterFilterRuleFactory.CreateEqualsRule(
                        idComentarios,
                        ValorComentarioProcesado);

                return new ElementParameterFilter(
                    regla);
            }
            catch
            {
                return null;
            }
        }

        private static HashSet<ElementId> ObtenerCategoriasFiltrablesComentarios(
            Document doc,
            IList<Element> elementos)
        {
            HashSet<ElementId> resultado =
                new HashSet<ElementId>();

            if (doc == null ||
                elementos == null)
            {
                return resultado;
            }

            HashSet<ElementId> categoriasFiltrables =
                new HashSet<ElementId>(
                    ParameterFilterUtilities.GetAllFilterableCategories());

            foreach (Element elemento
                in elementos)
            {
                if (elemento == null ||
                    elemento.Category == null)
                {
                    continue;
                }

                ElementId idCat =
                    elemento.Category.Id;

                if (!categoriasFiltrables.Contains(
                    idCat))
                {
                    continue;
                }

                Parameter comentarios =
                    null;

                try
                {
                    comentarios =
                        elemento.get_Parameter(
                            BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);
                }
                catch
                {
                    comentarios =
                        null;
                }

                if (comentarios == null ||
                    comentarios.StorageType !=
                        StorageType.String)
                {
                    continue;
                }

                resultado.Add(
                    idCat);
            }

            return
                FiltrarCategoriasCompatiblesComentarios(
                    doc,
                    resultado);
        }

        private static HashSet<ElementId> FiltrarCategoriasCompatiblesComentarios(
            Document doc,
            IEnumerable<ElementId> categorias)
        {
            HashSet<ElementId> resultado =
                new HashSet<ElementId>();

            if (doc == null ||
                categorias == null)
            {
                return resultado;
            }

            ElementFilter regla =
                CrearReglaComentariosProcesados();

            foreach (ElementId idCat
                in categorias)
            {
                if (idCat == null ||
                    idCat ==
                        ElementId.InvalidElementId)
                {
                    continue;
                }

                try
                {
                    HashSet<ElementId> prueba =
                        new HashSet<ElementId>();

                    prueba.Add(
                        idCat);

                    bool aceptable =
                        ParameterFilterElement
                            .ElementFilterIsAcceptableForParameterFilterElement(
                                doc,
                                prueba,
                                regla);

                    if (aceptable)
                    {
                        resultado.Add(
                            idCat);
                    }
                }
                catch
                {
                }
            }

            return resultado;
        }

        private static OverrideGraphicSettings CrearOverrideProcesado(
            Document doc)
        {
            // ========================================================
            // V20 - GRÁFICOS DEL FILTRO TEMPORAL
            //
            // PROYECCIÓN / SUPERFICIE
            // - Línea: NEGRA
            // - Grosor: 1
            // - Patrón primer plano: RELLENO SÓLIDO VERDE
            // - Patrón fondo: RELLENO SÓLIDO VERDE
            //
            // CORTE
            // Se deja la misma configuración para que, si algún
            // elemento aparece cortado en otra vista, mantenga el
            // mismo criterio gráfico.
            // ========================================================

            Autodesk.Revit.DB.Color negro =
                new Autodesk.Revit.DB.Color(
                    0,
                    0,
                    0);

            Autodesk.Revit.DB.Color verde =
                new Autodesk.Revit.DB.Color(
                    0,
                    210,
                    70);

            OverrideGraphicSettings ogs =
                new OverrideGraphicSettings();

            // --------------------------------------------------------
            // LÍNEAS DE PROYECCIÓN / SUPERFICIE
            // --------------------------------------------------------
            ogs.SetProjectionLineColor(
                negro);

            ogs.SetProjectionLineWeight(
                1);

            // --------------------------------------------------------
            // LÍNEAS DE CORTE
            // --------------------------------------------------------
            try
            {
                ogs.SetCutLineColor(
                    negro);

                ogs.SetCutLineWeight(
                    1);
            }
            catch
            {
            }

            // Sin transparencia para que el relleno se vea claramente.
            try
            {
                ogs.SetSurfaceTransparency(
                    0);
            }
            catch
            {
            }

            ElementId patronSolido =
                ObtenerPatronSolidoIdTemporal(
                    doc);

            if (patronSolido !=
                ElementId.InvalidElementId)
            {
                // ----------------------------------------------------
                // PROYECCIÓN / SUPERFICIE
                // PRIMER PLANO
                // ----------------------------------------------------
                try
                {
                    ogs.SetSurfaceForegroundPatternId(
                        patronSolido);

                    ogs.SetSurfaceForegroundPatternColor(
                        verde);

                    ogs.SetSurfaceForegroundPatternVisible(
                        true);
                }
                catch
                {
                }

                // ----------------------------------------------------
                // PROYECCIÓN / SUPERFICIE
                // FONDO
                // ----------------------------------------------------
                try
                {
                    ogs.SetSurfaceBackgroundPatternId(
                        patronSolido);

                    ogs.SetSurfaceBackgroundPatternColor(
                        verde);

                    ogs.SetSurfaceBackgroundPatternVisible(
                        true);
                }
                catch
                {
                }

                // ----------------------------------------------------
                // CORTE
                // PRIMER PLANO
                // ----------------------------------------------------
                try
                {
                    ogs.SetCutForegroundPatternId(
                        patronSolido);

                    ogs.SetCutForegroundPatternColor(
                        verde);

                    ogs.SetCutForegroundPatternVisible(
                        true);
                }
                catch
                {
                }

                // ----------------------------------------------------
                // CORTE
                // FONDO
                // ----------------------------------------------------
                try
                {
                    ogs.SetCutBackgroundPatternId(
                        patronSolido);

                    ogs.SetCutBackgroundPatternColor(
                        verde);

                    ogs.SetCutBackgroundPatternVisible(
                        true);
                }
                catch
                {
                }
            }

            return ogs;
        }

        private static ElementId ObtenerPatronSolidoIdTemporal(
            Document doc)
        {
            if (doc == null)
                return ElementId.InvalidElementId;

            try
            {
                FillPatternElement patron =
                    new FilteredElementCollector(doc)
                        .OfClass(
                            typeof(FillPatternElement))
                        .Cast<FillPatternElement>()
                        .FirstOrDefault(
                            x =>
                            {
                                try
                                {
                                    FillPattern fp =
                                        x.GetFillPattern();

                                    return
                                        fp != null &&
                                        fp.IsSolidFill;
                                }
                                catch
                                {
                                    return false;
                                }
                            });

                return patron != null
                    ? patron.Id
                    : ElementId.InvalidElementId;
            }
            catch
            {
                return ElementId.InvalidElementId;
            }
        }

        // ============================================================
        // V21 - RESTAURAR LA VISTA AL CERRAR LA VENTANA
        // ============================================================
        private void LimpiarControlVisualTemporal(
            Document doc)
        {
            if (doc == null)
                return;

            View vistaControl =
                null;

            try
            {
                if (_vistaTemporalControlId != null &&
                    _vistaTemporalControlId != ElementId.InvalidElementId)
                {
                    vistaControl =
                        doc.GetElement(
                            _vistaTemporalControlId) as View;
                }
            }
            catch
            {
                vistaControl =
                    null;
            }

            ParameterFilterElement filtro =
                null;

            try
            {
                filtro =
                    new FilteredElementCollector(doc)
                        .OfClass(
                            typeof(ParameterFilterElement))
                        .Cast<ParameterFilterElement>()
                        .FirstOrDefault(
                            x =>
                                String.Equals(
                                    x.Name,
                                    NombreFiltroControlTemporal,
                                    StringComparison.CurrentCultureIgnoreCase));
            }
            catch
            {
                filtro =
                    null;
            }

            using (Transaction t =
                new Transaction(
                    doc,
                    "MYG - Restaurar vista cables"))
            {
                t.Start();

                if (vistaControl != null)
                {
                    // -------------------------------------------------
                    // CASO NORMAL:
                    // MYG fue quien activó Temporary View Properties.
                    //
                    // Autodesk indica que al desactivarlo se descartan
                    // todos los cambios temporales y la vista vuelve a
                    // sus propiedades anteriores.
                    // -------------------------------------------------
                    if (_modoTemporalActivadoPorMYG)
                    {
                        try
                        {
                            vistaControl.EnableTemporaryViewPropertiesMode(
                                ElementId.InvalidElementId);
                        }
                        catch
                        {
                            try
                            {
                                vistaControl.DisableTemporaryViewMode(
                                    TemporaryViewMode.TemporaryViewProperties);
                            }
                            catch
                            {
                            }
                        }
                    }
                    else
                    {
                        // -------------------------------------------------
                        // Si el usuario YA tenía Temporary View Properties
                        // antes de MYG, no apagamos su modo temporal.
                        // Solamente retiramos nuestro filtro de esa vista.
                        // -------------------------------------------------
                        if (filtro != null)
                        {
                            try
                            {
                                bool aplicado =
                                    vistaControl
                                        .GetFilters()
                                        .Any(
                                            x =>
                                                x.Value ==
                                                filtro.Id.Value);

                                if (aplicado)
                                {
                                    vistaControl.RemoveFilter(
                                        filtro.Id);
                                }
                            }
                            catch
                            {
                            }
                        }

                        try
                        {
                            TemporaryViewModes modos =
                                vistaControl.TemporaryViewModes;

                            if (modos != null)
                            {
                                modos.RemoveCustomization();
                            }
                        }
                        catch
                        {
                        }
                    }
                }

                // El filtro es auxiliar y pertenece exclusivamente a
                // esta herramienta. Eliminándolo no dejamos residuos
                // MYG en Filtros del proyecto al cerrar la ventana.
                if (filtro != null)
                {
                    try
                    {
                        doc.Delete(
                            filtro.Id);
                    }
                    catch
                    {
                    }
                }

                t.Commit();
            }

            _vistaTemporalControlId =
                ElementId.InvalidElementId;

            _modoTemporalActivadoPorMYG =
                false;

            try
            {
                doc.Regenerate();

                if (UiDoc != null)
                {
                    UiDoc.RefreshActiveView();
                }
            }
            catch
            {
            }
        }

        // ============================================================
        // CARGA DE PARÁMETROS PARA LOS DESPLEGABLES
        // ============================================================
        private void CargarParametrosEnVentana(
            Document doc)
        {
            try
            {
                List<MYG_InformacionCablesCircuito58.ParametroDisponible> parametros =
                    ObtenerParametrosDisponiblesParaVentana(
                        doc);

                Form.EstablecerParametrosDisponibles(
                    parametros);
            }
            catch (Exception ex)
            {
                Form.MarcarOperacionCompletada();

                Form.SetProcesando(
                    false);

                Form.MostrarResultado(
                    "No se pudieron cargar los parámetros:\r\n" +
                    ex.Message);
            }
        }

        internal static List<MYG_InformacionCablesCircuito58.ParametroDisponible> ObtenerParametrosDisponiblesParaVentana(
            Document doc)
        {
            Dictionary<string, HashSet<StorageType>> tiposPorNombre =
                new Dictionary<string, HashSet<StorageType>>(
                    StringComparer.CurrentCultureIgnoreCase);

            Dictionary<string, string> nombreOriginal =
                new Dictionary<string, string>(
                    StringComparer.CurrentCultureIgnoreCase);

            HashSet<long> procesados =
                new HashSet<long>();

            // --------------------------------------------------------
            // Canalizaciones principales.
            // --------------------------------------------------------
            List<BuiltInCategory> categoriasCanalizacion =
                new List<BuiltInCategory>(
                    CategoriasCanalizacion);

            ElementMulticategoryFilter filtroCanalizacion =
                new ElementMulticategoryFilter(
                    categoriasCanalizacion);

            FilteredElementCollector collectorCanalizacion =
                new FilteredElementCollector(doc)
                    .WherePasses(
                        filtroCanalizacion)
                    .WhereElementIsNotElementType();

            foreach (Element e
                in collectorCanalizacion)
            {
                RegistrarParametrosElemento(
                    e,
                    procesados,
                    tiposPorNombre,
                    nombreOriginal);
            }

            // --------------------------------------------------------
            // FlexPipe / FlexDuct.
            // --------------------------------------------------------
            FilteredElementCollector flexPipes =
                new FilteredElementCollector(doc)
                    .OfClass(
                        typeof(
                            Autodesk.Revit.DB.Plumbing.FlexPipe))
                    .WhereElementIsNotElementType();

            foreach (Element e
                in flexPipes)
            {
                RegistrarParametrosElemento(
                    e,
                    procesados,
                    tiposPorNombre,
                    nombreOriginal);
            }

            FilteredElementCollector flexDucts =
                new FilteredElementCollector(doc)
                    .OfClass(
                        typeof(
                            Autodesk.Revit.DB.Mechanical.FlexDuct))
                    .WhereElementIsNotElementType();

            foreach (Element e
                in flexDucts)
            {
                RegistrarParametrosElemento(
                    e,
                    procesados,
                    tiposPorNombre,
                    nombreOriginal);
            }

            // --------------------------------------------------------
            // Cajas / dispositivos que pueden aparecer en la ruta.
            // --------------------------------------------------------
            List<BuiltInCategory> categoriasDispositivos =
                new List<BuiltInCategory>(
                    CategoriasDispositivos);

            ElementMulticategoryFilter filtroDispositivos =
                new ElementMulticategoryFilter(
                    categoriasDispositivos);

            FilteredElementCollector collectorDispositivos =
                new FilteredElementCollector(doc)
                    .WherePasses(
                        filtroDispositivos)
                    .WhereElementIsNotElementType();

            foreach (Element e
                in collectorDispositivos)
            {
                RegistrarParametrosElemento(
                    e,
                    procesados,
                    tiposPorNombre,
                    nombreOriginal);
            }

            List<MYG_InformacionCablesCircuito58.ParametroDisponible> resultado =
                new List<MYG_InformacionCablesCircuito58.ParametroDisponible>();

            foreach (KeyValuePair<string, HashSet<StorageType>> kv
                in tiposPorNombre)
            {
                // ====================================================
                // V15:
                // NO eliminar un nombre simplemente porque aparezca
                // con StorageType diferente en familias/categorías
                // distintas.
                //
                // El desplegable debe mostrar la unión de TODOS los
                // parámetros de instancia editables encontrados.
                //
                // Si un mismo nombre aparece con tipos distintos:
                // Texto > Double > Integer.
                // Al escribir, cada elemento igualmente valida que su
                // StorageType real sea compatible y, si no lo es, se
                // omite solo ese elemento.
                // ====================================================
                MYG_InformacionCablesCircuito58.TipoDatoParametro tipoUi;

                if (kv.Value.Contains(
                    StorageType.String))
                {
                    tipoUi =
                        MYG_InformacionCablesCircuito58.TipoDatoParametro.Texto;
                }
                else if (kv.Value.Contains(
                    StorageType.Double))
                {
                    tipoUi =
                        MYG_InformacionCablesCircuito58.TipoDatoParametro.NumeroDecimal;
                }
                else if (kv.Value.Contains(
                    StorageType.Integer))
                {
                    tipoUi =
                        MYG_InformacionCablesCircuito58.TipoDatoParametro.NumeroEntero;
                }
                else
                {
                    continue;
                }

                resultado.Add(
                    new MYG_InformacionCablesCircuito58.ParametroDisponible()
                    {
                        Nombre =
                            nombreOriginal[kv.Key],

                        Tipo =
                            tipoUi
                    });
            }

            return resultado
                .OrderBy(
                    x => x.Nombre)
                .ToList();
        }

        private static void RegistrarParametrosElemento(
            Element elemento,
            HashSet<long> procesados,
            Dictionary<string, HashSet<StorageType>> tiposPorNombre,
            Dictionary<string, string> nombreOriginal)
        {
            if (elemento == null)
                return;

            if (!procesados.Add(
                elemento.Id.Value))
            {
                return;
            }

            // Element.Parameters devuelve los parámetros de ESTA
            // INSTANCIA, es decir, los que aparecen en Propiedades
            // del elemento. No se inspeccionan parámetros de tipo.
            ParameterSet parametros =
                elemento.Parameters;

            if (parametros == null)
                return;

            foreach (Parameter p
                in parametros)
            {
                if (p == null ||
                    p.Definition == null ||
                    p.IsReadOnly)
                {
                    continue;
                }

                if (p.StorageType !=
                        StorageType.String &&
                    p.StorageType !=
                        StorageType.Integer &&
                    p.StorageType !=
                        StorageType.Double)
                {
                    continue;
                }

                string nombre =
                    p.Definition.Name;

                if (String.IsNullOrWhiteSpace(
                    nombre))
                {
                    continue;
                }

                HashSet<StorageType> tipos;

                if (!tiposPorNombre.TryGetValue(
                    nombre,
                    out tipos))
                {
                    tipos =
                        new HashSet<StorageType>();

                    tiposPorNombre[nombre] =
                        tipos;

                    nombreOriginal[nombre] =
                        nombre;
                }

                tipos.Add(
                    p.StorageType);
            }
        }

        // ============================================================
        // CONSTRUCCIÓN DEL MAPA DE RED
        // ============================================================
        private static MapaRuta ConstruirMapaRuta(
            Document doc,
            ElementId excluirA,
            ElementId excluirB)
        {
            MapaRuta mapa =
                new MapaRuta();

            // ========================================================
            // V13 - OPTIMIZACIÓN
            //
            // Antes se creaba un FilteredElementCollector por cada
            // categoría. Ahora se usa un único ElementMulticategoryFilter
            // para canalizaciones y otro para dispositivos.
            // ========================================================

            // --------------------------------------------------------
            // 1) CONDUITS / FITTINGS / BANDEJAS
            // --------------------------------------------------------
            List<BuiltInCategory> categoriasCanalizacion =
                new List<BuiltInCategory>(
                    CategoriasCanalizacion);

            ElementMulticategoryFilter filtroCanalizacion =
                new ElementMulticategoryFilter(
                    categoriasCanalizacion);

            FilteredElementCollector collectorCanalizacion =
                new FilteredElementCollector(doc)
                    .WherePasses(
                        filtroCanalizacion)
                    .WhereElementIsNotElementType();

            foreach (Element e
                in collectorCanalizacion)
            {
                AgregarElementoAlMapa(
                    e,
                    false,
                    excluirA,
                    excluirB,
                    mapa);
            }

            // --------------------------------------------------------
            // 2) FLEXPIPE / FLEXDUCT
            // --------------------------------------------------------
            FilteredElementCollector flexPipes =
                new FilteredElementCollector(doc)
                    .OfClass(
                        typeof(
                            Autodesk.Revit.DB.Plumbing.FlexPipe))
                    .WhereElementIsNotElementType();

            foreach (Element e
                in flexPipes)
            {
                AgregarElementoAlMapa(
                    e,
                    false,
                    excluirA,
                    excluirB,
                    mapa);
            }

            FilteredElementCollector flexDucts =
                new FilteredElementCollector(doc)
                    .OfClass(
                        typeof(
                            Autodesk.Revit.DB.Mechanical.FlexDuct))
                    .WhereElementIsNotElementType();

            foreach (Element e
                in flexDucts)
            {
                AgregarElementoAlMapa(
                    e,
                    false,
                    excluirA,
                    excluirB,
                    mapa);
            }

            // --------------------------------------------------------
            // 3) CAJAS / DISPOSITIVOS PUENTE
            //
            // Un solo collector para todas las categorías.
            // Además, los connectors se leen una sola vez.
            // --------------------------------------------------------
            List<BuiltInCategory> categoriasDispositivos =
                new List<BuiltInCategory>(
                    CategoriasDispositivos);

            ElementMulticategoryFilter filtroDispositivos =
                new ElementMulticategoryFilter(
                    categoriasDispositivos);

            FilteredElementCollector collectorDispositivos =
                new FilteredElementCollector(doc)
                    .WherePasses(
                        filtroDispositivos)
                    .WhereElementIsNotElementType();

            foreach (Element e
                in collectorDispositivos)
            {
                if (e == null)
                    continue;

                if (e.Id.Value ==
                        excluirA.Value ||
                    e.Id.Value ==
                        excluirB.Value)
                {
                    continue;
                }

                List<Connector> conectores =
                    ObtenerConectoresFisicos(
                        e);

                if (conectores.Count < 2)
                    continue;

                AgregarElementoAlMapa(
                    e,
                    true,
                    excluirA,
                    excluirB,
                    mapa,
                    conectores);
            }

            // --------------------------------------------------------
            // 4) ÍNDICE ESPACIAL ÚNICO
            //
            // Se reutiliza para:
            // - encontrar ramas cerca de A y B;
            // - Dijkstra a 50 mm;
            // - reintento adaptativo a 100 mm.
            //
            // Antes se reconstruía un índice completo en cada intento.
            // --------------------------------------------------------
            double celdaIndice =
                UnitUtils.ConvertToInternalUnits(
                    250.0,
                    UnitTypeId.Millimeters);

            mapa.IndiceConectores =
                new IndiceEspacial(
                    mapa.Conectores,
                    celdaIndice);

            return mapa;
        }

        private static void AgregarElementoAlMapa(
            Element elemento,
            bool esCajaPuente,
            ElementId excluirA,
            ElementId excluirB,
            MapaRuta mapa,
            List<Connector> conectoresPrecalculados = null)
        {
            if (elemento == null)
                return;

            long id =
                elemento.Id.Value;

            if (id == excluirA.Value ||
                id == excluirB.Value)
            {
                return;
            }

            if (mapa.Nodos.ContainsKey(id))
                return;

            List<Connector> conectores =
                conectoresPrecalculados != null
                    ? conectoresPrecalculados
                    : ObtenerConectoresFisicos(
                        elemento);

            if (conectores.Count == 0)
                return;

            NodoRuta nodo =
                new NodoRuta();

            nodo.Id =
                id;

            nodo.Elemento =
                elemento;

            nodo.EsCajaPuente =
                esCajaPuente;

            nodo.CostoInterno =
                ObtenerCostoInternoElemento(
                    elemento,
                    conectores,
                    esCajaPuente);

            foreach (Connector c
                in conectores)
            {
                XYZ origen =
                    ObtenerOrigenSeguro(c);

                if (origen == null)
                    continue;

                ConectorRuta cr =
                    new ConectorRuta();

                cr.NodoId =
                    id;

                cr.Conector =
                    c;

                cr.Origen =
                    origen;

                nodo.Conectores.Add(
                    cr);

                mapa.Conectores.Add(
                    cr);
            }

            if (nodo.Conectores.Count == 0)
                return;

            mapa.Nodos[id] =
                nodo;
        }

        // ============================================================
        // ANCLAJE A / B A LA RED
        // ============================================================
        private static List<Anclaje> BuscarAnclajesExtremo(
            Element extremo,
            MapaRuta mapa,
            double alcance)
        {
            // ========================================================
            // V10:
            // NO devolver solamente lo que aparezca en AllRefs.
            //
            // Caso típico:
            //
            //                 Conduit rígido
            //                       \
            //                        [ A ]
            //                         |
            //                     FlexPipe
            //                         |
            //                         B
            //
            // Si Revit reporta solamente el rígido como referencia
            // física de A, la versión anterior empezaba obligatoriamente
            // por el rígido. Ahora A actúa como un "origen virtual":
            // se consideran TODAS las ramas que realmente nacen junto
            // a sus conectores, y Dijkstra decide cuál conduce a B.
            // ========================================================

            Dictionary<long, double> candidatos =
                new Dictionary<long, double>();

            List<Connector> conectoresExtremo =
                ObtenerConectoresFisicos(
                    extremo);

            // --------------------------------------------------------
            // 1) CONEXIONES FÍSICAS QUE REVIT SÍ REPORTA.
            // --------------------------------------------------------
            foreach (Connector c
                in conectoresExtremo)
            {
                foreach (Connector conectado
                    in ObtenerReferenciasFisicas(c))
                {
                    if (conectado == null ||
                        conectado.Owner == null)
                    {
                        continue;
                    }

                    long idOtro =
                        conectado.Owner.Id.Value;

                    if (!mapa.Nodos.ContainsKey(
                        idOtro))
                    {
                        continue;
                    }

                    double existente;

                    if (!candidatos.TryGetValue(
                        idOtro,
                        out existente) ||
                        0.0 < existente)
                    {
                        candidatos[idOtro] =
                            0.0;
                    }
                }
            }

            // --------------------------------------------------------
            // 2) TODAS LAS RAMAS QUE NACEN JUNTO A LOS CONNECTORS
            //    DEL ELEMENTO A/B.
            //
            // Esto es importante para FlexPipe: aunque visualmente y
            // geométricamente nazca desde A, algunas familias/modelados
            // no dejan esa relación disponible mediante AllRefs.
            // --------------------------------------------------------
            List<XYZ> puntosExtremo =
                new List<XYZ>();

            foreach (Connector c
                in conectoresExtremo)
            {
                XYZ p =
                    ObtenerOrigenSeguro(c);

                if (p != null)
                {
                    puntosExtremo.Add(
                        p);
                }
            }

            // Si la familia no expone connectors, usar su centro solo
            // como respaldo. En ese caso se mantiene el alcance indicado.
            bool usandoCentro =
                false;

            if (puntosExtremo.Count == 0)
            {
                XYZ centro =
                    ObtenerCentroElemento(
                        extremo);

                if (centro != null)
                {
                    puntosExtremo.Add(
                        centro);

                    usandoCentro =
                        true;
                }
            }

            if (puntosExtremo.Count == 0)
            {
                return candidatos
                    .OrderBy(kv => kv.Value)
                    .Take(8)
                    .Select(
                        kv => new Anclaje()
                        {
                            NodoId = kv.Key,
                            Distancia = kv.Value
                        })
                    .ToList();
            }

            // Para un elemento con conectores NO queremos utilizar todo
            // el alcance de 2000/5000 mm para crear ramas. Solo buscamos
            // elementos que realmente nazcan junto al conector.
            double radioLocal =
                usandoCentro
                    ? alcance
                    : Math.Min(
                        alcance,
                        UnitUtils.ConvertToInternalUnits(
                            250.0,
                            UnitTypeId.Millimeters));

            IndiceEspacial indiceLocal =
                mapa.IndiceConectores;

            if (indiceLocal == null)
            {
                indiceLocal =
                    new IndiceEspacial(
                        mapa.Conectores,
                        UnitUtils.ConvertToInternalUnits(
                            250.0,
                            UnitTypeId.Millimeters));
            }

            foreach (XYZ p
                in puntosExtremo)
            {
                foreach (ConectorRuta cr
                    in indiceLocal.Buscar(
                        p,
                        radioLocal))
                {
                    double d =
                        p.DistanceTo(
                            cr.Origen);

                    if (d >
                        radioLocal)
                    {
                        continue;
                    }

                    double existente;

                    if (!candidatos.TryGetValue(
                        cr.NodoId,
                        out existente) ||
                        d < existente)
                    {
                        candidatos[cr.NodoId] =
                            d;
                    }
                }
            }

            if (candidatos.Count == 0)
                return new List<Anclaje>();

            // --------------------------------------------------------
            // 3) PODA LOCAL.
            //
            // Conservamos:
            // - todas las conexiones físicas exactas (d = 0);
            // - y las ramas geométricas próximas al mejor conector.
            //
            // Así A puede ofrecer simultáneamente:
            // rígido + flexible, pero NO tubos situados a varios metros.
            // --------------------------------------------------------
            double minimo =
                candidatos
                    .Values
                    .Min();

            double margenLocal =
                UnitUtils.ConvertToInternalUnits(
                    150.0,
                    UnitTypeId.Millimeters);

            double limiteLocal =
                Math.Min(
                    radioLocal,
                    minimo + margenLocal);

            List<Anclaje> resultado =
                candidatos
                    .Where(
                        kv =>
                            kv.Value <= 1e-9 ||
                            kv.Value <= limiteLocal)
                    .OrderBy(
                        kv => kv.Value)
                    .ThenBy(
                        kv => kv.Key)
                    .Take(8)
                    .Select(
                        kv => new Anclaje()
                        {
                            NodoId =
                                kv.Key,

                            Distancia =
                                kv.Value
                        })
                    .ToList();

            return resultado;
        }

        // ============================================================
        // DIJKSTRA SOBRE ELEMENTOS DE LA RED
        //
        // No se genera un grafo global N x N.
        // Los vecinos de cada nodo se obtienen solo cuando Dijkstra
        // visita ese elemento.
        // ============================================================
        private static ResultadoRuta BuscarRutaMasCorta(
            MapaRuta mapa,
            List<Anclaje> inicios,
            List<Anclaje> finales,
            double toleranciaSalto)
        {
            if (mapa == null ||
                mapa.Nodos.Count == 0 ||
                inicios == null ||
                finales == null ||
                inicios.Count == 0 ||
                finales.Count == 0)
            {
                return null;
            }

            IndiceEspacial indice =
                mapa.IndiceConectores;

            if (indice == null)
            {
                indice =
                    new IndiceEspacial(
                        mapa.Conectores,
                        UnitUtils.ConvertToInternalUnits(
                            250.0,
                            UnitTypeId.Millimeters));
            }

            Dictionary<long, double> distancia =
                new Dictionary<long, double>();

            HashSet<long> cerrados =
                new HashSet<long>();

            Dictionary<long, long> previo =
                new Dictionary<long, long>();

            Dictionary<long, long> origen =
                new Dictionary<long, long>();

            Dictionary<long, double> costoFinal =
                new Dictionary<long, double>();

            foreach (Anclaje fin
                in finales)
            {
                double actual;

                if (!costoFinal.TryGetValue(
                    fin.NodoId,
                    out actual) ||
                    fin.Distancia < actual)
                {
                    costoFinal[fin.NodoId] =
                        fin.Distancia;
                }
            }

            SortedSet<ItemCola> cola =
                new SortedSet<ItemCola>();

            long secuencia =
                0;

            foreach (Anclaje inicio
                in inicios)
            {
                NodoRuta nodo;

                if (!mapa.Nodos.TryGetValue(
                    inicio.NodoId,
                    out nodo))
                {
                    continue;
                }

                double costo =
                    inicio.Distancia +
                    nodo.CostoInterno * 0.5;

                double existente;

                if (!distancia.TryGetValue(
                    nodo.Id,
                    out existente) ||
                    costo < existente)
                {
                    distancia[nodo.Id] =
                        costo;

                    origen[nodo.Id] =
                        nodo.Id;

                    cola.Add(
                        new ItemCola(
                            nodo.Id,
                            costo,
                            secuencia++));
                }
            }

            if (cola.Count == 0)
                return null;

            double mejorFinal =
                double.PositiveInfinity;

            long mejorNodoFinal =
                -1;

            long mejorNodoInicio =
                -1;

            while (cola.Count > 0)
            {
                ItemCola item =
                    cola.Min;

                cola.Remove(
                    item);

                double distanciaActual;

                if (!distancia.TryGetValue(
                    item.NodoId,
                    out distanciaActual))
                {
                    continue;
                }

                if (item.Distancia >
                    distanciaActual + 1e-9)
                {
                    continue;
                }

                // Un nodo queda cerrado la primera vez que sale con
                // su menor distancia. Así no calculamos sus vecinos
                // varias veces por entradas duplicadas en la cola.
                if (cerrados.Contains(
                    item.NodoId))
                {
                    continue;
                }

                cerrados.Add(
                    item.NodoId);

                // Si la menor distancia pendiente ya supera la mejor
                // ruta encontrada, terminar.
                if (item.Distancia >=
                    mejorFinal)
                {
                    break;
                }

                double distanciaHastaB;

                if (costoFinal.TryGetValue(
                    item.NodoId,
                    out distanciaHastaB))
                {
                    NodoRuta nodoFinal =
                        mapa.Nodos[item.NodoId];

                    double total =
                        item.Distancia +
                        nodoFinal.CostoInterno * 0.5 +
                        distanciaHastaB;

                    if (total < mejorFinal)
                    {
                        mejorFinal =
                            total;

                        mejorNodoFinal =
                            item.NodoId;

                        long idInicio;

                        mejorNodoInicio =
                            origen.TryGetValue(
                                item.NodoId,
                                out idInicio)
                                ? idInicio
                                : item.NodoId;
                    }
                }

                NodoRuta nodoActual =
                    mapa.Nodos[item.NodoId];

                List<VecinoRuta> vecinos =
                    ObtenerVecinos(
                        nodoActual,
                        mapa,
                        indice,
                        toleranciaSalto);

                foreach (VecinoRuta vecino
                    in vecinos)
                {
                    NodoRuta nodoVecino;

                    if (!mapa.Nodos.TryGetValue(
                        vecino.NodoId,
                        out nodoVecino))
                    {
                        continue;
                    }

                    // Medio costo del actual + hueco + medio costo
                    // del siguiente. Los elementos intermedios terminan
                    // acumulando aproximadamente toda su longitud.
                    double costoArista =
                        nodoActual.CostoInterno * 0.5 +
                        vecino.Separacion +
                        nodoVecino.CostoInterno * 0.5;

                    double nueva =
                        item.Distancia +
                        costoArista;

                    double previa;

                    if (!distancia.TryGetValue(
                        vecino.NodoId,
                        out previa) ||
                        nueva + 1e-9 < previa)
                    {
                        distancia[vecino.NodoId] =
                            nueva;

                        previo[vecino.NodoId] =
                            item.NodoId;

                        long idInicio;

                        origen[vecino.NodoId] =
                            origen.TryGetValue(
                                item.NodoId,
                                out idInicio)
                                ? idInicio
                                : item.NodoId;

                        cola.Add(
                            new ItemCola(
                                vecino.NodoId,
                                nueva,
                                secuencia++));
                    }
                }
            }

            if (mejorNodoFinal < 0)
                return null;

            List<long> ruta =
                new List<long>();

            long cursor =
                mejorNodoFinal;

            ruta.Add(
                cursor);

            while (cursor !=
                mejorNodoInicio)
            {
                long anterior;

                if (!previo.TryGetValue(
                    cursor,
                    out anterior))
                {
                    return null;
                }

                cursor =
                    anterior;

                ruta.Add(
                    cursor);
            }

            ruta.Reverse();

            return new ResultadoRuta()
            {
                ElementIds =
                    ruta
                        .Select(
                            id => mapa.Nodos[id].Elemento.Id)
                        .ToList(),

                CostoInterno =
                    mejorFinal,

                IdAnclajeInicio =
                    mejorNodoInicio,

                IdAnclajeFin =
                    mejorNodoFinal
            };
        }

        // ============================================================
        // VECINOS DE UN ELEMENTO
        // ============================================================
        private static List<VecinoRuta> ObtenerVecinos(
            NodoRuta nodo,
            MapaRuta mapa,
            IndiceEspacial indice,
            double toleranciaSalto)
        {
            Dictionary<long, double> resultado =
                new Dictionary<long, double>();

            foreach (ConectorRuta cr
                in nodo.Conectores)
            {
                bool encontroConexionFisica =
                    false;

                // ----------------------------------------------------
                // 1. CONEXIONES FÍSICAS REALES DE REVIT
                // ----------------------------------------------------
                foreach (Connector refCon
                    in ObtenerReferenciasFisicas(
                        cr.Conector))
                {
                    if (refCon == null ||
                        refCon.Owner == null)
                    {
                        continue;
                    }

                    long idOtro =
                        refCon.Owner.Id.Value;

                    if (idOtro ==
                        nodo.Id)
                    {
                        continue;
                    }

                    if (!mapa.Nodos.ContainsKey(
                        idOtro))
                    {
                        continue;
                    }

                    encontroConexionFisica =
                        true;

                    AgregarVecino(
                        resultado,
                        idOtro,
                        0.0);
                }

                // ----------------------------------------------------
                // 2. PEQUEÑOS HUECOS ENTRE EXTREMOS
                //
                // Solamente si este conector no encontró una unión
                // física hacia otro elemento de la red.
                // ----------------------------------------------------
                if (!encontroConexionFisica &&
                    toleranciaSalto > 1e-9)
                {
                    foreach (ConectorRuta otro
                        in indice.Buscar(
                            cr.Origen,
                            toleranciaSalto))
                    {
                        if (otro.NodoId ==
                            nodo.Id)
                        {
                            continue;
                        }

                        double d =
                            cr.Origen.DistanceTo(
                                otro.Origen);

                        if (d >
                            toleranciaSalto)
                        {
                            continue;
                        }

                        AgregarVecino(
                            resultado,
                            otro.NodoId,
                            d);
                    }
                }
            }

            return resultado
                .Select(
                    kv => new VecinoRuta()
                    {
                        NodoId =
                            kv.Key,

                        Separacion =
                            kv.Value
                    })
                .ToList();
        }

        private static void AgregarVecino(
            Dictionary<long, double> vecinos,
            long id,
            double separacion)
        {
            double existente;

            if (!vecinos.TryGetValue(
                id,
                out existente) ||
                separacion < existente)
            {
                vecinos[id] =
                    separacion;
            }
        }

        // ============================================================
        // CONNECTORS
        // ============================================================
        private static List<Connector> ObtenerConectoresFisicos(
            Element elemento)
        {
            List<Connector> resultado =
                new List<Connector>();

            if (elemento == null)
                return resultado;

            MEPCurve curva =
                elemento as MEPCurve;

            if (curva != null)
            {
                try
                {
                    ConnectorManager manager =
                        curva.ConnectorManager;

                    if (manager != null)
                    {
                        foreach (Connector c
                            in manager.Connectors)
                        {
                            if (c != null &&
                                EsConectorFisico(c))
                            {
                                resultado.Add(c);
                            }
                        }
                    }
                }
                catch
                {
                }

                return resultado;
            }

            FamilyInstance fi =
                elemento as FamilyInstance;

            if (fi != null)
            {
                try
                {
                    if (fi.MEPModel != null &&
                        fi.MEPModel.ConnectorManager != null)
                    {
                        foreach (Connector c
                            in fi.MEPModel.ConnectorManager.Connectors)
                        {
                            if (c != null &&
                                EsConectorFisico(c))
                            {
                                resultado.Add(c);
                            }
                        }
                    }
                }
                catch
                {
                }
            }

            return resultado;
        }

        private static bool EsConectorFisico(
            Connector c)
        {
            if (c == null)
                return false;

            try
            {
                return
                    c.ConnectorType ==
                        ConnectorType.End ||
                    c.ConnectorType ==
                        ConnectorType.Curve ||
                    c.ConnectorType ==
                        ConnectorType.Physical;
            }
            catch
            {
                return false;
            }
        }

        private static List<Connector> ObtenerReferenciasFisicas(
            Connector c)
        {
            List<Connector> resultado =
                new List<Connector>();

            if (c == null)
                return resultado;

            try
            {
                if (!c.IsConnected)
                    return resultado;
            }
            catch
            {
                return resultado;
            }

            ConnectorSet refs =
                null;

            try
            {
                refs =
                    c.AllRefs;
            }
            catch
            {
                refs = null;
            }

            if (refs == null)
                return resultado;

            foreach (Connector otro
                in refs)
            {
                if (otro == null ||
                    otro.Owner == null)
                {
                    continue;
                }

                if (c.Owner != null &&
                    otro.Owner.Id.Value ==
                        c.Owner.Id.Value)
                {
                    continue;
                }

                if (!EsConectorFisico(
                    otro))
                {
                    continue;
                }

                resultado.Add(
                    otro);
            }

            return resultado;
        }

        private static XYZ ObtenerOrigenSeguro(
            Connector c)
        {
            if (c == null)
                return null;

            try
            {
                return c.Origin;
            }
            catch
            {
                return null;
            }
        }

        // ============================================================
        // COSTO / LONGITUD DE CADA ELEMENTO DE RED
        // ============================================================
        private static double ObtenerCostoInternoElemento(
            Element elemento,
            List<Connector> conectores,
            bool esCajaPuente)
        {
            // Conduit / bandeja:
            // usar longitud real de LocationCurve.
            try
            {
                LocationCurve lc =
                    elemento.Location as LocationCurve;

                if (lc != null &&
                    lc.Curve != null &&
                    lc.Curve.Length > 1e-9)
                {
                    return lc.Curve.Length;
                }
            }
            catch
            {
            }

            // Fittings / cajas:
            // usar la mayor separación entre sus conectores.
            double maximo =
                0.0;

            for (int i = 0;
                i < conectores.Count;
                i++)
            {
                XYZ a =
                    ObtenerOrigenSeguro(
                        conectores[i]);

                if (a == null)
                    continue;

                for (int j = i + 1;
                    j < conectores.Count;
                    j++)
                {
                    XYZ b =
                        ObtenerOrigenSeguro(
                            conectores[j]);

                    if (b == null)
                        continue;

                    double d =
                        a.DistanceTo(b);

                    if (d > maximo)
                        maximo = d;
                }
            }

            double minimo =
                UnitUtils.ConvertToInternalUnits(
                    esCajaPuente
                        ? 20.0
                        : 10.0,
                    UnitTypeId.Millimeters);

            return Math.Max(
                maximo,
                minimo);
        }

        // ============================================================
        // ÍNDICE ESPACIAL DE CONNECTOR.ORIGIN
        //
        // Evita comparar cada extremo contra todos los demás cuando
        // se necesita puentear un pequeño hueco.
        // ============================================================
        private struct ClaveCelda : IEquatable<ClaveCelda>
        {
            public int X;
            public int Y;
            public int Z;

            public ClaveCelda(
                int x,
                int y,
                int z)
            {
                X = x;
                Y = y;
                Z = z;
            }

            public bool Equals(
                ClaveCelda other)
            {
                return
                    X == other.X &&
                    Y == other.Y &&
                    Z == other.Z;
            }

            public override bool Equals(
                object obj)
            {
                if (!(obj is ClaveCelda))
                    return false;

                return Equals(
                    (ClaveCelda)obj);
            }

            public override int GetHashCode()
            {
                unchecked
                {
                    int hash = 17;
                    hash = hash * 31 + X;
                    hash = hash * 31 + Y;
                    hash = hash * 31 + Z;
                    return hash;
                }
            }
        }

        private class IndiceEspacial
        {
            private readonly double _celda;

            private readonly Dictionary<ClaveCelda, List<ConectorRuta>> _mapa =
                new Dictionary<ClaveCelda, List<ConectorRuta>>();

            public IndiceEspacial(
                IList<ConectorRuta> conectores,
                double tamanoCelda)
            {
                _celda =
                    Math.Max(
                        tamanoCelda,
                        1e-6);

                if (conectores == null)
                    return;

                foreach (ConectorRuta c
                    in conectores)
                {
                    if (c == null ||
                        c.Origen == null)
                    {
                        continue;
                    }

                    ClaveCelda key =
                        Clave(
                            c.Origen);

                    List<ConectorRuta> lista;

                    if (!_mapa.TryGetValue(
                        key,
                        out lista))
                    {
                        lista =
                            new List<ConectorRuta>();

                        _mapa[key] =
                            lista;
                    }

                    lista.Add(
                        c);
                }
            }

            public IEnumerable<ConectorRuta> Buscar(
                XYZ punto,
                double radio)
            {
                if (punto == null)
                    yield break;

                int ix =
                    (int)Math.Floor(
                        punto.X / _celda);

                int iy =
                    (int)Math.Floor(
                        punto.Y / _celda);

                int iz =
                    (int)Math.Floor(
                        punto.Z / _celda);

                int n =
                    Math.Max(
                        1,
                        (int)Math.Ceiling(
                            radio / _celda));

                for (int dx = -n;
                    dx <= n;
                    dx++)
                {
                    for (int dy = -n;
                        dy <= n;
                        dy++)
                    {
                        for (int dz = -n;
                            dz <= n;
                            dz++)
                        {
                            ClaveCelda key =
                                new ClaveCelda(
                                    ix + dx,
                                    iy + dy,
                                    iz + dz);

                            List<ConectorRuta> lista;

                            if (!_mapa.TryGetValue(
                                key,
                                out lista))
                            {
                                continue;
                            }

                            foreach (ConectorRuta c
                                in lista)
                            {
                                yield return c;
                            }
                        }
                    }
                }
            }

            private ClaveCelda Clave(
                XYZ p)
            {
                return new ClaveCelda(
                    (int)Math.Floor(
                        p.X / _celda),
                    (int)Math.Floor(
                        p.Y / _celda),
                    (int)Math.Floor(
                        p.Z / _celda));
            }
        }

        // ============================================================
        // SEGUNDA PASADA:
        // CAJAS / APARATOS / DISPOSITIVOS FÍSICAMENTE SOBRE LA RUTA
        // ============================================================
        private static List<Element> AgregarDispositivosFisicosSobreRuta(
            Document doc,
            List<Element> rutaBase,
            ElementId excluirA,
            ElementId excluirB,
            double tolerancia,
            out int agregados)
        {
            agregados = 0;

            if (rutaBase == null)
                rutaBase = new List<Element>();

            List<Element> rutaLimpia =
                rutaBase
                    .Where(e => e != null)
                    .GroupBy(e => e.Id.Value)
                    .Select(g => g.First())
                    .ToList();

            if (rutaLimpia.Count == 0)
                return rutaLimpia;

            // --------------------------------------------------------
            // CACHE DEL BACKBONE
            //
            // BoundingBox, LocationCurve y Connector.Origin se leen
            // UNA sola vez por tramo.
            // --------------------------------------------------------
            List<DatosTramoRuta> datosRuta =
                PrepararDatosRuta(
                    rutaLimpia);

            if (datosRuta.Count == 0)
                return rutaLimpia;

            HashSet<long> idsExistentes =
                new HashSet<long>(
                    rutaLimpia.Select(
                        e => e.Id.Value));

            Dictionary<int, List<ElementoIntermedioDetectado>> porIndice =
                new Dictionary<int, List<ElementoIntermedioDetectado>>();

            // --------------------------------------------------------
            // ENVOLVENTE DE LA RUTA
            //
            // Antes se recorrían TODOS los aparatos/dispositivos del
            // proyecto. Ahora Revit descarta primero, mediante un Quick
            // Filter, todo lo que ni siquiera intersecta la caja global
            // del recorrido expandida por la tolerancia.
            // --------------------------------------------------------
            Outline envolvente =
                CrearEnvolventeRuta(
                    datosRuta,
                    tolerancia);

            List<BuiltInCategory> categoriasDispositivos =
                new List<BuiltInCategory>(
                    CategoriasDispositivos);

            ElementMulticategoryFilter filtroCategorias =
                new ElementMulticategoryFilter(
                    categoriasDispositivos);

            FilteredElementCollector collector =
                new FilteredElementCollector(doc)
                    .WherePasses(
                        filtroCategorias)
                    .WhereElementIsNotElementType();

            if (envolvente != null)
            {
                BoundingBoxIntersectsFilter filtroCaja =
                    new BoundingBoxIntersectsFilter(
                        envolvente);

                collector =
                    collector.WherePasses(
                        filtroCaja);
            }

            foreach (Element candidato
                in collector)
            {
                if (candidato == null)
                    continue;

                long id =
                    candidato.Id.Value;

                if (excluirA != null &&
                    id == excluirA.Value)
                {
                    continue;
                }

                if (excluirB != null &&
                    id == excluirB.Value)
                {
                    continue;
                }

                if (idsExistentes.Contains(id))
                    continue;

                ElementoIntermedioDetectado detectado =
                    DetectarElementoSobreRutaRapido(
                        candidato,
                        datosRuta,
                        tolerancia);

                if (detectado == null)
                    continue;

                List<ElementoIntermedioDetectado> lista;

                if (!porIndice.TryGetValue(
                    detectado.IndiceRuta,
                    out lista))
                {
                    lista =
                        new List<ElementoIntermedioDetectado>();

                    porIndice[detectado.IndiceRuta] =
                        lista;
                }

                lista.Add(
                    detectado);

                idsExistentes.Add(
                    id);

                agregados++;
            }

            List<Element> resultado =
                new List<Element>();

            for (int i = 0;
                i < rutaLimpia.Count;
                i++)
            {
                resultado.Add(
                    rutaLimpia[i]);

                List<ElementoIntermedioDetectado> lista;

                if (!porIndice.TryGetValue(
                    i,
                    out lista))
                {
                    continue;
                }

                foreach (ElementoIntermedioDetectado d
                    in lista
                        .OrderBy(x => x.Distancia))
                {
                    resultado.Add(
                        d.Elemento);
                }
            }

            return resultado
                .GroupBy(e => e.Id.Value)
                .Select(g => g.First())
                .ToList();
        }

        private static List<DatosTramoRuta> PrepararDatosRuta(
            IList<Element> ruta)
        {
            List<DatosTramoRuta> resultado =
                new List<DatosTramoRuta>();

            if (ruta == null)
                return resultado;

            for (int i = 0;
                i < ruta.Count;
                i++)
            {
                Element e =
                    ruta[i];

                if (e == null)
                    continue;

                DatosTramoRuta dato =
                    new DatosTramoRuta();

                dato.IndiceRuta =
                    i;

                dato.Elemento =
                    e;

                dato.Caja =
                    ObtenerBoundingBoxSeguro(
                        e);

                try
                {
                    LocationCurve lc =
                        e.Location as LocationCurve;

                    dato.Curva =
                        lc != null
                            ? lc.Curve
                            : null;
                }
                catch
                {
                    dato.Curva =
                        null;
                }

                foreach (Connector c
                    in ObtenerTodosLosConectores(
                        e))
                {
                    XYZ p =
                        ObtenerOrigenSeguro(
                            c);

                    if (p != null)
                    {
                        dato.OrigenesConectores.Add(
                            p);
                    }
                }

                resultado.Add(
                    dato);
            }

            return resultado;
        }

        private static Outline CrearEnvolventeRuta(
            IList<DatosTramoRuta> datosRuta,
            double tolerancia)
        {
            if (datosRuta == null ||
                datosRuta.Count == 0)
            {
                return null;
            }

            bool inicializado =
                false;

            double minX = 0.0;
            double minY = 0.0;
            double minZ = 0.0;
            double maxX = 0.0;
            double maxY = 0.0;
            double maxZ = 0.0;

            foreach (DatosTramoRuta dato
                in datosRuta)
            {
                if (dato == null ||
                    dato.Caja == null)
                {
                    continue;
                }

                if (!inicializado)
                {
                    minX = dato.Caja.Min.X;
                    minY = dato.Caja.Min.Y;
                    minZ = dato.Caja.Min.Z;

                    maxX = dato.Caja.Max.X;
                    maxY = dato.Caja.Max.Y;
                    maxZ = dato.Caja.Max.Z;

                    inicializado =
                        true;
                }
                else
                {
                    minX =
                        Math.Min(
                            minX,
                            dato.Caja.Min.X);

                    minY =
                        Math.Min(
                            minY,
                            dato.Caja.Min.Y);

                    minZ =
                        Math.Min(
                            minZ,
                            dato.Caja.Min.Z);

                    maxX =
                        Math.Max(
                            maxX,
                            dato.Caja.Max.X);

                    maxY =
                        Math.Max(
                            maxY,
                            dato.Caja.Max.Y);

                    maxZ =
                        Math.Max(
                            maxZ,
                            dato.Caja.Max.Z);
                }
            }

            if (!inicializado)
                return null;

            XYZ min =
                new XYZ(
                    minX - tolerancia,
                    minY - tolerancia,
                    minZ - tolerancia);

            XYZ max =
                new XYZ(
                    maxX + tolerancia,
                    maxY + tolerancia,
                    maxZ + tolerancia);

            return new Outline(
                min,
                max);
        }

        private static ElementoIntermedioDetectado DetectarElementoSobreRutaRapido(
            Element candidato,
            IList<DatosTramoRuta> ruta,
            double tolerancia)
        {
            BoundingBoxXYZ cajaCandidato =
                ObtenerBoundingBoxSeguro(
                    candidato);

            if (cajaCandidato == null)
                return null;

            List<XYZ> puntosCandidato =
                ObtenerPuntosDeteccionDispositivo(
                    candidato);

            double mejor =
                double.PositiveInfinity;

            int mejorIndice =
                -1;

            List<int> indicesContacto =
                new List<int>();

            foreach (DatosTramoRuta tramo
                in ruta)
            {
                if (tramo == null ||
                    tramo.Caja == null)
                {
                    continue;
                }

                double dCaja =
                    DistanciaEntreCajasSegura(
                        cajaCandidato,
                        tramo.Caja);

                if (dCaja >
                    tolerancia)
                {
                    continue;
                }

                double distancia =
                    dCaja;

                if (tramo.Curva != null &&
                    puntosCandidato.Count > 0)
                {
                    double dCurva =
                        double.PositiveInfinity;

                    foreach (XYZ p
                        in puntosCandidato)
                    {
                        try
                        {
                            IntersectionResult ir =
                                tramo.Curva.Project(
                                    p);

                            if (ir != null &&
                                ir.XYZPoint != null)
                            {
                                double d =
                                    p.DistanceTo(
                                        ir.XYZPoint);

                                if (d < dCurva)
                                    dCurva = d;
                            }
                        }
                        catch
                        {
                        }
                    }

                    if (!double.IsInfinity(
                        dCurva))
                    {
                        distancia =
                            Math.Min(
                                distancia,
                                dCurva);
                    }
                }

                foreach (XYZ p
                    in puntosCandidato)
                {
                    foreach (XYZ origen
                        in tramo.OrigenesConectores)
                    {
                        double d =
                            p.DistanceTo(
                                origen);

                        if (d < distancia)
                            distancia = d;
                    }
                }

                if (distancia <= tolerancia)
                {
                    indicesContacto.Add(
                        tramo.IndiceRuta);

                    if (distancia < mejor)
                    {
                        mejor =
                            distancia;

                        mejorIndice =
                            tramo.IndiceRuta;
                    }
                }
            }

            if (mejorIndice < 0 ||
                mejor > tolerancia)
            {
                return null;
            }

            // Misma lógica V12:
            // el dispositivo debe relacionarse con al menos DOS
            // elementos consecutivos o casi consecutivos del backbone.
            bool tienePasoReal =
                false;

            for (int a = 0;
                a < indicesContacto.Count &&
                !tienePasoReal;
                a++)
            {
                for (int b = a + 1;
                    b < indicesContacto.Count;
                    b++)
                {
                    int diferencia =
                        Math.Abs(
                            indicesContacto[a] -
                            indicesContacto[b]);

                    if (diferencia >= 1 &&
                        diferencia <= 2)
                    {
                        tienePasoReal =
                            true;

                        break;
                    }
                }
            }

            if (!tienePasoReal)
                return null;

            return new ElementoIntermedioDetectado()
            {
                Elemento =
                    candidato,

                IndiceRuta =
                    mejorIndice,

                Distancia =
                    mejor
            };
        }

        private static List<XYZ> ObtenerPuntosDeteccionDispositivo(
            Element elemento)
        {
            List<XYZ> puntos =
                new List<XYZ>();

            // Usar TODOS los connectors, no solo End/Curve/Physical.
            // Algunas familias de cajas tienen conectores configurados
            // de forma distinta y aun así sus Origin son útiles.
            foreach (Connector c
                in ObtenerTodosLosConectores(
                    elemento))
            {
                XYZ p =
                    ObtenerOrigenSeguro(
                        c);

                if (p != null)
                {
                    AgregarPuntoDeteccion(
                        puntos,
                        p);
                }
            }

            BoundingBoxXYZ bb =
                ObtenerBoundingBoxSeguro(
                    elemento);

            if (bb != null)
            {
                XYZ centro =
                    new XYZ(
                        (bb.Min.X + bb.Max.X) * 0.5,
                        (bb.Min.Y + bb.Max.Y) * 0.5,
                        (bb.Min.Z + bb.Max.Z) * 0.5);

                AgregarPuntoDeteccion(
                    puntos,
                    centro);

                // Puntos medios de las 6 caras ayudan con cajas cuyo
                // punto de inserción está desplazado del conduit.
                AgregarPuntoDeteccion(
                    puntos,
                    new XYZ(
                        bb.Min.X,
                        centro.Y,
                        centro.Z));

                AgregarPuntoDeteccion(
                    puntos,
                    new XYZ(
                        bb.Max.X,
                        centro.Y,
                        centro.Z));

                AgregarPuntoDeteccion(
                    puntos,
                    new XYZ(
                        centro.X,
                        bb.Min.Y,
                        centro.Z));

                AgregarPuntoDeteccion(
                    puntos,
                    new XYZ(
                        centro.X,
                        bb.Max.Y,
                        centro.Z));

                AgregarPuntoDeteccion(
                    puntos,
                    new XYZ(
                        centro.X,
                        centro.Y,
                        bb.Min.Z));

                AgregarPuntoDeteccion(
                    puntos,
                    new XYZ(
                        centro.X,
                        centro.Y,
                        bb.Max.Z));
            }

            return puntos;
        }

        private static void AgregarPuntoDeteccion(
            List<XYZ> puntos,
            XYZ punto)
        {
            if (punto == null)
                return;

            double toleranciaDuplicado =
                UnitUtils.ConvertToInternalUnits(
                    0.5,
                    UnitTypeId.Millimeters);

            foreach (XYZ existente
                in puntos)
            {
                if (existente.DistanceTo(
                    punto) <=
                    toleranciaDuplicado)
                {
                    return;
                }
            }

            puntos.Add(
                punto);
        }

        private static List<Connector> ObtenerTodosLosConectores(
            Element elemento)
        {
            List<Connector> resultado =
                new List<Connector>();

            if (elemento == null)
                return resultado;

            MEPCurve curva =
                elemento as MEPCurve;

            if (curva != null)
            {
                try
                {
                    ConnectorManager manager =
                        curva.ConnectorManager;

                    if (manager != null)
                    {
                        foreach (Connector c
                            in manager.Connectors)
                        {
                            if (c != null)
                                resultado.Add(c);
                        }
                    }
                }
                catch
                {
                }

                return resultado;
            }

            FamilyInstance fi =
                elemento as FamilyInstance;

            if (fi != null)
            {
                try
                {
                    if (fi.MEPModel != null &&
                        fi.MEPModel.ConnectorManager != null)
                    {
                        foreach (Connector c
                            in fi.MEPModel.ConnectorManager.Connectors)
                        {
                            if (c != null)
                                resultado.Add(c);
                        }
                    }
                }
                catch
                {
                }
            }

            return resultado;
        }

        private static BoundingBoxXYZ ObtenerBoundingBoxSeguro(
            Element elemento)
        {
            if (elemento == null)
                return null;

            try
            {
                return elemento.get_BoundingBox(
                    null);
            }
            catch
            {
                return null;
            }
        }

        private static double DistanciaEntreCajasSegura(
            BoundingBoxXYZ a,
            BoundingBoxXYZ b)
        {
            if (a == null ||
                b == null)
            {
                return double.PositiveInfinity;
            }

            double dx =
                DistanciaIntervalosSegura(
                    a.Min.X,
                    a.Max.X,
                    b.Min.X,
                    b.Max.X);

            double dy =
                DistanciaIntervalosSegura(
                    a.Min.Y,
                    a.Max.Y,
                    b.Min.Y,
                    b.Max.Y);

            double dz =
                DistanciaIntervalosSegura(
                    a.Min.Z,
                    a.Max.Z,
                    b.Min.Z,
                    b.Max.Z);

            return Math.Sqrt(
                dx * dx +
                dy * dy +
                dz * dz);
        }

        private static double DistanciaIntervalosSegura(
            double minA,
            double maxA,
            double minB,
            double maxB)
        {
            if (maxA < minB)
                return minB - maxA;

            if (maxB < minA)
                return minA - maxB;

            return 0.0;
        }

        private class DatosTramoRuta
        {
            public int IndiceRuta;
            public Element Elemento;
            public BoundingBoxXYZ Caja;
            public Curve Curva;

            public List<XYZ> OrigenesConectores =
                new List<XYZ>();
        }

        private class ElementoIntermedioDetectado
        {
            public Element Elemento;
            public int IndiceRuta;
            public double Distancia;
        }

        // ============================================================
        // ESCRIBIR SOLO LOS PARÁMETROS CONFIGURADOS POR EL USUARIO
        // ============================================================
        private static void AplicarAsignacionesParametros(
            Document doc,
            IList<Element> elementosRuta,
            IList<MYG_InformacionCablesCircuito58.AsignacionParametro> asignaciones,
            MYG_InformacionCablesCircuito58.ModoEscritura modoEscritura,
            out int escriturasRealizadas,
            out int elementosConEscritura,
            out int omitidos)
        {
            escriturasRealizadas =
                0;

            elementosConEscritura =
                0;

            omitidos =
                0;

            if (elementosRuta == null ||
                asignaciones == null ||
                elementosRuta.Count == 0 ||
                asignaciones.Count == 0)
            {
                return;
            }

            using (Transaction t =
                new Transaction(
                    doc,
                    "MYG - Información cables circuito"))
            {
                t.Start();

                foreach (Element elemento
                    in elementosRuta)
                {
                    if (elemento == null)
                        continue;

                    bool modificoElemento =
                        false;

                    foreach (MYG_InformacionCablesCircuito58.AsignacionParametro asignacion
                        in asignaciones)
                    {
                        if (asignacion == null ||
                            String.IsNullOrWhiteSpace(
                                asignacion.NombreParametro))
                        {
                            continue;
                        }

                        Parameter parametro =
                            BuscarParametroEscribible(
                                elemento,
                                asignacion);

                        if (parametro == null)
                        {
                            omitidos++;
                            continue;
                        }

                        if (EscribirValorParametro(
                            doc,
                            parametro,
                            asignacion,
                            modoEscritura))
                        {
                            escriturasRealizadas++;
                            modificoElemento =
                                true;
                        }
                        else
                        {
                            omitidos++;
                        }
                    }

                    if (modificoElemento)
                        elementosConEscritura++;
                }

                t.Commit();
            }
        }

        private static Parameter BuscarParametroEscribible(
            Element elemento,
            MYG_InformacionCablesCircuito58.AsignacionParametro asignacion)
        {
            if (elemento == null ||
                asignacion == null)
            {
                return null;
            }

            IList<Parameter> parametros =
                elemento.GetParameters(
                    asignacion.NombreParametro);

            if (parametros == null ||
                parametros.Count == 0)
            {
                return null;
            }

            foreach (Parameter p
                in parametros)
            {
                if (p == null ||
                    p.IsReadOnly)
                {
                    continue;
                }

                if (EsTipoCompatible(
                    p.StorageType,
                    asignacion.Tipo))
                {
                    return p;
                }
            }

            return null;
        }

        private static bool EsTipoCompatible(
            StorageType storage,
            MYG_InformacionCablesCircuito58.TipoDatoParametro tipo)
        {
            if (tipo ==
                    MYG_InformacionCablesCircuito58.TipoDatoParametro.Texto &&
                storage ==
                    StorageType.String)
            {
                return true;
            }

            if (tipo ==
                    MYG_InformacionCablesCircuito58.TipoDatoParametro.NumeroEntero &&
                storage ==
                    StorageType.Integer)
            {
                return true;
            }

            if (tipo ==
                    MYG_InformacionCablesCircuito58.TipoDatoParametro.NumeroDecimal &&
                storage ==
                    StorageType.Double)
            {
                return true;
            }

            return false;
        }

        private static bool EscribirValorParametro(
            Document doc,
            Parameter parametro,
            MYG_InformacionCablesCircuito58.AsignacionParametro asignacion,
            MYG_InformacionCablesCircuito58.ModoEscritura modoEscritura)
        {
            try
            {
                if (parametro.StorageType == StorageType.String)
                {
                    if (modoEscritura ==
                        MYG_InformacionCablesCircuito58.ModoEscritura.Sumar)
                    {
                        return false;
                    }

                    parametro.Set(
                        asignacion.Valor ?? "");

                    return true;
                }

                if (parametro.StorageType == StorageType.Integer)
                {
                    int valorIngresado;

                    if (!Int32.TryParse(
                        (asignacion.Valor ?? "").Trim(),
                        out valorIngresado))
                    {
                        return false;
                    }

                    int valorFinal =
                        valorIngresado;

                    if (modoEscritura ==
                        MYG_InformacionCablesCircuito58.ModoEscritura.Sumar)
                    {
                        int actual = 0;

                        try
                        {
                            actual =
                                parametro.AsInteger();
                        }
                        catch
                        {
                            actual = 0;
                        }

                        valorFinal =
                            actual +
                            valorIngresado;
                    }

                    parametro.Set(
                        valorFinal);

                    return true;
                }

                if (parametro.StorageType == StorageType.Double)
                {
                    string texto =
                        (asignacion.Valor ?? "").Trim();

                    if (modoEscritura ==
                        MYG_InformacionCablesCircuito58.ModoEscritura.Reemplazar)
                    {
                        try
                        {
                            if (parametro.SetValueString(
                                texto))
                            {
                                return true;
                            }
                        }
                        catch
                        {
                        }

                        double valor;

                        if (!TryParseDoubleUsuario(
                            texto,
                            out valor))
                        {
                            return false;
                        }

                        parametro.Set(
                            valor);

                        return true;
                    }

                    double incrementoInterno;

                    if (!ObtenerIncrementoDoubleInterno(
                        doc,
                        parametro,
                        texto,
                        out incrementoInterno))
                    {
                        return false;
                    }

                    double actualDouble = 0.0;

                    try
                    {
                        actualDouble =
                            parametro.AsDouble();
                    }
                    catch
                    {
                        actualDouble = 0.0;
                    }

                    parametro.Set(
                        actualDouble +
                        incrementoInterno);

                    return true;
                }

                return false;
            }
            catch
            {
                return false;
            }
        }

        private static bool ObtenerIncrementoDoubleInterno(
            Document doc,
            Parameter parametro,
            string texto,
            out double valorInterno)
        {
            valorInterno = 0.0;

            if (doc == null ||
                parametro == null ||
                parametro.Definition == null)
            {
                return false;
            }

            try
            {
                ForgeTypeId specId =
                    parametro.Definition.GetDataType();

                if (specId != null &&
                    !specId.Empty())
                {
                    Units unidades =
                        doc.GetUnits();

                    double parsed;

                    if (UnitFormatUtils.TryParse(
                        unidades,
                        specId,
                        texto,
                        out parsed))
                    {
                        valorInterno =
                            parsed;

                        return true;
                    }
                }
            }
            catch
            {
            }

            double numero;

            if (TryParseDoubleUsuario(
                texto,
                out numero))
            {
                valorInterno =
                    numero;

                return true;
            }

            return false;
        }

        private static bool TryParseDoubleUsuario(
            string texto,
            out double valor)
        {
            valor = 0.0;

            if (String.IsNullOrWhiteSpace(texto))
                return false;

            if (Double.TryParse(
                texto,
                System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.CurrentCulture,
                out valor))
            {
                return true;
            }

            return Double.TryParse(
                texto.Trim().Replace(',', '.'),
                System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture,
                out valor);
        }

        // ============================================================
        // HELPERS
        // ============================================================
        private static XYZ ObtenerCentroElemento(
            Element elemento)
        {
            if (elemento == null)
                return null;

            try
            {
                BoundingBoxXYZ bb =
                    elemento.get_BoundingBox(
                        null);

                if (bb == null)
                    return null;

                return new XYZ(
                    (bb.Min.X + bb.Max.X) * 0.5,
                    (bb.Min.Y + bb.Max.Y) * 0.5,
                    (bb.Min.Z + bb.Max.Z) * 0.5);
            }
            catch
            {
                return null;
            }
        }

        private static string ObtenerNombreCategoria(
            Element elemento)
        {
            if (elemento == null ||
                elemento.Category == null)
            {
                return "Sin categoría";
            }

            try
            {
                return elemento.Category.Name;
            }
            catch
            {
                return "Categoría";
            }
        }

        private static string ObtenerNombreElemento(
            Element elemento)
        {
            if (elemento == null)
                return "Elemento";

            try
            {
                string categoria =
                    ObtenerNombreCategoria(
                        elemento);

                string nombre =
                    elemento.Name;

                if (string.IsNullOrWhiteSpace(
                    nombre))
                {
                    return categoria;
                }

                return
                    categoria +
                    " - " +
                    nombre;
            }
            catch
            {
                return
                    ObtenerNombreCategoria(
                        elemento);
            }
        }

        private static string FormatearAnclajes(
            MapaRuta mapa,
            List<Anclaje> anclajes)
        {
            if (anclajes == null ||
                anclajes.Count == 0)
            {
                return "ninguno";
            }

            List<string> datos =
                new List<string>();

            foreach (Anclaje a
                in anclajes)
            {
                NodoRuta nodo;

                if (!mapa.Nodos.TryGetValue(
                    a.NodoId,
                    out nodo))
                {
                    continue;
                }

                double mm =
                    UnitUtils.ConvertFromInternalUnits(
                        a.Distancia,
                        UnitTypeId.Millimeters);

                datos.Add(
                    a.NodoId +
                    " (" +
                    ObtenerNombreCategoria(
                        nodo.Elemento) +
                    ", " +
                    mm.ToString("0") +
                    " mm)");
            }

            return string.Join(
                ", ",
                datos);
        }

        private void Terminar(
            string mensaje)
        {
            if (Form == null ||
                Form.IsDisposed)
            {
                return;
            }

            Form.MarcarOperacionCompletada();

            Form.SetProcesando(
                false);

            Form.MostrarResultado(
                mensaje);
        }

        // ============================================================
        // CLASES AUXILIARES
        // ============================================================
        private class MapaRuta
        {
            public Dictionary<long, NodoRuta> Nodos =
                new Dictionary<long, NodoRuta>();

            public List<ConectorRuta> Conectores =
                new List<ConectorRuta>();

            public IndiceEspacial IndiceConectores;
        }

        private class NodoRuta
        {
            public long Id;
            public Element Elemento;
            public bool EsCajaPuente;
            public double CostoInterno;

            public List<ConectorRuta> Conectores =
                new List<ConectorRuta>();
        }

        private class ConectorRuta
        {
            public long NodoId;
            public Connector Conector;
            public XYZ Origen;
        }

        private class Anclaje
        {
            public long NodoId;
            public double Distancia;
        }

        private class VecinoRuta
        {
            public long NodoId;
            public double Separacion;
        }

        private class ResultadoRuta
        {
            public List<ElementId> ElementIds;
            public double CostoInterno;
            public long IdAnclajeInicio;
            public long IdAnclajeFin;
        }

        private class ItemCola : IComparable<ItemCola>
        {
            public long NodoId;
            public double Distancia;
            public long Secuencia;

            public ItemCola(
                long nodoId,
                double distancia,
                long secuencia)
            {
                NodoId =
                    nodoId;

                Distancia =
                    distancia;

                Secuencia =
                    secuencia;
            }

            public int CompareTo(
                ItemCola otro)
            {
                if (otro == null)
                    return 1;

                int c =
                    Distancia.CompareTo(
                        otro.Distancia);

                if (c != 0)
                    return c;

                c =
                    Secuencia.CompareTo(
                        otro.Secuencia);

                if (c != 0)
                    return c;

                return NodoId.CompareTo(
                    otro.NodoId);
            }
        }

        private class SelectorEquiposFiltro : ISelectionFilter
        {
            public bool AllowElement(
                Element elem)
            {
                if (elem == null ||
                    elem.Category == null)
                {
                    return false;
                }

                long idCategoria =
                    elem.Category.Id.Value;

                return
                    idCategoria == (long)BuiltInCategory.OST_ElectricalEquipment ||
                    idCategoria == (long)BuiltInCategory.OST_ElectricalFixtures ||
                    idCategoria == (long)BuiltInCategory.OST_CommunicationDevices ||
                    idCategoria == (long)BuiltInCategory.OST_DataDevices ||
                    idCategoria == (long)BuiltInCategory.OST_FireAlarmDevices ||
                    idCategoria == (long)BuiltInCategory.OST_LightingDevices ||
                    idCategoria == (long)BuiltInCategory.OST_LightingFixtures ||
                    idCategoria == (long)BuiltInCategory.OST_NurseCallDevices ||
                    idCategoria == (long)BuiltInCategory.OST_SecurityDevices ||
                    idCategoria == (long)BuiltInCategory.OST_TelephoneDevices ||
                    idCategoria == (long)BuiltInCategory.OST_MechanicalEquipment;
            }

            public bool AllowReference(
                Reference reference,
                XYZ position)
            {
                return false;
            }
        }
    }
}
