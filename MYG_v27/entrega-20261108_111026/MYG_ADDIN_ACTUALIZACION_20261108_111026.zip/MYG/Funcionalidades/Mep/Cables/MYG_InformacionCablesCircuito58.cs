using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // VENTANA 5.8 - INFORMACIÓN CABLES CIRCUITO
    // PEGAR DENTRO DEL MISMO NAMESPACE MYG_Addin DE TU CÓDIGO PRINCIPAL
    // SIN USING Y SIN DECLARAR NAMESPACE
    // =====================================

    public static class MYG_InformacionCablesCircuito58
    {
        internal enum Operacion
        {
            Ninguna = 0,
            CargarParametros = 1,
            SeleccionarYDetectar = 2,
            CerrarYLiberarVistaTemporal = 3
        }

        internal enum TipoDatoParametro
        {
            Texto = 0,
            NumeroEntero = 1,
            NumeroDecimal = 2
        }

        internal enum ModoEscritura
        {
            Reemplazar = 0,
            Sumar = 1
        }

        internal class ParametroDisponible
        {
            public string Nombre { get; set; }
            public TipoDatoParametro Tipo { get; set; }

            public string TipoVisible
            {
                get
                {
                    return Tipo == TipoDatoParametro.Texto
                        ? "Texto"
                        : "Número";
                }
            }
        }

        internal class AsignacionParametro
        {
            public string NombreParametro { get; set; }
            public string Valor { get; set; }
            public TipoDatoParametro Tipo { get; set; }
        }

        internal class InformacionCablesCircuitoForm : System.Windows.Forms.Form
        {
            private class FilaAsignacion
            {
                public System.Windows.Forms.Panel Contenedor;
                public System.Windows.Forms.ComboBox CmbParametro;
                public System.Windows.Forms.TextBox TxtValor;
                public System.Windows.Forms.Label LblTipo;
            }

            private System.Windows.Forms.TextBox txtToleranciaRuta;
            private System.Windows.Forms.TextBox txtAlcanceEquipo;
            private System.Windows.Forms.CheckBox chkSeleccionarRecorrido;
            private System.Windows.Forms.Button btnSeleccionarDetectar;
            private System.Windows.Forms.Button btnAgregarFila;
            private System.Windows.Forms.Button btnQuitarFila;
            private System.Windows.Forms.CheckBox chkReemplazar;
            private System.Windows.Forms.CheckBox chkSumar;
            private System.Windows.Forms.RichTextBox txtResultado;
            private System.Windows.Forms.Panel pnlFilasParametros;

            private readonly System.Collections.Generic.List<FilaAsignacion> _filas =
                new System.Collections.Generic.List<FilaAsignacion>();

            private readonly System.Collections.Generic.Dictionary<string, ParametroDisponible> _parametrosPorNombre =
                new System.Collections.Generic.Dictionary<string, ParametroDisponible>(
                    System.StringComparer.CurrentCultureIgnoreCase);

            private readonly System.Collections.Generic.List<ParametroDisponible> _parametrosDisponibles =
                new System.Collections.Generic.List<ParametroDisponible>();

            private const int MaxFilas = 10;

            // Cuando el usuario pulsa X no cerramos inmediatamente.
            // Primero pedimos al ExternalEvent que restaure la vista de Revit.
            private bool _cerrarDesdeHandler = false;
            private bool _cierreSolicitado = false;

            public Autodesk.Revit.UI.ExternalEvent EjecutarEvent;

            internal Operacion OperacionSolicitada
            {
                get;
                private set;
            }

            internal double ToleranciaRutaMm
            {
                get
                {
                    return LeerDouble(
                        txtToleranciaRuta.Text,
                        50.0);
                }
            }

            internal double AlcanceEquipoMm
            {
                get
                {
                    return LeerDouble(
                        txtAlcanceEquipo.Text,
                        2000.0);
                }
            }

            internal bool SeleccionarRecorrido
            {
                get
                {
                    return chkSeleccionarRecorrido.Checked;
                }
            }

            internal ModoEscritura ModoSeleccionado
            {
                get
                {
                    return chkSumar != null && chkSumar.Checked
                        ? ModoEscritura.Sumar
                        : ModoEscritura.Reemplazar;
                }
            }

            public InformacionCablesCircuitoForm()
            {
                OperacionSolicitada =
                    Operacion.Ninguna;

                this.Text =
                    "MEP 5.8 - Información cables circuito";

                this.Width =
                    790;

                this.Height =
                    735;

                this.StartPosition =
                    System.Windows.Forms.FormStartPosition.CenterScreen;

                this.FormBorderStyle =
                    System.Windows.Forms.FormBorderStyle.FixedDialog;

                this.MaximizeBox =
                    false;

                this.MinimizeBox =
                    true;

                this.BackColor =
                    System.Drawing.Color.FromArgb(
                        245,
                        247,
                        250);

                this.Font =
                    new System.Drawing.Font(
                        "Segoe UI",
                        9F);

                this.TopMost =
                    true;

                System.Windows.Forms.Label lblAutor =
                    new System.Windows.Forms.Label()
                    {
                        Text =
                            "Creado por: Ing. Marlon Yacila  |  MEP - Información cables circuito",

                        Left =
                            20,

                        Top =
                            10,

                        Width =
                            730,

                        Height =
                            20,

                        Font =
                            new System.Drawing.Font(
                                "Segoe UI",
                                8.5F,
                                System.Drawing.FontStyle.Bold),

                        ForeColor =
                            System.Drawing.Color.Gray
                    };

                System.Windows.Forms.Label lblTitulo =
                    new System.Windows.Forms.Label()
                    {
                        Text =
                            "01. DETECCIÓN DE RECORRIDO FÍSICO",

                        Left =
                            20,

                        Top =
                            42,

                        Width =
                            730,

                        Height =
                            22,

                        Font =
                            new System.Drawing.Font(
                                "Segoe UI",
                                9F,
                                System.Drawing.FontStyle.Bold),

                        ForeColor =
                            System.Drawing.Color.FromArgb(
                                50,
                                50,
                                50)
                    };

                System.Windows.Forms.Label lblDescripcion =
                    new System.Windows.Forms.Label()
                    {
                        Text =
                            "Selecciona 2 elementos de las categorías MEP admitidas.\r\n" +
                            "La herramienta detecta automáticamente tubos, flexibles, accesorios, bandejas y cajas del recorrido.",

                        Left =
                            20,

                        Top =
                            70,

                        Width =
                            730,

                        Height =
                            42,

                        ForeColor =
                            System.Drawing.Color.FromArgb(
                                70,
                                70,
                                70)
                    };

                System.Windows.Forms.Label lblTol =
                    new System.Windows.Forms.Label()
                    {
                        Text =
                            "Tolerancia / salto entre extremos de ruta (mm):",

                        Left =
                            20,

                        Top =
                            125,

                        Width =
                            320,

                        Height =
                            22
                    };

                txtToleranciaRuta =
                    new System.Windows.Forms.TextBox()
                    {
                        Left =
                            350,

                        Top =
                            122,

                        Width =
                            110,

                        Height =
                            24,

                        Text =
                            "50",

                        BorderStyle =
                            System.Windows.Forms.BorderStyle.FixedSingle
                    };

                System.Windows.Forms.Label lblAlcance =
                    new System.Windows.Forms.Label()
                    {
                        Text =
                            "Alcance equipo ↔ canalización (mm):",

                        Left =
                            20,

                        Top =
                            160,

                        Width =
                            320,

                        Height =
                            22
                    };

                txtAlcanceEquipo =
                    new System.Windows.Forms.TextBox()
                    {
                        Left =
                            350,

                        Top =
                            157,

                        Width =
                            110,

                        Height =
                            24,

                        Text =
                            "2000",

                        BorderStyle =
                            System.Windows.Forms.BorderStyle.FixedSingle
                    };

                chkSeleccionarRecorrido =
                    new System.Windows.Forms.CheckBox()
                    {
                        Text =
                            "Seleccionar en Revit todos los elementos del recorrido detectado",

                        Left =
                            20,

                        Top =
                            195,

                        Width =
                            540,

                        Height =
                            24,

                        Checked =
                            true
                    };

                // ======================================================
                // SECCIÓN PARÁMETROS
                // ======================================================
                System.Windows.Forms.Label lblParametros =
                    new System.Windows.Forms.Label()
                    {
                        Text =
                            "02. PARÁMETROS A ESCRIBIR EN EL RECORRIDO",

                        Left =
                            20,

                        Top =
                            235,

                        Width =
                            345,

                        Height =
                            22,

                        Font =
                            new System.Drawing.Font(
                                "Segoe UI",
                                9F,
                                System.Drawing.FontStyle.Bold),

                        ForeColor =
                            System.Drawing.Color.FromArgb(
                                50,
                                50,
                                50)
                    };

                chkReemplazar =
                    new System.Windows.Forms.CheckBox()
                    {
                        Text = "Reemplazar",
                        Left = 385,
                        Top = 236,
                        Width = 110,
                        Height = 22,
                        Checked = true
                    };

                chkSumar =
                    new System.Windows.Forms.CheckBox()
                    {
                        Text = "Sumar",
                        Left = 500,
                        Top = 236,
                        Width = 85,
                        Height = 22,
                        Checked = false
                    };

                chkReemplazar.CheckedChanged +=
                    (s, e) =>
                    {
                        if (chkReemplazar.Checked)
                            chkSumar.Checked = false;
                        else if (!chkSumar.Checked)
                            chkReemplazar.Checked = true;
                    };

                chkSumar.CheckedChanged +=
                    (s, e) =>
                    {
                        if (chkSumar.Checked)
                            chkReemplazar.Checked = false;
                        else if (!chkReemplazar.Checked)
                            chkSumar.Checked = true;
                    };

                btnAgregarFila =
                    CrearBoton(
                        "+",
                        690,
                        230,
                        34,
                        System.Drawing.Color.FromArgb(
                            0,
                            120,
                            215));

                btnAgregarFila.Height =
                    28;

                btnAgregarFila.Font =
                    new System.Drawing.Font(
                        "Segoe UI",
                        11F,
                        System.Drawing.FontStyle.Bold);

                btnAgregarFila.Click +=
                    (s, e) =>
                    {
                        AgregarFila();
                    };

                btnQuitarFila =
                    CrearBoton(
                        "−",
                        730,
                        230,
                        34,
                        System.Drawing.Color.FromArgb(
                            100,
                            100,
                            100));

                btnQuitarFila.Height =
                    28;

                btnQuitarFila.Font =
                    new System.Drawing.Font(
                        "Segoe UI",
                        11F,
                        System.Drawing.FontStyle.Bold);

                btnQuitarFila.Click +=
                    (s, e) =>
                    {
                        QuitarFila();
                    };

                System.Windows.Forms.Label lblColParametro =
                    new System.Windows.Forms.Label()
                    {
                        Text =
                            "PARÁMETRO",

                        Left =
                            20,

                        Top =
                            270,

                        Width =
                            370,

                        Height =
                            20,

                        Font =
                            new System.Drawing.Font(
                                "Segoe UI",
                                8F,
                                System.Drawing.FontStyle.Bold),

                        ForeColor =
                            System.Drawing.Color.Gray
                    };

                System.Windows.Forms.Label lblColValor =
                    new System.Windows.Forms.Label()
                    {
                        Text =
                            "VALOR",

                        Left =
                            405,

                        Top =
                            270,

                        Width =
                            250,

                        Height =
                            20,

                        Font =
                            new System.Drawing.Font(
                                "Segoe UI",
                                8F,
                                System.Drawing.FontStyle.Bold),

                        ForeColor =
                            System.Drawing.Color.Gray
                    };

                pnlFilasParametros =
                    new System.Windows.Forms.Panel()
                    {
                        Left =
                            20,

                        Top =
                            292,

                        Width =
                            730,

                        Height =
                            175,

                        AutoScroll =
                            true,

                        BorderStyle =
                            System.Windows.Forms.BorderStyle.FixedSingle,

                        BackColor =
                            System.Drawing.Color.White
                    };

                // ======================================================
                // RESULTADO
                // ======================================================
                System.Windows.Forms.Label lblResultado =
                    new System.Windows.Forms.Label()
                    {
                        Text =
                            "03. RESULTADO / DIAGNÓSTICO",

                        Left =
                            20,

                        Top =
                            485,

                        Width =
                            730,

                        Height =
                            22,

                        Font =
                            new System.Drawing.Font(
                                "Segoe UI",
                                9F,
                                System.Drawing.FontStyle.Bold),

                        ForeColor =
                            System.Drawing.Color.FromArgb(
                                50,
                                50,
                                50)
                    };

                txtResultado =
                    new System.Windows.Forms.RichTextBox()
                    {
                        Left =
                            20,

                        Top =
                            515,

                        Width =
                            730,

                        Height =
                            110,

                        ReadOnly =
                            true,

                        BorderStyle =
                            System.Windows.Forms.BorderStyle.FixedSingle,

                        BackColor =
                            System.Drawing.Color.White,

                        Font =
                            new System.Drawing.Font(
                                "Consolas",
                                8.5F),

                        WordWrap =
                            false,

                        ScrollBars =
                            System.Windows.Forms.RichTextBoxScrollBars.Vertical
                    };

                btnSeleccionarDetectar =
                    CrearBoton(
                        "SELECCIONAR 2 ELEMENTOS, DETECTAR Y ESCRIBIR",
                        205,
                        642,
                        380,
                        System.Drawing.Color.FromArgb(
                            0,
                            120,
                            215));

                btnSeleccionarDetectar.Height =
                    40;

                btnSeleccionarDetectar.Enabled =
                    false;

                btnSeleccionarDetectar.Click +=
                    (s, e) =>
                    {
                        if (ToleranciaRutaMm <= 0.0)
                        {
                            MostrarResultado(
                                "La tolerancia debe ser mayor que 0 mm.");

                            return;
                        }

                        if (AlcanceEquipoMm <= 0.0)
                        {
                            MostrarResultado(
                                "El alcance equipo ↔ canalización debe ser mayor que 0 mm.");

                            return;
                        }

                        string errorAsignaciones;

                        if (!ValidarAsignaciones(
                            out errorAsignaciones))
                        {
                            MostrarResultado(
                                errorAsignaciones);

                            return;
                        }

                        Ejecutar(
                            Operacion.SeleccionarYDetectar);
                    };

                Controls.Add(
                    lblAutor);

                Controls.Add(
                    lblTitulo);

                Controls.Add(
                    lblDescripcion);

                Controls.Add(
                    lblTol);

                Controls.Add(
                    txtToleranciaRuta);

                Controls.Add(
                    lblAlcance);

                Controls.Add(
                    txtAlcanceEquipo);

                Controls.Add(
                    chkSeleccionarRecorrido);

                Controls.Add(
                    lblParametros);

                Controls.Add(
                    chkReemplazar);

                Controls.Add(
                    chkSumar);

                Controls.Add(
                    btnAgregarFila);

                Controls.Add(
                    btnQuitarFila);

                Controls.Add(
                    lblColParametro);

                Controls.Add(
                    lblColValor);

                Controls.Add(
                    pnlFilasParametros);

                Controls.Add(
                    lblResultado);

                Controls.Add(
                    txtResultado);

                Controls.Add(
                    btnSeleccionarDetectar);

                // Una fila inicial.
                AgregarFila();

                MostrarResultado(
                    "Preparando lista de parámetros...");
            }

            // =========================================================
            // CARGA INICIAL
            // =========================================================
            internal void SolicitarCargaInicial()
            {
                if (EjecutarEvent == null)
                    return;

                OperacionSolicitada =
                    Operacion.CargarParametros;

                SetProcesando(
                    true);

                MostrarResultado(
                    "Cargando parámetros escribibles de tubos, flexibles, accesorios, bandejas, cajas y dispositivos...");

                EjecutarEvent.Raise();
            }

            internal void EstablecerParametrosDisponibles(
                System.Collections.Generic.IList<ParametroDisponible> parametros)
            {
                if (this.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(
                        new System.Action(
                            () => EstablecerParametrosDisponibles(
                                parametros)));

                    return;
                }

                _parametrosDisponibles.Clear();
                _parametrosPorNombre.Clear();

                if (parametros != null)
                {
                    foreach (ParametroDisponible p
                        in parametros)
                    {
                        if (p == null ||
                            System.String.IsNullOrWhiteSpace(
                                p.Nombre))
                        {
                            continue;
                        }

                        if (_parametrosPorNombre.ContainsKey(
                            p.Nombre))
                        {
                            continue;
                        }

                        _parametrosDisponibles.Add(
                            p);

                        _parametrosPorNombre[p.Nombre] =
                            p;
                    }
                }

                _parametrosDisponibles.Sort(
                    (a, b) =>
                        System.String.Compare(
                            a.Nombre,
                            b.Nombre,
                            System.StringComparison.CurrentCultureIgnoreCase));

                foreach (FilaAsignacion fila
                    in _filas)
                {
                    ActualizarItemsCombo(
                        fila);
                }

                OperacionSolicitada =
                    Operacion.Ninguna;

                SetProcesando(
                    false);

                btnSeleccionarDetectar.Enabled =
                    _parametrosDisponibles.Count > 0;

                MostrarResultado(
                    "Listo.\r\n" +
                    "Parámetros escribibles encontrados: " +
                    _parametrosDisponibles.Count +
                    ".\r\n" +
                    "Selecciona uno o más parámetros y asigna el valor que deseas escribir.");
            }

            // =========================================================
            // FILAS DINÁMICAS
            // =========================================================
            private void AgregarFila()
            {
                if (_filas.Count >=
                    MaxFilas)
                {
                    MostrarResultado(
                        "Se permite un máximo de " +
                        MaxFilas +
                        " filas de parámetros.");

                    return;
                }

                FilaAsignacion fila =
                    new FilaAsignacion();

                fila.Contenedor =
                    new System.Windows.Forms.Panel()
                    {
                        Left =
                            0,

                        Top =
                            _filas.Count * 36,

                        Width =
                            705,

                        Height =
                            34,

                        BackColor =
                            System.Drawing.Color.White
                    };

                fila.CmbParametro =
                    new System.Windows.Forms.ComboBox()
                    {
                        Left =
                            6,

                        Top =
                            5,

                        Width =
                            365,

                        Height =
                            24,

                        DropDownStyle =
                            System.Windows.Forms.ComboBoxStyle.DropDown,

                        AutoCompleteMode =
                            System.Windows.Forms.AutoCompleteMode.SuggestAppend,

                        AutoCompleteSource =
                            System.Windows.Forms.AutoCompleteSource.ListItems
                    };

                fila.TxtValor =
                    new System.Windows.Forms.TextBox()
                    {
                        Left =
                            385,

                        Top =
                            5,

                        Width =
                            240,

                        Height =
                            24,

                        BorderStyle =
                            System.Windows.Forms.BorderStyle.FixedSingle
                    };

                fila.LblTipo =
                    new System.Windows.Forms.Label()
                    {
                        Left =
                            635,

                        Top =
                            8,

                        Width =
                            62,

                        Height =
                            20,

                        Text =
                            "",

                        ForeColor =
                            System.Drawing.Color.Gray,

                        Font =
                            new System.Drawing.Font(
                                "Segoe UI",
                                7.5F,
                                System.Drawing.FontStyle.Italic)
                    };

                fila.CmbParametro.SelectedIndexChanged +=
                    (s, e) =>
                    {
                        ActualizarTipoFila(
                            fila);
                    };

                fila.CmbParametro.TextChanged +=
                    (s, e) =>
                    {
                        ActualizarTipoFila(
                            fila);
                    };

                fila.TxtValor.KeyPress +=
                    (s, e) =>
                    {
                        ValidarTeclaValor(
                            fila,
                            e);
                    };

                fila.Contenedor.Controls.Add(
                    fila.CmbParametro);

                fila.Contenedor.Controls.Add(
                    fila.TxtValor);

                fila.Contenedor.Controls.Add(
                    fila.LblTipo);

                pnlFilasParametros.Controls.Add(
                    fila.Contenedor);

                _filas.Add(
                    fila);

                ActualizarItemsCombo(
                    fila);

                ActualizarBotonesFilas();
            }

            private void QuitarFila()
            {
                if (_filas.Count <= 1)
                {
                    _filas[0].CmbParametro.Text =
                        "";

                    _filas[0].TxtValor.Text =
                        "";

                    _filas[0].LblTipo.Text =
                        "";

                    return;
                }

                int ultimo =
                    _filas.Count - 1;

                FilaAsignacion fila =
                    _filas[ultimo];

                pnlFilasParametros.Controls.Remove(
                    fila.Contenedor);

                fila.Contenedor.Dispose();

                _filas.RemoveAt(
                    ultimo);

                ActualizarPosicionesFilas();
                ActualizarBotonesFilas();
            }

            private void ActualizarPosicionesFilas()
            {
                for (int i = 0;
                    i < _filas.Count;
                    i++)
                {
                    _filas[i].Contenedor.Top =
                        i * 36;
                }

                pnlFilasParametros.AutoScrollMinSize =
                    new System.Drawing.Size(
                        0,
                        _filas.Count * 36);
            }

            private void ActualizarBotonesFilas()
            {
                if (btnAgregarFila != null)
                {
                    btnAgregarFila.Enabled =
                        _filas.Count <
                        MaxFilas;
                }

                if (btnQuitarFila != null)
                {
                    btnQuitarFila.Enabled =
                        _filas.Count >
                        1;
                }

                ActualizarPosicionesFilas();
            }

            private void ActualizarItemsCombo(
                FilaAsignacion fila)
            {
                if (fila == null ||
                    fila.CmbParametro == null)
                {
                    return;
                }

                string textoActual =
                    fila.CmbParametro.Text;

                fila.CmbParametro.BeginUpdate();

                fila.CmbParametro.Items.Clear();

                foreach (ParametroDisponible p
                    in _parametrosDisponibles)
                {
                    fila.CmbParametro.Items.Add(
                        p.Nombre);
                }

                fila.CmbParametro.EndUpdate();

                fila.CmbParametro.Text =
                    textoActual;

                ActualizarTipoFila(
                    fila);
            }

            private void ActualizarTipoFila(
                FilaAsignacion fila)
            {
                if (fila == null)
                    return;

                ParametroDisponible parametro;

                if (!_parametrosPorNombre.TryGetValue(
                    (fila.CmbParametro.Text ?? "").Trim(),
                    out parametro))
                {
                    fila.LblTipo.Text =
                        "";

                    return;
                }

                fila.LblTipo.Text =
                    parametro.TipoVisible;
            }

            private void ValidarTeclaValor(
                FilaAsignacion fila,
                System.Windows.Forms.KeyPressEventArgs e)
            {
                if (fila == null)
                    return;

                ParametroDisponible parametro;

                if (!_parametrosPorNombre.TryGetValue(
                    (fila.CmbParametro.Text ?? "").Trim(),
                    out parametro))
                {
                    return;
                }

                if (parametro.Tipo ==
                    TipoDatoParametro.Texto)
                {
                    return;
                }

                if (System.Char.IsControl(
                    e.KeyChar))
                {
                    return;
                }

                if (System.Char.IsDigit(
                    e.KeyChar))
                {
                    return;
                }

                if (e.KeyChar == ',' ||
                    e.KeyChar == '.' ||
                    e.KeyChar == '-' ||
                    e.KeyChar == '+')
                {
                    return;
                }

                e.Handled =
                    true;
            }

            private bool ValidarAsignaciones(
                out string mensaje)
            {
                mensaje =
                    "";

                int validas =
                    0;

                System.Collections.Generic.HashSet<string> usados =
                    new System.Collections.Generic.HashSet<string>(
                        System.StringComparer.CurrentCultureIgnoreCase);

                foreach (FilaAsignacion fila
                    in _filas)
                {
                    string nombre =
                        (fila.CmbParametro.Text ?? "").Trim();

                    string valor =
                        fila.TxtValor.Text ?? "";

                    if (System.String.IsNullOrWhiteSpace(
                        nombre))
                    {
                        continue;
                    }

                    ParametroDisponible parametro;

                    if (!_parametrosPorNombre.TryGetValue(
                        nombre,
                        out parametro))
                    {
                        mensaje =
                            "El parámetro \"" +
                            nombre +
                            "\" no pertenece a la lista cargada.";

                        return false;
                    }

                    if (!usados.Add(
                        nombre))
                    {
                        mensaje =
                            "El parámetro \"" +
                            nombre +
                            "\" está repetido.";

                        return false;
                    }

                    if (parametro.Tipo !=
                            TipoDatoParametro.Texto &&
                        System.String.IsNullOrWhiteSpace(
                            valor))
                    {
                        mensaje =
                            "Debes ingresar un número para \"" +
                            nombre +
                            "\".";

                        return false;
                    }

                    if (parametro.Tipo ==
                        TipoDatoParametro.NumeroEntero)
                    {
                        int entero;

                        if (!int.TryParse(
                            valor.Trim(),
                            out entero))
                        {
                            mensaje =
                                "El valor de \"" +
                                nombre +
                                "\" debe ser un número entero.";

                            return false;
                        }
                    }

                    if (parametro.Tipo ==
                        TipoDatoParametro.NumeroDecimal)
                    {
                        double numero;

                        if (!TryLeerNumeroUsuario(
                            valor,
                            out numero))
                        {
                            mensaje =
                                "El valor de \"" +
                                nombre +
                                "\" debe ser numérico.";

                            return false;
                        }
                    }

                    validas++;
                }

                if (validas == 0)
                {
                    mensaje =
                        "Selecciona al menos un parámetro y coloca su valor.";

                    return false;
                }

                if (ModoSeleccionado == ModoEscritura.Sumar)
                {
                    foreach (FilaAsignacion fila in _filas)
                    {
                        string nombre =
                            (fila.CmbParametro.Text ?? "").Trim();

                        if (System.String.IsNullOrWhiteSpace(nombre))
                            continue;

                        ParametroDisponible parametro;

                        if (!_parametrosPorNombre.TryGetValue(
                            nombre,
                            out parametro))
                        {
                            continue;
                        }

                        if (parametro.Tipo == TipoDatoParametro.Texto)
                        {
                            mensaje =
                                "El modo Sumar solo se puede usar con parámetros numéricos.\r\n" +
                                "El parámetro \"" +
                                nombre +
                                "\" es de texto.";

                            return false;
                        }
                    }
                }

                return true;
            }

            internal System.Collections.Generic.List<AsignacionParametro> ObtenerAsignaciones()
            {
                System.Collections.Generic.List<AsignacionParametro> resultado =
                    new System.Collections.Generic.List<AsignacionParametro>();

                foreach (FilaAsignacion fila
                    in _filas)
                {
                    string nombre =
                        (fila.CmbParametro.Text ?? "").Trim();

                    if (System.String.IsNullOrWhiteSpace(
                        nombre))
                    {
                        continue;
                    }

                    ParametroDisponible parametro;

                    if (!_parametrosPorNombre.TryGetValue(
                        nombre,
                        out parametro))
                    {
                        continue;
                    }

                    resultado.Add(
                        new AsignacionParametro()
                        {
                            NombreParametro =
                                parametro.Nombre,

                            Valor =
                                fila.TxtValor.Text ?? "",

                            Tipo =
                                parametro.Tipo
                        });
                }

                return resultado;
            }

            // =========================================================
            // EJECUCIÓN
            // =========================================================
            private void Ejecutar(
                Operacion operacion)
            {
                OperacionSolicitada =
                    operacion;

                if (EjecutarEvent == null)
                {
                    MostrarResultado(
                        "No se pudo crear el evento externo de Revit.");

                    return;
                }

                SetProcesando(
                    true);

                MostrarResultado(
                    "Esperando selección en Revit...\r\n" +
                    "1) Selecciona el primer elemento MEP.\r\n" +
                    "2) Selecciona el segundo elemento MEP.");

                EjecutarEvent.Raise();
            }

            internal void MarcarOperacionCompletada()
            {
                OperacionSolicitada =
                    Operacion.Ninguna;
            }

            internal void SetProcesando(
                bool procesando)
            {
                if (this.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(
                        new System.Action(
                            () => SetProcesando(
                                procesando)));

                    return;
                }

                btnSeleccionarDetectar.Enabled =
                    !procesando &&
                    _parametrosDisponibles.Count > 0;

                txtToleranciaRuta.Enabled =
                    !procesando;

                txtAlcanceEquipo.Enabled =
                    !procesando;

                chkSeleccionarRecorrido.Enabled =
                    !procesando;

                chkReemplazar.Enabled =
                    !procesando;

                chkSumar.Enabled =
                    !procesando;

                btnAgregarFila.Enabled =
                    !procesando &&
                    _filas.Count < MaxFilas;

                btnQuitarFila.Enabled =
                    !procesando &&
                    _filas.Count > 1;

                foreach (FilaAsignacion fila
                    in _filas)
                {
                    fila.CmbParametro.Enabled =
                        !procesando;

                    fila.TxtValor.Enabled =
                        !procesando;
                }
            }

            internal void MostrarResultado(
                string texto)
            {
                if (txtResultado == null ||
                    txtResultado.IsDisposed)
                {
                    return;
                }

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(
                        new System.Action(
                            () => MostrarResultado(
                                texto)));

                    return;
                }

                txtResultado.Clear();

                txtResultado.SelectionColor =
                    System.Drawing.Color.FromArgb(
                        50,
                        50,
                        50);

                txtResultado.AppendText(
                    texto ?? "");

                txtResultado.SelectionStart =
                    0;

                txtResultado.ScrollToCaret();
            }

            // =========================================================
            // CIERRE CONTROLADO
            // =========================================================
            internal void CerrarDesdeHandler()
            {
                if (this.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(
                        new System.Action(
                            () => CerrarDesdeHandler()));

                    return;
                }

                _cerrarDesdeHandler =
                    true;

                _cierreSolicitado =
                    false;

                this.Close();
            }

            // =========================================================
            // NÚMEROS
            // =========================================================
            private static double LeerDouble(
                string texto,
                double defecto)
            {
                double valor;

                if (TryLeerNumeroUsuario(
                    texto,
                    out valor))
                {
                    return valor;
                }

                return defecto;
            }

            private static bool TryLeerNumeroUsuario(
                string texto,
                out double valor)
            {
                valor =
                    0.0;

                if (System.String.IsNullOrWhiteSpace(
                    texto))
                {
                    return false;
                }

                if (double.TryParse(
                    texto,
                    System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.CurrentCulture,
                    out valor))
                {
                    return true;
                }

                return double.TryParse(
                    texto.Trim().Replace(',', '.'),
                    System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out valor);
            }

            private System.Windows.Forms.Button CrearBoton(
                string texto,
                int left,
                int top,
                int width,
                System.Drawing.Color color)
            {
                System.Windows.Forms.Button boton =
                    new System.Windows.Forms.Button()
                    {
                        Text =
                            texto,

                        Left =
                            left,

                        Top =
                            top,

                        Width =
                            width,

                        Height =
                            32,

                        BackColor =
                            color,

                        ForeColor =
                            System.Drawing.Color.White,

                        FlatStyle =
                            System.Windows.Forms.FlatStyle.Flat,

                        Font =
                            new System.Drawing.Font(
                                "Segoe UI",
                                8.5F,
                                System.Drawing.FontStyle.Bold),

                        Cursor =
                            System.Windows.Forms.Cursors.Hand
                    };

                boton.FlatAppearance.BorderSize =
                    0;

                boton.FlatAppearance.MouseOverBackColor =
                    System.Drawing.Color.FromArgb(
                        System.Math.Max(
                            color.R - 15,
                            0),

                        System.Math.Max(
                            color.G - 15,
                            0),

                        System.Math.Max(
                            color.B - 15,
                            0));

                return boton;
            }

            protected override void OnFormClosing(
                System.Windows.Forms.FormClosingEventArgs e)
            {
                // Si el Handler ya terminó la limpieza, permitir el cierre real.
                if (_cerrarDesdeHandler)
                {
                    base.OnFormClosing(
                        e);

                    return;
                }

                // Evitar lanzar dos ExternalEvent si el usuario pulsa X varias veces.
                if (_cierreSolicitado)
                {
                    e.Cancel =
                        true;

                    return;
                }

                if (EjecutarEvent != null)
                {
                    try
                    {
                        e.Cancel =
                            true;

                        _cierreSolicitado =
                            true;

                        OperacionSolicitada =
                            Operacion.CerrarYLiberarVistaTemporal;

                        // Desaparece visualmente de inmediato, pero permanece viva
                        // hasta que Revit termine de restaurar la vista.
                        this.Enabled =
                            false;

                        this.Hide();

                        EjecutarEvent.Raise();

                        return;
                    }
                    catch
                    {
                        // Si Revit ya se está cerrando o no acepta el ExternalEvent,
                        // permitir que WinForms cierre para no bloquear la aplicación.
                        _cerrarDesdeHandler =
                            true;

                        _cierreSolicitado =
                            false;

                        e.Cancel =
                            false;
                    }
                }

                base.OnFormClosing(
                    e);
            }

            protected override void OnFormClosed(
                System.Windows.Forms.FormClosedEventArgs e)
            {
                try
                {
                    if (EjecutarEvent != null)
                        EjecutarEvent.Dispose();
                }
                catch
                {
                }

                EjecutarEvent =
                    null;

                base.OnFormClosed(
                    e);
            }
        }
    }

}
