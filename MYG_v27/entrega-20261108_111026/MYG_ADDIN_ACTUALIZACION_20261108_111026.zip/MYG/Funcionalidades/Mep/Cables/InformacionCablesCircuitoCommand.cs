using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{


    // =====================================
    // COMANDO 5.8 - INFORMACIÓN CABLES CIRCUITO
    // PEGAR DENTRO DEL MISMO NAMESPACE MYG_Addin DE TUS OTROS COMMANDS
    // SIN USING Y SIN DECLARAR NAMESPACE
    // =====================================

    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class InformacionCablesCircuitoCommand : Autodesk.Revit.UI.IExternalCommand
    {
        public Autodesk.Revit.UI.Result Execute(
            Autodesk.Revit.UI.ExternalCommandData commandData,
            ref string message,
            Autodesk.Revit.DB.ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            Autodesk.Revit.UI.UIDocument uidoc =
                commandData.Application.ActiveUIDocument;

            if (uidoc == null || uidoc.Document == null)
            {
                message = "No hay documento activo.";
                return Autodesk.Revit.UI.Result.Failed;
            }

            try
            {
                MYG_InformacionCablesCircuito58.InformacionCablesCircuitoForm form =
                    new MYG_InformacionCablesCircuito58.InformacionCablesCircuitoForm();

                InformacionCablesCircuitoExternalEventHandler handler =
                    new InformacionCablesCircuitoExternalEventHandler();

                handler.UiDoc = uidoc;
                handler.Form = form;

                Autodesk.Revit.UI.ExternalEvent ejecutarEvent =
                    Autodesk.Revit.UI.ExternalEvent.Create(handler);

                form.EjecutarEvent = ejecutarEvent;

                form.Show();

                // Carga inicial de los parámetros escribibles de las
                // categorías que pueden formar parte del recorrido.
                form.SolicitarCargaInicial();

                return Autodesk.Revit.UI.Result.Succeeded;
            }
            catch (System.Exception ex)
            {
                message = ex.Message;
                return Autodesk.Revit.UI.Result.Failed;
            }
        }
    }

}
