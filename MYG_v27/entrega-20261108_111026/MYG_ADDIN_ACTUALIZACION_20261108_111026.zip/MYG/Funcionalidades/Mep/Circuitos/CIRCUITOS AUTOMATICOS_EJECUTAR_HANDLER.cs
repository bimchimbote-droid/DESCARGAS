﻿using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;

namespace MYG_Addin
{
    public enum EleCircuitoRequest
    {
        None,
        SeleccionarTableros,
        AsignarCircuitos
    }

    public class EjecutarEleCircuitoTableroHandler : IExternalEventHandler
    {
        public EleCircuitoRequest Request { get; set; } = EleCircuitoRequest.None;

        public EleCircuitoTableroForm Form { get; set; }

        public List<ElementId> TablerosIds { get; set; } = new List<ElementId>();

        public string ParametroCircuito { get; set; } = "ELE_Circuito";
        public string PrefijoCircuito { get; set; } = "C-";
        public int NumeroInicial { get; set; } = 1;
        public int Digitos { get; set; } = 2;

        public bool IncluirTablero { get; set; } = true;
        public bool SeleccionarResultado { get; set; } = true;
        public bool ReiniciarNumeracionPorTablero { get; set; } = true;

        public bool NoMezclarCircuitosEnCajas { get; set; } = true;
        public bool ContinuarPorAlineacionEnCajas { get; set; } = true;
        public bool DetenerSiCajaConflictiva { get; set; } = true;

        public string PalabrasClaveCajaPase { get; set; } = "CAJA;PASE;BOX;JUNCTION;JUNTA;REGISTRO";
        public double ToleranciaAlineacionCajaCm { get; set; } = 30.0;
        public double AlineacionMinima { get; set; } = 0.60;

        private HashSet<ElementId> _cajasFisicasUnicas;
        private int _pasosPorCajas;
        private int _cajasContinuadasPorConectores;
        private int _cajasContinuadasPorGeometria;
        private int _cajasConflictivas;
        private int _cajasDetenidas;

        public string GetName()
        {
            return "MYG - Asignar circuitos desde tableros";
        }

        public void Execute(UIApplication app)
        {
            try
            {
                UIDocument uidoc = app.ActiveUIDocument;

                if (uidoc == null || uidoc.Document == null)
                    return;

                Document doc = uidoc.Document;

                if (Request == EleCircuitoRequest.SeleccionarTableros)
                {
                    EjecutarSeleccionarTableros(uidoc, doc);
                }
                else if (Request == EleCircuitoRequest.AsignarCircuitos)
                {
                    EjecutarAsignacion(uidoc, doc);
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
            }
            catch (Exception ex)
            {
                TaskDialog.Show("MYG - Error", ex.Message);
            }
            finally
            {
                Request = EleCircuitoRequest.None;
            }
        }

        private void EjecutarSeleccionarTableros(UIDocument uidoc, Document doc)
        {
            IList<Reference> refs = uidoc.Selection.PickObjects(
                ObjectType.Element,
                new FiltroTableroElectrico(),
                "Selecciona uno o varios tableros eléctricos");

            if (refs == null || refs.Count == 0)
                return;

            TablerosIds.Clear();

            List<Element> tableros = new List<Element>();

            foreach (Reference r in refs)
            {
                if (r == null)
                    continue;

                Element tablero = doc.GetElement(r.ElementId);

                if (tablero == null)
                    continue;

                if (TablerosIds.Any(x => x.Value == tablero.Id.Value))
                    continue;

                TablerosIds.Add(tablero.Id);
                tableros.Add(tablero);
            }

            if (Form != null && !Form.IsDisposed)
            {
                Form.SetTablerosSeleccionados(tableros);
            }
        }

        private void EjecutarAsignacion(UIDocument uidoc, Document doc)
        {
            _cajasFisicasUnicas = new HashSet<ElementId>(new ElementIdComparer());
            _pasosPorCajas = 0;
            _cajasContinuadasPorConectores = 0;
            _cajasContinuadasPorGeometria = 0;
            _cajasConflictivas = 0;
            _cajasDetenidas = 0;

            if (TablerosIds == null || TablerosIds.Count == 0)
            {
                TaskDialog.Show("MYG", "Primero debes seleccionar uno o varios tableros.");
                return;
            }

            if (string.IsNullOrWhiteSpace(ParametroCircuito))
                ParametroCircuito = "ELE_Circuito";

            if (string.IsNullOrWhiteSpace(PrefijoCircuito))
                PrefijoCircuito = "C-";

            if (Form != null && !Form.IsDisposed)
            {
                Form.MostrarResultado("Analizando tableros seleccionados...");
            }

            Dictionary<ElementId, SortedSet<string>> mapaElementoCircuitos =
                new Dictionary<ElementId, SortedSet<string>>(new ElementIdComparer());

            HashSet<ElementId> tablerosProcesados = new HashSet<ElementId>(new ElementIdComparer());

            int numeroGlobal = NumeroInicial;
            int totalCircuitos = 0;

            foreach (ElementId tableroId in TablerosIds)
            {
                Element tablero = doc.GetElement(tableroId);

                if (tablero == null)
                    continue;

                tablerosProcesados.Add(tablero.Id);

                int numeroCircuito = ReiniciarNumeracionPorTablero ? NumeroInicial : numeroGlobal;

                List<InicioCircuito> inicios = ObtenerIniciosDesdeTablero(tablero);

                if (Form != null && !Form.IsDisposed)
                {
                    Form.AgregarResultado(
                        "Tablero " + tablero.Id.Value + " - " + tablero.Name + ": " + inicios.Count + " salidas.");
                }

                SortedSet<string> circuitosDeEsteTablero = new SortedSet<string>();

                foreach (InicioCircuito inicio in inicios)
                {
                    string codigoCircuito = CrearCodigoCircuito(numeroCircuito);
                    numeroCircuito++;
                    totalCircuitos++;

                    circuitosDeEsteTablero.Add(codigoCircuito);

                    HashSet<ElementId> redCircuito = RecorrerCircuitoInteligente(
                        doc,
                        tablero.Id,
                        inicio.ElementoId,
                        inicio.ConectorEnElemento,
                        codigoCircuito);

                    foreach (ElementId id in redCircuito)
                    {
                        if (!mapaElementoCircuitos.ContainsKey(id))
                            mapaElementoCircuitos[id] = new SortedSet<string>();

                        mapaElementoCircuitos[id].Add(codigoCircuito);
                    }

                    if (Form != null && !Form.IsDisposed)
                    {
                        Form.AgregarResultado(
                            "  " + codigoCircuito + " -> " + redCircuito.Count + " elementos.");
                    }
                }

                if (!ReiniciarNumeracionPorTablero)
                    numeroGlobal = numeroCircuito;

                if (IncluirTablero)
                {
                    if (!mapaElementoCircuitos.ContainsKey(tablero.Id))
                        mapaElementoCircuitos[tablero.Id] = new SortedSet<string>();

                    foreach (string circuito in circuitosDeEsteTablero)
                        mapaElementoCircuitos[tablero.Id].Add(circuito);
                }
            }

            int modificados = 0;
            int sinParametro = 0;
            int soloLectura = 0;
            int errorSet = 0;

            using (Transaction t = new Transaction(doc, "MYG - Asignar ELE_Circuito desde tableros"))
            {
                t.Start();

                foreach (KeyValuePair<ElementId, SortedSet<string>> kvp in mapaElementoCircuitos)
                {
                    Element e = doc.GetElement(kvp.Key);

                    if (e == null)
                        continue;

                    string valor = string.Join(" + ", kvp.Value);

                    ResultadoSetParametro resultado = SetParametroTexto(e, ParametroCircuito, valor);

                    if (resultado == ResultadoSetParametro.Ok)
                        modificados++;
                    else if (resultado == ResultadoSetParametro.NoExiste)
                        sinParametro++;
                    else if (resultado == ResultadoSetParametro.SoloLectura)
                        soloLectura++;
                    else
                        errorSet++;
                }

                t.Commit();
            }

            if (SeleccionarResultado)
            {
                List<ElementId> idsSeleccion = mapaElementoCircuitos
                    .Keys
                    .Distinct(new ElementIdComparer())
                    .ToList();

                if (idsSeleccion.Count > 0)
                    uidoc.Selection.SetElementIds(idsSeleccion);
            }

            int cajasUnicas = _cajasFisicasUnicas == null ? 0 : _cajasFisicasUnicas.Count;

            if (Form != null && !Form.IsDisposed)
            {
                Form.AgregarResultado("Tableros procesados: " + tablerosProcesados.Count);
                Form.AgregarResultado("Circuitos detectados: " + totalCircuitos);
                Form.AgregarResultado("Cajas físicas únicas: " + cajasUnicas);
                Form.AgregarResultado("Pasos por cajas: " + _pasosPorCajas);
                Form.AgregarResultado("Cajas por conectores/eje: " + _cajasContinuadasPorConectores);
                Form.AgregarResultado("Cajas por geometría/eje: " + _cajasContinuadasPorGeometria);
                Form.AgregarResultado("Cajas conflictivas: " + _cajasConflictivas);
                Form.AgregarResultado("Elementos modificados: " + modificados);
            }

            TaskDialog.Show(
                "MYG - Circuitos asignados",
                "Proceso finalizado.\n\n" +
                "Tableros procesados: " + tablerosProcesados.Count + "\n" +
                "Circuitos detectados: " + totalCircuitos + "\n" +
                "Elementos modificados: " + modificados + "\n" +
                "Sin parámetro '" + ParametroCircuito + "': " + sinParametro + "\n" +
                "Parámetro solo lectura: " + soloLectura + "\n" +
                "Errores al asignar: " + errorSet + "\n\n" +
                "Cajas físicas únicas: " + cajasUnicas + "\n" +
                "Pasos por cajas: " + _pasosPorCajas + "\n" +
                "Cajas continuadas por conectores/eje: " + _cajasContinuadasPorConectores + "\n" +
                "Cajas continuadas por geometría/eje: " + _cajasContinuadasPorGeometria + "\n" +
                "Cajas conflictivas: " + _cajasConflictivas + "\n" +
                "Circuitos detenidos en cajas: " + _cajasDetenidas);
        }

        private HashSet<ElementId> RecorrerCircuitoInteligente(
            Document doc,
            ElementId tableroId,
            ElementId inicialId,
            Connector conectorInicial,
            string codigoCircuito)
        {
            HashSet<ElementId> resultado = new HashSet<ElementId>(new ElementIdComparer());
            HashSet<string> visitados = new HashSet<string>();
            Queue<EstadoRecorrido> cola = new Queue<EstadoRecorrido>();

            Element inicial = doc.GetElement(inicialId);
            XYZ dirInicial = ObtenerDireccionPrincipal(inicial);

            cola.Enqueue(new EstadoRecorrido
            {
                ElementoId = inicialId,
                ElementoAnteriorId = tableroId,
                ConectorEntrada = conectorInicial,
                DireccionEntrada = dirInicial,
                CodigoCircuito = codigoCircuito
            });

            while (cola.Count > 0)
            {
                EstadoRecorrido estado = cola.Dequeue();

                string clave = estado.ElementoId.Value + "|" +
                               estado.ElementoAnteriorId.Value + "|" +
                               estado.CodigoCircuito;

                if (visitados.Contains(clave))
                    continue;

                visitados.Add(clave);

                if (estado.ElementoId.Value == tableroId.Value)
                    continue;

                Element actual = doc.GetElement(estado.ElementoId);

                if (actual == null)
                    continue;

                if (!EsElementoMEPValidoParaRecorrido(actual))
                    continue;

                resultado.Add(actual.Id);

                bool esCaja = EsCajaDePase(actual);

                if (esCaja)
                {
                    _pasosPorCajas++;

                    if (_cajasFisicasUnicas != null)
                        _cajasFisicasUnicas.Add(actual.Id);

                    if (NoMezclarCircuitosEnCajas)
                    {
                        if (!ContinuarPorAlineacionEnCajas)
                        {
                            _cajasDetenidas++;
                            continue;
                        }

                        bool usoGeometria = false;

                        List<SiguienteElemento> mejores = ObtenerSalidasAlineadasDesdeCaja(
                            doc,
                            actual,
                            estado.ElementoAnteriorId,
                            estado.ConectorEntrada,
                            estado.DireccionEntrada,
                            out usoGeometria);

                        if (mejores.Count == 0)
                        {
                            _cajasDetenidas++;
                            continue;
                        }

                        if (mejores.Count > 1 && DetenerSiCajaConflictiva)
                        {
                            _cajasConflictivas++;
                            _cajasDetenidas++;
                            continue;
                        }

                        if (usoGeometria)
                            _cajasContinuadasPorGeometria++;
                        else
                            _cajasContinuadasPorConectores++;

                        foreach (SiguienteElemento sig in mejores)
                        {
                            cola.Enqueue(new EstadoRecorrido
                            {
                                ElementoId = sig.ElementoId,
                                ElementoAnteriorId = actual.Id,
                                ConectorEntrada = sig.ConectorEnSiguiente,
                                DireccionEntrada = sig.Direccion,
                                CodigoCircuito = codigoCircuito
                            });
                        }

                        continue;
                    }
                }

                List<SiguienteElemento> siguientes = ObtenerSiguientesNormales(
                    doc,
                    actual,
                    estado.ElementoAnteriorId,
                    tableroId);

                foreach (SiguienteElemento sig in siguientes)
                {
                    cola.Enqueue(new EstadoRecorrido
                    {
                        ElementoId = sig.ElementoId,
                        ElementoAnteriorId = actual.Id,
                        ConectorEntrada = sig.ConectorEnSiguiente,
                        DireccionEntrada = sig.Direccion,
                        CodigoCircuito = codigoCircuito
                    });
                }
            }

            return resultado;
        }

        private List<InicioCircuito> ObtenerIniciosDesdeTablero(Element tablero)
        {
            List<InicioCircuito> inicios = new List<InicioCircuito>();

            List<Connector> conectoresTablero = ObtenerConectores(tablero);

            foreach (Connector cTablero in conectoresTablero)
            {
                ConnectorSet refs = null;

                try
                {
                    refs = cTablero.AllRefs;
                }
                catch
                {
                    continue;
                }

                if (refs == null)
                    continue;

                foreach (Connector cOtro in refs)
                {
                    if (!EsConectorValido(cTablero, cOtro))
                        continue;

                    Element owner = cOtro.Owner as Element;

                    if (owner == null)
                        continue;

                    if (owner.Id.Value == tablero.Id.Value)
                        continue;

                    if (!EsElementoMEPValidoParaRecorrido(owner))
                        continue;

                    if (inicios.Any(x => x.ElementoId.Value == owner.Id.Value))
                        continue;

                    inicios.Add(new InicioCircuito
                    {
                        ElementoId = owner.Id,
                        ConectorEnElemento = cOtro,
                        PuntoOrden = ObtenerOrigenSeguro(cOtro)
                    });
                }
            }

            return inicios
                .OrderBy(x => Math.Round(x.PuntoOrden.Z, 6))
                .ThenBy(x => Math.Round(x.PuntoOrden.X, 6))
                .ThenBy(x => Math.Round(x.PuntoOrden.Y, 6))
                .ThenBy(x => x.ElementoId.Value)
                .ToList();
        }

        private List<SiguienteElemento> ObtenerSiguientesNormales(
            Document doc,
            Element actual,
            ElementId anteriorId,
            ElementId tableroId)
        {
            List<SiguienteElemento> lista = new List<SiguienteElemento>();

            List<Connector> conectores = ObtenerConectores(actual);

            foreach (Connector cActual in conectores)
            {
                ConnectorSet refs = null;

                try
                {
                    refs = cActual.AllRefs;
                }
                catch
                {
                    continue;
                }

                if (refs == null)
                    continue;

                foreach (Connector cOtro in refs)
                {
                    if (!EsConectorValido(cActual, cOtro))
                        continue;

                    Element owner = cOtro.Owner as Element;

                    if (owner == null)
                        continue;

                    if (owner.Id.Value == actual.Id.Value)
                        continue;

                    if (owner.Id.Value == anteriorId.Value)
                        continue;

                    if (owner.Id.Value == tableroId.Value)
                        continue;

                    if (!EsElementoMEPValidoParaRecorrido(owner))
                        continue;

                    lista.Add(new SiguienteElemento
                    {
                        ElementoId = owner.Id,
                        ConectorEnActual = cActual,
                        ConectorEnSiguiente = cOtro,
                        Direccion = ObtenerDireccionPrincipal(owner)
                    });
                }
            }

            return lista
                .GroupBy(x => x.ElementoId.Value)
                .Select(g => g.First())
                .ToList();
        }

        private List<SiguienteElemento> ObtenerSalidasAlineadasDesdeCaja(
            Document doc,
            Element caja,
            ElementId anteriorId,
            Connector conectorEntrada,
            XYZ direccionEntrada,
            out bool usoGeometria)
        {
            usoGeometria = false;

            Element anterior = doc.GetElement(anteriorId);

            XYZ direccionAnterior = ObtenerDireccionPrincipal(anterior);

            if (direccionAnterior != null && !EsVectorCero(direccionAnterior))
                direccionEntrada = direccionAnterior;

            if (direccionEntrada == null || EsVectorCero(direccionEntrada))
                direccionEntrada = XYZ.BasisZ;

            XYZ puntoReferencia = ObtenerPuntoReferenciaEje(anterior, conectorEntrada, caja);
            double toleranciaFt = CmToFeet(ToleranciaAlineacionCajaCm);
            double diametroEntrada = ObtenerDiametroDesdeElementoOConector(anterior, conectorEntrada);

            List<CandidatoCaja> candidatosConectores = ObtenerCandidatosPorConectoresDeCaja(
                doc,
                caja,
                anterior,
                anteriorId,
                puntoReferencia,
                direccionEntrada,
                diametroEntrada,
                toleranciaFt);

            List<CandidatoCaja> candidatosGeometria = BuscarSalidasGeometricasCercaDeCaja(
                doc,
                caja,
                anterior,
                anteriorId,
                puntoReferencia,
                direccionEntrada,
                diametroEntrada,
                toleranciaFt);

            List<CandidatoCaja> candidatos = new List<CandidatoCaja>();
            candidatos.AddRange(candidatosConectores);
            candidatos.AddRange(candidatosGeometria);

            candidatos = candidatos
                .GroupBy(x => x.ElementoId.Value)
                .Select(g => g.OrderByDescending(a => a.Score).First())
                .OrderByDescending(x => x.Score)
                .ToList();

            if (candidatos.Count == 0)
                return new List<SiguienteElemento>();

            CandidatoCaja mejor = candidatos[0];

            double toleranciaEmpateScore = 1.00;
            double toleranciaEmpateEje = CmToFeet(1.0);

            List<CandidatoCaja> empatados = candidatos
                .Where(x =>
                    Math.Abs(x.Score - mejor.Score) <= toleranciaEmpateScore &&
                    Math.Abs(x.DistanciaEjeXY - mejor.DistanciaEjeXY) <= toleranciaEmpateEje)
                .ToList();

            if (empatados.Count > 1)
            {
                return empatados.Select(x => new SiguienteElemento
                {
                    ElementoId = x.ElementoId,
                    ConectorEnActual = x.ConectorEnCaja,
                    ConectorEnSiguiente = x.ConectorEnSiguiente,
                    Direccion = x.Direccion
                }).ToList();
            }

            usoGeometria = mejor.VieneDeGeometria;

            return new List<SiguienteElemento>
            {
                new SiguienteElemento
                {
                    ElementoId = mejor.ElementoId,
                    ConectorEnActual = mejor.ConectorEnCaja,
                    ConectorEnSiguiente = mejor.ConectorEnSiguiente,
                    Direccion = mejor.Direccion
                }
            };
        }

        private List<CandidatoCaja> ObtenerCandidatosPorConectoresDeCaja(
            Document doc,
            Element caja,
            Element anterior,
            ElementId anteriorId,
            XYZ puntoReferencia,
            XYZ direccionEntrada,
            double diametroEntrada,
            double toleranciaFt)
        {
            List<CandidatoCaja> candidatos = new List<CandidatoCaja>();
            List<Connector> conectoresCaja = ObtenerConectores(caja);

            foreach (Connector cCaja in conectoresCaja)
            {
                ConnectorSet refs = null;

                try
                {
                    refs = cCaja.AllRefs;
                }
                catch
                {
                    continue;
                }

                if (refs == null)
                    continue;

                foreach (Connector cOtro in refs)
                {
                    if (!EsConectorValido(cCaja, cOtro))
                        continue;

                    Element candidato = cOtro.Owner as Element;

                    if (candidato == null)
                        continue;

                    if (candidato.Id.Value == caja.Id.Value)
                        continue;

                    if (candidato.Id.Value == anteriorId.Value)
                        continue;

                    if (!EsElementoMEPValidoParaRecorrido(candidato))
                        continue;

                    CandidatoCaja evaluado = EvaluarCandidatoCaja(
                        candidato,
                        anterior,
                        cCaja,
                        cOtro,
                        puntoReferencia,
                        direccionEntrada,
                        diametroEntrada,
                        toleranciaFt,
                        false);

                    if (evaluado != null)
                        candidatos.Add(evaluado);
                }
            }

            return candidatos;
        }

        private List<CandidatoCaja> BuscarSalidasGeometricasCercaDeCaja(
            Document doc,
            Element caja,
            Element anterior,
            ElementId anteriorId,
            XYZ puntoReferencia,
            XYZ direccionEntrada,
            double diametroEntrada,
            double toleranciaFt)
        {
            List<CandidatoCaja> candidatos = new List<CandidatoCaja>();

            BoundingBoxXYZ bbCaja = null;

            try
            {
                bbCaja = caja.get_BoundingBox(null);
            }
            catch
            {
            }

            if (bbCaja == null)
                return candidatos;

            XYZ centroCaja = (bbCaja.Min + bbCaja.Max) * 0.5;

            List<BuiltInCategory> categorias = new List<BuiltInCategory>
            {
                BuiltInCategory.OST_Conduit,
                BuiltInCategory.OST_ConduitFitting,
                BuiltInCategory.OST_CableTray,
                BuiltInCategory.OST_CableTrayFitting
            };

            foreach (BuiltInCategory bic in categorias)
            {
                FilteredElementCollector collector = new FilteredElementCollector(doc)
                    .OfCategory(bic)
                    .WhereElementIsNotElementType();

                foreach (Element candidato in collector)
                {
                    if (candidato == null)
                        continue;

                    if (candidato.Id.Value == anteriorId.Value)
                        continue;

                    if (!EsElementoMEPValidoParaRecorrido(candidato))
                        continue;

                    if (!ElementoTocaCajaPorGeometria(candidato, bbCaja, toleranciaFt))
                        continue;

                    Connector conectorCercano = ObtenerConectorMasCercano(candidato, centroCaja);

                    CandidatoCaja evaluado = EvaluarCandidatoCaja(
                        candidato,
                        anterior,
                        null,
                        conectorCercano,
                        puntoReferencia,
                        direccionEntrada,
                        diametroEntrada,
                        toleranciaFt,
                        true);

                    if (evaluado != null)
                        candidatos.Add(evaluado);
                }
            }

            return candidatos;
        }

        private CandidatoCaja EvaluarCandidatoCaja(
            Element candidato,
            Element anterior,
            Connector conectorEnCaja,
            Connector conectorEnSiguiente,
            XYZ puntoReferencia,
            XYZ direccionEntrada,
            double diametroEntrada,
            double toleranciaFt,
            bool vieneDeGeometria)
        {
            XYZ dirCandidato = ObtenerDireccionPrincipal(candidato);

            if (dirCandidato == null || EsVectorCero(dirCandidato))
                return null;

            double alineacion = Math.Abs(
                NormalizarSeguro(direccionEntrada).DotProduct(NormalizarSeguro(dirCandidato)));

            if (alineacion < AlineacionMinima)
                return null;

            double distanciaEjeXY = DistanciaEntreEjesXY(anterior, candidato, puntoReferencia);

            double limiteEje = Math.Max(toleranciaFt, CmToFeet(8.0));

            if (distanciaEjeXY > limiteEje)
                return null;

            double diametroCandidato = ObtenerDiametroDesdeElementoOConector(candidato, conectorEnSiguiente);

            bool mismoDiametro = false;

            if (diametroEntrada > 0.0001 && diametroCandidato > 0.0001)
                mismoDiametro = Math.Abs(diametroEntrada - diametroCandidato) <= CmToFeet(0.2);

            double distanciaReferencia = DistanciaXYElemento(puntoReferencia, candidato);
            double distanciaConector = 0.0;

            if (conectorEnSiguiente != null)
                distanciaConector = ObtenerOrigenSeguro(conectorEnSiguiente).DistanceTo(puntoReferencia);
            else
                distanciaConector = distanciaReferencia;

            double score = 0.0;

            score += alineacion * 100.0;

            if (mismoDiametro)
                score += 35.0;

            score += Math.Max(0.0, 80.0 - distanciaEjeXY * 220.0);
            score += Math.Max(0.0, 25.0 - distanciaReferencia * 35.0);
            score -= distanciaConector * 2.0;

            if (vieneDeGeometria)
                score -= 2.0;
            else
                score += 5.0;

            return new CandidatoCaja
            {
                ElementoId = candidato.Id,
                ConectorEnCaja = conectorEnCaja,
                ConectorEnSiguiente = conectorEnSiguiente,
                Direccion = dirCandidato,
                Alineacion = alineacion,
                DistanciaEjeXY = distanciaEjeXY,
                DistanciaXY = distanciaReferencia,
                Score = score,
                VieneDeGeometria = vieneDeGeometria
            };
        }

        private XYZ ObtenerPuntoReferenciaEje(Element anterior, Connector conectorEntrada, Element caja)
        {
            XYZ punto = XYZ.Zero;

            if (anterior != null)
            {
                Connector c = ObtenerConectorMasCercano(anterior, ObtenerPuntoElemento(caja));

                if (c != null)
                    punto = ObtenerOrigenSeguro(c);
            }

            if (!EsPuntoValido(punto) && conectorEntrada != null)
                punto = ObtenerOrigenSeguro(conectorEntrada);

            if (!EsPuntoValido(punto))
                punto = ObtenerPuntoElemento(caja);

            return punto;
        }

        private double DistanciaEntreEjesXY(Element referencia, Element candidato, XYZ puntoReferencia)
        {
            if (candidato == null)
                return double.MaxValue;

            LocationCurve lcCand = candidato.Location as LocationCurve;
            LocationCurve lcRef = referencia == null ? null : referencia.Location as LocationCurve;

            if (lcCand != null && lcCand.Curve != null)
            {
                XYZ c0 = lcCand.Curve.GetEndPoint(0);
                XYZ c1 = lcCand.Curve.GetEndPoint(1);

                if (lcRef != null && lcRef.Curve != null)
                {
                    XYZ r0 = lcRef.Curve.GetEndPoint(0);
                    XYZ r1 = lcRef.Curve.GetEndPoint(1);
                    return DistanciaXYEntreSegmentos(r0, r1, c0, c1);
                }

                return DistanciaXYPuntoSegmento(puntoReferencia, c0, c1);
            }

            XYZ pc = ObtenerPuntoElemento(candidato);

            if (lcRef != null && lcRef.Curve != null)
            {
                XYZ r0 = lcRef.Curve.GetEndPoint(0);
                XYZ r1 = lcRef.Curve.GetEndPoint(1);
                return DistanciaXYPuntoSegmento(pc, r0, r1);
            }

            return DistanciaXY(puntoReferencia, pc);
        }

        private double DistanciaXYEntreSegmentos(XYZ a0, XYZ a1, XYZ b0, XYZ b1)
        {
            double d1 = DistanciaXYPuntoSegmento(a0, b0, b1);
            double d2 = DistanciaXYPuntoSegmento(a1, b0, b1);
            double d3 = DistanciaXYPuntoSegmento(b0, a0, a1);
            double d4 = DistanciaXYPuntoSegmento(b1, a0, a1);

            return Math.Min(Math.Min(d1, d2), Math.Min(d3, d4));
        }

        private bool ElementoTocaCajaPorGeometria(Element e, BoundingBoxXYZ bbCaja, double toleranciaFt)
        {
            if (e == null || bbCaja == null)
                return false;

            LocationCurve lc = e.Location as LocationCurve;

            if (lc != null && lc.Curve != null)
            {
                XYZ p0 = lc.Curve.GetEndPoint(0);
                XYZ p1 = lc.Curve.GetEndPoint(1);

                if (PuntoDentroDeBoundingBoxExpandido(p0, bbCaja, toleranciaFt))
                    return true;

                if (PuntoDentroDeBoundingBoxExpandido(p1, bbCaja, toleranciaFt))
                    return true;

                XYZ centroCaja = (bbCaja.Min + bbCaja.Max) * 0.5;
                double dist = DistanciaPuntoSegmento(centroCaja, p0, p1);

                XYZ diagonal = bbCaja.Max - bbCaja.Min;
                double radioAproxCaja = diagonal.GetLength() * 0.5;

                if (dist <= radioAproxCaja + toleranciaFt)
                    return true;
            }

            BoundingBoxXYZ bb = null;

            try
            {
                bb = e.get_BoundingBox(null);
            }
            catch
            {
            }

            if (bb == null)
                return false;

            return BoundingBoxesIntersectanExpandido(bb, bbCaja, toleranciaFt);
        }

        private bool PuntoDentroDeBoundingBoxExpandido(XYZ p, BoundingBoxXYZ bb, double toleranciaFt)
        {
            if (p == null || bb == null)
                return false;

            if (p.X < bb.Min.X - toleranciaFt)
                return false;

            if (p.X > bb.Max.X + toleranciaFt)
                return false;

            if (p.Y < bb.Min.Y - toleranciaFt)
                return false;

            if (p.Y > bb.Max.Y + toleranciaFt)
                return false;

            if (p.Z < bb.Min.Z - toleranciaFt)
                return false;

            if (p.Z > bb.Max.Z + toleranciaFt)
                return false;

            return true;
        }

        private bool BoundingBoxesIntersectanExpandido(BoundingBoxXYZ a, BoundingBoxXYZ b, double toleranciaFt)
        {
            if (a == null || b == null)
                return false;

            if (a.Max.X < b.Min.X - toleranciaFt)
                return false;

            if (a.Min.X > b.Max.X + toleranciaFt)
                return false;

            if (a.Max.Y < b.Min.Y - toleranciaFt)
                return false;

            if (a.Min.Y > b.Max.Y + toleranciaFt)
                return false;

            if (a.Max.Z < b.Min.Z - toleranciaFt)
                return false;

            if (a.Min.Z > b.Max.Z + toleranciaFt)
                return false;

            return true;
        }

        private double DistanciaXYElemento(XYZ punto, Element e)
        {
            if (punto == null || e == null)
                return double.MaxValue;

            LocationCurve lc = e.Location as LocationCurve;

            if (lc != null && lc.Curve != null)
            {
                XYZ p0 = lc.Curve.GetEndPoint(0);
                XYZ p1 = lc.Curve.GetEndPoint(1);

                return DistanciaXYPuntoSegmento(punto, p0, p1);
            }

            XYZ centro = ObtenerPuntoElemento(e);
            return DistanciaXY(punto, centro);
        }

        private double DistanciaPuntoSegmento(XYZ p, XYZ a, XYZ b)
        {
            if (p == null || a == null || b == null)
                return double.MaxValue;

            XYZ ap = p - a;
            XYZ ab = b - a;

            double ab2 = ab.DotProduct(ab);

            if (ab2 < 0.0000001)
                return p.DistanceTo(a);

            double t = ap.DotProduct(ab) / ab2;

            if (t < 0.0)
                t = 0.0;

            if (t > 1.0)
                t = 1.0;

            XYZ proy = a + ab * t;

            return p.DistanceTo(proy);
        }

        private double DistanciaXYPuntoSegmento(XYZ p, XYZ a, XYZ b)
        {
            if (p == null || a == null || b == null)
                return double.MaxValue;

            XYZ ap = new XYZ(p.X - a.X, p.Y - a.Y, 0);
            XYZ ab = new XYZ(b.X - a.X, b.Y - a.Y, 0);

            double ab2 = ab.DotProduct(ab);

            if (ab2 < 0.0000001)
                return DistanciaXY(p, a);

            double t = ap.DotProduct(ab) / ab2;

            if (t < 0.0)
                t = 0.0;

            if (t > 1.0)
                t = 1.0;

            XYZ proy = new XYZ(
                a.X + ab.X * t,
                a.Y + ab.Y * t,
                p.Z);

            return DistanciaXY(p, proy);
        }

        private Connector ObtenerConectorMasCercano(Element e, XYZ punto)
        {
            if (e == null || punto == null)
                return null;

            List<Connector> conectores = ObtenerConectores(e);

            Connector mejor = null;
            double menor = double.MaxValue;

            foreach (Connector c in conectores)
            {
                XYZ pc = ObtenerOrigenSeguro(c);
                double d = pc.DistanceTo(punto);

                if (d < menor)
                {
                    menor = d;
                    mejor = c;
                }
            }

            return mejor;
        }

        private bool EsCajaDePase(Element e)
        {
            if (e == null)
                return false;

            BuiltInCategory bic;

            try
            {
                if (e.Category == null)
                    return false;

                bic = (BuiltInCategory)(int)e.Category.Id.Value;
            }
            catch
            {
                return false;
            }

            if (bic == BuiltInCategory.OST_Conduit ||
                bic == BuiltInCategory.OST_ConduitFitting ||
                bic == BuiltInCategory.OST_CableTray ||
                bic == BuiltInCategory.OST_CableTrayFitting)
                return false;

            string texto = "";

            try { texto += " " + e.Name; } catch { }

            FamilyInstance fi = e as FamilyInstance;

            if (fi != null)
            {
                try { texto += " " + fi.Symbol.Name; } catch { }
                try { texto += " " + fi.Symbol.FamilyName; } catch { }
            }

            texto = NormalizarTexto(texto);

            List<string> claves = ObtenerPalabrasCaja();

            foreach (string clave in claves)
            {
                if (texto.Contains(clave))
                    return true;
            }

            return false;
        }

        private List<string> ObtenerPalabrasCaja()
        {
            List<string> lista = new List<string>();

            string bruto = PalabrasClaveCajaPase;

            if (string.IsNullOrWhiteSpace(bruto))
                bruto = "CAJA;PASE;BOX;JUNCTION;JUNTA;REGISTRO";

            string[] partes = bruto.Split(new char[] { ';', ',', '|' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string p in partes)
            {
                string v = NormalizarTexto(p.Trim());

                if (!string.IsNullOrWhiteSpace(v))
                    lista.Add(v);
            }

            return lista;
        }

        private string NormalizarTexto(string texto)
        {
            if (texto == null)
                return "";

            return texto.Trim().ToUpperInvariant();
        }

        private List<Connector> ObtenerConectores(Element e)
        {
            List<Connector> lista = new List<Connector>();

            if (e == null)
                return lista;

            MEPCurve mepCurve = e as MEPCurve;

            if (mepCurve != null)
            {
                try
                {
                    ConnectorSet set = mepCurve.ConnectorManager.Connectors;

                    foreach (Connector c in set)
                        lista.Add(c);
                }
                catch
                {
                }

                return lista;
            }

            FamilyInstance fi = e as FamilyInstance;

            if (fi != null)
            {
                try
                {
                    if (fi.MEPModel != null && fi.MEPModel.ConnectorManager != null)
                    {
                        ConnectorSet set = fi.MEPModel.ConnectorManager.Connectors;

                        foreach (Connector c in set)
                            lista.Add(c);
                    }
                }
                catch
                {
                }

                return lista;
            }

            return lista;
        }

        private bool EsConectorValido(Connector a, Connector b)
        {
            if (a == null || b == null)
                return false;

            if (b.Owner == null)
                return false;

            try
            {
                if (a.Owner != null && a.Owner.Id.Value == b.Owner.Id.Value)
                    return false;
            }
            catch
            {
                return false;
            }

            try
            {
                if (a.ConnectorType == ConnectorType.Logical ||
                    b.ConnectorType == ConnectorType.Logical)
                    return false;
            }
            catch
            {
            }

            return true;
        }

        private bool EsElementoMEPValidoParaRecorrido(Element e)
        {
            if (e == null || e.Category == null)
                return false;

            BuiltInCategory bic;

            try
            {
                bic = (BuiltInCategory)(int)e.Category.Id.Value;
            }
            catch
            {
                return false;
            }

            if (bic == BuiltInCategory.OST_Conduit)
                return true;

            if (bic == BuiltInCategory.OST_ConduitFitting)
                return true;

            if (bic == BuiltInCategory.OST_CableTray)
                return true;

            if (bic == BuiltInCategory.OST_CableTrayFitting)
                return true;

            if (bic == BuiltInCategory.OST_ElectricalEquipment)
                return true;

            if (bic == BuiltInCategory.OST_ElectricalFixtures)
                return true;

            if (bic == BuiltInCategory.OST_LightingFixtures)
                return true;

            if (bic == BuiltInCategory.OST_LightingDevices)
                return true;

            if (bic == BuiltInCategory.OST_DataDevices)
                return true;

            if (bic == BuiltInCategory.OST_CommunicationDevices)
                return true;

            if (bic == BuiltInCategory.OST_FireAlarmDevices)
                return true;

            if (bic == BuiltInCategory.OST_SecurityDevices)
                return true;

            if (bic == BuiltInCategory.OST_TelephoneDevices)
                return true;

            if (bic == BuiltInCategory.OST_NurseCallDevices)
                return true;

            if (bic == BuiltInCategory.OST_GenericModel)
                return true;

            return false;
        }

        private XYZ ObtenerDireccionPrincipal(Element e)
        {
            if (e == null)
                return XYZ.Zero;

            LocationCurve lc = e.Location as LocationCurve;

            if (lc != null && lc.Curve != null)
            {
                XYZ p0 = lc.Curve.GetEndPoint(0);
                XYZ p1 = lc.Curve.GetEndPoint(1);
                XYZ v = p1 - p0;

                if (!EsVectorCero(v))
                    return v.Normalize();
            }

            List<Connector> conectores = ObtenerConectores(e);

            if (conectores.Count >= 2)
            {
                XYZ p0 = ObtenerOrigenSeguro(conectores[0]);
                XYZ p1 = ObtenerOrigenSeguro(conectores[1]);
                XYZ v = p1 - p0;

                if (!EsVectorCero(v))
                    return v.Normalize();
            }

            return XYZ.Zero;
        }

        private XYZ ObtenerOrigenSeguro(Connector c)
        {
            if (c == null)
                return XYZ.Zero;

            try
            {
                return c.Origin;
            }
            catch
            {
                return XYZ.Zero;
            }
        }

        private XYZ ObtenerPuntoElemento(Element e)
        {
            if (e == null)
                return XYZ.Zero;

            LocationPoint lp = e.Location as LocationPoint;

            if (lp != null)
                return lp.Point;

            LocationCurve lc = e.Location as LocationCurve;

            if (lc != null && lc.Curve != null)
                return (lc.Curve.GetEndPoint(0) + lc.Curve.GetEndPoint(1)) * 0.5;

            BoundingBoxXYZ bb = null;

            try
            {
                bb = e.get_BoundingBox(null);
            }
            catch
            {
            }

            if (bb != null)
                return (bb.Min + bb.Max) * 0.5;

            return XYZ.Zero;
        }

        private bool EsPuntoValido(XYZ p)
        {
            if (p == null)
                return false;

            return p.GetLength() > 0.000001;
        }

        private double ObtenerDiametroDesdeElementoOConector(Element e, Connector c)
        {
            try
            {
                if (c != null)
                {
                    double radio = c.Radius;

                    if (radio > 0.0001)
                        return radio * 2.0;
                }
            }
            catch
            {
            }

            if (e != null)
            {
                double d = ObtenerParametroDouble(e, "Diámetro");

                if (d > 0.0001)
                    return d;

                d = ObtenerParametroDouble(e, "Diameter");

                if (d > 0.0001)
                    return d;

                d = ObtenerParametroDouble(e, "Trade Size");

                if (d > 0.0001)
                    return d;
            }

            return 0.0;
        }

        private double ObtenerParametroDouble(Element e, string nombre)
        {
            if (e == null)
                return 0.0;

            Parameter p = e.LookupParameter(nombre);

            if (p == null)
                return 0.0;

            try
            {
                if (p.StorageType == StorageType.Double)
                    return p.AsDouble();
            }
            catch
            {
            }

            return 0.0;
        }

        private ResultadoSetParametro SetParametroTexto(Element e, string nombreParametro, string valor)
        {
            Parameter p = e.LookupParameter(nombreParametro);

            if (p == null)
                return ResultadoSetParametro.NoExiste;

            if (p.IsReadOnly)
                return ResultadoSetParametro.SoloLectura;

            try
            {
                if (p.StorageType == StorageType.String)
                {
                    p.Set(valor);
                    return ResultadoSetParametro.Ok;
                }

                p.SetValueString(valor);
                return ResultadoSetParametro.Ok;
            }
            catch
            {
                return ResultadoSetParametro.Error;
            }
        }

        private string CrearCodigoCircuito(int numero)
        {
            string formato = new string('0', Math.Max(1, Digitos));
            return PrefijoCircuito + numero.ToString(formato);
        }

        private double CmToFeet(double cm)
        {
            return cm / 30.48;
        }

        private bool EsVectorCero(XYZ v)
        {
            if (v == null)
                return true;

            return v.GetLength() < 0.000001;
        }

        private XYZ NormalizarSeguro(XYZ v)
        {
            if (v == null || EsVectorCero(v))
                return XYZ.Zero;

            return v.Normalize();
        }

        private double DistanciaXY(XYZ a, XYZ b)
        {
            double dx = a.X - b.X;
            double dy = a.Y - b.Y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

        private enum ResultadoSetParametro
        {
            Ok,
            NoExiste,
            SoloLectura,
            Error
        }

        private class InicioCircuito
        {
            public ElementId ElementoId { get; set; }
            public Connector ConectorEnElemento { get; set; }
            public XYZ PuntoOrden { get; set; }
        }

        private class EstadoRecorrido
        {
            public ElementId ElementoId { get; set; }
            public ElementId ElementoAnteriorId { get; set; }
            public Connector ConectorEntrada { get; set; }
            public XYZ DireccionEntrada { get; set; }
            public string CodigoCircuito { get; set; }
        }

        private class SiguienteElemento
        {
            public ElementId ElementoId { get; set; }
            public Connector ConectorEnActual { get; set; }
            public Connector ConectorEnSiguiente { get; set; }
            public XYZ Direccion { get; set; }
        }

        private class CandidatoCaja
        {
            public ElementId ElementoId { get; set; }
            public Connector ConectorEnCaja { get; set; }
            public Connector ConectorEnSiguiente { get; set; }
            public XYZ Direccion { get; set; }
            public double Alineacion { get; set; }
            public double DistanciaEjeXY { get; set; }
            public double DistanciaXY { get; set; }
            public double Score { get; set; }
            public bool VieneDeGeometria { get; set; }
        }

        private class ElementIdComparer : IEqualityComparer<ElementId>
        {
            public bool Equals(ElementId x, ElementId y)
            {
                if (x == null && y == null)
                    return true;

                if (x == null || y == null)
                    return false;

                return x.Value == y.Value;
            }

            public int GetHashCode(ElementId obj)
            {
                if (obj == null)
                    return 0;

                return obj.Value.GetHashCode();
            }
        }

        private class FiltroTableroElectrico : ISelectionFilter
        {
            public bool AllowElement(Element elem)
            {
                if (elem == null || elem.Category == null)
                    return false;

                BuiltInCategory bic;

                try
                {
                    bic = (BuiltInCategory)(int)elem.Category.Id.Value;
                }
                catch
                {
                    return false;
                }

                if (bic == BuiltInCategory.OST_ElectricalEquipment)
                    return true;

                return false;
            }

            public bool AllowReference(Reference reference, XYZ position)
            {
                return false;
            }
        }
    }
}
