using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // VENTANA 5.2 - CIRCUITOS AUTOMÁTICOS DESDE TABLEROS
    // =====================================

    public class EleCircuitoTableroForm : System.Windows.Forms.Form
    {
        private readonly EjecutarEleCircuitoTableroHandler _handler;
        private readonly Autodesk.Revit.UI.ExternalEvent _externalEvent;

        private System.Collections.Generic.List<Autodesk.Revit.DB.ElementId> tablerosIds;

        private System.Windows.Forms.Button btnSeleccionarTableros;
        private System.Windows.Forms.Button btnAsignarCircuitos;

        private System.Windows.Forms.ListBox lstTableros;
        private System.Windows.Forms.RichTextBox txtResultado;

        private System.Windows.Forms.TextBox txtParametro;
        private System.Windows.Forms.TextBox txtPrefijo;
        private System.Windows.Forms.NumericUpDown nudInicio;
        private System.Windows.Forms.NumericUpDown nudDigitos;

        private System.Windows.Forms.CheckBox chkIncluirTableros;
        private System.Windows.Forms.CheckBox chkSeleccionarResultado;
        private System.Windows.Forms.CheckBox chkReiniciarNumeracionPorTablero;

        private System.Windows.Forms.CheckBox chkNoMezclarCajas;
        private System.Windows.Forms.CheckBox chkContinuarPorAlineacion;
        private System.Windows.Forms.CheckBox chkDetenerCajaConflictiva;

        private System.Windows.Forms.TextBox txtPalabrasCaja;
        private System.Windows.Forms.NumericUpDown nudToleranciaCm;
        private System.Windows.Forms.NumericUpDown nudAlineacion;

        public EleCircuitoTableroForm(
            EjecutarEleCircuitoTableroHandler handler,
            Autodesk.Revit.UI.ExternalEvent externalEvent)
        {
            _handler = handler;
            _externalEvent = externalEvent;

            tablerosIds = new System.Collections.Generic.List<Autodesk.Revit.DB.ElementId>();

            this.Text = "MEP 5.2 - Asignar Circuitos desde Tableros";
            this.Width = 690;
            this.Height = 735;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = true;
            this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;

            InicializarComponentes();
        }

        private void InicializarComponentes()
        {
            System.Windows.Forms.Label lblAutor = new System.Windows.Forms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  MEP - Circuitos desde Tableros",
                Left = 20,
                Top = 10,
                Width = 620,
                Height = 20,
                Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.Gray
            };

            System.Windows.Forms.Label lblTitulo = new System.Windows.Forms.Label()
            {
                Text = "01. SELECCIÓN DE TABLEROS",
                Left = 20,
                Top = 42,
                Width = 620,
                Height = 22,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            System.Windows.Forms.Label lblInfo = new System.Windows.Forms.Label()
            {
                Text = "Selecciona uno o varios tableros. Cada salida conectada al tablero se tomará como un circuito C-01, C-02, etc.",
                Left = 20,
                Top = 68,
                Width = 640,
                Height = 34,
                ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
            };

            btnSeleccionarTableros = CrearBoton(
                "SELECCIONAR TABLEROS",
                20,
                110,
                190,
                System.Drawing.Color.FromArgb(90, 90, 90));

            lstTableros = new System.Windows.Forms.ListBox()
            {
                Left = 230,
                Top = 108,
                Width = 410,
                Height = 86,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                BackColor = System.Drawing.Color.White
            };

            System.Windows.Forms.Label lblConfig = new System.Windows.Forms.Label()
            {
                Text = "02. CONFIGURACIÓN GENERAL",
                Left = 20,
                Top = 212,
                Width = 620,
                Height = 22,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            System.Windows.Forms.Label lblParametro = new System.Windows.Forms.Label()
            {
                Text = "Parámetro de instancia:",
                Left = 20,
                Top = 248,
                Width = 170,
                Height = 22
            };

            txtParametro = new System.Windows.Forms.TextBox()
            {
                Left = 200,
                Top = 245,
                Width = 430,
                Height = 24,
                Text = "ELE_Circuito",
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            };

            System.Windows.Forms.Label lblPrefijo = new System.Windows.Forms.Label()
            {
                Text = "Prefijo:",
                Left = 20,
                Top = 282,
                Width = 70,
                Height = 22
            };

            txtPrefijo = new System.Windows.Forms.TextBox()
            {
                Left = 85,
                Top = 279,
                Width = 80,
                Height = 24,
                Text = "C-",
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            };

            System.Windows.Forms.Label lblInicio = new System.Windows.Forms.Label()
            {
                Text = "Inicio:",
                Left = 190,
                Top = 282,
                Width = 50,
                Height = 22
            };

            nudInicio = new System.Windows.Forms.NumericUpDown()
            {
                Left = 242,
                Top = 279,
                Width = 70,
                Height = 24,
                Minimum = 1,
                Maximum = 999,
                Value = 1
            };

            System.Windows.Forms.Label lblDigitos = new System.Windows.Forms.Label()
            {
                Text = "Dígitos:",
                Left = 335,
                Top = 282,
                Width = 55,
                Height = 22
            };

            nudDigitos = new System.Windows.Forms.NumericUpDown()
            {
                Left = 395,
                Top = 279,
                Width = 70,
                Height = 24,
                Minimum = 1,
                Maximum = 5,
                Value = 2
            };

            chkReiniciarNumeracionPorTablero = new System.Windows.Forms.CheckBox()
            {
                Text = "Reiniciar numeración por cada tablero",
                Left = 20,
                Top = 318,
                Width = 285,
                Height = 24,
                Checked = true
            };

            chkIncluirTableros = new System.Windows.Forms.CheckBox()
            {
                Text = "Asignar también al tablero",
                Left = 320,
                Top = 318,
                Width = 220,
                Height = 24,
                Checked = true
            };

            chkSeleccionarResultado = new System.Windows.Forms.CheckBox()
            {
                Text = "Seleccionar resultado en Revit",
                Left = 20,
                Top = 346,
                Width = 250,
                Height = 24,
                Checked = true
            };

            System.Windows.Forms.Label lblCajas = new System.Windows.Forms.Label()
            {
                Text = "03. CAJAS DE PASE / NODOS DE DISTRIBUCIÓN",
                Left = 20,
                Top = 388,
                Width = 620,
                Height = 22,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            chkNoMezclarCajas = new System.Windows.Forms.CheckBox()
            {
                Text = "No mezclar circuitos en cajas de pase",
                Left = 20,
                Top = 422,
                Width = 295,
                Height = 24,
                Checked = true
            };

            chkContinuarPorAlineacion = new System.Windows.Forms.CheckBox()
            {
                Text = "Continuar por tubo más alineado",
                Left = 330,
                Top = 422,
                Width = 260,
                Height = 24,
                Checked = true
            };

            chkDetenerCajaConflictiva = new System.Windows.Forms.CheckBox()
            {
                Text = "Si hay empate/conflicto, detener el circuito en la caja",
                Left = 20,
                Top = 450,
                Width = 430,
                Height = 24,
                Checked = true
            };

            System.Windows.Forms.Label lblPalabras = new System.Windows.Forms.Label()
            {
                Text = "Detectar cajas por nombre:",
                Left = 20,
                Top = 486,
                Width = 175,
                Height = 22
            };

            txtPalabrasCaja = new System.Windows.Forms.TextBox()
            {
                Left = 200,
                Top = 483,
                Width = 430,
                Height = 24,
                Text = "CAJA;PASE;BOX;JUNCTION;JUNTA;REGISTRO",
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            };

            System.Windows.Forms.Label lblTol = new System.Windows.Forms.Label()
            {
                Text = "Tolerancia XY (cm):",
                Left = 20,
                Top = 520,
                Width = 135,
                Height = 22
            };

            nudToleranciaCm = new System.Windows.Forms.NumericUpDown()
            {
                Left = 160,
                Top = 517,
                Width = 70,
                Height = 24,
                Minimum = 1,
                Maximum = 100,
                Value = 30
            };

            System.Windows.Forms.Label lblAli = new System.Windows.Forms.Label()
            {
                Text = "Alineación mínima:",
                Left = 265,
                Top = 520,
                Width = 130,
                Height = 22
            };

            nudAlineacion = new System.Windows.Forms.NumericUpDown()
            {
                Left = 400,
                Top = 517,
                Width = 70,
                Height = 24,
                DecimalPlaces = 2,
                Increment = 0.05M,
                Minimum = 0.50M,
                Maximum = 1.00M,
                Value = 0.60M
            };

            System.Windows.Forms.Label lblResultado = new System.Windows.Forms.Label()
            {
                Text = "04. RESULTADO",
                Left = 20,
                Top = 560,
                Width = 620,
                Height = 22,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            txtResultado = new System.Windows.Forms.RichTextBox()
            {
                Left = 20,
                Top = 590,
                Width = 620,
                Height = 72,
                ReadOnly = true,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                BackColor = System.Drawing.Color.White,
                Font = new System.Drawing.Font("Consolas", 8.5F),
                WordWrap = false,
                ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
            };

            btnAsignarCircuitos = CrearBoton(
                "ASIGNAR CIRCUITOS",
                220,
                675,
                240,
                System.Drawing.Color.FromArgb(0, 120, 215));

            btnAsignarCircuitos.Height = 38;

            btnSeleccionarTableros.Click += (s, e) => Ejecutar(EleCircuitoRequest.SeleccionarTableros);
            btnAsignarCircuitos.Click += (s, e) => EjecutarAsignacion();

            this.Controls.Add(lblAutor);
            this.Controls.Add(lblTitulo);
            this.Controls.Add(lblInfo);
            this.Controls.Add(btnSeleccionarTableros);
            this.Controls.Add(lstTableros);

            this.Controls.Add(lblConfig);
            this.Controls.Add(lblParametro);
            this.Controls.Add(txtParametro);
            this.Controls.Add(lblPrefijo);
            this.Controls.Add(txtPrefijo);
            this.Controls.Add(lblInicio);
            this.Controls.Add(nudInicio);
            this.Controls.Add(lblDigitos);
            this.Controls.Add(nudDigitos);
            this.Controls.Add(chkReiniciarNumeracionPorTablero);
            this.Controls.Add(chkIncluirTableros);
            this.Controls.Add(chkSeleccionarResultado);

            this.Controls.Add(lblCajas);
            this.Controls.Add(chkNoMezclarCajas);
            this.Controls.Add(chkContinuarPorAlineacion);
            this.Controls.Add(chkDetenerCajaConflictiva);
            this.Controls.Add(lblPalabras);
            this.Controls.Add(txtPalabrasCaja);
            this.Controls.Add(lblTol);
            this.Controls.Add(nudToleranciaCm);
            this.Controls.Add(lblAli);
            this.Controls.Add(nudAlineacion);

            this.Controls.Add(lblResultado);
            this.Controls.Add(txtResultado);
            this.Controls.Add(btnAsignarCircuitos);

            MostrarResultado("Selecciona uno o varios tableros para iniciar.");
        }

        private System.Windows.Forms.Button CrearBoton(
            string texto,
            int left,
            int top,
            int width,
            System.Drawing.Color color)
        {
            System.Windows.Forms.Button boton = new System.Windows.Forms.Button()
            {
                Text = texto,
                Left = left,
                Top = top,
                Width = width,
                Height = 32,
                BackColor = color,
                ForeColor = System.Drawing.Color.White,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                Cursor = System.Windows.Forms.Cursors.Hand
            };

            boton.FlatAppearance.BorderSize = 0;
            boton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(
                System.Math.Max(color.R - 15, 0),
                System.Math.Max(color.G - 15, 0),
                System.Math.Max(color.B - 15, 0));

            return boton;
        }

        private void Ejecutar(EleCircuitoRequest request)
        {
            _handler.Request = request;

            if (_externalEvent == null)
            {
                MostrarResultado("No se pudo crear el evento externo de Revit.");
                return;
            }

            _externalEvent.Raise();
        }

        private void EjecutarAsignacion()
        {
            if (tablerosIds == null || tablerosIds.Count == 0)
            {
                System.Windows.Forms.MessageBox.Show(
                    "Primero debes seleccionar uno o varios tableros.",
                    "MYG",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Warning);
                return;
            }

            _handler.ParametroCircuito = ObtenerTexto(txtParametro.Text, "ELE_Circuito");
            _handler.PrefijoCircuito = ObtenerTexto(txtPrefijo.Text, "C-");
            _handler.NumeroInicial = (int)nudInicio.Value;
            _handler.Digitos = (int)nudDigitos.Value;

            _handler.IncluirTablero = chkIncluirTableros.Checked;
            _handler.SeleccionarResultado = chkSeleccionarResultado.Checked;
            _handler.ReiniciarNumeracionPorTablero = chkReiniciarNumeracionPorTablero.Checked;

            _handler.NoMezclarCircuitosEnCajas = chkNoMezclarCajas.Checked;
            _handler.ContinuarPorAlineacionEnCajas = chkContinuarPorAlineacion.Checked;
            _handler.DetenerSiCajaConflictiva = chkDetenerCajaConflictiva.Checked;
            _handler.PalabrasClaveCajaPase = ObtenerTexto(txtPalabrasCaja.Text, "CAJA;PASE;BOX;JUNCTION;JUNTA;REGISTRO");
            _handler.ToleranciaAlineacionCajaCm = (double)nudToleranciaCm.Value;
            _handler.AlineacionMinima = (double)nudAlineacion.Value;

            Ejecutar(EleCircuitoRequest.AsignarCircuitos);
        }

        public void SetTablerosSeleccionados(
            System.Collections.Generic.List<Autodesk.Revit.DB.Element> tableros)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new System.Action(() => SetTablerosSeleccionados(tableros)));
                return;
            }

            tablerosIds.Clear();
            lstTableros.Items.Clear();

            if (tableros != null)
            {
                foreach (Autodesk.Revit.DB.Element tablero in tableros)
                {
                    if (tablero == null)
                        continue;

                    if (tablero.Id == Autodesk.Revit.DB.ElementId.InvalidElementId)
                        continue;

                    tablerosIds.Add(tablero.Id);
                    lstTableros.Items.Add(tablero.Id.Value + " - " + tablero.Name);
                }
            }

            MostrarResultado("Tableros seleccionados: " + tablerosIds.Count);
        }

        public void MostrarResultado(string texto)
        {
            if (txtResultado == null || txtResultado.IsDisposed)
                return;

            if (this.InvokeRequired)
            {
                this.BeginInvoke(new System.Action(() => MostrarResultado(texto)));
                return;
            }

            txtResultado.Clear();
            txtResultado.SelectionColor = System.Drawing.Color.FromArgb(50, 50, 50);
            txtResultado.AppendText(texto ?? "");
            txtResultado.SelectionStart = 0;
            txtResultado.ScrollToCaret();
        }

        public void AgregarResultado(string texto)
        {
            if (txtResultado == null || txtResultado.IsDisposed)
                return;

            if (this.InvokeRequired)
            {
                this.BeginInvoke(new System.Action(() => AgregarResultado(texto)));
                return;
            }

            txtResultado.AppendText("\r\n" + (texto ?? ""));
            txtResultado.SelectionStart = txtResultado.TextLength;
            txtResultado.ScrollToCaret();
        }

        private static string ObtenerTexto(string texto, string defecto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return defecto;

            return texto.Trim();
        }
    }

}
