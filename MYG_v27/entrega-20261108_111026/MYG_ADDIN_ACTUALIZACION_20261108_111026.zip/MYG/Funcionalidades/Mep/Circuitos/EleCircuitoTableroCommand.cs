using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // COMANDO 5.2 - CIRCUITOS AUTOMÁTICOS
    // =====================================
    [Transaction(TransactionMode.Manual)]
    public class EleCircuitoTableroCommand : IExternalCommand
    {
        private static EleCircuitoTableroForm _form;
        private static EjecutarEleCircuitoTableroHandler _handler;
        private static ExternalEvent _externalEvent;

        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            try
            {
                UIApplication uiapp = commandData.Application;

                if (_form == null || _form.IsDisposed)
                {
                    _handler = new EjecutarEleCircuitoTableroHandler();
                    _externalEvent = ExternalEvent.Create(_handler);

                    _form = new EleCircuitoTableroForm(_handler, _externalEvent);
                    _handler.Form = _form;
                }

                if (!_form.Visible)
                {
                    RevitWindowHandle handle = new RevitWindowHandle(uiapp.MainWindowHandle);
                    _form.Show(handle);
                }
                else
                {
                    _form.Activate();
                }

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return Result.Failed;
            }
        }

        private class RevitWindowHandle : System.Windows.Forms.IWin32Window
        {
            private readonly IntPtr _handle;

            public RevitWindowHandle(IntPtr handle)
            {
                _handle = handle;
            }

            public IntPtr Handle
            {
                get { return _handle; }
            }
        }
    }

}
