﻿// =====================================
// HANDLER EXTERNO 5.1
// GENERAR COLGADORES / HANGERS PARA BANDEJAS PORTACABLES
// CON USING Y NAMESPACE
// REVIT 2027
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MYG_Addin
{
    public class EjecutarHangersBandejasHandler : IExternalEventHandler
    {
        public UIDocument UiDoc { get; set; }
        internal MYG_HangersBandejas51.HangersBandejasForm Form { get; set; }

        private ReferenciaSuperiorPickada referenciaSuperiorPickada;

        public string GetName()
        {
            return "MYG - Generar colgadores para bandejas";
        }

        public void Execute(UIApplication app)
        {
            if (UiDoc == null || UiDoc.Document == null)
                return;

            if (Form == null || Form.IsDisposed)
                return;

            Document doc = UiDoc.Document;

            try
            {
                switch (Form.OperacionSolicitada)
                {
                    case MYG_HangersBandejas51.Operacion.CargarDatos:
                        CargarDatos(doc);
                        break;

                    case MYG_HangersBandejas51.Operacion.UsarSeleccionActual:
                        UsarSeleccionActual(doc);
                        break;

                    case MYG_HangersBandejas51.Operacion.SeleccionarBandejas:
                        SeleccionarBandejas(doc);
                        break;

                    case MYG_HangersBandejas51.Operacion.GenerarColgadores:
                        GenerarColgadores(doc);
                        break;

                    case MYG_HangersBandejas51.Operacion.PickarSuperficie:
                        PickarSuperficieSuperior(doc);
                        break;
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                Mostrar("Selección cancelada por el usuario.");
            }
            catch (Exception ex)
            {
                Mostrar("ERROR GENERAL:\r\n" + ex.Message);
            }
        }

        // =========================================================
        // CARGA DE DATOS
        // =========================================================

        private void CargarDatos(Document doc)
        {
            List<MYG_HangersBandejas51.ComboItem> familias = ObtenerFamiliasCandidatas(doc);
            List<MYG_HangersBandejas51.ComboItem> niveles = ObtenerNiveles(doc);

            Form.SetCatalogos(familias, niveles);
        }

        private List<MYG_HangersBandejas51.ComboItem> ObtenerFamiliasCandidatas(Document doc)
        {
            List<FamilySymbol> todos = new FilteredElementCollector(doc)
                .OfClass(typeof(FamilySymbol))
                .Cast<FamilySymbol>()
                .Where(x => x != null && x.Family != null && x.Category != null)
                .OrderBy(x => x.Family.Name)
                .ThenBy(x => x.Name)
                .ToList();

            List<FamilySymbol> candidatos = todos
                .Where(EsFamiliaCandidataColgador)
                .ToList();

            // Si no encuentra por nombre, muestra familias modelo comunes para que no quede vacío.
            if (candidatos.Count == 0)
            {
                candidatos = todos
                    .Where(x => EsCategoriaModeloComun(x.Category))
                    .ToList();
            }

            return candidatos
                .Select(x => new MYG_HangersBandejas51.ComboItem(
                    x.Id,
                    x.Family.Name + " : " + x.Name + "  [" + x.Category.Name + "]"))
                .ToList();
        }

        private bool EsFamiliaCandidataColgador(FamilySymbol fs)
        {
            if (fs == null)
                return false;

            string texto = Normalizar(
                (fs.Family != null ? fs.Family.Name : "") + " " +
                fs.Name + " " +
                (fs.Category != null ? fs.Category.Name : ""));

            if (texto.Contains("COLGADOR")) return true;
            if (texto.Contains("HANGER")) return true;
            if (texto.Contains("SOPORTE")) return true;
            if (texto.Contains("SUJETADOR")) return true;
            if (texto.Contains("TRAPEZE")) return true;
            if (texto.Contains("TRAPECIO")) return true;
            if (texto.Contains("BANDEJA")) return true;

            return false;
        }

        private bool EsCategoriaModeloComun(Category cat)
        {
            if (cat == null)
                return false;

            string nombre = Normalizar(cat.Name);

            if (nombre.Contains("MODELOS_GENERICOS")) return true;
            if (nombre.Contains("GENERIC_MODELS")) return true;
            if (nombre.Contains("EQUIPOS_ESPECIALES")) return true;
            if (nombre.Contains("SPECIALTY_EQUIPMENT")) return true;
            if (nombre.Contains("EQUIPO_MECANICO")) return true;
            if (nombre.Contains("MECHANICAL_EQUIPMENT")) return true;
            if (nombre.Contains("DISPOSITIVOS_ELECTRICOS")) return true;
            if (nombre.Contains("ELECTRICAL_FIXTURES")) return true;

            try
            {
                if (cat.Id.Value == (long)BuiltInCategory.OST_GenericModel)
                    return true;

                if (cat.Id.Value == (long)BuiltInCategory.OST_SpecialityEquipment)
                    return true;

                if (cat.Id.Value == (long)BuiltInCategory.OST_MechanicalEquipment)
                    return true;

                if (cat.Id.Value == (long)BuiltInCategory.OST_ElectricalFixtures)
                    return true;
            }
            catch
            {
            }

            return false;
        }

        private List<MYG_HangersBandejas51.ComboItem> ObtenerNiveles(Document doc)
        {
            return new FilteredElementCollector(doc)
                .OfClass(typeof(Level))
                .Cast<Level>()
                .OrderBy(x => x.Elevation)
                .Select(x => new MYG_HangersBandejas51.ComboItem(
                    x.Id,
                    x.Name + "  | Elev.: " + Math.Round(FeetToMeters(x.Elevation), 3).ToString("0.###") + " m"))
                .ToList();
        }

        // =========================================================
        // SELECCIÓN
        // =========================================================

        private void UsarSeleccionActual(Document doc)
        {
            ICollection<ElementId> ids = UiDoc.Selection.GetElementIds();

            List<Element> bandejas = ids
                .Select(x => doc.GetElement(x))
                .Where(EsBandejaValida)
                .ToList();

            Form.SetBandejasSeleccionadas(ConvertirBandejasAItems(bandejas));
        }

        private void SeleccionarBandejas(Document doc)
        {
            IList<Reference> refs = UiDoc.Selection.PickObjects(
                ObjectType.Element,
                new FiltroSeleccionBandejas(),
                "Selecciona las bandejas portacables y presiona FINALIZAR");

            List<ElementId> ids = refs
                .Where(x => x != null)
                .Select(x => x.ElementId)
                .Distinct(new ElementIdComparer())
                .ToList();

            UiDoc.Selection.SetElementIds(ids);

            List<Element> bandejas = ids
                .Select(x => doc.GetElement(x))
                .Where(EsBandejaValida)
                .ToList();

            Form.SetBandejasSeleccionadas(ConvertirBandejasAItems(bandejas));
        }

        private List<MYG_HangersBandejas51.ComboItem> ConvertirBandejasAItems(List<Element> bandejas)
        {
            List<MYG_HangersBandejas51.ComboItem> lista = new List<MYG_HangersBandejas51.ComboItem>();

            if (bandejas == null)
                return lista;

            foreach (Element e in bandejas)
            {
                if (e == null)
                    continue;

                string cat = e.Category != null ? e.Category.Name : "Sin categoría";
                string nombre = cat + " | Id: " + e.Id.Value;
                lista.Add(new MYG_HangersBandejas51.ComboItem(e.Id, nombre));
            }

            return lista;
        }

        private void PickarSuperficieSuperior(Document doc)
        {
            bool estabaVisible = Form != null && Form.Visible;

            try
            {
                if (Form != null && !Form.IsDisposed)
                    Form.Hide();

                Reference referencia = UiDoc.Selection.PickObject(
                    ObjectType.Face,
                    new FiltroSeleccionSuperficieSuperior(),
                    "Picka la superficie que será la REFERENCIA SUPERIOR del colgador");

                if (referencia == null)
                    return;

                Element elemento = doc.GetElement(referencia.ElementId);

                if (elemento == null)
                {
                    Mostrar("No se pudo leer el elemento de la superficie pickada.");
                    return;
                }

                XYZ puntoPick = referencia.GlobalPoint;

                if (puntoPick == null)
                    puntoPick = XYZ.Zero;

                GeometryObject geoObj = elemento.GetGeometryObjectFromReference(referencia);
                Face face = geoObj as Face;
                PlanarFace planarFace = face as PlanarFace;

                ReferenciaSuperiorPickada data = new ReferenciaSuperiorPickada();
                data.ElementId = elemento.Id;
                data.ElementUniqueId = elemento.UniqueId;
                data.PuntoPick = puntoPick;
                data.ElevacionFija = puntoPick.Z;
                data.EsPlanar = false;
                data.Origen = puntoPick;
                data.Normal = XYZ.BasisZ;

                if (planarFace != null)
                {
                    XYZ normal = planarFace.FaceNormal;

                    if (normal != null && normal.GetLength() > 0.000001)
                    {
                        data.EsPlanar = true;
                        data.Origen = planarFace.Origin;
                        data.Normal = normal.Normalize();
                    }
                }

                referenciaSuperiorPickada = data;

                string texto =
                    "Referencia superior activa: superficie Id " + elemento.Id.Value +
                    " | Z pick: " + FeetToMeters(puntoPick.Z).ToString("0.###") + " m";

                Form.SetReferenciaSuperiorPickada(texto);
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                Mostrar("Pick de superficie cancelado por el usuario.");
            }
            catch (Exception ex)
            {
                Mostrar("No se pudo pickar la superficie superior:\r\n" + ex.Message);
            }
            finally
            {
                try
                {
                    if (estabaVisible && Form != null && !Form.IsDisposed)
                        Form.Show();
                }
                catch
                {
                }
            }
        }

        // =========================================================
        // GENERACIÓN
        // =========================================================

        private void GenerarColgadores(Document doc)
        {
            FamilySymbol symbol = doc.GetElement(Form.FamiliaColgadorId) as FamilySymbol;
            Level nivelSuperior = doc.GetElement(Form.NivelSuperiorId) as Level;
            List<ElementId> bandejasIds = Form.BandejasSeleccionadasIds;

            bool usarSuperficiePickada =
                Form.UsarSuperficieSuperiorPickada &&
                referenciaSuperiorPickada != null;

            if (symbol == null)
            {
                Mostrar("Debes seleccionar una familia/tipo de colgador.");
                return;
            }

            if (nivelSuperior == null && !usarSuperficiePickada)
            {
                Mostrar("Debes seleccionar un nivel superior de referencia o pickar una superficie superior.");
                return;
            }

            if (bandejasIds == null || bandejasIds.Count == 0)
            {
                Mostrar("Debes seleccionar al menos una bandeja.");
                return;
            }

            double separacion = MetersToFeet(Form.SeparacionMetros);
            double margen = MetersToFeet(Form.MargenLateralMetros);
            double desfase = MetersToFeet(Form.DesfaseInferiorMetros);
            double rotacionExtra = Form.RotacionAdicionalGrados * Math.PI / 180.0;

            if (separacion <= MetersToFeet(0.05))
            {
                Mostrar("La separación debe ser mayor a 0.05 m.");
                return;
            }

            int creados = 0;
            int omitidos = 0;
            int errores = 0;
            int eliminados = 0;
            int omitidosPorTramoVertical = 0;

            StringBuilder reporte = new StringBuilder();

            using (Transaction trans = new Transaction(doc, "MYG - Generar colgadores de bandejas"))
            {
                trans.Start();

                if (!symbol.IsActive)
                {
                    symbol.Activate();
                    doc.Regenerate();
                }

                if (Form.EliminarPrevios)
                {
                    eliminados = EliminarColgadoresPrevios(doc, bandejasIds, Form.ParametroIdBandeja);
                }

                foreach (ElementId bandejaId in bandejasIds)
                {
                    try
                    {
                        Element bandeja = doc.GetElement(bandejaId);

                        if (!EsBandejaValida(bandeja))
                        {
                            omitidos++;
                            reporte.AppendLine("OMITIDO Id " + IdToString(bandejaId) + ": no es una bandeja válida.");
                            continue;
                        }

                        LocationCurve loc = bandeja.Location as LocationCurve;

                        if (loc == null || loc.Curve == null)
                        {
                            omitidos++;
                            reporte.AppendLine("OMITIDO Id " + bandeja.Id.Value + ": no tiene LocationCurve.");
                            continue;
                        }

                        BoundingBoxXYZ bb = bandeja.get_BoundingBox(null);

                        if (bb == null)
                        {
                            omitidos++;
                            reporte.AppendLine("OMITIDO Id " + bandeja.Id.Value + ": no tiene BoundingBox.");
                            continue;
                        }

                        Curve curva = loc.Curve;
                        double longitud = curva.Length;

                        if (longitud <= MetersToFeet(0.05))
                        {
                            omitidos++;
                            reporte.AppendLine("OMITIDO Id " + bandeja.Id.Value + ": longitud muy pequeña.");
                            continue;
                        }

                        List<double> parametrosNormalizados = ObtenerParametrosDistribucion(
                            longitud,
                            separacion,
                            Form.IncluirExtremos);

                        int creadosEnBandeja = 0;
                        int puntosVerticales = 0;
                        int puntosSinPuntoInferior = 0;

                        foreach (double t in parametrosNormalizados)
                        {
                            XYZ puntoCurva = curva.Evaluate(t, true);
                            XYZ direccion = ObtenerDireccionCurva(curva, t);

                            if (EsDireccionVertical(direccion))
                            {
                                puntosVerticales++;
                                omitidosPorTramoVertical++;
                                continue;
                            }

                            XYZ direccionHorizontal = new XYZ(direccion.X, direccion.Y, 0.0);

                            if (direccionHorizontal.GetLength() < 0.000001)
                                direccionHorizontal = XYZ.BasisX;
                            else
                                direccionHorizontal = direccionHorizontal.Normalize();

                            XYZ direccionAncho = new XYZ(-direccionHorizontal.Y, direccionHorizontal.X, 0.0);

                            XYZ puntoInferior = ObtenerPuntoInferiorBandeja(
                                bandeja,
                                puntoCurva,
                                bb,
                                desfase);

                            if (puntoInferior == null)
                            {
                                puntosSinPuntoInferior++;
                                continue;
                            }

                            double zReferenciaSuperior;

                            if (!ObtenerElevacionReferenciaSuperior(
                                puntoInferior,
                                nivelSuperior,
                                usarSuperficiePickada,
                                out zReferenciaSuperior))
                            {
                                omitidos++;
                                reporte.AppendLine("OMITIDO Id " + bandeja.Id.Value + ": no se pudo calcular la referencia superior.");
                                continue;
                            }

                            double alturaColgador = zReferenciaSuperior - puntoInferior.Z;

                            if (alturaColgador <= MetersToFeet(0.02))
                            {
                                omitidos++;
                                reporte.AppendLine("OMITIDO Id " + bandeja.Id.Value + ": la referencia superior está por debajo o muy cerca de la bandeja.");
                                continue;
                            }

                            double anchoBandeja = ObtenerAnchoBandeja(bandeja, bb, direccionAncho);
                            double anchoSoporte = anchoBandeja + (2.0 * margen);

                            FamilyInstance inst = doc.Create.NewFamilyInstance(
                                puntoInferior,
                                symbol,
                                StructuralType.NonStructural);

                            RotarInstancia(doc, inst.Id, puntoInferior, direccionAncho, rotacionExtra);

                            SetParametroLongitud(inst, Form.ParametroAltura, alturaColgador);
                            SetParametroLongitud(inst, Form.ParametroAncho, anchoSoporte);
                            SetParametroTexto(inst, Form.ParametroIdBandeja, bandeja.Id.Value.ToString());

                            if (Form.AsignarDisciplina)
                                SetParametroTexto(inst, Form.ParametroDisciplina, "MEP");

                            creados++;
                            creadosEnBandeja++;
                        }

                        if (creadosEnBandeja == 0)
                            omitidos++;

                        reporte.AppendLine(
                            "OK Id " + bandeja.Id.Value +
                            " | Longitud: " + FeetToMeters(longitud).ToString("0.00") + " m" +
                            " | Creados: " + creadosEnBandeja +
                            " | Verticales omitidos: " + puntosVerticales +
                            " | Sin punto inferior: " + puntosSinPuntoInferior);
                    }
                    catch (Exception exElemento)
                    {
                        errores++;
                        reporte.AppendLine("ERROR Id " + IdToString(bandejaId) + ": " + exElemento.Message);
                    }
                }

                trans.Commit();
            }

            Mostrar(
                "PROCESO TERMINADO\r\n" +
                "----------------------------------------\r\n" +
                "Colgadores creados: " + creados + "\r\n" +
                "Colgadores previos eliminados: " + eliminados + "\r\n" +
                "Puntos omitidos por tramo vertical: " + omitidosPorTramoVertical + "\r\n" +
                "Omitidos: " + omitidos + "\r\n" +
                "Errores: " + errores + "\r\n\r\n" +
                reporte.ToString());
        }

        private List<double> ObtenerParametrosDistribucion(
            double longitud,
            double separacion,
            bool incluirExtremos)
        {
            List<double> parametros = new List<double>();

            if (longitud <= 0.000001)
                return parametros;

            if (longitud <= separacion)
            {
                parametros.Add(0.5);
                return parametros;
            }

            if (incluirExtremos)
            {
                parametros.Add(0.0);

                double d = separacion;

                while (d < longitud - MetersToFeet(0.05))
                {
                    parametros.Add(d / longitud);
                    d += separacion;
                }

                parametros.Add(1.0);
            }
            else
            {
                double d = separacion;

                while (d < longitud - MetersToFeet(0.05))
                {
                    parametros.Add(d / longitud);
                    d += separacion;
                }

                if (parametros.Count == 0)
                    parametros.Add(0.5);
            }

            return parametros
                .Where(x => x >= 0.0 && x <= 1.0)
                .Distinct(new DoubleComparer(0.000001))
                .OrderBy(x => x)
                .ToList();
        }

        private bool EsDireccionVertical(XYZ direccion)
        {
            if (direccion == null || direccion.GetLength() < 0.000001)
                return true;

            XYZ dir = direccion.Normalize();
            double horizontal = Math.Sqrt((dir.X * dir.X) + (dir.Y * dir.Y));

            // Si el tramo es prácticamente vertical, no debe recibir colgadores.
            if (horizontal < 0.15)
                return true;

            if (Math.Abs(dir.Z) > 0.985)
                return true;

            return false;
        }

        private XYZ ObtenerPuntoInferiorBandeja(
            Element bandeja,
            XYZ puntoCurva,
            BoundingBoxXYZ bb,
            double desfase)
        {
            XYZ puntoInferior = ObtenerPuntoInferiorPorInterseccionVertical(
                bandeja,
                puntoCurva,
                bb);

            if (puntoInferior != null)
                return new XYZ(puntoInferior.X, puntoInferior.Y, puntoInferior.Z - desfase);

            double alturaLocal = LeerParametroDouble(
                bandeja,
                "Altura",
                "Alto",
                "Height",
                "Tray Height",
                "Cable Tray Height");

            if (alturaLocal <= 0.0)
                alturaLocal = ObtenerSemiAlturaBandeja(bb) * 2.0;

            if (alturaLocal <= 0.0)
                return null;

            return new XYZ(
                puntoCurva.X,
                puntoCurva.Y,
                puntoCurva.Z - (alturaLocal / 2.0) - desfase);
        }

        private XYZ ObtenerPuntoInferiorPorInterseccionVertical(
            Element elemento,
            XYZ puntoCurva,
            BoundingBoxXYZ bb)
        {
            if (elemento == null || puntoCurva == null || bb == null)
                return null;

            try
            {
                double margenVertical = MetersToFeet(2.00);

                XYZ pSuperior = new XYZ(
                    puntoCurva.X,
                    puntoCurva.Y,
                    bb.Max.Z + margenVertical);

                XYZ pInferior = new XYZ(
                    puntoCurva.X,
                    puntoCurva.Y,
                    bb.Min.Z - margenVertical);

                Line lineaVertical = Line.CreateBound(pSuperior, pInferior);

                Options opciones = new Options();
                opciones.ComputeReferences = false;
                opciones.IncludeNonVisibleObjects = false;
                opciones.DetailLevel = ViewDetailLevel.Fine;

                GeometryElement ge = elemento.get_Geometry(opciones);

                if (ge == null)
                    return null;

                List<Solid> solidos = new List<Solid>();
                RecolectarSolidos(ge, solidos);

                List<XYZ> puntos = new List<XYZ>();

                foreach (Solid solid in solidos)
                {
                    if (solid == null || solid.Faces == null || solid.Faces.Size == 0)
                        continue;

                    foreach (Face face in solid.Faces)
                    {
                        if (face == null)
                            continue;

                        try
                        {
                            IntersectionResultArray resultados;
                            SetComparisonResult comparacion = face.Intersect(lineaVertical, out resultados);

                            if (resultados == null || resultados.Size == 0)
                                continue;

                            for (int i = 0; i < resultados.Size; i++)
                            {
                                IntersectionResult ir = resultados.get_Item(i);

                                if (ir == null || ir.XYZPoint == null)
                                    continue;

                                XYZ p = ir.XYZPoint;

                                if (p.Z < bb.Min.Z - margenVertical || p.Z > bb.Max.Z + margenVertical)
                                    continue;

                                puntos.Add(p);
                            }
                        }
                        catch
                        {
                        }
                    }
                }

                if (puntos.Count == 0)
                    return null;

                // El punto más bajo sobre la vertical del eje representa la superficie inferior real.
                // Esto corrige los tramos inclinados, porque ya no usa el alto total del BoundingBox.
                return puntos
                    .OrderBy(x => x.Z)
                    .FirstOrDefault();
            }
            catch
            {
                return null;
            }
        }

        private void RecolectarSolidos(GeometryElement ge, List<Solid> solidos)
        {
            if (ge == null || solidos == null)
                return;

            foreach (GeometryObject obj in ge)
            {
                Solid solid = obj as Solid;

                if (solid != null && solid.Faces != null && solid.Faces.Size > 0)
                {
                    solidos.Add(solid);
                    continue;
                }

                GeometryInstance gi = obj as GeometryInstance;

                if (gi != null)
                {
                    try
                    {
                        GeometryElement geInstancia = gi.GetInstanceGeometry();
                        RecolectarSolidos(geInstancia, solidos);
                    }
                    catch
                    {
                    }
                }
            }
        }

        private bool ObtenerElevacionReferenciaSuperior(
            XYZ puntoBase,
            Level nivelSuperior,
            bool usarSuperficiePickada,
            out double elevacion)
        {
            elevacion = 0.0;

            if (usarSuperficiePickada && referenciaSuperiorPickada != null)
                return referenciaSuperiorPickada.ObtenerElevacionEnPunto(puntoBase, out elevacion);

            if (nivelSuperior != null)
            {
                elevacion = nivelSuperior.Elevation;
                return true;
            }

            return false;
        }

        private XYZ ObtenerDireccionCurva(Curve curva, double parametroNormalizado)
        {
            try
            {
                double delta = 0.001;
                double t1 = Math.Max(0.0, parametroNormalizado - delta);
                double t2 = Math.Min(1.0, parametroNormalizado + delta);

                if (Math.Abs(t2 - t1) < 0.000001)
                {
                    t1 = 0.0;
                    t2 = 1.0;
                }

                XYZ p1 = curva.Evaluate(t1, true);
                XYZ p2 = curva.Evaluate(t2, true);
                XYZ dir = p2 - p1;

                if (dir.GetLength() > 0.000001)
                    return dir.Normalize();
            }
            catch
            {
            }

            try
            {
                XYZ p1 = curva.GetEndPoint(0);
                XYZ p2 = curva.GetEndPoint(1);
                XYZ dir = p2 - p1;

                if (dir.GetLength() > 0.000001)
                    return dir.Normalize();
            }
            catch
            {
            }

            return XYZ.BasisX;
        }

        private double ObtenerSemiAlturaBandeja(BoundingBoxXYZ bb)
        {
            if (bb == null)
                return 0.0;

            double h = bb.Max.Z - bb.Min.Z;

            if (h <= 0.0)
                return 0.0;

            return h / 2.0;
        }

        private double ObtenerAnchoBandeja(Element bandeja, BoundingBoxXYZ bb, XYZ direccionAncho)
        {
            double valorParam = LeerParametroDouble(
                bandeja,
                "Ancho",
                "Width",
                "Tray Width",
                "Cable Tray Width");

            if (valorParam > 0.0)
                return valorParam;

            return MedirBoundingBoxEnDireccion(bb, direccionAncho);
        }

        private double MedirBoundingBoxEnDireccion(BoundingBoxXYZ bb, XYZ direccion)
        {
            if (bb == null)
                return 0.0;

            if (direccion == null || direccion.GetLength() < 0.000001)
                direccion = XYZ.BasisX;
            else
                direccion = direccion.Normalize();

            List<XYZ> puntos = new List<XYZ>();

            puntos.Add(new XYZ(bb.Min.X, bb.Min.Y, bb.Min.Z));
            puntos.Add(new XYZ(bb.Min.X, bb.Min.Y, bb.Max.Z));
            puntos.Add(new XYZ(bb.Min.X, bb.Max.Y, bb.Min.Z));
            puntos.Add(new XYZ(bb.Min.X, bb.Max.Y, bb.Max.Z));
            puntos.Add(new XYZ(bb.Max.X, bb.Min.Y, bb.Min.Z));
            puntos.Add(new XYZ(bb.Max.X, bb.Min.Y, bb.Max.Z));
            puntos.Add(new XYZ(bb.Max.X, bb.Max.Y, bb.Min.Z));
            puntos.Add(new XYZ(bb.Max.X, bb.Max.Y, bb.Max.Z));

            double min = double.MaxValue;
            double max = double.MinValue;

            foreach (XYZ p in puntos)
            {
                double proy = p.DotProduct(direccion);

                if (proy < min) min = proy;
                if (proy > max) max = proy;
            }

            double ancho = max - min;

            if (ancho <= 0.0)
                return 0.0;

            return ancho;
        }

        private void RotarInstancia(
            Document doc,
            ElementId instanciaId,
            XYZ punto,
            XYZ direccionAncho,
            double rotacionExtra)
        {
            try
            {
                if (direccionAncho == null || direccionAncho.GetLength() < 0.000001)
                    return;

                XYZ dir = direccionAncho.Normalize();
                double angulo = Math.Atan2(dir.Y, dir.X) + rotacionExtra;

                Line eje = Line.CreateBound(
                    punto,
                    punto + XYZ.BasisZ);

                ElementTransformUtils.RotateElement(doc, instanciaId, eje, angulo);
            }
            catch
            {
            }
        }

        // =========================================================
        // ELIMINAR PREVIOS
        // =========================================================

        private int EliminarColgadoresPrevios(
            Document doc,
            List<ElementId> bandejasIds,
            string nombreParametroIdBandeja)
        {
            if (bandejasIds == null || bandejasIds.Count == 0)
                return 0;

            HashSet<string> idsTexto = new HashSet<string>(
                bandejasIds.Select(x => x.Value.ToString()));

            List<ElementId> eliminar = new List<ElementId>();

            List<FamilyInstance> instancias = new FilteredElementCollector(doc)
                .OfClass(typeof(FamilyInstance))
                .Cast<FamilyInstance>()
                .ToList();

            foreach (FamilyInstance fi in instancias)
            {
                Parameter p = BuscarParametro(fi, nombreParametroIdBandeja);

                if (p == null)
                    continue;

                string valor = ObtenerValorTexto(p);

                if (idsTexto.Contains(valor))
                    eliminar.Add(fi.Id);
            }

            if (eliminar.Count == 0)
                return 0;

            doc.Delete(eliminar);
            return eliminar.Count;
        }

        // =========================================================
        // PARÁMETROS
        // =========================================================

        private bool SetParametroLongitud(Element elemento, string nombreParametro, double valorFeet)
        {
            Parameter p = BuscarParametro(elemento, nombreParametro);

            if (p == null || p.IsReadOnly)
                return false;

            try
            {
                if (p.StorageType == StorageType.Double)
                {
                    p.Set(valorFeet);
                    return true;
                }

                if (p.StorageType == StorageType.String)
                {
                    p.Set(FeetToMeters(valorFeet).ToString("0.###"));
                    return true;
                }
            }
            catch
            {
            }

            return false;
        }

        private bool SetParametroTexto(Element elemento, string nombreParametro, string valor)
        {
            Parameter p = BuscarParametro(elemento, nombreParametro);

            if (p == null || p.IsReadOnly)
                return false;

            try
            {
                if (p.StorageType == StorageType.String)
                {
                    p.Set(valor ?? "");
                    return true;
                }

                if (p.StorageType == StorageType.Integer)
                {
                    int numero;

                    if (int.TryParse(valor, out numero))
                    {
                        p.Set(numero);
                        return true;
                    }
                }
            }
            catch
            {
            }

            return false;
        }

        private double LeerParametroDouble(Element elemento, params string[] nombres)
        {
            if (elemento == null || nombres == null)
                return 0.0;

            foreach (string nombre in nombres)
            {
                Parameter p = BuscarParametro(elemento, nombre);

                if (p == null)
                    continue;

                try
                {
                    if (p.StorageType == StorageType.Double)
                        return p.AsDouble();
                }
                catch
                {
                }
            }

            return 0.0;
        }

        private Parameter BuscarParametro(Element elemento, string nombreParametro)
        {
            if (elemento == null || string.IsNullOrWhiteSpace(nombreParametro))
                return null;

            Parameter p = elemento.LookupParameter(nombreParametro);

            if (p != null)
                return p;

            string nombreNormalizado = Normalizar(nombreParametro);

            foreach (Parameter param in elemento.Parameters)
            {
                if (param == null || param.Definition == null)
                    continue;

                if (Normalizar(param.Definition.Name) == nombreNormalizado)
                    return param;
            }

            return null;
        }

        private string ObtenerValorTexto(Parameter p)
        {
            if (p == null)
                return "";

            try
            {
                if (p.StorageType == StorageType.String)
                    return p.AsString() ?? "";

                if (p.StorageType == StorageType.Integer)
                    return p.AsInteger().ToString();

                if (p.StorageType == StorageType.ElementId)
                    return p.AsElementId().Value.ToString();
            }
            catch
            {
            }

            return "";
        }

        // =========================================================
        // VALIDACIÓN BANDEJAS
        // =========================================================

        private static bool EsBandejaValida(Element e)
        {
            if (e == null || e.Category == null)
                return false;

            if (!(e.Location is LocationCurve))
                return false;

            string cat = Normalizar(e.Category.Name);
            string tipo = Normalizar(e.GetType().Name);

            if (cat.Contains("BANDEJA")) return true;
            if (cat.Contains("CABLE_TRAY")) return true;
            if (cat.Contains("CABLETRAY")) return true;
            if (cat.Contains("PORTACABLE")) return true;

            if (tipo.Contains("CABLETRAY")) return true;

            try
            {
                if (e.Category.Id.Value == (long)BuiltInCategory.OST_CableTray)
                    return true;
            }
            catch
            {
            }

            // Para algunos Fabrication Parts de contención, siempre que tengan LocationCurve.
            if (tipo.Contains("FABRICATIONPART") &&
                (cat.Contains("FABRICACION") || cat.Contains("FABRICACIÓN") || cat.Contains("FABRICATION")))
            {
                return true;
            }

            return false;
        }

        internal class FiltroSeleccionBandejas : ISelectionFilter
        {
            public bool AllowElement(Element elem)
            {
                return EsBandejaValida(elem);
            }

            public bool AllowReference(Reference reference, XYZ position)
            {
                return false;
            }
        }

        internal class FiltroSeleccionSuperficieSuperior : ISelectionFilter
        {
            public bool AllowElement(Element elem)
            {
                return elem != null;
            }

            public bool AllowReference(Reference reference, XYZ position)
            {
                return reference != null;
            }
        }

        // =========================================================
        // UTILIDADES
        // =========================================================

        private void Mostrar(string texto)
        {
            if (Form != null && !Form.IsDisposed)
                Form.MostrarResultado(texto);
        }

        private static double MetersToFeet(double metros)
        {
            try
            {
                return UnitUtils.ConvertToInternalUnits(metros, UnitTypeId.Meters);
            }
            catch
            {
                return metros / 0.3048;
            }
        }

        private static double FeetToMeters(double feet)
        {
            try
            {
                return UnitUtils.ConvertFromInternalUnits(feet, UnitTypeId.Meters);
            }
            catch
            {
                return feet * 0.3048;
            }
        }

        private static string Normalizar(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return "";

            return texto
                .Replace('\u00A0', ' ')
                .Replace('\t', ' ')
                .Trim()
                .ToUpperInvariant()
                .Replace("Á", "A")
                .Replace("É", "E")
                .Replace("Í", "I")
                .Replace("Ó", "O")
                .Replace("Ú", "U")
                .Replace("Ñ", "N")
                .Replace("-", "_")
                .Replace("/", "_")
                .Replace(" ", "_");
        }

        private static string IdToString(ElementId id)
        {
            if (id == null)
                return "";

            return id.Value.ToString();
        }

        internal class ReferenciaSuperiorPickada
        {
            public ElementId ElementId { get; set; }
            public string ElementUniqueId { get; set; }
            public XYZ PuntoPick { get; set; }
            public XYZ Origen { get; set; }
            public XYZ Normal { get; set; }
            public bool EsPlanar { get; set; }
            public double ElevacionFija { get; set; }

            public bool ObtenerElevacionEnPunto(XYZ puntoBase, out double elevacion)
            {
                elevacion = ElevacionFija;

                if (puntoBase == null)
                    return false;

                try
                {
                    if (EsPlanar && Origen != null && Normal != null && Math.Abs(Normal.Z) > 0.000001)
                    {
                        elevacion = Origen.Z -
                            ((Normal.X * (puntoBase.X - Origen.X)) +
                             (Normal.Y * (puntoBase.Y - Origen.Y))) / Normal.Z;

                        return true;
                    }

                    elevacion = ElevacionFija;
                    return true;
                }
                catch
                {
                    elevacion = ElevacionFija;
                    return true;
                }
            }
        }

        internal class ElementIdComparer : IEqualityComparer<ElementId>
        {
            public bool Equals(ElementId x, ElementId y)
            {
                if (x == null || y == null)
                    return false;

                return x.Value == y.Value;
            }

            public int GetHashCode(ElementId obj)
            {
                if (obj == null)
                    return 0;

                return obj.Value.GetHashCode();
            }
        }

        internal class DoubleComparer : IEqualityComparer<double>
        {
            private readonly double tolerancia;

            public DoubleComparer(double tolerancia)
            {
                this.tolerancia = tolerancia;
            }

            public bool Equals(double x, double y)
            {
                return Math.Abs(x - y) <= tolerancia;
            }

            public int GetHashCode(double obj)
            {
                return Math.Round(obj / tolerancia).GetHashCode();
            }
        }
    }
}
