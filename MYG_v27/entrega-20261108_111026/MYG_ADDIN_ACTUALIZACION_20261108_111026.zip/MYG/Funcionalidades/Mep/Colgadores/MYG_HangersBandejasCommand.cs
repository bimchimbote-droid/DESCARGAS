using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{










    // =====================================
    // COMANDO 5.1 - GENERAR COLGADORES PARA BANDEJAS
    // =====================================

    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class MYG_HangersBandejasCommand : Autodesk.Revit.UI.IExternalCommand
    {
        public Autodesk.Revit.UI.Result Execute(
            Autodesk.Revit.UI.ExternalCommandData commandData,
            ref string message,
            Autodesk.Revit.DB.ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            Autodesk.Revit.UI.UIDocument uidoc = commandData.Application.ActiveUIDocument;

            if (uidoc == null || uidoc.Document == null)
            {
                message = "No hay documento activo.";
                return Autodesk.Revit.UI.Result.Failed;
            }

            MYG_HangersBandejas51.HangersBandejasForm form =
                new MYG_HangersBandejas51.HangersBandejasForm();

            EjecutarHangersBandejasHandler handler = new EjecutarHangersBandejasHandler();
            handler.UiDoc = uidoc;
            handler.Form = form;

            Autodesk.Revit.UI.ExternalEvent ejecutarEvent =
                Autodesk.Revit.UI.ExternalEvent.Create(handler);

            form.EjecutarEvent = ejecutarEvent;
            form.Show();
            form.SolicitarCargaInicial();

            return Autodesk.Revit.UI.Result.Succeeded;
        }
    }

}
