using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{


































    // =====================================
    // VENTANA 5.1 - GENERAR COLGADORES PARA BANDEJAS
    // =====================================

    public static class MYG_HangersBandejas51
    {
        internal enum Operacion
        {
            Ninguna = 0,
            CargarDatos = 1,
            UsarSeleccionActual = 2,
            SeleccionarBandejas = 3,
            GenerarColgadores = 4,
            PickarSuperficie = 5
        }

        internal class ComboItem
        {
            public Autodesk.Revit.DB.ElementId Id { get; set; }
            public string Nombre { get; set; }

            public ComboItem()
            {
                Id = Autodesk.Revit.DB.ElementId.InvalidElementId;
                Nombre = "";
            }

            public ComboItem(Autodesk.Revit.DB.ElementId id, string nombre)
            {
                Id = id;
                Nombre = nombre;
            }

            public override string ToString()
            {
                return Nombre;
            }
        }

        internal class HangersBandejasForm : WinForms.Form
        {
            private WinForms.ComboBox cmbFamiliaColgador;
            private WinForms.ComboBox cmbNivelSuperior;
            private WinForms.Button btnPickarSuperficie;
            private WinForms.Label lblReferenciaPickada;

            private WinForms.TextBox txtSeparacion;
            private WinForms.TextBox txtMargenLateral;
            private WinForms.TextBox txtDesfaseInferior;
            private WinForms.TextBox txtParametroAltura;
            private WinForms.TextBox txtParametroAncho;
            private WinForms.TextBox txtParametroIdBandeja;
            private WinForms.TextBox txtParametroDisciplina;
            private WinForms.TextBox txtRotacionAdicional;

            private WinForms.CheckBox chkIncluirExtremos;
            private WinForms.CheckBox chkEliminarPrevios;
            private WinForms.CheckBox chkAsignarDisciplina;

            private WinForms.Button btnCargarDatos;
            private WinForms.Button btnUsarSeleccionActual;
            private WinForms.Button btnSeleccionarBandejas;
            private WinForms.Button btnGenerar;

            private WinForms.ListBox lstBandejas;
            private WinForms.RichTextBox txtResultado;

            private System.Collections.Generic.List<Autodesk.Revit.DB.ElementId> bandejasIds;
            private bool referenciaSuperiorPickadaActiva;

            public Autodesk.Revit.UI.ExternalEvent EjecutarEvent;
            internal Operacion OperacionSolicitada { get; private set; }

            internal System.Collections.Generic.List<Autodesk.Revit.DB.ElementId> BandejasSeleccionadasIds
            {
                get
                {
                    if (bandejasIds == null)
                        bandejasIds = new System.Collections.Generic.List<Autodesk.Revit.DB.ElementId>();

                    return new System.Collections.Generic.List<Autodesk.Revit.DB.ElementId>(bandejasIds);
                }
            }

            internal Autodesk.Revit.DB.ElementId FamiliaColgadorId
            {
                get
                {
                    ComboItem item = cmbFamiliaColgador.SelectedItem as ComboItem;

                    if (item == null)
                        return Autodesk.Revit.DB.ElementId.InvalidElementId;

                    return item.Id;
                }
            }

            internal Autodesk.Revit.DB.ElementId NivelSuperiorId
            {
                get
                {
                    ComboItem item = cmbNivelSuperior.SelectedItem as ComboItem;

                    if (item == null)
                        return Autodesk.Revit.DB.ElementId.InvalidElementId;

                    return item.Id;
                }
            }

            internal double SeparacionMetros => LeerDouble(txtSeparacion.Text, 1.50);
            internal double MargenLateralMetros => LeerDouble(txtMargenLateral.Text, 0.10);
            internal double DesfaseInferiorMetros => LeerDouble(txtDesfaseInferior.Text, 0.00);
            internal double RotacionAdicionalGrados => LeerDouble(txtRotacionAdicional.Text, 0.00);

            internal string ParametroAltura => ObtenerTexto(txtParametroAltura.Text, "Altura de colgador");
            internal string ParametroAncho => ObtenerTexto(txtParametroAncho.Text, "Ancho de soporte");
            internal string ParametroIdBandeja => ObtenerTexto(txtParametroIdBandeja.Text, "ID_Bandeja_Anfitriona");
            internal string ParametroDisciplina => ObtenerTexto(txtParametroDisciplina.Text, "GEN_Disciplina");

            internal bool IncluirExtremos => chkIncluirExtremos.Checked;
            internal bool EliminarPrevios => chkEliminarPrevios.Checked;
            internal bool AsignarDisciplina => chkAsignarDisciplina.Checked;
            internal bool UsarSuperficieSuperiorPickada => referenciaSuperiorPickadaActiva;

            public HangersBandejasForm()
            {
                bandejasIds = new System.Collections.Generic.List<Autodesk.Revit.DB.ElementId>();
                referenciaSuperiorPickadaActiva = false;
                OperacionSolicitada = Operacion.Ninguna;

                this.Text = "MEP 5.1 - Generar Colgadores de Bandejas";
                this.Width = 690;
                this.Height = 790;
                this.StartPosition = WinForms.FormStartPosition.CenterScreen;
                this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
                this.MaximizeBox = false;
                this.MinimizeBox = true;
                this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
                this.Font = new Drawing.Font("Segoe UI", 9F);
                this.TopMost = true;

                WinForms.Label lblAutor = new WinForms.Label()
                {
                    Text = "Creado por: Ing. Marlon Yacila  |  MEP - Bandejas a Colgadores",
                    Left = 20,
                    Top = 10,
                    Width = 620,
                    Height = 20,
                    Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.Gray
                };

                WinForms.Label lblTitulo = new WinForms.Label()
                {
                    Text = "01. CONFIGURACIÓN DEL COLGADOR",
                    Left = 20,
                    Top = 42,
                    Width = 620,
                    Height = 22,
                    Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(50, 50, 50)
                };

                WinForms.Label lblFamilia = new WinForms.Label()
                {
                    Text = "Familia / Tipo de colgador:",
                    Left = 20,
                    Top = 75,
                    Width = 180,
                    Height = 22
                };

                cmbFamiliaColgador = new WinForms.ComboBox()
                {
                    Left = 210,
                    Top = 72,
                    Width = 420,
                    Height = 25,
                    DropDownStyle = WinForms.ComboBoxStyle.DropDownList
                };

                WinForms.Label lblNivel = new WinForms.Label()
                {
                    Text = "Nivel superior de referencia:",
                    Left = 20,
                    Top = 110,
                    Width = 180,
                    Height = 22
                };

                cmbNivelSuperior = new WinForms.ComboBox()
                {
                    Left = 210,
                    Top = 107,
                    Width = 270,
                    Height = 25,
                    DropDownStyle = WinForms.ComboBoxStyle.DropDownList
                };

                cmbNivelSuperior.SelectionChangeCommitted += (s, e) =>
                {
                    referenciaSuperiorPickadaActiva = false;

                    if (lblReferenciaPickada != null)
                    {
                        lblReferenciaPickada.Text = "Referencia superior activa: nivel seleccionado.";
                        lblReferenciaPickada.ForeColor = Drawing.Color.FromArgb(90, 90, 90);
                    }
                };

                btnPickarSuperficie = CrearBoton("PICKAR SUPERFICIE", 490, 104, 140, Drawing.Color.FromArgb(90, 90, 90));
                btnPickarSuperficie.Height = 29;

                lblReferenciaPickada = new WinForms.Label()
                {
                    Text = "Referencia superior activa: nivel seleccionado.",
                    Left = 210,
                    Top = 135,
                    Width = 420,
                    Height = 18,
                    Font = new Drawing.Font("Segoe UI", 8F),
                    ForeColor = Drawing.Color.FromArgb(90, 90, 90)
                };

                WinForms.Label lblParametros = new WinForms.Label()
                {
                    Text = "02. PARÁMETROS DE DISTRIBUCIÓN",
                    Left = 20,
                    Top = 152,
                    Width = 620,
                    Height = 22,
                    Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(50, 50, 50)
                };

                WinForms.Label lblSeparacion = new WinForms.Label()
                {
                    Text = "Separación entre colgadores (m):",
                    Left = 20,
                    Top = 188,
                    Width = 210,
                    Height = 22
                };

                txtSeparacion = new WinForms.TextBox()
                {
                    Left = 240,
                    Top = 185,
                    Width = 80,
                    Height = 24,
                    Text = "1.50",
                    BorderStyle = WinForms.BorderStyle.FixedSingle
                };

                WinForms.Label lblMargen = new WinForms.Label()
                {
                    Text = "Margen lateral por lado (m):",
                    Left = 350,
                    Top = 188,
                    Width = 190,
                    Height = 22
                };

                txtMargenLateral = new WinForms.TextBox()
                {
                    Left = 550,
                    Top = 185,
                    Width = 80,
                    Height = 24,
                    Text = "0.10",
                    BorderStyle = WinForms.BorderStyle.FixedSingle
                };

                WinForms.Label lblDesfase = new WinForms.Label()
                {
                    Text = "Desfase bajo bandeja (m):",
                    Left = 20,
                    Top = 220,
                    Width = 210,
                    Height = 22
                };

                txtDesfaseInferior = new WinForms.TextBox()
                {
                    Left = 240,
                    Top = 217,
                    Width = 80,
                    Height = 24,
                    Text = "0.00",
                    BorderStyle = WinForms.BorderStyle.FixedSingle
                };

                WinForms.Label lblRotacion = new WinForms.Label()
                {
                    Text = "Rotación adicional (°):",
                    Left = 350,
                    Top = 220,
                    Width = 190,
                    Height = 22
                };

                txtRotacionAdicional = new WinForms.TextBox()
                {
                    Left = 550,
                    Top = 217,
                    Width = 80,
                    Height = 24,
                    Text = "0.00",
                    BorderStyle = WinForms.BorderStyle.FixedSingle
                };

                chkIncluirExtremos = new WinForms.CheckBox()
                {
                    Text = "Incluir colgadores en extremos de cada tramo",
                    Left = 20,
                    Top = 252,
                    Width = 330,
                    Height = 24,
                    Checked = true
                };

                chkEliminarPrevios = new WinForms.CheckBox()
                {
                    Text = "Eliminar colgadores previos vinculados a las bandejas seleccionadas",
                    Left = 20,
                    Top = 278,
                    Width = 490,
                    Height = 24,
                    Checked = false
                };

                chkAsignarDisciplina = new WinForms.CheckBox()
                {
                    Text = "Asignar GEN_Disciplina = MEP",
                    Left = 20,
                    Top = 304,
                    Width = 260,
                    Height = 24,
                    Checked = true
                };

                WinForms.Label lblParamsFamilia = new WinForms.Label()
                {
                    Text = "03. NOMBRES DE PARÁMETROS DE LA FAMILIA",
                    Left = 20,
                    Top = 342,
                    Width = 620,
                    Height = 22,
                    Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(50, 50, 50)
                };

                WinForms.Label lblParamAltura = new WinForms.Label()
                {
                    Text = "Altura:",
                    Left = 20,
                    Top = 375,
                    Width = 85,
                    Height = 22
                };

                txtParametroAltura = new WinForms.TextBox()
                {
                    Left = 105,
                    Top = 372,
                    Width = 205,
                    Height = 24,
                    Text = "Altura de colgador",
                    BorderStyle = WinForms.BorderStyle.FixedSingle
                };

                WinForms.Label lblParamAncho = new WinForms.Label()
                {
                    Text = "Ancho:",
                    Left = 330,
                    Top = 375,
                    Width = 75,
                    Height = 22
                };

                txtParametroAncho = new WinForms.TextBox()
                {
                    Left = 405,
                    Top = 372,
                    Width = 225,
                    Height = 24,
                    Text = "Ancho de soporte",
                    BorderStyle = WinForms.BorderStyle.FixedSingle
                };

                WinForms.Label lblParamId = new WinForms.Label()
                {
                    Text = "ID bandeja:",
                    Left = 20,
                    Top = 408,
                    Width = 85,
                    Height = 22
                };

                txtParametroIdBandeja = new WinForms.TextBox()
                {
                    Left = 105,
                    Top = 405,
                    Width = 205,
                    Height = 24,
                    Text = "ID_Bandeja_Anfitriona",
                    BorderStyle = WinForms.BorderStyle.FixedSingle
                };

                WinForms.Label lblParamDisc = new WinForms.Label()
                {
                    Text = "Disciplina:",
                    Left = 330,
                    Top = 408,
                    Width = 75,
                    Height = 22
                };

                txtParametroDisciplina = new WinForms.TextBox()
                {
                    Left = 405,
                    Top = 405,
                    Width = 225,
                    Height = 24,
                    Text = "GEN_Disciplina",
                    BorderStyle = WinForms.BorderStyle.FixedSingle
                };

                WinForms.Label lblNotaReferencia = new WinForms.Label()
                {
                    Text = "Nota: en la familia, la referencia 'REFERENCIA SUPERIOR' debe estar controlada por el parámetro de instancia 'Altura de colgador'.",
                    Left = 20,
                    Top = 438,
                    Width = 620,
                    Height = 35,
                    ForeColor = Drawing.Color.FromArgb(90, 90, 90)
                };

                WinForms.Label lblSeleccion = new WinForms.Label()
                {
                    Text = "04. BANDEJAS SELECCIONADAS",
                    Left = 20,
                    Top = 482,
                    Width = 620,
                    Height = 22,
                    Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(50, 50, 50)
                };

                btnCargarDatos = CrearBoton("RECARGAR DATOS", 20, 510, 140, Drawing.Color.FromArgb(90, 90, 90));
                btnUsarSeleccionActual = CrearBoton("USAR SELECCIÓN ACTUAL", 170, 510, 180, Drawing.Color.FromArgb(90, 90, 90));
                btnSeleccionarBandejas = CrearBoton("SELECCIONAR BANDEJAS", 360, 510, 180, Drawing.Color.FromArgb(90, 90, 90));

                lstBandejas = new WinForms.ListBox()
                {
                    Left = 20,
                    Top = 552,
                    Width = 280,
                    Height = 105,
                    BorderStyle = WinForms.BorderStyle.FixedSingle
                };

                txtResultado = new WinForms.RichTextBox()
                {
                    Left = 320,
                    Top = 552,
                    Width = 320,
                    Height = 105,
                    ReadOnly = true,
                    BorderStyle = WinForms.BorderStyle.FixedSingle,
                    BackColor = Drawing.Color.White,
                    Font = new Drawing.Font("Consolas", 8.5F),
                    WordWrap = false,
                    ScrollBars = WinForms.RichTextBoxScrollBars.Vertical
                };

                btnGenerar = CrearBoton("GENERAR COLGADORES", 210, 675, 240, Drawing.Color.FromArgb(0, 120, 215));
                btnGenerar.Height = 38;

                btnCargarDatos.Click += (s, e) => Ejecutar(Operacion.CargarDatos);
                btnUsarSeleccionActual.Click += (s, e) => Ejecutar(Operacion.UsarSeleccionActual);
                btnSeleccionarBandejas.Click += (s, e) => Ejecutar(Operacion.SeleccionarBandejas);
                btnPickarSuperficie.Click += (s, e) => Ejecutar(Operacion.PickarSuperficie);
                btnGenerar.Click += (s, e) => Ejecutar(Operacion.GenerarColgadores);

                Controls.Add(lblAutor);
                Controls.Add(lblTitulo);
                Controls.Add(lblFamilia);
                Controls.Add(cmbFamiliaColgador);
                Controls.Add(lblNivel);
                Controls.Add(cmbNivelSuperior);
                Controls.Add(btnPickarSuperficie);
                Controls.Add(lblReferenciaPickada);
                Controls.Add(lblParametros);
                Controls.Add(lblSeparacion);
                Controls.Add(txtSeparacion);
                Controls.Add(lblMargen);
                Controls.Add(txtMargenLateral);
                Controls.Add(lblDesfase);
                Controls.Add(txtDesfaseInferior);
                Controls.Add(lblRotacion);
                Controls.Add(txtRotacionAdicional);
                Controls.Add(chkIncluirExtremos);
                Controls.Add(chkEliminarPrevios);
                Controls.Add(chkAsignarDisciplina);
                Controls.Add(lblParamsFamilia);
                Controls.Add(lblParamAltura);
                Controls.Add(txtParametroAltura);
                Controls.Add(lblParamAncho);
                Controls.Add(txtParametroAncho);
                Controls.Add(lblParamId);
                Controls.Add(txtParametroIdBandeja);
                Controls.Add(lblParamDisc);
                Controls.Add(txtParametroDisciplina);
                Controls.Add(lblNotaReferencia);
                Controls.Add(lblSeleccion);
                Controls.Add(btnCargarDatos);
                Controls.Add(btnUsarSeleccionActual);
                Controls.Add(btnSeleccionarBandejas);
                Controls.Add(lstBandejas);
                Controls.Add(txtResultado);
                Controls.Add(btnGenerar);

                MostrarResultado("Abre la herramienta, elige familia, nivel superior o picka una superficie superior y selecciona bandejas.");
            }

            private WinForms.Button CrearBoton(string texto, int left, int top, int width, Drawing.Color color)
            {
                WinForms.Button boton = new WinForms.Button()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 32,
                    BackColor = color,
                    ForeColor = Drawing.Color.White,
                    FlatStyle = WinForms.FlatStyle.Flat,
                    Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                    Cursor = WinForms.Cursors.Hand
                };

                boton.FlatAppearance.BorderSize = 0;
                boton.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(
                    System.Math.Max(color.R - 15, 0),
                    System.Math.Max(color.G - 15, 0),
                    System.Math.Max(color.B - 15, 0));

                return boton;
            }

            internal void SolicitarCargaInicial()
            {
                Ejecutar(Operacion.CargarDatos);
            }

            private void Ejecutar(Operacion operacion)
            {
                OperacionSolicitada = operacion;

                if (EjecutarEvent == null)
                {
                    MostrarResultado("No se pudo crear el evento externo de Revit.");
                    return;
                }

                EjecutarEvent.Raise();
            }

            internal void SetCatalogos(
                System.Collections.Generic.List<ComboItem> familias,
                System.Collections.Generic.List<ComboItem> niveles)
            {
                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() => SetCatalogos(familias, niveles)));
                    return;
                }

                object familiaPrevia = cmbFamiliaColgador.SelectedItem;
                object nivelPrevio = cmbNivelSuperior.SelectedItem;

                cmbFamiliaColgador.Items.Clear();
                cmbNivelSuperior.Items.Clear();

                if (familias != null)
                {
                    foreach (ComboItem item in familias)
                        cmbFamiliaColgador.Items.Add(item);
                }

                if (niveles != null)
                {
                    foreach (ComboItem item in niveles)
                        cmbNivelSuperior.Items.Add(item);
                }

                if (cmbFamiliaColgador.Items.Count > 0)
                    cmbFamiliaColgador.SelectedIndex = 0;

                if (cmbNivelSuperior.Items.Count > 0)
                    cmbNivelSuperior.SelectedIndex = cmbNivelSuperior.Items.Count - 1;

                MostrarResultado(
                    "Datos cargados.\r\n" +
                    "Familias encontradas: " + cmbFamiliaColgador.Items.Count + "\r\n" +
                    "Niveles encontrados: " + cmbNivelSuperior.Items.Count);
            }


            internal void SetReferenciaSuperiorPickada(string texto)
            {
                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() => SetReferenciaSuperiorPickada(texto)));
                    return;
                }

                referenciaSuperiorPickadaActiva = true;

                if (lblReferenciaPickada != null)
                {
                    lblReferenciaPickada.Text = string.IsNullOrWhiteSpace(texto)
                        ? "Referencia superior activa: superficie pickada."
                        : texto;

                    lblReferenciaPickada.ForeColor = Drawing.Color.FromArgb(0, 100, 180);
                }

                MostrarResultado(
                    "Superficie superior pickada correctamente.\r\n" +
                    "Al generar, la altura del colgador se calculará desde la parte inferior de la bandeja hasta esa superficie.");
            }

            internal void RestaurarReferenciaSuperiorPorNivel()
            {
                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(RestaurarReferenciaSuperiorPorNivel));
                    return;
                }

                referenciaSuperiorPickadaActiva = false;

                if (lblReferenciaPickada != null)
                {
                    lblReferenciaPickada.Text = "Referencia superior activa: nivel seleccionado.";
                    lblReferenciaPickada.ForeColor = Drawing.Color.FromArgb(90, 90, 90);
                }
            }

            internal void SetBandejasSeleccionadas(System.Collections.Generic.List<ComboItem> bandejas)
            {
                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() => SetBandejasSeleccionadas(bandejas)));
                    return;
                }

                bandejasIds.Clear();
                lstBandejas.Items.Clear();

                if (bandejas != null)
                {
                    foreach (ComboItem item in bandejas)
                    {
                        if (item == null)
                            continue;

                        if (item.Id == Autodesk.Revit.DB.ElementId.InvalidElementId)
                            continue;

                        bandejasIds.Add(item.Id);
                        lstBandejas.Items.Add(item.Nombre);
                    }
                }

                MostrarResultado("Bandejas seleccionadas: " + bandejasIds.Count);
            }

            internal void MostrarResultado(string texto)
            {
                if (txtResultado == null || txtResultado.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() => MostrarResultado(texto)));
                    return;
                }

                txtResultado.Clear();
                txtResultado.SelectionColor = Drawing.Color.FromArgb(50, 50, 50);
                txtResultado.AppendText(texto ?? "");
                txtResultado.SelectionStart = 0;
                txtResultado.ScrollToCaret();
            }

            private static string ObtenerTexto(string texto, string defecto)
            {
                if (string.IsNullOrWhiteSpace(texto))
                    return defecto;

                return texto.Trim();
            }

            private static double LeerDouble(string texto, double defecto)
            {
                if (string.IsNullOrWhiteSpace(texto))
                    return defecto;

                string t = texto.Trim().Replace(",", ".");
                double valor;

                if (double.TryParse(
                    t,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out valor))
                {
                    return valor;
                }

                return defecto;
            }
        }
    }

}
