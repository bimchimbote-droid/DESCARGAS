using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // VENTANA - CUADRO DE ACABADOS DESDE ROOMS
    // =====================================

    public class CuadroAcabadosRoomForm : WinForms.Form
    {
        // =========================================================
        // ENUM INTERNO
        // =========================================================

        public enum CuadroAcabadosRoomAccion
        {
            Ninguna,
            SeleccionarRooms,
            ExportarExcel,
            CrearCuadroLeyenda
        }

        // =========================================================
        // VARIABLES
        // =========================================================

        private UIDocument _uidoc;
        private Document _doc;

        private WinForms.Label lblRoomsSeleccionados;
        private WinForms.Label lblResultado;
        private WinForms.Label lblInfo;
        private WinForms.Label lblRutaExcel;
        private WinForms.Label lblLeyenda;
        private WinForms.Label lblEscala;

        private WinForms.TextBox txtRutaExcel;
        private WinForms.ComboBox cmbLeyenda;
        private WinForms.ComboBox cmbEscala;
        private WinForms.CheckBox chkUsarEscalaLeyenda;

        private WinForms.Button btnSeleccionarRooms;
        private WinForms.Button btnRutaGuardarComo;
        private WinForms.Button btnRutaBuscarExcel;
        private WinForms.Button btnExportarExcel;
        private WinForms.Button btnCrearCuadroLeyenda;
        private WinForms.Button btnCerrar;

        private List<CeldaLeyendaItemMYG> _leyendas = new List<CeldaLeyendaItemMYG>();
        private List<EscalaCuadroItemMYG> _escalas = new List<EscalaCuadroItemMYG>();
        private string _ultimoResultado = "";

        public ExternalEvent EjecutarEvent;
        public EjecutarCuadroAcabadosRoomHandler Handler;

        public List<ElementId> RoomsSeleccionadosIds { get; set; }

        public ElementId LeyendaSeleccionadaId
        {
            get
            {
                if (cmbLeyenda == null)
                    return ElementId.InvalidElementId;

                CeldaLeyendaItemMYG item = cmbLeyenda.SelectedItem as CeldaLeyendaItemMYG;

                if (item != null && item.Id != null)
                    return item.Id;

                return ElementId.InvalidElementId;
            }
        }

        public bool UsarEscalaDeLeyenda
        {
            get
            {
                if (chkUsarEscalaLeyenda == null)
                    return false;

                return chkUsarEscalaLeyenda.Checked;
            }
        }

        public int EscalaCuadroSeleccionada
        {
            get
            {
                if (UsarEscalaDeLeyenda)
                {
                    CeldaLeyendaItemMYG leyenda = null;

                    try
                    {
                        leyenda = cmbLeyenda.SelectedItem as CeldaLeyendaItemMYG;
                    }
                    catch
                    {
                        leyenda = null;
                    }

                    if (leyenda != null && leyenda.Escala > 0)
                        return leyenda.Escala;
                }

                if (cmbEscala != null)
                {
                    EscalaCuadroItemMYG item = cmbEscala.SelectedItem as EscalaCuadroItemMYG;

                    if (item != null && item.Valor > 0)
                        return item.Valor;

                    int valorTexto = ObtenerEscalaDesdeTexto(cmbEscala.Text);

                    if (valorTexto > 0)
                        return valorTexto;
                }

                return 1;
            }
        }

        public string RutaExcelActual
        {
            get
            {
                if (txtRutaExcel == null)
                    return "";

                return txtRutaExcel.Text == null ? "" : txtRutaExcel.Text.Trim();
            }
        }

        public CuadroAcabadosRoomForm(UIDocument uidoc)
        {
            _uidoc = uidoc;
            _doc = uidoc.Document;

            RoomsSeleccionadosIds = new List<ElementId>();

            this.Text = "🏠 Cuadro de Acabados por Rooms";
            this.Width = 640;
            this.Height = 655;
            this.MinimumSize = new Drawing.Size(640, 655);
            this.MaximumSize = new Drawing.Size(640, 655);
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;
            this.AutoScaleMode = WinForms.AutoScaleMode.Dpi;

            WinForms.Label lblAutor = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                Left = 20,
                Top = 8,
                Width = 580,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.Gray
            };

            WinForms.Label lblTitulo = new WinForms.Label()
            {
                Text = "01. SELECCIONAR HABITACIONES / ROOMS",
                Left = 20,
                Top = 38,
                Width = 590,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            btnSeleccionarRooms = new WinForms.Button()
            {
                Text = "SELECCIONAR ROOMS",
                Width = 190,
                Height = 34,
                Left = 20,
                Top = 65,
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnSeleccionarRooms.FlatAppearance.BorderSize = 0;

            btnSeleccionarRooms.Click += (s, e) =>
            {
                if (Handler == null)
                    return;

                Handler.Accion = CuadroAcabadosRoomAccion.SeleccionarRooms;
                EjecutarEvent?.Raise();
            };

            lblRoomsSeleccionados = new WinForms.Label()
            {
                Text = "Rooms seleccionados: Ninguno",
                Left = 20,
                Top = 112,
                Width = 590,
                Height = 58,
                ForeColor = Drawing.Color.FromArgb(70, 70, 70)
            };

            WinForms.Label lblTituloRuta = new WinForms.Label()
            {
                Text = "02. RUTA DEL EXCEL",
                Left = 20,
                Top = 180,
                Width = 590,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            lblRutaExcel = new WinForms.Label()
            {
                Text = "Ruta donde se guardará o desde donde se leerá el Excel:",
                Left = 20,
                Top = 207,
                Width = 590,
                Height = 20,
                ForeColor = Drawing.Color.FromArgb(80, 80, 80)
            };

            txtRutaExcel = new WinForms.TextBox()
            {
                Left = 20,
                Top = 232,
                Width = 410,
                Height = 25,
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };

            btnRutaGuardarComo = new WinForms.Button()
            {
                Text = "GUARDAR...",
                Width = 85,
                Height = 27,
                Left = 440,
                Top = 231,
                BackColor = Drawing.Color.FromArgb(120, 120, 120),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnRutaGuardarComo.FlatAppearance.BorderSize = 0;

            btnRutaGuardarComo.Click += (s, e) =>
            {
                SeleccionarRutaGuardarExcel();
            };

            btnRutaBuscarExcel = new WinForms.Button()
            {
                Text = "BUSCAR...",
                Width = 85,
                Height = 27,
                Left = 530,
                Top = 231,
                BackColor = Drawing.Color.FromArgb(120, 120, 120),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnRutaBuscarExcel.FlatAppearance.BorderSize = 0;

            btnRutaBuscarExcel.Click += (s, e) =>
            {
                SeleccionarRutaExcelExistente();
            };

            WinForms.Label lblTituloExportar = new WinForms.Label()
            {
                Text = "03. EXPORTAR CUADRO DE ACABADOS A EXCEL",
                Left = 20,
                Top = 275,
                Width = 590,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            lblInfo = new WinForms.Label()
            {
                Text = "Detecta MUROS y SUELOS relacionados a cada Room y arma una matriz en Excel: filas = Descripción de tipo, columnas = habitaciones.",
                Left = 20,
                Top = 302,
                Width = 590,
                Height = 38,
                ForeColor = Drawing.Color.FromArgb(80, 80, 80)
            };

            btnExportarExcel = new WinForms.Button()
            {
                Text = "EXPORTAR EXCEL",
                Width = 155,
                Height = 36,
                Left = 20,
                Top = 343,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnExportarExcel.FlatAppearance.BorderSize = 0;
            btnExportarExcel.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(0, 100, 190);
            btnExportarExcel.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(0, 84, 160);

            btnExportarExcel.Click += (s, e) =>
            {
                if (RoomsSeleccionadosIds == null || RoomsSeleccionadosIds.Count == 0)
                {
                    MostrarResultado("Debe seleccionar una o más habitaciones / Rooms antes de exportar.");
                    return;
                }

                if (Handler == null)
                    return;

                Handler.Accion = CuadroAcabadosRoomAccion.ExportarExcel;
                EjecutarEvent?.Raise();
            };

            WinForms.Label lblTituloLeyenda = new WinForms.Label()
            {
                Text = "04. CREAR CUADRO CON LÍNEAS DE DETALLE EN LEYENDA",
                Left = 20,
                Top = 395,
                Width = 590,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            lblLeyenda = new WinForms.Label()
            {
                Text = "Seleccione la leyenda donde se dibujará el cuadro usando la información del Excel indicado arriba:",
                Left = 20,
                Top = 422,
                Width = 590,
                Height = 20,
                ForeColor = Drawing.Color.FromArgb(80, 80, 80)
            };

            cmbLeyenda = new WinForms.ComboBox()
            {
                Left = 20,
                Top = 447,
                Width = 410,
                Height = 26,
                DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
                IntegralHeight = false,
                DropDownHeight = 180
            };

            cmbLeyenda.SelectedIndexChanged += (s, e) =>
            {
                SincronizarEscalaDesdeLeyendaSiCorresponde();
            };

            lblEscala = new WinForms.Label()
            {
                Text = "Escala a considerar para dibujar el cuadro:",
                Left = 20,
                Top = 482,
                Width = 590,
                Height = 20,
                ForeColor = Drawing.Color.FromArgb(80, 80, 80)
            };

            cmbEscala = new WinForms.ComboBox()
            {
                Left = 20,
                Top = 507,
                Width = 120,
                Height = 26,
                DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
                IntegralHeight = false,
                DropDownHeight = 180
            };

            chkUsarEscalaLeyenda = new WinForms.CheckBox()
            {
                Text = "Adquirir escala de la leyenda",
                Left = 155,
                Top = 509,
                Width = 265,
                Height = 24,
                Checked = true,
                ForeColor = Drawing.Color.FromArgb(70, 70, 70)
            };

            chkUsarEscalaLeyenda.CheckedChanged += (s, e) =>
            {
                if (cmbEscala != null)
                    cmbEscala.Enabled = !chkUsarEscalaLeyenda.Checked;

                SincronizarEscalaDesdeLeyendaSiCorresponde();
            };

            btnCrearCuadroLeyenda = new WinForms.Button()
            {
                Text = "CREAR EN LEYENDA",
                Width = 175,
                Height = 36,
                Left = 440,
                Top = 503,
                BackColor = Drawing.Color.FromArgb(0, 150, 90),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnCrearCuadroLeyenda.FlatAppearance.BorderSize = 0;
            btnCrearCuadroLeyenda.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(0, 130, 78);
            btnCrearCuadroLeyenda.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(0, 105, 64);

            btnCrearCuadroLeyenda.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(RutaExcelActual))
                {
                    MostrarResultado("Debe indicar la ruta del Excel antes de crear el cuadro en leyenda.");
                    return;
                }

                if (!System.IO.File.Exists(RutaExcelActual))
                {
                    MostrarResultado("No existe el Excel indicado en la ruta.");
                    return;
                }

                if (LeyendaSeleccionadaId == ElementId.InvalidElementId)
                {
                    MostrarResultado("Debe seleccionar una leyenda.");
                    return;
                }

                if (EscalaCuadroSeleccionada <= 0)
                {
                    MostrarResultado("Debe seleccionar una escala válida para crear el cuadro en la leyenda.");
                    return;
                }

                if (Handler == null)
                    return;

                Handler.Accion = CuadroAcabadosRoomAccion.CrearCuadroLeyenda;
                EjecutarEvent?.Raise();
            };

            btnCerrar = new WinForms.Button()
            {
                Text = "CERRAR",
                Width = 120,
                Height = 36,
                Left = 495,
                Top = 573,
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnCerrar.FlatAppearance.BorderSize = 0;

            btnCerrar.Click += (s, e) =>
            {
                this.Close();
            };

            lblResultado = new WinForms.Label()
            {
                Text = "",
                Left = 20,
                Top = 555,
                Width = 460,
                Height = 70,
                Visible = true,
                ForeColor = Drawing.Color.FromArgb(90, 90, 90)
            };

            Controls.Add(lblAutor);
            Controls.Add(lblTitulo);
            Controls.Add(btnSeleccionarRooms);
            Controls.Add(lblRoomsSeleccionados);

            Controls.Add(lblTituloRuta);
            Controls.Add(lblRutaExcel);
            Controls.Add(txtRutaExcel);
            Controls.Add(btnRutaGuardarComo);
            Controls.Add(btnRutaBuscarExcel);

            Controls.Add(lblTituloExportar);
            Controls.Add(lblInfo);
            Controls.Add(btnExportarExcel);

            Controls.Add(lblTituloLeyenda);
            Controls.Add(lblLeyenda);
            Controls.Add(cmbLeyenda);
            Controls.Add(lblEscala);
            Controls.Add(cmbEscala);
            Controls.Add(chkUsarEscalaLeyenda);
            Controls.Add(btnCrearCuadroLeyenda);

            Controls.Add(btnCerrar);
            Controls.Add(lblResultado);

            CargarEscalas();
            CargarLeyendas();
            SincronizarEscalaDesdeLeyendaSiCorresponde();

            MostrarResultado("Seleccione los Rooms, defina ruta del Excel y luego exporte o cree el cuadro en una leyenda.");
        }

        // =========================================================
        // RUTA EXCEL
        // =========================================================

        private void SeleccionarRutaGuardarExcel()
        {
            string ruta = ObtenerRutaExportacionExcelConDialogo();

            if (!string.IsNullOrWhiteSpace(ruta))
                EstablecerRutaExcel(ruta);
        }

        private void SeleccionarRutaExcelExistente()
        {
            using (WinForms.OpenFileDialog dialog = new WinForms.OpenFileDialog())
            {
                dialog.Title = "Seleccionar Excel de cuadro de acabados";
                dialog.Filter = "Archivo Excel (*.xlsx)|*.xlsx";
                dialog.RestoreDirectory = true;
                dialog.Multiselect = false;

                WinForms.DialogResult resultado = dialog.ShowDialog(this);

                if (resultado != WinForms.DialogResult.OK)
                    return;

                EstablecerRutaExcel(dialog.FileName);
            }
        }

        public string ObtenerRutaExportacionExcel()
        {
            string rutaActual = RutaExcelActual;

            if (!string.IsNullOrWhiteSpace(rutaActual))
            {
                try
                {
                    string carpeta = System.IO.Path.GetDirectoryName(rutaActual);

                    if (!string.IsNullOrWhiteSpace(carpeta) && System.IO.Directory.Exists(carpeta))
                        return rutaActual;
                }
                catch
                {
                }
            }

            string ruta = ObtenerRutaExportacionExcelConDialogo();

            if (!string.IsNullOrWhiteSpace(ruta))
                EstablecerRutaExcel(ruta);

            return ruta;
        }

        private string ObtenerRutaExportacionExcelConDialogo()
        {
            string nombreArchivo = "Cuadro_Acabados_Rooms_" +
                DateTime.Now.ToString("yyyyMMdd_HHmm") + ".xlsx";

            using (WinForms.SaveFileDialog dialog = new WinForms.SaveFileDialog())
            {
                dialog.Title = "Guardar cuadro de acabados";
                dialog.Filter = "Archivo Excel (*.xlsx)|*.xlsx";
                dialog.FileName = nombreArchivo;
                dialog.RestoreDirectory = true;
                dialog.OverwritePrompt = true;

                WinForms.DialogResult resultado = dialog.ShowDialog(this);

                if (resultado != WinForms.DialogResult.OK)
                    return "";

                return dialog.FileName;
            }
        }

        public void EstablecerRutaExcel(string ruta)
        {
            if (txtRutaExcel == null)
                return;

            txtRutaExcel.Text = ruta ?? "";
        }

        // =========================================================
        // ESCALA DEL CUADRO / LEYENDA
        // =========================================================

        private void CargarEscalas()
        {
            if (cmbEscala == null)
                return;

            _escalas.Clear();
            cmbEscala.Items.Clear();

            int[] valores = new int[]
            {
            1, 2, 5, 10, 20, 25, 50, 75, 100, 125, 150, 200, 250, 500
            };

            foreach (int valor in valores)
            {
                EscalaCuadroItemMYG item = new EscalaCuadroItemMYG();
                item.Valor = valor;
                item.Nombre = "1 : " + valor.ToString();

                _escalas.Add(item);
                cmbEscala.Items.Add(item);
            }

            SeleccionarEscalaEnCombo(50);

            if (chkUsarEscalaLeyenda != null)
                cmbEscala.Enabled = !chkUsarEscalaLeyenda.Checked;
        }

        private void SincronizarEscalaDesdeLeyendaSiCorresponde()
        {
            if (chkUsarEscalaLeyenda == null || !chkUsarEscalaLeyenda.Checked)
                return;

            CeldaLeyendaItemMYG leyenda = null;

            try
            {
                leyenda = cmbLeyenda.SelectedItem as CeldaLeyendaItemMYG;
            }
            catch
            {
                leyenda = null;
            }

            if (leyenda == null || leyenda.Escala <= 0)
                return;

            SeleccionarEscalaEnCombo(leyenda.Escala);
        }

        private void SeleccionarEscalaEnCombo(int escala)
        {
            if (cmbEscala == null || escala <= 0)
                return;

            for (int i = 0; i < cmbEscala.Items.Count; i++)
            {
                EscalaCuadroItemMYG item = cmbEscala.Items[i] as EscalaCuadroItemMYG;

                if (item == null)
                    continue;

                if (item.Valor == escala)
                {
                    cmbEscala.SelectedIndex = i;
                    return;
                }
            }

            EscalaCuadroItemMYG nuevo = new EscalaCuadroItemMYG();
            nuevo.Valor = escala;
            nuevo.Nombre = "1 : " + escala.ToString();

            _escalas.Add(nuevo);
            cmbEscala.Items.Add(nuevo);
            cmbEscala.SelectedItem = nuevo;
        }

        private int ObtenerEscalaDesdeTexto(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return 0;

            string limpio = texto.Trim();
            limpio = limpio.Replace("Esc.", "");
            limpio = limpio.Replace("ESC.", "");
            limpio = limpio.Replace("Escala", "");
            limpio = limpio.Replace("escala", "");
            limpio = limpio.Replace(" ", "");

            if (limpio.Contains(":"))
            {
                string[] partes = limpio.Split(':');

                if (partes.Length >= 2)
                    limpio = partes[partes.Length - 1];
            }

            int valor = 0;

            if (int.TryParse(limpio, out valor))
                return valor;

            return 0;
        }

        // =========================================================
        // LEYENDAS
        // =========================================================

        private void CargarLeyendas()
        {
            if (cmbLeyenda == null || _doc == null)
                return;

            _leyendas.Clear();
            cmbLeyenda.Items.Clear();

            try
            {
                List<Autodesk.Revit.DB.View> vistas = new List<Autodesk.Revit.DB.View>();

                FilteredElementCollector collector = new FilteredElementCollector(_doc);
                collector.OfClass(typeof(Autodesk.Revit.DB.View));

                foreach (Element elemento in collector)
                {
                    Autodesk.Revit.DB.View vista = elemento as Autodesk.Revit.DB.View;

                    if (vista == null)
                        continue;

                    if (vista.IsTemplate)
                        continue;

                    if (vista.ViewType != ViewType.Legend)
                        continue;

                    vistas.Add(vista);
                }

                vistas.Sort(delegate (Autodesk.Revit.DB.View a, Autodesk.Revit.DB.View b)
                {
                    if (a == null && b == null) return 0;
                    if (a == null) return -1;
                    if (b == null) return 1;

                    return string.Compare(a.Name, b.Name, System.StringComparison.CurrentCultureIgnoreCase);
                });

                foreach (Autodesk.Revit.DB.View vista in vistas)
                {
                    CeldaLeyendaItemMYG item = new CeldaLeyendaItemMYG();
                    item.Id = vista.Id;
                    item.Escala = ObtenerEscalaVistaLeyenda(vista);
                    item.Nombre = vista.Name + "  (Esc. 1:" + item.Escala.ToString() + ")";

                    _leyendas.Add(item);
                    cmbLeyenda.Items.Add(item);
                }

                if (cmbLeyenda.Items.Count > 0)
                    cmbLeyenda.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MostrarResultado("Error al cargar leyendas: " + ex.Message);
            }
        }

        private int ObtenerEscalaVistaLeyenda(Autodesk.Revit.DB.View vista)
        {
            if (vista == null)
                return 1;

            try
            {
                if (vista.Scale > 0)
                    return vista.Scale;
            }
            catch
            {
            }

            return 1;
        }

        // =========================================================
        // ACTUALIZAR ROOMS Y RESULTADOS
        // =========================================================

        public void ActualizarRoomsSeleccionados(List<Room> rooms)
        {
            RoomsSeleccionadosIds = new List<ElementId>();

            if (rooms == null || rooms.Count == 0)
            {
                lblRoomsSeleccionados.Text = "Rooms seleccionados: Ninguno";
                MostrarResultado("No se seleccionó ningún Room válido.");
                return;
            }

            List<string> nombres = new List<string>();

            foreach (Room room in rooms)
            {
                if (room == null)
                    continue;

                bool yaExiste = false;

                foreach (ElementId idExistente in RoomsSeleccionadosIds)
                {
                    if (idExistente == null)
                        continue;

                    if (idExistente.Value == room.Id.Value)
                    {
                        yaExiste = true;
                        break;
                    }
                }

                if (!yaExiste)
                    RoomsSeleccionadosIds.Add(room.Id);

                nombres.Add(ObtenerNombreRoom(room));
            }

            string textoNombres = "";
            int maximo = Math.Min(6, nombres.Count);

            for (int i = 0; i < maximo; i++)
            {
                if (i > 0)
                    textoNombres += ", ";

                textoNombres += nombres[i];
            }

            if (nombres.Count > 6)
                textoNombres += " ...";

            lblRoomsSeleccionados.Text =
                "Rooms seleccionados: " + RoomsSeleccionadosIds.Count.ToString() + "\r\n" +
                textoNombres;

            MostrarResultado("Rooms seleccionados: " + RoomsSeleccionadosIds.Count.ToString());
        }

        public void MostrarResultado(string texto)
        {
            _ultimoResultado = texto ?? "";

            if (lblResultado == null)
                return;

            lblResultado.Text = _ultimoResultado;
            lblResultado.Visible = true;

            if (string.IsNullOrWhiteSpace(_ultimoResultado))
                return;

            if (_ultimoResultado.StartsWith("ERROR", System.StringComparison.OrdinalIgnoreCase) ||
                _ultimoResultado.StartsWith("Debe", System.StringComparison.OrdinalIgnoreCase) ||
                _ultimoResultado.StartsWith("No se", System.StringComparison.OrdinalIgnoreCase) ||
                _ultimoResultado.StartsWith("Selección cancelada", System.StringComparison.OrdinalIgnoreCase))
            {
                lblResultado.ForeColor = Drawing.Color.FromArgb(190, 40, 40);
            }
            else
            {
                lblResultado.ForeColor = Drawing.Color.FromArgb(70, 70, 70);
            }
        }

        public void OcultarTemporalmenteParaSeleccion()
        {
            try
            {
                this.Hide();
            }
            catch
            {
            }
        }

        public void MostrarLuegoDeSeleccion()
        {
            try
            {
                if (!this.IsDisposed)
                {
                    this.Show();
                    this.Activate();
                    this.TopMost = true;
                }
            }
            catch
            {
            }
        }

        private string ObtenerNombreRoom(Room room)
        {
            if (room == null)
                return "Room";

            string numero = "";
            string nombre = "";

            try
            {
                numero = room.Number;
            }
            catch
            {
            }

            try
            {
                nombre = room.Name;
            }
            catch
            {
            }

            if (!string.IsNullOrWhiteSpace(numero) && !string.IsNullOrWhiteSpace(nombre))
                return numero + " - " + nombre;

            if (!string.IsNullOrWhiteSpace(nombre))
                return nombre;

            if (!string.IsNullOrWhiteSpace(numero))
                return numero;

            return "Room " + room.Id.Value.ToString();
        }

        private class CeldaLeyendaItemMYG
        {
            public ElementId Id { get; set; }
            public int Escala { get; set; }
            public string Nombre { get; set; }

            public override string ToString()
            {
                return Nombre;
            }
        }

        private class EscalaCuadroItemMYG
        {
            public int Valor { get; set; }
            public string Nombre { get; set; }

            public override string ToString()
            {
                return Nombre;
            }
        }
    }

}
