using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{























































































    // =====================================
    // VENTANA 4.1 - CREAR SUELO DESDE ROOM
    // =====================================

    public class CrearSueloDesdeRoomForm : WinForms.Form
    {
        private UIDocument _uidoc;
        private Document _doc;

        private WinForms.Label lblRoomSeleccionado;
        private WinForms.Label lblTituloTipoSuelo;
        private WinForms.Label lblSubTipoSueloInferior;
        private WinForms.Label lblSubTipoSueloSuperior;
        private WinForms.Label lblNivel;
        private WinForms.Label lblDesfase;
        private WinForms.Label lblNotaDesfase;
        private WinForms.Label lblProfundidadQuiebrePuertas;
        private WinForms.Label lblNotaProfundidadQuiebrePuertas;
        private WinForms.Label lblOpciones;

        private WinForms.ComboBox cmbTipoSueloInferior;
        private WinForms.ComboBox cmbTipoSueloSuperior;
        private WinForms.ComboBox cmbNivel;
        private WinForms.TextBox txtDesfaseMetros;
        private WinForms.TextBox txtProfundidadQuiebrePuertasMetros;
        private WinForms.CheckBox chkUsarDosCapas;
        private WinForms.CheckBox chkIncluirPuertas;
        private WinForms.CheckBox chkDescontarIntersecciones;

        private WinForms.Button btnSeleccionarRoom;
        private WinForms.Button btnEjecutar;
        private WinForms.Button btnCerrar;

        private List<RoomSueloTipoItem> _tiposSuelo = new List<RoomSueloTipoItem>();
        private List<RoomSueloNivelItem> _niveles = new List<RoomSueloNivelItem>();

        private bool _filtrandoCombo = false;
        private bool _cargandoCombos = false;
        private string _ultimoResultado = "";

        public ExternalEvent EjecutarEvent;
        public EjecutarCrearSueloDesdeRoomHandler Handler;

        public List<ElementId> RoomsSeleccionadosIds { get; set; }

        public bool UsarDosCapas
        {
            get { return chkUsarDosCapas != null && chkUsarDosCapas.Checked; }
        }

        public bool IncluirPuertas
        {
            get { return chkIncluirPuertas != null && chkIncluirPuertas.Checked; }
        }

        public bool DescontarIntersecciones
        {
            get { return chkDescontarIntersecciones != null && chkDescontarIntersecciones.Checked; }
        }

        public double DesfaseMetros
        {
            get
            {
                if (txtDesfaseMetros == null)
                    return 0.0;

                string texto = txtDesfaseMetros.Text;

                if (string.IsNullOrWhiteSpace(texto))
                    return 0.0;

                texto = texto.Trim().Replace(",", ".");

                double valor;

                if (double.TryParse(
                    texto,
                    NumberStyles.Any,
                    CultureInfo.InvariantCulture,
                    out valor))
                {
                    return valor;
                }

                return 0.0;
            }
        }

        public double ProfundidadQuiebrePuertasMetros
        {
            get
            {
                if (txtProfundidadQuiebrePuertasMetros == null)
                    return 0.0;

                string texto = txtProfundidadQuiebrePuertasMetros.Text;

                if (string.IsNullOrWhiteSpace(texto))
                    return 0.0;

                texto = texto.Trim().Replace(",", ".");

                double valor;

                if (double.TryParse(
                    texto,
                    NumberStyles.Any,
                    CultureInfo.InvariantCulture,
                    out valor))
                {
                    if (valor < 0.0)
                        return 0.0;

                    return valor;
                }

                return 0.0;
            }
        }

        public ElementId TipoSueloInferiorSeleccionadoId
        {
            get { return ObtenerTipoSueloIdDesdeCombo(cmbTipoSueloInferior); }
        }

        public ElementId TipoSueloSuperiorSeleccionadoId
        {
            get
            {
                if (!UsarDosCapas)
                    return TipoSueloInferiorSeleccionadoId;

                return ObtenerTipoSueloIdDesdeCombo(cmbTipoSueloSuperior);
            }
        }

        // Se mantiene esta propiedad por compatibilidad con código antiguo.
        // En 1 capa equivale al suelo único; en 2 capas equivale al suelo superior.
        public ElementId TipoSueloSeleccionadoId
        {
            get { return TipoSueloSuperiorSeleccionadoId; }
        }

        public ElementId NivelSeleccionadoId
        {
            get { return ObtenerNivelIdDesdeCombo(cmbNivel); }
        }

        public CrearSueloDesdeRoomForm(UIDocument uidoc)
        {
            _uidoc = uidoc;
            _doc = uidoc.Document;

            RoomsSeleccionadosIds = new List<ElementId>();

            this.Text = "🏠 Crear Suelo desde Rooms";
            this.Width = 540;
            this.Height = 600;
            this.MinimumSize = new Drawing.Size(540, 600);
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;
            this.AutoScaleMode = WinForms.AutoScaleMode.Dpi;

            WinForms.Label lblAutor = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                Left = 20,
                Top = 8,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.Gray
            };

            WinForms.Label lblTitulo = new WinForms.Label()
            {
                Text = "01. SELECCIONAR HABITACIÓN / ROOM",
                Left = 20,
                Top = 38,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            btnSeleccionarRoom = new WinForms.Button()
            {
                Text = "SELECCIONAR ROOMS",
                Width = 180,
                Height = 32,
                Left = 20,
                Top = 65,
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnSeleccionarRoom.FlatAppearance.BorderSize = 0;

            btnSeleccionarRoom.Click += (s, e) =>
            {
                if (Handler == null)
                    return;

                Handler.Accion = RoomSueloAccion.SeleccionarRoom;
                EjecutarEvent?.Raise();
            };

            lblRoomSeleccionado = new WinForms.Label()
            {
                Text = "Rooms seleccionados: Ninguno",
                Left = 20,
                Top = 107,
                Width = 480,
                Height = 55,
                ForeColor = Drawing.Color.FromArgb(70, 70, 70)
            };

            lblTituloTipoSuelo = new WinForms.Label()
            {
                Text = "02. TIPO DE SUELO",
                Left = 20,
                Top = 175,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            chkUsarDosCapas = new WinForms.CheckBox()
            {
                Text = "Crear con 2 capas",
                Left = 20,
                Top = 200,
                Width = 250,
                Height = 24,
                Checked = false,
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            chkUsarDosCapas.CheckedChanged += (s, e) =>
            {
                ActualizarVisibilidadCapas();
            };

            lblSubTipoSueloInferior = new WinForms.Label()
            {
                Text = "Suelo",
                Left = 20,
                Top = 230,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(85, 85, 85)
            };

            cmbTipoSueloInferior = new WinForms.ComboBox()
            {
                Left = 20,
                Top = 251,
                Width = 480,
                Height = 26,
                DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                AutoCompleteMode = WinForms.AutoCompleteMode.None,
                AutoCompleteSource = WinForms.AutoCompleteSource.None,
                IntegralHeight = false,
                DropDownHeight = 180
            };

            lblSubTipoSueloSuperior = new WinForms.Label()
            {
                Text = "Suelo superior",
                Left = 20,
                Top = 288,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(85, 85, 85),
                Visible = false
            };

            cmbTipoSueloSuperior = new WinForms.ComboBox()
            {
                Left = 20,
                Top = 309,
                Width = 480,
                Height = 26,
                DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                AutoCompleteMode = WinForms.AutoCompleteMode.None,
                AutoCompleteSource = WinForms.AutoCompleteSource.None,
                IntegralHeight = false,
                DropDownHeight = 180,
                Visible = false
            };

            lblNivel = new WinForms.Label()
            {
                Text = "03. NIVEL DE REFERENCIA",
                Left = 20,
                Top = 309,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            cmbNivel = new WinForms.ComboBox()
            {
                Left = 20,
                Top = 336,
                Width = 480,
                Height = 26,
                DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                AutoCompleteMode = WinForms.AutoCompleteMode.None,
                AutoCompleteSource = WinForms.AutoCompleteSource.None,
                IntegralHeight = false,
                DropDownHeight = 180
            };

            lblDesfase = new WinForms.Label()
            {
                Text = "04. DESFASE RESPECTO AL NIVEL (m)",
                Left = 20,
                Top = 376,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtDesfaseMetros = new WinForms.TextBox()
            {
                Left = 20,
                Top = 403,
                Width = 120,
                Height = 25,
                Text = "0.00",
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };

            txtDesfaseMetros.Leave += (s, e) =>
            {
                NormalizarTextBoxDecimal(txtDesfaseMetros, true);
            };

            lblNotaDesfase = new WinForms.Label()
            {
                Text = "Cota de encuentro entre el suelo inferior y superior",
                Left = 155,
                Top = 406,
                Width = 350,
                Height = 22,
                ForeColor = Drawing.Color.FromArgb(90, 90, 90)
            };

            lblProfundidadQuiebrePuertas = new WinForms.Label()
            {
                Text = "05. PROFUNDIDAD QUIEBRE PUERTAS (m)",
                Left = 20,
                Top = 445,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtProfundidadQuiebrePuertasMetros = new WinForms.TextBox()
            {
                Left = 20,
                Top = 472,
                Width = 120,
                Height = 25,
                Text = "0.00",
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };

            txtProfundidadQuiebrePuertasMetros.Leave += (s, e) =>
            {
                NormalizarTextBoxDecimal(txtProfundidadQuiebrePuertasMetros, false);
            };

            lblNotaProfundidadQuiebrePuertas = new WinForms.Label()
            {
                Text = "Ejemplo: 0.23 para muro de cabeza + acabados",
                Left = 155,
                Top = 475,
                Width = 350,
                Height = 22,
                ForeColor = Drawing.Color.FromArgb(90, 90, 90)
            };

            lblOpciones = new WinForms.Label()
            {
                Text = "06. OPCIONES DE BOCETO",
                Left = 20,
                Top = 445,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            chkIncluirPuertas = new WinForms.CheckBox()
            {
                Text = "Incluir Puertas",
                Left = 20,
                Top = 471,
                Width = 500,
                Height = 24,
                Checked = true,
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            // Se mantiene internamente para compatibilidad con el handler.
            // No se muestra en la ventana.
            chkDescontarIntersecciones = new WinForms.CheckBox()
            {
                Text = "Descontar intersecciones",
                Left = 20,
                Top = 498,
                Width = 500,
                Height = 24,
                Checked = false,
                Visible = false
            };

            btnEjecutar = new WinForms.Button()
            {
                Text = "EJECUTAR",
                Width = 135,
                Height = 36,
                Left = 220,
                Top = 550,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnEjecutar.FlatAppearance.BorderSize = 0;
            btnEjecutar.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(0, 100, 190);
            btnEjecutar.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(0, 84, 160);

            btnEjecutar.Click += (s, e) =>
            {
                AsegurarSeleccionCombo(cmbTipoSueloInferior);

                if (UsarDosCapas)
                    AsegurarSeleccionCombo(cmbTipoSueloSuperior);

                AsegurarSeleccionCombo(cmbNivel);

                if (RoomsSeleccionadosIds == null || RoomsSeleccionadosIds.Count == 0)
                {
                    MostrarResultado("Debe seleccionar una o más habitaciones / Rooms antes de ejecutar.");
                    return;
                }

                if (TipoSueloInferiorSeleccionadoId == ElementId.InvalidElementId)
                {
                    MostrarResultado(UsarDosCapas
                        ? "Debe seleccionar el tipo de suelo inferior."
                        : "Debe seleccionar el tipo de suelo.");
                    return;
                }

                if (UsarDosCapas && TipoSueloSuperiorSeleccionadoId == ElementId.InvalidElementId)
                {
                    MostrarResultado("Debe seleccionar el tipo de suelo superior.");
                    return;
                }

                if (NivelSeleccionadoId == ElementId.InvalidElementId)
                {
                    MostrarResultado("Debe seleccionar un nivel de referencia.");
                    return;
                }

                if (!TextoDecimalValido(txtDesfaseMetros, true))
                {
                    MostrarResultado("Ingrese un desfase válido en metros. Ejemplo: -0.05 debajo del nivel o 0.10 encima del nivel.");
                    return;
                }

                if (!TextoDecimalValido(txtProfundidadQuiebrePuertasMetros, false))
                {
                    MostrarResultado("Ingrese una profundidad de quiebre válida en metros. Ejemplo: 0.23");
                    return;
                }

                if (Handler == null)
                    return;

                Handler.Accion = RoomSueloAccion.CrearSuelo;
                EjecutarEvent?.Raise();
            };

            btnCerrar = new WinForms.Button()
            {
                Text = "CERRAR",
                Width = 130,
                Height = 36,
                Left = 370,
                Top = 550,
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnCerrar.FlatAppearance.BorderSize = 0;

            btnCerrar.Click += (s, e) =>
            {
                this.Close();
            };

            Controls.Add(lblAutor);
            Controls.Add(lblTitulo);
            Controls.Add(btnSeleccionarRoom);
            Controls.Add(lblRoomSeleccionado);

            Controls.Add(lblTituloTipoSuelo);
            Controls.Add(chkUsarDosCapas);
            Controls.Add(lblSubTipoSueloInferior);
            Controls.Add(cmbTipoSueloInferior);

            Controls.Add(lblSubTipoSueloSuperior);
            Controls.Add(cmbTipoSueloSuperior);

            Controls.Add(lblNivel);
            Controls.Add(cmbNivel);

            Controls.Add(lblDesfase);
            Controls.Add(txtDesfaseMetros);
            Controls.Add(lblNotaDesfase);

            Controls.Add(lblProfundidadQuiebrePuertas);
            Controls.Add(txtProfundidadQuiebrePuertasMetros);
            Controls.Add(lblNotaProfundidadQuiebrePuertas);

            Controls.Add(lblOpciones);
            Controls.Add(chkIncluirPuertas);
            Controls.Add(chkDescontarIntersecciones);

            Controls.Add(btnEjecutar);
            Controls.Add(btnCerrar);

            ConfigurarComboConFiltro(cmbTipoSueloInferior);
            ConfigurarComboConFiltro(cmbTipoSueloSuperior);
            ConfigurarComboConFiltro(cmbNivel);

            CargarTiposDeSuelo();
            CargarNiveles();
            ActualizarVisibilidadCapas();

            MostrarResultado("Seleccione uno o más Rooms y luego ejecute la creación de suelos.");
        }


        private void NormalizarTextBoxDecimal(WinForms.TextBox textBox, bool permitirNegativo)
        {
            if (textBox == null)
                return;

            string texto = textBox.Text;

            if (string.IsNullOrWhiteSpace(texto))
                return;

            texto = texto.Trim().Replace(",", ".");

            if (texto.StartsWith("-."))
                texto = "-0" + texto.Substring(1);

            if (texto.StartsWith("."))
                texto = "0" + texto;

            if (texto.EndsWith("."))
                texto = texto + "0";

            double valor;

            if (double.TryParse(
                texto,
                NumberStyles.Any,
                CultureInfo.InvariantCulture,
                out valor))
            {
                if (!permitirNegativo && valor < 0.0)
                    valor = 0.0;

                textBox.Text = valor.ToString("0.###", CultureInfo.InvariantCulture);
            }
        }

        private bool TextoDecimalValido(WinForms.TextBox textBox, bool permitirNegativo)
        {
            if (textBox == null)
                return true;

            string texto = textBox.Text;

            if (string.IsNullOrWhiteSpace(texto))
                return true;

            texto = texto.Trim().Replace(",", ".");

            if (texto.StartsWith("-."))
                texto = "-0" + texto.Substring(1);

            if (texto.StartsWith("."))
                texto = "0" + texto;

            double valor;

            if (!double.TryParse(
                texto,
                NumberStyles.Any,
                CultureInfo.InvariantCulture,
                out valor))
            {
                return false;
            }

            if (!permitirNegativo && valor < 0.0)
                return false;

            return true;
        }

        // =========================================================
        // VISIBILIDAD 1 CAPA / 2 CAPAS
        // =========================================================

        private void ActualizarVisibilidadCapas()
        {
            bool dosCapas = UsarDosCapas;

            try
            {
                this.SuspendLayout();

                if (lblSubTipoSueloInferior != null)
                    lblSubTipoSueloInferior.Text = dosCapas ? "Suelo inferior" : "Suelo";

                if (lblSubTipoSueloSuperior != null)
                    lblSubTipoSueloSuperior.Visible = dosCapas;

                if (cmbTipoSueloSuperior != null)
                    cmbTipoSueloSuperior.Visible = dosCapas;

                int yNivel = dosCapas ? 349 : 288;
                int yDesfase = dosCapas ? 416 : 355;
                int yProfundidadQuiebre = dosCapas ? 485 : 424;
                int yOpciones = dosCapas ? 554 : 493;
                int yBotones = dosCapas ? 645 : 584;
                int altoVentana = dosCapas ? 750 : 690;

                if (lblNivel != null) lblNivel.Top = yNivel;
                if (cmbNivel != null) cmbNivel.Top = yNivel + 27;

                if (lblDesfase != null) lblDesfase.Top = yDesfase;
                if (txtDesfaseMetros != null) txtDesfaseMetros.Top = yDesfase + 27;
                if (lblNotaDesfase != null) lblNotaDesfase.Top = yDesfase + 30;

                if (lblNotaDesfase != null)
                {
                    lblNotaDesfase.Text = dosCapas
                        ? "Cota de encuentro entre el suelo inferior y superior"
                        : "Cota inferior del suelo respecto al nivel";
                }

                if (lblProfundidadQuiebrePuertas != null) lblProfundidadQuiebrePuertas.Top = yProfundidadQuiebre;
                if (txtProfundidadQuiebrePuertasMetros != null) txtProfundidadQuiebrePuertasMetros.Top = yProfundidadQuiebre + 27;
                if (lblNotaProfundidadQuiebrePuertas != null) lblNotaProfundidadQuiebrePuertas.Top = yProfundidadQuiebre + 30;

                if (lblOpciones != null) lblOpciones.Top = yOpciones;
                if (chkIncluirPuertas != null) chkIncluirPuertas.Top = yOpciones + 26;
                if (chkDescontarIntersecciones != null) chkDescontarIntersecciones.Top = yOpciones + 53;

                if (btnEjecutar != null) btnEjecutar.Top = yBotones;
                if (btnCerrar != null) btnCerrar.Top = yBotones;

                // IMPORTANTE:
                // Primero se libera MinimumSize/MaximumSize para que WinForms sí permita achicar
                // la ventana cuando se desactiva "Crear con 2 capas".
                this.MinimumSize = new Drawing.Size(540, 1);
                this.MaximumSize = Drawing.Size.Empty;

                this.Size = new Drawing.Size(540, altoVentana);

                // Luego se vuelve a fijar el tamaño actual para mantener el estilo FixedDialog
                // y evitar que el usuario redimensione manualmente la ventana.
                this.MinimumSize = new Drawing.Size(540, altoVentana);
                this.MaximumSize = new Drawing.Size(540, altoVentana);
            }
            finally
            {
                this.ResumeLayout(false);
                this.PerformLayout();
            }
        }

        // =========================================================
        // COMBOBOX EDITABLES CON FILTRO EN TIEMPO REAL
        // =========================================================

        private void ConfigurarComboConFiltro(WinForms.ComboBox combo)
        {
            if (combo == null)
                return;

            combo.TextUpdate += Combo_TextUpdate;
            combo.KeyDown += Combo_KeyDown;
            combo.Leave += Combo_Leave;
            combo.DropDown += Combo_DropDown;
        }

        private void Combo_TextUpdate(object sender, EventArgs e)
        {
            if (_cargandoCombos || _filtrandoCombo)
                return;

            WinForms.ComboBox combo = sender as WinForms.ComboBox;

            if (combo == null)
                return;

            if (combo == cmbTipoSueloInferior || combo == cmbTipoSueloSuperior)
            {
                FiltrarComboTiposSuelo(combo, combo.Text);
                return;
            }

            if (combo == cmbNivel)
            {
                FiltrarComboNiveles(combo, combo.Text);
                return;
            }
        }

        private void Combo_KeyDown(object sender, WinForms.KeyEventArgs e)
        {
            WinForms.ComboBox combo = sender as WinForms.ComboBox;

            if (combo == null)
                return;

            if (e.KeyCode == WinForms.Keys.Escape)
            {
                RestaurarComboCompleto(combo, true);
                e.Handled = true;
                return;
            }

            if (e.KeyCode == WinForms.Keys.Enter || e.KeyCode == WinForms.Keys.Tab)
            {
                AsegurarSeleccionCombo(combo);
                combo.SelectionStart = combo.Text.Length;
                combo.SelectionLength = 0;
            }
        }

        private void Combo_Leave(object sender, EventArgs e)
        {
            WinForms.ComboBox combo = sender as WinForms.ComboBox;

            if (combo == null)
                return;

            AsegurarSeleccionCombo(combo);
        }

        private void Combo_DropDown(object sender, EventArgs e)
        {
            WinForms.ComboBox combo = sender as WinForms.ComboBox;

            if (combo == null)
                return;

            if (combo.Items.Count == 0)
                RestaurarComboCompleto(combo, false);
        }

        private void FiltrarComboTiposSuelo(WinForms.ComboBox combo, string textoFiltro)
        {
            if (combo == null)
                return;

            string textoActual = combo.Text;
            int cursor = combo.SelectionStart;

            List<RoomSueloTipoItem> filtrados = new List<RoomSueloTipoItem>();

            foreach (RoomSueloTipoItem item in _tiposSuelo)
            {
                if (item == null)
                    continue;

                if (CoincideFiltro(item.Nombre, textoFiltro))
                    filtrados.Add(item);
            }

            AplicarFiltroACombo(combo, filtrados.Cast<object>().ToList(), textoActual, cursor);
        }

        private void FiltrarComboNiveles(WinForms.ComboBox combo, string textoFiltro)
        {
            if (combo == null)
                return;

            string textoActual = combo.Text;
            int cursor = combo.SelectionStart;

            List<RoomSueloNivelItem> filtrados = new List<RoomSueloNivelItem>();

            foreach (RoomSueloNivelItem item in _niveles)
            {
                if (item == null)
                    continue;

                if (CoincideFiltro(item.Nombre, textoFiltro))
                    filtrados.Add(item);
            }

            AplicarFiltroACombo(combo, filtrados.Cast<object>().ToList(), textoActual, cursor);
        }

        private void AplicarFiltroACombo(
            WinForms.ComboBox combo,
            List<object> itemsFiltrados,
            string textoActual,
            int cursor)
        {
            if (combo == null)
                return;

            try
            {
                _filtrandoCombo = true;

                combo.BeginUpdate();
                combo.Items.Clear();

                if (itemsFiltrados != null)
                {
                    foreach (object item in itemsFiltrados)
                    {
                        if (item != null)
                            combo.Items.Add(item);
                    }
                }

                combo.EndUpdate();

                combo.Text = textoActual;

                if (cursor < 0)
                    cursor = 0;

                if (cursor > combo.Text.Length)
                    cursor = combo.Text.Length;

                combo.SelectionStart = cursor;
                combo.SelectionLength = 0;

                if (combo.Focused)
                {
                    try
                    {
                        combo.DroppedDown = true;
                        WinForms.Cursor.Current = WinForms.Cursors.Default;
                    }
                    catch
                    {
                    }
                }
            }
            finally
            {
                _filtrandoCombo = false;
            }
        }

        private void RestaurarComboCompleto(WinForms.ComboBox combo, bool conservarTexto)
        {
            if (combo == null)
                return;

            string textoActual = combo.Text;
            int cursor = combo.SelectionStart;

            try
            {
                _filtrandoCombo = true;

                combo.BeginUpdate();
                combo.Items.Clear();

                if (combo == cmbTipoSueloInferior || combo == cmbTipoSueloSuperior)
                {
                    foreach (RoomSueloTipoItem item in _tiposSuelo)
                    {
                        if (item != null)
                            combo.Items.Add(item);
                    }
                }
                else if (combo == cmbNivel)
                {
                    foreach (RoomSueloNivelItem item in _niveles)
                    {
                        if (item != null)
                            combo.Items.Add(item);
                    }
                }

                combo.EndUpdate();

                if (conservarTexto)
                {
                    combo.Text = textoActual;

                    if (cursor < 0)
                        cursor = 0;

                    if (cursor > combo.Text.Length)
                        cursor = combo.Text.Length;

                    combo.SelectionStart = cursor;
                    combo.SelectionLength = 0;
                }
            }
            finally
            {
                _filtrandoCombo = false;
            }
        }

        private void AsegurarSeleccionCombo(WinForms.ComboBox combo)
        {
            if (combo == null)
                return;

            if (_cargandoCombos || _filtrandoCombo)
                return;

            if (combo.SelectedItem != null)
                return;

            if (combo == cmbTipoSueloInferior || combo == cmbTipoSueloSuperior)
            {
                RoomSueloTipoItem tipo = BuscarTipoSueloPorTexto(combo.Text);

                if (tipo != null)
                {
                    RestaurarComboCompleto(combo, false);
                    SeleccionarTipoSueloEnCombo(combo, tipo.Id);
                    return;
                }
            }

            if (combo == cmbNivel)
            {
                RoomSueloNivelItem nivel = BuscarNivelPorTexto(combo.Text);

                if (nivel != null)
                {
                    RestaurarComboCompleto(combo, false);
                    SeleccionarNivelEnCombo(combo, nivel.Id);
                    return;
                }
            }
        }

        private ElementId ObtenerTipoSueloIdDesdeCombo(WinForms.ComboBox combo)
        {
            if (combo == null)
                return ElementId.InvalidElementId;

            RoomSueloTipoItem itemSeleccionado = combo.SelectedItem as RoomSueloTipoItem;

            if (itemSeleccionado != null && itemSeleccionado.Id != null)
                return itemSeleccionado.Id;

            RoomSueloTipoItem itemPorTexto = BuscarTipoSueloPorTexto(combo.Text);

            if (itemPorTexto != null && itemPorTexto.Id != null)
                return itemPorTexto.Id;

            return ElementId.InvalidElementId;
        }

        private ElementId ObtenerNivelIdDesdeCombo(WinForms.ComboBox combo)
        {
            if (combo == null)
                return ElementId.InvalidElementId;

            RoomSueloNivelItem itemSeleccionado = combo.SelectedItem as RoomSueloNivelItem;

            if (itemSeleccionado != null && itemSeleccionado.Id != null)
                return itemSeleccionado.Id;

            RoomSueloNivelItem itemPorTexto = BuscarNivelPorTexto(combo.Text);

            if (itemPorTexto != null && itemPorTexto.Id != null)
                return itemPorTexto.Id;

            return ElementId.InvalidElementId;
        }

        private RoomSueloTipoItem BuscarTipoSueloPorTexto(string texto)
        {
            if (_tiposSuelo == null || _tiposSuelo.Count == 0)
                return null;

            string filtro = NormalizarTexto(texto);

            if (string.IsNullOrWhiteSpace(filtro))
                return null;

            foreach (RoomSueloTipoItem item in _tiposSuelo)
            {
                if (item == null)
                    continue;

                if (NormalizarTexto(item.Nombre) == filtro)
                    return item;
            }

            foreach (RoomSueloTipoItem item in _tiposSuelo)
            {
                if (item == null)
                    continue;

                if (NormalizarTexto(item.Nombre).Contains(filtro))
                    return item;
            }

            return null;
        }

        private RoomSueloNivelItem BuscarNivelPorTexto(string texto)
        {
            if (_niveles == null || _niveles.Count == 0)
                return null;

            string filtro = NormalizarTexto(texto);

            if (string.IsNullOrWhiteSpace(filtro))
                return null;

            foreach (RoomSueloNivelItem item in _niveles)
            {
                if (item == null)
                    continue;

                if (NormalizarTexto(item.Nombre) == filtro)
                    return item;
            }

            foreach (RoomSueloNivelItem item in _niveles)
            {
                if (item == null)
                    continue;

                if (NormalizarTexto(item.Nombre).Contains(filtro))
                    return item;
            }

            return null;
        }

        private bool CoincideFiltro(string textoBase, string textoFiltro)
        {
            string baseNormalizada = NormalizarTexto(textoBase);
            string filtroNormalizado = NormalizarTexto(textoFiltro);

            if (string.IsNullOrWhiteSpace(filtroNormalizado))
                return true;

            return baseNormalizada.Contains(filtroNormalizado);
        }

        private string NormalizarTexto(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return "";

            string textoFormD = texto.Trim().Normalize(System.Text.NormalizationForm.FormD);
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            for (int i = 0; i < textoFormD.Length; i++)
            {
                char c = textoFormD[i];

                System.Globalization.UnicodeCategory categoria =
                    System.Globalization.CharUnicodeInfo.GetUnicodeCategory(c);

                if (categoria != System.Globalization.UnicodeCategory.NonSpacingMark)
                    sb.Append(c);
            }

            return sb.ToString()
                .Normalize(System.Text.NormalizationForm.FormC)
                .ToUpperInvariant();
        }

        // =========================================================
        // CARGA DE TIPOS Y NIVELES
        // =========================================================

        private void CargarTiposDeSuelo()
        {
            try
            {
                _cargandoCombos = true;

                _tiposSuelo.Clear();
                cmbTipoSueloInferior.Items.Clear();
                cmbTipoSueloSuperior.Items.Clear();

                List<FloorType> tipos = new FilteredElementCollector(_doc)
                    .OfClass(typeof(FloorType))
                    .Cast<FloorType>()
                    .OrderBy(x => x.Name)
                    .ToList();

                foreach (FloorType ft in tipos)
                {
                    RoomSueloTipoItem item = new RoomSueloTipoItem()
                    {
                        Id = ft.Id,
                        Nombre = ft.Name
                    };

                    _tiposSuelo.Add(item);
                }

                foreach (RoomSueloTipoItem item in _tiposSuelo)
                {
                    cmbTipoSueloInferior.Items.Add(item);
                    cmbTipoSueloSuperior.Items.Add(item);
                }

                if (cmbTipoSueloInferior.Items.Count > 0)
                    cmbTipoSueloInferior.SelectedIndex = 0;

                if (cmbTipoSueloSuperior.Items.Count > 0)
                    cmbTipoSueloSuperior.SelectedIndex = 0;
            }
            finally
            {
                _cargandoCombos = false;
            }
        }

        private void CargarNiveles()
        {
            try
            {
                _cargandoCombos = true;

                _niveles.Clear();
                cmbNivel.Items.Clear();

                List<Level> niveles = new FilteredElementCollector(_doc)
                    .OfClass(typeof(Level))
                    .Cast<Level>()
                    .OrderBy(x => x.Elevation)
                    .ToList();

                foreach (Level nivel in niveles)
                {
                    RoomSueloNivelItem item = new RoomSueloNivelItem()
                    {
                        Id = nivel.Id,
                        Nombre = nivel.Name,
                        Elevation = nivel.Elevation
                    };

                    _niveles.Add(item);
                    cmbNivel.Items.Add(item);
                }

                if (cmbNivel.Items.Count > 0)
                    cmbNivel.SelectedIndex = 0;
            }
            finally
            {
                _cargandoCombos = false;
            }
        }

        public void ActualizarRoomsSeleccionados(List<Room> rooms)
        {
            RoomsSeleccionadosIds = new List<ElementId>();

            if (rooms == null || rooms.Count == 0)
            {
                lblRoomSeleccionado.Text = "Rooms seleccionados: Ninguno";
                MostrarResultado("No se seleccionó ningún Room válido.");
                return;
            }

            foreach (Room room in rooms)
            {
                if (room == null)
                    continue;

                if (!RoomsSeleccionadosIds.Any(x => x.Value == room.Id.Value))
                    RoomsSeleccionadosIds.Add(room.Id);
            }

            Room primerRoom = rooms.FirstOrDefault();

            if (primerRoom != null)
                SeleccionarNivelPorId(primerRoom.LevelId);

            List<string> nombres = new List<string>();

            foreach (Room room in rooms)
            {
                string textoRoom = ObtenerTextoRoom(room);

                if (!string.IsNullOrWhiteSpace(textoRoom))
                    nombres.Add(textoRoom);
            }

            string resumen = "Rooms seleccionados: " + RoomsSeleccionadosIds.Count.ToString();

            if (nombres.Count > 0)
            {
                resumen += "\r\n" + string.Join(" | ", nombres.Take(3));

                if (nombres.Count > 3)
                    resumen += " | ...";
            }

            lblRoomSeleccionado.Text = resumen;

            MostrarResultado(
                "Rooms seleccionados correctamente: " + RoomsSeleccionadosIds.Count.ToString() + "\r\n\r\n" +
                "Ahora seleccione tipo de suelo, nivel, desfase, opciones y presione EJECUTAR.");
        }

        private string ObtenerTextoRoom(Room room)
        {
            if (room == null)
                return "";

            string numero = "";
            string nombre = "";

            Parameter pNumero = room.get_Parameter(BuiltInParameter.ROOM_NUMBER);
            if (pNumero != null)
                numero = pNumero.AsString();

            Parameter pNombre = room.get_Parameter(BuiltInParameter.ROOM_NAME);
            if (pNombre != null)
                nombre = pNombre.AsString();

            string textoRoom = "";

            if (!string.IsNullOrWhiteSpace(numero))
                textoRoom += numero;

            if (!string.IsNullOrWhiteSpace(nombre))
            {
                if (!string.IsNullOrWhiteSpace(textoRoom))
                    textoRoom += " - ";

                textoRoom += nombre;
            }

            if (string.IsNullOrWhiteSpace(textoRoom))
                textoRoom = "Id " + room.Id.Value.ToString();

            return textoRoom;
        }

        private void SeleccionarNivelPorId(ElementId levelId)
        {
            if (levelId == null || levelId == ElementId.InvalidElementId)
                return;

            RestaurarComboCompleto(cmbNivel, false);
            SeleccionarNivelEnCombo(cmbNivel, levelId);
        }

        private void SeleccionarNivelEnCombo(WinForms.ComboBox combo, ElementId levelId)
        {
            if (combo == null || levelId == null || levelId == ElementId.InvalidElementId)
                return;

            for (int i = 0; i < combo.Items.Count; i++)
            {
                RoomSueloNivelItem item = combo.Items[i] as RoomSueloNivelItem;

                if (item == null)
                    continue;

                if (item.Id.Value == levelId.Value)
                {
                    combo.SelectedIndex = i;
                    return;
                }
            }
        }

        private void SeleccionarTipoSueloEnCombo(WinForms.ComboBox combo, ElementId tipoId)
        {
            if (combo == null || tipoId == null || tipoId == ElementId.InvalidElementId)
                return;

            for (int i = 0; i < combo.Items.Count; i++)
            {
                RoomSueloTipoItem item = combo.Items[i] as RoomSueloTipoItem;

                if (item == null)
                    continue;

                if (item.Id.Value == tipoId.Value)
                {
                    combo.SelectedIndex = i;
                    return;
                }
            }
        }

        public void MostrarResultado(string texto)
        {
            _ultimoResultado = texto ?? "";

            if (string.IsNullOrWhiteSpace(_ultimoResultado))
                return;

            // IMPORTANTE:
            // Ya no se muestra ventana emergente cuando termina correctamente el proceso.
            // El handler puede seguir enviando el reporte final con "PROCESO TERMINADO",
            // pero esta ventana lo recibe silenciosamente para no interrumpir al usuario.
            if (_ultimoResultado.StartsWith("PROCESO TERMINADO", StringComparison.OrdinalIgnoreCase))
                return;

            bool mostrarMensaje =
                _ultimoResultado.StartsWith("ERROR", StringComparison.OrdinalIgnoreCase) ||
                _ultimoResultado.StartsWith("Debe", StringComparison.OrdinalIgnoreCase) ||
                _ultimoResultado.StartsWith("No se", StringComparison.OrdinalIgnoreCase);

            if (!mostrarMensaje)
                return;

            WinForms.MessageBoxIcon icono = WinForms.MessageBoxIcon.Warning;

            try
            {
                WinForms.MessageBox.Show(
                    this,
                    _ultimoResultado,
                    "MYG - Crear Suelo desde Rooms",
                    WinForms.MessageBoxButtons.OK,
                    icono);
            }
            catch
            {
            }
        }

        public void OcultarTemporalmenteParaSeleccion()
        {
            try
            {
                this.Hide();
            }
            catch
            {
            }
        }

        public void MostrarLuegoDeSeleccion()
        {
            try
            {
                this.Show();
                this.Activate();
                this.TopMost = true;
            }
            catch
            {
            }
        }
        // =========================================================
        // CLASES INTERNAS PARA ORDENAR EL CÓDIGO
        // =========================================================

        private class RoomSueloTipoItem
        {
            public ElementId Id { get; set; }
            public string Nombre { get; set; }

            public override string ToString()
            {
                return Nombre;
            }
        }

        private class RoomSueloNivelItem
        {
            public ElementId Id { get; set; }
            public string Nombre { get; set; }
            public double Elevation { get; set; }

            public override string ToString()
            {
                return Nombre;
            }
        }
    }

}
