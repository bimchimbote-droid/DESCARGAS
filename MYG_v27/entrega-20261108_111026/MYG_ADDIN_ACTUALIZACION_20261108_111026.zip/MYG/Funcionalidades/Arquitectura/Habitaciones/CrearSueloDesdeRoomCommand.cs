using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{








    // =====================================
    // COMANDO 4.1 - CREAR SUELO DESDE ROOM
    // =====================================


    [Transaction(TransactionMode.Manual)]
    public class CrearSueloDesdeRoomCommand : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            UIDocument uidoc = commandData.Application.ActiveUIDocument;

            //-------------------------------------------------
            // MOSTRAR VENTANA
            //-------------------------------------------------

            CrearSueloDesdeRoomForm form = new CrearSueloDesdeRoomForm(uidoc);

            //-------------------------------------------------
            // HANDLER EXTERNO
            //-------------------------------------------------

            EjecutarCrearSueloDesdeRoomHandler ejecutarHandler =
                new EjecutarCrearSueloDesdeRoomHandler();

            ejecutarHandler.UiDoc = uidoc;
            ejecutarHandler.Form = form;

            ExternalEvent ejecutarEvent = ExternalEvent.Create(ejecutarHandler);

            form.EjecutarEvent = ejecutarEvent;
            form.Handler = ejecutarHandler;

            //-------------------------------------------------
            // MOSTRAR FORMULARIO
            //-------------------------------------------------

            form.Show();

            return Result.Succeeded;
        }
    }

}
