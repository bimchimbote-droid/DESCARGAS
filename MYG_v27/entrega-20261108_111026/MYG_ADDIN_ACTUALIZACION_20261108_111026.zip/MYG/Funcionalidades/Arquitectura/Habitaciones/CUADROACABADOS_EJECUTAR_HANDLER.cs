﻿// =====================================
// HANDLER EXTERNO - CUADRO DE ACABADOS DESDE ROOMS
// REVIT 2027
// SELECCIÓN MÚLTIPLE DE ROOMS + DETECCIÓN DE MUROS Y SUELOS + EXPORTACIÓN EXCEL
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Drawing = System.Drawing;

public class EjecutarCuadroAcabadosRoomHandler : IExternalEventHandler
{
    public UIDocument UiDoc { get; set; }
    public CuadroAcabadosRoomForm Form { get; set; }

    public CuadroAcabadosRoomForm.CuadroAcabadosRoomAccion Accion { get; set; } =
        CuadroAcabadosRoomForm.CuadroAcabadosRoomAccion.Ninguna;

    public string GetName()
    {
        return "MYG - Cuadro de acabados por Rooms";
    }

    public void Execute(UIApplication app)
    {
        if (UiDoc == null || UiDoc.Document == null)
            return;

        if (Form == null || Form.IsDisposed)
            return;

        try
        {
            if (Accion == CuadroAcabadosRoomForm.CuadroAcabadosRoomAccion.SeleccionarRooms)
            {
                SeleccionarRooms();
                return;
            }

            if (Accion == CuadroAcabadosRoomForm.CuadroAcabadosRoomAccion.ExportarExcel)
            {
                ExportarCuadroAcabadosExcel();
                return;
            }

            if (Accion == CuadroAcabadosRoomForm.CuadroAcabadosRoomAccion.CrearCuadroLeyenda)
            {
                CrearCuadroAcabadosEnLeyenda();
                return;
            }
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            MostrarEnVentana("Selección cancelada.");
        }
        catch (Exception ex)
        {
            MostrarEnVentana("ERROR:\r\n" + ex.Message);
        }
        finally
        {
            Accion = CuadroAcabadosRoomForm.CuadroAcabadosRoomAccion.Ninguna;
        }
    }

    // =========================================================
    // SELECCIONAR ROOMS
    // =========================================================

    private void SeleccionarRooms()
    {
        Document doc = UiDoc.Document;

        try
        {
            Form.OcultarTemporalmenteParaSeleccion();

            IList<Reference> referencias = UiDoc.Selection.PickObjects(
                ObjectType.Element,
                new FiltroSeleccionRoomMYG(),
                "Seleccione una o más habitaciones / Rooms");

            if (referencias == null || referencias.Count == 0)
                return;

            List<Room> rooms = new List<Room>();

            foreach (Reference referencia in referencias)
            {
                if (referencia == null)
                    continue;

                Room room = doc.GetElement(referencia.ElementId) as Room;

                if (room == null)
                    continue;

                try
                {
                    if (room.Area <= 0)
                        continue;
                }
                catch
                {
                }

                bool yaExiste = false;

                foreach (Room roomExistente in rooms)
                {
                    if (roomExistente == null)
                        continue;

                    if (roomExistente.Id.Value == room.Id.Value)
                    {
                        yaExiste = true;
                        break;
                    }
                }

                if (!yaExiste)
                    rooms.Add(room);
            }

            if (rooms.Count == 0)
            {
                MostrarEnVentana("No se seleccionó ningún Room válido.");
                return;
            }

            Form.ActualizarRoomsSeleccionados(rooms);
        }
        finally
        {
            Form.MostrarLuegoDeSeleccion();
        }
    }

    // =========================================================
    // EXPORTAR EXCEL
    // =========================================================

    private void ExportarCuadroAcabadosExcel()
    {
        Document doc = UiDoc.Document;

        List<ElementId> roomIds = Form.RoomsSeleccionadosIds;

        if (roomIds == null || roomIds.Count == 0)
        {
            MostrarEnVentana("Debe seleccionar una o más habitaciones / Rooms.");
            return;
        }

        List<RoomAcabadoMYG> roomsProcesados = new List<RoomAcabadoMYG>();
        Dictionary<string, FilaAcabadoMYG> matriz = new Dictionary<string, FilaAcabadoMYG>();
        Dictionary<long, ElementId> elementosGenerales = new Dictionary<long, ElementId>();
        int elementosDetectadosRoomTotal = 0;

        foreach (ElementId roomId in roomIds)
        {
            if (roomId == null)
                continue;

            Room room = doc.GetElement(roomId) as Room;

            if (room == null)
                continue;

            RoomAcabadoMYG infoRoom = new RoomAcabadoMYG();
            infoRoom.RoomId = room.Id;
            infoRoom.ARQUbicacion = ObtenerParametroRoom(room, "ARQ_Ubicación");

            if (string.IsNullOrWhiteSpace(infoRoom.ARQUbicacion))
                infoRoom.ARQUbicacion = ObtenerParametroRoom(room, "ARQ_Ubicacion");

            if (string.IsNullOrWhiteSpace(infoRoom.ARQUbicacion))
                infoRoom.ARQUbicacion = "-";

            infoRoom.ItemCodigoElemento = ObtenerParametroRoom(room, "ITEM_CódigoElemento");

            if (string.IsNullOrWhiteSpace(infoRoom.ItemCodigoElemento))
                infoRoom.ItemCodigoElemento = ObtenerParametroRoom(room, "ITEM_CodigoElemento");

            infoRoom.NombreRoom = ObtenerNombreRoomConItemCodigo(room, infoRoom.ItemCodigoElemento);
            infoRoom.Elementos = new List<ElementoAcabadoMYG>();

            List<Element> elementos = DetectarMurosYSuelosEnRoom(doc, room);

            if (elementos == null)
                elementos = new List<Element>();

            foreach (Element elemento in elementos)
            {
                if (elemento == null)
                    continue;

                ElementoAcabadoMYG infoElemento = CrearInfoElementoAcabado(doc, elemento, infoRoom.NombreRoom);

                if (infoElemento == null)
                    continue;

                infoRoom.Elementos.Add(infoElemento);
                elementosDetectadosRoomTotal++;

                if (!elementosGenerales.ContainsKey(infoElemento.ElementIdValue))
                    elementosGenerales.Add(infoElemento.ElementIdValue, elemento.Id);

                string claveFila = infoElemento.ClaveFila;

                if (!matriz.ContainsKey(claveFila))
                {
                    FilaAcabadoMYG fila = new FilaAcabadoMYG();
                    fila.Clave = claveFila;
                    fila.Categoria = infoElemento.Categoria;
                    fila.ModeloTipo = infoElemento.ModeloTipo;
                    fila.DescripcionTipo = infoElemento.DescripcionTipo;
                    fila.NombreTipo = infoElemento.NombreTipo;
                    fila.ConteoPorRoom = new Dictionary<long, int>();
                    fila.ElementosIds = new List<ElementId>();
                    matriz.Add(claveFila, fila);
                }

                FilaAcabadoMYG filaExistente = matriz[claveFila];
                long roomKey = infoRoom.RoomId.Value;

                if (!filaExistente.ConteoPorRoom.ContainsKey(roomKey))
                    filaExistente.ConteoPorRoom.Add(roomKey, 0);

                filaExistente.ConteoPorRoom[roomKey]++;
                filaExistente.ElementosIds.Add(elemento.Id);
            }

            roomsProcesados.Add(infoRoom);
        }

        if (roomsProcesados.Count == 0)
        {
            MostrarEnVentana("No se encontraron Rooms válidos para procesar.");
            return;
        }

        if (matriz.Count == 0)
        {
            MostrarEnVentana("No se detectaron muros ni suelos relacionados a los Rooms seleccionados.");
            return;
        }

        string rutaExcel = Form.ObtenerRutaExportacionExcel();

        if (string.IsNullOrWhiteSpace(rutaExcel))
        {
            MostrarEnVentana("Exportación cancelada.");
            return;
        }

        try
        {
            Form.EstablecerRutaExcel(rutaExcel);
        }
        catch
        {
        }

        CrearExcelCuadroAcabados(
            doc,
            rutaExcel,
            roomsProcesados,
            matriz.Values.ToList());

        if (elementosGenerales.Count > 0)
        {
            try
            {
                UiDoc.Selection.SetElementIds(elementosGenerales.Values.ToList());
            }
            catch
            {
            }
        }

        MostrarEnVentana(
            "Excel generado correctamente | Rooms: " + roomsProcesados.Count.ToString() +
            " | Filas de acabados: " + matriz.Count.ToString() +
            " | Detecciones Room-Elemento: " + elementosDetectadosRoomTotal.ToString());
    }

    // =========================================================
    // DETECCIÓN DE MUROS Y SUELOS POR ROOM
    // =========================================================

    private List<Element> DetectarMurosYSuelosEnRoom(Document doc, Room room)
    {
        List<Element> resultado = new List<Element>();
        Dictionary<long, Element> unicos = new Dictionary<long, Element>();

        if (doc == null || room == null)
            return resultado;

        double zPrueba = ObtenerZPruebaRoom(doc, room);
        BoundingBoxXYZ bbRoom = ObtenerBoundingBoxRoomExpandido(room, MetrosAPies(0.50));

        // 1) MUROS POR BOUNDARY DEL ROOM.
        // Esto es importante porque muchos muros delimitan el Room, pero su eje cae dentro del espesor del muro.
        List<ElementId> idsBoundary = ObtenerElementosBoundaryRoom(doc, room);

        foreach (ElementId id in idsBoundary)
        {
            if (id == null || id == ElementId.InvalidElementId)
                continue;

            Element elemento = doc.GetElement(id);

            if (elemento == null)
                continue;

            if (!(elemento is Wall))
                continue;

            long key = elemento.Id.Value;

            if (!unicos.ContainsKey(key))
                unicos.Add(key, elemento);
        }

        // 2) MUROS ADICIONALES POR MUESTREO.
        // Captura muros interiores que no necesariamente aparecen como boundary principal.
        List<Wall> murosCandidatos = ObtenerMurosCandidatos(doc, bbRoom);

        foreach (Wall muro in murosCandidatos)
        {
            if (muro == null)
                continue;

            long key = muro.Id.Value;

            if (unicos.ContainsKey(key))
                continue;

            if (MuroPerteneceARoom(doc, muro, room, zPrueba))
                unicos.Add(key, muro);
        }

        // 3) SUELOS POR MUESTREO DE CARA SUPERIOR.
        List<Floor> suelosCandidatos = ObtenerSuelosCandidatos(doc, bbRoom);

        foreach (Floor suelo in suelosCandidatos)
        {
            if (suelo == null)
                continue;

            long key = suelo.Id.Value;

            if (unicos.ContainsKey(key))
                continue;

            if (SueloPerteneceARoom(doc, suelo, room, zPrueba))
                unicos.Add(key, suelo);
        }

        foreach (Element elemento in unicos.Values)
        {
            if (elemento != null)
                resultado.Add(elemento);
        }

        resultado.Sort(delegate (Element a, Element b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            return a.Id.Value.CompareTo(b.Id.Value);
        });

        return resultado;
    }

    private List<ElementId> ObtenerElementosBoundaryRoom(Document doc, Room room)
    {
        List<ElementId> ids = new List<ElementId>();
        HashSet<long> unicos = new HashSet<long>();

        if (doc == null || room == null)
            return ids;

        try
        {
            SpatialElementBoundaryOptions opciones = new SpatialElementBoundaryOptions();
            opciones.SpatialElementBoundaryLocation = SpatialElementBoundaryLocation.Finish;

            IList<IList<BoundarySegment>> loops = room.GetBoundarySegments(opciones);

            if (loops == null)
                return ids;

            foreach (IList<BoundarySegment> loop in loops)
            {
                if (loop == null)
                    continue;

                foreach (BoundarySegment segmento in loop)
                {
                    if (segmento == null)
                        continue;

                    ElementId id = segmento.ElementId;

                    if (id == null || id == ElementId.InvalidElementId)
                        continue;

                    if (unicos.Contains(id.Value))
                        continue;

                    Element elemento = doc.GetElement(id);

                    if (elemento == null)
                        continue;

                    // Por ahora para el cuadro de acabados solo interesa capturar muros desde boundary.
                    // Los suelos se detectan por muestreo de cara superior.
                    if (elemento is Wall)
                    {
                        unicos.Add(id.Value);
                        ids.Add(id);
                    }
                }
            }
        }
        catch
        {
        }

        return ids;
    }

    private List<Wall> ObtenerMurosCandidatos(Document doc, BoundingBoxXYZ bbRoom)
    {
        List<Wall> resultado = new List<Wall>();

        if (doc == null)
            return resultado;

        FilteredElementCollector collector = new FilteredElementCollector(doc);
        collector.OfClass(typeof(Wall));
        collector.WhereElementIsNotElementType();

        ElementFilter filtro = CrearFiltroBoundingBox(bbRoom);

        if (filtro != null)
            collector.WherePasses(filtro);

        foreach (Element elemento in collector)
        {
            Wall muro = elemento as Wall;

            if (muro == null)
                continue;

            resultado.Add(muro);
        }

        return resultado;
    }

    private List<Floor> ObtenerSuelosCandidatos(Document doc, BoundingBoxXYZ bbRoom)
    {
        List<Floor> resultado = new List<Floor>();

        if (doc == null)
            return resultado;

        FilteredElementCollector collector = new FilteredElementCollector(doc);
        collector.OfClass(typeof(Floor));
        collector.WhereElementIsNotElementType();

        ElementFilter filtro = CrearFiltroBoundingBox(bbRoom);

        if (filtro != null)
            collector.WherePasses(filtro);

        foreach (Element elemento in collector)
        {
            Floor suelo = elemento as Floor;

            if (suelo == null)
                continue;

            resultado.Add(suelo);
        }

        return resultado;
    }

    private ElementFilter CrearFiltroBoundingBox(BoundingBoxXYZ bb)
    {
        if (bb == null)
            return null;

        try
        {
            Outline outline = new Outline(bb.Min, bb.Max);
            return new BoundingBoxIntersectsFilter(outline);
        }
        catch
        {
            return null;
        }
    }

    private bool MuroPerteneceARoom(Document doc, Wall muro, Room room, double zPrueba)
    {
        if (doc == null || muro == null || room == null)
            return false;

        LocationCurve locCurve = muro.Location as LocationCurve;

        if (locCurve == null || locCurve.Curve == null)
            return false;

        Curve curva = locCurve.Curve;

        XYZ pInicio = null;
        XYZ pFin = null;

        try
        {
            pInicio = curva.GetEndPoint(0);
            pFin = curva.GetEndPoint(1);
        }
        catch
        {
            return false;
        }

        if (pInicio == null || pFin == null)
            return false;

        XYZ dirXY = new XYZ(pFin.X - pInicio.X, pFin.Y - pInicio.Y, 0.0);

        if (dirXY.GetLength() < 0.0001)
            return false;

        dirXY = dirXY.Normalize();

        XYZ perpendicular = new XYZ(-dirXY.Y, dirXY.X, 0.0);

        double ancho = ObtenerAnchoMuro(muro);
        double margen = MetrosAPies(0.06);
        double offsetPrincipal = (ancho / 2.0) + margen;

        double[] parametros = new double[] { 0.10, 0.25, 0.50, 0.75, 0.90 };
        double[] offsets = new double[]
        {
            0.0,
            offsetPrincipal,
            -offsetPrincipal,
            MetrosAPies(0.15),
            -MetrosAPies(0.15)
        };

        foreach (double parametro in parametros)
        {
            XYZ p = null;

            try
            {
                p = curva.Evaluate(parametro, true);
            }
            catch
            {
                p = null;
            }

            if (p == null)
                continue;

            foreach (double offset in offsets)
            {
                XYZ pTest = new XYZ(
                    p.X + perpendicular.X * offset,
                    p.Y + perpendicular.Y * offset,
                    zPrueba);

                try
                {
                    if (room.IsPointInRoom(pTest))
                        return true;
                }
                catch
                {
                }
            }
        }

        return false;
    }

    private bool SueloPerteneceARoom(Document doc, Floor suelo, Room room, double zPrueba)
    {
        if (doc == null || suelo == null || room == null)
            return false;

        List<PlanarFace> carasSuperiores = ObtenerCarasSuperioresSuelo(suelo);

        if (carasSuperiores != null && carasSuperiores.Count > 0)
        {
            double[] muestras = new double[] { 0.10, 0.25, 0.50, 0.75, 0.90 };

            foreach (PlanarFace cara in carasSuperiores)
            {
                if (cara == null)
                    continue;

                BoundingBoxUV bb = null;

                try
                {
                    bb = cara.GetBoundingBox();
                }
                catch
                {
                    bb = null;
                }

                if (bb == null)
                    continue;

                foreach (double fu in muestras)
                {
                    foreach (double fv in muestras)
                    {
                        double u = bb.Min.U + (bb.Max.U - bb.Min.U) * fu;
                        double v = bb.Min.V + (bb.Max.V - bb.Min.V) * fv;

                        UV uv = new UV(u, v);

                        bool dentroCara = false;

                        try
                        {
                            dentroCara = cara.IsInside(uv);
                        }
                        catch
                        {
                            dentroCara = true;
                        }

                        if (!dentroCara)
                            continue;

                        XYZ p = null;

                        try
                        {
                            p = cara.Evaluate(uv);
                        }
                        catch
                        {
                            p = null;
                        }

                        if (p == null)
                            continue;

                        XYZ pRoom = new XYZ(p.X, p.Y, zPrueba);

                        try
                        {
                            if (room.IsPointInRoom(pRoom))
                                return true;
                        }
                        catch
                        {
                        }
                    }
                }
            }
        }

        // Fallback por bounding box para casos donde no se pudo leer geometría.
        return SueloPerteneceARoomPorBoundingBox(suelo, room, zPrueba);
    }

    private List<PlanarFace> ObtenerCarasSuperioresSuelo(Floor suelo)
    {
        List<PlanarFace> caras = new List<PlanarFace>();

        if (suelo == null)
            return caras;

        Options opciones = new Options();
        opciones.ComputeReferences = false;
        opciones.DetailLevel = ViewDetailLevel.Fine;

        GeometryElement geo = null;

        try
        {
            geo = suelo.get_Geometry(opciones);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return caras;

        foreach (GeometryObject obj in geo)
        {
            Solid solid = obj as Solid;

            if (solid == null || solid.Faces == null || solid.Faces.Size == 0)
                continue;

            foreach (Face face in solid.Faces)
            {
                PlanarFace pf = face as PlanarFace;

                if (pf == null)
                    continue;

                XYZ normal = null;

                try
                {
                    normal = pf.FaceNormal;
                }
                catch
                {
                    normal = null;
                }

                if (normal == null)
                    continue;

                if (normal.Z > 0.70)
                    caras.Add(pf);
            }
        }

        caras.Sort(delegate (PlanarFace a, PlanarFace b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;

            double za = 0.0;
            double zb = 0.0;

            try { za = a.Origin.Z; } catch { }
            try { zb = b.Origin.Z; } catch { }

            return zb.CompareTo(za);
        });

        return caras;
    }

    private bool SueloPerteneceARoomPorBoundingBox(Floor suelo, Room room, double zPrueba)
    {
        if (suelo == null || room == null)
            return false;

        BoundingBoxXYZ bb = null;

        try
        {
            bb = suelo.get_BoundingBox(null);
        }
        catch
        {
            bb = null;
        }

        if (bb == null)
            return false;

        double[] muestras = new double[] { 0.20, 0.50, 0.80 };

        foreach (double fx in muestras)
        {
            foreach (double fy in muestras)
            {
                double x = bb.Min.X + (bb.Max.X - bb.Min.X) * fx;
                double y = bb.Min.Y + (bb.Max.Y - bb.Min.Y) * fy;

                XYZ pRoom = new XYZ(x, y, zPrueba);

                try
                {
                    if (room.IsPointInRoom(pRoom))
                        return true;
                }
                catch
                {
                }
            }
        }

        return false;
    }

    // =========================================================
    // INFO ELEMENTO / PARÁMETRO DE TIPO DESCRIPCIÓN
    // =========================================================

    private ElementoAcabadoMYG CrearInfoElementoAcabado(
        Document doc,
        Element elemento,
        string nombreRoom)
    {
        if (doc == null || elemento == null)
            return null;

        string categoria = ObtenerCategoriaElemento(elemento);
        string nombreTipo = ObtenerNombreTipoElemento(doc, elemento);
        string modeloTipo = ObtenerModeloTipoElemento(doc, elemento);
        string descripcionTipo = ObtenerDescripcionTipoElemento(doc, elemento);

        if (string.IsNullOrWhiteSpace(modeloTipo))
            modeloTipo = "SIN MODELO";

        if (string.IsNullOrWhiteSpace(descripcionTipo))
            descripcionTipo = "SIN DESCRIPCIÓN | " + nombreTipo;

        ElementoAcabadoMYG info = new ElementoAcabadoMYG();
        info.ElementId = elemento.Id;
        info.ElementIdValue = elemento.Id.Value;
        info.Categoria = categoria;
        info.NombreTipo = nombreTipo;
        info.ModeloTipo = modeloTipo;
        info.DescripcionTipo = descripcionTipo;
        info.NombreRoom = nombreRoom;
        // IMPORTANTE:
        // La matriz se agrupa por MODELO DE TIPO + DESCRIPCIÓN.
        // No se usa CATEGORÍA para que elementos de muros y suelos con el mismo modelo
        // queden agrupados bajo una sola cabecera en Excel y en la leyenda.
        info.ClaveFila = NormalizarClave(NormalizarTextoModelo(modeloTipo)) + "|" + NormalizarClave(descripcionTipo);

        return info;
    }

    private string ObtenerCategoriaElemento(Element elemento)
    {
        if (elemento == null)
            return "";

        if (elemento is Wall)
            return "MUROS";

        if (elemento is Floor)
            return "SUELOS";

        try
        {
            if (elemento.Category != null)
                return elemento.Category.Name;
        }
        catch
        {
        }

        return "ELEMENTOS";
    }

    private string ObtenerNombreTipoElemento(Document doc, Element elemento)
    {
        if (doc == null || elemento == null)
            return "";

        Element tipo = null;

        try
        {
            ElementId tipoId = elemento.GetTypeId();

            if (tipoId != null && tipoId != ElementId.InvalidElementId)
                tipo = doc.GetElement(tipoId);
        }
        catch
        {
            tipo = null;
        }

        if (tipo != null)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(tipo.Name))
                    return tipo.Name;
            }
            catch
            {
            }
        }

        try
        {
            return elemento.Name;
        }
        catch
        {
            return "";
        }
    }

    private string ObtenerModeloTipoElemento(Document doc, Element elemento)
    {
        if (doc == null || elemento == null)
            return "";

        Element tipo = null;

        try
        {
            ElementId tipoId = elemento.GetTypeId();

            if (tipoId != null && tipoId != ElementId.InvalidElementId)
                tipo = doc.GetElement(tipoId);
        }
        catch
        {
            tipo = null;
        }

        if (tipo == null)
            return "";

        string valor = ObtenerTextoParametro(tipo, "Modelo");

        if (!string.IsNullOrWhiteSpace(valor))
            return valor.Trim();

        valor = ObtenerTextoParametro(tipo, "Model");

        if (!string.IsNullOrWhiteSpace(valor))
            return valor.Trim();

        try
        {
            Parameter p = tipo.get_Parameter(BuiltInParameter.ALL_MODEL_MODEL);
            valor = ObtenerTextoDesdeParametro(p);

            if (!string.IsNullOrWhiteSpace(valor))
                return valor.Trim();
        }
        catch
        {
        }

        return "";
    }

    private string ObtenerDescripcionTipoElemento(Document doc, Element elemento)
    {
        if (doc == null || elemento == null)
            return "";

        Element tipo = null;

        try
        {
            ElementId tipoId = elemento.GetTypeId();

            if (tipoId != null && tipoId != ElementId.InvalidElementId)
                tipo = doc.GetElement(tipoId);
        }
        catch
        {
            tipo = null;
        }

        if (tipo == null)
            return "";

        string valor = ObtenerTextoParametro(tipo, "Descripción");

        if (!string.IsNullOrWhiteSpace(valor))
            return valor.Trim();

        valor = ObtenerTextoParametro(tipo, "Description");

        if (!string.IsNullOrWhiteSpace(valor))
            return valor.Trim();

        try
        {
            Parameter p = tipo.get_Parameter(BuiltInParameter.ALL_MODEL_DESCRIPTION);
            valor = ObtenerTextoDesdeParametro(p);

            if (!string.IsNullOrWhiteSpace(valor))
                return valor.Trim();
        }
        catch
        {
        }

        return "";
    }

    private string ObtenerTextoParametro(Element elemento, string nombreParametro)
    {
        if (elemento == null || string.IsNullOrWhiteSpace(nombreParametro))
            return "";

        try
        {
            Parameter p = elemento.LookupParameter(nombreParametro);
            return ObtenerTextoDesdeParametro(p);
        }
        catch
        {
            return "";
        }
    }

    private string ObtenerTextoDesdeParametro(Parameter p)
    {
        if (p == null || !p.HasValue)
            return "";

        try
        {
            if (p.StorageType == StorageType.String)
                return p.AsString() ?? "";

            string textoValor = p.AsValueString();

            if (!string.IsNullOrWhiteSpace(textoValor))
                return textoValor;

            if (p.StorageType == StorageType.Integer)
                return p.AsInteger().ToString();

            if (p.StorageType == StorageType.Double)
                return p.AsDouble().ToString("0.###", CultureInfo.InvariantCulture);

            if (p.StorageType == StorageType.ElementId)
            {
                ElementId id = p.AsElementId();

                if (id != null)
                    return id.Value.ToString();
            }
        }
        catch
        {
        }

        return "";
    }

    private string NormalizarTextoModelo(string modelo)
    {
        if (string.IsNullOrWhiteSpace(modelo))
            return "SIN MODELO";

        string limpio = modelo.Trim();

        if (string.IsNullOrWhiteSpace(limpio))
            return "SIN MODELO";

        if (NormalizarClave(limpio) == NormalizarClave("SIN MODELO"))
            return "SIN MODELO";

        return limpio;
    }

    // =========================================================
    // CREAR EXCEL
    // =========================================================

    private void CrearExcelCuadroAcabados(
        Document doc,
        string rutaExcel,
        List<RoomAcabadoMYG> rooms,
        List<FilaAcabadoMYG> filas)
    {
        if (string.IsNullOrWhiteSpace(rutaExcel))
            return;

        if (rooms == null)
            rooms = new List<RoomAcabadoMYG>();

        if (filas == null)
            filas = new List<FilaAcabadoMYG>();

        filas.Sort(delegate (FilaAcabadoMYG a, FilaAcabadoMYG b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;

            // IMPORTANTE:
            // Ya no se ordena por CATEGORÍA porque MUROS/SUELOS ya no son cabecera.
            // Esto permite que todos los acabados con el mismo MODELO DE TIPO,
            // por ejemplo "SIN MODELO", queden juntos aunque provengan de muros o suelos.
            int c = string.Compare(
                NormalizarTextoModelo(a.ModeloTipo),
                NormalizarTextoModelo(b.ModeloTipo),
                StringComparison.CurrentCultureIgnoreCase);

            if (c != 0)
                return c;

            return string.Compare(a.DescripcionTipo, b.DescripcionTipo, StringComparison.CurrentCultureIgnoreCase);
        });

        if (File.Exists(rutaExcel))
            File.Delete(rutaExcel);

        ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;

        FileInfo archivo = new FileInfo(rutaExcel);

        using (ExcelPackage package = new ExcelPackage(archivo))
        {
            ExcelWorksheet ws = package.Workbook.Worksheets.Add("CUADRO DE ACABADOS");
            ExcelWorksheet wsDetalle = package.Workbook.Worksheets.Add("DETALLE ELEMENTOS");
            ExcelWorksheet wsResumen = package.Workbook.Worksheets.Add("RESUMEN");

            CrearHojaMatriz(doc, ws, rooms, filas);
            CrearHojaDetalle(wsDetalle, rooms);
            CrearHojaResumen(wsResumen, rooms, filas);

            package.Save();
        }
    }

    private void CrearHojaMatriz(
        Document doc,
        ExcelWorksheet ws,
        List<RoomAcabadoMYG> rooms,
        List<FilaAcabadoMYG> filas)
    {
        if (rooms == null)
            rooms = new List<RoomAcabadoMYG>();

        if (filas == null)
            filas = new List<FilaAcabadoMYG>();

        int columnasRooms = rooms.Count;
        // El cuadro principal ya no muestra MUROS/SUELOS como agrupador.
        // Solo muestra MODELO DE TIPO + DESCRIPCIÓN DE TIPO.
        int colInicioRooms = 3;
        int colFinal = Math.Max(2 + columnasRooms, 6);

        ws.Cells[1, 1, 1, colFinal].Merge = true;
        ws.Cells[1, 1].Value = "CUADRO DE ACABADOS POR HABITACIÓN";
        ws.Cells[1, 1].Style.Font.Bold = true;
        ws.Cells[1, 1].Style.Font.Size = 14;
        ws.Cells[1, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

        ws.Cells[2, 1].Value = "Proyecto";
        ws.Cells[2, 2, 2, colFinal].Merge = true;
        ws.Cells[2, 2].Value = ObtenerNombreProyecto(doc);

        ws.Cells[3, 1].Value = "Fecha de exportación";
        ws.Cells[3, 2].Value = DateTime.Now.ToString("dd/MM/yyyy HH:mm");

        ws.Cells[4, 1].Value = "Criterio";
        ws.Cells[4, 2, 4, colFinal].Merge = true;
        ws.Cells[4, 2].Value = "Filas: parámetro de TIPO 'Modelo' + parámetro de TIPO 'Descripción' de muros y suelos detectados. Columnas: habitaciones seleccionadas. Marca ✓ cuando existe el acabado en la habitación.";

        int filaUbicacion = 6;
        int filaHeader = 7;

        ws.Cells[filaUbicacion, 1, filaUbicacion, 2].Merge = true;
        ws.Cells[filaUbicacion, 1].Value = "ZONIFICACIÓN";

        ws.Cells[filaHeader, 1].Value = "MODELO DE TIPO";
        ws.Cells[filaHeader, 2].Value = "DESCRIPCIÓN DE TIPO";

        for (int i = 0; i < rooms.Count; i++)
        {
            string ubicacion = "-";

            if (rooms[i] != null && !string.IsNullOrWhiteSpace(rooms[i].ARQUbicacion))
                ubicacion = rooms[i].ARQUbicacion.Trim();

            ws.Cells[filaUbicacion, colInicioRooms + i].Value = ubicacion;

            if (rooms[i] != null)
                ws.Cells[filaHeader, colInicioRooms + i].Value = rooms[i].NombreRoom;
        }

        int filaActual = filaHeader + 1;

        foreach (FilaAcabadoMYG fila in filas)
        {
            if (fila == null)
                continue;

            ws.Cells[filaActual, 1].Value = string.IsNullOrWhiteSpace(fila.ModeloTipo) ? "SIN MODELO" : fila.ModeloTipo;
            ws.Cells[filaActual, 2].Value = fila.DescripcionTipo;

            for (int i = 0; i < rooms.Count; i++)
            {
                RoomAcabadoMYG room = rooms[i];

                if (room == null || room.RoomId == null)
                    continue;

                long roomKey = room.RoomId.Value;

                if (fila.ConteoPorRoom != null && fila.ConteoPorRoom.ContainsKey(roomKey))
                {
                    int cantidad = fila.ConteoPorRoom[roomKey];

                    if (cantidad > 0)
                        ws.Cells[filaActual, colInicioRooms + i].Value = "✓";
                }
            }

            filaActual++;
        }

        int ultimaFila = Math.Max(filaActual - 1, filaHeader);
        int ultimaColumna = Math.Max(2 + rooms.Count, 2);

        AplicarEstiloTitulo(ws, 1, 1, 1, colFinal);
        AplicarEstiloEncabezado(ws, filaUbicacion, 1, filaHeader, ultimaColumna);
        AplicarBordes(ws, filaUbicacion, 1, ultimaFila, ultimaColumna);

        ws.Cells[2, 1, 4, colFinal].Style.WrapText = true;
        ws.Cells[filaUbicacion, 1, ultimaFila, ultimaColumna].Style.WrapText = true;
        ws.Cells[filaUbicacion, colInicioRooms, filaHeader, ultimaColumna].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        ws.Cells[filaUbicacion, colInicioRooms, filaHeader, ultimaColumna].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        ws.Cells[filaHeader + 1, colInicioRooms, ultimaFila, ultimaColumna].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        ws.Cells[filaHeader + 1, colInicioRooms, ultimaFila, ultimaColumna].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        ws.Cells[filaHeader + 1, colInicioRooms, ultimaFila, ultimaColumna].Style.Font.Bold = true;
        ws.Cells[filaHeader + 1, colInicioRooms, ultimaFila, ultimaColumna].Style.Font.Size = 13;

        ws.View.FreezePanes(filaHeader + 1, colInicioRooms);
        ws.Cells.AutoFitColumns();

        ws.Column(1).Width = 28;
        ws.Column(2).Width = 48;

        for (int i = 0; i < rooms.Count; i++)
        {
            ws.Column(colInicioRooms + i).Width = 22;
        }
    }

    private void CrearHojaDetalle(
        ExcelWorksheet ws,
        List<RoomAcabadoMYG> rooms)
    {
        ws.Cells[1, 1].Value = "DETALLE DE ELEMENTOS DETECTADOS";
        ws.Cells[1, 1, 1, 9].Merge = true;
        ws.Cells[1, 1].Style.Font.Bold = true;
        ws.Cells[1, 1].Style.Font.Size = 13;
        ws.Cells[1, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

        int filaHeader = 3;
        ws.Cells[filaHeader, 1].Value = "N°";
        ws.Cells[filaHeader, 2].Value = "ARQ_UBICACIÓN";
        ws.Cells[filaHeader, 3].Value = "ROOM";
        ws.Cells[filaHeader, 4].Value = "CATEGORÍA";
        ws.Cells[filaHeader, 5].Value = "ELEMENT ID";
        ws.Cells[filaHeader, 6].Value = "TIPO";
        ws.Cells[filaHeader, 7].Value = "MODELO DE TIPO";
        ws.Cells[filaHeader, 8].Value = "DESCRIPCIÓN DE TIPO";
        ws.Cells[filaHeader, 9].Value = "CLAVE GENERAL";

        int fila = filaHeader + 1;
        int contador = 1;

        if (rooms != null)
        {
            foreach (RoomAcabadoMYG room in rooms)
            {
                if (room == null || room.Elementos == null)
                    continue;

                foreach (ElementoAcabadoMYG elemento in room.Elementos)
                {
                    if (elemento == null)
                        continue;

                    ws.Cells[fila, 1].Value = contador;
                    ws.Cells[fila, 2].Value = room.ARQUbicacion;
                    ws.Cells[fila, 3].Value = room.NombreRoom;
                    ws.Cells[fila, 4].Value = elemento.Categoria;
                    ws.Cells[fila, 5].Value = elemento.ElementIdValue;
                    ws.Cells[fila, 6].Value = elemento.NombreTipo;
                    ws.Cells[fila, 7].Value = elemento.ModeloTipo;
                    ws.Cells[fila, 8].Value = elemento.DescripcionTipo;
                    ws.Cells[fila, 9].Value = elemento.ClaveFila;

                    fila++;
                    contador++;
                }
            }
        }

        int ultimaFila = Math.Max(fila - 1, filaHeader);

        AplicarEstiloTitulo(ws, 1, 1, 1, 9);
        AplicarEstiloEncabezado(ws, filaHeader, 1, filaHeader, 9);
        AplicarBordes(ws, filaHeader, 1, ultimaFila, 9);

        ws.Cells[filaHeader, 1, ultimaFila, 9].Style.WrapText = true;
        ws.View.FreezePanes(filaHeader + 1, 1);
        ws.Cells.AutoFitColumns();

        ws.Column(2).Width = 22;
        ws.Column(3).Width = 30;
        ws.Column(6).Width = 35;
        ws.Column(7).Width = 30;
        ws.Column(8).Width = 45;
        ws.Column(9).Width = 55;
    }

    private void CrearHojaResumen(
        ExcelWorksheet ws,
        List<RoomAcabadoMYG> rooms,
        List<FilaAcabadoMYG> filas)
    {
        ws.Cells[1, 1].Value = "RESUMEN DE ACABADOS";
        ws.Cells[1, 1, 1, 6].Merge = true;
        ws.Cells[1, 1].Style.Font.Bold = true;
        ws.Cells[1, 1].Style.Font.Size = 13;
        ws.Cells[1, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

        int filaHeader = 3;
        ws.Cells[filaHeader, 1].Value = "N°";
        ws.Cells[filaHeader, 2].Value = "CATEGORÍA";
        ws.Cells[filaHeader, 3].Value = "MODELO DE TIPO";
        ws.Cells[filaHeader, 4].Value = "DESCRIPCIÓN DE TIPO";
        ws.Cells[filaHeader, 5].Value = "ROOMS DONDE APARECE";
        ws.Cells[filaHeader, 6].Value = "TOTAL DETECCIONES";

        int fila = filaHeader + 1;
        int contador = 1;

        foreach (FilaAcabadoMYG item in filas)
        {
            if (item == null)
                continue;

            int roomsDondeAparece = 0;
            int totalDetecciones = 0;

            if (item.ConteoPorRoom != null)
            {
                foreach (int cantidad in item.ConteoPorRoom.Values)
                {
                    if (cantidad > 0)
                        roomsDondeAparece++;

                    totalDetecciones += cantidad;
                }
            }

            ws.Cells[fila, 1].Value = contador;
            ws.Cells[fila, 2].Value = item.Categoria;
            ws.Cells[fila, 3].Value = item.ModeloTipo;
            ws.Cells[fila, 4].Value = item.DescripcionTipo;
            ws.Cells[fila, 5].Value = roomsDondeAparece;
            ws.Cells[fila, 6].Value = totalDetecciones;

            fila++;
            contador++;
        }

        int ultimaFila = Math.Max(fila - 1, filaHeader);

        AplicarEstiloTitulo(ws, 1, 1, 1, 6);
        AplicarEstiloEncabezado(ws, filaHeader, 1, filaHeader, 6);
        AplicarBordes(ws, filaHeader, 1, ultimaFila, 6);

        ws.Cells[filaHeader, 1, ultimaFila, 6].Style.WrapText = true;
        ws.View.FreezePanes(filaHeader + 1, 1);
        ws.Cells.AutoFitColumns();

        ws.Column(3).Width = 32;
        ws.Column(4).Width = 50;
    }

    private void AplicarEstiloTitulo(ExcelWorksheet ws, int f1, int c1, int f2, int c2)
    {
        try
        {
            ExcelRange rango = ws.Cells[f1, c1, f2, c2];
            rango.Style.Fill.PatternType = ExcelFillStyle.Solid;
            rango.Style.Fill.BackgroundColor.SetColor(Drawing.Color.FromArgb(31, 78, 121));
            rango.Style.Font.Color.SetColor(Drawing.Color.White);
            rango.Style.Font.Bold = true;
        }
        catch
        {
        }
    }

    private void AplicarEstiloEncabezado(ExcelWorksheet ws, int f1, int c1, int f2, int c2)
    {
        try
        {
            ExcelRange rango = ws.Cells[f1, c1, f2, c2];
            rango.Style.Fill.PatternType = ExcelFillStyle.Solid;
            rango.Style.Fill.BackgroundColor.SetColor(Drawing.Color.FromArgb(217, 225, 242));
            rango.Style.Font.Bold = true;
            rango.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            rango.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        }
        catch
        {
        }
    }

    private void AplicarBordes(ExcelWorksheet ws, int f1, int c1, int f2, int c2)
    {
        try
        {
            ExcelRange rango = ws.Cells[f1, c1, f2, c2];
            rango.Style.Border.Top.Style = ExcelBorderStyle.Thin;
            rango.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
            rango.Style.Border.Left.Style = ExcelBorderStyle.Thin;
            rango.Style.Border.Right.Style = ExcelBorderStyle.Thin;
            rango.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        }
        catch
        {
        }
    }


    // =========================================================
    // CREAR CUADRO EN LEYENDA DESDE EL EXCEL YA EXPORTADO
    // =========================================================

    private void CrearCuadroAcabadosEnLeyenda()
    {
        Document doc = UiDoc.Document;

        if (doc == null)
            return;

        string rutaExcel = "";

        try
        {
            rutaExcel = Form.RutaExcelActual;
        }
        catch
        {
            rutaExcel = "";
        }

        if (string.IsNullOrWhiteSpace(rutaExcel))
        {
            MostrarEnVentana("Debe indicar la ruta del Excel para crear el cuadro en la leyenda.");
            return;
        }

        if (!File.Exists(rutaExcel))
        {
            MostrarEnVentana("No existe el Excel indicado en la ruta.");
            return;
        }

        ElementId leyendaId = ElementId.InvalidElementId;

        try
        {
            leyendaId = Form.LeyendaSeleccionadaId;
        }
        catch
        {
            leyendaId = ElementId.InvalidElementId;
        }

        if (leyendaId == ElementId.InvalidElementId)
        {
            MostrarEnVentana("Debe seleccionar una leyenda.");
            return;
        }

        Autodesk.Revit.DB.View leyenda = doc.GetElement(leyendaId) as Autodesk.Revit.DB.View;

        if (leyenda == null || leyenda.ViewType != ViewType.Legend)
        {
            MostrarEnVentana("La vista seleccionada no es una leyenda válida.");
            return;
        }

        int escalaCuadro = ObtenerEscalaCuadroDesdeFormulario(leyenda);

        if (escalaCuadro <= 0)
            escalaCuadro = 1;

        CuadroExcelAcabadosMYG datos = LeerCuadroAcabadosDesdeExcel(rutaExcel);

        if (datos == null || datos.Ambientes == null || datos.Ambientes.Count == 0 ||
            datos.Acabados == null || datos.Acabados.Count == 0)
        {
            MostrarEnVentana("No se pudo leer una matriz válida desde el Excel.");
            return;
        }

        // Asegura que los modelos iguales se agrupen juntos en la leyenda,
        // incluso si el Excel fue generado con una versión anterior que separaba
        // MUROS/SUELOS o repetía "SIN MODELO" en bloques distintos.
        OrdenarYConsolidarAcabadosPorModelo(datos);

        int elementosCreados = 0;

        using (Transaction tx = new Transaction(doc, "MYG - Crear cuadro de acabados en leyenda"))
        {
            tx.Start();

            elementosCreados = DibujarCuadroAcabadosConLineasDetalle(
                doc,
                leyenda,
                datos,
                escalaCuadro);

            tx.Commit();
        }

        MostrarEnVentana(
            "Cuadro creado en leyenda: " + leyenda.Name +
            " | Escala de referencia: 1:" + escalaCuadro.ToString() +
            " | Ambientes: " + datos.Ambientes.Count.ToString() +
            " | Acabados: " + datos.Acabados.Count.ToString() +
            " | Elementos dibujados: " + elementosCreados.ToString());
    }

    private int ObtenerEscalaCuadroDesdeFormulario(Autodesk.Revit.DB.View leyenda)
    {
        int escala = 1;

        try
        {
            if (Form != null && Form.UsarEscalaDeLeyenda && leyenda != null && leyenda.Scale > 0)
                return leyenda.Scale;
        }
        catch
        {
        }

        try
        {
            if (Form != null && Form.EscalaCuadroSeleccionada > 0)
                escala = Form.EscalaCuadroSeleccionada;
        }
        catch
        {
            escala = 1;
        }

        if (escala <= 0)
            escala = 1;

        return escala;
    }

    private CuadroExcelAcabadosMYG LeerCuadroAcabadosDesdeExcel(string rutaExcel)
    {
        if (string.IsNullOrWhiteSpace(rutaExcel) || !File.Exists(rutaExcel))
            return null;

        ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;

        FileInfo archivo = new FileInfo(rutaExcel);

        using (ExcelPackage package = new ExcelPackage(archivo))
        {
            ExcelWorksheet ws = null;

            foreach (ExcelWorksheet hoja in package.Workbook.Worksheets)
            {
                if (hoja == null)
                    continue;

                if (NormalizarClave(hoja.Name) == NormalizarClave("CUADRO DE ACABADOS"))
                {
                    ws = hoja;
                    break;
                }
            }

            if (ws == null)
            {
                foreach (ExcelWorksheet hoja in package.Workbook.Worksheets)
                {
                    if (hoja != null)
                    {
                        ws = hoja;
                        break;
                    }
                }
            }

            if (ws == null || ws.Dimension == null)
                return null;

            int filaHeader = EncontrarFilaEncabezadoMatriz(ws);

            if (filaHeader <= 0)
                return null;

            int filaZonificacion = -1;
            string celdaAnterior = ObtenerTextoCelda(ws, filaHeader - 1, 1);

            if (NormalizarClave(celdaAnterior).Contains("ZONIFICACION") ||
                NormalizarClave(celdaAnterior).Contains("ARQ_UBICACION") ||
                NormalizarClave(celdaAnterior).Contains("ARQ UBICACION"))
            {
                filaZonificacion = filaHeader - 1;
            }

            string headerCol1 = NormalizarClave(ObtenerTextoCelda(ws, filaHeader, 1));
            string headerCol2 = NormalizarClave(ObtenerTextoCelda(ws, filaHeader, 2));
            string headerCol3 = NormalizarClave(ObtenerTextoCelda(ws, filaHeader, 3));

            // Soporta 3 formatos:
            // 1) NUEVO: MODELO DE TIPO | DESCRIPCIÓN DE TIPO | Ambientes...
            // 2) ANTERIOR: CATEGORÍA | MODELO DE TIPO | DESCRIPCIÓN DE TIPO | Ambientes...
            // 3) ANTIGUO: CATEGORÍA | DESCRIPCIÓN DE TIPO | Ambientes...
            bool formatoSoloModelo = headerCol1.Contains("MODELO") &&
                (headerCol2.Contains("DESCRIPCION") || headerCol2.Contains("ACABADOS"));

            bool formatoCategoriaModelo = headerCol2.Contains("MODELO") &&
                (headerCol3.Contains("DESCRIPCION") || headerCol3.Contains("ACABADOS"));

            int colInicioAmbientes = formatoCategoriaModelo ? 4 : 3;

            int ultimaColumna = ws.Dimension.End.Column;
            int ultimaFila = ws.Dimension.End.Row;

            CuadroExcelAcabadosMYG datos = new CuadroExcelAcabadosMYG();
            datos.Titulo = ObtenerTextoCelda(ws, 1, 1);
            datos.Ambientes = new List<AmbienteExcelAcabadoMYG>();
            datos.Acabados = new List<AcabadoExcelMYG>();
            datos.Marcas = new Dictionary<string, bool>();

            for (int col = colInicioAmbientes; col <= ultimaColumna; col++)
            {
                string ambiente = ObtenerTextoCelda(ws, filaHeader, col);

                if (string.IsNullOrWhiteSpace(ambiente))
                    continue;

                AmbienteExcelAcabadoMYG itemAmbiente = new AmbienteExcelAcabadoMYG();
                itemAmbiente.ColumnaExcel = col;
                itemAmbiente.Nombre = LimpiarNombreAmbienteSinNumeroHabitacion(ambiente.Trim(), (col - colInicioAmbientes + 1).ToString());
                itemAmbiente.Zona = "-";

                if (filaZonificacion > 0)
                {
                    string zona = ObtenerTextoCelda(ws, filaZonificacion, col);

                    if (!string.IsNullOrWhiteSpace(zona))
                        itemAmbiente.Zona = zona.Trim();
                }

                datos.Ambientes.Add(itemAmbiente);
            }

            if (datos.Ambientes.Count == 0)
                return datos;

            int indiceAcabado = 0;

            for (int fila = filaHeader + 1; fila <= ultimaFila; fila++)
            {
                string categoria = "ACABADOS";
                string modeloTipo = "SIN MODELO";
                string descripcion = "";

                if (formatoCategoriaModelo)
                {
                    categoria = ObtenerTextoCelda(ws, fila, 1);
                    modeloTipo = ObtenerTextoCelda(ws, fila, 2);
                    descripcion = ObtenerTextoCelda(ws, fila, 3);
                }
                else if (formatoSoloModelo)
                {
                    modeloTipo = ObtenerTextoCelda(ws, fila, 1);
                    descripcion = ObtenerTextoCelda(ws, fila, 2);
                }
                else
                {
                    categoria = ObtenerTextoCelda(ws, fila, 1);
                    descripcion = ObtenerTextoCelda(ws, fila, 2);
                }

                if (string.IsNullOrWhiteSpace(categoria) &&
                    string.IsNullOrWhiteSpace(modeloTipo) &&
                    string.IsNullOrWhiteSpace(descripcion))
                {
                    continue;
                }

                if (string.IsNullOrWhiteSpace(modeloTipo))
                    modeloTipo = "SIN MODELO";

                if (string.IsNullOrWhiteSpace(descripcion))
                    descripcion = modeloTipo;

                AcabadoExcelMYG acabado = new AcabadoExcelMYG();
                acabado.FilaExcel = fila;
                acabado.Categoria = string.IsNullOrWhiteSpace(categoria) ? "ACABADOS" : categoria.Trim();
                acabado.ModeloTipo = modeloTipo.Trim();
                acabado.Descripcion = descripcion.Trim();

                datos.Acabados.Add(acabado);

                for (int i = 0; i < datos.Ambientes.Count; i++)
                {
                    AmbienteExcelAcabadoMYG ambiente = datos.Ambientes[i];

                    if (ambiente == null)
                        continue;

                    string marca = ObtenerTextoCelda(ws, fila, ambiente.ColumnaExcel);

                    if (!string.IsNullOrWhiteSpace(marca))
                    {
                        string clave = ObtenerClaveMarca(i, indiceAcabado);

                        if (!datos.Marcas.ContainsKey(clave))
                            datos.Marcas.Add(clave, true);
                    }
                }

                indiceAcabado++;
            }

            return datos;
        }
    }

    private int EncontrarFilaEncabezadoMatriz(ExcelWorksheet ws)
    {
        if (ws == null || ws.Dimension == null)
            return -1;

        int maxFila = Math.Min(ws.Dimension.End.Row, 40);

        for (int fila = 1; fila <= maxFila; fila++)
        {
            string c1 = NormalizarClave(ObtenerTextoCelda(ws, fila, 1));
            string c2 = NormalizarClave(ObtenerTextoCelda(ws, fila, 2));
            string c3 = NormalizarClave(ObtenerTextoCelda(ws, fila, 3));

            bool esCategoria = c1.Contains("CATEGORIA") || c1.Contains("PARTIDAS");
            bool esModeloEnC1 = c1.Contains("MODELO");
            bool esModeloEnC2 = c2.Contains("MODELO");
            bool esDescripcionEnC2 = c2.Contains("DESCRIPCION") || c2.Contains("ACABADOS");
            bool esDescripcionEnC3 = c3.Contains("DESCRIPCION") || c3.Contains("ACABADOS");

            // Nuevo: MODELO DE TIPO | DESCRIPCIÓN DE TIPO
            if (esModeloEnC1 && esDescripcionEnC2)
                return fila;

            // Anteriores: CATEGORÍA | MODELO | DESCRIPCIÓN  o  CATEGORÍA | DESCRIPCIÓN
            if (esCategoria && ((esModeloEnC2 && esDescripcionEnC3) || esDescripcionEnC2))
                return fila;
        }

        return -1;
    }

    private string ObtenerTextoCelda(ExcelWorksheet ws, int fila, int columna)
    {
        if (ws == null || fila <= 0 || columna <= 0)
            return "";

        try
        {
            object valor = ws.Cells[fila, columna].Value;

            if (valor == null)
                return "";

            return valor.ToString().Trim();
        }
        catch
        {
            return "";
        }
    }

    private string ObtenerClaveMarca(int indiceAmbiente, int indiceAcabado)
    {
        return indiceAmbiente.ToString() + "|" + indiceAcabado.ToString();
    }

    private void OrdenarYConsolidarAcabadosPorModelo(CuadroExcelAcabadosMYG datos)
    {
        if (datos == null || datos.Acabados == null || datos.Acabados.Count == 0)
            return;

        if (datos.Marcas == null)
            datos.Marcas = new Dictionary<string, bool>();

        List<int> indicesOrdenados = new List<int>();

        for (int i = 0; i < datos.Acabados.Count; i++)
            indicesOrdenados.Add(i);

        indicesOrdenados.Sort(delegate (int ia, int ib)
        {
            AcabadoExcelMYG a = datos.Acabados[ia];
            AcabadoExcelMYG b = datos.Acabados[ib];

            string ma = a == null ? "SIN MODELO" : NormalizarTextoModelo(a.ModeloTipo);
            string mb = b == null ? "SIN MODELO" : NormalizarTextoModelo(b.ModeloTipo);

            int c = string.Compare(ma, mb, StringComparison.CurrentCultureIgnoreCase);

            if (c != 0)
                return c;

            string da = a == null ? "" : (a.Descripcion ?? "");
            string db = b == null ? "" : (b.Descripcion ?? "");

            return string.Compare(da, db, StringComparison.CurrentCultureIgnoreCase);
        });

        List<AcabadoExcelMYG> nuevosAcabados = new List<AcabadoExcelMYG>();
        Dictionary<string, int> indiceNuevoPorClave = new Dictionary<string, int>();
        Dictionary<string, bool> nuevasMarcas = new Dictionary<string, bool>();

        foreach (int indiceOriginal in indicesOrdenados)
        {
            if (indiceOriginal < 0 || indiceOriginal >= datos.Acabados.Count)
                continue;

            AcabadoExcelMYG acabadoOriginal = datos.Acabados[indiceOriginal];

            if (acabadoOriginal == null)
                continue;

            string modelo = NormalizarTextoModelo(acabadoOriginal.ModeloTipo);
            string descripcion = acabadoOriginal.Descripcion == null ? "" : acabadoOriginal.Descripcion.Trim();

            if (string.IsNullOrWhiteSpace(descripcion))
                descripcion = modelo;

            string clave = NormalizarClave(modelo) + "|" + NormalizarClave(descripcion);
            int indiceNuevo = -1;

            if (indiceNuevoPorClave.ContainsKey(clave))
            {
                indiceNuevo = indiceNuevoPorClave[clave];
            }
            else
            {
                AcabadoExcelMYG nuevo = new AcabadoExcelMYG();
                nuevo.FilaExcel = acabadoOriginal.FilaExcel;
                nuevo.Categoria = "ACABADOS";
                nuevo.ModeloTipo = modelo;
                nuevo.Descripcion = descripcion;

                nuevosAcabados.Add(nuevo);
                indiceNuevo = nuevosAcabados.Count - 1;
                indiceNuevoPorClave.Add(clave, indiceNuevo);
            }

            if (datos.Ambientes == null)
                continue;

            for (int iAmbiente = 0; iAmbiente < datos.Ambientes.Count; iAmbiente++)
            {
                string claveMarcaOriginal = ObtenerClaveMarca(iAmbiente, indiceOriginal);

                if (!datos.Marcas.ContainsKey(claveMarcaOriginal))
                    continue;

                string claveMarcaNueva = ObtenerClaveMarca(iAmbiente, indiceNuevo);

                if (!nuevasMarcas.ContainsKey(claveMarcaNueva))
                    nuevasMarcas.Add(claveMarcaNueva, true);
            }
        }

        datos.Acabados = nuevosAcabados;
        datos.Marcas = nuevasMarcas;
    }

    private bool ExisteMarca(CuadroExcelAcabadosMYG datos, int indiceAmbiente, int indiceAcabado)
    {
        if (datos == null || datos.Marcas == null)
            return false;

        string clave = ObtenerClaveMarca(indiceAmbiente, indiceAcabado);
        return datos.Marcas.ContainsKey(clave);
    }

    private double CalcularAltoModeloDesdeTextos(CuadroExcelAcabadosMYG datos, double mm)
    {
        if (mm <= 0.0)
            return 24.0 / 304.8;

        int longitudMayor = 0;
        HashSet<string> modelosProcesados = new HashSet<string>();

        if (datos != null && datos.Acabados != null)
        {
            foreach (AcabadoExcelMYG acabado in datos.Acabados)
            {
                if (acabado == null)
                    continue;

                string modelo = NormalizarTextoModelo(acabado.ModeloTipo);
                string clave = NormalizarClave(modelo);

                if (modelosProcesados.Contains(clave))
                    continue;

                modelosProcesados.Add(clave);

                int longitud = ObtenerLongitudVisibleTexto(modelo);

                if (longitud > longitudMayor)
                    longitudMayor = longitud;
            }
        }

        // Fórmula práctica en milímetros de papel:
        // base 10 mm + 3.20 mm por carácter visible.
        // Así textos como CONTRAZOCALO o SIN MODELO no salen del rango.
        double altoModeloMm = 10.0 + (longitudMayor * 3.20);

        if (altoModeloMm < 24.0)
            altoModeloMm = 24.0;

        if (altoModeloMm > 120.0)
            altoModeloMm = 120.0;

        return altoModeloMm * mm;
    }

    private int ObtenerLongitudVisibleTexto(string texto)
    {
        if (string.IsNullOrWhiteSpace(texto))
            return 0;

        int contador = 0;

        for (int i = 0; i < texto.Length; i++)
        {
            char c = texto[i];

            if (char.IsWhiteSpace(c))
                continue;

            contador++;
        }

        return contador;
    }

    private int DibujarCuadroAcabadosConLineasDetalle(
        Document doc,
        Autodesk.Revit.DB.View vista,
        CuadroExcelAcabadosMYG datos,
        int escalaCuadro)
    {
        if (doc == null || vista == null || datos == null)
            return 0;

        int contador = 0;

        if (escalaCuadro <= 0)
            escalaCuadro = 1;

        double mm = (double)escalaCuadro / 304.8;

        double x0 = 0.0;
        double y0 = 0.0;

        double anchoZona = 24.0 * mm;
        double anchoAmbiente = 52.0 * mm;
        double anchoAcabado = 9.0 * mm;
        // Ya no se dibuja la fila superior de CATEGORÍA (MUROS/SUELOS).
        // El encabezado superior agrupa directamente por MODELO DE TIPO.
        double altoCategoria = 0.0;

        // ALTURA DE LA FILA DE MODELO DE TIPO.
        // Se calcula según el texto de MODELO más largo para que no sobresalga
        // cuando se coloca en vertical. No se cambia el ancho de las columnas.
        double altoModelo = CalcularAltoModeloDesdeTextos(datos, mm);

        // Se conserva la altura útil para las descripciones verticales.
        double altoCabeceraDescripcion = 64.0 * mm;
        double altoCabecera = altoModelo + altoCabeceraDescripcion;

        double altoFila = 8.0 * mm;
        double margenTitulo = 18.0 * mm;

        int cantidadAmbientes = datos.Ambientes.Count;
        int cantidadAcabados = datos.Acabados.Count;

        double xAmbiente = x0 + anchoZona;
        double xAcabados = x0 + anchoZona + anchoAmbiente;
        double xFinal = xAcabados + cantidadAcabados * anchoAcabado;

        double yTablaSuperior = y0;
        double yCategoriaInferior = yTablaSuperior - altoCategoria;
        double yModeloInferior = yCategoriaInferior - altoModelo;
        double yFilasSuperior = yTablaSuperior - altoCabecera;
        double yFinal = yFilasSuperior - cantidadAmbientes * altoFila;

        string titulo = "CUADRO DE ACABADOS";

        if (!string.IsNullOrWhiteSpace(datos.Titulo))
            titulo = datos.Titulo.Trim();

        // Relleno de títulos por MODELO DE TIPO.
        int inicioModeloRelleno = 0;

        while (inicioModeloRelleno < cantidadAcabados)
        {
            string modeloRelleno = datos.Acabados[inicioModeloRelleno] == null ? "SIN MODELO" : NormalizarTextoModelo(datos.Acabados[inicioModeloRelleno].ModeloTipo);
            int finModeloRelleno = inicioModeloRelleno;

            while (finModeloRelleno + 1 < cantidadAcabados)
            {
                string modeloSiguiente = datos.Acabados[finModeloRelleno + 1] == null ? "SIN MODELO" : NormalizarTextoModelo(datos.Acabados[finModeloRelleno + 1].ModeloTipo);

                if (NormalizarClave(modeloSiguiente) != NormalizarClave(modeloRelleno))
                {
                    break;
                }

                finModeloRelleno++;
            }

            double xInicioRelleno = xAcabados + inicioModeloRelleno * anchoAcabado;
            double xFinRelleno = xAcabados + (finModeloRelleno + 1) * anchoAcabado;

            contador += CrearRellenoTituloDetalle(doc, vista, xInicioRelleno, yCategoriaInferior, xFinRelleno, yModeloInferior);

            inicioModeloRelleno = finModeloRelleno + 1;
        }

        // Relleno de celdas de zonas.
        int inicioZonaRelleno = 0;

        while (inicioZonaRelleno < cantidadAmbientes)
        {
            string zonaRelleno = datos.Ambientes[inicioZonaRelleno] == null ? "-" : datos.Ambientes[inicioZonaRelleno].Zona;
            int finZonaRelleno = inicioZonaRelleno;

            while (finZonaRelleno + 1 < cantidadAmbientes)
            {
                string zonaSiguienteRelleno = datos.Ambientes[finZonaRelleno + 1] == null ? "-" : datos.Ambientes[finZonaRelleno + 1].Zona;

                if (NormalizarClave(zonaSiguienteRelleno) != NormalizarClave(zonaRelleno))
                    break;

                finZonaRelleno++;
            }

            double ySupZonaRelleno = yFilasSuperior - inicioZonaRelleno * altoFila;
            double yInfZonaRelleno = yFilasSuperior - (finZonaRelleno + 1) * altoFila;

            contador += CrearRellenoTituloDetalle(doc, vista, x0, ySupZonaRelleno, xAmbiente, yInfZonaRelleno);

            inicioZonaRelleno = finZonaRelleno + 1;
        }

        contador += CrearTextoDetalle(
            doc,
            vista,
            (x0 + xFinal) / 2.0,
            yTablaSuperior + margenTitulo,
            xFinal - x0,
            titulo,
            0.0,
            HorizontalTextAlignment.Center,
            VerticalTextAlignment.Middle,
            true);

        // Marco principal.
        contador += CrearLineaDetalle(doc, vista, x0, yTablaSuperior, xFinal, yTablaSuperior);
        contador += CrearLineaDetalle(doc, vista, x0, yFinal, xFinal, yFinal);
        contador += CrearLineaDetalle(doc, vista, x0, yTablaSuperior, x0, yFinal);
        contador += CrearLineaDetalle(doc, vista, xFinal, yTablaSuperior, xFinal, yFinal);

        // Líneas principales de cabecera.
        contador += CrearLineaDetalle(doc, vista, x0, yFilasSuperior, xFinal, yFilasSuperior);
        contador += CrearLineaDetalle(doc, vista, xAcabados, yTablaSuperior, xAcabados, yFinal);
        contador += CrearLineaDetalle(doc, vista, xAmbiente, yTablaSuperior, xAmbiente, yFinal);
        contador += CrearLineaDetalle(doc, vista, xAcabados, yCategoriaInferior, xFinal, yCategoriaInferior);
        contador += CrearLineaDetalle(doc, vista, xAcabados, yModeloInferior, xFinal, yModeloInferior);

        // Línea diagonal del bloque ambientes/acabados.
        contador += CrearLineaDetalle(doc, vista, xAmbiente, yModeloInferior, xAcabados, yFilasSuperior);

        contador += CrearTextoDetalle(
            doc,
            vista,
            x0 + anchoZona / 2.0,
            (yTablaSuperior + yFilasSuperior) / 2.0,
            altoCabecera,
            "ZONAS",
            Math.PI / 2.0,
            HorizontalTextAlignment.Center,
            VerticalTextAlignment.Middle,
            true);

        contador += CrearTextoDetalle(
            doc,
            vista,
            xAmbiente + anchoAmbiente * 0.35,
            yFilasSuperior + altoCabecera * 0.23,
            anchoAmbiente * 0.70,
            "AMBIENTES",
            0.0,
            HorizontalTextAlignment.Center,
            VerticalTextAlignment.Middle,
            true);

        contador += CrearTextoDetalle(
            doc,
            vista,
            xAmbiente + anchoAmbiente * 0.62,
            yTablaSuperior - altoCabecera * 0.28,
            anchoAmbiente * 0.70,
            "ACABADOS",
            0.0,
            HorizontalTextAlignment.Center,
            VerticalTextAlignment.Middle,
            true);

        // Agrupar cabeceras por MODELO DE TIPO.
        int inicioModelo = 0;

        while (inicioModelo < cantidadAcabados)
        {
            string modeloTipo = datos.Acabados[inicioModelo] == null ? "SIN MODELO" : NormalizarTextoModelo(datos.Acabados[inicioModelo].ModeloTipo);
            int finModelo = inicioModelo;

            while (finModelo + 1 < cantidadAcabados)
            {
                string modeloSiguiente = datos.Acabados[finModelo + 1] == null ? "SIN MODELO" : NormalizarTextoModelo(datos.Acabados[finModelo + 1].ModeloTipo);

                if (NormalizarClave(modeloSiguiente) != NormalizarClave(modeloTipo))
                {
                    break;
                }

                finModelo++;
            }

            double xInicio = xAcabados + inicioModelo * anchoAcabado;
            double xFin = xAcabados + (finModelo + 1) * anchoAcabado;

            contador += CrearLineaDetalle(doc, vista, xInicio, yCategoriaInferior, xInicio, yFilasSuperior);
            contador += CrearLineaDetalle(doc, vista, xFin, yCategoriaInferior, xFin, yFilasSuperior);

            contador += CrearTextoDetalle(
                doc,
                vista,
                (xInicio + xFin) / 2.0,
                yCategoriaInferior - altoModelo / 2.0,
                altoModelo - (2.0 * mm),
                modeloTipo,
                Math.PI / 2.0,
                HorizontalTextAlignment.Center,
                VerticalTextAlignment.Middle,
                true);

            inicioModelo = finModelo + 1;
        }

        // Columnas de acabados y textos verticales.
        for (int j = 0; j < cantidadAcabados; j++)
        {
            double x = xAcabados + j * anchoAcabado;
            double xCentro = x + anchoAcabado / 2.0;

            contador += CrearLineaDetalle(doc, vista, x, yModeloInferior, x, yFinal);

            string descripcion = "";

            if (datos.Acabados[j] != null)
                descripcion = datos.Acabados[j].Descripcion;

            contador += CrearTextoDetalle(
                doc,
                vista,
                xCentro,
                (yModeloInferior + yFilasSuperior) / 2.0,
                altoCabecera - altoCategoria - altoModelo - (4.0 * mm),
                descripcion,
                Math.PI / 2.0,
                HorizontalTextAlignment.Center,
                VerticalTextAlignment.Middle);
        }

        contador += CrearLineaDetalle(doc, vista, xFinal, yModeloInferior, xFinal, yFinal);

        // Filas de ambientes. No atraviesan la columna de ZONAS cuando hay grupos combinados.
        for (int i = 0; i <= cantidadAmbientes; i++)
        {
            double y = yFilasSuperior - i * altoFila;
            contador += CrearLineaDetalle(doc, vista, xAmbiente, y, xFinal, y);
        }

        // Ambientes, zonas y marcas.
        int indiceInicioZona = 0;

        while (indiceInicioZona < cantidadAmbientes)
        {
            string zona = datos.Ambientes[indiceInicioZona] == null ? "-" : datos.Ambientes[indiceInicioZona].Zona;
            int indiceFinZona = indiceInicioZona;

            while (indiceFinZona + 1 < cantidadAmbientes)
            {
                string zonaSig = datos.Ambientes[indiceFinZona + 1] == null ? "-" : datos.Ambientes[indiceFinZona + 1].Zona;

                if (NormalizarClave(zonaSig) != NormalizarClave(zona))
                    break;

                indiceFinZona++;
            }

            double ySupZona = yFilasSuperior - indiceInicioZona * altoFila;
            double yInfZona = yFilasSuperior - (indiceFinZona + 1) * altoFila;

            contador += CrearLineaDetalle(doc, vista, x0, ySupZona, xAmbiente, ySupZona);
            contador += CrearLineaDetalle(doc, vista, x0, yInfZona, xAmbiente, yInfZona);

            contador += CrearTextoDetalle(
                doc,
                vista,
                x0 + anchoZona / 2.0,
                (ySupZona + yInfZona) / 2.0,
                anchoZona - (2.0 * mm),
                zona,
                0.0,
                HorizontalTextAlignment.Center,
                VerticalTextAlignment.Middle,
                true);

            indiceInicioZona = indiceFinZona + 1;
        }

        for (int i = 0; i < cantidadAmbientes; i++)
        {
            AmbienteExcelAcabadoMYG ambiente = datos.Ambientes[i];

            if (ambiente == null)
                continue;

            double ySup = yFilasSuperior - i * altoFila;
            double yInf = ySup - altoFila;
            double yCentro = (ySup + yInf) / 2.0;

            contador += CrearTextoDetalle(
                doc,
                vista,
                xAmbiente + (2.0 * mm),
                yCentro,
                anchoAmbiente - (4.0 * mm),
                ambiente.Nombre,
                0.0,
                HorizontalTextAlignment.Left,
                VerticalTextAlignment.Middle);

            for (int j = 0; j < cantidadAcabados; j++)
            {
                if (!ExisteMarca(datos, i, j))
                    continue;

                double xCentro = xAcabados + j * anchoAcabado + anchoAcabado / 2.0;
                contador += CrearPuntoRellenoDetalle(doc, vista, xCentro, yCentro, 1.55 * mm);
            }
        }

        return contador;
    }

    private int CrearLineaDetalle(
        Document doc,
        Autodesk.Revit.DB.View vista,
        double x1,
        double y1,
        double x2,
        double y2)
    {
        if (doc == null || vista == null)
            return 0;

        XYZ p1 = new XYZ(x1, y1, 0.0);
        XYZ p2 = new XYZ(x2, y2, 0.0);

        if (p1.DistanceTo(p2) < 0.00001)
            return 0;

        try
        {
            Line linea = Line.CreateBound(p1, p2);
            doc.Create.NewDetailCurve(vista, linea);
            return 1;
        }
        catch
        {
            return 0;
        }
    }

    private int CrearCirculoDetalleConLineas(
        Document doc,
        Autodesk.Revit.DB.View vista,
        double xCentro,
        double yCentro,
        double radio)
    {
        int contador = 0;
        int segmentos = 16;

        for (int i = 0; i < segmentos; i++)
        {
            double a1 = (Math.PI * 2.0) * ((double)i / (double)segmentos);
            double a2 = (Math.PI * 2.0) * ((double)(i + 1) / (double)segmentos);

            double x1 = xCentro + Math.Cos(a1) * radio;
            double y1 = yCentro + Math.Sin(a1) * radio;
            double x2 = xCentro + Math.Cos(a2) * radio;
            double y2 = yCentro + Math.Sin(a2) * radio;

            contador += CrearLineaDetalle(doc, vista, x1, y1, x2, y2);
        }

        return contador;
    }

    private int CrearPuntoRellenoDetalle(
        Document doc,
        Autodesk.Revit.DB.View vista,
        double xCentro,
        double yCentro,
        double radio)
    {
        if (doc == null || vista == null)
            return 0;

        if (radio <= 0.000001)
            return 0;

        try
        {
            ElementId tipoRegionId = ObtenerOCrearTipoRegionPuntoAzulMYG(doc);

            if (tipoRegionId == ElementId.InvalidElementId)
                return CrearCirculoDetalleConLineas(doc, vista, xCentro, yCentro, radio);

            int segmentos = 32;
            CurveLoop loop = new CurveLoop();

            XYZ puntoInicial = null;
            XYZ puntoAnterior = null;

            for (int i = 0; i <= segmentos; i++)
            {
                double angulo = (Math.PI * 2.0) * ((double)i / (double)segmentos);

                XYZ punto = new XYZ(
                    xCentro + Math.Cos(angulo) * radio,
                    yCentro + Math.Sin(angulo) * radio,
                    0.0);

                if (i == 0)
                {
                    puntoInicial = punto;
                    puntoAnterior = punto;
                    continue;
                }

                if (puntoAnterior != null && puntoAnterior.DistanceTo(punto) > 0.000001)
                    loop.Append(Line.CreateBound(puntoAnterior, punto));

                puntoAnterior = punto;
            }

            if (puntoAnterior != null && puntoInicial != null && puntoAnterior.DistanceTo(puntoInicial) > 0.000001)
                loop.Append(Line.CreateBound(puntoAnterior, puntoInicial));

            IList<CurveLoop> loops = new List<CurveLoop>();
            loops.Add(loop);

            FilledRegion.Create(doc, tipoRegionId, vista.Id, loops);
            return 1;
        }
        catch
        {
            return CrearCirculoDetalleConLineas(doc, vista, xCentro, yCentro, radio);
        }
    }

    private int CrearTextoDetalle(
        Document doc,
        Autodesk.Revit.DB.View vista,
        double x,
        double y,
        double ancho,
        string texto,
        double rotacion,
        HorizontalTextAlignment alineacionHorizontal,
        VerticalTextAlignment alineacionVertical,
        bool esTitulo = false)
    {
        if (doc == null || vista == null)
            return 0;

        if (string.IsNullOrWhiteSpace(texto))
            return 0;

        ElementId tipoTextoId = ObtenerTipoTextoDetalle(doc, esTitulo);

        if (tipoTextoId == ElementId.InvalidElementId)
            return 0;

        // CORRECCIÓN PUNTUAL:
        // Antes se usaba TextNote.Create(..., ancho, texto, ...).
        // Ese ancho funciona visualmente, pero en leyendas con escala 1:50, 1:100, etc.
        // genera una caja/rango de selección demasiado grande.
        // Para este cuadro no necesitamos caja de ajuste, porque todos los textos se
        // ubican por coordenada y rotación. Por eso se crea primero como texto simple
        // SIN ancho fijo, conservando la misma rotación y alineación.
        try
        {
            TextNoteOptions opcionesSimple = new TextNoteOptions(tipoTextoId);
            opcionesSimple.HorizontalAlignment = alineacionHorizontal;
            opcionesSimple.VerticalAlignment = alineacionVertical;
            opcionesSimple.Rotation = rotacion;

            TextNote.Create(
                doc,
                vista.Id,
                new XYZ(x, y, 0.0),
                texto,
                opcionesSimple);

            return 1;
        }
        catch
        {
            try
            {
                if (ancho < (2.0 / 304.8))
                    ancho = 2.0 / 304.8;

                TextNoteOptions opcionesConAncho = new TextNoteOptions(tipoTextoId);
                opcionesConAncho.HorizontalAlignment = alineacionHorizontal;
                opcionesConAncho.VerticalAlignment = alineacionVertical;
                opcionesConAncho.Rotation = rotacion;

                TextNote.Create(
                    doc,
                    vista.Id,
                    new XYZ(x, y, 0.0),
                    ancho,
                    texto,
                    opcionesConAncho);

                return 1;
            }
            catch
            {
                return 0;
            }
        }
    }

    private ElementId ObtenerTipoTextoDetalle(Document doc, bool esTitulo)
    {
        if (doc == null)
            return ElementId.InvalidElementId;

        if (esTitulo)
            return ObtenerOCrearTipoTextoMYG(
                doc,
                "MYG_ARIAL_NARROW_TITULO_AZUL_0064",
                true,
                0,
                0,
                64);

        return ObtenerOCrearTipoTextoMYG(
            doc,
            "MYG_ARIAL_NARROW_GENERAL_NEGRO",
            false,
            0,
            0,
            0);
    }

    private ElementId ObtenerOCrearTipoTextoMYG(
        Document doc,
        string nombreTipo,
        bool negrita,
        byte rojo,
        byte verde,
        byte azul)
    {
        if (doc == null || string.IsNullOrWhiteSpace(nombreTipo))
            return ElementId.InvalidElementId;

        try
        {
            TextNoteType existente = new FilteredElementCollector(doc)
                .OfClass(typeof(TextNoteType))
                .Cast<TextNoteType>()
                .FirstOrDefault(x => x != null && x.Name == nombreTipo);

            if (existente != null)
            {
                ConfigurarTipoTextoMYG(existente, negrita, rojo, verde, azul);
                return existente.Id;
            }

            TextNoteType baseTipo = new FilteredElementCollector(doc)
                .OfClass(typeof(TextNoteType))
                .Cast<TextNoteType>()
                .FirstOrDefault();

            if (baseTipo == null)
                return ElementId.InvalidElementId;

            TextNoteType nuevo = baseTipo.Duplicate(nombreTipo) as TextNoteType;

            if (nuevo == null)
                return baseTipo.Id;

            ConfigurarTipoTextoMYG(nuevo, negrita, rojo, verde, azul);

            return nuevo.Id;
        }
        catch
        {
            try
            {
                ElementId id = new FilteredElementCollector(doc)
                    .OfClass(typeof(TextNoteType))
                    .FirstElementId();

                if (id != null)
                    return id;
            }
            catch
            {
            }
        }

        return ElementId.InvalidElementId;
    }

    private void ConfigurarTipoTextoMYG(
        TextNoteType tipo,
        bool negrita,
        byte rojo,
        byte verde,
        byte azul)
    {
        if (tipo == null)
            return;

        // Fuente: Arial Narrow.
        try
        {
            Parameter pFuente = tipo.get_Parameter(BuiltInParameter.TEXT_FONT);

            if (pFuente != null && !pFuente.IsReadOnly)
                pFuente.Set("Arial Narrow");
        }
        catch
        {
        }

        // Negrita solo para títulos.
        try
        {
            Parameter pNegrita = tipo.get_Parameter(BuiltInParameter.TEXT_STYLE_BOLD);

            if (pNegrita != null && !pNegrita.IsReadOnly)
                pNegrita.Set(negrita ? 1 : 0);
        }
        catch
        {
        }

        // Color de texto.
        try
        {
            Parameter pColor = tipo.get_Parameter(BuiltInParameter.LINE_COLOR);

            if (pColor != null && !pColor.IsReadOnly)
                pColor.Set(ConvertirColorAEnteroRevit(rojo, verde, azul));
        }
        catch
        {
        }

        // Fondo del texto transparente.
        // En Revit, este parámetro debe quedar en 1 para evitar el fondo blanco/opaque
        // que tapa el hatch beige de títulos y zonas.
        try
        {
            Parameter pFondoTexto = tipo.get_Parameter(BuiltInParameter.TEXT_BACKGROUND);

            if (pFondoTexto != null && !pFondoTexto.IsReadOnly)
                pFondoTexto.Set(1);
        }
        catch
        {
        }
    }

    private int ConvertirColorAEnteroRevit(byte rojo, byte verde, byte azul)
    {
        return rojo + (verde * 256) + (azul * 256 * 256);
    }

    private int CrearRellenoTituloDetalle(
        Document doc,
        Autodesk.Revit.DB.View vista,
        double x1,
        double y1,
        double x2,
        double y2)
    {
        if (doc == null || vista == null)
            return 0;

        if (Math.Abs(x2 - x1) < 0.00001 || Math.Abs(y2 - y1) < 0.00001)
            return 0;

        double minX = Math.Min(x1, x2);
        double maxX = Math.Max(x1, x2);
        double minY = Math.Min(y1, y2);
        double maxY = Math.Max(y1, y2);

        try
        {
            ElementId tipoRegionId = ObtenerOCrearTipoRegionTituloMYG(doc);

            if (tipoRegionId == ElementId.InvalidElementId)
                return 0;

            CurveLoop loop = new CurveLoop();
            loop.Append(Line.CreateBound(new XYZ(minX, minY, 0.0), new XYZ(maxX, minY, 0.0)));
            loop.Append(Line.CreateBound(new XYZ(maxX, minY, 0.0), new XYZ(maxX, maxY, 0.0)));
            loop.Append(Line.CreateBound(new XYZ(maxX, maxY, 0.0), new XYZ(minX, maxY, 0.0)));
            loop.Append(Line.CreateBound(new XYZ(minX, maxY, 0.0), new XYZ(minX, minY, 0.0)));

            IList<CurveLoop> loops = new List<CurveLoop>();
            loops.Add(loop);

            FilledRegion.Create(doc, tipoRegionId, vista.Id, loops);
            return 1;
        }
        catch
        {
            return 0;
        }
    }

    private ElementId ObtenerOCrearTipoRegionTituloMYG(Document doc)
    {
        if (doc == null)
            return ElementId.InvalidElementId;

        string nombreTipo = "MYG_HATCH_TITULO_GRIS_230";

        try
        {
            FilledRegionType existente = new FilteredElementCollector(doc)
                .OfClass(typeof(FilledRegionType))
                .Cast<FilledRegionType>()
                .FirstOrDefault(x => x != null && x.Name == nombreTipo);

            if (existente != null)
            {
                ConfigurarRegionTituloMYG(doc, existente);
                return existente.Id;
            }

            FilledRegionType baseTipo = new FilteredElementCollector(doc)
                .OfClass(typeof(FilledRegionType))
                .Cast<FilledRegionType>()
                .FirstOrDefault();

            if (baseTipo == null)
                return ElementId.InvalidElementId;

            FilledRegionType nuevo = baseTipo.Duplicate(nombreTipo) as FilledRegionType;

            if (nuevo == null)
                return baseTipo.Id;

            ConfigurarRegionTituloMYG(doc, nuevo);

            return nuevo.Id;
        }
        catch
        {
            try
            {
                ElementId id = new FilteredElementCollector(doc)
                    .OfClass(typeof(FilledRegionType))
                    .FirstElementId();

                if (id != null)
                    return id;
            }
            catch
            {
            }
        }

        return ElementId.InvalidElementId;
    }

    private ElementId ObtenerOCrearTipoRegionPuntoAzulMYG(Document doc)
    {
        if (doc == null)
            return ElementId.InvalidElementId;

        string nombreTipo = "MYG_PUNTO_RELLENO_AZUL_0064";

        try
        {
            FilledRegionType existente = new FilteredElementCollector(doc)
                .OfClass(typeof(FilledRegionType))
                .Cast<FilledRegionType>()
                .FirstOrDefault(x => x != null && x.Name == nombreTipo);

            if (existente != null)
            {
                ConfigurarRegionPuntoAzulMYG(doc, existente);
                return existente.Id;
            }

            FilledRegionType baseTipo = new FilteredElementCollector(doc)
                .OfClass(typeof(FilledRegionType))
                .Cast<FilledRegionType>()
                .FirstOrDefault();

            if (baseTipo == null)
                return ElementId.InvalidElementId;

            FilledRegionType nuevo = baseTipo.Duplicate(nombreTipo) as FilledRegionType;

            if (nuevo == null)
                return baseTipo.Id;

            ConfigurarRegionPuntoAzulMYG(doc, nuevo);

            return nuevo.Id;
        }
        catch
        {
            try
            {
                ElementId id = new FilteredElementCollector(doc)
                    .OfClass(typeof(FilledRegionType))
                    .FirstElementId();

                if (id != null)
                    return id;
            }
            catch
            {
            }
        }

        return ElementId.InvalidElementId;
    }

    private void ConfigurarRegionPuntoAzulMYG(Document doc, FilledRegionType tipo)
    {
        if (doc == null || tipo == null)
            return;

        try
        {
            FillPatternElement solido = new FilteredElementCollector(doc)
                .OfClass(typeof(FillPatternElement))
                .Cast<FillPatternElement>()
                .FirstOrDefault(x => x != null && x.GetFillPattern() != null && x.GetFillPattern().IsSolidFill);

            if (solido != null)
                tipo.ForegroundPatternId = solido.Id;
        }
        catch
        {
        }

        try
        {
            tipo.ForegroundPatternColor = new Autodesk.Revit.DB.Color(0, 0, 64);
        }
        catch
        {
        }

        try
        {
            tipo.BackgroundPatternColor = new Autodesk.Revit.DB.Color(0, 0, 64);
        }
        catch
        {
        }

        try
        {
            tipo.IsMasking = false;
        }
        catch
        {
        }
    }

    private void ConfigurarRegionTituloMYG(Document doc, FilledRegionType tipo)
    {
        if (doc == null || tipo == null)
            return;

        try
        {
            FillPatternElement solido = new FilteredElementCollector(doc)
                .OfClass(typeof(FillPatternElement))
                .Cast<FillPatternElement>()
                .FirstOrDefault(x => x != null && x.GetFillPattern() != null && x.GetFillPattern().IsSolidFill);

            if (solido != null)
                tipo.ForegroundPatternId = solido.Id;
        }
        catch
        {
        }

        try
        {
            tipo.ForegroundPatternColor = new Autodesk.Revit.DB.Color(230, 230, 230);
        }
        catch
        {
        }

        try
        {
            tipo.BackgroundPatternColor = new Autodesk.Revit.DB.Color(230, 230, 230);
        }
        catch
        {
        }


        try
        {
            tipo.IsMasking = false;
        }
        catch
        {
        }
    }

    // =========================================================
    // UTILIDADES GEOMÉTRICAS Y ROOM
    // =========================================================

    private BoundingBoxXYZ ObtenerBoundingBoxRoomExpandido(Room room, double margenFeet)
    {
        if (room == null)
            return null;

        BoundingBoxXYZ bb = null;

        try
        {
            bb = room.get_BoundingBox(null);
        }
        catch
        {
            bb = null;
        }

        if (bb == null)
            return null;

        BoundingBoxXYZ nuevo = new BoundingBoxXYZ();
        nuevo.Min = new XYZ(
            bb.Min.X - margenFeet,
            bb.Min.Y - margenFeet,
            bb.Min.Z - margenFeet);

        nuevo.Max = new XYZ(
            bb.Max.X + margenFeet,
            bb.Max.Y + margenFeet,
            bb.Max.Z + margenFeet);

        return nuevo;
    }

    private double ObtenerZPruebaRoom(Document doc, Room room)
    {
        if (doc == null || room == null)
            return 0.0;

        double zBase = 0.0;

        try
        {
            Level nivel = doc.GetElement(room.LevelId) as Level;

            if (nivel != null)
                zBase = nivel.Elevation;
        }
        catch
        {
        }

        try
        {
            LocationPoint lp = room.Location as LocationPoint;

            if (lp != null && lp.Point != null)
                zBase = lp.Point.Z;
        }
        catch
        {
        }

        double zPrueba = zBase + MetrosAPies(1.00);

        try
        {
            LocationPoint lp = room.Location as LocationPoint;

            if (lp != null && lp.Point != null)
            {
                XYZ p = new XYZ(lp.Point.X, lp.Point.Y, zPrueba);

                if (room.IsPointInRoom(p))
                    return zPrueba;
            }
        }
        catch
        {
        }

        // Fallback más bajo para Rooms con altura reducida o límites especiales.
        return zBase + MetrosAPies(0.30);
    }

    private double ObtenerAnchoMuro(Wall muro)
    {
        if (muro == null)
            return MetrosAPies(0.15);

        try
        {
            WallType tipo = muro.WallType;

            if (tipo != null && tipo.Width > 0.0001)
                return tipo.Width;
        }
        catch
        {
        }

        return MetrosAPies(0.15);
    }

    private double MetrosAPies(double metros)
    {
        return metros / 0.3048;
    }

    private string ObtenerParametroRoom(Room room, string nombreParametro)
    {
        if (room == null || string.IsNullOrWhiteSpace(nombreParametro))
            return "";

        try
        {
            string valor = ObtenerTextoParametro(room, nombreParametro);

            if (!string.IsNullOrWhiteSpace(valor))
                return valor.Trim();
        }
        catch
        {
        }

        return "";
    }

    private string ObtenerNombreRoomConItemCodigo(Room room, string itemCodigoElemento)
    {
        if (room == null)
            return "Room";

        string nombre = "";

        try
        {
            nombre = room.Name;
        }
        catch
        {
            nombre = "";
        }

        if (string.IsNullOrWhiteSpace(nombre))
        {
            try
            {
                nombre = room.Number;
            }
            catch
            {
                nombre = "";
            }
        }

        if (string.IsNullOrWhiteSpace(nombre))
            nombre = "Room " + room.Id.Value.ToString();

        nombre = LimpiarNombreRoomSinNumeroHabitacion(room, nombre);

        if (!string.IsNullOrWhiteSpace(itemCodigoElemento))
            return itemCodigoElemento.Trim() + " - " + nombre.Trim();

        return LimpiarNombreAmbienteSinNumeroHabitacion(ObtenerNombreRoom(room), "");
    }

    private string LimpiarNombreRoomSinNumeroHabitacion(Room room, string nombreBase)
    {
        string nombre = nombreBase == null ? "" : nombreBase.Trim();

        if (string.IsNullOrWhiteSpace(nombre))
            return "";

        string numeroRoom = "";

        try
        {
            if (room != null)
                numeroRoom = room.Number;
        }
        catch
        {
            numeroRoom = "";
        }

        if (!string.IsNullOrWhiteSpace(numeroRoom))
            nombre = QuitarNumeroFinalExacto(nombre, numeroRoom);

        return nombre.Trim();
    }

    private string LimpiarNombreAmbienteSinNumeroHabitacion(string texto, string numeroHabitacionEsperado)
    {
        if (string.IsNullOrWhiteSpace(texto))
            return "";

        string limpio = texto.Trim();
        string numeroEsperado = numeroHabitacionEsperado == null ? "" : numeroHabitacionEsperado.Trim();

        // Caso típico del Excel: "05.02 - SALA COMEDOR 1".
        // Se conserva el código ITEM_CódigoElemento y se retira solo el número final
        // cuando coincide con el número/orden de habitación esperado.
        int indiceSeparador = limpio.IndexOf(" - ", StringComparison.Ordinal);

        if (indiceSeparador >= 0 && indiceSeparador + 3 < limpio.Length)
        {
            string codigo = limpio.Substring(0, indiceSeparador).Trim();
            string ambiente = limpio.Substring(indiceSeparador + 3).Trim();

            if (!string.IsNullOrWhiteSpace(numeroEsperado))
                ambiente = QuitarNumeroFinalExacto(ambiente, numeroEsperado);

            if (!string.IsNullOrWhiteSpace(codigo) && !string.IsNullOrWhiteSpace(ambiente))
                return codigo + " - " + ambiente;
        }

        if (!string.IsNullOrWhiteSpace(numeroEsperado))
            return QuitarNumeroFinalExacto(limpio, numeroEsperado);

        return limpio;
    }

    private string QuitarNumeroFinalExacto(string texto, string numero)
    {
        if (string.IsNullOrWhiteSpace(texto))
            return "";

        if (string.IsNullOrWhiteSpace(numero))
            return texto.Trim();

        string limpio = texto.Trim();
        string numeroLimpio = numero.Trim();

        try
        {
            string patron = @"\s+" + System.Text.RegularExpressions.Regex.Escape(numeroLimpio) + @"$";

            if (System.Text.RegularExpressions.Regex.IsMatch(limpio, patron))
                return System.Text.RegularExpressions.Regex.Replace(limpio, patron, "").Trim();
        }
        catch
        {
        }

        return limpio;
    }

    private string ObtenerNombreRoom(Room room)
    {
        if (room == null)
            return "Room";

        string numero = "";
        string nombre = "";

        try
        {
            numero = room.Number;
        }
        catch
        {
        }

        try
        {
            nombre = room.Name;
        }
        catch
        {
        }

        if (!string.IsNullOrWhiteSpace(numero) && !string.IsNullOrWhiteSpace(nombre))
            return numero + " - " + nombre;

        if (!string.IsNullOrWhiteSpace(nombre))
            return nombre;

        if (!string.IsNullOrWhiteSpace(numero))
            return numero;

        return "Room " + room.Id.Value.ToString();
    }

    private string ObtenerNombreProyecto(Document doc)
    {
        if (doc == null)
            return "";

        try
        {
            if (doc.ProjectInformation != null && !string.IsNullOrWhiteSpace(doc.ProjectInformation.Name))
                return doc.ProjectInformation.Name;
        }
        catch
        {
        }

        try
        {
            return doc.Title;
        }
        catch
        {
            return "";
        }
    }

    private string NormalizarClave(string texto)
    {
        if (string.IsNullOrWhiteSpace(texto))
            return "";

        string textoFormD = texto.Trim().Normalize(System.Text.NormalizationForm.FormD);
        System.Text.StringBuilder sb = new System.Text.StringBuilder();

        for (int i = 0; i < textoFormD.Length; i++)
        {
            char c = textoFormD[i];

            System.Globalization.UnicodeCategory categoria =
                System.Globalization.CharUnicodeInfo.GetUnicodeCategory(c);

            if (categoria != System.Globalization.UnicodeCategory.NonSpacingMark)
                sb.Append(c);
        }

        return sb.ToString()
            .Normalize(System.Text.NormalizationForm.FormC)
            .ToUpperInvariant();
    }

    private void MostrarEnVentana(string texto)
    {
        if (Form == null || Form.IsDisposed)
            return;

        Form.MostrarResultado(texto);
    }

    // =========================================================
    // FILTRO DE SELECCIÓN
    // =========================================================

    private class FiltroSeleccionRoomMYG : ISelectionFilter
    {
        public bool AllowElement(Element elem)
        {
            if (elem == null)
                return false;

            Room room = elem as Room;

            if (room == null)
                return false;

            try
            {
                return room.Area > 0;
            }
            catch
            {
                return true;
            }
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            return true;
        }
    }

    // =========================================================
    // CLASES INTERNAS
    // =========================================================


    private class CuadroExcelAcabadosMYG
    {
        public string Titulo { get; set; }
        public List<AmbienteExcelAcabadoMYG> Ambientes { get; set; }
        public List<AcabadoExcelMYG> Acabados { get; set; }
        public Dictionary<string, bool> Marcas { get; set; }
    }

    private class AmbienteExcelAcabadoMYG
    {
        public int ColumnaExcel { get; set; }
        public string Zona { get; set; }
        public string Nombre { get; set; }
    }

    private class AcabadoExcelMYG
    {
        public int FilaExcel { get; set; }
        public string Categoria { get; set; }
        public string ModeloTipo { get; set; }
        public string Descripcion { get; set; }
    }

    private class RoomAcabadoMYG
    {
        public ElementId RoomId { get; set; }
        public string ARQUbicacion { get; set; }
        public string ItemCodigoElemento { get; set; }
        public string NombreRoom { get; set; }
        public List<ElementoAcabadoMYG> Elementos { get; set; }
    }

    private class ElementoAcabadoMYG
    {
        public ElementId ElementId { get; set; }
        public long ElementIdValue { get; set; }
        public string Categoria { get; set; }
        public string NombreTipo { get; set; }
        public string ModeloTipo { get; set; }
        public string DescripcionTipo { get; set; }
        public string NombreRoom { get; set; }
        public string ClaveFila { get; set; }
    }

    private class FilaAcabadoMYG
    {
        public string Clave { get; set; }
        public string Categoria { get; set; }
        public string ModeloTipo { get; set; }
        public string DescripcionTipo { get; set; }
        public string NombreTipo { get; set; }
        public Dictionary<long, int> ConteoPorRoom { get; set; }
        public List<ElementId> ElementosIds { get; set; }
    }
}
