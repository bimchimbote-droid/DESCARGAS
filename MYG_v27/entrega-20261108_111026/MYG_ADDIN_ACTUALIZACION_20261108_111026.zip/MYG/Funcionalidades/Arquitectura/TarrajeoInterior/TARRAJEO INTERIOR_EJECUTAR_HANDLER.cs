﻿// =====================================
// HANDLER EXTERNO - TARRAJEO INTERIOR POR CARA SEMILLA / FRANJA COMPARTIDA
// CON USING
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Linq;

public class EjecutarTarrajeoInteriorConfinamientoHandler : IExternalEventHandler
{
    public UIDocument UiDoc { get; set; }
    public CrearTarrajeoInteriorConfinamientoForm Form { get; set; }

    public CrearTarrajeoInteriorConfinamientoForm.TarrajeoInteriorAccion Accion { get; set; } =
        CrearTarrajeoInteriorConfinamientoForm.TarrajeoInteriorAccion.Ninguna;

    // Normal vertical: cara con normal casi horizontal.
    private const double TOL_NORMAL_VERTICAL = 0.08;

    // Tolerancias de detección de franja desde la cara semilla.
    private const double TOL_PLANO_SEMILLA = 0.035 / 0.3048;        // 3.5 cm
    private const double TOL_ANGULO_SEMILLA_GRADOS = 5.0;          // 5 grados
    private const double TOL_CONTINUIDAD = (1.5 * 0.0254) / 0.3048;   // 1.5 pulgadas: margen máximo de junta/corte
    private const double TOL_SEMILLA_PUNTO = 0.25 / 0.3048;        // 25 cm
    private const double TOL_PEGADO_REAL = 0.006 / 0.3048;           // 6 mm: une caras realmente pegadas; juntas mayores cortan la franja

    // V16:
    // Permite proyectar la franja a través de interrupciones propias del confinamiento
    // (columnetas/encuentros cortos) aunque no exista una cara coplanar exactamente pegada.
    // Las juntas pequeñas visibles, aprox. 1" a 1.5", se siguen tomando como corte.
    private const double GAP_MAXIMO_PROYECCION_SIN_CARA = 0.60 / 0.3048; // 60 cm: puente máximo por columneta/interrupción local

    // V9:
    // Detecta muros/columnetas transversales que atraviesan la franja semilla.
    // Si una cara perpendicular cruza el plano de tarrajeo, corta la franja en esa cara
    // para que el tarrajeo no se proyecte hasta el fondo atravesando otro muro.
    private const double TOL_ANGULO_BARRERA_GRADOS = 15.0;
    private const double TOL_CRUCE_PLANO_BARRERA = 0.025 / 0.3048;   // 2.5 cm
    private const double PROFUNDIDAD_MINIMA_BARRERA_TRANSVERSAL = 0.35 / 0.3048; // 35 cm: ignora caras laterales cortas de columnetas; corta muros que cruzan
    private const double MARGEN_CORTE_BARRERA = 0.0;                  // V13: sin retiro; corta al ras de la cara/límite detectado

    // V34:
    // Ajuste tipo TRIM/EXTEND en quiebres. Después de crear el tarrajeo,
    // se busca un muro adyacente cercano y se recorta/extiende la LocationCurve
    // para que el extremo llegue al cruce real, similar a la herramienta
    // Modificar > Recortar/Extender elemento simple.
    private const double TOL_TRIM_QUIEBRE = 0.18 / 0.3048;            // 18 cm: distancia máxima del extremo al punto de cruce
    private const double TOL_BUSQUEDA_MURO_TRIM = 0.45 / 0.3048;      // 45 cm: margen para buscar muros adyacentes
    private const double TOL_SOLAPE_Z_TRIM = 0.05 / 0.3048;           // 5 cm: solape vertical mínimo
    private const double ANGULO_MINIMO_TRIM_GRADOS = 8.0;             // ignora muros casi paralelos

    // V27:
    // Interferencias de cualquier categoría visible. Esta lógica NO debe impedir la creación del muro.
    // Si una interferencia no se puede resolver, se crea el tarrajeo base igual y se continúa.
    private const double TOL_INTERFERENCIA_PLANO = 0.005 / 0.3048;    // V30: 5 mm. Ya no se usa bbox amplio; solo sólido real contra envolvente
    private const double TOL_INTERFERENCIA_BORDE = 0.005 / 0.3048;    // 5 mm para recortes / aberturas
    private const double COBERTURA_TOTAL_INTERFERENCIA = 0.92;        // 92% se considera total

    // Dimensiones mínimas para evitar caras muy pequeñas.
    private const double AREA_MINIMA_CARA = 0.03;                  // pies² aprox.
    private const double ANCHO_MINIMO_CARA = 0.05 / 0.3048;        // 5 cm
    private const double ALTO_MINIMO_CARA = 0.05 / 0.3048;         // 5 cm
    private const double LONGITUD_MINIMA_FRANJA = 0.10 / 0.3048;   // 10 cm
    private const double ALTURA_MINIMA_FRANJA = 0.10 / 0.3048;     // 10 cm

    // Preview en Revit.
    private const string NOMBRE_ESTILO_PREVIEW = "MYG_PREVIEW_TARRAJEO";
    private readonly List<ElementId> _idsPreview = new List<ElementId>();

    // V35 OPT:
    // Caches de lectura pesada para que el pick consecutivo no vuelva a leer
    // toda la geometría base, puertas/ventanas y muros candidatos en cada cara.
    private string _cacheClaveCarasBase = "";
    private List<CaraVerticalHostMYG> _cacheCarasBaseSeleccionadas = null;
    private long _cacheVistaPuertasVentanasValue = long.MinValue;
    private List<Element> _cachePuertasVentanasVisibles = null;

    public string GetName()
    {
        return "MYG - Tarrajeo interior por cara semilla V40 PV perfil fallback";
    }

    public void Execute(UIApplication app)
    {
        if (UiDoc == null || UiDoc.Document == null)
            return;

        if (Form == null || Form.IsDisposed)
            return;

        try
        {
            if (Accion == CrearTarrajeoInteriorConfinamientoForm.TarrajeoInteriorAccion.SeleccionarElementosNativos)
            {
                SeleccionarElementosNativos();
                return;
            }

            if (Accion == CrearTarrajeoInteriorConfinamientoForm.TarrajeoInteriorAccion.SeleccionarElementosVinculados)
            {
                SeleccionarElementosVinculados();
                return;
            }

            if (Accion == CrearTarrajeoInteriorConfinamientoForm.TarrajeoInteriorAccion.PickarCaraSemilla)
            {
                PickarCaraSemilla();
                return;
            }

            if (Accion == CrearTarrajeoInteriorConfinamientoForm.TarrajeoInteriorAccion.PickarYCrearConsecutivo)
            {
                PickarYCrearTarrajeoConsecutivo();
                return;
            }

            if (Accion == CrearTarrajeoInteriorConfinamientoForm.TarrajeoInteriorAccion.PrevisualizarFranja)
            {
                PrevisualizarFranja();
                return;
            }

            if (Accion == CrearTarrajeoInteriorConfinamientoForm.TarrajeoInteriorAccion.BorrarPrevisualizacion)
            {
                BorrarPrevisualizacion();
                return;
            }

            if (Accion == CrearTarrajeoInteriorConfinamientoForm.TarrajeoInteriorAccion.CrearTarrajeo)
            {
                CrearTarrajeoInterior();
                return;
            }
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            MostrarEnVentana("Selección cancelada.");
        }
        catch (Exception ex)
        {
            MostrarEnVentana("ERROR:\r\n" + ex.Message);
        }
        finally
        {
            Accion = CrearTarrajeoInteriorConfinamientoForm.TarrajeoInteriorAccion.Ninguna;
        }
    }

    // =========================================================
    // SELECCIÓN DE ELEMENTOS NATIVOS
    // =========================================================

    private void SeleccionarElementosNativos()
    {
        Document doc = UiDoc.Document;

        try
        {
            Form.OcultarTemporalmenteParaSeleccion();

            IList<Reference> referencias = UiDoc.Selection.PickObjects(
                ObjectType.Element,
                new FiltroSeleccionElementosBaseNativosMYG(),
                "Seleccione muros, columnetas y vigas de confinamiento nativas");

            if (referencias == null || referencias.Count == 0)
                return;

            List<CrearTarrajeoInteriorConfinamientoForm.ElementoTarrajeoBaseMYG> seleccion =
                new List<CrearTarrajeoInteriorConfinamientoForm.ElementoTarrajeoBaseMYG>();

            if (Form.ElementosSeleccionados != null)
                seleccion.AddRange(Form.ElementosSeleccionados.Where(x => x != null && x.EsVinculado));

            foreach (Reference referencia in referencias)
            {
                if (referencia == null)
                    continue;

                Element elemento = doc.GetElement(referencia.ElementId);

                if (elemento == null)
                    continue;

                if (!EsCategoriaBasePermitida(elemento))
                    continue;

                CrearTarrajeoInteriorConfinamientoForm.ElementoTarrajeoBaseMYG item =
                    new CrearTarrajeoInteriorConfinamientoForm.ElementoTarrajeoBaseMYG();

                item.EsVinculado = false;
                item.ElementIdNativo = elemento.Id;
                item.LinkInstanceId = ElementId.InvalidElementId;
                item.LinkedElementId = ElementId.InvalidElementId;
                item.NombreVinculo = "";
                item.Nombre = ObtenerNombreElemento(elemento);
                item.Categoria = ObtenerCategoriaElemento(elemento);

                seleccion.Add(item);
            }

            Form.ActualizarElementosSeleccionados(seleccion);
            InvalidarCachesOptimizacion();
        }
        finally
        {
            Form.MostrarLuegoDeSeleccion();
        }
    }

    // =========================================================
    // SELECCIÓN DE ELEMENTOS VINCULADOS
    // =========================================================

    private void SeleccionarElementosVinculados()
    {
        Document doc = UiDoc.Document;

        try
        {
            Form.OcultarTemporalmenteParaSeleccion();

            IList<Reference> referencias = UiDoc.Selection.PickObjects(
                ObjectType.LinkedElement,
                new FiltroSeleccionElementosBaseVinculadosMYG(doc),
                "Seleccione muros, columnetas y vigas de confinamiento desde vínculo");

            if (referencias == null || referencias.Count == 0)
                return;

            List<CrearTarrajeoInteriorConfinamientoForm.ElementoTarrajeoBaseMYG> seleccion =
                new List<CrearTarrajeoInteriorConfinamientoForm.ElementoTarrajeoBaseMYG>();

            if (Form.ElementosSeleccionados != null)
                seleccion.AddRange(Form.ElementosSeleccionados.Where(x => x != null && !x.EsVinculado));

            foreach (Reference referencia in referencias)
            {
                if (referencia == null)
                    continue;

                RevitLinkInstance link = doc.GetElement(referencia.ElementId) as RevitLinkInstance;

                if (link == null)
                    continue;

                Document docLink = ObtenerDocumentoVinculo(link);

                if (docLink == null)
                    continue;

                ElementId linkedElementId = referencia.LinkedElementId;

                if (linkedElementId == null || linkedElementId == ElementId.InvalidElementId)
                    continue;

                Element elementoLink = docLink.GetElement(linkedElementId);

                if (elementoLink == null)
                    continue;

                if (!EsCategoriaBasePermitida(elementoLink))
                    continue;

                CrearTarrajeoInteriorConfinamientoForm.ElementoTarrajeoBaseMYG item =
                    new CrearTarrajeoInteriorConfinamientoForm.ElementoTarrajeoBaseMYG();

                item.EsVinculado = true;
                item.ElementIdNativo = ElementId.InvalidElementId;
                item.LinkInstanceId = link.Id;
                item.LinkedElementId = linkedElementId;
                item.NombreVinculo = ObtenerNombreElemento(link);
                item.Nombre = ObtenerNombreElemento(elementoLink);
                item.Categoria = ObtenerCategoriaElemento(elementoLink);

                seleccion.Add(item);
            }

            Form.ActualizarElementosSeleccionados(seleccion);
            InvalidarCachesOptimizacion();
        }
        finally
        {
            Form.MostrarLuegoDeSeleccion();
        }
    }


    // =========================================================
    // PICKAR CARAS Y CREAR AL INSTANTE
    // =========================================================

    private void PickarYCrearTarrajeoConsecutivo()
    {
        Document doc = UiDoc.Document;

        if (doc == null)
            return;

        if (Form.ElementosSeleccionados == null || Form.ElementosSeleccionados.Count == 0)
        {
            MostrarEnVentana("Debe seleccionar muros, columnetas o vigas base.");
            return;
        }

        WallType wallType = doc.GetElement(Form.TipoMuroSeleccionadoId) as WallType;

        if (wallType == null)
        {
            MostrarEnVentana("No se encontró el tipo de muro seleccionado.");
            return;
        }

        int carasPickadas = 0;
        int murosCreados = 0;
        int omitidos = 0;
        int errores = 0;

        List<ElementId> idsMurosCreados = new List<ElementId>();
        HashSet<string> firmasCreadasSesion = new HashSet<string>();

        try
        {
            // Limpieza de cualquier preview que haya quedado de versiones anteriores.
            try
            {
                using (Transaction t0 = new Transaction(doc, "MYG - Limpiar preview tarrajeo"))
                {
                    t0.Start();
                    BorrarPrevisualizacionInterno(doc);
                    t0.Commit();
                }
            }
            catch
            {
            }

            Form.OcultarTemporalmenteParaSeleccion();

            while (true)
            {
                Reference referencia = null;

                try
                {
                    referencia = UiDoc.Selection.PickObject(
                        ObjectType.PointOnElement,
                        new FiltroSeleccionCaraSemillaMYG(doc),
                        "Picke una cara interior para crear tarrajeo al instante. Presione ESC para terminar.");
                }
                catch (Autodesk.Revit.Exceptions.OperationCanceledException)
                {
                    break;
                }

                if (referencia == null)
                    break;

                carasPickadas++;

                CrearTarrajeoInteriorConfinamientoForm.CaraSemillaTarrajeoMYG cara =
                    ObtenerCaraSemillaDesdeReferencia(doc, referencia);

                if (cara == null)
                {
                    omitidos++;
                    continue;
                }

                Form.CaraSemillaSeleccionada = cara;

                try
                {
                    Form.ActualizarCaraSemilla(cara);
                }
                catch
                {
                }

                DatosDeteccionMYG datos = null;
                FranjaTarrajeoMYG franja = DetectarFranjaDesdeSemilla(doc, wallType, out datos);

                if (franja == null)
                {
                    omitidos++;
                    continue;
                }

                if (franja.UFin <= franja.UInicio || franja.ZTop <= franja.ZBase)
                {
                    omitidos++;
                    continue;
                }

                if ((franja.UFin - franja.UInicio) < LONGITUD_MINIMA_FRANJA ||
                    (franja.ZTop - franja.ZBase) < ALTURA_MINIMA_FRANJA)
                {
                    omitidos++;
                    continue;
                }

                string firma = ObtenerFirmaFranjaSesion(franja);

                if (Form.EvitarDuplicados && firmasCreadasSesion.Contains(firma))
                {
                    omitidos++;
                    continue;
                }

                Level nivel = ObtenerNivelMasCercano(doc, franja.ZBase);

                if (nivel == null)
                {
                    omitidos++;
                    continue;
                }

                try
                {
                    Form.SeleccionarNivelVisual(nivel.Id);
                }
                catch
                {
                }

                Wall muroCreado = null;

                try
                {
                    using (Transaction t = new Transaction(doc, "MYG - Crear tarrajeo instantáneo por cara"))
                    {
                        t.Start();
                        ConfigurarTransaccionParaSuprimirAdvertencias(t);

                        muroCreado = CrearMuroDesdeFranja(
                            doc,
                            franja,
                            wallType,
                            nivel,
                            Form.GuardarParametros);

                        t.Commit();
                    }
                }
                catch
                {
                    muroCreado = null;
                    errores++;
                }

                if (muroCreado != null)
                {
                    murosCreados++;
                    idsMurosCreados.Add(muroCreado.Id);

                    // V36:
                    // Se recupera el ajuste inmediato que pediste: el muro creado se intenta
                    // recortar/extender en su quiebre al instante, pero usando la misma caché
                    // de V35 para no volver tan lento el proceso. Al finalizar con ESC igual
                    // se hace un pase global para rematar uniones entre todos los muros creados.
                    try
                    {
                        using (Transaction tTrimLocal = new Transaction(doc, "MYG - Ajustar quiebre tarrajeo local"))
                        {
                            tTrimLocal.Start();
                            ConfigurarTransaccionParaSuprimirAdvertencias(tTrimLocal);
                            Wall muroLocal = doc.GetElement(muroCreado.Id) as Wall;
                            if (muroLocal != null)
                                AjustarQuiebresYUnionesMurosCreados(doc, new List<Wall>() { muroLocal });
                            tTrimLocal.Commit();
                        }
                    }
                    catch
                    {
                    }

                    if (Form.EvitarDuplicados && !firmasCreadasSesion.Contains(firma))
                        firmasCreadasSesion.Add(firma);

                    // V36 OPT: no se selecciona cada muro inmediatamente porque refresca la UI
                    // y vuelve lento el pick consecutivo. Al final se seleccionan todos juntos.
                }
                else
                {
                    omitidos++;
                }
            }
        }
        finally
        {
            Form.MostrarLuegoDeSeleccion();
        }

        // V36: segundo pase global de ajuste tipo Trim/Extend.
        // Aunque ya se hizo un trim local inmediato, este remate final resuelve cruces entre muros creados en la misma tanda
        // o contra un muro que recién queda disponible después de terminar el pick consecutivo.
        try
        {
            if (idsMurosCreados.Count > 0)
            {
                using (Transaction tTrim = new Transaction(doc, "MYG - Ajustar quiebres tarrajeo"))
                {
                    tTrim.Start();
                    ConfigurarTransaccionParaSuprimirAdvertencias(tTrim);
                    AjustarQuiebresYUnionesMurosCreados(doc, ObtenerMurosDesdeIds(doc, idsMurosCreados));
                    tTrim.Commit();
                }
            }
        }
        catch
        {
        }

        try
        {
            if (idsMurosCreados.Count > 0)
                UiDoc.Selection.SetElementIds(idsMurosCreados);
        }
        catch
        {
        }

        MostrarEnVentana(
            "Proceso terminado.\r\n" +
            "Caras pickadas: " + carasPickadas.ToString() +
            " | Muros creados: " + murosCreados.ToString() +
            " | Omitidos: " + omitidos.ToString() +
            " | Errores: " + errores.ToString());
    }

    private string ObtenerFirmaFranjaSesion(FranjaTarrajeoMYG franja)
    {
        if (franja == null || franja.Normal == null || franja.EjeU == null)
            return "";

        string firma =
            Redondear(franja.Normal.X) + "|" +
            Redondear(franja.Normal.Y) + "|" +
            Redondear(franja.PlaneDCara) + "|" +
            Redondear(franja.UInicio) + "|" +
            Redondear(franja.UFin) + "|" +
            Redondear(franja.ZBase) + "|" +
            Redondear(franja.ZTop);

        return firma;
    }

    // =========================================================
    // PICKAR CARA SEMILLA
    // =========================================================

    private void PickarCaraSemilla()
    {
        Document doc = UiDoc.Document;

        try
        {
            Form.OcultarTemporalmenteParaSeleccion();

            Reference referencia = UiDoc.Selection.PickObject(
                ObjectType.PointOnElement,
                new FiltroSeleccionCaraSemillaMYG(doc),
                "Picke UNA cara interior que servirá como semilla para proyectar la franja de tarrajeo.");

            if (referencia == null)
                return;

            CrearTarrajeoInteriorConfinamientoForm.CaraSemillaTarrajeoMYG cara =
                ObtenerCaraSemillaDesdeReferencia(doc, referencia);

            if (cara == null)
            {
                MostrarEnVentana("No se pudo leer una cara vertical válida como semilla.");
                return;
            }

            Form.ActualizarCaraSemilla(cara);
        }
        finally
        {
            Form.MostrarLuegoDeSeleccion();
        }
    }

    private CrearTarrajeoInteriorConfinamientoForm.CaraSemillaTarrajeoMYG ObtenerCaraSemillaDesdeReferencia(
        Document doc,
        Reference referencia)
    {
        if (doc == null || referencia == null)
            return null;

        XYZ puntoHost = null;

        try
        {
            puntoHost = referencia.GlobalPoint;
        }
        catch
        {
            puntoHost = null;
        }

        if (puntoHost == null)
            return null;

        ElementoConTransformMYG data = ResolverElementoDesdeReferencia(doc, referencia);

        if (data == null || data.Elemento == null)
            return null;

        if (!EsCategoriaBasePermitida(data.Elemento))
            return null;

        List<CaraVerticalHostMYG> caras = ObtenerCarasVerticalesHost(data.Elemento, data.Transformacion);

        if (caras == null || caras.Count == 0)
            return null;

        CaraVerticalHostMYG mejor = null;
        double mejorScore = double.MaxValue;

        foreach (CaraVerticalHostMYG cara in caras)
        {
            if (cara == null || cara.Normal == null || cara.EjeU == null)
                continue;

            double score = CalcularScorePuntoSobreCara(puntoHost, cara.Normal, cara.EjeU, cara.PlaneD, cara.MinU, cara.MaxU, cara.MinZ, cara.MaxZ);

            if (score < mejorScore)
            {
                mejorScore = score;
                mejor = cara;
            }
        }

        if (mejor == null)
            return null;

        if (mejorScore > TOL_SEMILLA_PUNTO)
            return null;

        XYZ normal = mejor.Normal.Normalize();
        XYZ ejeU = XYZ.BasisZ.CrossProduct(normal);

        if (ejeU.GetLength() < 0.0001)
            return null;

        ejeU = ejeU.Normalize();

        CrearTarrajeoInteriorConfinamientoForm.CaraSemillaTarrajeoMYG semilla =
            new CrearTarrajeoInteriorConfinamientoForm.CaraSemillaTarrajeoMYG();

        semilla.EsVinculado = data.EsVinculado;
        semilla.ElementIdNativo = data.EsVinculado ? ElementId.InvalidElementId : data.Elemento.Id;
        semilla.LinkInstanceId = data.EsVinculado ? data.LinkInstanceId : ElementId.InvalidElementId;
        semilla.LinkedElementId = data.EsVinculado ? data.LinkedElementId : ElementId.InvalidElementId;
        semilla.PuntoHost = puntoHost;
        semilla.NormalHost = normal;
        semilla.EjeUHost = ejeU;
        semilla.PlaneD = mejor.PlaneD;
        semilla.MinU = mejor.MinU;
        semilla.MaxU = mejor.MaxU;
        semilla.MinZ = mejor.MinZ;
        semilla.MaxZ = mejor.MaxZ;
        semilla.NombreVinculo = data.NombreVinculo;
        semilla.Nombre = ObtenerNombreElemento(data.Elemento);
        semilla.Categoria = ObtenerCategoriaElemento(data.Elemento);

        return semilla;
    }

    // =========================================================
    // PREVIEW
    // =========================================================

    private void PrevisualizarFranja()
    {
        Document doc = UiDoc.Document;

        if (doc == null)
            return;

        WallType wallType = doc.GetElement(Form.TipoMuroSeleccionadoId) as WallType;

        if (wallType == null)
        {
            MostrarEnVentana("No se encontró el tipo de muro seleccionado.");
            return;
        }

        DatosDeteccionMYG datos = null;
        FranjaTarrajeoMYG franja = DetectarFranjaDesdeSemilla(doc, wallType, out datos);

        if (franja == null)
        {
            MostrarEnVentana(ArmarMensajeDeteccion("No se detectó una franja continua desde la cara semilla.", datos));
            return;
        }

        try
        {
            Level nivelPreview = ObtenerNivelMasCercano(doc, franja.ZBase);
            if (nivelPreview != null)
                Form.SeleccionarNivelVisual(nivelPreview.Id);
        }
        catch
        {
        }

        int lineas = 0;

        using (Transaction t = new Transaction(doc, "MYG - Previsualizar franja tarrajeo"))
        {
            t.Start();

            BorrarPrevisualizacionInterno(doc);

            GraphicsStyle estiloPreview = ObtenerOCrearEstiloPreview(doc);
            lineas = CrearPreviewRectanguloFranja(doc, franja, estiloPreview);

            t.Commit();
        }

        try
        {
            List<ElementId> idsSeleccionables = new List<ElementId>();

            foreach (ElementId id in _idsPreview)
            {
                Element e = null;
                try { e = doc.GetElement(id); } catch { e = null; }

                if (e is ModelCurve)
                    idsSeleccionables.Add(id);
            }

            if (idsSeleccionables.Count > 0)
                UiDoc.Selection.SetElementIds(idsSeleccionables);
        }
        catch
        {
        }

        MostrarEnVentana(
            "Preview terminado. Revise la franja verde en la vista de Revit.\r\n" +
            ArmarResumenFranja(franja, datos) +
            " | Líneas preview: " + lineas.ToString());
    }

    private void BorrarPrevisualizacion()
    {
        Document doc = UiDoc.Document;

        if (doc == null)
            return;

        int borrados = 0;

        using (Transaction t = new Transaction(doc, "MYG - Borrar preview tarrajeo"))
        {
            t.Start();
            borrados = BorrarPrevisualizacionInterno(doc);
            t.Commit();
        }

        MostrarEnVentana("Preview borrado. Elementos eliminados: " + borrados.ToString());
    }

    private int BorrarPrevisualizacionInterno(Document doc)
    {
        if (doc == null)
            return 0;

        List<ElementId> idsModelCurves = new List<ElementId>();
        List<ElementId> idsSketchPlanes = new List<ElementId>();
        List<ElementId> idsOtros = new List<ElementId>();

        foreach (ElementId id in _idsPreview)
        {
            if (id == null || id == ElementId.InvalidElementId)
                continue;

            Element e = null;

            try
            {
                e = doc.GetElement(id);
            }
            catch
            {
                e = null;
            }

            if (e == null)
                continue;

            if (e is ModelCurve)
                idsModelCurves.Add(id);
            else if (e is SketchPlane)
                idsSketchPlanes.Add(id);
            else
                idsOtros.Add(id);
        }

        int cantidad = idsModelCurves.Count + idsSketchPlanes.Count + idsOtros.Count;

        try
        {
            if (idsModelCurves.Count > 0)
                doc.Delete(idsModelCurves);
        }
        catch
        {
        }

        try
        {
            if (idsSketchPlanes.Count > 0)
                doc.Delete(idsSketchPlanes);
        }
        catch
        {
        }

        try
        {
            if (idsOtros.Count > 0)
                doc.Delete(idsOtros);
        }
        catch
        {
        }

        _idsPreview.Clear();

        return cantidad;
    }

    private GraphicsStyle ObtenerOCrearEstiloPreview(Document doc)
    {
        if (doc == null)
            return null;

        try
        {
            Category lineas = doc.Settings.Categories.get_Item(BuiltInCategory.OST_Lines);

            if (lineas == null)
                return null;

            Category subCategoria = null;

            foreach (Category sub in lineas.SubCategories)
            {
                if (sub == null)
                    continue;

                if (string.Equals(sub.Name, NOMBRE_ESTILO_PREVIEW, StringComparison.OrdinalIgnoreCase))
                {
                    subCategoria = sub;
                    break;
                }
            }

            if (subCategoria == null)
                subCategoria = doc.Settings.Categories.NewSubcategory(lineas, NOMBRE_ESTILO_PREVIEW);

            if (subCategoria != null)
            {
                try { subCategoria.LineColor = new Autodesk.Revit.DB.Color(0, 180, 0); } catch { }
                try { subCategoria.SetLineWeight(7, GraphicsStyleType.Projection); } catch { }

                return subCategoria.GetGraphicsStyle(GraphicsStyleType.Projection);
            }
        }
        catch
        {
        }

        return null;
    }

    private int CrearPreviewRectanguloFranja(Document doc, FranjaTarrajeoMYG franja, GraphicsStyle estiloPreview)
    {
        if (doc == null || franja == null)
            return 0;

        List<Curve> curvas = CrearCurvasRectanguloFranja(franja);

        if (curvas == null || curvas.Count == 0)
            return 0;

        int creadas = 0;

        Plane plano = Plane.CreateByNormalAndOrigin(franja.Normal, franja.PuntoCentroPlano);
        SketchPlane sketchPlane = SketchPlane.Create(doc, plano);

        if (sketchPlane == null)
            return 0;

        _idsPreview.Add(sketchPlane.Id);

        foreach (Curve curva in curvas)
        {
            if (curva == null)
                continue;

            try
            {
                if (curva.Length < MetrosAPies(0.005))
                    continue;

                ModelCurve modelCurve = doc.Create.NewModelCurve(curva, sketchPlane);

                if (modelCurve == null)
                    continue;

                if (estiloPreview != null)
                {
                    try { modelCurve.LineStyle = estiloPreview; } catch { }
                }

                _idsPreview.Add(modelCurve.Id);
                creadas++;
            }
            catch
            {
            }
        }

        return creadas;
    }

    // =========================================================
    // CREAR TARRAJEO
    // =========================================================

    private void CrearTarrajeoInterior()
    {
        Document doc = UiDoc.Document;

        if (doc == null)
            return;

        WallType wallType = doc.GetElement(Form.TipoMuroSeleccionadoId) as WallType;

        if (wallType == null)
        {
            MostrarEnVentana("No se encontró el tipo de muro seleccionado.");
            return;
        }

        DatosDeteccionMYG datos = null;
        FranjaTarrajeoMYG franja = DetectarFranjaDesdeSemilla(doc, wallType, out datos);

        if (franja == null)
        {
            MostrarEnVentana(ArmarMensajeDeteccion("No se detectó una franja continua desde la cara semilla.", datos));
            return;
        }

        if (franja.UFin <= franja.UInicio || franja.ZTop <= franja.ZBase)
        {
            MostrarEnVentana("La franja detectada no tiene dimensiones válidas.");
            return;
        }

        Level nivel = ObtenerNivelMasCercano(doc, franja.ZBase);

        if (nivel == null)
        {
            MostrarEnVentana("No se pudo detectar automáticamente el nivel base más cercano.");
            return;
        }

        try
        {
            Form.SeleccionarNivelVisual(nivel.Id);
        }
        catch
        {
        }

        Wall muroCreado = null;

        using (Transaction t = new Transaction(doc, "MYG - Crear tarrajeo por cara semilla"))
        {
            t.Start();
            ConfigurarTransaccionParaSuprimirAdvertencias(t);

            BorrarPrevisualizacionInterno(doc);

            muroCreado = CrearMuroDesdeFranja(doc, franja, wallType, nivel, Form.GuardarParametros);

            t.Commit();
        }

        if (muroCreado != null)
        {
            try
            {
                UiDoc.Selection.SetElementIds(new List<ElementId>() { muroCreado.Id });
            }
            catch
            {
            }

            MostrarEnVentana(
                "Proceso terminado. Muro de tarrajeo creado.\r\n" +
                "Nivel automático: " + nivel.Name + "\r\n" +
                ArmarResumenFranja(franja, datos));
        }
        else
        {
            MostrarEnVentana("No se pudo crear el muro de tarrajeo desde la franja detectada.");
        }
    }

    private Level ObtenerNivelMasCercano(Document doc, double elevacionReferencia)
    {
        if (doc == null)
            return null;

        Level mejor = null;
        double mejorDistancia = double.MaxValue;

        try
        {
            FilteredElementCollector collector = new FilteredElementCollector(doc);
            collector.OfClass(typeof(Level));

            foreach (Element e in collector)
            {
                Level nivel = e as Level;

                if (nivel == null)
                    continue;

                double distancia = Math.Abs(nivel.Elevation - elevacionReferencia);

                if (distancia < mejorDistancia)
                {
                    mejorDistancia = distancia;
                    mejor = nivel;
                }
            }
        }
        catch
        {
            mejor = null;
        }

        return mejor;
    }

    private Wall CrearMuroDesdeFranja(Document doc, FranjaTarrajeoMYG franja, WallType wallType, Level nivel, bool guardarParametros)
    {
        if (doc == null || franja == null || wallType == null || nivel == null)
            return null;

        // V30:
        // La interferencia ahora se calcula con sólido real, NO con bounding box.
        // Luego se resta la intersección como rectángulos U-Z y se crean muros separados.
        // Ya no se usa NewOpening para sólidos que tocan la base, porque Revit suele ignorar
        // o advertir ese tipo de abertura en muros creados por línea.
        List<InterferenciaTarrajeoMYG> interferencias = new List<InterferenciaTarrajeoMYG>();
        List<SegmentoFranjaMYG> segmentos = null;

        try
        {
            interferencias = ObtenerInterferenciasTarrajeoVisibles(doc, franja, wallType);
            segmentos = CrearSegmentosPorInterferenciasSeguro(franja, interferencias);
        }
        catch
        {
            // Si la evaluación de sólidos falla por algún elemento raro, se mantiene el comportamiento original,
            // pero igual se aplica el ajuste de quiebres al muro creado.
            Wall muroBaseFallo = CrearMuroDesdeFranjaSimple(doc, franja, wallType, nivel, guardarParametros);
            try { UnirTarrajeoConAnfitrionesPuertasVentanasCercanas(doc, muroBaseFallo, franja); } catch { }
            return muroBaseFallo;
        }

        if (segmentos == null)
            segmentos = new List<SegmentoFranjaMYG>();

        if (segmentos.Count == 0)
        {
            // Si hay interferencia real cubriendo toda la franja, no se crea tarrajeo en esa zona.
            // Si no hubo interferencias, se crea el muro original.
            if (interferencias == null || interferencias.Count == 0)
            {
                Wall muroBaseSinInterferencia = CrearMuroDesdeFranjaSimple(doc, franja, wallType, nivel, guardarParametros);
                try { UnirTarrajeoConAnfitrionesPuertasVentanasCercanas(doc, muroBaseSinInterferencia, franja); } catch { }
                return muroBaseSinInterferencia;
            }

            return null;
        }

        Wall primerMuro = null;
        List<Wall> murosCreadosLocales = new List<Wall>();

        foreach (SegmentoFranjaMYG segmento in segmentos.OrderBy(x => x.UInicio).ThenBy(x => x.ZBase))
        {
            if (segmento == null)
                continue;

            FranjaTarrajeoMYG franjaSegmento = CrearFranjaDesdeSegmento(franja, segmento);

            if (franjaSegmento == null)
                continue;

            Wall muro = CrearMuroDesdeFranjaSimple(doc, franjaSegmento, wallType, nivel, guardarParametros);

            if (muro == null)
                continue;

            murosCreadosLocales.Add(muro);

            // V32:
            // Las puertas y ventanas nativas NO generan "Hueco de muro".
            // Solo se une el tarrajeo con el muro anfitrión de la puerta/ventana,
            // igual que la herramienta manual Unir geometría de Revit.
            // Para huecos dentro de vínculos no existe unión directa con el anfitrión
            // vinculado, por eso solo en ese caso se deja respaldo rectangular.
            try
            {
                AplicarPuertasVentanasComoHuecosDeAnfitrion(doc, muro, franjaSegmento, interferencias);
            }
            catch
            {
            }

            // V33:
            // Además de los huecos detectados como interferencia, se vuelve a buscar
            // TODAS las puertas y ventanas nativas cercanas al tarrajeo creado.
            // Esto replica mejor la herramienta manual Unir geometría: se une el
            // muro de tarrajeo con el muro anfitrión de cada puerta/ventana cercana.
            try
            {
                UnirTarrajeoConAnfitrionesPuertasVentanasCercanas(doc, muro, franjaSegmento);
            }
            catch
            {
            }

            if (primerMuro == null)
                primerMuro = muro;
        }

        // V36 OPT: el trim/extend se ejecuta en 2 etapas:
        // 1) un ajuste local inmediato por muro creado;
        // 2) un pase global al terminar con ESC para rematar quiebres entre muros de la tanda.

        if (primerMuro == null)
        {
            if (interferencias == null || interferencias.Count == 0)
            {
                Wall muroBaseFinal = CrearMuroDesdeFranjaSimple(doc, franja, wallType, nivel, guardarParametros);
                try { UnirTarrajeoConAnfitrionesPuertasVentanasCercanas(doc, muroBaseFinal, franja); } catch { }
                return muroBaseFinal;
            }

            return null;
        }

        return primerMuro;
    }

    private Wall CrearMuroDesdeFranjaSimple(Document doc, FranjaTarrajeoMYG franja, WallType wallType, Level nivel, bool guardarParametros)
    {
        if (doc == null || franja == null || wallType == null || nivel == null)
            return null;

        double altura = franja.ZTop - franja.ZBase;
        double baseOffset = franja.ZBase - nivel.Elevation;

        if (altura < ALTURA_MINIMA_FRANJA)
            return null;

        XYZ p0 = CrearPuntoDesdePlano(franja.UInicio, nivel.Elevation, franja.EjeU, franja.Normal, franja.PlaneDCentroMuro);
        XYZ p1 = CrearPuntoDesdePlano(franja.UFin, nivel.Elevation, franja.EjeU, franja.Normal, franja.PlaneDCentroMuro);

        if (p0 == null || p1 == null)
            return null;

        if (DistanciaXY(p0, p1) < LONGITUD_MINIMA_FRANJA)
            return null;

        Line linea = null;

        try
        {
            linea = Line.CreateBound(p0, p1);
        }
        catch
        {
            linea = null;
        }

        if (linea == null)
            return null;

        Wall muro = null;

        try
        {
            muro = Wall.Create(
                doc,
                linea,
                wallType.Id,
                nivel.Id,
                altura,
                baseOffset,
                false,
                false);
        }
        catch
        {
            muro = null;
        }

        if (muro == null)
            return null;

        try
        {
            Parameter pLineaUbicacion = muro.get_Parameter(BuiltInParameter.WALL_KEY_REF_PARAM);

            if (pLineaUbicacion != null && !pLineaUbicacion.IsReadOnly)
                pLineaUbicacion.Set(0); // Eje del muro.
        }
        catch
        {
        }

        // V13: dejar permitida la unión en ambos extremos del muro creado.
        // En versiones anteriores se bloqueaba la unión con DisallowWallJoinAtEnd,
        // por eso aparecía la opción "Permitir unión" al hacer clic derecho.
        try
        {
            WallUtils.AllowWallJoinAtEnd(muro, 0);
            WallUtils.AllowWallJoinAtEnd(muro, 1);
        }
        catch
        {
        }

        if (guardarParametros)
        {
            SetParametro(muro, "GEN_ID Elemento", muro.Id.Value.ToString());
            SetParametro(muro, "GEN_Disciplina", "Arquitectura");
        }

        return muro;
    }


    // =========================================================
    // V34 - AJUSTE AUTOMÁTICO TIPO TRIM / EXTEND EN QUIEBRES
    // =========================================================

    private List<Wall> ObtenerMurosDesdeIds(Document doc, List<ElementId> ids)
    {
        List<Wall> resultado = new List<Wall>();

        if (doc == null || ids == null)
            return resultado;

        foreach (ElementId id in ids)
        {
            if (id == null || id == ElementId.InvalidElementId)
                continue;

            try
            {
                Wall muro = doc.GetElement(id) as Wall;

                if (muro != null && muro.IsValidObject)
                    resultado.Add(muro);
            }
            catch
            {
            }
        }

        return resultado;
    }

    private void AjustarQuiebresYUnionesMurosCreados(Document doc, List<Wall> murosCreados)
    {
        if (doc == null || murosCreados == null || murosCreados.Count == 0)
            return;

        List<Wall> murosValidos = murosCreados
            .Where(x => x != null)
            .Where(x =>
            {
                try { return x.IsValidObject; }
                catch { return false; }
            })
            .ToList();

        if (murosValidos.Count == 0)
            return;

        List<Wall> candidatos = ObtenerMurosCandidatosParaTrim(doc, murosValidos);

        if (candidatos == null || candidatos.Count == 0)
            return;

        foreach (Wall muro in murosValidos)
        {
            try
            {
                AjustarExtremosDeMuroPorTrim(doc, muro, candidatos);
            }
            catch
            {
            }
        }

        foreach (Wall muro in murosValidos)
        {
            try
            {
                WallUtils.AllowWallJoinAtEnd(muro, 0);
                WallUtils.AllowWallJoinAtEnd(muro, 1);
            }
            catch
            {
            }
        }
    }

    private List<Wall> ObtenerMurosCandidatosParaTrim(Document doc, List<Wall> murosCreados)
    {
        List<Wall> resultado = new List<Wall>();

        if (doc == null)
            return resultado;

        HashSet<long> ids = new HashSet<long>();

        if (murosCreados != null)
        {
            foreach (Wall w in murosCreados)
            {
                if (w == null)
                    continue;

                try
                {
                    if (!ids.Contains(w.Id.Value))
                    {
                        ids.Add(w.Id.Value);
                        resultado.Add(w);
                    }
                }
                catch
                {
                }
            }
        }

        try
        {
            FilteredElementCollector collector = null;

            try
            {
                if (doc.ActiveView != null)
                    collector = new FilteredElementCollector(doc, doc.ActiveView.Id);
            }
            catch
            {
                collector = null;
            }

            if (collector == null)
                collector = new FilteredElementCollector(doc);

            collector.OfClass(typeof(Wall));
            collector.WhereElementIsNotElementType();

            foreach (Element e in collector)
            {
                Wall w = e as Wall;

                if (w == null)
                    continue;

                try
                {
                    if (!w.IsValidObject)
                        continue;

                    if (ids.Contains(w.Id.Value))
                        continue;

                    ids.Add(w.Id.Value);
                    resultado.Add(w);
                }
                catch
                {
                }
            }
        }
        catch
        {
        }

        return resultado;
    }

    private void AjustarExtremosDeMuroPorTrim(Document doc, Wall muro, List<Wall> candidatos)
    {
        if (doc == null || muro == null || candidatos == null || candidatos.Count == 0)
            return;

        LocationCurve loc = muro.Location as LocationCurve;

        if (loc == null)
            return;

        Line lineaMuro = loc.Curve as Line;

        if (lineaMuro == null)
            return;

        XYZ p0 = lineaMuro.GetEndPoint(0);
        XYZ p1 = lineaMuro.GetEndPoint(1);

        if (p0 == null || p1 == null)
            return;

        if (DistanciaXY(p0, p1) < LONGITUD_MINIMA_FRANJA)
            return;

        XYZ nuevoP0 = p0;
        XYZ nuevoP1 = p1;
        Wall muroUnion0 = null;
        Wall muroUnion1 = null;

        XYZ candidato0 = null;
        XYZ candidato1 = null;

        if (TryObtenerPuntoTrimParaExtremo(muro, lineaMuro, 0, candidatos, out candidato0, out muroUnion0))
            nuevoP0 = new XYZ(candidato0.X, candidato0.Y, p0.Z);

        if (TryObtenerPuntoTrimParaExtremo(muro, lineaMuro, 1, candidatos, out candidato1, out muroUnion1))
            nuevoP1 = new XYZ(candidato1.X, candidato1.Y, p1.Z);

        if (DistanciaXY(nuevoP0, nuevoP1) < LONGITUD_MINIMA_FRANJA)
            return;

        bool cambio = DistanciaXY(nuevoP0, p0) > MetrosAPies(0.001) || DistanciaXY(nuevoP1, p1) > MetrosAPies(0.001);

        if (cambio)
        {
            try
            {
                loc.Curve = Line.CreateBound(nuevoP0, nuevoP1);
            }
            catch
            {
            }
        }

        if (muroUnion0 != null)
            IntentarUnirMurosEnQuiebre(doc, muro, muroUnion0);

        if (muroUnion1 != null && muroUnion1.Id.Value != (muroUnion0 != null ? muroUnion0.Id.Value : -1))
            IntentarUnirMurosEnQuiebre(doc, muro, muroUnion1);
    }

    private bool TryObtenerPuntoTrimParaExtremo(
        Wall muro,
        Line lineaMuro,
        int extremo,
        List<Wall> candidatos,
        out XYZ puntoTrim,
        out Wall muroUnion)
    {
        puntoTrim = null;
        muroUnion = null;

        if (muro == null || lineaMuro == null || candidatos == null)
            return false;

        XYZ pExtremo = lineaMuro.GetEndPoint(extremo);
        XYZ pOtro = lineaMuro.GetEndPoint(extremo == 0 ? 1 : 0);

        if (pExtremo == null || pOtro == null)
            return false;

        XYZ dirMuro = new XYZ(pOtro.X - pExtremo.X, pOtro.Y - pExtremo.Y, 0.0);

        if (dirMuro.GetLength() < 0.0001)
            return false;

        dirMuro = dirMuro.Normalize();

        double mejorDistancia = double.MaxValue;
        XYZ mejorPunto = null;
        Wall mejorMuro = null;

        foreach (Wall candidato in candidatos)
        {
            if (candidato == null)
                continue;

            try
            {
                if (!candidato.IsValidObject)
                    continue;

                if (candidato.Id.Value == muro.Id.Value)
                    continue;
            }
            catch
            {
                continue;
            }

            if (!TieneSolapeZEntreMuros(muro, candidato))
                continue;

            LocationCurve locCand = candidato.Location as LocationCurve;

            if (locCand == null)
                continue;

            Line lineaCand = locCand.Curve as Line;

            if (lineaCand == null)
                continue;

            if (!LineasTienenAnguloValidoParaTrim(lineaMuro, lineaCand))
                continue;

            XYZ interseccion = null;

            if (!TryIntersecarLineasInfinitasXY(lineaMuro, lineaCand, out interseccion))
                continue;

            if (interseccion == null)
                continue;

            double distanciaExtremo = DistanciaXY(pExtremo, interseccion);

            if (distanciaExtremo > TOL_TRIM_QUIEBRE)
                continue;

            if (distanciaExtremo < MetrosAPies(0.001))
                continue;

            // El punto debe estar dentro o muy cerca del muro candidato.
            double distanciaASegmentoCandidato = DistanciaPuntoASegmentoXY(interseccion, lineaCand.GetEndPoint(0), lineaCand.GetEndPoint(1));

            if (distanciaASegmentoCandidato > TOL_BUSQUEDA_MURO_TRIM)
                continue;

            // Evita mover el extremo hacia un punto que está claramente hacia el interior del mismo muro.
            // Se permite extender o recortar solo si el cruce está cerca del extremo.
            if (!PuntoEstaCercaDeExtensionDelExtremo(lineaMuro, extremo, interseccion))
                continue;

            if (distanciaExtremo < mejorDistancia)
            {
                mejorDistancia = distanciaExtremo;
                mejorPunto = interseccion;
                mejorMuro = candidato;
            }
        }

        if (mejorPunto == null || mejorMuro == null)
            return false;

        puntoTrim = mejorPunto;
        muroUnion = mejorMuro;
        return true;
    }

    private bool PuntoEstaCercaDeExtensionDelExtremo(Line linea, int extremo, XYZ punto)
    {
        if (linea == null || punto == null)
            return false;

        XYZ p0 = linea.GetEndPoint(0);
        XYZ p1 = linea.GetEndPoint(1);

        if (p0 == null || p1 == null)
            return false;

        XYZ dir = new XYZ(p1.X - p0.X, p1.Y - p0.Y, 0.0);
        double len = dir.GetLength();

        if (len < 0.0001)
            return false;

        dir = dir.Normalize();

        double t = ((punto.X - p0.X) * dir.X) + ((punto.Y - p0.Y) * dir.Y);

        // t=0 es el inicio, t=len es el final. El punto de trim debe caer cerca
        // del extremo que se está ajustando, con margen para extender o recortar.
        if (extremo == 0)
            return t >= -TOL_TRIM_QUIEBRE && t <= TOL_TRIM_QUIEBRE;

        return t >= len - TOL_TRIM_QUIEBRE && t <= len + TOL_TRIM_QUIEBRE;
    }

    private bool LineasTienenAnguloValidoParaTrim(Line a, Line b)
    {
        if (a == null || b == null)
            return false;

        XYZ da = a.Direction;
        XYZ db = b.Direction;

        if (da == null || db == null)
            return false;

        da = new XYZ(da.X, da.Y, 0.0);
        db = new XYZ(db.X, db.Y, 0.0);

        if (da.GetLength() < 0.0001 || db.GetLength() < 0.0001)
            return false;

        da = da.Normalize();
        db = db.Normalize();

        double dot = Math.Abs(da.DotProduct(db));
        double cosMin = Math.Cos(ANGULO_MINIMO_TRIM_GRADOS * Math.PI / 180.0);

        // Si dot está muy cerca de 1, son casi paralelas y no corresponde trim de quiebre.
        return dot < cosMin;
    }

    private bool TryIntersecarLineasInfinitasXY(Line a, Line b, out XYZ punto)
    {
        punto = null;

        if (a == null || b == null)
            return false;

        XYZ p = a.GetEndPoint(0);
        XYZ r0 = a.GetEndPoint(1) - a.GetEndPoint(0);
        XYZ q = b.GetEndPoint(0);
        XYZ s0 = b.GetEndPoint(1) - b.GetEndPoint(0);

        XYZ r = new XYZ(r0.X, r0.Y, 0.0);
        XYZ s = new XYZ(s0.X, s0.Y, 0.0);

        double den = r.X * s.Y - r.Y * s.X;

        if (Math.Abs(den) < 1e-9)
            return false;

        double qpx = q.X - p.X;
        double qpy = q.Y - p.Y;
        double t = (qpx * s.Y - qpy * s.X) / den;

        punto = new XYZ(p.X + t * r.X, p.Y + t * r.Y, p.Z);
        return true;
    }

    private double DistanciaPuntoASegmentoXY(XYZ p, XYZ a, XYZ b)
    {
        if (p == null || a == null || b == null)
            return double.MaxValue;

        double vx = b.X - a.X;
        double vy = b.Y - a.Y;
        double wx = p.X - a.X;
        double wy = p.Y - a.Y;
        double len2 = vx * vx + vy * vy;

        if (len2 < 1e-12)
            return DistanciaXY(p, a);

        double t = (wx * vx + wy * vy) / len2;

        if (t < 0.0) t = 0.0;
        if (t > 1.0) t = 1.0;

        XYZ proy = new XYZ(a.X + t * vx, a.Y + t * vy, p.Z);
        return DistanciaXY(p, proy);
    }

    private bool TieneSolapeZEntreMuros(Wall a, Wall b)
    {
        if (a == null || b == null)
            return false;

        BoundingBoxXYZ bba = null;
        BoundingBoxXYZ bbb = null;

        try { bba = a.get_BoundingBox(null); } catch { bba = null; }
        try { bbb = b.get_BoundingBox(null); } catch { bbb = null; }

        if (bba == null || bbb == null)
            return true;

        double z1 = Math.Max(bba.Min.Z, bbb.Min.Z);
        double z2 = Math.Min(bba.Max.Z, bbb.Max.Z);

        return (z2 - z1) >= TOL_SOLAPE_Z_TRIM;
    }

    private void IntentarUnirMurosEnQuiebre(Document doc, Wall muroA, Wall muroB)
    {
        if (doc == null || muroA == null || muroB == null)
            return;

        try
        {
            if (!JoinGeometryUtils.AreElementsJoined(doc, muroA, muroB))
                JoinGeometryUtils.JoinGeometry(doc, muroA, muroB);
        }
        catch
        {
        }

        try
        {
            WallUtils.AllowWallJoinAtEnd(muroA, 0);
            WallUtils.AllowWallJoinAtEnd(muroA, 1);
            WallUtils.AllowWallJoinAtEnd(muroB, 0);
            WallUtils.AllowWallJoinAtEnd(muroB, 1);
        }
        catch
        {
        }
    }


    // =========================================================
    // V27 - INTERFERENCIAS VISIBLES, NATIVAS Y DE VÍNCULOS
    // =========================================================

    private FranjaTarrajeoMYG CrearFranjaDesdeSegmento(FranjaTarrajeoMYG origen, SegmentoFranjaMYG segmento)
    {
        if (origen == null || segmento == null)
            return null;

        if (segmento.UFin <= segmento.UInicio || segmento.ZTop <= segmento.ZBase)
            return null;

        FranjaTarrajeoMYG f = new FranjaTarrajeoMYG();
        f.Normal = origen.Normal;
        f.EjeU = origen.EjeU;
        f.PlaneDCara = origen.PlaneDCara;
        f.PlaneDCentroMuro = origen.PlaneDCentroMuro;
        f.UInicio = segmento.UInicio;
        f.UFin = segmento.UFin;
        f.ZBase = segmento.ZBase;
        f.ZTop = segmento.ZTop;
        f.CarasUsadas = origen.CarasUsadas;
        f.PuntoCentroPlano = CrearPuntoDesdePlano(
            (segmento.UInicio + segmento.UFin) / 2.0,
            (segmento.ZBase + segmento.ZTop) / 2.0,
            origen.EjeU,
            origen.Normal,
            origen.PlaneDCentroMuro);

        return f;
    }

    private List<InterferenciaTarrajeoMYG> ObtenerInterferenciasTarrajeoVisibles(
        Document doc,
        FranjaTarrajeoMYG franja,
        WallType wallType)
    {
        List<InterferenciaTarrajeoMYG> resultado = new List<InterferenciaTarrajeoMYG>();

        if (doc == null || franja == null || wallType == null || doc.ActiveView == null)
            return resultado;

        HashSet<string> clavesBase = ObtenerClavesElementosBaseSeleccionados();
        double espesor = ObtenerAnchoMuro(wallType);

        // 1) Elementos nativos visibles en la vista activa.
        try
        {
            FilteredElementCollector collectorHost = new FilteredElementCollector(doc, doc.ActiveView.Id);
            collectorHost.WhereElementIsNotElementType();

            foreach (Element elemento in collectorHost)
            {
                if (elemento == null)
                    continue;

                if (elemento is RevitLinkInstance)
                    continue;

                if (!EsElementoModeloParaInterferencia(elemento))
                    continue;

                string clave = "N|" + elemento.Id.Value.ToString();

                // Se excluyen los elementos base seleccionados para no descontar la propia albañilería.
                if (clavesBase.Contains(clave))
                    continue;

                AgregarInterferenciaDesdeElemento(
                    resultado,
                    elemento,
                    Transform.Identity,
                    franja,
                    espesor,
                    false,
                    ElementId.InvalidElementId,
                    elemento.Id);
            }
        }
        catch
        {
        }

        // V40 - Refuerzo para puertas/ventanas NATIVAS:
        // El collector por vista puede no traer todos los vanos si hay caja de sección,
        // filtros, estados temporales u otras condiciones. Para puertas/ventanas se
        // revisa todo el documento nativo y luego se filtra por cercanía contra la franja.
        try
        {
            List<Element> puertasVentanasNativas = ObtenerPuertasVentanasNativasVisiblesCacheadas(doc);

            if (puertasVentanasNativas != null)
            {
                foreach (Element pv in puertasVentanasNativas)
                {
                    if (pv == null)
                        continue;

                    string clavePv = "N|" + pv.Id.Value.ToString();

                    if (clavesBase.Contains(clavePv))
                        continue;

                    AgregarInterferenciaDesdeElemento(
                        resultado,
                        pv,
                        Transform.Identity,
                        franja,
                        espesor,
                        false,
                        ElementId.InvalidElementId,
                        pv.Id);
                }
            }
        }
        catch
        {
        }

        // 2) Elementos dentro de vínculos visibles como instancia en la vista activa.
        // La API no entrega con precisión todos los subelementos visibles por vista del vínculo,
        // por eso se toma cada vínculo visible y se revisan sus elementos modelados transformados a host.
        try
        {
            FilteredElementCollector collectorLinks = new FilteredElementCollector(doc, doc.ActiveView.Id);
            collectorLinks.OfClass(typeof(RevitLinkInstance));

            foreach (Element eLink in collectorLinks)
            {
                RevitLinkInstance link = eLink as RevitLinkInstance;

                if (link == null)
                    continue;

                Document docLink = ObtenerDocumentoVinculo(link);

                if (docLink == null)
                    continue;

                Transform transformLink = ObtenerTransformVinculo(link);

                FilteredElementCollector collectorDocLink = new FilteredElementCollector(docLink);
                collectorDocLink.WhereElementIsNotElementType();

                foreach (Element elementoLink in collectorDocLink)
                {
                    if (elementoLink == null)
                        continue;

                    if (!EsElementoModeloParaInterferencia(elementoLink))
                        continue;

                    string clave = "L|" + link.Id.Value.ToString() + "|" + elementoLink.Id.Value.ToString();

                    // Se excluyen los elementos base seleccionados para no descontar el muro anfitrión seleccionado.
                    if (clavesBase.Contains(clave))
                        continue;

                    AgregarInterferenciaDesdeElemento(
                        resultado,
                        elementoLink,
                        transformLink,
                        franja,
                        espesor,
                        true,
                        link.Id,
                        elementoLink.Id);
                }
            }
        }
        catch
        {
        }

        return UnirInterferenciasSimilares(resultado);
    }

    private void AgregarInterferenciaDesdeElemento(
        List<InterferenciaTarrajeoMYG> resultado,
        Element elemento,
        Transform transformacion,
        FranjaTarrajeoMYG franja,
        double espesorMuro,
        bool esVinculado,
        ElementId linkInstanceId,
        ElementId elementId)
    {
        if (resultado == null || elemento == null || franja == null || franja.Normal == null || franja.EjeU == null)
            return;

        // V40:
        // Puertas y ventanas tienen 2 caminos:
        // 1) Si son NATIVAS y tienen un muro anfitrión realmente cercano al tarrajeo,
        //    NO se cortan por perfil: se guardan como hueco de anfitrión para unir geometría.
        // 2) Si el anfitrión no existe, está lejos, pertenece a vínculo, o no puede servir
        //    como cortante, NO se crea NewOpening. Se agrega como interferencia normal
        //    para que el tarrajeo se cree recortado por su perfil U-Z.
        if (EsPuertaOVentana(elemento))
        {
            bool usarUnionConAnfitrion = false;

            try
            {
                if (!esVinculado)
                    usarUnionConAnfitrion = PuertaVentanaTieneAnfitrionNativoCercanoParaUnir(elemento, franja);
            }
            catch
            {
                usarUnionConAnfitrion = false;
            }

            if (usarUnionConAnfitrion)
            {
                AgregarHuecoPuertaVentanaDesdeBoundingBox(
                    resultado,
                    elemento,
                    transformacion,
                    franja,
                    espesorMuro,
                    esVinculado,
                    linkInstanceId,
                    elementId);
            }
            else
            {
                AgregarRecortePerfilPuertaVentanaDesdeBoundingBox(
                    resultado,
                    elemento,
                    transformacion,
                    franja,
                    espesorMuro,
                    esVinculado,
                    linkInstanceId,
                    elementId);
            }

            return;
        }

        // V35 OPT:
        // Antes de leer sólidos y hacer booleanas, se hace un filtro rápido por BoundingBox.
        // El BoundingBox NO decide el corte final; solo evita procesar elementos que están lejos.
        if (!ElementoPuedeCruzarFranjaPorBoundingBoxRapido(elemento, transformacion, franja, espesorMuro))
            return;

        // V30:
        // Antes se usaba solo el BoundingBox del elemento. Eso generaba falsos positivos,
        // porque un bbox puede cruzar el plano del tarrajeo aunque el sólido real no toque nada.
        // Ahora se crea una envolvente del tarrajeo y se hace intersección booleana contra
        // los sólidos reales del elemento nativo o vinculado.
        Solid solidoEnvolvente = CrearSolidoEnvolventeFranja(franja, espesorMuro);

        if (solidoEnvolvente == null)
            return;

        List<Solid> solidosElemento = ObtenerSolidosElementoHost(elemento, transformacion);

        if (solidosElemento == null || solidosElemento.Count == 0)
            return;

        foreach (Solid solido in solidosElemento)
        {
            if (solido == null)
                continue;

            try
            {
                if (solido.Volume <= 0.0000001)
                    continue;
            }
            catch
            {
            }

            Solid interseccion = null;

            try
            {
                interseccion = BooleanOperationsUtils.ExecuteBooleanOperation(
                    solidoEnvolvente,
                    solido,
                    BooleanOperationsType.Intersect);
            }
            catch
            {
                interseccion = null;
            }

            if (interseccion == null)
                continue;

            double volumen = 0.0;

            try
            {
                volumen = interseccion.Volume;
            }
            catch
            {
                volumen = 0.0;
            }

            if (volumen <= 0.0000001)
                continue;

            AgregarInterferenciaDesdeSolidoIntersectado(
                resultado,
                elemento,
                interseccion,
                franja,
                esVinculado,
                linkInstanceId,
                elementId);
        }
    }


    private void AgregarHuecoPuertaVentanaDesdeBoundingBox(
        List<InterferenciaTarrajeoMYG> resultado,
        Element elemento,
        Transform transformacion,
        FranjaTarrajeoMYG franja,
        double espesorMuro,
        bool esVinculado,
        ElementId linkInstanceId,
        ElementId elementId)
    {
        if (resultado == null || elemento == null || franja == null || franja.Normal == null || franja.EjeU == null)
            return;

        List<XYZ> puntos = ObtenerPuntosBoundingBoxHost(elemento, transformacion);

        if (puntos == null || puntos.Count == 0)
            return;

        double minU = double.MaxValue;
        double maxU = double.MinValue;
        double minZ = double.MaxValue;
        double maxZ = double.MinValue;
        double minD = double.MaxValue;
        double maxD = double.MinValue;

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            double u = p.DotProduct(franja.EjeU);
            double z = p.Z;
            double d = p.DotProduct(franja.Normal);

            if (u < minU) minU = u;
            if (u > maxU) maxU = u;
            if (z < minZ) minZ = z;
            if (z > maxZ) maxZ = z;
            if (d < minD) minD = d;
            if (d > maxD) maxD = d;
        }

        if (minU == double.MaxValue || maxU == double.MinValue || minZ == double.MaxValue || maxZ == double.MinValue)
            return;

        double toleranciaPlano = Math.Max(TOL_INTERFERENCIA_PLANO, espesorMuro + TOL_INTERFERENCIA_BORDE);
        double dMinEval = franja.PlaneDCara - toleranciaPlano;
        double dMaxEval = franja.PlaneDCara + espesorMuro + toleranciaPlano;

        if (maxD < dMinEval)
            return;

        if (minD > dMaxEval)
            return;

        double margenHueco = Math.Max(TOL_INTERFERENCIA_BORDE, MetrosAPies(0.005));
        double u1 = Math.Max(minU - margenHueco, franja.UInicio);
        double u2 = Math.Min(maxU + margenHueco, franja.UFin);
        double z1 = Math.Max(minZ - margenHueco, franja.ZBase);
        double z2 = Math.Min(maxZ + margenHueco, franja.ZTop);

        if ((u2 - u1) < ANCHO_MINIMO_CARA)
            return;

        if ((z2 - z1) < ALTO_MINIMO_CARA)
            return;

        InterferenciaTarrajeoMYG hueco = new InterferenciaTarrajeoMYG();
        hueco.UInicio = u1;
        hueco.UFin = u2;
        hueco.ZBase = z1;
        hueco.ZTop = z2;
        hueco.EsVinculado = esVinculado;
        hueco.LinkInstanceId = linkInstanceId;
        hueco.ElementId = elementId;
        hueco.EsHuecoAnfitrion = true;
        hueco.HostElementId = ObtenerHostIdPuertaVentana(elemento);

        try
        {
            hueco.Nombre = ObtenerCategoriaElemento(elemento) + " - " + ObtenerNombreElemento(elemento);
        }
        catch
        {
            hueco.Nombre = "Puerta/Ventana";
        }

        resultado.Add(hueco);
    }


    private void AgregarRecortePerfilPuertaVentanaDesdeBoundingBox(
        List<InterferenciaTarrajeoMYG> resultado,
        Element elemento,
        Transform transformacion,
        FranjaTarrajeoMYG franja,
        double espesorMuro,
        bool esVinculado,
        ElementId linkInstanceId,
        ElementId elementId)
    {
        if (resultado == null || elemento == null || franja == null || franja.Normal == null || franja.EjeU == null)
            return;

        List<XYZ> puntos = ObtenerPuntosBoundingBoxHost(elemento, transformacion);

        if (puntos == null || puntos.Count == 0)
            return;

        double minU = double.MaxValue;
        double maxU = double.MinValue;
        double minZ = double.MaxValue;
        double maxZ = double.MinValue;
        double minD = double.MaxValue;
        double maxD = double.MinValue;

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            double u = p.DotProduct(franja.EjeU);
            double z = p.Z;
            double d = p.DotProduct(franja.Normal);

            if (u < minU) minU = u;
            if (u > maxU) maxU = u;
            if (z < minZ) minZ = z;
            if (z > maxZ) maxZ = z;
            if (d < minD) minD = d;
            if (d > maxD) maxD = d;
        }

        if (minU == double.MaxValue || maxU == double.MinValue || minZ == double.MaxValue || maxZ == double.MinValue)
            return;

        // El vano debe tocar la franja del tarrajeo. Se evalúa como envolvente U-Z-D,
        // pero no se genera ningún Opening nativo de Revit.
        double toleranciaPlano = Math.Max(TOL_INTERFERENCIA_PLANO, espesorMuro + TOL_INTERFERENCIA_BORDE);
        double dMinEval = franja.PlaneDCara - toleranciaPlano;
        double dMaxEval = franja.PlaneDCara + espesorMuro + toleranciaPlano;

        if (maxD < dMinEval)
            return;

        if (minD > dMaxEval)
            return;

        // Margen pequeño para que el perfil no quede mordiéndose con el marco/hoja.
        // No es un Hueco de muro: solo genera segmentos de tarrajeo alrededor del vano.
        double margenPerfil = Math.Max(TOL_INTERFERENCIA_BORDE, MetrosAPies(0.01));
        double u1 = Math.Max(minU - margenPerfil, franja.UInicio);
        double u2 = Math.Min(maxU + margenPerfil, franja.UFin);
        double z1 = Math.Max(minZ - margenPerfil, franja.ZBase);
        double z2 = Math.Min(maxZ + margenPerfil, franja.ZTop);

        if ((u2 - u1) < ANCHO_MINIMO_CARA)
            return;

        if ((z2 - z1) < ALTO_MINIMO_CARA)
            return;

        InterferenciaTarrajeoMYG recorte = new InterferenciaTarrajeoMYG();
        recorte.UInicio = u1;
        recorte.UFin = u2;
        recorte.ZBase = z1;
        recorte.ZTop = z2;
        recorte.EsVinculado = esVinculado;
        recorte.LinkInstanceId = linkInstanceId;
        recorte.ElementId = elementId;
        recorte.EsHuecoAnfitrion = false;
        recorte.HostElementId = ObtenerHostIdPuertaVentana(elemento);

        try
        {
            recorte.Nombre = "RECORTE PERFIL PV - " + ObtenerCategoriaElemento(elemento) + " - " + ObtenerNombreElemento(elemento);
        }
        catch
        {
            recorte.Nombre = "RECORTE PERFIL PUERTA/VENTANA";
        }

        resultado.Add(recorte);
    }

    private bool PuertaVentanaTieneAnfitrionNativoCercanoParaUnir(Element puertaVentana, FranjaTarrajeoMYG franja)
    {
        if (puertaVentana == null || franja == null)
            return false;

        Document doc = null;

        try
        {
            doc = puertaVentana.Document;
        }
        catch
        {
            doc = null;
        }

        if (doc == null)
            return false;

        ElementId hostId = ObtenerHostIdPuertaVentana(puertaVentana);

        if (hostId == null || hostId == ElementId.InvalidElementId)
            return false;

        Element anfitrion = null;

        try
        {
            anfitrion = doc.GetElement(hostId);
        }
        catch
        {
            anfitrion = null;
        }

        if (anfitrion == null)
            return false;

        try
        {
            if (anfitrion.Document == null || !anfitrion.Document.Equals(doc))
                return false;
        }
        catch
        {
            return false;
        }

        // Si el anfitrión está lejos del plano del tarrajeo, unir geometría no va a propagar
        // el vano. En ese caso se usa el recorte por perfil del vano, no JoinGeometry.
        if (!PuertaVentanaEstaCercaDeFranja(puertaVentana, anfitrion, franja))
            return false;

        return true;
    }

    private Solid CrearSolidoEnvolventeFranja(FranjaTarrajeoMYG franja, double espesorMuro)
    {
        if (franja == null || franja.EjeU == null || franja.Normal == null)
            return null;

        if (franja.UFin <= franja.UInicio || franja.ZTop <= franja.ZBase)
            return null;

        double margenU = TOL_INTERFERENCIA_BORDE;
        double margenZ = TOL_INTERFERENCIA_BORDE;
        double margenD = TOL_INTERFERENCIA_PLANO;

        double u0 = franja.UInicio - margenU;
        double u1 = franja.UFin + margenU;
        double z0 = franja.ZBase - margenZ;
        double z1 = franja.ZTop + margenZ;
        double d0 = franja.PlaneDCara - margenD;
        double d1 = franja.PlaneDCara + espesorMuro + margenD;

        if (u1 <= u0 || z1 <= z0 || d1 <= d0)
            return null;

        XYZ p0 = CrearPuntoDesdePlano(u0, z0, franja.EjeU, franja.Normal, d0);
        XYZ p1 = CrearPuntoDesdePlano(u1, z0, franja.EjeU, franja.Normal, d0);
        XYZ p2 = CrearPuntoDesdePlano(u1, z0, franja.EjeU, franja.Normal, d1);
        XYZ p3 = CrearPuntoDesdePlano(u0, z0, franja.EjeU, franja.Normal, d1);

        if (p0 == null || p1 == null || p2 == null || p3 == null)
            return null;

        try
        {
            CurveLoop loop = new CurveLoop();
            loop.Append(Line.CreateBound(p0, p1));
            loop.Append(Line.CreateBound(p1, p2));
            loop.Append(Line.CreateBound(p2, p3));
            loop.Append(Line.CreateBound(p3, p0));

            List<CurveLoop> loops = new List<CurveLoop>();
            loops.Add(loop);

            return GeometryCreationUtilities.CreateExtrusionGeometry(loops, XYZ.BasisZ, z1 - z0);
        }
        catch
        {
            return null;
        }
    }

    private List<Solid> ObtenerSolidosElementoHost(Element elemento, Transform transformacionBase)
    {
        List<Solid> resultado = new List<Solid>();

        if (elemento == null)
            return resultado;

        if (transformacionBase == null)
            transformacionBase = Transform.Identity;

        Options opt = new Options();
        opt.ComputeReferences = false;
        opt.IncludeNonVisibleObjects = false;
        opt.DetailLevel = ViewDetailLevel.Fine;

        GeometryElement geo = null;

        try
        {
            geo = elemento.get_Geometry(opt);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return resultado;

        RecorrerGeometriaParaSolidosHost(geo, transformacionBase, resultado);

        return resultado;
    }

    private void RecorrerGeometriaParaSolidosHost(GeometryElement geo, Transform transformacion, List<Solid> resultado)
    {
        if (geo == null || transformacion == null || resultado == null)
            return;

        foreach (GeometryObject obj in geo)
        {
            if (obj == null)
                continue;

            Solid solid = obj as Solid;

            if (solid != null)
            {
                try
                {
                    if (solid.Faces == null || solid.Faces.Size == 0)
                        continue;

                    if (solid.Volume <= 0.0000001)
                        continue;

                    Solid solidHost = SolidUtils.CreateTransformed(solid, transformacion);

                    if (solidHost != null)
                        resultado.Add(solidHost);
                }
                catch
                {
                }

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi != null)
            {
                GeometryElement geoInst = null;

                try
                {
                    geoInst = gi.GetSymbolGeometry();
                }
                catch
                {
                    geoInst = null;
                }

                if (geoInst == null)
                    continue;

                Transform trfInst = transformacion.Multiply(gi.Transform);
                RecorrerGeometriaParaSolidosHost(geoInst, trfInst, resultado);
            }
        }
    }

    private void AgregarInterferenciaDesdeSolidoIntersectado(
        List<InterferenciaTarrajeoMYG> resultado,
        Element elemento,
        Solid solidoInterseccion,
        FranjaTarrajeoMYG franja,
        bool esVinculado,
        ElementId linkInstanceId,
        ElementId elementId)
    {
        if (resultado == null || elemento == null || solidoInterseccion == null || franja == null)
            return;

        List<XYZ> puntos = ObtenerPuntosSolido(solidoInterseccion);

        if (puntos == null || puntos.Count == 0)
            return;

        double minU = double.MaxValue;
        double maxU = double.MinValue;
        double minZ = double.MaxValue;
        double maxZ = double.MinValue;

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            double u = p.DotProduct(franja.EjeU);
            double z = p.Z;

            if (u < minU) minU = u;
            if (u > maxU) maxU = u;
            if (z < minZ) minZ = z;
            if (z > maxZ) maxZ = z;
        }

        if (minU == double.MaxValue || maxU == double.MinValue || minZ == double.MaxValue || maxZ == double.MinValue)
            return;

        double u1 = Math.Max(minU, franja.UInicio);
        double u2 = Math.Min(maxU, franja.UFin);
        double z1 = Math.Max(minZ, franja.ZBase);
        double z2 = Math.Min(maxZ, franja.ZTop);

        if ((u2 - u1) < ANCHO_MINIMO_CARA)
            return;

        if ((z2 - z1) < ALTO_MINIMO_CARA)
            return;

        InterferenciaTarrajeoMYG interferencia = new InterferenciaTarrajeoMYG();
        interferencia.UInicio = u1;
        interferencia.UFin = u2;
        interferencia.ZBase = z1;
        interferencia.ZTop = z2;
        interferencia.EsVinculado = esVinculado;
        interferencia.LinkInstanceId = linkInstanceId;
        interferencia.ElementId = elementId;

        try
        {
            interferencia.Nombre = ObtenerCategoriaElemento(elemento) + " - " + ObtenerNombreElemento(elemento);
        }
        catch
        {
            interferencia.Nombre = "Interferencia";
        }

        resultado.Add(interferencia);
    }

    private List<XYZ> ObtenerPuntosSolido(Solid solid)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (solid == null || solid.Faces == null || solid.Faces.Size == 0)
            return puntos;

        try
        {
            foreach (Face face in solid.Faces)
            {
                if (face == null)
                    continue;

                IList<CurveLoop> loops = null;

                try
                {
                    loops = face.GetEdgesAsCurveLoops();
                }
                catch
                {
                    loops = null;
                }

                if (loops == null)
                    continue;

                foreach (CurveLoop loop in loops)
                {
                    if (loop == null)
                        continue;

                    foreach (Curve curve in loop)
                    {
                        if (curve == null)
                            continue;

                        IList<XYZ> tess = null;

                        try
                        {
                            tess = curve.Tessellate();
                        }
                        catch
                        {
                            tess = null;
                        }

                        if (tess != null && tess.Count > 0)
                        {
                            foreach (XYZ p in tess)
                                AgregarPuntoSinDuplicar(puntos, p);
                        }
                        else
                        {
                            try { AgregarPuntoSinDuplicar(puntos, curve.GetEndPoint(0)); } catch { }
                            try { AgregarPuntoSinDuplicar(puntos, curve.GetEndPoint(1)); } catch { }
                        }
                    }
                }
            }
        }
        catch
        {
        }

        return puntos;
    }

    private List<XYZ> ObtenerPuntosBoundingBoxHost(Element elemento, Transform transformacion)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (elemento == null)
            return puntos;

        if (transformacion == null)
            transformacion = Transform.Identity;

        BoundingBoxXYZ bb = null;

        try
        {
            bb = elemento.get_BoundingBox(null);
        }
        catch
        {
            bb = null;
        }

        if (bb == null)
            return puntos;

        Transform trfBB = null;

        try
        {
            trfBB = bb.Transform;
        }
        catch
        {
            trfBB = Transform.Identity;
        }

        if (trfBB == null)
            trfBB = Transform.Identity;

        XYZ min = bb.Min;
        XYZ max = bb.Max;

        if (min == null || max == null)
            return puntos;

        XYZ[] locales = new XYZ[]
        {
            new XYZ(min.X, min.Y, min.Z),
            new XYZ(max.X, min.Y, min.Z),
            new XYZ(min.X, max.Y, min.Z),
            new XYZ(max.X, max.Y, min.Z),
            new XYZ(min.X, min.Y, max.Z),
            new XYZ(max.X, min.Y, max.Z),
            new XYZ(min.X, max.Y, max.Z),
            new XYZ(max.X, max.Y, max.Z)
        };

        foreach (XYZ pLocal in locales)
        {
            try
            {
                XYZ pDoc = trfBB.OfPoint(pLocal);
                XYZ pHost = transformacion.OfPoint(pDoc);
                puntos.Add(pHost);
            }
            catch
            {
            }
        }

        return puntos;
    }

    private HashSet<string> ObtenerClavesElementosBaseSeleccionados()
    {
        HashSet<string> claves = new HashSet<string>();

        if (Form == null || Form.ElementosSeleccionados == null)
            return claves;

        foreach (CrearTarrajeoInteriorConfinamientoForm.ElementoTarrajeoBaseMYG item in Form.ElementosSeleccionados)
        {
            if (item == null)
                continue;

            try
            {
                if (item.EsVinculado)
                {
                    if (item.LinkInstanceId != null && item.LinkedElementId != null)
                        claves.Add("L|" + item.LinkInstanceId.Value.ToString() + "|" + item.LinkedElementId.Value.ToString());
                }
                else
                {
                    if (item.ElementIdNativo != null)
                        claves.Add("N|" + item.ElementIdNativo.Value.ToString());
                }
            }
            catch
            {
            }
        }

        return claves;
    }


    private bool EsPuertaOVentana(Element elemento)
    {
        if (elemento == null || elemento.Category == null)
            return false;

        try
        {
            long catId = elemento.Category.Id.Value;

            if (catId == (long)BuiltInCategory.OST_Doors)
                return true;

            if (catId == (long)BuiltInCategory.OST_Windows)
                return true;
        }
        catch
        {
        }

        return false;
    }

    private ElementId ObtenerHostIdPuertaVentana(Element elemento)
    {
        if (elemento == null)
            return ElementId.InvalidElementId;

        FamilyInstance fi = elemento as FamilyInstance;

        if (fi == null)
            return ElementId.InvalidElementId;

        Element host = null;

        try
        {
            host = fi.Host;
        }
        catch
        {
            host = null;
        }

        if (host == null)
            return ElementId.InvalidElementId;

        try
        {
            return host.Id;
        }
        catch
        {
            return ElementId.InvalidElementId;
        }
    }

    private bool EsElementoModeloParaInterferencia(Element elemento)
    {
        if (elemento == null || elemento.Category == null)
            return false;

        if (elemento is ElementType)
            return false;

        if (elemento is View)
            return false;

        if (elemento is Level)
            return false;

        if (elemento is RevitLinkInstance)
            return false;

        try
        {
            if (elemento.Category.CategoryType != CategoryType.Model)
                return false;
        }
        catch
        {
            return false;
        }

        // Evita categorías claramente no físicas que igual son Model.
        try
        {
            BuiltInCategory bic = (BuiltInCategory)elemento.Category.Id.Value;

            if (bic == BuiltInCategory.OST_Cameras ||
                bic == BuiltInCategory.OST_Grids ||
                bic == BuiltInCategory.OST_Levels ||
                bic == BuiltInCategory.OST_RvtLinks)
                return false;
        }
        catch
        {
        }

        return true;
    }

    private List<InterferenciaTarrajeoMYG> UnirInterferenciasSimilares(List<InterferenciaTarrajeoMYG> interferencias)
    {
        List<InterferenciaTarrajeoMYG> resultado = new List<InterferenciaTarrajeoMYG>();

        if (interferencias == null || interferencias.Count == 0)
            return resultado;

        List<InterferenciaTarrajeoMYG> ordenadas = interferencias
            .Where(x => x != null && x.UFin > x.UInicio && x.ZTop > x.ZBase)
            .OrderBy(x => x.UInicio)
            .ThenBy(x => x.ZBase)
            .ToList();

        foreach (InterferenciaTarrajeoMYG actual in ordenadas)
        {
            // V31: puertas/ventanas se conservan como huecos independientes.
            // No se deben unir con otras interferencias, porque eso puede agrandar
            // el hueco o volver a partir el tarrajeo.
            if (actual.EsHuecoAnfitrion)
            {
                resultado.Add(actual);
                continue;
            }

            bool unido = false;

            foreach (InterferenciaTarrajeoMYG existente in resultado)
            {
                if (existente == null)
                    continue;

                if (existente.EsHuecoAnfitrion)
                    continue;

                bool solapeU = actual.UInicio <= existente.UFin + TOL_INTERFERENCIA_BORDE &&
                               actual.UFin >= existente.UInicio - TOL_INTERFERENCIA_BORDE;

                bool solapeZ = actual.ZBase <= existente.ZTop + TOL_INTERFERENCIA_BORDE &&
                               actual.ZTop >= existente.ZBase - TOL_INTERFERENCIA_BORDE;

                if (solapeU && solapeZ)
                {
                    existente.UInicio = Math.Min(existente.UInicio, actual.UInicio);
                    existente.UFin = Math.Max(existente.UFin, actual.UFin);
                    existente.ZBase = Math.Min(existente.ZBase, actual.ZBase);
                    existente.ZTop = Math.Max(existente.ZTop, actual.ZTop);
                    unido = true;
                    break;
                }
            }

            if (!unido)
                resultado.Add(actual);
        }

        return resultado;
    }

    private List<SegmentoFranjaMYG> CrearSegmentosPorInterferenciasSeguro(
        FranjaTarrajeoMYG franja,
        List<InterferenciaTarrajeoMYG> interferencias)
    {
        List<SegmentoFranjaMYG> segmentos = new List<SegmentoFranjaMYG>();

        if (franja == null)
            return segmentos;

        SegmentoFranjaMYG inicial = new SegmentoFranjaMYG();
        inicial.UInicio = franja.UInicio;
        inicial.UFin = franja.UFin;
        inicial.ZBase = franja.ZBase;
        inicial.ZTop = franja.ZTop;
        inicial.Aberturas = new List<InterferenciaTarrajeoMYG>();
        segmentos.Add(inicial);

        if (interferencias == null || interferencias.Count == 0)
            return segmentos;

        // V30:
        // Se resta cada interferencia como un rectángulo U-Z.
        // Esto evita usar NewOpening para cortes que nacen en la base o pegan a un borde.
        // El resultado son varios muros rectangulares, separados alrededor del sólido real.
        foreach (InterferenciaTarrajeoMYG interferencia in interferencias.OrderBy(x => x.UInicio).ThenBy(x => x.ZBase))
        {
            if (interferencia == null)
                continue;

            // V31: las puertas/ventanas no deben dividir el tarrajeo en pedazos.
            // Se procesan luego como huecos de su anfitrión.
            if (interferencia.EsHuecoAnfitrion)
                continue;

            List<SegmentoFranjaMYG> nuevos = new List<SegmentoFranjaMYG>();

            foreach (SegmentoFranjaMYG segmento in segmentos)
            {
                if (segmento == null)
                    continue;

                RestarInterferenciaASegmento(segmento, interferencia, nuevos);
            }

            segmentos = nuevos
                .Where(x => x != null &&
                            (x.UFin - x.UInicio) >= LONGITUD_MINIMA_FRANJA &&
                            (x.ZTop - x.ZBase) >= ALTURA_MINIMA_FRANJA)
                .ToList();

            if (segmentos.Count == 0)
                break;
        }

        return UnirSegmentosRectangulares(segmentos);
    }

    private void RestarInterferenciaASegmento(
        SegmentoFranjaMYG segmento,
        InterferenciaTarrajeoMYG interferencia,
        List<SegmentoFranjaMYG> resultado)
    {
        if (segmento == null || interferencia == null || resultado == null)
            return;

        double u1 = Math.Max(segmento.UInicio, interferencia.UInicio - TOL_INTERFERENCIA_BORDE);
        double u2 = Math.Min(segmento.UFin, interferencia.UFin + TOL_INTERFERENCIA_BORDE);
        double z1 = Math.Max(segmento.ZBase, interferencia.ZBase - TOL_INTERFERENCIA_BORDE);
        double z2 = Math.Min(segmento.ZTop, interferencia.ZTop + TOL_INTERFERENCIA_BORDE);

        if ((u2 - u1) < ANCHO_MINIMO_CARA || (z2 - z1) < ALTO_MINIMO_CARA)
        {
            resultado.Add(segmento);
            return;
        }

        // Izquierda: todo lo que queda antes del sólido.
        if ((u1 - segmento.UInicio) >= LONGITUD_MINIMA_FRANJA)
        {
            SegmentoFranjaMYG izq = CopiarSegmento(segmento);
            izq.UFin = u1;
            resultado.Add(izq);
        }

        // Derecha: todo lo que queda después del sólido.
        if ((segmento.UFin - u2) >= LONGITUD_MINIMA_FRANJA)
        {
            SegmentoFranjaMYG der = CopiarSegmento(segmento);
            der.UInicio = u2;
            resultado.Add(der);
        }

        // Inferior: solo bajo el sólido, si el sólido no nace desde la base.
        if ((z1 - segmento.ZBase) >= ALTURA_MINIMA_FRANJA)
        {
            SegmentoFranjaMYG inf = CopiarSegmento(segmento);
            inf.UInicio = u1;
            inf.UFin = u2;
            inf.ZTop = z1;
            resultado.Add(inf);
        }

        // Superior: solo sobre el sólido, si el sólido no llega al tope.
        if ((segmento.ZTop - z2) >= ALTURA_MINIMA_FRANJA)
        {
            SegmentoFranjaMYG sup = CopiarSegmento(segmento);
            sup.UInicio = u1;
            sup.UFin = u2;
            sup.ZBase = z2;
            resultado.Add(sup);
        }
    }

    private List<SegmentoFranjaMYG> UnirSegmentosRectangulares(List<SegmentoFranjaMYG> segmentos)
    {
        List<SegmentoFranjaMYG> resultado = new List<SegmentoFranjaMYG>();

        if (segmentos == null || segmentos.Count == 0)
            return resultado;

        List<SegmentoFranjaMYG> lista = segmentos
            .Where(x => x != null && x.UFin > x.UInicio && x.ZTop > x.ZBase)
            .OrderBy(x => x.ZBase)
            .ThenBy(x => x.ZTop)
            .ThenBy(x => x.UInicio)
            .ToList();

        foreach (SegmentoFranjaMYG s in lista)
        {
            bool unido = false;

            foreach (SegmentoFranjaMYG r in resultado)
            {
                if (r == null)
                    continue;

                bool mismaBandaZ = Math.Abs(r.ZBase - s.ZBase) <= TOL_INTERFERENCIA_BORDE &&
                                   Math.Abs(r.ZTop - s.ZTop) <= TOL_INTERFERENCIA_BORDE;

                bool tocaU = s.UInicio <= r.UFin + TOL_INTERFERENCIA_BORDE &&
                             s.UFin >= r.UInicio - TOL_INTERFERENCIA_BORDE;

                if (mismaBandaZ && tocaU)
                {
                    r.UInicio = Math.Min(r.UInicio, s.UInicio);
                    r.UFin = Math.Max(r.UFin, s.UFin);
                    unido = true;
                    break;
                }
            }

            if (!unido)
                resultado.Add(s);
        }

        return resultado;
    }

    private SegmentoFranjaMYG CopiarSegmento(SegmentoFranjaMYG origen)
    {
        SegmentoFranjaMYG copia = new SegmentoFranjaMYG();

        if (origen == null)
            return copia;

        copia.UInicio = origen.UInicio;
        copia.UFin = origen.UFin;
        copia.ZBase = origen.ZBase;
        copia.ZTop = origen.ZTop;
        copia.Aberturas = new List<InterferenciaTarrajeoMYG>();

        if (origen.Aberturas != null)
            copia.Aberturas.AddRange(origen.Aberturas);

        return copia;
    }


    // V40: Para puertas/ventanas que SÍ tienen anfitrión nativo cercano, este método
    // solo une geometría. No crea NewOpening ni "Hueco de muro recto rectangular".
    // Si un vano no tiene anfitrión cercano, ya fue convertido antes en interferencia
    // normal para recortar el perfil del tarrajeo al crearlo.
    private void AplicarPuertasVentanasComoHuecosDeAnfitrion(
        Document doc,
        Wall muroTarrajeo,
        FranjaTarrajeoMYG franjaSegmento,
        List<InterferenciaTarrajeoMYG> interferencias)
    {
        if (doc == null || muroTarrajeo == null || franjaSegmento == null || interferencias == null)
            return;

        foreach (InterferenciaTarrajeoMYG hueco in interferencias)
        {
            if (hueco == null || !hueco.EsHuecoAnfitrion)
                continue;

            if (hueco.EsVinculado)
                continue;

            double u1 = Math.Max(franjaSegmento.UInicio, hueco.UInicio);
            double u2 = Math.Min(franjaSegmento.UFin, hueco.UFin);
            double z1 = Math.Max(franjaSegmento.ZBase, hueco.ZBase);
            double z2 = Math.Min(franjaSegmento.ZTop, hueco.ZTop);

            if ((u2 - u1) < ANCHO_MINIMO_CARA)
                continue;

            if ((z2 - z1) < ALTO_MINIMO_CARA)
                continue;

            try
            {
                IntentarUnirTarrajeoConAnfitrionNativo(doc, muroTarrajeo, hueco);
            }
            catch
            {
            }
        }
    }

    private bool IntentarUnirTarrajeoConAnfitrionNativo(
        Document doc,
        Wall muroTarrajeo,
        InterferenciaTarrajeoMYG hueco)
    {
        if (doc == null || muroTarrajeo == null || hueco == null)
            return false;

        if (!hueco.EsHuecoAnfitrion)
            return false;

        // No se puede unir geometría contra elementos dentro de un vínculo Revit.
        if (hueco.EsVinculado)
            return false;

        if (hueco.HostElementId == null || hueco.HostElementId == ElementId.InvalidElementId)
            return false;

        Element anfitrion = null;

        try
        {
            anfitrion = doc.GetElement(hueco.HostElementId);
        }
        catch
        {
            anfitrion = null;
        }

        if (anfitrion == null)
            return false;

        try
        {
            bool yaUnidos = false;

            try
            {
                yaUnidos = JoinGeometryUtils.AreElementsJoined(doc, anfitrion, muroTarrajeo);
            }
            catch
            {
                yaUnidos = false;
            }

            if (!yaUnidos)
                JoinGeometryUtils.JoinGeometry(doc, anfitrion, muroTarrajeo);

            // Forzar el orden correcto: el muro anfitrión debe ser el elemento
            // que corta al tarrajeo, no al revés. Esto replica mejor el flujo manual
            // de Unir geometría que mostraste en la imagen.
            try
            {
                if (JoinGeometryUtils.AreElementsJoined(doc, anfitrion, muroTarrajeo))
                {
                    bool anfitrionCorta = false;

                    try
                    {
                        anfitrionCorta = JoinGeometryUtils.IsCuttingElementInJoin(doc, anfitrion, muroTarrajeo);
                    }
                    catch
                    {
                        anfitrionCorta = true;
                    }

                    if (!anfitrionCorta)
                    {
                        try
                        {
                            JoinGeometryUtils.SwitchJoinOrder(doc, anfitrion, muroTarrajeo);
                        }
                        catch
                        {
                        }
                    }
                }
            }
            catch
            {
            }

            return true;
        }
        catch
        {
            return false;
        }
    }


    // V33:
    // Busca puertas y ventanas NATIVAS cercanas al muro de tarrajeo recién creado
    // y une el tarrajeo con el muro anfitrión de cada una. No crea huecos.
    // V37:
    // Busca puertas y ventanas NATIVAS cercanas al muro de tarrajeo recién creado,
    // obtiene sus muros anfitriones y une el tarrajeo con esos anfitriones.
    // Esta versión no depende de que la puerta/ventana haya sido detectada antes como interferencia.
    private void UnirTarrajeoConAnfitrionesPuertasVentanasCercanas(
        Document doc,
        Wall muroTarrajeo,
        FranjaTarrajeoMYG franja)
    {
        if (doc == null || muroTarrajeo == null || franja == null)
            return;

        List<Element> puertasVentanas = ObtenerPuertasVentanasNativasVisiblesCacheadas(doc);

        if (puertasVentanas == null || puertasVentanas.Count == 0)
            return;

        HashSet<long> anfitrionesUnidos = new HashSet<long>();

        foreach (Element puertaVentana in puertasVentanas)
        {
            if (puertaVentana == null)
                continue;

            ElementId hostId = ObtenerHostIdPuertaVentana(puertaVentana);

            if (hostId == null || hostId == ElementId.InvalidElementId)
                continue;

            if (hostId == muroTarrajeo.Id)
                continue;

            Element anfitrion = null;

            try
            {
                anfitrion = doc.GetElement(hostId);
            }
            catch
            {
                anfitrion = null;
            }

            if (anfitrion == null)
                continue;

            // Solo tiene sentido unir contra elementos nativos. Si la puerta/ventana está en vínculo,
            // Revit no permite unir el tarrajeo nativo contra el muro anfitrión vinculado.
            if (anfitrion.Document == null || !anfitrion.Document.Equals(doc))
                continue;

            // Filtro de cercanía basado en el vano y en el muro anfitrión.
            // Se hace amplio porque el vano puede estar embebido en el espesor del muro,
            // mientras el tarrajeo está pegado a una de sus caras.
            if (!PuertaVentanaEstaCercaDeFranja(puertaVentana, anfitrion, franja))
                continue;

            long claveHost = 0;

            try
            {
                claveHost = anfitrion.Id.Value;
            }
            catch
            {
                claveHost = 0;
            }

            if (claveHost != 0 && anfitrionesUnidos.Contains(claveHost))
                continue;

            bool unido = IntentarUnirTarrajeoConElementoCortante(doc, muroTarrajeo, anfitrion);

            if (unido && claveHost != 0)
                anfitrionesUnidos.Add(claveHost);
        }
    }


    private bool PuertaVentanaEstaCercaDeFranja(
        Element puertaVentana,
        Element anfitrion,
        FranjaTarrajeoMYG franja)
    {
        if (puertaVentana == null || anfitrion == null || franja == null || franja.EjeU == null || franja.Normal == null)
            return false;

        // 1) El vano debe caer dentro o muy cerca del tramo U/Z del tarrajeo.
        // Se usa tolerancia amplia para no perder puertas/ventanas con marco, alféizar o símbolos.
        if (!ElementoTieneSolapeUZConFranja(puertaVentana, Transform.Identity, franja, MetrosAPies(0.35), MetrosAPies(0.35)))
            return false;

        // 2) El muro anfitrión debe estar cerca/cruzar el plano del tarrajeo.
        // Esta validación es la que evita unir con anfitriones lejanos del mismo nivel.
        if (!ElementoCruzaOCercaPlanoFranja(anfitrion, Transform.Identity, franja, MetrosAPies(0.55)))
            return false;

        // 3) Además el anfitrión debe solaparse con la franja en U/Z.
        // Esto ayuda en muros largos con varias puertas cercanas.
        if (!ElementoTieneSolapeUZConFranja(anfitrion, Transform.Identity, franja, MetrosAPies(0.20), MetrosAPies(0.20)))
            return false;

        return true;
    }


    private bool ElementoTieneSolapeUZConFranja(
        Element elemento,
        Transform transformacion,
        FranjaTarrajeoMYG franja,
        double toleranciaU,
        double toleranciaZ)
    {
        if (elemento == null || franja == null || franja.EjeU == null)
            return false;

        List<XYZ> puntos = ObtenerPuntosBoundingBoxHost(elemento, transformacion);

        if (puntos == null || puntos.Count == 0)
            return false;

        double minU = double.MaxValue;
        double maxU = double.MinValue;
        double minZ = double.MaxValue;
        double maxZ = double.MinValue;

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            double u = p.DotProduct(franja.EjeU);
            double z = p.Z;

            if (u < minU) minU = u;
            if (u > maxU) maxU = u;
            if (z < minZ) minZ = z;
            if (z > maxZ) maxZ = z;
        }

        if (minU == double.MaxValue || maxU == double.MinValue || minZ == double.MaxValue || maxZ == double.MinValue)
            return false;

        double u1 = Math.Max(minU, franja.UInicio - toleranciaU);
        double u2 = Math.Min(maxU, franja.UFin + toleranciaU);
        double z1 = Math.Max(minZ, franja.ZBase - toleranciaZ);
        double z2 = Math.Min(maxZ, franja.ZTop + toleranciaZ);

        if ((u2 - u1) < MetrosAPies(0.02))
            return false;

        if ((z2 - z1) < MetrosAPies(0.02))
            return false;

        return true;
    }

    private bool ElementoCruzaOCercaPlanoFranja(
        Element elemento,
        Transform transformacion,
        FranjaTarrajeoMYG franja,
        double toleranciaPlano)
    {
        if (elemento == null || franja == null || franja.Normal == null)
            return false;

        List<XYZ> puntos = ObtenerPuntosBoundingBoxHost(elemento, transformacion);

        if (puntos == null || puntos.Count == 0)
            return false;

        double minD = double.MaxValue;
        double maxD = double.MinValue;

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            double d = p.DotProduct(franja.Normal);

            if (d < minD) minD = d;
            if (d > maxD) maxD = d;
        }

        if (minD == double.MaxValue || maxD == double.MinValue)
            return false;

        double dRef = franja.PlaneDCara;

        if (maxD < dRef - toleranciaPlano)
            return false;

        if (minD > dRef + toleranciaPlano)
            return false;

        return true;
    }

    private bool IntentarUnirTarrajeoConElementoCortante(
        Document doc,
        Wall muroTarrajeo,
        Element elementoCortante)
    {
        if (doc == null || muroTarrajeo == null || elementoCortante == null)
            return false;

        if (elementoCortante.Id == muroTarrajeo.Id)
            return false;

        try
        {
            bool yaUnidos = false;

            try
            {
                yaUnidos = JoinGeometryUtils.AreElementsJoined(doc, elementoCortante, muroTarrajeo);
            }
            catch
            {
                yaUnidos = false;
            }

            if (!yaUnidos)
            {
                bool unido = false;

                // En algunos casos Revit acepta la unión solo con un orden específico.
                // Por eso se intenta en ambos órdenes, igual que cuando lo haces manualmente.
                try
                {
                    JoinGeometryUtils.JoinGeometry(doc, muroTarrajeo, elementoCortante);
                    unido = true;
                }
                catch
                {
                    unido = false;
                }

                if (!unido)
                {
                    try
                    {
                        JoinGeometryUtils.JoinGeometry(doc, elementoCortante, muroTarrajeo);
                        unido = true;
                    }
                    catch
                    {
                        unido = false;
                    }
                }

                if (!unido)
                    return false;
            }

            try
            {
                doc.Regenerate();
            }
            catch
            {
            }

            // Forzar que el anfitrión/cortante sea quien corte al tarrajeo.
            // Esto es lo que permite que el vano del anfitrión afecte al tarrajeo unido.
            try
            {
                if (JoinGeometryUtils.AreElementsJoined(doc, elementoCortante, muroTarrajeo))
                {
                    bool elementoCorta = true;

                    try
                    {
                        elementoCorta = JoinGeometryUtils.IsCuttingElementInJoin(doc, elementoCortante, muroTarrajeo);
                    }
                    catch
                    {
                        elementoCorta = true;
                    }

                    if (!elementoCorta)
                    {
                        try
                        {
                            JoinGeometryUtils.SwitchJoinOrder(doc, elementoCortante, muroTarrajeo);
                        }
                        catch
                        {
                        }
                    }
                }
            }
            catch
            {
            }

            try
            {
                doc.Regenerate();
            }
            catch
            {
            }

            return true;
        }
        catch
        {
            return false;
        }
    }


    // V40: método desactivado. No se debe crear ningún "Hueco de muro recto rectangular".
    // Los vanos sin anfitrión cercano se resuelven recortando el perfil/segmentos del tarrajeo.
    private void CrearAberturaRectangularEnTarrajeo(
        Document doc,
        Wall muro,
        FranjaTarrajeoMYG franja,
        double u1,
        double u2,
        double z1,
        double z2)
    {
        return;
    }

    // V40: método desactivado. No se deben crear aberturas nativas.
    // Los cortes se resuelven con segmentos/perfil al momento de crear el tarrajeo.
    private void AplicarAberturasParcialesPorInterferencias(
        Document doc,
        Wall muro,
        FranjaTarrajeoMYG franja,
        SegmentoFranjaMYG segmento,
        List<InterferenciaTarrajeoMYG> interferencias)
    {
        return;
    }


    // =========================================================
    // V35 OPT - CACHES Y PREFILTROS RÁPIDOS
    // =========================================================

    private void InvalidarCachesOptimizacion()
    {
        _cacheClaveCarasBase = "";
        _cacheCarasBaseSeleccionadas = null;
        _cacheVistaPuertasVentanasValue = long.MinValue;
        _cachePuertasVentanasVisibles = null;
    }

    private string ObtenerClaveSeleccionBaseCache(Document doc)
    {
        if (doc == null || Form == null || Form.ElementosSeleccionados == null)
            return "";

        List<string> partes = new List<string>();

        try
        {
            partes.Add(doc.GetHashCode().ToString());
        }
        catch
        {
        }

        foreach (CrearTarrajeoInteriorConfinamientoForm.ElementoTarrajeoBaseMYG item in Form.ElementosSeleccionados)
        {
            if (item == null)
                continue;

            try
            {
                if (item.EsVinculado)
                {
                    partes.Add("L:" + item.LinkInstanceId.Value.ToString() + ":" + item.LinkedElementId.Value.ToString());
                }
                else
                {
                    partes.Add("N:" + item.ElementIdNativo.Value.ToString());
                }
            }
            catch
            {
            }
        }

        return string.Join("|", partes);
    }

    private List<CaraVerticalHostMYG> ObtenerCarasBaseSeleccionadasCacheadas(Document doc, DatosDeteccionMYG datos)
    {
        List<CaraVerticalHostMYG> resultado = new List<CaraVerticalHostMYG>();

        if (doc == null || Form == null || Form.ElementosSeleccionados == null || Form.ElementosSeleccionados.Count == 0)
            return resultado;

        string clave = ObtenerClaveSeleccionBaseCache(doc);

        if (!string.IsNullOrWhiteSpace(clave) &&
            _cacheCarasBaseSeleccionadas != null &&
            string.Equals(_cacheClaveCarasBase, clave, StringComparison.Ordinal))
        {
            if (datos != null)
            {
                datos.ElementosLeidos = Form.ElementosSeleccionados.Count;
            }

            return _cacheCarasBaseSeleccionadas;
        }

        foreach (CrearTarrajeoInteriorConfinamientoForm.ElementoTarrajeoBaseMYG item in Form.ElementosSeleccionados)
        {
            if (item == null)
                continue;

            ElementoConTransformMYG data = ResolverElementoBaseSeleccionado(doc, item);

            if (data == null || data.Elemento == null)
            {
                if (datos != null) datos.ElementosOmitidos++;
                continue;
            }

            if (datos != null) datos.ElementosLeidos++;

            List<CaraVerticalHostMYG> caras = ObtenerCarasVerticalesHost(data.Elemento, data.Transformacion);

            if (caras == null || caras.Count == 0)
            {
                if (datos != null) datos.ElementosOmitidos++;
                continue;
            }

            foreach (CaraVerticalHostMYG cara in caras)
            {
                if (cara != null)
                    resultado.Add(cara);
            }
        }

        _cacheClaveCarasBase = clave;
        _cacheCarasBaseSeleccionadas = resultado;

        return resultado;
    }

    private List<Element> ObtenerPuertasVentanasNativasVisiblesCacheadas(Document doc)
    {
        List<Element> resultado = new List<Element>();

        if (doc == null)
            return resultado;

        // V37:
        // No se limita estrictamente al collector de la vista activa, porque en 3D con caja de sección,
        // filtros o estados temporales algunas puertas/ventanas pueden no entrar en ese collector aunque
        // su muro anfitrión sí esté afectando el tarrajeo. Se recolecta todo el documento nativo y luego
        // cada vano se filtra por cercanía contra la franja.
        long docValue = 0;

        try
        {
            docValue = doc.GetHashCode();
        }
        catch
        {
            docValue = -1;
        }

        if (_cachePuertasVentanasVisibles != null && _cacheVistaPuertasVentanasValue == docValue)
            return _cachePuertasVentanasVisibles;

        try
        {
            List<BuiltInCategory> categorias = new List<BuiltInCategory>();
            categorias.Add(BuiltInCategory.OST_Doors);
            categorias.Add(BuiltInCategory.OST_Windows);

            ElementMulticategoryFilter filtro = new ElementMulticategoryFilter(categorias);

            FilteredElementCollector collector = new FilteredElementCollector(doc);
            collector.WherePasses(filtro);
            collector.WhereElementIsNotElementType();

            foreach (Element elemento in collector)
            {
                if (elemento == null)
                    continue;

                if (!EsPuertaOVentana(elemento))
                    continue;

                resultado.Add(elemento);
            }
        }
        catch
        {
            try
            {
                FilteredElementCollector collectorFallback = new FilteredElementCollector(doc);
                collectorFallback.WhereElementIsNotElementType();

                foreach (Element elemento in collectorFallback)
                {
                    if (elemento == null)
                        continue;

                    if (!EsPuertaOVentana(elemento))
                        continue;

                    resultado.Add(elemento);
                }
            }
            catch
            {
            }
        }

        _cacheVistaPuertasVentanasValue = docValue;
        _cachePuertasVentanasVisibles = resultado;

        return resultado;
    }


    private bool ElementoPuedeCruzarFranjaPorBoundingBoxRapido(
        Element elemento,
        Transform transformacion,
        FranjaTarrajeoMYG franja,
        double espesorMuro)
    {
        if (elemento == null || franja == null || franja.EjeU == null || franja.Normal == null)
            return false;

        List<XYZ> puntos = ObtenerPuntosBoundingBoxHost(elemento, transformacion);

        if (puntos == null || puntos.Count == 0)
            return false;

        double minU = double.MaxValue;
        double maxU = double.MinValue;
        double minZ = double.MaxValue;
        double maxZ = double.MinValue;
        double minD = double.MaxValue;
        double maxD = double.MinValue;

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            double u = p.DotProduct(franja.EjeU);
            double z = p.Z;
            double d = p.DotProduct(franja.Normal);

            if (u < minU) minU = u;
            if (u > maxU) maxU = u;
            if (z < minZ) minZ = z;
            if (z > maxZ) maxZ = z;
            if (d < minD) minD = d;
            if (d > maxD) maxD = d;
        }

        if (minU == double.MaxValue || minZ == double.MaxValue || minD == double.MaxValue)
            return false;

        double tolU = TOL_INTERFERENCIA_BORDE;
        double tolZ = TOL_INTERFERENCIA_BORDE;
        double tolD = Math.Max(TOL_INTERFERENCIA_PLANO, espesorMuro + TOL_INTERFERENCIA_BORDE);

        if (maxU < franja.UInicio - tolU)
            return false;

        if (minU > franja.UFin + tolU)
            return false;

        if (maxZ < franja.ZBase - tolZ)
            return false;

        if (minZ > franja.ZTop + tolZ)
            return false;

        if (maxD < franja.PlaneDCara - tolD)
            return false;

        if (minD > franja.PlaneDCara + espesorMuro + tolD)
            return false;

        return true;
    }

    // =========================================================
    // DETECCIÓN DE FRANJA
    // =========================================================

    private FranjaTarrajeoMYG DetectarFranjaDesdeSemilla(Document doc, WallType wallType, out DatosDeteccionMYG datos)
    {
        datos = new DatosDeteccionMYG();

        if (doc == null || wallType == null || Form == null)
            return null;

        CrearTarrajeoInteriorConfinamientoForm.CaraSemillaTarrajeoMYG semilla = Form.CaraSemillaSeleccionada;

        if (semilla == null || semilla.NormalHost == null || semilla.EjeUHost == null)
            return null;

        List<CrearTarrajeoInteriorConfinamientoForm.ElementoTarrajeoBaseMYG> seleccion = Form.ElementosSeleccionados;

        if (seleccion == null || seleccion.Count == 0)
            return null;

        XYZ normalSemilla = semilla.NormalHost.Normalize();
        XYZ ejeUSemilla = semilla.EjeUHost.Normalize();
        double cosAngulo = Math.Cos(TOL_ANGULO_SEMILLA_GRADOS * Math.PI / 180.0);

        List<CaraFranjaMYG> candidatas = new List<CaraFranjaMYG>();
        List<CaraVerticalHostMYG> todasLasCarasBase = ObtenerCarasBaseSeleccionadasCacheadas(doc, datos);
        HashSet<string> firmas = new HashSet<string>();

        if (todasLasCarasBase == null || todasLasCarasBase.Count == 0)
            return null;

        foreach (CaraVerticalHostMYG cara in todasLasCarasBase)
        {
            if (cara == null || cara.Normal == null || cara.Puntos == null || cara.Puntos.Count == 0)
                continue;

            datos.CarasEvaluadas++;

            XYZ normalCara = cara.Normal.Normalize();
            double dotAbs = Math.Abs(normalCara.DotProduct(normalSemilla));

            if (dotAbs < cosAngulo)
                continue;

            IntervaloCaraEnSemillaMYG intervalo = CalcularIntervaloCaraEnSistemaSemilla(cara, normalSemilla, ejeUSemilla);

            if (intervalo == null)
                continue;

            double distanciaPlano = Math.Abs(intervalo.PlaneD - semilla.PlaneD);

            if (distanciaPlano > TOL_PLANO_SEMILLA)
                continue;

            if ((intervalo.MaxU - intervalo.MinU) < ANCHO_MINIMO_CARA)
                continue;

            if ((intervalo.MaxZ - intervalo.MinZ) < ALTO_MINIMO_CARA)
                continue;

            string firma =
                Redondear(intervalo.MinU) + "|" +
                Redondear(intervalo.MaxU) + "|" +
                Redondear(intervalo.MinZ) + "|" +
                Redondear(intervalo.MaxZ) + "|" +
                Redondear(intervalo.PlaneD);

            if (Form.EvitarDuplicados && firmas.Contains(firma))
                continue;

            firmas.Add(firma);

            CaraFranjaMYG candidata = new CaraFranjaMYG();
            candidata.Cara = cara;
            candidata.MinU = intervalo.MinU;
            candidata.MaxU = intervalo.MaxU;
            candidata.MinZ = intervalo.MinZ;
            candidata.MaxZ = intervalo.MaxZ;
            candidata.PlaneD = intervalo.PlaneD;
            candidata.ScoreSemilla = CalcularScorePuntoSobreIntervalo(semilla.PuntoHost, normalSemilla, ejeUSemilla, intervalo);

            candidatas.Add(candidata);
            datos.CarasCompatibles++;
        }

        if (candidatas.Count == 0)
            return null;

        // V13:
        // Modo recomendado: la cara picada funciona como semilla y la franja se extiende
        // en toda su longitud por caras coplanares/contiguas, hasta encontrar una junta
        // o un elemento transversal que cruza el plano. Si el usuario desmarca la opción,
        // se conserva el modo exacto solo sobre la cara picada.
        bool expandirTodaLaFranja = true;
        try
        {
            expandirTodaLaFranja = Form.ExpandirCarasContiguas;
        }
        catch
        {
            expandirTodaLaFranja = true;
        }

        List<CaraFranjaMYG> aceptadas = ObtenerCarasConectadasASemilla(candidatas, semilla, normalSemilla, ejeUSemilla, expandirTodaLaFranja);

        if (aceptadas == null || aceptadas.Count == 0)
            return null;

        datos.CarasConectadas = aceptadas.Count;

        double minU = expandirTodaLaFranja ? aceptadas.Min(x => x.MinU) : semilla.MinU;
        double maxU = expandirTodaLaFranja ? aceptadas.Max(x => x.MaxU) : semilla.MaxU;
        double minZ = expandirTodaLaFranja ? aceptadas.Min(x => x.MinZ) : semilla.MinZ;
        double maxZ = expandirTodaLaFranja ? aceptadas.Max(x => x.MaxZ) : semilla.MaxZ;

        // Siempre se usa el plano exacto de la cara semilla para evitar desfases visibles.
        double dCaraReferencia = semilla.PlaneD;

        // Si se expande, se recorta contra elementos transversales que cruzan la franja.
        if (expandirTodaLaFranja)
        {
            double uSemilla = semilla.PuntoHost.DotProduct(ejeUSemilla);
            AjustarLimitesPorBarrerasTransversales(
                todasLasCarasBase,
                candidatas,
                normalSemilla,
                ejeUSemilla,
                semilla.PlaneD,
                uSemilla,
                minZ,
                maxZ,
                ref minU,
                ref maxU,
                datos);

            // V16:
            // Luego del corte por muros que cruzan, se vuelve a revisar la corrida a la
            // altura donde se picó. Si entre tramos coplanares aparece una junta/separación,
            // la franja se corta ahí y no la atraviesa.
            AjustarLimitesPorJuntasEnCorrida(
                candidatas,
                semilla,
                normalSemilla,
                ejeUSemilla,
                ref minU,
                ref maxU,
                datos);
        }

        if ((maxU - minU) < LONGITUD_MINIMA_FRANJA)
            return null;

        if ((maxZ - minZ) < ALTURA_MINIMA_FRANJA)
            return null;

        double espesor = ObtenerAnchoMuro(wallType);

        if (espesor <= MetrosAPies(0.002))
            return null;

        FranjaTarrajeoMYG franja = new FranjaTarrajeoMYG();
        franja.Normal = normalSemilla;
        franja.EjeU = ejeUSemilla;
        franja.PlaneDCara = dCaraReferencia;
        franja.PlaneDCentroMuro = dCaraReferencia + (espesor / 2.0);
        franja.UInicio = minU;
        franja.UFin = maxU;
        franja.ZBase = minZ;
        franja.ZTop = maxZ;
        franja.CarasUsadas = aceptadas;
        franja.PuntoCentroPlano = CrearPuntoDesdePlano((minU + maxU) / 2.0, (minZ + maxZ) / 2.0, ejeUSemilla, normalSemilla, franja.PlaneDCentroMuro);

        return franja;
    }

    private List<CaraFranjaMYG> ObtenerCarasConectadasASemilla(
        List<CaraFranjaMYG> candidatas,
        CrearTarrajeoInteriorConfinamientoForm.CaraSemillaTarrajeoMYG semilla,
        XYZ normalSemilla,
        XYZ ejeUSemilla,
        bool expandir)
    {
        if (candidatas == null || candidatas.Count == 0 || semilla == null)
            return new List<CaraFranjaMYG>();

        List<CaraFranjaMYG> resultado = new List<CaraFranjaMYG>();

        CaraFranjaMYG inicial = null;

        foreach (CaraFranjaMYG c in candidatas)
        {
            if (c == null)
                continue;

            bool contienePunto = PuntoDentroDeIntervaloSemilla(semilla.PuntoHost, normalSemilla, ejeUSemilla, c);

            if (contienePunto)
            {
                inicial = c;
                break;
            }
        }

        if (inicial == null)
        {
            inicial = candidatas.OrderBy(x => x.ScoreSemilla).FirstOrDefault();

            if (inicial == null || inicial.ScoreSemilla > TOL_SEMILLA_PUNTO)
                return resultado;
        }

        if (!expandir)
        {
            resultado.Add(inicial);
            return resultado;
        }

        // V14:
        // La cara picada ya no se toma como un único tramo ni se expande solo hacia un lado.
        // Ahora se arma una "corrida" o franja continua en ambos sentidos del eje U:
        // - Parte desde la cara semilla.
        // - Avanza hacia izquierda y derecha mientras existan caras coplanares realmente pegadas.
        // - Se detiene donde ya no hay caras, donde aparece una junta/separación o donde luego
        //   el recorte transversal detecta un muro/columneta/viga que cruza.
        // Esto evita que el tarrajeo quede solo desde el punto picado hacia un lado.
        List<CaraFranjaMYG> corrida = ObtenerCorridaBidireccionalPorIntervalos(candidatas, inicial);

        if (corrida == null || corrida.Count == 0)
            return resultado;

        return corrida
            .OrderBy(x => x.MinU)
            .ThenBy(x => x.MinZ)
            .ToList();
    }

    private List<CaraFranjaMYG> ObtenerCorridaBidireccionalPorIntervalos(
        List<CaraFranjaMYG> candidatas,
        CaraFranjaMYG inicial)
    {
        List<CaraFranjaMYG> resultado = new List<CaraFranjaMYG>();

        if (candidatas == null || candidatas.Count == 0 || inicial == null)
            return resultado;

        // V16:
        // Antes solo se unían caras si estaban prácticamente pegadas. Eso hacía que
        // el tarrajeo quedara limitado al ancho de la cara picada cuando había una
        // columneta, un encuentro corto o una interrupción propia del confinamiento.
        // Ahora la franja se proyecta hacia ambos lados:
        //  - si la siguiente cara está pegada/solapada, se une;
        //  - si hay una junta pequeña visible de hasta 1.5", se corta;
        //  - si hay una interrupción mayor pero menor al puente máximo, se proyecta;
        //  - si el vacío es demasiado grande, se considera que ya no hay caras y se detiene.

        HashSet<CaraFranjaMYG> agregadas = new HashSet<CaraFranjaMYG>();

        double minUGrupo = inicial.MinU;
        double maxUGrupo = inicial.MaxU;
        double minZGrupo = inicial.MinZ;
        double maxZGrupo = inicial.MaxZ;

        resultado.Add(inicial);
        agregadas.Add(inicial);

        bool cambio = true;

        while (cambio)
        {
            cambio = false;

            // Primero absorbe todo lo que se solape o toque realmente la corrida actual.
            foreach (CaraFranjaMYG c in candidatas)
            {
                if (c == null || agregadas.Contains(c))
                    continue;

                if (!TieneSolapeVerticalConCorrida(c, minZGrupo, maxZGrupo))
                    continue;

                if (CaraTocaOSolapaCorrida(c, minUGrupo, maxUGrupo))
                {
                    AgregarCaraACorrida(c, resultado, agregadas, ref minUGrupo, ref maxUGrupo, ref minZGrupo, ref maxZGrupo);
                    cambio = true;
                }
            }

            if (cambio)
                continue;

            // Luego busca la cara más cercana por la derecha y por la izquierda.
            CaraFranjaMYG mejorDerecha = null;
            CaraFranjaMYG mejorIzquierda = null;
            double gapDerecha = double.MaxValue;
            double gapIzquierda = double.MaxValue;

            foreach (CaraFranjaMYG c in candidatas)
            {
                if (c == null || agregadas.Contains(c))
                    continue;

                if (!TieneSolapeVerticalConCorrida(c, minZGrupo, maxZGrupo))
                    continue;

                if (c.MinU > maxUGrupo)
                {
                    double gap = c.MinU - maxUGrupo;

                    if (gap < gapDerecha)
                    {
                        gapDerecha = gap;
                        mejorDerecha = c;
                    }
                }
                else if (c.MaxU < minUGrupo)
                {
                    double gap = minUGrupo - c.MaxU;

                    if (gap < gapIzquierda)
                    {
                        gapIzquierda = gap;
                        mejorIzquierda = c;
                    }
                }
            }

            if (PuedeProyectarSaltandoGap(gapDerecha) && mejorDerecha != null)
            {
                AgregarCaraACorrida(mejorDerecha, resultado, agregadas, ref minUGrupo, ref maxUGrupo, ref minZGrupo, ref maxZGrupo);
                cambio = true;
            }

            if (PuedeProyectarSaltandoGap(gapIzquierda) && mejorIzquierda != null)
            {
                AgregarCaraACorrida(mejorIzquierda, resultado, agregadas, ref minUGrupo, ref maxUGrupo, ref minZGrupo, ref maxZGrupo);
                cambio = true;
            }
        }

        return resultado;
    }

    private bool TieneSolapeVerticalConCorrida(CaraFranjaMYG c, double minZGrupo, double maxZGrupo)
    {
        if (c == null)
            return false;

        double solapeZ = Math.Min(c.MaxZ, maxZGrupo) - Math.Max(c.MinZ, minZGrupo);

        if (solapeZ >= ALTO_MINIMO_CARA)
            return true;

        // Permite que se integren caras superiores/inferiores del mismo plano si casi se tocan.
        double gapZ = 0.0;

        if (c.MaxZ < minZGrupo)
            gapZ = minZGrupo - c.MaxZ;
        else if (c.MinZ > maxZGrupo)
            gapZ = c.MinZ - maxZGrupo;
        else
            gapZ = 0.0;

        return gapZ <= TOL_PEGADO_REAL;
    }

    private bool CaraTocaOSolapaCorrida(CaraFranjaMYG c, double minUGrupo, double maxUGrupo)
    {
        if (c == null)
            return false;

        double solapeU = Math.Min(c.MaxU, maxUGrupo) - Math.Max(c.MinU, minUGrupo);

        if (solapeU > TOL_PEGADO_REAL)
            return true;

        double gapU = 0.0;

        if (c.MaxU < minUGrupo)
            gapU = minUGrupo - c.MaxU;
        else if (c.MinU > maxUGrupo)
            gapU = c.MinU - maxUGrupo;
        else
            gapU = 0.0;

        return gapU <= TOL_PEGADO_REAL;
    }

    private bool PuedeProyectarSaltandoGap(double gap)
    {
        if (double.IsNaN(gap) || double.IsInfinity(gap) || gap == double.MaxValue)
            return false;

        if (gap <= TOL_PEGADO_REAL)
            return true;

        // Junta pequeña: se corta, no se salta.
        if (gap <= TOL_CONTINUIDAD)
            return false;

        // Interrupción local mayor a una junta, pero razonable para columneta/encuentro.
        if (gap <= GAP_MAXIMO_PROYECCION_SIN_CARA)
            return true;

        // Ya no hay caras cercanas para continuar la proyección.
        return false;
    }

    private void AgregarCaraACorrida(
        CaraFranjaMYG c,
        List<CaraFranjaMYG> resultado,
        HashSet<CaraFranjaMYG> agregadas,
        ref double minUGrupo,
        ref double maxUGrupo,
        ref double minZGrupo,
        ref double maxZGrupo)
    {
        if (c == null || resultado == null || agregadas == null)
            return;

        resultado.Add(c);
        agregadas.Add(c);

        if (c.MinU < minUGrupo) minUGrupo = c.MinU;
        if (c.MaxU > maxUGrupo) maxUGrupo = c.MaxU;
        if (c.MinZ < minZGrupo) minZGrupo = c.MinZ;
        if (c.MaxZ > maxZGrupo) maxZGrupo = c.MaxZ;
    }

    private bool CarasSonContiguas(CaraFranjaMYG a, CaraFranjaMYG b)
    {
        if (a == null || b == null)
            return false;

        double solapeU = Math.Min(a.MaxU, b.MaxU) - Math.Max(a.MinU, b.MinU);
        double solapeZ = Math.Min(a.MaxZ, b.MaxZ) - Math.Max(a.MinZ, b.MinZ);

        double gapU = 0.0;
        if (a.MaxU < b.MinU)
            gapU = b.MinU - a.MaxU;
        else if (b.MaxU < a.MinU)
            gapU = a.MinU - b.MaxU;

        double gapZ = 0.0;
        if (a.MaxZ < b.MinZ)
            gapZ = b.MinZ - a.MaxZ;
        else if (b.MaxZ < a.MinZ)
            gapZ = a.MinZ - b.MaxZ;

        // V8:
        // Si hay una junta/separación visible de hasta 1.5", NO se debe saltar esa junta.
        // Por eso solo unimos caras si realmente están pegadas o solapadas.
        // Separaciones mayores a 6 mm se consideran corte de franja; el tarrajeo termina ahí.
        if (gapU > TOL_PEGADO_REAL && gapU <= TOL_CONTINUIDAD && solapeZ >= ALTO_MINIMO_CARA)
            return false;

        if (gapZ > TOL_PEGADO_REAL && gapZ <= TOL_CONTINUIDAD && solapeU >= ANCHO_MINIMO_CARA)
            return false;

        // Juntas en horizontal: se tocan realmente por el lado y comparten altura.
        if (gapU <= TOL_PEGADO_REAL && solapeZ >= ALTO_MINIMO_CARA)
            return true;

        // Juntas en vertical: una está encima de otra y comparten ancho.
        if (gapZ <= TOL_PEGADO_REAL && solapeU >= ANCHO_MINIMO_CARA)
            return true;

        // Solapadas prácticamente en ambas direcciones.
        if (solapeU > TOL_PEGADO_REAL && solapeZ > TOL_PEGADO_REAL)
            return true;

        return false;
    }

    private void AjustarLimitesPorBarrerasTransversales(
        List<CaraVerticalHostMYG> todasLasCarasBase,
        List<CaraFranjaMYG> carasCompatiblesSemilla,
        XYZ normalSemilla,
        XYZ ejeUSemilla,
        double planeDSemilla,
        double uSemilla,
        double zBaseFranja,
        double zTopFranja,
        ref double minU,
        ref double maxU,
        DatosDeteccionMYG datos)
    {
        if (todasLasCarasBase == null || todasLasCarasBase.Count == 0)
            return;

        if (normalSemilla == null || ejeUSemilla == null)
            return;

        if (maxU <= minU || zTopFranja <= zBaseFranja)
            return;

        double cosBarrera = Math.Cos(TOL_ANGULO_BARRERA_GRADOS * Math.PI / 180.0);
        double mejorCorteIzquierda = double.MinValue;
        double mejorCorteDerecha = double.MaxValue;
        int cortesDetectados = 0;

        foreach (CaraVerticalHostMYG cara in todasLasCarasBase)
        {
            if (cara == null || cara.Normal == null || cara.Puntos == null || cara.Puntos.Count == 0)
                continue;

            XYZ normalCara = null;

            try
            {
                normalCara = cara.Normal.Normalize();
            }
            catch
            {
                normalCara = null;
            }

            if (normalCara == null)
                continue;

            // Barrera transversal: su normal horizontal debe apuntar casi en dirección U.
            // Ejemplo: muro perpendicular al muro picado.
            double alineacionConU = Math.Abs(normalCara.DotProduct(ejeUSemilla));

            if (alineacionConU < cosBarrera)
                continue;

            double minD = double.MaxValue;
            double maxD = double.MinValue;
            double minUCara = double.MaxValue;
            double maxUCara = double.MinValue;
            double minZCara = double.MaxValue;
            double maxZCara = double.MinValue;

            foreach (XYZ p in cara.Puntos)
            {
                if (p == null)
                    continue;

                double d = p.DotProduct(normalSemilla);
                double u = p.DotProduct(ejeUSemilla);
                double z = p.Z;

                if (d < minD) minD = d;
                if (d > maxD) maxD = d;
                if (u < minUCara) minUCara = u;
                if (u > maxUCara) maxUCara = u;
                if (z < minZCara) minZCara = z;
                if (z > maxZCara) maxZCara = z;
            }

            if (minD == double.MaxValue || minUCara == double.MaxValue)
                continue;

            // La cara debe cruzar el plano de la cara semilla.
            // Si no cruza ese plano, no puede cortar la franja de tarrajeo.
            if (maxD < planeDSemilla - TOL_CRUCE_PLANO_BARRERA)
                continue;

            if (minD > planeDSemilla + TOL_CRUCE_PLANO_BARRERA)
                continue;

            double solapeZ = Math.Min(maxZCara, zTopFranja) - Math.Max(minZCara, zBaseFranja);

            if (solapeZ < ALTO_MINIMO_CARA)
                continue;

            // V16:
            // Una columneta del mismo paño puede tener caras laterales con normal transversal,
            // pero su profundidad respecto al plano del tarrajeo es pequeña. Un muro/elemento
            // que realmente cruza la franja tiene una profundidad mayor. Así se evita cortar
            // en columnetas normales y sí se corta en cruces como los de tus imágenes.
            double profundidadBarrera = maxD - minD;

            if (profundidadBarrera < PROFUNDIDAD_MINIMA_BARRERA_TRANSVERSAL)
                continue;

            // Para cortar al ras del elemento que cruza, no se usa el centro de la barrera.
            // Se toma la cara/límite más cercano a la semilla:
            // - barrera a la derecha: su U mínimo
            // - barrera a la izquierda: su U máximo
            double uCorteDerecha = minUCara;
            double uCorteIzquierda = maxUCara;

            // Si la barrera está a la derecha de la semilla, tomar el límite izquierdo de esa barrera.
            if (uCorteDerecha > uSemilla + TOL_PEGADO_REAL &&
                uCorteDerecha > minU + TOL_PEGADO_REAL &&
                uCorteDerecha < maxU - TOL_PEGADO_REAL &&
                uCorteDerecha < mejorCorteDerecha)
            {
                mejorCorteDerecha = uCorteDerecha;
                cortesDetectados++;
            }

            // Si la barrera está a la izquierda de la semilla, tomar el límite derecho de esa barrera.
            if (uCorteIzquierda < uSemilla - TOL_PEGADO_REAL &&
                uCorteIzquierda > minU + TOL_PEGADO_REAL &&
                uCorteIzquierda < maxU - TOL_PEGADO_REAL &&
                uCorteIzquierda > mejorCorteIzquierda)
            {
                mejorCorteIzquierda = uCorteIzquierda;
                cortesDetectados++;
            }
        }

        if (mejorCorteIzquierda != double.MinValue)
        {
            double nuevoMin = mejorCorteIzquierda + MARGEN_CORTE_BARRERA;

            if (nuevoMin < maxU - LONGITUD_MINIMA_FRANJA)
                minU = Math.Max(minU, nuevoMin);
        }

        if (mejorCorteDerecha != double.MaxValue)
        {
            double nuevoMax = mejorCorteDerecha - MARGEN_CORTE_BARRERA;

            if (nuevoMax > minU + LONGITUD_MINIMA_FRANJA)
                maxU = Math.Min(maxU, nuevoMax);
        }

        if (datos != null && cortesDetectados > 0)
            datos.CortesTransversales = cortesDetectados;
    }

    private void AjustarLimitesPorJuntasEnCorrida(
        List<CaraFranjaMYG> carasCompatibles,
        CrearTarrajeoInteriorConfinamientoForm.CaraSemillaTarrajeoMYG semilla,
        XYZ normalSemilla,
        XYZ ejeUSemilla,
        ref double minU,
        ref double maxU,
        DatosDeteccionMYG datos)
    {
        if (carasCompatibles == null || carasCompatibles.Count == 0)
            return;

        if (semilla == null || semilla.PuntoHost == null || normalSemilla == null || ejeUSemilla == null)
            return;

        if (maxU <= minU)
            return;

        double zReferencia = semilla.PuntoHost.Z;
        double uSemilla = semilla.PuntoHost.DotProduct(ejeUSemilla);

        List<IntervaloUMYG> intervalos = new List<IntervaloUMYG>();

        foreach (CaraFranjaMYG c in carasCompatibles)
        {
            if (c == null)
                continue;

            // Solo se evalúan las caras que pasan por la altura aproximada donde se picó.
            // Esto evita que una viga o una banda superior haga "puente" sobre una junta
            // visible en la cara de albañilería/columneta.
            if (zReferencia < c.MinZ - TOL_PEGADO_REAL || zReferencia > c.MaxZ + TOL_PEGADO_REAL)
                continue;

            if (c.MaxU < minU - TOL_CONTINUIDAD || c.MinU > maxU + TOL_CONTINUIDAD)
                continue;

            IntervaloUMYG inter = new IntervaloUMYG();
            inter.Min = c.MinU;
            inter.Max = c.MaxU;
            intervalos.Add(inter);
        }

        if (intervalos.Count == 0)
            return;

        intervalos = intervalos
            .Where(x => x != null && x.Max > x.Min)
            .OrderBy(x => x.Min)
            .ToList();

        if (intervalos.Count == 0)
            return;

        // Unir intervalos que realmente se tocan o se solapan.
        List<IntervaloUMYG> unidos = new List<IntervaloUMYG>();

        foreach (IntervaloUMYG inter in intervalos)
        {
            if (unidos.Count == 0)
            {
                unidos.Add(new IntervaloUMYG() { Min = inter.Min, Max = inter.Max });
                continue;
            }

            IntervaloUMYG ultimo = unidos[unidos.Count - 1];
            double gap = inter.Min - ultimo.Max;

            if (gap <= TOL_PEGADO_REAL)
            {
                if (inter.Max > ultimo.Max)
                    ultimo.Max = inter.Max;
            }
            else
            {
                unidos.Add(new IntervaloUMYG() { Min = inter.Min, Max = inter.Max });
            }
        }

        if (unidos.Count == 0)
            return;

        int indexSemilla = -1;
        double mejorDist = double.MaxValue;

        for (int i = 0; i < unidos.Count; i++)
        {
            IntervaloUMYG inter = unidos[i];

            if (uSemilla >= inter.Min - TOL_SEMILLA_PUNTO && uSemilla <= inter.Max + TOL_SEMILLA_PUNTO)
            {
                indexSemilla = i;
                break;
            }

            double dist = 0.0;

            if (uSemilla < inter.Min)
                dist = inter.Min - uSemilla;
            else if (uSemilla > inter.Max)
                dist = uSemilla - inter.Max;

            if (dist < mejorDist)
            {
                mejorDist = dist;
                indexSemilla = i;
            }
        }

        if (indexSemilla < 0 || indexSemilla >= unidos.Count)
            return;

        double limiteIzq = unidos[indexSemilla].Min;
        double limiteDer = unidos[indexSemilla].Max;
        int cortesJunta = 0;

        // Avance hacia la derecha: se corta en la primera junta o ausencia real de caras.
        for (int i = indexSemilla + 1; i < unidos.Count; i++)
        {
            IntervaloUMYG siguiente = unidos[i];
            double gap = siguiente.Min - limiteDer;

            if (gap <= TOL_PEGADO_REAL)
            {
                if (siguiente.Max > limiteDer)
                    limiteDer = siguiente.Max;

                continue;
            }

            // Junta visible o fin de cara: no se atraviesa.
            cortesJunta++;
            break;
        }

        // Avance hacia la izquierda: se corta en la primera junta o ausencia real de caras.
        for (int i = indexSemilla - 1; i >= 0; i--)
        {
            IntervaloUMYG anterior = unidos[i];
            double gap = limiteIzq - anterior.Max;

            if (gap <= TOL_PEGADO_REAL)
            {
                if (anterior.Min < limiteIzq)
                    limiteIzq = anterior.Min;

                continue;
            }

            // Junta visible o fin de cara: no se atraviesa.
            cortesJunta++;
            break;
        }

        if (limiteIzq > minU + TOL_PEGADO_REAL && limiteIzq < maxU - LONGITUD_MINIMA_FRANJA)
            minU = limiteIzq;

        if (limiteDer < maxU - TOL_PEGADO_REAL && limiteDer > minU + LONGITUD_MINIMA_FRANJA)
            maxU = limiteDer;

        if (datos != null && cortesJunta > 0)
            datos.CortesTransversales += cortesJunta;
    }

    private bool ExisteContinuidadDeCarasAlrededorDelCorte(
        List<CaraFranjaMYG> carasCompatibles,
        double uCorte,
        double zBaseFranja,
        double zTopFranja)
    {
        if (carasCompatibles == null || carasCompatibles.Count == 0)
            return false;

        bool hayAntes = false;
        bool hayDespues = false;

        foreach (CaraFranjaMYG c in carasCompatibles)
        {
            if (c == null)
                continue;

            double solapeZ = Math.Min(c.MaxZ, zTopFranja) - Math.Max(c.MinZ, zBaseFranja);

            if (solapeZ < ALTO_MINIMO_CARA)
                continue;

            // Cara o tramo cercano antes del corte.
            if (c.MinU < uCorte - TOL_PEGADO_REAL &&
                c.MaxU >= uCorte - GAP_MAXIMO_PROYECCION_SIN_CARA)
            {
                hayAntes = true;
            }

            // Cara o tramo cercano después del corte.
            if (c.MaxU > uCorte + TOL_PEGADO_REAL &&
                c.MinU <= uCorte + GAP_MAXIMO_PROYECCION_SIN_CARA)
            {
                hayDespues = true;
            }

            if (hayAntes && hayDespues)
                return true;
        }

        return false;
    }

    private bool PuntoDentroDeIntervaloSemilla(XYZ punto, XYZ normal, XYZ ejeU, CaraFranjaMYG c)
    {
        if (punto == null || normal == null || ejeU == null || c == null)
            return false;

        double d = punto.DotProduct(normal);
        double u = punto.DotProduct(ejeU);
        double z = punto.Z;

        if (Math.Abs(d - c.PlaneD) > TOL_SEMILLA_PUNTO)
            return false;

        if (u < c.MinU - TOL_CONTINUIDAD || u > c.MaxU + TOL_CONTINUIDAD)
            return false;

        if (z < c.MinZ - TOL_CONTINUIDAD || z > c.MaxZ + TOL_CONTINUIDAD)
            return false;

        return true;
    }

    private IntervaloCaraEnSemillaMYG CalcularIntervaloCaraEnSistemaSemilla(CaraVerticalHostMYG cara, XYZ normalSemilla, XYZ ejeUSemilla)
    {
        if (cara == null || cara.Puntos == null || cara.Puntos.Count == 0 || normalSemilla == null || ejeUSemilla == null)
            return null;

        double minU = double.MaxValue;
        double maxU = double.MinValue;
        double minZ = double.MaxValue;
        double maxZ = double.MinValue;
        double sumaD = 0.0;
        int n = 0;

        foreach (XYZ p in cara.Puntos)
        {
            if (p == null)
                continue;

            double u = p.DotProduct(ejeUSemilla);
            double z = p.Z;
            double d = p.DotProduct(normalSemilla);

            minU = Math.Min(minU, u);
            maxU = Math.Max(maxU, u);
            minZ = Math.Min(minZ, z);
            maxZ = Math.Max(maxZ, z);
            sumaD += d;
            n++;
        }

        if (n == 0)
            return null;

        IntervaloCaraEnSemillaMYG intervalo = new IntervaloCaraEnSemillaMYG();
        intervalo.MinU = minU;
        intervalo.MaxU = maxU;
        intervalo.MinZ = minZ;
        intervalo.MaxZ = maxZ;
        intervalo.PlaneD = sumaD / n;

        return intervalo;
    }

    // =========================================================
    // GEOMETRÍA BASE
    // =========================================================

    private List<CaraVerticalHostMYG> ObtenerCarasVerticalesHost(Element elemento, Transform transformacionBase)
    {
        List<CaraVerticalHostMYG> resultado = new List<CaraVerticalHostMYG>();

        if (elemento == null)
            return resultado;

        if (transformacionBase == null)
            transformacionBase = Transform.Identity;

        Options opt = new Options();
        opt.ComputeReferences = false;
        opt.IncludeNonVisibleObjects = false;
        opt.DetailLevel = ViewDetailLevel.Fine;

        GeometryElement geo = null;

        try
        {
            geo = elemento.get_Geometry(opt);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return resultado;

        RecorrerGeometriaParaCarasHost(geo, transformacionBase, resultado);

        return resultado;
    }

    private void RecorrerGeometriaParaCarasHost(GeometryElement geo, Transform transformacion, List<CaraVerticalHostMYG> resultado)
    {
        if (geo == null || transformacion == null || resultado == null)
            return;

        foreach (GeometryObject obj in geo)
        {
            if (obj == null)
                continue;

            Solid solid = obj as Solid;

            if (solid != null)
            {
                if (solid.Faces == null || solid.Faces.Size == 0)
                    continue;

                try
                {
                    if (solid.Volume <= 0.000001)
                        continue;
                }
                catch
                {
                }

                foreach (Face face in solid.Faces)
                {
                    PlanarFace pf = face as PlanarFace;

                    if (pf == null)
                        continue;

                    if (pf.Area < AREA_MINIMA_CARA)
                        continue;

                    XYZ normal = null;

                    try
                    {
                        normal = transformacion.OfVector(pf.FaceNormal).Normalize();
                    }
                    catch
                    {
                        normal = null;
                    }

                    if (normal == null)
                        continue;

                    if (Math.Abs(normal.Z) > TOL_NORMAL_VERTICAL)
                        continue;

                    IList<CurveLoop> loopsOriginales = null;

                    try
                    {
                        loopsOriginales = pf.GetEdgesAsCurveLoops();
                    }
                    catch
                    {
                        loopsOriginales = null;
                    }

                    if (loopsOriginales == null || loopsOriginales.Count == 0)
                        continue;

                    XYZ ejeU = XYZ.BasisZ.CrossProduct(normal);

                    if (ejeU.GetLength() < 0.0001)
                        continue;

                    ejeU = ejeU.Normalize();

                    List<XYZ> puntos = new List<XYZ>();

                    foreach (CurveLoop cl in loopsOriginales)
                    {
                        if (cl == null)
                            continue;

                        foreach (Curve c in cl)
                        {
                            if (c == null)
                                continue;

                            try
                            {
                                Curve curvaHost = c.CreateTransformed(transformacion);

                                IList<XYZ> tess = null;

                                try { tess = curvaHost.Tessellate(); } catch { tess = null; }

                                if (tess != null && tess.Count > 0)
                                {
                                    foreach (XYZ p in tess)
                                        AgregarPuntoSinDuplicar(puntos, p);
                                }
                                else
                                {
                                    AgregarPuntoSinDuplicar(puntos, curvaHost.GetEndPoint(0));
                                    AgregarPuntoSinDuplicar(puntos, curvaHost.GetEndPoint(1));
                                }
                            }
                            catch
                            {
                            }
                        }
                    }

                    if (puntos.Count < 3)
                        continue;

                    double minU = double.MaxValue;
                    double maxU = double.MinValue;
                    double minZ = double.MaxValue;
                    double maxZ = double.MinValue;
                    double sumaD = 0.0;

                    foreach (XYZ p in puntos)
                    {
                        double u = p.DotProduct(ejeU);
                        double z = p.Z;
                        double d = p.DotProduct(normal);

                        minU = Math.Min(minU, u);
                        maxU = Math.Max(maxU, u);
                        minZ = Math.Min(minZ, z);
                        maxZ = Math.Max(maxZ, z);
                        sumaD += d;
                    }

                    if ((maxU - minU) < ANCHO_MINIMO_CARA)
                        continue;

                    if ((maxZ - minZ) < ALTO_MINIMO_CARA)
                        continue;

                    CaraVerticalHostMYG info = new CaraVerticalHostMYG();
                    info.Normal = normal;
                    info.EjeU = ejeU;
                    info.PlaneD = sumaD / puntos.Count;
                    info.MinU = minU;
                    info.MaxU = maxU;
                    info.MinZ = minZ;
                    info.MaxZ = maxZ;
                    info.Puntos = puntos;

                    resultado.Add(info);
                }
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi != null)
            {
                GeometryElement geoInst = null;

                try
                {
                    geoInst = gi.GetSymbolGeometry();
                }
                catch
                {
                    geoInst = null;
                }

                if (geoInst == null)
                    continue;

                Transform trfInst = transformacion.Multiply(gi.Transform);
                RecorrerGeometriaParaCarasHost(geoInst, trfInst, resultado);
            }
        }
    }

    // =========================================================
    // RESOLVER ELEMENTOS
    // =========================================================

    private ElementoConTransformMYG ResolverElementoBaseSeleccionado(
        Document docHost,
        CrearTarrajeoInteriorConfinamientoForm.ElementoTarrajeoBaseMYG item)
    {
        if (docHost == null || item == null)
            return null;

        if (!item.EsVinculado)
        {
            Element e = docHost.GetElement(item.ElementIdNativo);

            if (e == null || !EsCategoriaBasePermitida(e))
                return null;

            ElementoConTransformMYG data = new ElementoConTransformMYG();
            data.Elemento = e;
            data.Transformacion = Transform.Identity;
            data.EsVinculado = false;
            data.LinkInstanceId = ElementId.InvalidElementId;
            data.LinkedElementId = ElementId.InvalidElementId;
            data.NombreVinculo = "";

            return data;
        }

        RevitLinkInstance link = docHost.GetElement(item.LinkInstanceId) as RevitLinkInstance;

        if (link == null)
            return null;

        Document docLink = ObtenerDocumentoVinculo(link);

        if (docLink == null)
            return null;

        Element elementoLink = docLink.GetElement(item.LinkedElementId);

        if (elementoLink == null || !EsCategoriaBasePermitida(elementoLink))
            return null;

        ElementoConTransformMYG dataVinculada = new ElementoConTransformMYG();
        dataVinculada.Elemento = elementoLink;
        dataVinculada.Transformacion = ObtenerTransformVinculo(link);
        dataVinculada.EsVinculado = true;
        dataVinculada.LinkInstanceId = link.Id;
        dataVinculada.LinkedElementId = item.LinkedElementId;
        dataVinculada.NombreVinculo = ObtenerNombreElemento(link);

        return dataVinculada;
    }

    private ElementoConTransformMYG ResolverElementoDesdeReferencia(Document docHost, Reference referencia)
    {
        if (docHost == null || referencia == null)
            return null;

        Element elementoHost = docHost.GetElement(referencia.ElementId);
        RevitLinkInstance link = elementoHost as RevitLinkInstance;

        if (link != null)
        {
            Document docLink = ObtenerDocumentoVinculo(link);

            if (docLink == null)
                return null;

            ElementId linkedElementId = referencia.LinkedElementId;

            if (linkedElementId == null || linkedElementId == ElementId.InvalidElementId)
                return null;

            Element elementoLink = docLink.GetElement(linkedElementId);

            if (elementoLink == null)
                return null;

            ElementoConTransformMYG dataLink = new ElementoConTransformMYG();
            dataLink.Elemento = elementoLink;
            dataLink.Transformacion = ObtenerTransformVinculo(link);
            dataLink.EsVinculado = true;
            dataLink.LinkInstanceId = link.Id;
            dataLink.LinkedElementId = linkedElementId;
            dataLink.NombreVinculo = ObtenerNombreElemento(link);

            return dataLink;
        }

        if (elementoHost == null)
            return null;

        ElementoConTransformMYG dataHost = new ElementoConTransformMYG();
        dataHost.Elemento = elementoHost;
        dataHost.Transformacion = Transform.Identity;
        dataHost.EsVinculado = false;
        dataHost.LinkInstanceId = ElementId.InvalidElementId;
        dataHost.LinkedElementId = ElementId.InvalidElementId;
        dataHost.NombreVinculo = "";

        return dataHost;
    }

    private Document ObtenerDocumentoVinculo(RevitLinkInstance link)
    {
        if (link == null)
            return null;

        try
        {
            return link.GetLinkDocument();
        }
        catch
        {
            return null;
        }
    }

    private Transform ObtenerTransformVinculo(RevitLinkInstance link)
    {
        if (link == null)
            return Transform.Identity;

        try
        {
            return link.GetTotalTransform();
        }
        catch
        {
            try
            {
                return link.GetTransform();
            }
            catch
            {
                return Transform.Identity;
            }
        }
    }

    // =========================================================
    // UTILIDADES GEOMÉTRICAS
    // =========================================================

    private List<Curve> CrearCurvasRectanguloFranja(FranjaTarrajeoMYG franja)
    {
        List<Curve> curvas = new List<Curve>();

        if (franja == null)
            return curvas;

        XYZ p00 = CrearPuntoDesdePlano(franja.UInicio, franja.ZBase, franja.EjeU, franja.Normal, franja.PlaneDCentroMuro);
        XYZ p10 = CrearPuntoDesdePlano(franja.UFin, franja.ZBase, franja.EjeU, franja.Normal, franja.PlaneDCentroMuro);
        XYZ p11 = CrearPuntoDesdePlano(franja.UFin, franja.ZTop, franja.EjeU, franja.Normal, franja.PlaneDCentroMuro);
        XYZ p01 = CrearPuntoDesdePlano(franja.UInicio, franja.ZTop, franja.EjeU, franja.Normal, franja.PlaneDCentroMuro);

        try { curvas.Add(Line.CreateBound(p00, p10)); } catch { }
        try { curvas.Add(Line.CreateBound(p10, p11)); } catch { }
        try { curvas.Add(Line.CreateBound(p11, p01)); } catch { }
        try { curvas.Add(Line.CreateBound(p01, p00)); } catch { }

        return curvas;
    }

    private XYZ CrearPuntoDesdePlano(double coordU, double coordZ, XYZ ejeU, XYZ normal, double planeD)
    {
        if (ejeU == null || normal == null)
            return null;

        return ejeU.Multiply(coordU)
            .Add(XYZ.BasisZ.Multiply(coordZ))
            .Add(normal.Multiply(planeD));
    }

    private double CalcularScorePuntoSobreCara(XYZ punto, XYZ normal, XYZ ejeU, double planeD, double minU, double maxU, double minZ, double maxZ)
    {
        if (punto == null || normal == null || ejeU == null)
            return double.MaxValue;

        double distanciaPlano = Math.Abs(punto.DotProduct(normal) - planeD);
        double u = punto.DotProduct(ejeU);
        double z = punto.Z;

        double fueraU = 0.0;
        double fueraZ = 0.0;

        if (u < minU)
            fueraU = minU - u;
        else if (u > maxU)
            fueraU = u - maxU;

        if (z < minZ)
            fueraZ = minZ - z;
        else if (z > maxZ)
            fueraZ = z - maxZ;

        return distanciaPlano * 5.0 + fueraU + fueraZ;
    }

    private double CalcularScorePuntoSobreIntervalo(XYZ punto, XYZ normal, XYZ ejeU, IntervaloCaraEnSemillaMYG intervalo)
    {
        if (intervalo == null)
            return double.MaxValue;

        return CalcularScorePuntoSobreCara(
            punto,
            normal,
            ejeU,
            intervalo.PlaneD,
            intervalo.MinU,
            intervalo.MaxU,
            intervalo.MinZ,
            intervalo.MaxZ);
    }

    private void AgregarPuntoSinDuplicar(List<XYZ> puntos, XYZ p)
    {
        if (puntos == null || p == null)
            return;

        if (puntos.Count == 0)
        {
            puntos.Add(p);
            return;
        }

        XYZ ultimo = puntos[puntos.Count - 1];

        if (ultimo == null || ultimo.DistanceTo(p) > 0.00001)
            puntos.Add(p);
    }

    private double DistanciaXY(XYZ a, XYZ b)
    {
        if (a == null || b == null)
            return double.MaxValue;

        double dx = a.X - b.X;
        double dy = a.Y - b.Y;

        return Math.Sqrt(dx * dx + dy * dy);
    }

    private double ObtenerAnchoMuro(WallType wallType)
    {
        if (wallType == null)
            return 0.0;

        try
        {
            return wallType.Width;
        }
        catch
        {
            return 0.0;
        }
    }

    private double MetrosAPies(double metros)
    {
        try
        {
            return UnitUtils.ConvertToInternalUnits(metros, UnitTypeId.Meters);
        }
        catch
        {
            return metros / 0.3048;
        }
    }

    private string Redondear(double valor)
    {
        return Math.Round(valor, 3).ToString("0.000");
    }

    // =========================================================
    // PARÁMETROS / TEXTOS
    // =========================================================

    private void SetParametro(Element e, string nombreParametro, string valor)
    {
        if (e == null || string.IsNullOrWhiteSpace(nombreParametro))
            return;

        Parameter p = null;

        try
        {
            p = e.LookupParameter(nombreParametro);
        }
        catch
        {
            p = null;
        }

        if (p == null || p.IsReadOnly)
            return;

        try
        {
            if (p.StorageType == StorageType.String)
            {
                p.Set(valor);
            }
            else if (p.StorageType == StorageType.Integer)
            {
                int n = 0;
                if (int.TryParse(valor, out n))
                    p.Set(n);
            }
            else if (p.StorageType == StorageType.Double)
            {
                double d = 0.0;
                if (double.TryParse(valor, out d))
                    p.Set(d);
            }
            else if (p.StorageType == StorageType.ElementId)
            {
                long idLong = 0;
                if (long.TryParse(valor, out idLong))
                    p.Set(new ElementId(idLong));
            }
        }
        catch
        {
        }
    }

    private string ObtenerNombreElemento(Element elemento)
    {
        if (elemento == null)
            return "";

        try
        {
            string nombre = elemento.Name;

            if (!string.IsNullOrWhiteSpace(nombre))
                return nombre;
        }
        catch
        {
        }

        try
        {
            return elemento.Id.Value.ToString();
        }
        catch
        {
            return "";
        }
    }

    private string ObtenerCategoriaElemento(Element elemento)
    {
        if (elemento == null || elemento.Category == null)
            return "";

        try
        {
            return elemento.Category.Name;
        }
        catch
        {
            return "";
        }
    }

    private void MostrarEnVentana(string texto)
    {
        if (Form == null || Form.IsDisposed)
            return;

        try
        {
            Form.MostrarResultado(texto);
        }
        catch
        {
        }
    }

    private string ArmarMensajeDeteccion(string encabezado, DatosDeteccionMYG datos)
    {
        if (datos == null)
            return encabezado;

        return encabezado + "\r\n" +
            "Elementos leídos: " + datos.ElementosLeidos.ToString() +
            " | Caras evaluadas: " + datos.CarasEvaluadas.ToString() +
            " | Compatibles: " + datos.CarasCompatibles.ToString() +
            " | Conectadas: " + datos.CarasConectadas.ToString();
    }

    private string ArmarResumenFranja(FranjaTarrajeoMYG franja, DatosDeteccionMYG datos)
    {
        if (franja == null)
            return "";

        double largoM = (franja.UFin - franja.UInicio) * 0.3048;
        double altoM = (franja.ZTop - franja.ZBase) * 0.3048;

        string texto =
            "Caras usadas: " + (franja.CarasUsadas != null ? franja.CarasUsadas.Count.ToString() : "0") +
            " | Largo aprox.: " + largoM.ToString("0.00") + " m" +
            " | Alto aprox.: " + altoM.ToString("0.00") + " m";

        if (datos != null)
        {
            texto +=
                " | Evaluadas: " + datos.CarasEvaluadas.ToString() +
                " | Compatibles: " + datos.CarasCompatibles.ToString();

            if (datos.CortesTransversales > 0)
                texto += " | Cortes transversales: " + datos.CortesTransversales.ToString();
        }

        return texto;
    }

    // =========================================================
    // CATEGORÍAS / FILTROS
    // =========================================================

    private static bool EsCategoriaBasePermitida(Element e)
    {
        if (e == null || e.Category == null || e.Category.Id == null)
            return false;

        long catId = 0;

        try
        {
            catId = e.Category.Id.Value;
        }
        catch
        {
            return false;
        }

        if (catId == (long)BuiltInCategory.OST_Walls)
            return true;

        if (catId == (long)BuiltInCategory.OST_StructuralColumns)
            return true;

        if (catId == (long)BuiltInCategory.OST_Columns)
            return true;

        if (catId == (long)BuiltInCategory.OST_StructuralFraming)
            return true;

        return false;
    }

    private class FiltroSeleccionElementosBaseNativosMYG : ISelectionFilter
    {
        public bool AllowElement(Element elem)
        {
            return EsCategoriaBasePermitida(elem);
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            return true;
        }
    }

    private class FiltroSeleccionElementosBaseVinculadosMYG : ISelectionFilter
    {
        private readonly Document _docHost;

        public FiltroSeleccionElementosBaseVinculadosMYG(Document docHost)
        {
            _docHost = docHost;
        }

        public bool AllowElement(Element elem)
        {
            return elem is RevitLinkInstance;
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            if (_docHost == null || reference == null)
                return false;

            RevitLinkInstance link = _docHost.GetElement(reference.ElementId) as RevitLinkInstance;

            if (link == null)
                return false;

            Document docLink = null;

            try { docLink = link.GetLinkDocument(); } catch { docLink = null; }

            if (docLink == null)
                return false;

            ElementId linkedElementId = reference.LinkedElementId;

            if (linkedElementId == null || linkedElementId == ElementId.InvalidElementId)
                return false;

            Element elementoLink = docLink.GetElement(linkedElementId);

            return EsCategoriaBasePermitida(elementoLink);
        }
    }

    private class FiltroSeleccionCaraSemillaMYG : ISelectionFilter
    {
        private readonly Document _docHost;

        public FiltroSeleccionCaraSemillaMYG(Document docHost)
        {
            _docHost = docHost;
        }

        public bool AllowElement(Element elem)
        {
            if (elem is RevitLinkInstance)
                return true;

            return EsCategoriaBasePermitida(elem);
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            if (_docHost == null || reference == null)
                return false;

            Element elementoHost = _docHost.GetElement(reference.ElementId);

            RevitLinkInstance link = elementoHost as RevitLinkInstance;

            if (link != null)
            {
                Document docLink = null;
                try { docLink = link.GetLinkDocument(); } catch { docLink = null; }

                if (docLink == null)
                    return false;

                ElementId linkedElementId = reference.LinkedElementId;

                if (linkedElementId == null || linkedElementId == ElementId.InvalidElementId)
                    return false;

                Element elementoLink = docLink.GetElement(linkedElementId);

                return EsCategoriaBasePermitida(elementoLink);
            }

            return EsCategoriaBasePermitida(elementoHost);
        }
    }

    private void ConfigurarTransaccionParaSuprimirAdvertencias(Transaction t)
    {
        if (t == null)
            return;

        try
        {
            FailureHandlingOptions opciones = t.GetFailureHandlingOptions();
            opciones.SetFailuresPreprocessor(new EliminarAdvertenciasTarrajeoInteriorMYG());
            t.SetFailureHandlingOptions(opciones);
        }
        catch
        {
        }
    }

    private class EliminarAdvertenciasTarrajeoInteriorMYG : IFailuresPreprocessor
    {
        public FailureProcessingResult PreprocessFailures(FailuresAccessor failuresAccessor)
        {
            if (failuresAccessor == null)
                return FailureProcessingResult.Continue;

            try
            {
                IList<FailureMessageAccessor> fallas = failuresAccessor.GetFailureMessages();

                if (fallas == null || fallas.Count == 0)
                    return FailureProcessingResult.Continue;

                foreach (FailureMessageAccessor falla in fallas)
                {
                    if (falla == null)
                        continue;

                    try
                    {
                        if (falla.GetSeverity() == FailureSeverity.Warning)
                            failuresAccessor.DeleteWarning(falla);
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }

            return FailureProcessingResult.Continue;
        }
    }

    // =========================================================
    // CLASES INTERNAS
    // =========================================================

    private class ElementoConTransformMYG
    {
        public Element Elemento { get; set; }
        public Transform Transformacion { get; set; }
        public bool EsVinculado { get; set; }
        public ElementId LinkInstanceId { get; set; }
        public ElementId LinkedElementId { get; set; }
        public string NombreVinculo { get; set; }
    }

    private class CaraVerticalHostMYG
    {
        public XYZ Normal { get; set; }
        public XYZ EjeU { get; set; }
        public double PlaneD { get; set; }
        public double MinU { get; set; }
        public double MaxU { get; set; }
        public double MinZ { get; set; }
        public double MaxZ { get; set; }
        public List<XYZ> Puntos { get; set; }
    }

    private class IntervaloCaraEnSemillaMYG
    {
        public double MinU { get; set; }
        public double MaxU { get; set; }
        public double MinZ { get; set; }
        public double MaxZ { get; set; }
        public double PlaneD { get; set; }
    }

    private class IntervaloUMYG
    {
        public double Min { get; set; }
        public double Max { get; set; }
    }

    private class CaraFranjaMYG
    {
        public CaraVerticalHostMYG Cara { get; set; }
        public double MinU { get; set; }
        public double MaxU { get; set; }
        public double MinZ { get; set; }
        public double MaxZ { get; set; }
        public double PlaneD { get; set; }
        public double ScoreSemilla { get; set; }
    }

    private class FranjaTarrajeoMYG
    {
        public XYZ Normal { get; set; }
        public XYZ EjeU { get; set; }
        public double PlaneDCara { get; set; }
        public double PlaneDCentroMuro { get; set; }
        public double UInicio { get; set; }
        public double UFin { get; set; }
        public double ZBase { get; set; }
        public double ZTop { get; set; }
        public XYZ PuntoCentroPlano { get; set; }
        public List<CaraFranjaMYG> CarasUsadas { get; set; }
    }

    private class InterferenciaTarrajeoMYG
    {
        public double UInicio { get; set; }
        public double UFin { get; set; }
        public double ZBase { get; set; }
        public double ZTop { get; set; }
        public bool EsVinculado { get; set; }
        public ElementId LinkInstanceId { get; set; }
        public ElementId ElementId { get; set; }
        public bool EsHuecoAnfitrion { get; set; }
        public ElementId HostElementId { get; set; }
        public string Nombre { get; set; }
    }

    private class SegmentoFranjaMYG
    {
        public double UInicio { get; set; }
        public double UFin { get; set; }
        public double ZBase { get; set; }
        public double ZTop { get; set; }
        public List<InterferenciaTarrajeoMYG> Aberturas { get; set; }
    }

    private class DatosDeteccionMYG
    {
        public int ElementosLeidos { get; set; }
        public int ElementosOmitidos { get; set; }
        public int CarasEvaluadas { get; set; }
        public int CarasCompatibles { get; set; }
        public int CarasConectadas { get; set; }
        public int CortesTransversales { get; set; }
    }
}
