using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{


    // =====================================
    // VENTANA - TARRAJEO INTERIOR POR CARA SEMILLA / CREACIÓN INSTANTÁNEA
    // SIN USING NI NAMESPACE
    // =====================================

    public class CrearTarrajeoInteriorConfinamientoForm : System.Windows.Forms.Form
    {
        // =========================================================
        // ENUM INTERNO
        // =========================================================

        public enum TarrajeoInteriorAccion
        {
            Ninguna,
            SeleccionarElementosNativos,
            SeleccionarElementosVinculados,
            PickarCaraSemilla,
            PrevisualizarFranja,
            BorrarPrevisualizacion,
            CrearTarrajeo,
            PickarYCrearConsecutivo
        }

        // =========================================================
        // VARIABLES
        // =========================================================

        private Autodesk.Revit.UI.UIDocument _uidoc;
        private Autodesk.Revit.DB.Document _doc;

        private System.Windows.Forms.Label lblElementosSeleccionados;
        private System.Windows.Forms.Label lblUltimaCara;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Label lblTipoMuro;
        private System.Windows.Forms.Label lblNivel;
        private System.Windows.Forms.Label lblOpciones;

        private System.Windows.Forms.ComboBox cmbTipoMuro;
        private System.Windows.Forms.ComboBox cmbNivel;

        private System.Windows.Forms.CheckBox chkGuardarParametros;
        private System.Windows.Forms.CheckBox chkEvitarDuplicados;
        private System.Windows.Forms.CheckBox chkExpandirContiguas;

        private System.Windows.Forms.Button btnSeleccionarNativos;
        private System.Windows.Forms.Button btnSeleccionarVinculados;
        private System.Windows.Forms.Button btnPickarYCrear;
        private System.Windows.Forms.Button btnCerrar;

        private System.Collections.Generic.List<WallTypeItemMYG> _tiposMuro = new System.Collections.Generic.List<WallTypeItemMYG>();
        private System.Collections.Generic.List<LevelItemMYG> _niveles = new System.Collections.Generic.List<LevelItemMYG>();
        private string _ultimoResultado = "";

        public Autodesk.Revit.UI.ExternalEvent EjecutarEvent;
        public EjecutarTarrajeoInteriorConfinamientoHandler Handler;

        public System.Collections.Generic.List<ElementoTarrajeoBaseMYG> ElementosSeleccionados { get; set; }
        public CaraSemillaTarrajeoMYG CaraSemillaSeleccionada { get; set; }

        public Autodesk.Revit.DB.ElementId TipoMuroSeleccionadoId
        {
            get
            {
                if (cmbTipoMuro == null)
                    return Autodesk.Revit.DB.ElementId.InvalidElementId;

                WallTypeItemMYG item = cmbTipoMuro.SelectedItem as WallTypeItemMYG;

                if (item != null && item.Id != null)
                    return item.Id;

                return Autodesk.Revit.DB.ElementId.InvalidElementId;
            }
        }

        public Autodesk.Revit.DB.ElementId NivelSeleccionadoId
        {
            get
            {
                if (cmbNivel == null)
                    return Autodesk.Revit.DB.ElementId.InvalidElementId;

                LevelItemMYG item = cmbNivel.SelectedItem as LevelItemMYG;

                if (item != null && item.Id != null)
                    return item.Id;

                return Autodesk.Revit.DB.ElementId.InvalidElementId;
            }
        }

        public bool GuardarParametros
        {
            get
            {
                if (chkGuardarParametros == null)
                    return true;

                return chkGuardarParametros.Checked;
            }
        }

        public bool EvitarDuplicados
        {
            get
            {
                if (chkEvitarDuplicados == null)
                    return true;

                return chkEvitarDuplicados.Checked;
            }
        }

        public bool ExpandirCarasContiguas
        {
            get
            {
                if (chkExpandirContiguas == null)
                    return true;

                return chkExpandirContiguas.Checked;
            }
        }

        public CrearTarrajeoInteriorConfinamientoForm(Autodesk.Revit.UI.UIDocument uidoc)
        {
            _uidoc = uidoc;
            _doc = uidoc.Document;

            ElementosSeleccionados = new System.Collections.Generic.List<ElementoTarrajeoBaseMYG>();
            CaraSemillaSeleccionada = null;

            this.Text = "🏠 Tarrajeo Interior por Cara Semilla V14";
            this.Width = 660;
            this.Height = 560;
            this.MinimumSize = new System.Drawing.Size(660, 560);
            this.MaximumSize = new System.Drawing.Size(660, 560);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = false;

            System.Windows.Forms.Label lblAutor = new System.Windows.Forms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                Left = 20,
                Top = 8,
                Width = 610,
                Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.Gray
            };

            System.Windows.Forms.Label lblTitulo = new System.Windows.Forms.Label()
            {
                Text = "01. SELECCIONAR ELEMENTOS BASE",
                Left = 20,
                Top = 38,
                Width = 610,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            lblInfo = new System.Windows.Forms.Label()
            {
                Text = "Seleccione muros de albañilería, columnetas y vigas de confinamiento. Luego use el botón inferior para pickar caras consecutivamente y crear el tarrajeo al instante.",
                Left = 20,
                Top = 62,
                Width = 610,
                Height = 42,
                ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
            };

            btnSeleccionarNativos = new System.Windows.Forms.Button()
            {
                Text = "SELECCIONAR NATIVOS",
                Width = 210,
                Height = 34,
                Left = 20,
                Top = 108,
                BackColor = System.Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = System.Drawing.Color.White,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                Cursor = System.Windows.Forms.Cursors.Hand
            };

            btnSeleccionarNativos.FlatAppearance.BorderSize = 0;

            btnSeleccionarNativos.Click += (s, e) =>
            {
                if (Handler == null)
                    return;

                Handler.Accion = TarrajeoInteriorAccion.SeleccionarElementosNativos;
                EjecutarEvent?.Raise();
            };

            btnSeleccionarVinculados = new System.Windows.Forms.Button()
            {
                Text = "SELECCIONAR VÍNCULO",
                Width = 210,
                Height = 34,
                Left = 245,
                Top = 108,
                BackColor = System.Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = System.Drawing.Color.White,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                Cursor = System.Windows.Forms.Cursors.Hand
            };

            btnSeleccionarVinculados.FlatAppearance.BorderSize = 0;

            btnSeleccionarVinculados.Click += (s, e) =>
            {
                if (Handler == null)
                    return;

                Handler.Accion = TarrajeoInteriorAccion.SeleccionarElementosVinculados;
                EjecutarEvent?.Raise();
            };

            lblElementosSeleccionados = new System.Windows.Forms.Label()
            {
                Text = "Elementos seleccionados: Ninguno",
                Left = 20,
                Top = 153,
                Width = 610,
                Height = 68,
                ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
            };

            System.Windows.Forms.Label lblTituloConfig = new System.Windows.Forms.Label()
            {
                Text = "02. CONFIGURACIÓN DEL TARRAJEO",
                Left = 20,
                Top = 235,
                Width = 610,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            lblTipoMuro = new System.Windows.Forms.Label()
            {
                Text = "Tipo de muro delgado de tarrajeo:",
                Left = 20,
                Top = 263,
                Width = 230,
                Height = 20,
                ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
            };

            cmbTipoMuro = new System.Windows.Forms.ComboBox()
            {
                Left = 250,
                Top = 259,
                Width = 380,
                Height = 26,
                DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList,
                IntegralHeight = false,
                DropDownHeight = 220
            };

            lblNivel = new System.Windows.Forms.Label()
            {
                Text = "Nivel base automático:",
                Left = 20,
                Top = 296,
                Width = 230,
                Height = 20,
                ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
            };

            cmbNivel = new System.Windows.Forms.ComboBox()
            {
                Left = 250,
                Top = 292,
                Width = 380,
                Height = 26,
                DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList,
                IntegralHeight = false,
                DropDownHeight = 220,
                Enabled = false
            };

            lblOpciones = new System.Windows.Forms.Label()
            {
                Text = "Opciones:",
                Left = 20,
                Top = 326,
                Width = 100,
                Height = 20,
                ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
            };

            chkExpandirContiguas = new System.Windows.Forms.CheckBox()
            {
                Text = "Extender hacia ambos lados hasta no encontrar caras, junta o elemento transversal",
                Left = 20,
                Top = 349,
                Width = 560,
                Height = 22,
                Checked = true,
                ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
            };

            chkGuardarParametros = new System.Windows.Forms.CheckBox()
            {
                Text = "Guardar GEN_ID Elemento y GEN_Disciplina",
                Left = 20,
                Top = 372,
                Width = 330,
                Height = 22,
                Checked = true,
                ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
            };

            chkEvitarDuplicados = new System.Windows.Forms.CheckBox()
            {
                Text = "Evitar duplicar franja en la misma sesión",
                Left = 350,
                Top = 372,
                Width = 280,
                Height = 22,
                Checked = true,
                ForeColor = System.Drawing.Color.FromArgb(70, 70, 70)
            };

            System.Windows.Forms.Label lblTituloPick = new System.Windows.Forms.Label()
            {
                Text = "03. PICKAR Y CREAR AL INSTANTE",
                Left = 20,
                Top = 410,
                Width = 610,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
            };

            System.Windows.Forms.Label lblInfoPick = new System.Windows.Forms.Label()
            {
                Text = "Presione el botón, picke una cara interior y el tarrajeo se creará al instante. Puede seguir pickando caras consecutivamente. Presione ESC para terminar.",
                Left = 20,
                Top = 433,
                Width = 610,
                Height = 38,
                ForeColor = System.Drawing.Color.FromArgb(80, 80, 80)
            };

            btnPickarYCrear = new System.Windows.Forms.Button()
            {
                Text = "PICKAR CARAS Y CREAR",
                Width = 215,
                Height = 38,
                Left = 20,
                Top = 486,
                BackColor = System.Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = System.Drawing.Color.White,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                Cursor = System.Windows.Forms.Cursors.Hand
            };

            btnPickarYCrear.FlatAppearance.BorderSize = 0;
            btnPickarYCrear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(0, 100, 190);
            btnPickarYCrear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(0, 84, 160);

            btnPickarYCrear.Click += (s, e) =>
            {
                if (!ValidarBaseParaCrearInstantaneo())
                    return;

                if (Handler == null)
                    return;

                Handler.Accion = TarrajeoInteriorAccion.PickarYCrearConsecutivo;
                EjecutarEvent?.Raise();
            };

            btnCerrar = new System.Windows.Forms.Button()
            {
                Text = "CERRAR",
                Width = 120,
                Height = 38,
                Left = 510,
                Top = 486,
                BackColor = System.Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = System.Drawing.Color.White,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                Cursor = System.Windows.Forms.Cursors.Hand
            };

            btnCerrar.FlatAppearance.BorderSize = 0;

            btnCerrar.Click += (s, e) =>
            {
                this.Close();
            };

            lblResultado = new System.Windows.Forms.Label()
            {
                Text = "",
                Left = 250,
                Top = 472,
                Width = 245,
                Height = 66,
                Visible = true,
                ForeColor = System.Drawing.Color.FromArgb(90, 90, 90)
            };

            lblUltimaCara = new System.Windows.Forms.Label()
            {
                Text = "Última cara: No definida",
                Left = 20,
                Top = 532,
                Width = 610,
                Height = 22,
                ForeColor = System.Drawing.Color.FromArgb(90, 90, 90)
            };

            Controls.Add(lblAutor);
            Controls.Add(lblTitulo);
            Controls.Add(lblInfo);
            Controls.Add(btnSeleccionarNativos);
            Controls.Add(btnSeleccionarVinculados);
            Controls.Add(lblElementosSeleccionados);

            Controls.Add(lblTituloConfig);
            Controls.Add(lblTipoMuro);
            Controls.Add(cmbTipoMuro);
            Controls.Add(lblNivel);
            Controls.Add(cmbNivel);
            Controls.Add(lblOpciones);
            Controls.Add(chkExpandirContiguas);
            Controls.Add(chkGuardarParametros);
            Controls.Add(chkEvitarDuplicados);

            Controls.Add(lblTituloPick);
            Controls.Add(lblInfoPick);
            Controls.Add(btnPickarYCrear);
            Controls.Add(btnCerrar);
            Controls.Add(lblResultado);
            Controls.Add(lblUltimaCara);

            CargarTiposDeMuro();
            CargarNiveles();

            MostrarResultado("Seleccione elementos base y luego use PICKAR CARAS Y CREAR.");
        }

        private bool ValidarBaseParaCrearInstantaneo()
        {
            if (ElementosSeleccionados == null || ElementosSeleccionados.Count == 0)
            {
                MostrarResultado("Debe seleccionar muros, columnetas o vigas base.");
                return false;
            }

            if (TipoMuroSeleccionadoId == Autodesk.Revit.DB.ElementId.InvalidElementId)
            {
                MostrarResultado("Debe seleccionar un tipo de muro válido.");
                return false;
            }

            return true;
        }

        // =========================================================
        // CARGAR TIPOS DE MURO
        // =========================================================

        private void CargarTiposDeMuro()
        {
            if (cmbTipoMuro == null || _doc == null)
                return;

            _tiposMuro.Clear();
            cmbTipoMuro.Items.Clear();

            try
            {
                System.Collections.Generic.List<Autodesk.Revit.DB.WallType> tipos = new System.Collections.Generic.List<Autodesk.Revit.DB.WallType>();

                Autodesk.Revit.DB.FilteredElementCollector collector = new Autodesk.Revit.DB.FilteredElementCollector(_doc);
                collector.OfClass(typeof(Autodesk.Revit.DB.WallType));

                foreach (Autodesk.Revit.DB.Element elemento in collector)
                {
                    Autodesk.Revit.DB.WallType tipo = elemento as Autodesk.Revit.DB.WallType;

                    if (tipo == null)
                        continue;

                    try
                    {
                        if (tipo.Kind != Autodesk.Revit.DB.WallKind.Basic)
                            continue;
                    }
                    catch
                    {
                    }

                    tipos.Add(tipo);
                }

                tipos.Sort(delegate (Autodesk.Revit.DB.WallType a, Autodesk.Revit.DB.WallType b)
                {
                    if (a == null && b == null) return 0;
                    if (a == null) return -1;
                    if (b == null) return 1;

                    string na = "";
                    string nb = "";

                    try { na = a.FamilyName + " : " + a.Name; } catch { }
                    try { nb = b.FamilyName + " : " + b.Name; } catch { }

                    return string.Compare(na, nb, System.StringComparison.CurrentCultureIgnoreCase);
                });

                int indexTarrajeo = -1;

                foreach (Autodesk.Revit.DB.WallType tipo in tipos)
                {
                    WallTypeItemMYG item = new WallTypeItemMYG();
                    item.Id = tipo.Id;

                    string nombre = "";

                    try
                    {
                        nombre = tipo.FamilyName + " : " + tipo.Name;
                    }
                    catch
                    {
                        nombre = tipo.Name;
                    }

                    double espesorCm = 0.0;

                    try
                    {
                        espesorCm = Autodesk.Revit.DB.UnitUtils.ConvertFromInternalUnits(
                            tipo.Width,
                            Autodesk.Revit.DB.UnitTypeId.Centimeters);
                    }
                    catch
                    {
                        espesorCm = tipo.Width * 30.48;
                    }

                    item.Nombre = nombre + "  |  " + espesorCm.ToString("0.##") + " cm";

                    if (indexTarrajeo < 0)
                    {
                        string upper = item.Nombre.ToUpperInvariant();

                        if (upper.Contains("TARRAJ") || upper.Contains("TARRAJE") || upper.Contains("ACABADO"))
                            indexTarrajeo = cmbTipoMuro.Items.Count;
                    }

                    _tiposMuro.Add(item);
                    cmbTipoMuro.Items.Add(item);
                }

                if (cmbTipoMuro.Items.Count > 0)
                {
                    if (indexTarrajeo >= 0)
                        cmbTipoMuro.SelectedIndex = indexTarrajeo;
                    else
                        cmbTipoMuro.SelectedIndex = 0;
                }
            }
            catch (System.Exception ex)
            {
                MostrarResultado("Error al cargar tipos de muro: " + ex.Message);
            }
        }

        // =========================================================
        // CARGAR NIVELES
        // =========================================================

        private void CargarNiveles()
        {
            if (cmbNivel == null || _doc == null)
                return;

            _niveles.Clear();
            cmbNivel.Items.Clear();

            try
            {
                System.Collections.Generic.List<Autodesk.Revit.DB.Level> niveles = new System.Collections.Generic.List<Autodesk.Revit.DB.Level>();

                Autodesk.Revit.DB.FilteredElementCollector collector = new Autodesk.Revit.DB.FilteredElementCollector(_doc);
                collector.OfClass(typeof(Autodesk.Revit.DB.Level));

                foreach (Autodesk.Revit.DB.Element elemento in collector)
                {
                    Autodesk.Revit.DB.Level nivel = elemento as Autodesk.Revit.DB.Level;

                    if (nivel == null)
                        continue;

                    niveles.Add(nivel);
                }

                niveles.Sort(delegate (Autodesk.Revit.DB.Level a, Autodesk.Revit.DB.Level b)
                {
                    if (a == null && b == null) return 0;
                    if (a == null) return -1;
                    if (b == null) return 1;

                    return a.Elevation.CompareTo(b.Elevation);
                });

                foreach (Autodesk.Revit.DB.Level nivel in niveles)
                {
                    LevelItemMYG item = new LevelItemMYG();
                    item.Id = nivel.Id;
                    item.Nombre = nivel.Name;
                    item.Elevacion = nivel.Elevation;

                    _niveles.Add(item);
                    cmbNivel.Items.Add(item);
                }

                Autodesk.Revit.DB.Level nivelVista = null;

                try
                {
                    Autodesk.Revit.DB.ViewPlan viewPlan = _doc.ActiveView as Autodesk.Revit.DB.ViewPlan;

                    if (viewPlan != null)
                        nivelVista = viewPlan.GenLevel;
                }
                catch
                {
                    nivelVista = null;
                }

                if (nivelVista != null)
                {
                    for (int i = 0; i < cmbNivel.Items.Count; i++)
                    {
                        LevelItemMYG item = cmbNivel.Items[i] as LevelItemMYG;

                        if (item != null && item.Id.Value == nivelVista.Id.Value)
                        {
                            cmbNivel.SelectedIndex = i;
                            break;
                        }
                    }
                }

                if (cmbNivel.SelectedIndex < 0 && cmbNivel.Items.Count > 0)
                    cmbNivel.SelectedIndex = 0;
            }
            catch (System.Exception ex)
            {
                MostrarResultado("Error al cargar niveles: " + ex.Message);
            }
        }

        // =========================================================
        // ACTUALIZAR SELECCIÓN
        // =========================================================

        public void ActualizarElementosSeleccionados(System.Collections.Generic.List<ElementoTarrajeoBaseMYG> elementos)
        {
            ElementosSeleccionados = new System.Collections.Generic.List<ElementoTarrajeoBaseMYG>();

            if (elementos == null || elementos.Count == 0)
            {
                lblElementosSeleccionados.Text = "Elementos seleccionados: Ninguno";
                MostrarResultado("No se seleccionó ningún elemento válido.");
                return;
            }

            System.Collections.Generic.List<string> nombres = new System.Collections.Generic.List<string>();
            System.Collections.Generic.HashSet<string> unicos = new System.Collections.Generic.HashSet<string>();

            foreach (ElementoTarrajeoBaseMYG item in elementos)
            {
                if (item == null)
                    continue;

                string clave = item.ObtenerClaveUnica();

                if (unicos.Contains(clave))
                    continue;

                unicos.Add(clave);
                ElementosSeleccionados.Add(item);

                string texto = item.Categoria + " - " + item.Nombre;

                if (!string.IsNullOrWhiteSpace(item.NombreVinculo))
                    texto = item.NombreVinculo + " | " + texto;

                nombres.Add(texto);
            }

            if (ElementosSeleccionados.Count == 0)
            {
                lblElementosSeleccionados.Text = "Elementos seleccionados: Ninguno";
                MostrarResultado("No se seleccionó ningún elemento válido.");
                return;
            }

            string textoNombres = "";
            int maximo = System.Math.Min(4, nombres.Count);

            for (int i = 0; i < maximo; i++)
            {
                if (i > 0)
                    textoNombres += "\r\n";

                textoNombres += nombres[i];
            }

            if (nombres.Count > 4)
                textoNombres += "\r\n...";

            lblElementosSeleccionados.Text =
                "Elementos seleccionados: " + ElementosSeleccionados.Count.ToString() + "\r\n" +
                textoNombres;

            MostrarResultado("Elementos seleccionados: " + ElementosSeleccionados.Count.ToString());
        }

        public void ActualizarCaraSemilla(CaraSemillaTarrajeoMYG cara)
        {
            CaraSemillaSeleccionada = cara;

            if (lblUltimaCara == null)
                return;

            if (cara == null)
            {
                lblUltimaCara.Text = "Última cara: No definida";
                return;
            }

            string texto = "Última cara: definida";

            if (!string.IsNullOrWhiteSpace(cara.NombreVinculo))
                texto += " | " + cara.NombreVinculo + " | " + cara.Categoria;
            else
                texto += " | " + cara.Categoria;

            lblUltimaCara.Text = texto;
        }

        public void SeleccionarNivelVisual(Autodesk.Revit.DB.ElementId nivelId)
        {
            if (cmbNivel == null || nivelId == null || nivelId == Autodesk.Revit.DB.ElementId.InvalidElementId)
                return;

            try
            {
                for (int i = 0; i < cmbNivel.Items.Count; i++)
                {
                    LevelItemMYG item = cmbNivel.Items[i] as LevelItemMYG;

                    if (item == null || item.Id == null)
                        continue;

                    if (item.Id.Value == nivelId.Value)
                    {
                        cmbNivel.SelectedIndex = i;
                        break;
                    }
                }
            }
            catch
            {
            }
        }

        public void MostrarResultado(string texto)
        {
            _ultimoResultado = texto ?? "";

            if (lblResultado == null)
                return;

            lblResultado.Text = _ultimoResultado;
            lblResultado.Visible = true;

            if (string.IsNullOrWhiteSpace(_ultimoResultado))
                return;

            if (_ultimoResultado.StartsWith("ERROR", System.StringComparison.OrdinalIgnoreCase) ||
                _ultimoResultado.StartsWith("Debe", System.StringComparison.OrdinalIgnoreCase) ||
                _ultimoResultado.StartsWith("No se", System.StringComparison.OrdinalIgnoreCase) ||
                _ultimoResultado.StartsWith("Selección cancelada", System.StringComparison.OrdinalIgnoreCase))
            {
                lblResultado.ForeColor = System.Drawing.Color.FromArgb(190, 40, 40);
            }
            else
            {
                lblResultado.ForeColor = System.Drawing.Color.FromArgb(70, 70, 70);
            }
        }

        public void OcultarTemporalmenteParaSeleccion()
        {
            try
            {
                this.Hide();
            }
            catch
            {
            }
        }

        public void MostrarLuegoDeSeleccion()
        {
            try
            {
                if (!this.IsDisposed)
                {
                    this.Show();
                    this.Activate();
                    this.TopMost = true;
                }
            }
            catch
            {
            }
        }

        // =========================================================
        // CLASES INTERNAS
        // =========================================================

        private class WallTypeItemMYG
        {
            public Autodesk.Revit.DB.ElementId Id { get; set; }
            public string Nombre { get; set; }

            public override string ToString()
            {
                return Nombre;
            }
        }

        private class LevelItemMYG
        {
            public Autodesk.Revit.DB.ElementId Id { get; set; }
            public string Nombre { get; set; }
            public double Elevacion { get; set; }

            public override string ToString()
            {
                return Nombre;
            }
        }

        public class ElementoTarrajeoBaseMYG
        {
            public bool EsVinculado { get; set; }
            public Autodesk.Revit.DB.ElementId ElementIdNativo { get; set; }
            public Autodesk.Revit.DB.ElementId LinkInstanceId { get; set; }
            public Autodesk.Revit.DB.ElementId LinkedElementId { get; set; }

            public string NombreVinculo { get; set; }
            public string Nombre { get; set; }
            public string Categoria { get; set; }

            public string ObtenerClaveUnica()
            {
                if (EsVinculado)
                {
                    string link = LinkInstanceId != null ? LinkInstanceId.Value.ToString() : "0";
                    string elem = LinkedElementId != null ? LinkedElementId.Value.ToString() : "0";

                    return "L|" + link + "|" + elem;
                }
                else
                {
                    string elem = ElementIdNativo != null ? ElementIdNativo.Value.ToString() : "0";

                    return "N|" + elem;
                }
            }

            public override string ToString()
            {
                if (!string.IsNullOrWhiteSpace(NombreVinculo))
                    return NombreVinculo + " | " + Categoria + " | " + Nombre;

                return Categoria + " | " + Nombre;
            }
        }

        public class CaraSemillaTarrajeoMYG
        {
            public bool EsVinculado { get; set; }
            public Autodesk.Revit.DB.ElementId ElementIdNativo { get; set; }
            public Autodesk.Revit.DB.ElementId LinkInstanceId { get; set; }
            public Autodesk.Revit.DB.ElementId LinkedElementId { get; set; }

            public Autodesk.Revit.DB.XYZ PuntoHost { get; set; }
            public Autodesk.Revit.DB.XYZ NormalHost { get; set; }
            public Autodesk.Revit.DB.XYZ EjeUHost { get; set; }
            public double PlaneD { get; set; }
            public double MinU { get; set; }
            public double MaxU { get; set; }
            public double MinZ { get; set; }
            public double MaxZ { get; set; }

            public string NombreVinculo { get; set; }
            public string Nombre { get; set; }
            public string Categoria { get; set; }
        }
    }

}
