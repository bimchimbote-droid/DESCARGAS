using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // VENTANA MAIN 4.7 - CIELO RASO ACÚSTICO
    // FRANJA LATERAL IZQUIERDA + 3 PESTAÑAS
    // V48: agrega Reticulado Open Cell. NO CREA ExternalEvent; los recibe desde el COMANDO.
    // SIN USING NI NAMESPACE
    // =====================================

    public class MYG_CieloRasoAcustico47MainForm : System.Windows.Forms.Form
    {
        private const int ANCHO_MENU = 175;

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel panelContenido;
        private System.Windows.Forms.Button btnMenuSistemaSuspendido;
        private System.Windows.Forms.Button btnMenuBaldosasOrtogonales;
        private System.Windows.Forms.Button btnMenuReticuladoOpenCell;
        private System.Windows.Forms.PictureBox picIconoModulo;
        private System.Windows.Forms.Label lblTituloModulo;

        private Autodesk.Revit.UI.UIDocument uiDoc;

        public global::MYG_Addin.MYG_CieloRasoAcustico47.CieloRasoAcusticoForm VentanaSistemaSuspendido { get; private set; }
        public global::MYG_Addin.MYG_BaldosasOrtogonales47.BaldosasOrtogonalesForm VentanaBaldosasOrtogonales { get; private set; }
        public global::MYG_Addin.MYG_CieloRasoReticulado47.ReticuladoForm VentanaReticuladoOpenCell { get; private set; }

        private global::MYG_Addin.EjecutarCieloRasoAcustico47Handler handlerSistemaSuspendido;
        private global::MYG_Addin.EjecutarBaldosasOrtogonales47Handler handlerBaldosasOrtogonales;
        private global::MYG_Addin.EjecutarCieloRasoReticulado47Handler handlerReticuladoOpenCell;

        private Autodesk.Revit.UI.ExternalEvent eventoSistemaSuspendido;
        private Autodesk.Revit.UI.ExternalEvent eventoBaldosasOrtogonales;
        private Autodesk.Revit.UI.ExternalEvent eventoReticuladoOpenCell;

        private bool cargaInicialSistemaSolicitada = false;
        private bool cargaInicialBaldosasSolicitada = false;
        private bool cargaInicialReticuladoSolicitada = false;

        public MYG_CieloRasoAcustico47MainForm(
            Autodesk.Revit.UI.UIDocument uidoc,
            global::MYG_Addin.MYG_CieloRasoAcustico47.CieloRasoAcusticoForm ventanaSistemaSuspendido,
            global::MYG_Addin.EjecutarCieloRasoAcustico47Handler handlerSistema,
            Autodesk.Revit.UI.ExternalEvent eventoSistema,
            global::MYG_Addin.MYG_BaldosasOrtogonales47.BaldosasOrtogonalesForm ventanaBaldosas,
            global::MYG_Addin.EjecutarBaldosasOrtogonales47Handler handlerBaldosas,
            Autodesk.Revit.UI.ExternalEvent eventoBaldosas,
            global::MYG_Addin.MYG_CieloRasoReticulado47.ReticuladoForm ventanaReticulado,
            global::MYG_Addin.EjecutarCieloRasoReticulado47Handler handlerReticulado,
            Autodesk.Revit.UI.ExternalEvent eventoReticulado)
        {
            uiDoc = uidoc;

            VentanaSistemaSuspendido = ventanaSistemaSuspendido;
            handlerSistemaSuspendido = handlerSistema;
            eventoSistemaSuspendido = eventoSistema;

            VentanaBaldosasOrtogonales = ventanaBaldosas;
            handlerBaldosasOrtogonales = handlerBaldosas;
            eventoBaldosasOrtogonales = eventoBaldosas;

            VentanaReticuladoOpenCell = ventanaReticulado;
            handlerReticuladoOpenCell = handlerReticulado;
            eventoReticuladoOpenCell = eventoReticulado;

            this.Text = "ARQ 4.7 - Cielo Raso Acústico";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.ControlBox = true;
            this.MinimizeBox = true;
            this.MaximizeBox = false;
            this.ShowInTaskbar = true;
            this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;

            int anchoContenido = 790;
            int altoTotal = 865;
            this.ClientSize = new System.Drawing.Size(ANCHO_MENU + anchoContenido, altoTotal);

            CrearMenuLateral();
            CrearPanelContenido();

            this.Controls.Add(panelContenido);
            this.Controls.Add(panelMenu);

            ValidarReferenciasRecibidas();
            CargarVentanaSistemaSuspendido();

            this.FormClosed += (s, e) =>
            {
                try
                {
                    LiberarImagenIcono();
                    DisposeSiViva(VentanaSistemaSuspendido);
                    DisposeSiViva(VentanaBaldosasOrtogonales);
                    DisposeSiViva(VentanaReticuladoOpenCell);
                }
                catch
                {
                }
            };
        }

        private void DisposeSiViva(System.Windows.Forms.Form f)
        {
            if (f != null && !f.IsDisposed)
                f.Dispose();
        }

        private void ValidarReferenciasRecibidas()
        {
            if (VentanaSistemaSuspendido == null)
                throw new System.InvalidOperationException("No se recibió la ventana de Sistema suspendido.");

            if (VentanaBaldosasOrtogonales == null)
                throw new System.InvalidOperationException("No se recibió la ventana de Baldosas ortogonales.");

            if (VentanaReticuladoOpenCell == null)
                throw new System.InvalidOperationException("No se recibió la ventana de Reticulado Open Cell.");

            if (eventoSistemaSuspendido == null)
                throw new System.InvalidOperationException("No se recibió el ExternalEvent del Sistema suspendido.");

            if (eventoBaldosasOrtogonales == null)
                throw new System.InvalidOperationException("No se recibió el ExternalEvent de Baldosas ortogonales.");

            if (eventoReticuladoOpenCell == null)
                throw new System.InvalidOperationException("No se recibió el ExternalEvent de Reticulado Open Cell.");
        }

        private void CrearMenuLateral()
        {
            panelMenu = new System.Windows.Forms.Panel()
            {
                Left = 0,
                Top = 0,
                Width = ANCHO_MENU,
                Height = this.ClientSize.Height,
                Anchor = System.Windows.Forms.AnchorStyles.Top |
                         System.Windows.Forms.AnchorStyles.Bottom |
                         System.Windows.Forms.AnchorStyles.Left,
                BackColor = System.Drawing.Color.FromArgb(238, 240, 243),
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            };

            picIconoModulo = new System.Windows.Forms.PictureBox()
            {
                Left = 14,
                Top = 14,
                Width = 54,
                Height = 54,
                SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom,
                BackColor = System.Drawing.Color.Transparent
            };

            picIconoModulo.Image = CargarIconoDesdeCarpeta("cielo_raso_acustico_47_64.png");

            lblTituloModulo = new System.Windows.Forms.Label()
            {
                Text = "MYG\nCIELO RASO\nACÚSTICO",
                Left = 74,
                Top = 13,
                Width = ANCHO_MENU - 82,
                Height = 58,
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(55, 55, 55),
                BackColor = System.Drawing.Color.Transparent
            };

            System.Windows.Forms.Panel linea = new System.Windows.Forms.Panel()
            {
                Left = 0,
                Top = 84,
                Width = ANCHO_MENU,
                Height = 1,
                BackColor = System.Drawing.Color.FromArgb(210, 210, 210)
            };

            btnMenuSistemaSuspendido = CrearBotonMenu("  Sistema suspendido", 103);
            btnMenuSistemaSuspendido.Click += (s, e) => CargarVentanaSistemaSuspendido();

            btnMenuBaldosasOrtogonales = CrearBotonMenu("  Baldosas ortogonales", 145);
            btnMenuBaldosasOrtogonales.Click += (s, e) => CargarVentanaBaldosasOrtogonales();

            btnMenuReticuladoOpenCell = CrearBotonMenu("  Reticulado Open Cell", 187);
            btnMenuReticuladoOpenCell.Click += (s, e) => CargarVentanaReticuladoOpenCell();

            panelMenu.Controls.Add(picIconoModulo);
            panelMenu.Controls.Add(lblTituloModulo);
            panelMenu.Controls.Add(linea);
            panelMenu.Controls.Add(btnMenuSistemaSuspendido);
            panelMenu.Controls.Add(btnMenuBaldosasOrtogonales);
            panelMenu.Controls.Add(btnMenuReticuladoOpenCell);
        }

        private System.Windows.Forms.Button CrearBotonMenu(string texto, int top)
        {
            System.Windows.Forms.Button btn = new System.Windows.Forms.Button()
            {
                Text = texto,
                Left = 0,
                Top = top,
                Width = ANCHO_MENU - 1,
                Height = 42,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                Cursor = System.Windows.Forms.Cursors.Hand,
                BackColor = System.Drawing.Color.FromArgb(238, 240, 243),
                ForeColor = System.Drawing.Color.FromArgb(55, 55, 55)
            };

            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(225, 228, 232);
            btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(215, 218, 222);
            return btn;
        }

        private void CrearPanelContenido()
        {
            panelContenido = new System.Windows.Forms.Panel()
            {
                Left = ANCHO_MENU,
                Top = 0,
                Width = this.ClientSize.Width - ANCHO_MENU,
                Height = this.ClientSize.Height,
                Anchor = System.Windows.Forms.AnchorStyles.Top |
                         System.Windows.Forms.AnchorStyles.Bottom |
                         System.Windows.Forms.AnchorStyles.Left |
                         System.Windows.Forms.AnchorStyles.Right,
                BackColor = System.Drawing.Color.FromArgb(245, 247, 250)
            };
        }

        private void CargarVentanaSistemaSuspendido()
        {
            if (VentanaSistemaSuspendido == null || VentanaSistemaSuspendido.IsDisposed)
                return;

            MostrarFormularioEnContenido(VentanaSistemaSuspendido);
            MarcarBotonActivo(btnMenuSistemaSuspendido);

            if (!cargaInicialSistemaSolicitada)
            {
                cargaInicialSistemaSolicitada = true;
                SolicitarCargaSistemaSuspendido();
            }
        }

        private void CargarVentanaBaldosasOrtogonales()
        {
            if (VentanaBaldosasOrtogonales == null || VentanaBaldosasOrtogonales.IsDisposed)
                return;

            MostrarFormularioEnContenido(VentanaBaldosasOrtogonales);
            MarcarBotonActivo(btnMenuBaldosasOrtogonales);

            if (!cargaInicialBaldosasSolicitada)
            {
                cargaInicialBaldosasSolicitada = true;
                SolicitarCargaBaldosasOrtogonales();
            }
        }

        private void CargarVentanaReticuladoOpenCell()
        {
            if (VentanaReticuladoOpenCell == null || VentanaReticuladoOpenCell.IsDisposed)
                return;

            MostrarFormularioEnContenido(VentanaReticuladoOpenCell);
            MarcarBotonActivo(btnMenuReticuladoOpenCell);

            if (!cargaInicialReticuladoSolicitada)
            {
                cargaInicialReticuladoSolicitada = true;
                SolicitarCargaReticuladoOpenCell();
            }
        }

        private void MostrarFormularioEnContenido(System.Windows.Forms.Form form)
        {
            if (form == null || panelContenido == null)
                return;

            panelContenido.SuspendLayout();
            panelContenido.Controls.Clear();

            form.TopLevel = false;
            form.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            form.Dock = System.Windows.Forms.DockStyle.Fill;
            form.Visible = true;

            panelContenido.Controls.Add(form);
            form.Show();
            form.BringToFront();
            panelContenido.ResumeLayout();
        }

        private void MarcarBotonActivo(System.Windows.Forms.Button activo)
        {
            System.Drawing.Color azul = System.Drawing.Color.FromArgb(0, 122, 204);
            System.Drawing.Color fondo = System.Drawing.Color.FromArgb(238, 240, 243);
            System.Drawing.Color texto = System.Drawing.Color.FromArgb(55, 55, 55);

            System.Windows.Forms.Button[] botones = new System.Windows.Forms.Button[]
            {
            btnMenuSistemaSuspendido,
            btnMenuBaldosasOrtogonales,
            btnMenuReticuladoOpenCell
            };

            foreach (System.Windows.Forms.Button b in botones)
            {
                if (b == null)
                    continue;

                if (b == activo)
                {
                    b.BackColor = azul;
                    b.ForeColor = System.Drawing.Color.White;
                }
                else
                {
                    b.BackColor = fondo;
                    b.ForeColor = texto;
                }
            }
        }

        private void SolicitarCargaSistemaSuspendido()
        {
            try { VentanaSistemaSuspendido.SolicitarCargaInicial(); } catch { }
        }

        private void SolicitarCargaBaldosasOrtogonales()
        {
            try { VentanaBaldosasOrtogonales.SolicitarCargaInicial(); } catch { }
        }

        private void SolicitarCargaReticuladoOpenCell()
        {
            try { VentanaReticuladoOpenCell.SolicitarCargaInicial(); } catch { }
        }

        private System.Drawing.Image CargarIconoDesdeCarpeta(string nombreArchivo)
        {
            try
            {
                string baseDir = System.IO.Path.GetDirectoryName(
                    System.Reflection.Assembly.GetExecutingAssembly().Location);

                if (string.IsNullOrWhiteSpace(baseDir))
                    return CrearIconoRespaldo();

                string[] rutas = new string[]
                {
                System.IO.Path.Combine(baseDir, "iconos", nombreArchivo),
                System.IO.Path.Combine(baseDir, nombreArchivo)
                };

                foreach (string ruta in rutas)
                {
                    if (!System.IO.File.Exists(ruta))
                        continue;

                    using (System.Drawing.Image imgTemp = System.Drawing.Image.FromFile(ruta))
                    {
                        return new System.Drawing.Bitmap(imgTemp);
                    }
                }
            }
            catch
            {
            }

            return CrearIconoRespaldo();
        }

        private System.Drawing.Image CrearIconoRespaldo()
        {
            System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(64, 64);

            using (System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(bmp))
            using (System.Drawing.Pen pen = new System.Drawing.Pen(System.Drawing.Color.FromArgb(60, 60, 60), 2))
            using (System.Drawing.Brush gris = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(170, 170, 170)))
            using (System.Drawing.Brush amarillo = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(220, 185, 70)))
            using (System.Drawing.Brush negro = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(35, 35, 35)))
            {
                g.Clear(System.Drawing.Color.Transparent);
                g.FillRectangle(gris, 12, 8, 40, 7);
                g.DrawRectangle(pen, 12, 8, 40, 7);
                g.DrawLine(pen, 22, 15, 22, 34);
                g.DrawLine(pen, 42, 15, 42, 34);
                g.FillRectangle(gris, 13, 34, 38, 7);
                g.DrawRectangle(pen, 13, 34, 38, 7);
                g.FillRectangle(amarillo, 13, 43, 38, 7);
                g.DrawRectangle(pen, 13, 43, 38, 7);
                g.FillRectangle(negro, 13, 52, 38, 8);
                g.DrawRectangle(pen, 13, 52, 38, 8);
            }

            return bmp;
        }

        private void LiberarImagenIcono()
        {
            try
            {
                if (picIconoModulo != null && picIconoModulo.Image != null)
                {
                    System.Drawing.Image img = picIconoModulo.Image;
                    picIconoModulo.Image = null;
                    img.Dispose();
                }
            }
            catch
            {
            }
        }
    }

}
