﻿// =====================================
// HANDLER EXTERNO 4.7
// CIELO RASO ACÚSTICO SUSPENDIDO DESDE SUPERFICIE - V34
// CAPAS: PRINCIPALES/PERIMETRAL EN BASE, SECUNDARIOS ENCIMA, COLGADOR ENCIMA
// CON USING Y NAMESPACE
// REVIT 2027
// V21: Marco perimetral sin clash, esquinas tipo tope alternado
// Base: V12 con rotación de sección transversal invertida/corregida
// V13: permite extender principales/secundarios hasta el perímetro real de la cara
// V14: agrega colgadores sobre marco perimetral
// V15: crea capas verticales: perfil principal/perimetral en contacto, secundario sobre principal y base del colgador sobre secundario
// V16: principales y secundarios en ambas direcciones; colgadores cada 2 x separación secundaria
// V17: el input de desfase solo afecta perfiles; el colgador usa solo Alto principal + Alto secundario
// V42: colgadores detectan caras superiores de vínculos Revit
// V43: si no hay caras guía, orientación automática por luz/boceto del elemento pickado
// V51: colgadores sobre perimetral arrancan al nivel del primer perfil + offset superior de colgador
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MYG_Addin
{
    public class EjecutarCieloRasoAcustico47Handler : IExternalEventHandler
    {
        public UIDocument UiDoc { get; set; }
        internal MYG_CieloRasoAcustico47.CieloRasoAcusticoForm Form { get; set; }

        private SuperficiePickada superficiePickada;
        private DireccionManual direccionManual;
        private GuiaLineasOrtogonales guiaLineas;

        public string GetName()
        {
            return "MYG - Cielo raso acústico suspendido";
        }

        public void Execute(UIApplication app)
        {
            if (UiDoc == null || UiDoc.Document == null)
                return;

            if (Form == null || Form.IsDisposed)
                return;

            Document doc = UiDoc.Document;

            try
            {
                switch (Form.OperacionSolicitada)
                {
                    case MYG_CieloRasoAcustico47.Operacion.CargarDatos:
                        CargarDatos(doc);
                        break;

                    case MYG_CieloRasoAcustico47.Operacion.PickarSuperficie:
                        PickarSuperficie(doc);
                        break;

                    case MYG_CieloRasoAcustico47.Operacion.PickarSuperficieYGenerar:
                        PickarSuperficieYGenerar(doc);
                        break;

                    case MYG_CieloRasoAcustico47.Operacion.PickarOrientacion:
                        PickarOrientacion(doc);
                        break;

                    case MYG_CieloRasoAcustico47.Operacion.PickarCaraGuia:
                        PickarCaraGuia(doc);
                        break;

                    case MYG_CieloRasoAcustico47.Operacion.PickarDosLineasGuia:
                        PickarDosCarasGuia(doc);
                        break;

                    case MYG_CieloRasoAcustico47.Operacion.UsarGuiaAutomatica:
                        UsarGuiaAutomatica();
                        break;

                    case MYG_CieloRasoAcustico47.Operacion.GenerarSistema:
                        GenerarSistema(doc);
                        break;
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                Mostrar("Operación cancelada por el usuario.");
            }
            catch (Exception ex)
            {
                Mostrar("ERROR GENERAL:\r\n" + ex.Message);
            }
        }

        // =========================================================
        // CARGA DE DATOS
        // =========================================================

        private void CargarDatos(Document doc)
        {
            List<MYG_CieloRasoAcustico47.ComboItem> perfiles = ObtenerPerfilesEstructurales(doc);
            List<MYG_CieloRasoAcustico47.ComboItem> colgadores = ObtenerColgadoresModeloGenerico(doc);
            List<MYG_CieloRasoAcustico47.ComboItem> niveles = ObtenerNiveles(doc);

            Form.SetCatalogos(perfiles, colgadores, niveles);
        }

        private List<MYG_CieloRasoAcustico47.ComboItem> ObtenerPerfilesEstructurales(Document doc)
        {
            List<FamilySymbol> todos = new FilteredElementCollector(doc)
                .OfClass(typeof(FamilySymbol))
                .Cast<FamilySymbol>()
                .Where(x => x != null && x.Family != null && x.Category != null)
                .ToList();

            List<FamilySymbol> perfiles = todos
                .Where(EsArmazonEstructural)
                .OrderBy(x => x.Family.Name)
                .ThenBy(x => x.Name)
                .ToList();

            return perfiles
                .Select(x => new MYG_CieloRasoAcustico47.ComboItem(
                    x.Id,
                    x.Family.Name + " : " + x.Name + "  [" + x.Category.Name + "]"))
                .ToList();
        }

        private List<MYG_CieloRasoAcustico47.ComboItem> ObtenerColgadoresModeloGenerico(Document doc)
        {
            List<FamilySymbol> todos = new FilteredElementCollector(doc)
                .OfClass(typeof(FamilySymbol))
                .Cast<FamilySymbol>()
                .Where(x => x != null && x.Family != null && x.Category != null)
                .ToList();

            List<FamilySymbol> candidatos = todos
                .Where(x => EsModeloGenerico(x) && EsFamiliaCandidataColgador(x))
                .ToList();

            if (candidatos.Count == 0)
            {
                candidatos = todos
                    .Where(EsModeloGenerico)
                    .ToList();
            }

            return candidatos
                .OrderBy(x => x.Family.Name)
                .ThenBy(x => x.Name)
                .Select(x => new MYG_CieloRasoAcustico47.ComboItem(
                    x.Id,
                    x.Family.Name + " : " + x.Name + "  [" + x.Category.Name + "]"))
                .ToList();
        }

        private List<MYG_CieloRasoAcustico47.ComboItem> ObtenerNiveles(Document doc)
        {
            return new FilteredElementCollector(doc)
                .OfClass(typeof(Level))
                .Cast<Level>()
                .OrderBy(x => x.Elevation)
                .Select(x => new MYG_CieloRasoAcustico47.ComboItem(
                    x.Id,
                    x.Name + "  | Elev.: " + FeetToMeters(x.Elevation).ToString("0.###") + " m"))
                .ToList();
        }

        private bool EsArmazonEstructural(FamilySymbol fs)
        {
            if (fs == null || fs.Category == null)
                return false;

            string cat = Normalizar(fs.Category.Name);

            if (cat.Contains("ARMAZON_ESTRUCTURAL")) return true;
            if (cat.Contains("STRUCTURAL_FRAMING")) return true;
            if (cat.Contains("STRUCTURALFRAMING")) return true;

            try
            {
                if (fs.Category.Id.Value == (long)BuiltInCategory.OST_StructuralFraming)
                    return true;
            }
            catch
            {
            }

            return false;
        }

        private bool EsModeloGenerico(FamilySymbol fs)
        {
            if (fs == null || fs.Category == null)
                return false;

            string cat = Normalizar(fs.Category.Name);

            if (cat.Contains("MODELOS_GENERICOS")) return true;
            if (cat.Contains("GENERIC_MODELS")) return true;
            if (cat.Contains("GENERICMODEL")) return true;

            try
            {
                if (fs.Category.Id.Value == (long)BuiltInCategory.OST_GenericModel)
                    return true;
            }
            catch
            {
            }

            return false;
        }

        private bool EsFamiliaCandidataColgador(FamilySymbol fs)
        {
            if (fs == null)
                return false;

            string texto = Normalizar(
                (fs.Family != null ? fs.Family.Name : "") + " " +
                fs.Name + " " +
                (fs.Category != null ? fs.Category.Name : ""));

            if (texto.Contains("COLGADOR")) return true;
            if (texto.Contains("HANGER")) return true;
            if (texto.Contains("VARILLA")) return true;
            if (texto.Contains("ROSCADA")) return true;
            if (texto.Contains("SOPORTE")) return true;
            if (texto.Contains("SUSPENDIDO")) return true;
            if (texto.Contains("ANCLAJE")) return true;

            return false;
        }

        // =========================================================
        // PICK SUPERFICIE / ORIENTACIÓN
        // =========================================================

        private void PickarSuperficieYGenerar(Document doc)
        {
            bool estabaVisible = Form != null && Form.Visible;

            try
            {
                if (Form != null && !Form.IsDisposed)
                    Form.Hide();

                Reference referencia = UiDoc.Selection.PickObject(
                    ObjectType.Face,
                    new FiltroSeleccionSuperficie(),
                    "Picka la CARA SUPERIOR de la baldosa/panel y se generará el sistema automáticamente");

                if (referencia == null)
                    return;

                SuperficiePickada data = LeerSuperficiePickada(doc, referencia);

                if (data == null)
                {
                    Mostrar("No se pudo leer la superficie pickada.");
                    return;
                }

                if (data.PoligonoExterior3D == null || data.PoligonoExterior3D.Count < 3)
                {
                    Mostrar("La cara pickada no tiene un contorno válido.");
                    return;
                }

                superficiePickada = data;

                Form.SetSuperficieSeleccionada(
                    "Superficie activa: Elemento Id " + data.ElementId.Value +
                    " | Área aprox.: " + Feet2ToMeters2(data.AreaAproximada).ToString("0.###") + " m²");

                if (direccionManual == null || direccionManual.DirU == null || direccionManual.DirU.GetLength() < 0.000001)
                    Form.RestaurarOrientacionAutomatica();
                else if (guiaLineas != null && guiaLineas.Activa)
                    Form.SetOrientacionLineasGuia("Orientación: 2 caras guía activas para parrilla ortogonal.");
                else if (direccionManual.EsCaraGuia)
                    Form.SetOrientacionCaraGuia("Orientación: cara guía activa para perfiles principales.");
                else
                    Form.SetOrientacionManual("Orientación: manual activa para perfiles principales.");

                // Genera inmediatamente con la configuración actual de la ventana.
                GenerarSistema(doc);
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                Mostrar("Pick de superficie cancelado por el usuario.");
            }
            catch (Exception ex)
            {
                Mostrar("No se pudo pickar la superficie y generar el sistema:\r\n" + ex.Message);
            }
            finally
            {
                try
                {
                    if (estabaVisible && Form != null && !Form.IsDisposed)
                        Form.Show();
                }
                catch
                {
                }
            }
        }

        private void PickarSuperficie(Document doc)
        {
            bool estabaVisible = Form != null && Form.Visible;

            try
            {
                if (Form != null && !Form.IsDisposed)
                    Form.Hide();

                Reference referencia = UiDoc.Selection.PickObject(
                    ObjectType.Face,
                    new FiltroSeleccionSuperficie(),
                    "Picka la CARA SUPERIOR de la baldosa/panel desde donde se generará la estructura");

                if (referencia == null)
                    return;

                SuperficiePickada data = LeerSuperficiePickada(doc, referencia);

                if (data == null)
                {
                    Mostrar("No se pudo leer la superficie pickada.");
                    return;
                }

                if (data.PoligonoExterior3D == null || data.PoligonoExterior3D.Count < 3)
                {
                    Mostrar("La cara pickada no tiene un contorno válido.");
                    return;
                }

                superficiePickada = data;

                Form.SetSuperficieSeleccionada(
                    "Superficie activa: Elemento Id " + data.ElementId.Value +
                    " | Área aprox.: " + Feet2ToMeters2(data.AreaAproximada).ToString("0.###") + " m²");

                if (direccionManual == null || direccionManual.DirU == null || direccionManual.DirU.GetLength() < 0.000001)
                    Form.RestaurarOrientacionAutomatica();
                else if (guiaLineas != null && guiaLineas.Activa)
                    Form.SetOrientacionLineasGuia("Orientación: 2 caras guía activas para parrilla ortogonal.");
                else if (direccionManual.EsCaraGuia)
                    Form.SetOrientacionCaraGuia("Orientación: cara guía activa para perfiles principales.");
                else
                    Form.SetOrientacionManual("Orientación: manual activa para perfiles principales.");
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                Mostrar("Pick de superficie cancelado por el usuario.");
            }
            catch (Exception ex)
            {
                Mostrar("No se pudo pickar la superficie:\r\n" + ex.Message);
            }
            finally
            {
                try
                {
                    if (estabaVisible && Form != null && !Form.IsDisposed)
                        Form.Show();
                }
                catch
                {
                }
            }
        }

        private void PickarDosCarasGuia(Document doc)
        {
            bool estabaVisible = Form != null && Form.Visible;

            try
            {
                if (Form != null && !Form.IsDisposed)
                    Form.Hide();

                Reference r1 = UiDoc.Selection.PickObject(
                    ObjectType.Face,
                    new FiltroSeleccionSuperficie(),
                    "Picka la PRIMERA CARA GUÍA. Debe ser una cara vertical o casi vertical. Esta define la dirección principal U de la parrilla.");

                if (r1 == null)
                    return;

                Reference r2 = UiDoc.Selection.PickObject(
                    ObjectType.Face,
                    new FiltroSeleccionSuperficie(),
                    "Picka la SEGUNDA CARA GUÍA ortogonal. Debe ser otra cara vertical o casi vertical.");

                if (r2 == null)
                    return;

                CaraGuiaData cara1 = LeerCaraGuiaParaParrilla(doc, r1, "primera");
                CaraGuiaData cara2 = LeerCaraGuiaParaParrilla(doc, r2, "segunda");

                if (cara1 == null || cara2 == null)
                {
                    Mostrar("No se pudo leer una o ambas caras guía. Debes pickar caras planas, preferiblemente verticales.");
                    return;
                }

                XYZ dir1 = cara1.DireccionParalelaPlanta;
                XYZ dir2 = cara2.DireccionParalelaPlanta;

                if (dir1 == null || dir1.GetLength() < 0.000001 || dir2 == null || dir2.GetLength() < 0.000001)
                {
                    Mostrar("Las caras guía no generan direcciones en planta válidas.");
                    return;
                }

                dir1 = dir1.Normalize();
                dir2 = dir2.Normalize();

                double paralelismo = Math.Abs(dir1.DotProduct(dir2));

                if (paralelismo > 0.30)
                {
                    Mostrar("Las 2 caras guía no parecen ortogonales. Picka dos caras aproximadamente perpendiculares.");
                    return;
                }

                guiaLineas = new GuiaLineasOrtogonales();
                guiaLineas.Activa = true;
                guiaLineas.PuntoLineaU = cara1.Punto;
                guiaLineas.PuntoLineaV = cara2.Punto;
                guiaLineas.DirUPlanta = dir1;
                guiaLineas.DirVPlanta = dir2;
                guiaLineas.NormalLibreUPlanta = cara1.NormalPlanta;
                guiaLineas.NormalLibreVPlanta = cara2.NormalPlanta;
                guiaLineas.ElementIdLineaU = r1.ElementId;
                guiaLineas.ElementIdLineaV = r2.ElementId;
                guiaLineas.EsCaraGuia = true;

                direccionManual = new DireccionManual();
                direccionManual.DirU = dir1;
                direccionManual.EsCaraGuia = true;
                direccionManual.EsLineasGuia = true;
                direccionManual.Descripcion = "2 caras guía ortogonales";

                Form.SetOrientacionLineasGuia(
                    "Orientación: 2 caras guía activas | U Id " + r1.ElementId.Value + " | V Id " + r2.ElementId.Value);
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                Mostrar("Pick de caras guía cancelado por el usuario.");
            }
            catch (Exception ex)
            {
                Mostrar("No se pudo pickar las 2 caras guía:\r\n" + ex.Message);
            }
            finally
            {
                try
                {
                    if (estabaVisible && Form != null && !Form.IsDisposed)
                        Form.Show();
                }
                catch
                {
                }
            }
        }

        private CaraGuiaData LeerCaraGuiaParaParrilla(Document doc, Reference referencia, string nombre)
        {
            if (doc == null || referencia == null)
                return null;

            Element elemento = doc.GetElement(referencia.ElementId);

            if (elemento == null)
                return null;

            GeometryObject obj = elemento.GetGeometryObjectFromReference(referencia);
            PlanarFace pf = obj as PlanarFace;

            if (pf == null)
                throw new InvalidOperationException("La " + nombre + " cara guía no es plana.");

            XYZ normal = pf.FaceNormal;

            if (normal == null || normal.GetLength() < 0.000001)
                throw new InvalidOperationException("No se pudo obtener la normal de la " + nombre + " cara guía.");

            normal = normal.Normalize();

            XYZ normalPlanta = new XYZ(normal.X, normal.Y, 0.0);

            if (normalPlanta.GetLength() < 0.000001)
                throw new InvalidOperationException("La " + nombre + " cara guía parece horizontal. Debes pickar una cara vertical o casi vertical.");

            normalPlanta = normalPlanta.Normalize();

            XYZ dirParalela = XYZ.BasisZ.CrossProduct(normalPlanta);

            if (dirParalela == null || dirParalela.GetLength() < 0.000001)
                throw new InvalidOperationException("No se pudo obtener la dirección paralela de la " + nombre + " cara guía.");

            XYZ punto = referencia.GlobalPoint;

            if (punto == null)
                punto = pf.Origin;

            // Se usa la normal horizontal de la cara como lado libre.
            // En la práctica, al pickar la cara visible del muro/luminaria/equipo, la normal suele apuntar hacia el lado donde debe quedar el eje del armazón.
            CaraGuiaData data = new CaraGuiaData();
            data.ElementId = elemento.Id;
            data.Punto = punto;
            data.NormalPlanta = normalPlanta;
            data.DireccionParalelaPlanta = dirParalela.Normalize();
            return data;
        }

        private void UsarGuiaAutomatica()
        {
            direccionManual = null;
            guiaLineas = null;

            if (Form != null && !Form.IsDisposed)
            {
                Form.RestaurarOrientacionAutomatica();
                Form.MostrarResultado("Guía automática activa. La parrilla tomará la orientación automática de la cara seleccionada.");
            }
        }

        private Curve ObtenerCurvaGuiaDesdeReferencia(Document doc, Reference referencia)
        {
            if (doc == null || referencia == null)
                return null;

            Element e = doc.GetElement(referencia.ElementId);

            if (e == null)
                return null;

            CurveElement ce = e as CurveElement;

            if (ce != null && ce.GeometryCurve != null)
                return ce.GeometryCurve;

            Grid grid = e as Grid;

            if (grid != null && grid.Curve != null)
                return grid.Curve;

            LocationCurve lc = e.Location as LocationCurve;

            if (lc != null && lc.Curve != null)
                return lc.Curve;

            return null;
        }

        private XYZ ObtenerDireccionHorizontalDeCurva(Curve curva)
        {
            if (curva == null)
                return XYZ.Zero;

            XYZ p0 = curva.GetEndPoint(0);
            XYZ p1 = curva.GetEndPoint(1);
            XYZ dir = p1 - p0;
            XYZ horizontal = new XYZ(dir.X, dir.Y, 0.0);

            if (horizontal.GetLength() < 0.000001)
                return XYZ.Zero;

            return horizontal.Normalize();
        }

        private XYZ ObtenerPuntoMedioCurva(Curve curva)
        {
            if (curva == null)
                return XYZ.Zero;

            try
            {
                return curva.Evaluate(0.5, true);
            }
            catch
            {
                return (curva.GetEndPoint(0) + curva.GetEndPoint(1)) * 0.5;
            }
        }

        private void PickarCaraGuia(Document doc)
        {
            bool estabaVisible = Form != null && Form.Visible;

            try
            {
                if (Form != null && !Form.IsDisposed)
                    Form.Hide();

                Reference referencia = UiDoc.Selection.PickObject(
                    ObjectType.Face,
                    new FiltroSeleccionSuperficie(),
                    "Picka una CARA VERTICAL de luminaria/equipo/muro guía para alinear los perfiles principales");

                if (referencia == null)
                    return;

                Element elemento = doc.GetElement(referencia.ElementId);

                if (elemento == null)
                {
                    Mostrar("No se pudo leer el elemento de la cara guía.");
                    return;
                }

                GeometryObject obj = elemento.GetGeometryObjectFromReference(referencia);
                Face face = obj as Face;
                PlanarFace planarFace = face as PlanarFace;

                if (planarFace == null)
                {
                    Mostrar("La cara guía debe ser una cara plana.");
                    return;
                }

                XYZ dirGuia = ObtenerDireccionPlantaDesdeCaraGuia(planarFace);

                if (dirGuia == null || dirGuia.GetLength() < 0.000001)
                {
                    Mostrar("No se pudo obtener una dirección horizontal válida desde la cara guía.");
                    return;
                }

                guiaLineas = null;
                direccionManual = new DireccionManual();
                direccionManual.DirU = dirGuia.Normalize();
                direccionManual.EsCaraGuia = true;
                direccionManual.Descripcion = "Cara guía Id " + elemento.Id.Value;

                Form.SetOrientacionCaraGuia(
                    "Orientación: cara guía activa | Elemento Id " + elemento.Id.Value);
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                Mostrar("Pick de cara guía cancelado por el usuario.");
            }
            catch (Exception ex)
            {
                Mostrar("No se pudo pickar la cara guía:\r\n" + ex.Message);
            }
            finally
            {
                try
                {
                    if (estabaVisible && Form != null && !Form.IsDisposed)
                        Form.Show();
                }
                catch
                {
                }
            }
        }

        private XYZ ObtenerDireccionPlantaDesdeCaraGuia(PlanarFace planarFace)
        {
            if (planarFace == null)
                return XYZ.Zero;

            XYZ normalFace = planarFace.FaceNormal;

            if (normalFace == null || normalFace.GetLength() < 0.000001)
                return XYZ.Zero;

            normalFace = normalFace.Normalize();

            // Si la cara es vertical o casi vertical, su normal apunta en planta.
            // La dirección paralela horizontal de esa cara se obtiene cruzando Z con la normal.
            XYZ normalHorizontal = new XYZ(normalFace.X, normalFace.Y, 0.0);

            if (normalHorizontal.GetLength() > 0.000001)
            {
                XYZ dirParalela = XYZ.BasisZ.CrossProduct(normalHorizontal);

                if (dirParalela != null && dirParalela.GetLength() > 0.000001)
                    return dirParalela.Normalize();
            }

            // Respaldo: intenta usar los vectores propios de la cara y proyectarlos a planta.
            XYZ xVec = XYZ.Zero;
            XYZ yVec = XYZ.Zero;

            try
            {
                xVec = planarFace.XVector;
                yVec = planarFace.YVector;
            }
            catch
            {
            }

            XYZ dirX = new XYZ(xVec.X, xVec.Y, 0.0);

            if (dirX.GetLength() > 0.000001)
                return dirX.Normalize();

            XYZ dirY = new XYZ(yVec.X, yVec.Y, 0.0);

            if (dirY.GetLength() > 0.000001)
                return dirY.Normalize();

            return XYZ.Zero;
        }

        private void PickarOrientacion(Document doc)
        {
            if (superficiePickada == null)
            {
                Mostrar("Primero debes pickar una superficie.");
                return;
            }

            bool estabaVisible = Form != null && Form.Visible;

            try
            {
                if (Form != null && !Form.IsDisposed)
                    Form.Hide();

                XYZ p1 = UiDoc.Selection.PickPoint("Picka el primer punto de orientación de los perfiles principales");
                XYZ p2 = UiDoc.Selection.PickPoint("Picka el segundo punto de orientación de los perfiles principales");

                XYZ dir = p2 - p1;
                dir = ProyectarVectorEnPlano(dir, superficiePickada.Normal);

                if (dir == null || dir.GetLength() < 0.000001)
                {
                    Mostrar("La orientación pickada no es válida. Los puntos no generan una dirección sobre el plano.");
                    return;
                }

                guiaLineas = null;
                direccionManual = new DireccionManual();
                direccionManual.DirU = dir.Normalize();
                direccionManual.EsCaraGuia = false;
                direccionManual.Descripcion = "Orientación manual por 2 puntos";

                Form.SetOrientacionManual("Orientación: manual activa para perfiles principales.");
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                Mostrar("Pick de orientación cancelado por el usuario.");
            }
            catch (Exception ex)
            {
                Mostrar("No se pudo pickar la orientación:\r\n" + ex.Message);
            }
            finally
            {
                try
                {
                    if (estabaVisible && Form != null && !Form.IsDisposed)
                        Form.Show();
                }
                catch
                {
                }
            }
        }

        private SuperficiePickada LeerSuperficiePickada(Document doc, Reference referencia)
        {
            Element elemento = doc.GetElement(referencia.ElementId);

            if (elemento == null)
                return null;

            GeometryObject obj = elemento.GetGeometryObjectFromReference(referencia);
            Face face = obj as Face;
            PlanarFace planarFace = face as PlanarFace;

            if (planarFace == null)
                throw new InvalidOperationException("Por ahora este módulo trabaja con superficies planas. La cara seleccionada no es PlanarFace.");

            XYZ normal = planarFace.FaceNormal;

            if (normal == null || normal.GetLength() < 0.000001)
                throw new InvalidOperationException("No se pudo obtener la normal de la cara.");

            normal = normal.Normalize();

            XYZ dirU = null;
            XYZ dirV = null;

            try
            {
                dirU = planarFace.XVector;
                dirV = planarFace.YVector;
            }
            catch
            {
            }

            if (dirU == null || dirU.GetLength() < 0.000001)
                ConstruirEjesDesdeNormal(normal, out dirU, out dirV);
            else
            {
                dirU = ProyectarVectorEnPlano(dirU, normal).Normalize();
                dirV = normal.CrossProduct(dirU).Normalize();
            }

            List<XYZ> exterior = ObtenerLoopExterior(planarFace, planarFace.Origin, dirU, dirV);

            if (exterior == null || exterior.Count < 3)
                throw new InvalidOperationException("No se pudo obtener el contorno exterior de la cara.");

            double area = Math.Abs(AreaPoligono(ProyectarPoligono(exterior, planarFace.Origin, dirU, dirV)));

            SuperficiePickada data = new SuperficiePickada();
            data.ElementId = elemento.Id;
            data.ElementUniqueId = elemento.UniqueId;
            data.FaceReference = referencia;
            data.Face = face;
            data.PlanarFace = planarFace;
            data.Origin = planarFace.Origin;
            data.Normal = normal;
            data.DirU = dirU;
            data.DirV = dirV;
            data.PoligonoExterior3D = exterior;
            data.AreaAproximada = area;

            return data;
        }

        private List<XYZ> ObtenerLoopExterior(PlanarFace face, XYZ origen, XYZ dirU, XYZ dirV)
        {
            IList<CurveLoop> loops = face.GetEdgesAsCurveLoops();

            if (loops == null || loops.Count == 0)
                return null;

            List<XYZ> mejor = null;
            double mejorArea = 0.0;

            foreach (CurveLoop loop in loops)
            {
                List<XYZ> puntos = TessellarLoop(loop);

                if (puntos == null || puntos.Count < 3)
                    continue;

                List<P2> p2 = ProyectarPoligono(puntos, origen, dirU, dirV);
                double area = Math.Abs(AreaPoligono(p2));

                if (area > mejorArea)
                {
                    mejorArea = area;
                    mejor = puntos;
                }
            }

            return mejor;
        }

        private List<XYZ> TessellarLoop(CurveLoop loop)
        {
            List<XYZ> puntos = new List<XYZ>();

            if (loop == null)
                return puntos;

            foreach (Curve c in loop)
            {
                if (c == null)
                    continue;

                IList<XYZ> tess = c.Tessellate();

                if (tess == null)
                    continue;

                foreach (XYZ p in tess)
                    AgregarPuntoUnico(puntos, p, MetersToFeet(0.001));
            }

            if (puntos.Count > 2)
            {
                XYZ primero = puntos.First();
                XYZ ultimo = puntos.Last();

                if (primero.DistanceTo(ultimo) <= MetersToFeet(0.001))
                    puntos.RemoveAt(puntos.Count - 1);
            }

            return puntos;
        }

        private void AgregarPuntoUnico(List<XYZ> puntos, XYZ p, double tol)
        {
            if (puntos == null || p == null)
                return;

            if (puntos.Count == 0)
            {
                puntos.Add(p);
                return;
            }

            XYZ ultimo = puntos[puntos.Count - 1];

            if (ultimo.DistanceTo(p) > tol)
                puntos.Add(p);
        }

        // =========================================================
        // GENERACIÓN
        // =========================================================

        private void GenerarSistema(Document doc)
        {
            if (superficiePickada == null)
            {
                Mostrar("Primero debes pickar la superficie de referencia.");
                return;
            }

            FamilySymbol perfilPrincipal = doc.GetElement(Form.PerfilPrincipalId) as FamilySymbol;
            FamilySymbol perfilSecundario = doc.GetElement(Form.PerfilSecundarioId) as FamilySymbol;
            FamilySymbol colgador = doc.GetElement(Form.ColgadorId) as FamilySymbol;

            // V3:
            // El nivel de referencia de los perfiles se detecta automáticamente
            // en función de la elevación de la cara pickada. El combo de nivel
            // de la ventana queda solo como referencia visual / respaldo.
            Level nivel = null;

            if ((Form.CrearMarco || Form.CrearPrincipales) && perfilPrincipal == null)
            {
                Mostrar("Debes seleccionar el tipo de perfil principal.");
                return;
            }

            if (Form.CrearSecundarios && perfilSecundario == null)
            {
                Mostrar("Debes seleccionar el tipo de perfil secundario.");
                return;
            }

            if (Form.CrearColgadores && colgador == null)
            {
                Mostrar("Debes seleccionar la familia/tipo de colgador.");
                return;
            }

            double camara = MetersToFeet(Form.CamaraTecnicaMetros);
            double sepPrincipal = MetersToFeet(Form.SeparacionPrincipalMetros);
            double sepSecundario = MetersToFeet(Form.SeparacionSecundarioMetros);

            // V16:
            // La separación de colgadores ya no se toma del input manual.
            // Se calcula automáticamente como el doble de la separación de perfiles secundarios,
            // es decir, deja un punto intermedio libre entre colgadores.
            double sepColgador = sepSecundario * 2.0;

            double margen = MetersToFeet(Form.MargenPerimetralMetros);
            double longitudMinima = MetersToFeet(Form.LongitudMinimaMetros);
            double offsetSuperiorColgador = MetersToFeet(Form.OffsetSuperiorColgadorMetros);

            if (offsetSuperiorColgador < 0.0)
                offsetSuperiorColgador = 0.0;

            if (camara < 0.0)
            {
                Mostrar("El desfase base de perfiles sobre la cara pickada no puede ser negativo.");
                return;
            }

            if (sepPrincipal <= MetersToFeet(0.05) || sepSecundario <= MetersToFeet(0.05))
            {
                Mostrar("Las separaciones de perfiles deben ser mayores a 0.05 m.");
                return;
            }

            XYZ normal = OrientarNormalHaciaArriba(superficiePickada.Normal).Normalize();
            XYZ dirU = null;
            XYZ dirV = null;
            bool superficieInclinada = EsSuperficieInclinada(normal);
            string textoOrientacionSistema = "Orientación automática: según ejes de la cara.";

            if (direccionManual != null && direccionManual.DirU != null && direccionManual.DirU.GetLength() > 0.000001)
            {
                // Si hay cara guía / 2 caras guía / orientación manual, se respeta exactamente eso.
                // La orientación por luz/boceto solo aplica cuando NO hay guías activas.
                dirU = ProyectarVectorEnPlano(direccionManual.DirU, normal);

                if (dirU == null || dirU.GetLength() < 0.000001)
                    dirU = ProyectarVectorEnPlano(superficiePickada.DirU, normal);

                if (dirU == null || dirU.GetLength() < 0.000001)
                    ConstruirEjesDesdeNormal(normal, out dirU, out dirV);
                else
                {
                    dirU = dirU.Normalize();
                    dirV = normal.CrossProduct(dirU).Normalize();
                }

                textoOrientacionSistema = "Orientación: guía/manual activa; no se aplicó orientación automática por luz/boceto.";
            }
            else
            {
                // V43:
                // Cuando NO hay caras guía, la dirección automática de la estructura toma la dirección
                // dominante del boceto/contorno exterior de la cara pickada. En pisos/cielos rectangulares,
                // esto equivale a la dirección de la luz/lado largo del elemento o del boceto creado.
                string detalleLuzBoceto = "";

                if (ObtenerEjesAutomaticosDesdeLuzOBoceto(
                    superficiePickada,
                    normal,
                    out dirU,
                    out dirV,
                    out detalleLuzBoceto))
                {
                    textoOrientacionSistema = "Orientación automática por luz/boceto: " + detalleLuzBoceto;
                }
                else
                {
                    ObtenerEjesAutomaticosParaSuperficie(normal, superficiePickada.DirU, out dirU, out dirV);
                    textoOrientacionSistema = "Orientación automática: respaldo por ejes de la cara.";
                }
            }

            // V19 - CAPAS + MARCO PERIMETRAL CON EJE DESPLAZADO AL INTERIOR:
            // La superficie pickada representa la cara/base del sistema.
            //
            // IMPORTANTE:
            // Los perfiles se apilan usando la NORMAL DE LA CARA, no el eje Z global.
            // Esto permite que en superficies inclinadas los perfiles sigan el plano seleccionado.
            //
            // Con familias de armazón estructural en "Justificación Z = Parte superior":
            // 01. Marco perimetral y perfiles principales:
            //     usan el input "Desfase base" como cota de la línea superior del perfil principal.
            //     Si el perfil principal mide 0.038 m, coloca 0.038 para que su parte inferior toque la cara.
            //
            // 02. Perfiles secundarios:
            //     NO suman nuevamente el alto del perfil principal.
            //     Se colocan por encima del principal sumando SOLO su propio alto.
            //     Fórmula: origenSecundario = origenPrincipal + normal * AltoPerfilSecundario.
            //
            // 03. Base/Nivel de referencia del colgador:
            //     coincide con la línea superior del perfil secundario.
            //     El colgador se mantiene vertical y busca la cara superior más cercana en +Z.
            XYZ origenBaldosa = superficiePickada.Origin;

            double altoPerfilPrincipal = ObtenerAltoPerfil(perfilPrincipal);
            double altoPerfilSecundario = ObtenerAltoPerfil(perfilSecundario);
            double anchoPerfilPrincipal = ObtenerAnchoPerfil(perfilPrincipal);

            XYZ direccionCapas = normal;

            if (direccionCapas == null || direccionCapas.GetLength() < 0.000001)
                direccionCapas = XYZ.BasisZ;
            else
                direccionCapas = direccionCapas.Normalize();

            XYZ origenPrincipal = origenBaldosa + (direccionCapas * camara);
            XYZ origenSecundario = origenPrincipal + (direccionCapas * altoPerfilSecundario);
            XYZ origenColgador = origenSecundario;

            List<P2> poligono = ProyectarPoligono(superficiePickada.PoligonoExterior3D, origenBaldosa, dirU, dirV);

            if (poligono == null || poligono.Count < 3)
            {
                Mostrar("No se pudo proyectar el contorno de la superficie.");
                return;
            }

            Bounding2D bboxOriginal = ObtenerBounding2D(poligono);

            if (bboxOriginal == null || bboxOriginal.Ancho <= longitudMinima || bboxOriginal.Alto <= longitudMinima)
            {
                Mostrar("El contorno de la superficie es demasiado pequeño para generar la estructura.");
                return;
            }

            bool proyectarPerfilesAlPerimetro = Form.ProyectarPerfilesAlPerimetro;

            // V21:
            // El armazón estructural se inserta por su eje/centro de sección.
            // Para que la CARA EXTERIOR del perfil perimetral coincida con el borde real
            // de la superficie, se desplaza la línea de inserción del marco hacia adentro
            // medio Ancho del perfil principal.
            // Para evitar clash en las esquinas, ya NO se sobreextienden todos los lados.
            // Se genera una esquina tipo TOPE: un lado pasa y el lado siguiente se recorta.
            double offsetInteriorMarco = 0.0;
            string advertenciaOffsetMarco = "";

            if (Form.CrearMarco && anchoPerfilPrincipal > MetersToFeet(0.001))
                offsetInteriorMarco = anchoPerfilPrincipal / 2.0;

            List<P2> poligonoMarco = poligono;

            if (offsetInteriorMarco > MetersToFeet(0.001))
            {
                List<P2> offset = GenerarPoligonoOffsetInterior(poligono, offsetInteriorMarco);

                if (offset != null && offset.Count >= 3 && Math.Abs(AreaPoligono(offset)) > MetersToFeet(0.01) * MetersToFeet(0.01))
                    poligonoMarco = offset;
                else
                    advertenciaOffsetMarco = "ADVERTENCIA: no se pudo calcular el offset interior del marco; se usó el contorno original.\r\n";
            }

            // Si hay marco, los perfiles internos y colgadores se calculan con el contorno interior
            // del marco. Así no atraviesan el perimetral y llegan hasta la línea de inserción real
            // del marco desplazado. Si no hay marco, se usa el contorno original.
            List<P2> poligonoTrabajo = Form.CrearMarco ? poligonoMarco : poligono;
            Bounding2D bboxTrabajo = ObtenerBounding2D(poligonoTrabajo);

            if (bboxTrabajo == null || bboxTrabajo.Ancho <= longitudMinima || bboxTrabajo.Alto <= longitudMinima)
            {
                Mostrar("El contorno interior útil es demasiado pequeño para generar la estructura. Revisa el parámetro Ancho del perfil o el tamaño de la superficie.");
                return;
            }

            // V34 - 2 CARAS GUÍA ORTOGONALES:
            // Si el usuario pickó 2 caras guía, se usan como ejes de arranque de la parrilla:
            // - Cara guía U: crea un perfil principal sobre esa dirección.
            // - Cara guía V: crea otro perfil principal perpendicular.
            // Las demás líneas se distribuyen desde esas referencias hasta topar el perímetro.
            double? anclaXGuia = null;
            double? anclaYGuia = null;
            string textoGuiaRejilla = "Guía de parrilla: automática";

            // V34 - GUÍAS COMPENSADAS POR NORMAL DE CARA:
            // Las 2 caras guía representan caras/límites existentes. Como los armazones estructurales
            // se insertan por el eje central de la sección, el eje NO debe quedar sobre la línea guía:
            // debe desplazarse Ancho/2 hacia el lado libre real de la superficie.
            //
            // Ya no se decide el signo con el centro del bounding box. Ahora se prueban las 4 combinaciones
            // (+X/-X y +Y/-Y), se detecta cuál queda dentro del polígono útil y cuál genera mayor longitud
            // de intersección dentro de la cara. Ese par de signos define el "afuera" real de ambas guías.
            double offsetGuiaMedioAncho = 0.0;

            if (anchoPerfilPrincipal > MetersToFeet(0.001))
                offsetGuiaMedioAncho = anchoPerfilPrincipal / 2.0;
            else if (ObtenerAnchoPerfil(perfilSecundario) > MetersToFeet(0.001))
                offsetGuiaMedioAncho = ObtenerAnchoPerfil(perfilSecundario) / 2.0;

            if (guiaLineas != null && guiaLineas.Activa && guiaLineas.PuntoLineaU != null && guiaLineas.PuntoLineaV != null)
            {
                P2 pLineaU = ProyectarPunto(guiaLineas.PuntoLineaU, origenBaldosa, dirU, dirV);
                P2 pLineaV = ProyectarPunto(guiaLineas.PuntoLineaV, origenBaldosa, dirU, dirV);

                if (pLineaU != null && pLineaV != null)
                {
                    double xOriginal = pLineaV.X;
                    double yOriginal = pLineaU.Y;

                    // Inicializados para evitar CS0165: Uso de variable local no asignada.
                    // Si por alguna razón no entra ninguna rutina de compensación,
                    // se conserva la ubicación original de las caras guía.
                    double xCompensado = xOriginal;
                    double yCompensado = yOriginal;
                    string detalleCompensacion = "sin compensación";

                    bool calculadoPorNormal = false;

                    if (guiaLineas.EsCaraGuia)
                    {
                        calculadoPorNormal = CalcularAnclasGuiaPorNormalDeCara(
                            poligonoTrabajo,
                            xOriginal,
                            yOriginal,
                            offsetGuiaMedioAncho,
                            dirU,
                            dirV,
                            guiaLineas.NormalLibreUPlanta,
                            guiaLineas.NormalLibreVPlanta,
                            out xCompensado,
                            out yCompensado,
                            out detalleCompensacion);
                    }

                    if (!calculadoPorNormal)
                    {
                        HashSet<long> idsExcluirObstruccionGuia = new HashSet<long>();

                        if (superficiePickada != null && superficiePickada.ElementId != null)
                            idsExcluirObstruccionGuia.Add(superficiePickada.ElementId.Value);

                        // Para líneas guía de detalle/modelo sí se excluye la propia línea.
                        // Para caras guía no se excluye el elemento anfitrión, porque esa cara puede ser justo la obstrucción.
                        if (!guiaLineas.EsCaraGuia)
                        {
                            if (guiaLineas.ElementIdLineaU != null)
                                idsExcluirObstruccionGuia.Add(guiaLineas.ElementIdLineaU.Value);

                            if (guiaLineas.ElementIdLineaV != null)
                                idsExcluirObstruccionGuia.Add(guiaLineas.ElementIdLineaV.Value);
                        }

                        CalcularAnclasGuiaPorObstruccionOFallback(
                            doc,
                            poligonoTrabajo,
                            xOriginal,
                            yOriginal,
                            offsetGuiaMedioAncho,
                            origenPrincipal,
                            dirU,
                            dirV,
                            idsExcluirObstruccionGuia,
                            out xCompensado,
                            out yCompensado,
                            out detalleCompensacion);
                    }

                    anclaXGuia = xCompensado;
                    anclaYGuia = yCompensado;

                    textoGuiaRejilla =
                        "Guía de parrilla: 2 caras guía" +
                        " | X guía=" + FeetToMeters(xOriginal).ToString("0.###") + " m" +
                        " → X eje=" + FeetToMeters(anclaXGuia.Value).ToString("0.###") + " m" +
                        " | Y guía=" + FeetToMeters(yOriginal).ToString("0.###") + " m" +
                        " → Y eje=" + FeetToMeters(anclaYGuia.Value).ToString("0.###") + " m" +
                        " | compensación lado libre Ancho/2=" + FeetToMeters(offsetGuiaMedioAncho).ToString("0.###") + " m" +
                        " | " + detalleCompensacion;
                }
            }

            // V16 + V22 + V23 + V28:
            // Tanto principales como secundarios se generan en ambas direcciones, usando el polígono útil interior.
            // Con 2 caras guía activas, las posiciones se anclan a esas líneas para que exista un perfil principal
            // exactamente sobre cada guía y el resto se module hacia ambos lados hasta el perímetro.
            double mediaAnchoMarco = offsetInteriorMarco;

            List<Segmento2D> segmentosPrincipales = GenerarSegmentosAmbasDirecciones(poligonoTrabajo, bboxTrabajo, sepPrincipal, margen, longitudMinima, proyectarPerfilesAlPerimetro, anclaXGuia, anclaYGuia);
            List<Segmento2D> segmentosSecundarios = GenerarSegmentosAmbasDirecciones(poligonoTrabajo, bboxTrabajo, sepSecundario, margen, longitudMinima, proyectarPerfilesAlPerimetro, anclaXGuia, anclaYGuia);

            if (Form.CrearMarco && proyectarPerfilesAlPerimetro && mediaAnchoMarco > MetersToFeet(0.001))
            {
                segmentosPrincipales = AjustarSegmentosInternosContraMarco(
                    segmentosPrincipales,
                    mediaAnchoMarco,
                    longitudMinima);

                segmentosSecundarios = AjustarSegmentosInternosContraMarco(
                    segmentosSecundarios,
                    mediaAnchoMarco,
                    longitudMinima);
            }

            // V21:
            // Encuentro perimetral sin interferencia:
            // - Lados pares pasan extendidos hasta la cara exterior.
            // - Lados impares se recortan para topar contra los lados pares.
            // Esto evita la superposición real de sólidos en las esquinas.
            List<Segmento2D> segmentosMarco = GenerarSegmentosMarcoSinClash(poligonoMarco, longitudMinima, mediaAnchoMarco);

            int creadosMarco = 0;
            int creadosPrincipales = 0;
            int creadosSecundarios = 0;
            int creadosColgadores = 0;
            int recortesAplicados = 0;
            int omitidos = 0;
            int errores = 0;

            StringBuilder reporte = new StringBuilder();

            string textoNivelDetectado = "sin nivel";
            double desfaseCaraRespectoNivel = 0.0;

            using (Transaction trans = new Transaction(doc, "MYG - Cielo raso acústico suspendido"))
            {
                trans.Start();

                ActivarSimbolo(doc, perfilPrincipal);
                ActivarSimbolo(doc, perfilSecundario);
                ActivarSimbolo(doc, colgador);

                // Nivel automático: se detecta con la elevación de la cara pickada,
                // no con el nivel elegido manualmente en la ventana.
                nivel = ObtenerNivelMasCercano(doc, origenBaldosa.Z);

                if (nivel == null && (Form.CrearMarco || Form.CrearPrincipales || Form.CrearSecundarios))
                    throw new InvalidOperationException("No se encontró un nivel válido para crear los perfiles estructurales.");

                textoNivelDetectado = nivel == null
                    ? "sin nivel"
                    : nivel.Name + " | elev. " + FeetToMeters(nivel.Elevation).ToString("0.###") + " m";

                desfaseCaraRespectoNivel = nivel == null ? 0.0 : origenBaldosa.Z - nivel.Elevation;

                List<Element> creados = new List<Element>();

                if (Form.CrearMarco && perfilPrincipal != null)
                {
                    foreach (Segmento2D s in segmentosMarco)
                    {
                        try
                        {
                            Element e = CrearPerfil(doc, perfilPrincipal, nivel, s, origenPrincipal, dirU, dirV, "Marco perimetral");

                            if (e != null)
                            {
                                creados.Add(e);
                                creadosMarco++;
                            }
                            else
                                omitidos++;
                        }
                        catch (Exception ex)
                        {
                            errores++;
                            reporte.AppendLine("ERROR marco: " + ex.Message);
                        }
                    }
                }

                if (Form.CrearPrincipales && perfilPrincipal != null)
                {
                    foreach (Segmento2D s in segmentosPrincipales)
                    {
                        try
                        {
                            Element e = CrearPerfil(doc, perfilPrincipal, nivel, s, origenPrincipal, dirU, dirV, "Perfil principal");

                            if (e != null)
                            {
                                creados.Add(e);
                                creadosPrincipales++;
                            }
                            else
                                omitidos++;
                        }
                        catch (Exception ex)
                        {
                            errores++;
                            reporte.AppendLine("ERROR perfil principal: " + ex.Message);
                        }
                    }
                }

                if (Form.CrearSecundarios && perfilSecundario != null)
                {
                    foreach (Segmento2D s in segmentosSecundarios)
                    {
                        try
                        {
                            Element e = CrearPerfil(doc, perfilSecundario, nivel, s, origenSecundario, dirU, dirV, "Perfil secundario");

                            if (e != null)
                            {
                                creados.Add(e);
                                creadosSecundarios++;
                            }
                            else
                                omitidos++;
                        }
                        catch (Exception ex)
                        {
                            errores++;
                            reporte.AppendLine("ERROR perfil secundario: " + ex.Message);
                        }
                    }
                }

                if (Form.CrearColgadores && colgador != null)
                {
                    // V16:
                    // Los colgadores se distribuyen en una rejilla basada en el doble
                    // de la separación secundaria. Con sep. secundaria 0.60 m,
                    // los colgadores quedan cada 1.20 m, dejando un punto intermedio libre.
                    List<P2> puntosColgadores = ObtenerPuntosColgadoresDobleSecundario(
                        poligonoTrabajo,
                        bboxTrabajo,
                        sepSecundario,
                        margen,
                        Form.CrearMarco ? segmentosMarco : null,
                        anclaXGuia,
                        anclaYGuia);

                    HashSet<long> idsExcluirBusquedaSuperior = new HashSet<long>();

                    if (superficiePickada != null && superficiePickada.ElementId != null)
                        idsExcluirBusquedaSuperior.Add(superficiePickada.ElementId.Value);

                    foreach (Element eCreado in creados)
                    {
                        if (eCreado != null && eCreado.Id != null)
                            idsExcluirBusquedaSuperior.Add(eCreado.Id.Value);
                    }

                    double distanciaMaximaBusqueda = MetersToFeet(20.0);
                    double toleranciaColgadorPerimetral = Math.Max(
                        MetersToFeet(0.02),
                        (anchoPerfilPrincipal > MetersToFeet(0.001) ? anchoPerfilPrincipal * 0.75 : MetersToFeet(0.02)));

                    foreach (P2 p in puntosColgadores)
                    {
                        try
                        {
                            XYZ puntoReferenciaPerfil = Convertir2Da3D(p, origenPrincipal, dirU, dirV);

                            // V51:
                            // Los colgadores que caen sobre el marco/perimetral NO deben arrancar
                            // en la capa de secundarios. Se proyectan al nivel del primer perfil
                            // principal/perimetral. Los demás colgadores mantienen la base superior
                            // del perfil secundario.
                            bool colgadorSobrePerimetral = Form.CrearMarco &&
                                PuntoCercaDeSegmentos(p, segmentosMarco, toleranciaColgadorPerimetral);

                            XYZ origenBaseColgador = colgadorSobrePerimetral ? origenPrincipal : origenColgador;

                            XYZ puntoInferiorColgador = Convertir2Da3D(p, origenBaseColgador, dirU, dirV);

                            // Se busca desde la base elevada del colgador hacia arriba en eje Z.
                            XYZ puntoBusquedaSuperior = puntoInferiorColgador + (XYZ.BasisZ * MetersToFeet(0.001));

                            ImpactoSuperior impactoSuperior = BuscarCaraMasCercanaHaciaArriba(
                                doc,
                                puntoBusquedaSuperior,
                                distanciaMaximaBusqueda,
                                idsExcluirBusquedaSuperior);

                            if (impactoSuperior == null || impactoSuperior.Punto == null)
                            {
                                omitidos++;
                                reporte.AppendLine(
                                    "OMITIDO colgador: no se encontró cara superior hacia +Z en X=" +
                                    FeetToMeters(puntoReferenciaPerfil.X).ToString("0.###") +
                                    ", Y=" + FeetToMeters(puntoReferenciaPerfil.Y).ToString("0.###") + ".");
                                continue;
                            }

                            XYZ puntoSuperior = impactoSuperior.Punto;

                            // V51:
                            // El offset superior solo afecta la longitud final del colgador respecto
                            // a la cara superior detectada. La parte inferior NO se mueve.
                            double longitud = (puntoSuperior.Z - offsetSuperiorColgador) - puntoInferiorColgador.Z;

                            if (longitud <= MetersToFeet(0.02))
                            {
                                omitidos++;
                                reporte.AppendLine(
                                    "OMITIDO colgador: la longitud resultante es insuficiente después del offset superior en X=" +
                                    FeetToMeters(puntoReferenciaPerfil.X).ToString("0.###") +
                                    ", Y=" + FeetToMeters(puntoReferenciaPerfil.Y).ToString("0.###") + ".");
                                continue;
                            }

                            FamilyInstance fi = CrearColgador(doc, colgador, impactoSuperior, puntoInferiorColgador, dirU, longitud, superficieInclinada);

                            if (fi != null)
                            {
                                creados.Add(fi);
                                idsExcluirBusquedaSuperior.Add(fi.Id.Value);
                                creadosColgadores++;
                            }
                            else
                                omitidos++;
                        }
                        catch (Exception ex)
                        {
                            errores++;
                            reporte.AppendLine("ERROR colgador: " + ex.Message);
                        }
                    }
                }

                // V23 - RECORTE NATIVO EN INTERSECCIONES:
                // Después de crear todos los perfiles, se intenta aplicar el recorte nativo de
                // Armazón estructural en las intersecciones, con distancia de recorte = 0.
                // Se filtran solo perfiles estructurales; los colgadores no participan.
                List<FamilyInstance> perfilesParaRecorte = creados
                    .OfType<FamilyInstance>()
                    .Where(x => EsInstanciaArmazonEstructural(x))
                    .ToList();

                // V24: antes de aplicar copings/recortes nativos se regenera el documento.
                // Sin este Regenerate, en algunos casos Revit todavía no tiene calculadas
                // las cajas/curvas/joins reales de los perfiles recién creados y AddCoping falla.
                try
                {
                    doc.Regenerate();
                }
                catch
                {
                }

                recortesAplicados = AplicarRecorteNativoEnIntersecciones(doc, perfilesParaRecorte, reporte);

                if (recortesAplicados > 0)
                {
                    try
                    {
                        doc.Regenerate();
                    }
                    catch
                    {
                    }
                }

                if (Form.AsignarParametros)
                {
                    foreach (Element e in creados)
                        AsignarParametrosMYG(e, camara);
                }

                trans.Commit();
            }

            Mostrar(
                "PROCESO TERMINADO\r\n" +
                "----------------------------------------\r\n" +
                "Marco perimetral: " + creadosMarco + "\r\n" +
                "Perfiles principales: " + creadosPrincipales + "\r\n" +
                "Perfiles secundarios: " + creadosSecundarios + "\r\n" +
                "Colgadores: " + creadosColgadores + "\r\n" +
                "Recortes nativos en intersecciones: " + recortesAplicados + "\r\n" +
                "Omitidos: " + omitidos + "\r\n" +
                "Errores: " + errores + "\r\n" +
                "Nivel automático de perfiles: " + textoNivelDetectado + "\r\n" +
                "Desfase cara - nivel: " + FeetToMeters(desfaseCaraRespectoNivel).ToString("0.###") + " m\r\n" +
                "Desfase base aplicado a línea superior de principales/perímetro: " + FeetToMeters(camara).ToString("0.###") + " m\r\n" +
                "Proyectar perfiles internos hasta perímetro útil: " + (proyectarPerfilesAlPerimetro ? "Sí" : "No") + "\r\n" +
                textoGuiaRejilla + "\r\n" +
                textoOrientacionSistema + "\r\n" +
                "Compensación de guías hacia lado libre por eje central: " + FeetToMeters(offsetGuiaMedioAncho).ToString("0.###") + " m\r\n" +
                "Alto perfil principal detectado: " + FeetToMeters(altoPerfilPrincipal).ToString("0.###") + " m\r\n" +
                "Alto perfil secundario detectado: " + FeetToMeters(altoPerfilSecundario).ToString("0.###") + " m\r\n" +
                "Ancho perfil principal detectado: " + FeetToMeters(anchoPerfilPrincipal).ToString("0.###") + " m\r\n" +
                "Offset interior del marco: " + FeetToMeters(offsetInteriorMarco).ToString("0.###") + " m\r\n" +
                "Encuentro marco: tipo tope alternado sin sobreposición\r\n" +
                "Cota secundaria sobre principal: " + FeetToMeters(altoPerfilSecundario).ToString("0.###") + " m sobre la línea superior principal\r\n" +
                "Base colgador: secundarios en parte superior de secundario; perimetrales al nivel del primer perfil\r\n" +
                "Offset superior de colgador respecto a cara próxima: " + FeetToMeters(offsetSuperiorColgador).ToString("0.###") + " m\r\n\r\n" +
                "Nota V34: aplica recorte nativo en intersecciones, mantiene capas con la NORMAL de la cara para superficies inclinadas, colgadores verticales hacia +Z y, si existen 2 líneas guía, detecta el lado con obstrucción cercana para desplazar el eje de la parrilla Ancho/2 hacia el lado libre, alineando la cara exterior del perfil con la guía.\r\n" +
                advertenciaOffsetMarco +
                reporte.ToString());
        }

        private Element CrearPerfil(
            Document doc,
            FamilySymbol symbol,
            Level nivel,
            Segmento2D segmento,
            XYZ origen,
            XYZ dirU,
            XYZ dirV,
            string tipo)
        {
            if (doc == null || symbol == null || nivel == null || segmento == null)
                return null;

            XYZ p1 = Convertir2Da3D(segmento.A, origen, dirU, dirV);
            XYZ p2 = Convertir2Da3D(segmento.B, origen, dirU, dirV);

            if (p1.DistanceTo(p2) <= MetersToFeet(0.02))
                return null;

            Line linea = Line.CreateBound(p1, p2);

            FamilyInstance fi = doc.Create.NewFamilyInstance(
                linea,
                symbol,
                nivel,
                StructuralType.Beam);

            // Refuerza que la curva física quede exactamente sobre la cara/origen calculado,
            // independientemente del nivel automático que use Revit para alojar el perfil.
            try
            {
                LocationCurve loc = fi.Location as LocationCurve;
                if (loc != null)
                    loc.Curve = linea;
            }
            catch
            {
            }

            AjustarDesfasesPerfilALaCurva(fi, nivel, p1, p2);

            // V11:
            // Si la cara pickada está inclinada, el eje del perfil ya queda en su posición 3D,
            // pero la sección transversal puede quedarse vertical. Aquí se calcula el ángulo
            // de roll respecto al eje del perfil y se escribe en "Rotación de sección transversal".
            XYZ normalPlanoPerfil = null;

            try
            {
                normalPlanoPerfil = dirU.CrossProduct(dirV);

                if (normalPlanoPerfil != null && normalPlanoPerfil.GetLength() > 0.000001)
                    normalPlanoPerfil = normalPlanoPerfil.Normalize();
            }
            catch
            {
                normalPlanoPerfil = null;
            }

            AjustarRotacionSeccionTransversalPerfil(fi, p1, p2, normalPlanoPerfil);

            // V53: Reforzar nuevamente después de rotación/regeneraciones internas.
            ForzarDesfaseZPerfilCero(fi);

            if (!string.IsNullOrWhiteSpace(tipo) && Normalizar(tipo).Contains("MARCO"))
            {
                // V21: evita que Revit recorte automáticamente los extremos del marco;
                // el recorte de esquinas ya lo controla la geometría 2D tipo tope.
                AjustarReduccionesJuntaCero(fi);

                // V21: si Revit intenta unir/cortar automáticamente los extremos, se intenta desactivar
                // la unión en ambos extremos. Si la API o la familia no lo permiten, no detiene el proceso.
                DesactivarUnionExtremosPerfil(fi);
            }

            // V53: Último seguro antes de devolver el perfil.
            ForzarDesfaseZPerfilCero(fi);

            SetParametroTexto(fi, Form.ParametroTipo, tipo);

            return fi;
        }

        private FamilyInstance CrearColgador(
            Document doc,
            FamilySymbol symbol,
            ImpactoSuperior impactoSuperior,
            XYZ puntoInferiorColgador,
            XYZ direccionReferencia,
            double longitud,
            bool superficieInclinada)
        {
            if (doc == null || symbol == null || impactoSuperior == null || impactoSuperior.Punto == null || puntoInferiorColgador == null)
                return null;

            XYZ puntoSuperior = impactoSuperior.Punto;
            FamilyInstance fi = null;

            try
            {
                XYZ refDir = direccionReferencia;

                if (refDir == null || refDir.GetLength() < 0.000001)
                    refDir = XYZ.BasisX;

                if (impactoSuperior.FaceNormal != null &&
                    impactoSuperior.FaceNormal.GetLength() > 0.000001)
                {
                    XYZ refDirProyectada = ProyectarVectorEnPlano(
                        refDir,
                        impactoSuperior.FaceNormal);

                    if (refDirProyectada != null &&
                        refDirProyectada.GetLength() > 0.000001)
                    {
                        refDir = refDirProyectada;
                    }
                }

                if (refDir == null || refDir.GetLength() < 0.000001)
                    refDir = XYZ.BasisX;

                refDir = refDir.Normalize();

                // Primero intenta colocar por Reference.
                // Esto permite usar también caras de vínculos mediante CreateLinkReference().
                if (impactoSuperior.FaceReference != null)
                {
                    try
                    {
                        fi = doc.Create.NewFamilyInstance(
                            impactoSuperior.FaceReference,
                            puntoSuperior,
                            refDir,
                            symbol);
                    }
                    catch
                    {
                        fi = null;
                    }
                }

                // Respaldo para caras nativas antiguas.
                // En caras de vínculo no se fuerza Face porque pertenece al documento vinculado.
                if (fi == null && !impactoSuperior.EsDeVinculo && impactoSuperior.Face != null)
                {
                    try
                    {
                        fi = doc.Create.NewFamilyInstance(
                            impactoSuperior.Face,
                            puntoSuperior,
                            refDir,
                            symbol);
                    }
                    catch
                    {
                        fi = null;
                    }
                }
            }
            catch
            {
                fi = null;
            }

            if (fi == null)
            {
                fi = doc.Create.NewFamilyInstance(
                    puntoSuperior,
                    symbol,
                    StructuralType.NonStructural);
            }

            if (fi != null)
            {
                // Primero se escribe la altura variable para que el PLANO SUPERIOR de la familia
                // llegue a la cara superior detectada.
                SetParametroLongitud(fi, Form.ParametroLongitudColgador, longitud);

                // En superficies horizontales se mantiene el método V9, porque fue el que conservó bien X/Y.
                // En superficies inclinadas NO se usa Offset from Host como primer recurso, porque el offset de una
                // familia alojada puede moverse en la normal de la cara y terminar inclinando/desplazando el colgador.
                // Para inclinadas se mueve solo en Z, conservando el X/Y original de inserción.
                if (superficieInclinada)
                    MoverSoloZHastaBase(doc, fi, puntoInferiorColgador);
                else
                    AjustarOffsetHostParaBaseColgador(doc, fi, puntoInferiorColgador);

                // Refuerzo: el colgador debe quedar vertical siempre. Si la familia es face based y Revit no permite
                // rotarla por su anfitrión, simplemente se conserva la altura y no se interrumpe el proceso.
                ForzarColgadorVertical(doc, fi, puntoInferiorColgador);
                MoverSoloZHastaBase(doc, fi, puntoInferiorColgador);

                SetParametroTexto(fi, Form.ParametroTipo, "Colgador");
            }

            return fi;
        }

        private void ForzarColgadorVertical(
            Document doc,
            FamilyInstance fi,
            XYZ puntoBaseReferencia)
        {
            if (doc == null || fi == null)
                return;

            try
            {
                doc.Regenerate();

                Transform tr = fi.GetTransform();

                if (tr == null)
                    return;

                XYZ ejeLocalZ = tr.BasisZ;

                if (ejeLocalZ == null || ejeLocalZ.GetLength() < 0.000001)
                    return;

                ejeLocalZ = ejeLocalZ.Normalize();

                // Si el eje local Z ya está paralelo a Z global, se considera vertical aunque apunte hacia abajo.
                double dot = ejeLocalZ.DotProduct(XYZ.BasisZ);

                if (Math.Abs(dot) >= 0.9995)
                    return;

                XYZ objetivo = dot >= 0.0 ? XYZ.BasisZ : -XYZ.BasisZ;
                XYZ ejeRotacion = ejeLocalZ.CrossProduct(objetivo);

                if (ejeRotacion == null || ejeRotacion.GetLength() < 0.000001)
                    return;

                XYZ puntoRotacion = puntoBaseReferencia;

                if (puntoRotacion == null)
                {
                    LocationPoint lp = fi.Location as LocationPoint;
                    puntoRotacion = lp != null ? lp.Point : XYZ.Zero;
                }

                Line eje = Line.CreateUnbound(puntoRotacion, ejeRotacion.Normalize());
                double angulo = ejeLocalZ.AngleTo(objetivo);

                if (Math.Abs(angulo) > 0.000001)
                    ElementTransformUtils.RotateElement(doc, fi.Id, eje, angulo);
            }
            catch
            {
                // Algunas familias basadas en cara no permiten rotación libre por su anfitrión.
                // En ese caso se conserva la creación y la altura para no omitir el colgador.
            }
        }

        private void AjustarOffsetHostParaBaseColgador(
            Document doc,
            FamilyInstance fi,
            XYZ puntoBaseDeseado)
        {
            if (doc == null || fi == null || puntoBaseDeseado == null)
                return;

            Parameter pOffset = ObtenerParametroOffsetHost(fi);

            if (pOffset == null || pOffset.IsReadOnly)
            {
                // Respaldo: si la familia no expone Offset from Host, se intenta mover solo en Z.
                // No se toca X/Y para no volver a desubicar los colgadores.
                MoverSoloZHastaBase(doc, fi, puntoBaseDeseado);
                return;
            }

            try
            {
                double offsetOriginal = pOffset.AsDouble();
                double zObjetivo = puntoBaseDeseado.Z;

                doc.Regenerate();

                double zActual = ObtenerZReferenciaInstancia(fi);
                double deltaZ = zObjetivo - zActual;

                if (Math.Abs(deltaZ) <= MetersToFeet(0.001))
                    return;

                // Candidato 1: sumar deltaZ al Offset from Host.
                if (ProbarOffsetHost(doc, fi, pOffset, offsetOriginal + deltaZ, zObjetivo))
                    return;

                // Candidato 2: restar deltaZ. Esto cubre familias/caras cuyo normal está invertido.
                if (ProbarOffsetHost(doc, fi, pOffset, offsetOriginal - deltaZ, zObjetivo))
                    return;

                // Candidato 3: usar directamente la distancia vertical entre host superior y base.
                // Se prueban ambos signos porque Revit invierte el sentido según la normal del host.
                double distanciaHostABase = zActual - zObjetivo;

                if (ProbarOffsetHost(doc, fi, pOffset, distanciaHostABase, zObjetivo))
                    return;

                if (ProbarOffsetHost(doc, fi, pOffset, -distanciaHostABase, zObjetivo))
                    return;

                // Si nada funcionó, se restaura el offset y se intenta mover solo en Z.
                pOffset.Set(offsetOriginal);
                doc.Regenerate();
                MoverSoloZHastaBase(doc, fi, puntoBaseDeseado);
            }
            catch
            {
                try
                {
                    MoverSoloZHastaBase(doc, fi, puntoBaseDeseado);
                }
                catch
                {
                }
            }
        }

        private bool ProbarOffsetHost(
            Document doc,
            FamilyInstance fi,
            Parameter pOffset,
            double valorOffset,
            double zObjetivo)
        {
            if (doc == null || fi == null || pOffset == null || pOffset.IsReadOnly)
                return false;

            try
            {
                pOffset.Set(valorOffset);
                doc.Regenerate();

                double zNuevo = ObtenerZReferenciaInstancia(fi);

                if (Math.Abs(zNuevo - zObjetivo) <= MetersToFeet(0.005))
                    return true;
            }
            catch
            {
            }

            return false;
        }

        private Parameter ObtenerParametroOffsetHost(FamilyInstance fi)
        {
            if (fi == null)
                return null;

            try
            {
                Parameter p = fi.get_Parameter(BuiltInParameter.INSTANCE_FREE_HOST_OFFSET_PARAM);

                if (p != null)
                    return p;
            }
            catch
            {
            }

            return BuscarParametro(fi,
                "Offset from Host",
                "Offset del anfitrión",
                "Desfase desde anfitrión",
                "Desfase de anfitrión",
                "Desfase de huésped",
                "Host Offset",
                "Offset");
        }

        private Parameter BuscarParametro(Element elemento, params string[] nombres)
        {
            if (elemento == null || nombres == null)
                return null;

            foreach (string nombre in nombres)
            {
                Parameter p = BuscarParametro(elemento, nombre);

                if (p != null)
                    return p;
            }

            return null;
        }

        private double ObtenerZReferenciaInstancia(FamilyInstance fi)
        {
            if (fi == null)
                return 0.0;

            try
            {
                LocationPoint lp = fi.Location as LocationPoint;

                if (lp != null && lp.Point != null)
                    return lp.Point.Z;
            }
            catch
            {
            }

            try
            {
                BoundingBoxXYZ bb = fi.get_BoundingBox(null);

                if (bb != null)
                    return bb.Min.Z;
            }
            catch
            {
            }

            return 0.0;
        }

        private void MoverSoloZHastaBase(
            Document doc,
            FamilyInstance fi,
            XYZ puntoBaseDeseado)
        {
            if (doc == null || fi == null || puntoBaseDeseado == null)
                return;

            try
            {
                double zActual = ObtenerZReferenciaInstancia(fi);
                double deltaZ = puntoBaseDeseado.Z - zActual;

                if (Math.Abs(deltaZ) <= MetersToFeet(0.001))
                    return;

                ElementTransformUtils.MoveElement(doc, fi.Id, new XYZ(0.0, 0.0, deltaZ));
            }
            catch
            {
            }
        }

        private void AsignarParametrosMYG(Element e, double camara)
        {
            if (e == null)
                return;

            SetParametroTexto(e, Form.ParametroSistema, "Cielo raso acústico suspendido");

            if (superficiePickada != null && superficiePickada.ElementId != null)
                SetParametroTexto(e, Form.ParametroIdSuperficie, superficiePickada.ElementId.Value.ToString());

            SetParametroTexto(e, Form.ParametroGenId, e.Id.Value.ToString());
        }

        // =========================================================
        // GEOMETRÍA 2D / RECORTE DE PARRILLA
        // =========================================================

        private bool CalcularAnclasGuiaPorNormalDeCara(
            List<P2> poligono,
            double xGuia,
            double yGuia,
            double offset,
            XYZ dirU,
            XYZ dirV,
            XYZ normalLibreUPlanta,
            XYZ normalLibreVPlanta,
            out double xCompensado,
            out double yCompensado,
            out string detalle)
        {
            xCompensado = xGuia;
            yCompensado = yGuia;
            detalle = "normal de cara no disponible";

            if (poligono == null || poligono.Count < 3)
                return false;

            if (offset <= MetersToFeet(0.001))
            {
                detalle = "offset menor a 1 mm";
                return true;
            }

            if (normalLibreUPlanta == null || normalLibreUPlanta.GetLength() < 0.000001)
                return false;

            if (normalLibreVPlanta == null || normalLibreVPlanta.GetLength() < 0.000001)
                return false;

            if (dirU == null || dirU.GetLength() < 0.000001 || dirV == null || dirV.GetLength() < 0.000001)
                return false;

            XYZ nU = new XYZ(normalLibreUPlanta.X, normalLibreUPlanta.Y, 0.0);
            XYZ nV = new XYZ(normalLibreVPlanta.X, normalLibreVPlanta.Y, 0.0);

            if (nU.GetLength() < 0.000001 || nV.GetLength() < 0.000001)
                return false;

            nU = nU.Normalize();
            nV = nV.Normalize();

            int signoY = nU.DotProduct(dirV) >= 0.0 ? 1 : -1;
            int signoX = nV.DotProduct(dirU) >= 0.0 ? 1 : -1;

            double xPropuesto = xGuia + (signoX * offset);
            double yPropuesto = yGuia + (signoY * offset);

            // Validación contra el polígono útil: si el lado elegido por la normal queda fuera,
            // invierte solo ese eje. Esto ayuda en caras con normal invertida por la familia.
            double longY = ObtenerLongitudUtilHorizontal(poligono, yPropuesto);
            double longYInv = ObtenerLongitudUtilHorizontal(poligono, yGuia - (signoY * offset));

            if (longY <= MetersToFeet(0.05) && longYInv > longY)
            {
                signoY *= -1;
                yPropuesto = yGuia + (signoY * offset);
            }

            double longX = ObtenerLongitudUtilVertical(poligono, xPropuesto);
            double longXInv = ObtenerLongitudUtilVertical(poligono, xGuia - (signoX * offset));

            if (longX <= MetersToFeet(0.05) && longXInv > longX)
            {
                signoX *= -1;
                xPropuesto = xGuia + (signoX * offset);
            }

            xCompensado = xPropuesto;
            yCompensado = yPropuesto;

            detalle =
                "offset por normal de cara" +
                " | X signo=" + signoX +
                " | Y signo=" + signoY +
                " | longX=" + FeetToMeters(ObtenerLongitudUtilVertical(poligono, xPropuesto)).ToString("0.###") + "m" +
                " | longY=" + FeetToMeters(ObtenerLongitudUtilHorizontal(poligono, yPropuesto)).ToString("0.###") + "m";

            return true;
        }

        private void CalcularAnclasGuiaPorObstruccionOFallback(
            Document doc,
            List<P2> poligono,
            double xGuia,
            double yGuia,
            double offset,
            XYZ origenCapa,
            XYZ dirU,
            XYZ dirV,
            HashSet<long> idsExcluir,
            out double xCompensado,
            out double yCompensado,
            out string detalle)
        {
            xCompensado = xGuia;
            yCompensado = yGuia;
            detalle = "sin compensación";

            if (poligono == null || poligono.Count < 3)
                return;

            if (offset <= MetersToFeet(0.001))
            {
                detalle = "offset menor a 1 mm";
                return;
            }

            // V32:
            // Las líneas guía normalmente representan CARAS/límites existentes.
            // Como el armazón se inserta por el eje, se debe mover el eje Ancho/2
            // hacia el lado libre, no hacia el lado donde existe muro/perfil/equipo.
            //
            // Para cada línea se prueban sus 2 lados:
            // - línea U: prueba +V / -V y decide la coordenada Y del eje.
            // - línea V: prueba +U / -U y decide la coordenada X del eje.
            // Primero busca obstrucción real con rayos cortos contra geometría visible.
            // Si no detecta obstrucción, usa el fallback anterior por longitud útil dentro del polígono.

            int signoY = ElegirSignoLibreParaGuiaHorizontal(
                doc, poligono, xGuia, yGuia, offset, origenCapa, dirU, dirV, idsExcluir, out string detalleY);

            int signoX = ElegirSignoLibreParaGuiaVertical(
                doc, poligono, xGuia, yGuia, offset, origenCapa, dirU, dirV, idsExcluir, out string detalleX);

            xCompensado = xGuia + (signoX * offset);
            yCompensado = yGuia + (signoY * offset);

            detalle =
                "offset por lado libre real" +
                " | X signo=" + signoX + " (" + detalleX + ")" +
                " | Y signo=" + signoY + " (" + detalleY + ")";
        }

        private int ElegirSignoLibreParaGuiaHorizontal(
            Document doc,
            List<P2> poligono,
            double xGuia,
            double yGuia,
            double offset,
            XYZ origenCapa,
            XYZ dirU,
            XYZ dirV,
            HashSet<long> idsExcluir,
            out string detalle)
        {
            detalle = "";

            List<P2> muestras = ObtenerPuntosMuestreoSobreGuiaHorizontal(poligono, yGuia, 7);

            if (muestras == null || muestras.Count == 0)
                muestras = new List<P2>() { new P2(xGuia, yGuia) };

            double distanciaPrueba = Math.Max(offset * 4.0, MetersToFeet(0.20));

            int impactosMas = ContarObstruccionesDesdeMuestras(
                doc, muestras, origenCapa, dirU, dirV, dirV, distanciaPrueba, idsExcluir);

            int impactosMenos = ContarObstruccionesDesdeMuestras(
                doc, muestras, origenCapa, dirU, dirV, -dirV, distanciaPrueba, idsExcluir);

            if (impactosMas != impactosMenos)
            {
                // Si +V tiene más obstrucción, el lado libre es -V; y viceversa.
                int signo = impactosMas > impactosMenos ? -1 : 1;
                detalle = "obstrucción +=" + impactosMas + " -= " + impactosMenos;
                return signo;
            }

            double longMas = ObtenerLongitudUtilHorizontal(poligono, yGuia + offset);
            double longMenos = ObtenerLongitudUtilHorizontal(poligono, yGuia - offset);

            bool dentroMas = longMas > MetersToFeet(0.05);
            bool dentroMenos = longMenos > MetersToFeet(0.05);

            if (dentroMas != dentroMenos)
            {
                int signo = dentroMas ? 1 : -1;
                detalle = "fallback polígono +=" + FeetToMeters(longMas).ToString("0.###") + "m -= " + FeetToMeters(longMenos).ToString("0.###") + "m";
                return signo;
            }

            detalle = "fallback longitud +=" + FeetToMeters(longMas).ToString("0.###") + "m -= " + FeetToMeters(longMenos).ToString("0.###") + "m";
            return longMas >= longMenos ? 1 : -1;
        }

        private int ElegirSignoLibreParaGuiaVertical(
            Document doc,
            List<P2> poligono,
            double xGuia,
            double yGuia,
            double offset,
            XYZ origenCapa,
            XYZ dirU,
            XYZ dirV,
            HashSet<long> idsExcluir,
            out string detalle)
        {
            detalle = "";

            List<P2> muestras = ObtenerPuntosMuestreoSobreGuiaVertical(poligono, xGuia, 7);

            if (muestras == null || muestras.Count == 0)
                muestras = new List<P2>() { new P2(xGuia, yGuia) };

            double distanciaPrueba = Math.Max(offset * 4.0, MetersToFeet(0.20));

            int impactosMas = ContarObstruccionesDesdeMuestras(
                doc, muestras, origenCapa, dirU, dirV, dirU, distanciaPrueba, idsExcluir);

            int impactosMenos = ContarObstruccionesDesdeMuestras(
                doc, muestras, origenCapa, dirU, dirV, -dirU, distanciaPrueba, idsExcluir);

            if (impactosMas != impactosMenos)
            {
                // Si +U tiene más obstrucción, el lado libre es -U; y viceversa.
                int signo = impactosMas > impactosMenos ? -1 : 1;
                detalle = "obstrucción +=" + impactosMas + " -= " + impactosMenos;
                return signo;
            }

            double longMas = ObtenerLongitudUtilVertical(poligono, xGuia + offset);
            double longMenos = ObtenerLongitudUtilVertical(poligono, xGuia - offset);

            bool dentroMas = longMas > MetersToFeet(0.05);
            bool dentroMenos = longMenos > MetersToFeet(0.05);

            if (dentroMas != dentroMenos)
            {
                int signo = dentroMas ? 1 : -1;
                detalle = "fallback polígono +=" + FeetToMeters(longMas).ToString("0.###") + "m -= " + FeetToMeters(longMenos).ToString("0.###") + "m";
                return signo;
            }

            detalle = "fallback longitud +=" + FeetToMeters(longMas).ToString("0.###") + "m -= " + FeetToMeters(longMenos).ToString("0.###") + "m";
            return longMas >= longMenos ? 1 : -1;
        }

        private List<P2> ObtenerPuntosMuestreoSobreGuiaHorizontal(List<P2> poligono, double y, int cantidadPorIntervalo)
        {
            List<P2> puntos = new List<P2>();
            List<Intervalo> intervalos = ObtenerIntervalosHorizontal(poligono, y);

            if (intervalos == null)
                return puntos;

            foreach (Intervalo inter in intervalos)
            {
                if (inter == null || inter.B <= inter.A)
                    continue;

                int n = Math.Max(3, cantidadPorIntervalo);

                for (int i = 1; i <= n; i++)
                {
                    double t = (double)i / (double)(n + 1);
                    double x = inter.A + ((inter.B - inter.A) * t);
                    puntos.Add(new P2(x, y));
                }
            }

            return puntos;
        }

        private List<P2> ObtenerPuntosMuestreoSobreGuiaVertical(List<P2> poligono, double x, int cantidadPorIntervalo)
        {
            List<P2> puntos = new List<P2>();
            List<Intervalo> intervalos = ObtenerIntervalosVertical(poligono, x);

            if (intervalos == null)
                return puntos;

            foreach (Intervalo inter in intervalos)
            {
                if (inter == null || inter.B <= inter.A)
                    continue;

                int n = Math.Max(3, cantidadPorIntervalo);

                for (int i = 1; i <= n; i++)
                {
                    double t = (double)i / (double)(n + 1);
                    double y = inter.A + ((inter.B - inter.A) * t);
                    puntos.Add(new P2(x, y));
                }
            }

            return puntos;
        }

        private int ContarObstruccionesDesdeMuestras(
            Document doc,
            List<P2> muestras,
            XYZ origenCapa,
            XYZ dirU,
            XYZ dirV,
            XYZ direccionBusqueda,
            double distanciaPrueba,
            HashSet<long> idsExcluir)
        {
            if (doc == null || muestras == null || muestras.Count == 0 || direccionBusqueda == null)
                return 0;

            if (direccionBusqueda.GetLength() < 0.000001)
                return 0;

            XYZ dir = direccionBusqueda.Normalize();
            int impactos = 0;
            int maxImpactos = muestras.Count;

            foreach (P2 p2 in muestras)
            {
                XYZ p = Convertir2Da3D(p2, origenCapa, dirU, dirV);

                // Se empieza apenas separado de la guía para no detectar la propia cara coincidente.
                XYZ p0 = p + (dir * MetersToFeet(0.002));
                XYZ p1 = p + (dir * distanciaPrueba);

                if (ExisteInterseccionModeloEnLinea(doc, p0, p1, idsExcluir))
                    impactos++;

                if (impactos >= maxImpactos)
                    break;
            }

            return impactos;
        }

        private bool ExisteInterseccionModeloEnLinea(
            Document doc,
            XYZ p0,
            XYZ p1,
            HashSet<long> idsExcluir)
        {
            if (doc == null || p0 == null || p1 == null)
                return false;

            if (p0.DistanceTo(p1) <= MetersToFeet(0.002))
                return false;

            Line linea = null;

            try
            {
                linea = Line.CreateBound(p0, p1);
            }
            catch
            {
                return false;
            }

            Options opciones = new Options();
            opciones.ComputeReferences = false;
            opciones.IncludeNonVisibleObjects = false;
            opciones.DetailLevel = ViewDetailLevel.Fine;

            try
            {
                if (doc.ActiveView != null && !doc.ActiveView.IsTemplate)
                    opciones.View = doc.ActiveView;
            }
            catch
            {
            }

            FilteredElementCollector collector;

            try
            {
                collector = new FilteredElementCollector(doc, doc.ActiveView.Id);
            }
            catch
            {
                collector = new FilteredElementCollector(doc);
            }

            foreach (Element e in collector.WhereElementIsNotElementType().ToElements())
            {
                if (!EsElementoCandidatoParaCaraSuperior(e, idsExcluir))
                    continue;

                try
                {
                    BoundingBoxXYZ bb = e.get_BoundingBox(doc.ActiveView);

                    if (bb != null && !LineaPuedeCruzarBoundingBox(linea, bb, MetersToFeet(0.05)))
                        continue;

                    GeometryElement ge = e.get_Geometry(opciones);

                    if (ge == null)
                        continue;

                    List<Solid> solidos = new List<Solid>();
                    RecolectarSolidos(ge, solidos);

                    foreach (Solid solid in solidos)
                    {
                        if (solid == null || solid.Faces == null || solid.Faces.Size == 0)
                            continue;

                        foreach (Face face in solid.Faces)
                        {
                            if (face == null)
                                continue;

                            try
                            {
                                IntersectionResultArray resultados;
                                SetComparisonResult res = face.Intersect(linea, out resultados);

                                if (resultados != null && resultados.Size > 0)
                                    return true;
                            }
                            catch
                            {
                            }
                        }
                    }
                }
                catch
                {
                }
            }

            return false;
        }

        private bool LineaPuedeCruzarBoundingBox(Line linea, BoundingBoxXYZ bb, double tolerancia)
        {
            if (linea == null || bb == null)
                return true;

            try
            {
                XYZ a = linea.GetEndPoint(0);
                XYZ b = linea.GetEndPoint(1);

                double minX = Math.Min(a.X, b.X) - tolerancia;
                double maxX = Math.Max(a.X, b.X) + tolerancia;
                double minY = Math.Min(a.Y, b.Y) - tolerancia;
                double maxY = Math.Max(a.Y, b.Y) + tolerancia;
                double minZ = Math.Min(a.Z, b.Z) - tolerancia;
                double maxZ = Math.Max(a.Z, b.Z) + tolerancia;

                if (bb.Max.X < minX || bb.Min.X > maxX) return false;
                if (bb.Max.Y < minY || bb.Min.Y > maxY) return false;
                if (bb.Max.Z < minZ || bb.Min.Z > maxZ) return false;

                return true;
            }
            catch
            {
                return true;
            }
        }

        private void CalcularAnclasGuiaPorLadoLibre(
            List<P2> poligono,
            double xGuia,
            double yGuia,
            double offset,
            out double xCompensado,
            out double yCompensado,
            out string detalle)
        {
            xCompensado = xGuia;
            yCompensado = yGuia;
            detalle = "sin compensación";

            if (poligono == null || poligono.Count < 3)
                return;

            if (offset <= MetersToFeet(0.001))
            {
                detalle = "offset menor a 1 mm";
                return;
            }

            // Se prueban los 4 cuadrantes alrededor del cruce de las 2 líneas guía.
            // El cuadrante correcto es el que queda en el lado libre de la superficie:
            // 1) preferentemente dentro del polígono útil,
            // 2) con mayor longitud disponible de perfiles en X e Y.
            int[] signos = new int[] { -1, 1 };
            double mejorScore = double.MinValue;
            int mejorSignoX = 1;
            int mejorSignoY = 1;
            double mejorLongX = 0.0;
            double mejorLongY = 0.0;
            bool mejorDentro = false;

            foreach (int sx in signos)
            {
                foreach (int sy in signos)
                {
                    double x = xGuia + (sx * offset);
                    double y = yGuia + (sy * offset);

                    bool dentro = PuntoDentroOPerimetro(
                        poligono,
                        new P2(x, y),
                        MetersToFeet(0.005));

                    double longVertical = ObtenerLongitudUtilVertical(poligono, x);
                    double longHorizontal = ObtenerLongitudUtilHorizontal(poligono, y);

                    // Peso alto para el cuadrante cuyo punto offset cae dentro del área útil.
                    // Las longitudes rompen empates en superficies irregulares o con huecos.
                    double score = (dentro ? 1000000.0 : 0.0) + longVertical + longHorizontal;

                    if (score > mejorScore)
                    {
                        mejorScore = score;
                        mejorSignoX = sx;
                        mejorSignoY = sy;
                        mejorLongX = longVertical;
                        mejorLongY = longHorizontal;
                        mejorDentro = dentro;
                    }
                }
            }

            xCompensado = xGuia + (mejorSignoX * offset);
            yCompensado = yGuia + (mejorSignoY * offset);

            // Respaldo: si ningún cuadrante cae dentro, se elige independientemente el lado con más longitud útil.
            if (!mejorDentro)
            {
                double xMas = xGuia + offset;
                double xMenos = xGuia - offset;
                double yMas = yGuia + offset;
                double yMenos = yGuia - offset;

                double lxMas = ObtenerLongitudUtilVertical(poligono, xMas);
                double lxMenos = ObtenerLongitudUtilVertical(poligono, xMenos);
                double lyMas = ObtenerLongitudUtilHorizontal(poligono, yMas);
                double lyMenos = ObtenerLongitudUtilHorizontal(poligono, yMenos);

                xCompensado = lxMas >= lxMenos ? xMas : xMenos;
                yCompensado = lyMas >= lyMenos ? yMas : yMenos;

                detalle =
                    "fallback por longitud útil" +
                    " | Lx+=" + FeetToMeters(lxMas).ToString("0.###") + " m" +
                    " Lx-=" + FeetToMeters(lxMenos).ToString("0.###") + " m" +
                    " Ly+=" + FeetToMeters(lyMas).ToString("0.###") + " m" +
                    " Ly-=" + FeetToMeters(lyMenos).ToString("0.###") + " m";

                return;
            }

            detalle =
                "lado libre detectado" +
                " | signoX=" + mejorSignoX +
                " signoY=" + mejorSignoY +
                " | longV=" + FeetToMeters(mejorLongX).ToString("0.###") + " m" +
                " | longH=" + FeetToMeters(mejorLongY).ToString("0.###") + " m";
        }

        private double ObtenerLongitudUtilHorizontal(List<P2> poligono, double y)
        {
            double total = 0.0;

            List<Intervalo> intervalos = ObtenerIntervalosHorizontal(poligono, y);

            if (intervalos == null)
                return total;

            foreach (Intervalo inter in intervalos)
            {
                if (inter == null)
                    continue;

                if (inter.B > inter.A)
                    total += inter.B - inter.A;
            }

            return total;
        }

        private double ObtenerLongitudUtilVertical(List<P2> poligono, double x)
        {
            double total = 0.0;

            List<Intervalo> intervalos = ObtenerIntervalosVertical(poligono, x);

            if (intervalos == null)
                return total;

            foreach (Intervalo inter in intervalos)
            {
                if (inter == null)
                    continue;

                if (inter.B > inter.A)
                    total += inter.B - inter.A;
            }

            return total;
        }

        private List<Segmento2D> GenerarSegmentosAmbasDirecciones(
            List<P2> poligono,
            Bounding2D bbox,
            double separacion,
            double margen,
            double longitudMinima,
            bool proyectarAlPerimetro,
            double? anclaX,
            double? anclaY)
        {
            List<Segmento2D> segmentos = new List<Segmento2D>();

            segmentos.AddRange(GenerarSegmentosPrincipales(
                poligono,
                bbox,
                separacion,
                margen,
                longitudMinima,
                proyectarAlPerimetro,
                anclaY));

            segmentos.AddRange(GenerarSegmentosSecundarios(
                poligono,
                bbox,
                separacion,
                margen,
                longitudMinima,
                proyectarAlPerimetro,
                anclaX));

            return LimpiarSegmentosDuplicados(segmentos, MetersToFeet(0.005));
        }

        private List<Segmento2D> LimpiarSegmentosDuplicados(List<Segmento2D> segmentos, double tol)
        {
            List<Segmento2D> limpios = new List<Segmento2D>();
            HashSet<string> claves = new HashSet<string>();

            if (segmentos == null)
                return limpios;

            foreach (Segmento2D s in segmentos)
            {
                if (s == null || s.A == null || s.B == null)
                    continue;

                string c1 = CrearClavePunto(s.A, tol);
                string c2 = CrearClavePunto(s.B, tol);

                string clave = string.CompareOrdinal(c1, c2) <= 0
                    ? c1 + "-" + c2
                    : c2 + "-" + c1;

                if (claves.Contains(clave))
                    continue;

                claves.Add(clave);
                limpios.Add(s);
            }

            return limpios;
        }

        private List<Segmento2D> GenerarSegmentosPrincipales(
            List<P2> poligono,
            Bounding2D bbox,
            double separacion,
            double margen,
            double longitudMinima,
            bool proyectarAlPerimetro,
            double? anclaY)
        {
            List<Segmento2D> segmentos = new List<Segmento2D>();
            List<double> posicionesY = CrearPosicionesConAncla(bbox.MinY + margen, bbox.MaxY - margen, separacion, anclaY);

            foreach (double y in posicionesY)
            {
                List<Intervalo> intervalos = ObtenerIntervalosHorizontal(poligono, y);

                foreach (Intervalo inter in intervalos)
                {
                    double x1 = proyectarAlPerimetro ? inter.A : inter.A + margen;
                    double x2 = proyectarAlPerimetro ? inter.B : inter.B - margen;

                    if (x2 - x1 < longitudMinima)
                        continue;

                    segmentos.Add(new Segmento2D(new P2(x1, y), new P2(x2, y)));
                }
            }

            return segmentos;
        }

        private List<Segmento2D> GenerarSegmentosSecundarios(
            List<P2> poligono,
            Bounding2D bbox,
            double separacion,
            double margen,
            double longitudMinima,
            bool proyectarAlPerimetro,
            double? anclaX)
        {
            List<Segmento2D> segmentos = new List<Segmento2D>();
            List<double> posicionesX = CrearPosicionesConAncla(bbox.MinX + margen, bbox.MaxX - margen, separacion, anclaX);

            foreach (double x in posicionesX)
            {
                List<Intervalo> intervalos = ObtenerIntervalosVertical(poligono, x);

                foreach (Intervalo inter in intervalos)
                {
                    double y1 = proyectarAlPerimetro ? inter.A : inter.A + margen;
                    double y2 = proyectarAlPerimetro ? inter.B : inter.B - margen;

                    if (y2 - y1 < longitudMinima)
                        continue;

                    segmentos.Add(new Segmento2D(new P2(x, y1), new P2(x, y2)));
                }
            }

            return segmentos;
        }

        private List<Segmento2D> AjustarSegmentosInternosContraMarco(
            List<Segmento2D> segmentos,
            double recorteContraMarco,
            double longitudMinima)
        {
            List<Segmento2D> ajustados = new List<Segmento2D>();

            if (segmentos == null)
                return ajustados;

            if (recorteContraMarco <= MetersToFeet(0.001))
                return segmentos;

            foreach (Segmento2D s in segmentos)
            {
                if (s == null || s.A == null || s.B == null)
                    continue;

                double longitud = Distancia(s.A, s.B);

                if (longitud <= longitudMinima)
                    continue;

                // Si el tramo es muy pequeño, no se ajusta para no invertir el segmento.
                // En tramos normales se recorta desde ambos extremos una distancia igual
                // a medio Ancho del marco perimetral. Esto hace que el sólido del perfil
                // interno termine contra la cara del marco y no contra su eje.
                double recorte = recorteContraMarco;

                if ((longitud - (2.0 * recorte)) < longitudMinima)
                {
                    // Si no alcanza para recortar ambos extremos, se conserva el tramo
                    // únicamente si todavía es útil. En caso contrario se omite.
                    if (longitud >= longitudMinima)
                        ajustados.Add(s);

                    continue;
                }

                double ux = (s.B.X - s.A.X) / longitud;
                double uy = (s.B.Y - s.A.Y) / longitud;

                P2 aa = new P2(
                    s.A.X + (ux * recorte),
                    s.A.Y + (uy * recorte));

                P2 bb = new P2(
                    s.B.X - (ux * recorte),
                    s.B.Y - (uy * recorte));

                if (Distancia(aa, bb) < longitudMinima)
                    continue;

                ajustados.Add(new Segmento2D(aa, bb));
            }

            return ajustados;
        }

        private List<Segmento2D> GenerarSegmentosMarcoSinClash(List<P2> poligono, double longitudMinima, double mediaAnchoPerfil)
        {
            List<Segmento2D> segmentos = new List<Segmento2D>();

            if (poligono == null || poligono.Count < 3)
                return segmentos;

            if (mediaAnchoPerfil < 0.0)
                mediaAnchoPerfil = 0.0;

            double tol = MetersToFeet(0.001);
            int n = poligono.Count;

            for (int i = 0; i < n; i++)
            {
                P2 a = poligono[i];
                P2 b = poligono[(i + 1) % n];

                double longitud = Distancia(a, b);

                if (longitud < longitudMinima)
                    continue;

                double ux = (b.X - a.X) / longitud;
                double uy = (b.Y - a.Y) / longitud;

                // V21 - Marco sin clash:
                // El polígono del marco ya está desplazado hacia adentro Ancho/2.
                // Si todos los ejes se sobreextienden, se cierran las esquinas pero se produce clash.
                // Por eso se aplica una junta tipo TOPE alternada:
                //   - Lados pares: pasan en ambos extremos. Su eje se extiende media sección.
                //   - Lados impares: topan contra los pares. Su eje se recorta media sección.
                //
                // Esto funciona en superficies inclinadas porque se resuelve en 2D local de la cara pickada;
                // luego Convertir2Da3D devuelve los puntos sobre el plano inclinado correspondiente.
                bool ladoPasa = (i % 2 == 0);
                double extInicio = ladoPasa ? mediaAnchoPerfil : -mediaAnchoPerfil;
                double extFinal = ladoPasa ? mediaAnchoPerfil : -mediaAnchoPerfil;

                // Si el lado es muy corto, se evita invertir el segmento por exceso de recorte.
                if (!ladoPasa && (longitud - (2.0 * mediaAnchoPerfil)) < longitudMinima)
                {
                    extInicio = 0.0;
                    extFinal = 0.0;
                }

                P2 aa = new P2(
                    a.X - (ux * extInicio),
                    a.Y - (uy * extInicio));

                P2 bb = new P2(
                    b.X + (ux * extFinal),
                    b.Y + (uy * extFinal));

                if (Distancia(aa, bb) < Math.Max(longitudMinima, tol))
                    continue;

                segmentos.Add(new Segmento2D(aa, bb));
            }

            return segmentos;
        }

        private List<P2> GenerarPoligonoOffsetInterior(List<P2> poligono, double distanciaInterior)
        {
            List<P2> resultado = new List<P2>();

            if (poligono == null || poligono.Count < 3)
                return resultado;

            if (distanciaInterior <= 0.0)
                return poligono.Select(p => new P2(p.X, p.Y)).ToList();

            double area = AreaPoligono(poligono);

            if (Math.Abs(area) < 1e-12)
                return resultado;

            // Si el polígono es CCW, el interior está a la izquierda de cada arista.
            // Si es CW, el interior está a la derecha. El offset se calcula en 2D local
            // de la cara, por eso también funciona en superficies inclinadas.
            int orientacion = area >= 0.0 ? 1 : -1;
            int n = poligono.Count;

            List<Linea2D> lineasOffset = new List<Linea2D>();

            for (int i = 0; i < n; i++)
            {
                P2 a = poligono[i];
                P2 b = poligono[(i + 1) % n];

                double dx = b.X - a.X;
                double dy = b.Y - a.Y;
                double len = Math.Sqrt((dx * dx) + (dy * dy));

                if (len <= 1e-12)
                    continue;

                double nx;
                double ny;

                if (orientacion > 0)
                {
                    nx = -dy / len;
                    ny = dx / len;
                }
                else
                {
                    nx = dy / len;
                    ny = -dx / len;
                }

                Linea2D linea = new Linea2D();
                linea.A = new P2(a.X + (nx * distanciaInterior), a.Y + (ny * distanciaInterior));
                linea.B = new P2(b.X + (nx * distanciaInterior), b.Y + (ny * distanciaInterior));
                lineasOffset.Add(linea);
            }

            if (lineasOffset.Count < 3)
                return resultado;

            for (int i = 0; i < lineasOffset.Count; i++)
            {
                Linea2D anterior = lineasOffset[(i - 1 + lineasOffset.Count) % lineasOffset.Count];
                Linea2D actual = lineasOffset[i];

                P2 interseccion;

                if (IntersectarLineasInfinitas(anterior.A, anterior.B, actual.A, actual.B, out interseccion))
                {
                    resultado.Add(interseccion);
                }
                else
                {
                    // Fallback para aristas casi paralelas o vértices degenerados.
                    resultado.Add(actual.A);
                }
            }

            // Limpieza básica de vértices muy cercanos.
            List<P2> limpio = new List<P2>();
            double tol = MetersToFeet(0.001);

            foreach (P2 p in resultado)
            {
                if (p == null)
                    continue;

                if (limpio.Count == 0 || Distancia(limpio.Last(), p) > tol)
                    limpio.Add(p);
            }

            if (limpio.Count > 2 && Distancia(limpio.First(), limpio.Last()) <= tol)
                limpio.RemoveAt(limpio.Count - 1);

            if (limpio.Count < 3)
                return new List<P2>();

            return limpio;
        }

        private bool IntersectarLineasInfinitas(P2 a1, P2 a2, P2 b1, P2 b2, out P2 interseccion)
        {
            interseccion = null;

            if (a1 == null || a2 == null || b1 == null || b2 == null)
                return false;

            double x1 = a1.X;
            double y1 = a1.Y;
            double x2 = a2.X;
            double y2 = a2.Y;
            double x3 = b1.X;
            double y3 = b1.Y;
            double x4 = b2.X;
            double y4 = b2.Y;

            double den = ((x1 - x2) * (y3 - y4)) - ((y1 - y2) * (x3 - x4));

            if (Math.Abs(den) < 1e-12)
                return false;

            double det1 = (x1 * y2) - (y1 * x2);
            double det2 = (x3 * y4) - (y3 * x4);

            double px = ((det1 * (x3 - x4)) - ((x1 - x2) * det2)) / den;
            double py = ((det1 * (y3 - y4)) - ((y1 - y2) * det2)) / den;

            interseccion = new P2(px, py);
            return true;
        }

        private List<double> CrearPosiciones(double min, double max, double separacion)
        {
            List<double> posiciones = new List<double>();

            if (max < min)
                return posiciones;

            if (Math.Abs(max - min) < MetersToFeet(0.005))
            {
                posiciones.Add((min + max) / 2.0);
                return posiciones;
            }

            double d = min;
            int seguridad = 0;

            while (d <= max + MetersToFeet(0.001) && seguridad < 10000)
            {
                posiciones.Add(d);
                d += separacion;
                seguridad++;
            }

            if (posiciones.Count == 0)
                posiciones.Add((min + max) / 2.0);

            return posiciones;
        }

        private List<double> CrearPosicionesConAncla(double min, double max, double separacion, double? ancla)
        {
            if (!ancla.HasValue)
                return CrearPosiciones(min, max, separacion);

            List<double> posiciones = new List<double>();

            if (max < min)
                return posiciones;

            if (separacion <= MetersToFeet(0.05))
                separacion = MetersToFeet(1.20);

            double a = ancla.Value;

            // Lleva el ancla al primer módulo dentro del rango [min, max]
            while (a > min + MetersToFeet(0.001))
                a -= separacion;

            while (a < min - MetersToFeet(0.001))
                a += separacion;

            int seguridad = 0;
            double d = a;

            while (d <= max + MetersToFeet(0.001) && seguridad < 10000)
            {
                if (d >= min - MetersToFeet(0.001))
                    posiciones.Add(d);

                d += separacion;
                seguridad++;
            }

            // Si el ancla real está dentro del área útil pero por tolerancias no cayó en la lista, se agrega.
            if (ancla.Value >= min - MetersToFeet(0.001) && ancla.Value <= max + MetersToFeet(0.001))
                posiciones.Add(ancla.Value);

            if (posiciones.Count == 0)
                posiciones.Add((min + max) / 2.0);

            return posiciones
                .Distinct(new DoubleComparer(MetersToFeet(0.002)))
                .OrderBy(x => x)
                .ToList();
        }

        private List<Intervalo> ObtenerIntervalosHorizontal(List<P2> poligono, double y)
        {
            List<double> xs = new List<double>();
            double tol = 1e-9;

            for (int i = 0; i < poligono.Count; i++)
            {
                P2 a = poligono[i];
                P2 b = poligono[(i + 1) % poligono.Count];

                if (Math.Abs(a.Y - b.Y) < tol)
                    continue;

                double ymin = Math.Min(a.Y, b.Y);
                double ymax = Math.Max(a.Y, b.Y);

                if (y < ymin || y >= ymax)
                    continue;

                double x = a.X + ((y - a.Y) * (b.X - a.X) / (b.Y - a.Y));
                xs.Add(x);
            }

            return CrearIntervalosDesdeIntersecciones(xs);
        }

        private List<Intervalo> ObtenerIntervalosVertical(List<P2> poligono, double x)
        {
            List<double> ys = new List<double>();
            double tol = 1e-9;

            for (int i = 0; i < poligono.Count; i++)
            {
                P2 a = poligono[i];
                P2 b = poligono[(i + 1) % poligono.Count];

                if (Math.Abs(a.X - b.X) < tol)
                    continue;

                double xmin = Math.Min(a.X, b.X);
                double xmax = Math.Max(a.X, b.X);

                if (x < xmin || x >= xmax)
                    continue;

                double y = a.Y + ((x - a.X) * (b.Y - a.Y) / (b.X - a.X));
                ys.Add(y);
            }

            return CrearIntervalosDesdeIntersecciones(ys);
        }

        private List<Intervalo> CrearIntervalosDesdeIntersecciones(List<double> valores)
        {
            List<Intervalo> intervalos = new List<Intervalo>();

            if (valores == null || valores.Count < 2)
                return intervalos;

            List<double> ordenados = valores
                .OrderBy(x => x)
                .ToList();

            List<double> limpios = new List<double>();

            foreach (double v in ordenados)
            {
                if (limpios.Count == 0 || Math.Abs(limpios.Last() - v) > MetersToFeet(0.001))
                    limpios.Add(v);
            }

            for (int i = 0; i + 1 < limpios.Count; i += 2)
            {
                double a = limpios[i];
                double b = limpios[i + 1];

                if (b > a)
                    intervalos.Add(new Intervalo(a, b));
            }

            return intervalos;
        }

        private List<P2> ObtenerPuntosColgadoresDobleSecundario(
            List<P2> poligono,
            Bounding2D bbox,
            double separacionSecundaria,
            double margen,
            List<Segmento2D> segmentosMarcoPerimetral,
            double? anclaX,
            double? anclaY)
        {
            List<P2> puntos = new List<P2>();
            HashSet<string> claves = new HashSet<string>();

            if (poligono == null || poligono.Count < 3 || bbox == null)
                return puntos;

            double toleranciaClave = MetersToFeet(0.005);
            double separacion = separacionSecundaria * 2.0;

            if (separacion <= MetersToFeet(0.05))
                separacion = MetersToFeet(1.20);

            // La rejilla inicia con el mismo origen de los perfiles secundarios,
            // pero avanza cada 2 módulos. Por ejemplo: secundarios cada 0.60 m,
            // colgadores cada 1.20 m.
            List<double> posicionesX = CrearPosicionesConAncla(bbox.MinX + margen, bbox.MaxX - margen, separacion, anclaX);
            List<double> posicionesY = CrearPosicionesConAncla(bbox.MinY + margen, bbox.MaxY - margen, separacion, anclaY);

            foreach (double x in posicionesX)
            {
                foreach (double y in posicionesY)
                {
                    P2 p = new P2(x, y);

                    if (!PuntoDentroOPerimetro(poligono, p, MetersToFeet(0.005)))
                        continue;

                    AgregarPuntoColgadorUnico(p, puntos, claves, toleranciaClave);
                }
            }

            // Mantiene el refuerzo perimetral solicitado en la V14,
            // pero con la misma separación automática del doble de secundarios.
            AgregarPuntosColgadoresDesdeSegmentos(
                segmentosMarcoPerimetral,
                separacion,
                puntos,
                claves,
                toleranciaClave);

            return puntos;
        }

        private bool PuntoDentroOPerimetro(List<P2> poligono, P2 punto, double tolerancia)
        {
            if (poligono == null || poligono.Count < 3 || punto == null)
                return false;

            for (int i = 0; i < poligono.Count; i++)
            {
                P2 a = poligono[i];
                P2 b = poligono[(i + 1) % poligono.Count];

                if (DistanciaPuntoASegmento(punto, a, b) <= tolerancia)
                    return true;
            }

            bool dentro = false;

            for (int i = 0, j = poligono.Count - 1; i < poligono.Count; j = i++)
            {
                P2 pi = poligono[i];
                P2 pj = poligono[j];

                bool cruza = ((pi.Y > punto.Y) != (pj.Y > punto.Y)) &&
                    (punto.X < (pj.X - pi.X) * (punto.Y - pi.Y) / ((pj.Y - pi.Y) == 0.0 ? 1e-12 : (pj.Y - pi.Y)) + pi.X);

                if (cruza)
                    dentro = !dentro;
            }

            return dentro;
        }

        private double DistanciaPuntoASegmento(P2 p, P2 a, P2 b)
        {
            if (p == null || a == null || b == null)
                return double.MaxValue;

            double dx = b.X - a.X;
            double dy = b.Y - a.Y;
            double l2 = (dx * dx) + (dy * dy);

            if (l2 <= 1e-12)
                return Distancia(p, a);

            double t = ((p.X - a.X) * dx + (p.Y - a.Y) * dy) / l2;
            t = Math.Max(0.0, Math.Min(1.0, t));

            P2 proy = new P2(a.X + (t * dx), a.Y + (t * dy));
            return Distancia(p, proy);
        }

        private bool PuntoCercaDeSegmentos(
            P2 punto,
            List<Segmento2D> segmentos,
            double tolerancia)
        {
            if (punto == null || segmentos == null || segmentos.Count == 0)
                return false;

            if (tolerancia <= 0.0)
                tolerancia = MetersToFeet(0.02);

            foreach (Segmento2D s in segmentos)
            {
                if (s == null || s.A == null || s.B == null)
                    continue;

                if (DistanciaPuntoASegmento(punto, s.A, s.B) <= tolerancia)
                    return true;
            }

            return false;
        }

        private List<P2> ObtenerPuntosColgadores(
            List<Segmento2D> segmentosPrincipales,
            List<Segmento2D> segmentosMarcoPerimetral,
            double separacion)
        {
            List<P2> puntos = new List<P2>();
            HashSet<string> claves = new HashSet<string>();
            double toleranciaClave = MetersToFeet(0.005);

            // 01. Colgadores normales sobre perfiles principales.
            AgregarPuntosColgadoresDesdeSegmentos(
                segmentosPrincipales,
                separacion,
                puntos,
                claves,
                toleranciaClave);

            // 02. Refuerzo perimetral.
            // Cuando el perfil principal/longitudinal no llega a un extremo o no existe tramo interior
            // por geometría irregular, igual debe existir colgador sobre el marco perimetral.
            // Estos puntos se agregan sobre la línea del perimetral y se filtran contra los ya creados
            // para no duplicar colgadores en encuentros donde sí llegó el perfil principal.
            AgregarPuntosColgadoresDesdeSegmentos(
                segmentosMarcoPerimetral,
                separacion,
                puntos,
                claves,
                toleranciaClave);

            return puntos;
        }

        private void AgregarPuntosColgadoresDesdeSegmentos(
            List<Segmento2D> segmentos,
            double separacion,
            List<P2> puntos,
            HashSet<string> claves,
            double toleranciaClave)
        {
            if (segmentos == null || puntos == null || claves == null)
                return;

            foreach (Segmento2D s in segmentos)
            {
                if (s == null || s.A == null || s.B == null)
                    continue;

                double longitud = Distancia(s.A, s.B);

                if (longitud <= MetersToFeet(0.02))
                    continue;

                if (separacion <= MetersToFeet(0.05))
                    separacion = MetersToFeet(1.20);

                int cantidad = Math.Max(1, (int)Math.Floor(longitud / separacion));

                for (int i = 0; i <= cantidad; i++)
                {
                    double d = i * separacion;

                    if (i == cantidad)
                        d = longitud;

                    if (d > longitud)
                        d = longitud;

                    double t = longitud <= 0.0 ? 0.0 : d / longitud;
                    P2 p = Interpolar(s.A, s.B, t);

                    AgregarPuntoColgadorUnico(p, puntos, claves, toleranciaClave);
                }
            }
        }

        private void AgregarPuntoColgadorUnico(
            P2 p,
            List<P2> puntos,
            HashSet<string> claves,
            double toleranciaClave)
        {
            if (p == null || puntos == null || claves == null)
                return;

            string clave = CrearClavePunto(p, toleranciaClave);

            if (claves.Contains(clave))
                return;

            claves.Add(clave);
            puntos.Add(p);
        }

        private List<P2> ProyectarPoligono(List<XYZ> puntos, XYZ origen, XYZ dirU, XYZ dirV)
        {
            List<P2> lista = new List<P2>();

            if (puntos == null)
                return lista;

            foreach (XYZ p in puntos)
            {
                XYZ v = p - origen;
                lista.Add(new P2(v.DotProduct(dirU), v.DotProduct(dirV)));
            }

            return lista;
        }

        private P2 ProyectarPunto(XYZ punto, XYZ origen, XYZ dirU, XYZ dirV)
        {
            if (punto == null || origen == null || dirU == null || dirV == null)
                return null;

            XYZ v = punto - origen;
            return new P2(v.DotProduct(dirU), v.DotProduct(dirV));
        }

        private XYZ Convertir2Da3D(P2 p, XYZ origen, XYZ dirU, XYZ dirV)
        {
            return origen + (dirU * p.X) + (dirV * p.Y);
        }

        private Bounding2D ObtenerBounding2D(List<P2> puntos)
        {
            if (puntos == null || puntos.Count == 0)
                return null;

            Bounding2D b = new Bounding2D();
            b.MinX = puntos.Min(p => p.X);
            b.MaxX = puntos.Max(p => p.X);
            b.MinY = puntos.Min(p => p.Y);
            b.MaxY = puntos.Max(p => p.Y);
            return b;
        }

        private double AreaPoligono(List<P2> puntos)
        {
            if (puntos == null || puntos.Count < 3)
                return 0.0;

            double suma = 0.0;

            for (int i = 0; i < puntos.Count; i++)
            {
                P2 a = puntos[i];
                P2 b = puntos[(i + 1) % puntos.Count];
                suma += (a.X * b.Y) - (b.X * a.Y);
            }

            return suma / 2.0;
        }

        private double Distancia(P2 a, P2 b)
        {
            double dx = b.X - a.X;
            double dy = b.Y - a.Y;
            return Math.Sqrt((dx * dx) + (dy * dy));
        }

        private P2 Interpolar(P2 a, P2 b, double t)
        {
            return new P2(
                a.X + ((b.X - a.X) * t),
                a.Y + ((b.Y - a.Y) * t));
        }

        private string CrearClavePunto(P2 p, double tol)
        {
            long x = (long)Math.Round(p.X / tol);
            long y = (long)Math.Round(p.Y / tol);
            return x + "|" + y;
        }

        private XYZ ProyectarVectorEnPlano(XYZ vector, XYZ normal)
        {
            if (vector == null || normal == null)
                return XYZ.Zero;

            XYZ n = normal.Normalize();
            XYZ proyectado = vector - (n * vector.DotProduct(n));

            if (proyectado.GetLength() < 0.000001)
                return XYZ.Zero;

            return proyectado;
        }

        private void ConstruirEjesDesdeNormal(XYZ normal, out XYZ dirU, out XYZ dirV)
        {
            XYZ n = normal.Normalize();
            XYZ baseRef = Math.Abs(n.DotProduct(XYZ.BasisZ)) < 0.90 ? XYZ.BasisZ : XYZ.BasisX;
            dirU = baseRef.CrossProduct(n);

            if (dirU.GetLength() < 0.000001)
                dirU = XYZ.BasisX;
            else
                dirU = dirU.Normalize();

            dirV = n.CrossProduct(dirU).Normalize();
        }

        private bool EsSuperficieInclinada(XYZ normal)
        {
            if (normal == null || normal.GetLength() < 0.000001)
                return false;

            XYZ n = normal.Normalize();
            double dotZ = Math.Abs(n.DotProduct(XYZ.BasisZ));

            // Aproximadamente mayor a 1 grado de inclinación respecto a horizontal.
            return dotZ < 0.99985;
        }

        // =========================================================
        // V43 - ORIENTACIÓN AUTOMÁTICA POR LUZ / BOCETO
        // =========================================================
        // Esta rutina SOLO se usa cuando NO hay guía manual ni caras guía.
        // Toma el contorno exterior de la cara pickada y busca la dirección dominante
        // de sus lados. En un Floor/Ceiling rectangular, esa dirección coincide con
        // la luz/lado largo del boceto. En superficies inclinadas se trabaja siempre
        // dentro del plano real de la cara, no en XY global.
        private bool ObtenerEjesAutomaticosDesdeLuzOBoceto(
            SuperficiePickada superficie,
            XYZ normal,
            out XYZ dirU,
            out XYZ dirV,
            out string detalle)
        {
            dirU = null;
            dirV = null;
            detalle = "no se pudo leer contorno";

            if (superficie == null || superficie.PoligonoExterior3D == null || superficie.PoligonoExterior3D.Count < 3)
                return false;

            if (normal == null || normal.GetLength() < 0.000001)
                return false;

            XYZ n = normal.Normalize();

            List<GrupoDireccionBoceto> grupos = new List<GrupoDireccionBoceto>();
            double longitudTotalAnalizada = 0.0;
            double longitudMinimaLado = MetersToFeet(0.03);
            double cosAgrupacion = Math.Cos(15.0 * Math.PI / 180.0);

            List<XYZ> pts = superficie.PoligonoExterior3D;

            for (int i = 0; i < pts.Count; i++)
            {
                XYZ a = pts[i];
                XYZ b = pts[(i + 1) % pts.Count];

                if (a == null || b == null)
                    continue;

                XYZ v = b - a;
                v = ProyectarVectorEnPlano(v, n);

                if (v == null || v.GetLength() <= longitudMinimaLado)
                    continue;

                double len = v.GetLength();
                XYZ dir = v.Normalize();

                AgregarDireccionAGruposBoceto(grupos, dir, len, cosAgrupacion);
                longitudTotalAnalizada += len;
            }

            if (grupos.Count == 0)
            {
                detalle = "sin lados útiles en el boceto";
                return false;
            }

            GrupoDireccionBoceto mejor = grupos
                .OrderByDescending(g => g.LongitudAcumulada)
                .FirstOrDefault();

            if (mejor == null || mejor.Direccion == null || mejor.Direccion.GetLength() < 0.000001)
            {
                detalle = "no se pudo agrupar dirección dominante";
                return false;
            }

            XYZ direccion = ProyectarVectorEnPlano(mejor.Direccion, n);

            if (direccion == null || direccion.GetLength() < 0.000001)
            {
                detalle = "dirección dominante inválida";
                return false;
            }

            direccion = direccion.Normalize();

            // Mantiene un sentido estable respecto al eje original de la cara, pero sin cambiar la orientación.
            if (superficie.DirU != null && superficie.DirU.GetLength() > 0.000001)
            {
                XYZ dirRef = ProyectarVectorEnPlano(superficie.DirU, n);

                if (dirRef != null && dirRef.GetLength() > 0.000001 && direccion.DotProduct(dirRef.Normalize()) < 0.0)
                    direccion = -direccion;
            }

            XYZ perpendicular = n.CrossProduct(direccion);

            if (perpendicular == null || perpendicular.GetLength() < 0.000001)
            {
                detalle = "no se pudo construir eje perpendicular";
                return false;
            }

            dirU = direccion.Normalize();
            dirV = perpendicular.Normalize();

            double porcentaje = longitudTotalAnalizada > 0.0
                ? (mejor.LongitudAcumulada / longitudTotalAnalizada) * 100.0
                : 0.0;

            detalle =
                "dirección dominante del contorno" +
                " | lados agrupados=" + mejor.CantidadLados +
                " | longitud agrupada=" + FeetToMeters(mejor.LongitudAcumulada).ToString("0.###") + " m" +
                " | peso=" + porcentaje.ToString("0") + "%";

            return true;
        }

        private void AgregarDireccionAGruposBoceto(
            List<GrupoDireccionBoceto> grupos,
            XYZ direccion,
            double longitud,
            double cosAgrupacion)
        {
            if (grupos == null || direccion == null || direccion.GetLength() < 0.000001 || longitud <= 0.0)
                return;

            XYZ dir = direccion.Normalize();

            foreach (GrupoDireccionBoceto g in grupos)
            {
                if (g == null || g.Direccion == null || g.Direccion.GetLength() < 0.000001)
                    continue;

                double dot = g.Direccion.Normalize().DotProduct(dir);

                // Se agrupan direcciones paralelas aunque vengan en sentido contrario.
                if (Math.Abs(dot) >= cosAgrupacion)
                {
                    if (dot < 0.0)
                        dir = -dir;

                    g.VectorAcumulado = g.VectorAcumulado + (dir * longitud);
                    g.LongitudAcumulada += longitud;
                    g.CantidadLados++;

                    if (g.VectorAcumulado != null && g.VectorAcumulado.GetLength() > 0.000001)
                        g.Direccion = g.VectorAcumulado.Normalize();

                    return;
                }
            }

            GrupoDireccionBoceto nuevo = new GrupoDireccionBoceto();
            nuevo.Direccion = dir;
            nuevo.VectorAcumulado = dir * longitud;
            nuevo.LongitudAcumulada = longitud;
            nuevo.CantidadLados = 1;
            grupos.Add(nuevo);
        }

        private void ObtenerEjesAutomaticosParaSuperficie(
            XYZ normal,
            XYZ direccionPreferida,
            out XYZ dirU,
            out XYZ dirV)
        {
            dirU = XYZ.BasisX;
            dirV = XYZ.BasisY;

            if (normal == null || normal.GetLength() < 0.000001)
                return;

            XYZ n = normal.Normalize();

            if (EsSuperficieInclinada(n))
            {
                // Dirección de máxima pendiente dentro de la cara.
                XYZ dirPendiente = ProyectarVectorEnPlano(XYZ.BasisZ, n);

                if (dirPendiente != null && dirPendiente.GetLength() > 0.000001)
                {
                    dirPendiente = dirPendiente.Normalize();

                    // Dirección transversal horizontal dentro de la cara.
                    XYZ dirHorizontal = n.CrossProduct(dirPendiente);

                    if (dirHorizontal != null && dirHorizontal.GetLength() > 0.000001)
                    {
                        dirU = dirHorizontal.Normalize();
                        dirV = n.CrossProduct(dirU).Normalize();
                        return;
                    }
                }
            }

            XYZ dir = ProyectarVectorEnPlano(direccionPreferida, n);

            if (dir == null || dir.GetLength() < 0.000001)
            {
                ConstruirEjesDesdeNormal(n, out dirU, out dirV);
                return;
            }

            dirU = dir.Normalize();
            dirV = n.CrossProduct(dirU).Normalize();
        }

        private XYZ ObtenerDireccionDesfaseHaciaAbajo(XYZ normal)
        {
            if (normal == null || normal.GetLength() < 0.000001)
                return -XYZ.BasisZ;

            XYZ n = normal.Normalize();

            if (n.Z > 0.0)
                n = -n;

            return n.Normalize();
        }

        private XYZ OrientarNormalHaciaArriba(XYZ normal)
        {
            if (normal == null || normal.GetLength() < 0.000001)
                return XYZ.BasisZ;

            XYZ n = normal.Normalize();

            if (n.Z < 0.0)
                n = -n;

            return n.Normalize();
        }

        private ImpactoSuperior BuscarCaraMasCercanaHaciaArriba(
            Document doc,
            XYZ puntoBase,
            double distanciaMaxima,
            HashSet<long> idsExcluir)
        {
            if (doc == null || puntoBase == null)
                return null;

            double tol = MetersToFeet(0.005);
            XYZ pInicio = puntoBase + (XYZ.BasisZ * tol);
            XYZ pFin = puntoBase + (XYZ.BasisZ * distanciaMaxima);

            if (pInicio.DistanceTo(pFin) <= tol)
                return null;

            Line lineaBusqueda = Line.CreateBound(pInicio, pFin);

            Options opciones = new Options();
            opciones.ComputeReferences = true;
            opciones.IncludeNonVisibleObjects = false;
            opciones.DetailLevel = ViewDetailLevel.Fine;

            try
            {
                if (doc.ActiveView != null && !doc.ActiveView.IsTemplate)
                    opciones.View = doc.ActiveView;
            }
            catch
            {
            }

            FilteredElementCollector collector;

            try
            {
                collector = new FilteredElementCollector(doc, doc.ActiveView.Id);
            }
            catch
            {
                collector = new FilteredElementCollector(doc);
            }

            List<Element> elementos = collector
                .WhereElementIsNotElementType()
                .ToElements()
                .Where(x => EsElementoCandidatoParaCaraSuperior(x, idsExcluir))
                .ToList();

            ImpactoSuperior mejor = null;
            double mejorDistanciaZ = double.MaxValue;

            // 01. Buscar primero en elementos nativos del documento anfitrión.
            foreach (Element e in elementos)
            {
                try
                {
                    GeometryElement ge = e.get_Geometry(opciones);

                    if (ge == null)
                        continue;

                    List<Solid> solidos = new List<Solid>();
                    RecolectarSolidos(ge, solidos);

                    foreach (Solid solid in solidos)
                    {
                        ImpactoSuperior impacto = BuscarImpactoEnSolidoNativo(
                            solid,
                            lineaBusqueda,
                            puntoBase,
                            tol,
                            mejorDistanciaZ,
                            e.Id);

                        if (impacto != null && impacto.DistanciaZ < mejorDistanciaZ)
                        {
                            mejorDistanciaZ = impacto.DistanciaZ;
                            mejor = impacto;
                        }
                    }
                }
                catch
                {
                }
            }

            // 02. Buscar también en documentos vinculados visibles/cargados.
            // IMPORTANTE:
            // La búsqueda se hace convirtiendo el rayo vertical del anfitrión
            // al sistema de coordenadas de cada vínculo. El punto encontrado
            // se transforma de vuelta al documento anfitrión.
            ImpactoSuperior impactoVinculo = BuscarCaraMasCercanaHaciaArribaEnVinculos(
                doc,
                pInicio,
                pFin,
                puntoBase,
                tol,
                mejorDistanciaZ,
                idsExcluir);

            if (impactoVinculo != null && impactoVinculo.DistanciaZ < mejorDistanciaZ)
            {
                mejorDistanciaZ = impactoVinculo.DistanciaZ;
                mejor = impactoVinculo;
            }

            return mejor;
        }

        private ImpactoSuperior BuscarImpactoEnSolidoNativo(
            Solid solid,
            Line lineaBusqueda,
            XYZ puntoBase,
            double tol,
            double mejorDistanciaActual,
            ElementId elementId)
        {
            if (solid == null || solid.Faces == null || solid.Faces.Size == 0)
                return null;

            if (lineaBusqueda == null || puntoBase == null)
                return null;

            ImpactoSuperior mejor = null;
            double mejorDistanciaZ = mejorDistanciaActual;

            foreach (Face face in solid.Faces)
            {
                if (face == null)
                    continue;

                try
                {
                    IntersectionResultArray resultados;
                    SetComparisonResult comparacion = face.Intersect(lineaBusqueda, out resultados);

                    if (resultados == null || resultados.Size == 0)
                        continue;

                    for (int i = 0; i < resultados.Size; i++)
                    {
                        IntersectionResult ir = resultados.get_Item(i);

                        if (ir == null || ir.XYZPoint == null)
                            continue;

                        XYZ p = ir.XYZPoint;
                        double dz = p.Z - puntoBase.Z;

                        if (dz <= tol)
                            continue;

                        if (dz >= mejorDistanciaZ)
                            continue;

                        XYZ normalFace = ObtenerNormalCaraEnPunto(face, ir);
                        Reference refCara = null;

                        try
                        {
                            refCara = face.Reference;
                        }
                        catch
                        {
                            refCara = null;
                        }

                        mejorDistanciaZ = dz;
                        mejor = new ImpactoSuperior();
                        mejor.ElementId = elementId;
                        mejor.Face = face;
                        mejor.FaceReference = refCara;
                        mejor.Punto = p;
                        mejor.FaceNormal = normalFace;
                        mejor.DistanciaZ = dz;
                        mejor.EsDeVinculo = false;
                        mejor.LinkInstanceId = ElementId.InvalidElementId;
                        mejor.LinkedElementId = ElementId.InvalidElementId;
                    }
                }
                catch
                {
                }
            }

            return mejor;
        }

        private ImpactoSuperior BuscarCaraMasCercanaHaciaArribaEnVinculos(
            Document doc,
            XYZ pInicioHost,
            XYZ pFinHost,
            XYZ puntoBaseHost,
            double tol,
            double mejorDistanciaActual,
            HashSet<long> idsExcluir)
        {
            if (doc == null || pInicioHost == null || pFinHost == null || puntoBaseHost == null)
                return null;

            List<RevitLinkInstance> vinculos = ObtenerVinculosCargadosParaBusqueda(doc);

            if (vinculos == null || vinculos.Count == 0)
                return null;

            ImpactoSuperior mejor = null;
            double mejorDistanciaZ = mejorDistanciaActual;

            foreach (RevitLinkInstance link in vinculos)
            {
                if (link == null || link.Id == null)
                    continue;

                // No se excluye un vínculo solo porque su Id esté en idsExcluir.
                // idsExcluir contiene sobre todo elementos creados en el anfitrión.
                // Si el usuario trabaja con vínculo, excluir toda la instancia podría
                // impedir detectar la losa/cielo superior del propio vínculo.

                Document linkDoc = null;

                try
                {
                    linkDoc = link.GetLinkDocument();
                }
                catch
                {
                    linkDoc = null;
                }

                if (linkDoc == null)
                    continue;

                Transform trLinkToHost = null;
                Transform trHostToLink = null;

                try
                {
                    trLinkToHost = link.GetTotalTransform();

                    if (trLinkToHost == null)
                        trLinkToHost = Transform.Identity;

                    trHostToLink = trLinkToHost.Inverse;
                }
                catch
                {
                    continue;
                }

                XYZ pInicioLink;
                XYZ pFinLink;

                try
                {
                    pInicioLink = trHostToLink.OfPoint(pInicioHost);
                    pFinLink = trHostToLink.OfPoint(pFinHost);
                }
                catch
                {
                    continue;
                }

                if (pInicioLink == null || pFinLink == null)
                    continue;

                if (pInicioLink.DistanceTo(pFinLink) <= tol)
                    continue;

                Line lineaBusquedaLink = null;

                try
                {
                    lineaBusquedaLink = Line.CreateBound(pInicioLink, pFinLink);
                }
                catch
                {
                    lineaBusquedaLink = null;
                }

                if (lineaBusquedaLink == null)
                    continue;

                Options opcionesLink = new Options();
                opcionesLink.ComputeReferences = true;
                opcionesLink.IncludeNonVisibleObjects = false;
                opcionesLink.DetailLevel = ViewDetailLevel.Fine;

                List<Element> elementosLink = ObtenerElementosCandidatosDeVinculo(
                    linkDoc,
                    pInicioLink,
                    pFinLink,
                    tol);

                if (elementosLink == null || elementosLink.Count == 0)
                    continue;

                foreach (Element eLink in elementosLink)
                {
                    try
                    {
                        if (!EsElementoCandidatoParaCaraSuperiorEnVinculo(eLink))
                            continue;

                        GeometryElement ge = eLink.get_Geometry(opcionesLink);

                        if (ge == null)
                            continue;

                        List<Solid> solidos = new List<Solid>();
                        RecolectarSolidos(ge, solidos);

                        foreach (Solid solid in solidos)
                        {
                            ImpactoSuperior impacto = BuscarImpactoEnSolidoDeVinculo(
                                solid,
                                lineaBusquedaLink,
                                puntoBaseHost,
                                tol,
                                mejorDistanciaZ,
                                link,
                                eLink.Id,
                                trLinkToHost);

                            if (impacto != null && impacto.DistanciaZ < mejorDistanciaZ)
                            {
                                mejorDistanciaZ = impacto.DistanciaZ;
                                mejor = impacto;
                            }
                        }
                    }
                    catch
                    {
                    }
                }
            }

            return mejor;
        }

        private List<RevitLinkInstance> ObtenerVinculosCargadosParaBusqueda(Document doc)
        {
            List<RevitLinkInstance> resultado = new List<RevitLinkInstance>();

            if (doc == null)
                return resultado;

            FilteredElementCollector collector = null;

            try
            {
                if (doc.ActiveView != null && !doc.ActiveView.IsTemplate)
                    collector = new FilteredElementCollector(doc, doc.ActiveView.Id);
            }
            catch
            {
                collector = null;
            }

            if (collector == null)
                collector = new FilteredElementCollector(doc);

            try
            {
                resultado = collector
                    .OfClass(typeof(RevitLinkInstance))
                    .Cast<RevitLinkInstance>()
                    .Where(x => x != null && x.GetLinkDocument() != null)
                    .ToList();
            }
            catch
            {
                resultado = new List<RevitLinkInstance>();
            }

            return resultado;
        }

        private List<Element> ObtenerElementosCandidatosDeVinculo(
            Document linkDoc,
            XYZ pInicioLink,
            XYZ pFinLink,
            double tol)
        {
            List<Element> resultado = new List<Element>();

            if (linkDoc == null || pInicioLink == null || pFinLink == null)
                return resultado;

            FilteredElementCollector collector = new FilteredElementCollector(linkDoc)
                .WhereElementIsNotElementType();

            try
            {
                double margenXY = MetersToFeet(0.10);
                double margenZ = MetersToFeet(0.10);

                XYZ min = new XYZ(
                    Math.Min(pInicioLink.X, pFinLink.X) - margenXY,
                    Math.Min(pInicioLink.Y, pFinLink.Y) - margenXY,
                    Math.Min(pInicioLink.Z, pFinLink.Z) - margenZ);

                XYZ max = new XYZ(
                    Math.Max(pInicioLink.X, pFinLink.X) + margenXY,
                    Math.Max(pInicioLink.Y, pFinLink.Y) + margenXY,
                    Math.Max(pInicioLink.Z, pFinLink.Z) + margenZ);

                Outline outline = new Outline(min, max);
                BoundingBoxIntersectsFilter filtroBb = new BoundingBoxIntersectsFilter(outline);

                collector = collector.WherePasses(filtroBb);
            }
            catch
            {
                // Si el filtro por bounding box falla, se continúa con el collector completo.
            }

            try
            {
                resultado = collector.ToElements().ToList();
            }
            catch
            {
                resultado = new List<Element>();
            }

            return resultado;
        }

        private bool EsElementoCandidatoParaCaraSuperiorEnVinculo(Element e)
        {
            if (e == null || e.Id == null)
                return false;

            if (e.ViewSpecific)
                return false;

            if (e.Category == null)
                return false;

            try
            {
                if (e.Category.CategoryType != CategoryType.Model)
                    return false;
            }
            catch
            {
                return false;
            }

            return true;
        }

        private ImpactoSuperior BuscarImpactoEnSolidoDeVinculo(
            Solid solid,
            Line lineaBusquedaLink,
            XYZ puntoBaseHost,
            double tol,
            double mejorDistanciaActual,
            RevitLinkInstance link,
            ElementId linkedElementId,
            Transform trLinkToHost)
        {
            if (solid == null || solid.Faces == null || solid.Faces.Size == 0)
                return null;

            if (lineaBusquedaLink == null || puntoBaseHost == null || link == null || trLinkToHost == null)
                return null;

            ImpactoSuperior mejor = null;
            double mejorDistanciaZ = mejorDistanciaActual;

            foreach (Face face in solid.Faces)
            {
                if (face == null)
                    continue;

                try
                {
                    IntersectionResultArray resultados;
                    SetComparisonResult comparacion = face.Intersect(lineaBusquedaLink, out resultados);

                    if (resultados == null || resultados.Size == 0)
                        continue;

                    for (int i = 0; i < resultados.Size; i++)
                    {
                        IntersectionResult ir = resultados.get_Item(i);

                        if (ir == null || ir.XYZPoint == null)
                            continue;

                        XYZ puntoLink = ir.XYZPoint;
                        XYZ puntoHost = trLinkToHost.OfPoint(puntoLink);

                        if (puntoHost == null)
                            continue;

                        double dz = puntoHost.Z - puntoBaseHost.Z;

                        if (dz <= tol)
                            continue;

                        if (dz >= mejorDistanciaZ)
                            continue;

                        XYZ normalLink = ObtenerNormalCaraEnPunto(face, ir);
                        XYZ normalHost = normalLink;

                        try
                        {
                            if (normalLink != null && normalLink.GetLength() > 0.000001)
                            {
                                normalHost = trLinkToHost.OfVector(normalLink);

                                if (normalHost != null && normalHost.GetLength() > 0.000001)
                                    normalHost = normalHost.Normalize();
                            }
                        }
                        catch
                        {
                            normalHost = normalLink;
                        }

                        Reference refHost = null;

                        try
                        {
                            Reference refLink = face.Reference;

                            if (refLink != null)
                                refHost = refLink.CreateLinkReference(link);
                        }
                        catch
                        {
                            refHost = null;
                        }

                        mejorDistanciaZ = dz;
                        mejor = new ImpactoSuperior();
                        mejor.ElementId = link.Id;
                        mejor.Face = null;
                        mejor.FaceReference = refHost;
                        mejor.Punto = puntoHost;
                        mejor.FaceNormal = normalHost;
                        mejor.DistanciaZ = dz;
                        mejor.EsDeVinculo = true;
                        mejor.LinkInstanceId = link.Id;
                        mejor.LinkedElementId = linkedElementId;
                    }
                }
                catch
                {
                }
            }

            return mejor;
        }

        private bool EsElementoCandidatoParaCaraSuperior(Element e, HashSet<long> idsExcluir)
        {
            if (e == null || e.Id == null)
                return false;

            if (idsExcluir != null && idsExcluir.Contains(e.Id.Value))
                return false;

            if (e.ViewSpecific)
                return false;

            if (e.Category == null)
                return false;

            try
            {
                if (e.Category.CategoryType != CategoryType.Model)
                    return false;
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void RecolectarSolidos(GeometryElement ge, List<Solid> solidos)
        {
            if (ge == null || solidos == null)
                return;

            foreach (GeometryObject obj in ge)
            {
                Solid solid = obj as Solid;

                if (solid != null && solid.Faces != null && solid.Faces.Size > 0 && solid.Volume > 0.0000001)
                {
                    solidos.Add(solid);
                    continue;
                }

                GeometryInstance gi = obj as GeometryInstance;

                if (gi != null)
                {
                    try
                    {
                        GeometryElement geInst = gi.GetInstanceGeometry();
                        RecolectarSolidos(geInst, solidos);
                    }
                    catch
                    {
                    }
                }
            }
        }

        private XYZ ObtenerNormalCaraEnPunto(Face face, IntersectionResult ir)
        {
            try
            {
                if (face != null && ir != null && ir.UVPoint != null)
                {
                    XYZ n = face.ComputeNormal(ir.UVPoint);

                    if (n != null && n.GetLength() > 0.000001)
                        return n.Normalize();
                }
            }
            catch
            {
            }

            return -XYZ.BasisZ;
        }

        // =========================================================
        // PARÁMETROS / UTILIDADES REVIT
        // =========================================================

        private void ActivarSimbolo(Document doc, FamilySymbol symbol)
        {
            if (doc == null || symbol == null)
                return;

            if (!symbol.IsActive)
            {
                symbol.Activate();
                doc.Regenerate();
            }
        }


        private int AplicarRecorteNativoEnIntersecciones(
            Document doc,
            List<FamilyInstance> perfiles,
            StringBuilder reporte)
        {
            if (doc == null || perfiles == null || perfiles.Count < 2)
                return 0;

            int aplicados = 0;
            int intentos = 0;
            int fallidos = 0;

            // Tolerancia amplia para detectar contactos entre perfiles por sección.
            // No modifica longitudes; solo decide si vale la pena intentar el recorte nativo.
            double toleranciaBounding = MetersToFeet(0.15);

            for (int i = 0; i < perfiles.Count; i++)
            {
                FamilyInstance a = perfiles[i];

                if (!EsInstanciaArmazonEstructural(a))
                    continue;

                for (int j = i + 1; j < perfiles.Count; j++)
                {
                    FamilyInstance b = perfiles[j];

                    if (!EsInstanciaArmazonEstructural(b))
                        continue;

                    if (!BoundingBoxesIntersectan(a, b, toleranciaBounding))
                        continue;

                    if (!CurvasSeCruzanOSeTocanEnProyeccion(a, b, MetersToFeet(0.08)))
                        continue;

                    FamilyInstance elementoARecortar;
                    FamilyInstance elementoCortante;
                    ElegirElementoRecorte(a, b, out elementoARecortar, out elementoCortante);

                    if (elementoARecortar == null || elementoCortante == null)
                        continue;

                    intentos++;

                    bool ok = IntentarAplicarCopingNativo(doc, elementoARecortar, elementoCortante);

                    if (ok)
                    {
                        SetDistanciaRecorteCero(elementoARecortar);
                        AjustarReduccionesJuntaCero(elementoARecortar);
                        aplicados++;
                    }
                    else
                    {
                        fallidos++;
                    }
                }
            }

            if (reporte != null)
            {
                reporte.AppendLine(
                    "Recorte nativo intersecciones | Intentos: " + intentos +
                    " | Aplicados: " + aplicados +
                    " | Fallidos/omitidos: " + fallidos);
            }

            return aplicados;
        }

        private void ElegirElementoRecorte(
            FamilyInstance a,
            FamilyInstance b,
            out FamilyInstance elementoARecortar,
            out FamilyInstance elementoCortante)
        {
            elementoARecortar = null;
            elementoCortante = null;

            int pa = PrioridadPerfilParaRecorte(a);
            int pb = PrioridadPerfilParaRecorte(b);

            // Mayor prioridad = elemento que normalmente debe pasar completo.
            // Menor prioridad = elemento que recibe el recorte.
            if (pa > pb)
            {
                elementoCortante = a;
                elementoARecortar = b;
                return;
            }

            if (pb > pa)
            {
                elementoCortante = b;
                elementoARecortar = a;
                return;
            }

            // Si tienen la misma prioridad, se recorta solo uno para evitar doble notch.
            // Se usa el Id mayor como elemento a recortar para que el criterio sea estable.
            long ida = a != null && a.Id != null ? a.Id.Value : 0;
            long idb = b != null && b.Id != null ? b.Id.Value : 0;

            if (ida > idb)
            {
                elementoARecortar = a;
                elementoCortante = b;
            }
            else
            {
                elementoARecortar = b;
                elementoCortante = a;
            }
        }

        private int PrioridadPerfilParaRecorte(FamilyInstance fi)
        {
            string tipo = ObtenerTextoParametro(fi, Form != null ? Form.ParametroTipo : "MYG_Tipo_Elemento");
            string t = Normalizar(tipo);

            if (t.Contains("MARCO"))
                return 300;

            if (t.Contains("PRINCIPAL"))
                return 200;

            if (t.Contains("SECUNDARIO"))
                return 100;

            return 50;
        }

        private string ObtenerTextoParametro(Element elemento, string nombreParametro)
        {
            if (elemento == null || string.IsNullOrWhiteSpace(nombreParametro))
                return "";

            Parameter p = BuscarParametro(elemento, nombreParametro);

            if (p == null)
                return "";

            try
            {
                if (p.StorageType == StorageType.String)
                    return p.AsString() ?? "";

                if (p.StorageType == StorageType.Integer)
                    return p.AsInteger().ToString();

                if (p.StorageType == StorageType.Double)
                    return FeetToMeters(p.AsDouble()).ToString("0.###");

                if (p.StorageType == StorageType.ElementId)
                    return p.AsElementId().Value.ToString();
            }
            catch
            {
            }

            return "";
        }

        private bool IntentarAplicarCopingNativo(
            Document doc,
            FamilyInstance elementoARecortar,
            FamilyInstance elementoCortante)
        {
            if (doc == null || elementoARecortar == null || elementoCortante == null)
                return false;

            if (elementoARecortar.Id.Value == elementoCortante.Id.Value)
                return false;

            try
            {
                if (YaTieneCopingCon(elementoARecortar, elementoCortante))
                {
                    SetDistanciaRecorteCero(elementoARecortar);
                    AjustarReduccionesJuntaCero(elementoARecortar);
                    return true;
                }
            }
            catch
            {
            }

            // V25:
            // La herramienta manual de Revit "Recorte / Coping" corresponde al método
            // de instancia de FamilyInstance: perfilARecortar.AddCoping(perfilCortador).
            // No se usa StructuralFramingUtils.AddCoping porque esa llamada no representa
            // la herramienta manual en varias versiones de Revit.
            SetDistanciaRecorteCero(elementoARecortar);
            AjustarReduccionesJuntaCero(elementoARecortar);

            bool aplicado = InvocarAddCopingDesdeFamilyInstance(
                doc,
                elementoARecortar,
                elementoCortante);

            if (!aplicado)
                return false;

            try
            {
                doc.Regenerate();
            }
            catch
            {
            }

            SetDistanciaRecorteCero(elementoARecortar);
            AjustarReduccionesJuntaCero(elementoARecortar);

            return true;
        }

        private bool InvocarAddCopingDesdeFamilyInstance(
            Document doc,
            FamilyInstance elementoARecortar,
            FamilyInstance elementoCortante)
        {
            if (doc == null || elementoARecortar == null || elementoCortante == null)
                return false;

            try
            {
                System.Reflection.MethodInfo[] metodos = typeof(FamilyInstance).GetMethods(
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance);

                foreach (System.Reflection.MethodInfo metodo in metodos)
                {
                    if (metodo == null || metodo.Name != "AddCoping")
                        continue;

                    System.Reflection.ParameterInfo[] ps = metodo.GetParameters();
                    object[] args;

                    if (!ConstruirArgumentosAddCopingFamilyInstance(ps, doc, elementoARecortar, elementoCortante, out args))
                        continue;

                    try
                    {
                        object resultado = metodo.Invoke(elementoARecortar, args);

                        // En algunas versiones AddCoping devuelve void; en otras puede devolver bool.
                        if (metodo.ReturnType == typeof(bool))
                        {
                            bool ok = false;

                            try
                            {
                                ok = resultado != null && (bool)resultado;
                            }
                            catch
                            {
                                ok = false;
                            }

                            if (!ok)
                                continue;
                        }

                        return true;
                    }
                    catch (System.Reflection.TargetInvocationException)
                    {
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }

            return false;
        }

        private bool ConstruirArgumentosAddCopingFamilyInstance(
            System.Reflection.ParameterInfo[] parametros,
            Document doc,
            FamilyInstance elementoARecortar,
            FamilyInstance elementoCortante,
            out object[] args)
        {
            args = null;

            if (parametros == null)
                return false;

            object[] temp = new object[parametros.Length];
            bool tieneCortante = false;

            for (int i = 0; i < parametros.Length; i++)
            {
                Type pt = parametros[i].ParameterType;

                if (pt == typeof(Document))
                {
                    temp[i] = doc;
                    continue;
                }

                if (pt == typeof(FamilyInstance) || pt.IsAssignableFrom(typeof(FamilyInstance)))
                {
                    temp[i] = elementoCortante;
                    tieneCortante = true;
                    continue;
                }

                if (pt == typeof(Element) || pt.IsAssignableFrom(typeof(Element)))
                {
                    temp[i] = (Element)elementoCortante;
                    tieneCortante = true;
                    continue;
                }

                if (pt == typeof(ElementId))
                {
                    temp[i] = elementoCortante.Id;
                    tieneCortante = true;
                    continue;
                }

                if (pt == typeof(double))
                {
                    temp[i] = 0.0;
                    continue;
                }

                if (pt == typeof(int))
                {
                    temp[i] = 0;
                    continue;
                }

                if (pt == typeof(bool))
                {
                    temp[i] = false;
                    continue;
                }

                return false;
            }

            if (!tieneCortante)
                return false;

            args = temp;
            return true;
        }

        private bool YaTieneCopingCon(FamilyInstance elementoARecortar, FamilyInstance elementoCortante)
        {
            if (elementoARecortar == null || elementoCortante == null)
                return false;

            try
            {
                System.Reflection.MethodInfo[] metodos = typeof(FamilyInstance).GetMethods(
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance);

                foreach (System.Reflection.MethodInfo metodo in metodos)
                {
                    if (metodo == null)
                        continue;

                    string nombre = metodo.Name;

                    if (nombre != "GetCopingIds" &&
                        nombre != "GetCopingCuttingElementIds" &&
                        nombre != "GetCopingElementIds")
                    {
                        continue;
                    }

                    object[] args;

                    if (!ConstruirArgumentosGetCopingFamilyInstance(metodo.GetParameters(), elementoARecortar, out args))
                        continue;

                    object resultado = null;

                    try
                    {
                        resultado = metodo.Invoke(elementoARecortar, args);
                    }
                    catch
                    {
                        continue;
                    }

                    System.Collections.IEnumerable enumerable = resultado as System.Collections.IEnumerable;

                    if (enumerable == null)
                        continue;

                    foreach (object obj in enumerable)
                    {
                        ElementId id = obj as ElementId;

                        if (id != null && id.Value == elementoCortante.Id.Value)
                            return true;
                    }
                }
            }
            catch
            {
            }

            return false;
        }

        private bool ConstruirArgumentosGetCopingFamilyInstance(
            System.Reflection.ParameterInfo[] parametros,
            FamilyInstance elemento,
            out object[] args)
        {
            args = null;

            if (parametros == null || elemento == null)
                return false;

            object[] temp = new object[parametros.Length];

            for (int i = 0; i < parametros.Length; i++)
            {
                Type pt = parametros[i].ParameterType;

                if (pt == typeof(Document))
                {
                    temp[i] = elemento.Document;
                    continue;
                }

                if (pt == typeof(ElementId))
                {
                    temp[i] = elemento.Id;
                    continue;
                }

                if (pt == typeof(Element) || pt.IsAssignableFrom(typeof(Element)))
                {
                    temp[i] = (Element)elemento;
                    continue;
                }

                if (pt == typeof(FamilyInstance) || pt.IsAssignableFrom(typeof(FamilyInstance)))
                {
                    temp[i] = elemento;
                    continue;
                }

                return false;
            }

            args = temp;
            return true;
        }

        private void SetDistanciaRecorteCero(FamilyInstance fi)
        {
            if (fi == null)
                return;

            // Parámetro visible en Revit: "Distancia de recorte".
            // Si el coping ya existe, este valor controla el retiro/notch. Debe quedar en 0.
            SetParametroLongitudPorNombres(fi, 0.0,
                "Distancia de recorte",
                "Distancia recorte",
                "Coping Distance",
                "Coping distance",
                "Cope Distance",
                "Cope distance",
                "Coping Offset",
                "Cope Offset",
                "Cutback Distance",
                "Distancia de cope",
                "Distancia coping");

            InvocarSetCopingDistanceFamilyInstance(fi);
        }

        private void InvocarSetCopingDistanceFamilyInstance(FamilyInstance fi)
        {
            if (fi == null)
                return;

            try
            {
                System.Reflection.MethodInfo[] metodos = typeof(FamilyInstance).GetMethods(
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance);

                foreach (System.Reflection.MethodInfo metodo in metodos)
                {
                    if (metodo == null || metodo.Name != "SetCopingDistance")
                        continue;

                    object[] args;

                    if (!ConstruirArgumentosSetCopingDistanceFamilyInstance(metodo.GetParameters(), fi, out args))
                        continue;

                    try
                    {
                        metodo.Invoke(fi, args);
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }
        }

        private bool ConstruirArgumentosSetCopingDistanceFamilyInstance(
            System.Reflection.ParameterInfo[] parametros,
            FamilyInstance fi,
            out object[] args)
        {
            args = null;

            if (parametros == null || fi == null)
                return false;

            object[] temp = new object[parametros.Length];
            bool tieneDistancia = false;

            for (int i = 0; i < parametros.Length; i++)
            {
                Type pt = parametros[i].ParameterType;

                if (pt == typeof(Document))
                {
                    temp[i] = fi.Document;
                    continue;
                }

                if (pt == typeof(ElementId))
                {
                    temp[i] = fi.Id;
                    continue;
                }

                if (pt == typeof(Element) || pt.IsAssignableFrom(typeof(Element)))
                {
                    temp[i] = (Element)fi;
                    continue;
                }

                if (pt == typeof(FamilyInstance) || pt.IsAssignableFrom(typeof(FamilyInstance)))
                {
                    temp[i] = fi;
                    continue;
                }

                if (pt == typeof(double))
                {
                    temp[i] = 0.0;
                    tieneDistancia = true;
                    continue;
                }

                return false;
            }

            if (!tieneDistancia)
                return false;

            args = temp;
            return true;
        }

        private bool EsInstanciaArmazonEstructural(FamilyInstance fi)
        {
            if (fi == null || fi.Category == null)
                return false;

            try
            {
                if (fi.Category.Id.Value == (long)BuiltInCategory.OST_StructuralFraming)
                    return true;
            }
            catch
            {
            }

            string cat = Normalizar(fi.Category.Name);

            if (cat.Contains("ARMAZON_ESTRUCTURAL")) return true;
            if (cat.Contains("STRUCTURAL_FRAMING")) return true;
            if (cat.Contains("STRUCTURALFRAMING")) return true;

            return false;
        }

        private bool BoundingBoxesIntersectan(Element a, Element b, double tol)
        {
            if (a == null || b == null)
                return false;

            BoundingBoxXYZ ba = null;
            BoundingBoxXYZ bb = null;

            try
            {
                ba = a.get_BoundingBox(null);
                bb = b.get_BoundingBox(null);
            }
            catch
            {
                return false;
            }

            if (ba == null || bb == null)
                return false;

            if ((ba.Max.X + tol) < (bb.Min.X - tol)) return false;
            if ((bb.Max.X + tol) < (ba.Min.X - tol)) return false;
            if ((ba.Max.Y + tol) < (bb.Min.Y - tol)) return false;
            if ((bb.Max.Y + tol) < (ba.Min.Y - tol)) return false;
            if ((ba.Max.Z + tol) < (bb.Min.Z - tol)) return false;
            if ((bb.Max.Z + tol) < (ba.Min.Z - tol)) return false;

            return true;
        }

        private bool CurvasSeCruzanOSeTocanEnProyeccion(FamilyInstance a, FamilyInstance b, double tol)
        {
            Curve ca = ObtenerCurvaUbicacion(a);
            Curve cb = ObtenerCurvaUbicacion(b);

            if (ca == null || cb == null)
                return true;

            XYZ a1 = ca.GetEndPoint(0);
            XYZ a2 = ca.GetEndPoint(1);
            XYZ b1 = cb.GetEndPoint(0);
            XYZ b2 = cb.GetEndPoint(1);

            if (a1 == null || a2 == null || b1 == null || b2 == null)
                return true;

            if (Segmentos2DIntersectan(a1, a2, b1, b2, tol))
                return true;

            double d1 = DistanciaPuntoSegmento2D(a1, b1, b2);
            double d2 = DistanciaPuntoSegmento2D(a2, b1, b2);
            double d3 = DistanciaPuntoSegmento2D(b1, a1, a2);
            double d4 = DistanciaPuntoSegmento2D(b2, a1, a2);

            return Math.Min(Math.Min(d1, d2), Math.Min(d3, d4)) <= tol;
        }

        private Curve ObtenerCurvaUbicacion(Element e)
        {
            try
            {
                LocationCurve loc = e != null ? e.Location as LocationCurve : null;

                if (loc != null)
                    return loc.Curve;
            }
            catch
            {
            }

            return null;
        }

        private bool Segmentos2DIntersectan(XYZ a1, XYZ a2, XYZ b1, XYZ b2, double tol)
        {
            double x1 = a1.X;
            double y1 = a1.Y;
            double x2 = a2.X;
            double y2 = a2.Y;
            double x3 = b1.X;
            double y3 = b1.Y;
            double x4 = b2.X;
            double y4 = b2.Y;

            double den = ((x1 - x2) * (y3 - y4)) - ((y1 - y2) * (x3 - x4));

            if (Math.Abs(den) < 1e-12)
                return DistanciaSegmentoSegmento2D(a1, a2, b1, b2) <= tol;

            double px = (((x1 * y2) - (y1 * x2)) * (x3 - x4) - (x1 - x2) * ((x3 * y4) - (y3 * x4))) / den;
            double py = (((x1 * y2) - (y1 * x2)) * (y3 - y4) - (y1 - y2) * ((x3 * y4) - (y3 * x4))) / den;

            return
                px >= Math.Min(x1, x2) - tol && px <= Math.Max(x1, x2) + tol &&
                py >= Math.Min(y1, y2) - tol && py <= Math.Max(y1, y2) + tol &&
                px >= Math.Min(x3, x4) - tol && px <= Math.Max(x3, x4) + tol &&
                py >= Math.Min(y3, y4) - tol && py <= Math.Max(y3, y4) + tol;
        }

        private double DistanciaSegmentoSegmento2D(XYZ a1, XYZ a2, XYZ b1, XYZ b2)
        {
            double d1 = DistanciaPuntoSegmento2D(a1, b1, b2);
            double d2 = DistanciaPuntoSegmento2D(a2, b1, b2);
            double d3 = DistanciaPuntoSegmento2D(b1, a1, a2);
            double d4 = DistanciaPuntoSegmento2D(b2, a1, a2);
            return Math.Min(Math.Min(d1, d2), Math.Min(d3, d4));
        }

        private double DistanciaPuntoSegmento2D(XYZ p, XYZ a, XYZ b)
        {
            double vx = b.X - a.X;
            double vy = b.Y - a.Y;
            double wx = p.X - a.X;
            double wy = p.Y - a.Y;
            double c1 = (wx * vx) + (wy * vy);

            if (c1 <= 0.0)
                return Math.Sqrt((p.X - a.X) * (p.X - a.X) + (p.Y - a.Y) * (p.Y - a.Y));

            double c2 = (vx * vx) + (vy * vy);

            if (c2 <= 1e-12)
                return Math.Sqrt((p.X - a.X) * (p.X - a.X) + (p.Y - a.Y) * (p.Y - a.Y));

            if (c2 <= c1)
                return Math.Sqrt((p.X - b.X) * (p.X - b.X) + (p.Y - b.Y) * (p.Y - b.Y));

            double t = c1 / c2;
            double qx = a.X + (t * vx);
            double qy = a.Y + (t * vy);
            return Math.Sqrt((p.X - qx) * (p.X - qx) + (p.Y - qy) * (p.Y - qy));
        }

        private void AjustarReduccionesJuntaCero(FamilyInstance fi)
        {
            if (fi == null)
                return;

            // Estos parámetros son los que Revit suele usar para recortar vigas/armazones
            // en los extremos. En español aparecen como reducción de junta inicial/final.
            SetParametroLongitudPorNombres(fi, 0.0,
                "Reducción de junta inicial",
                "Reduccion de junta inicial",
                "Reducción junta inicial",
                "Reduccion junta inicial",
                "Start Join Cutback",
                "Start Extension Cutback",
                "Start Cutback",
                "Extensión inicial",
                "Extension inicial",
                "Reducción inicial",
                "Reduccion inicial");

            SetParametroLongitudPorNombres(fi, 0.0,
                "Reducción de junta final",
                "Reduccion de junta final",
                "Reducción junta final",
                "Reduccion junta final",
                "End Join Cutback",
                "End Extension Cutback",
                "End Cutback",
                "Extensión final",
                "Extension final",
                "Reducción final",
                "Reduccion final");
        }

        private void DesactivarUnionExtremosPerfil(FamilyInstance fi)
        {
            if (fi == null)
                return;

            try
            {
                StructuralFramingUtils.DisallowJoinAtEnd(fi, 0);
            }
            catch
            {
            }

            try
            {
                StructuralFramingUtils.DisallowJoinAtEnd(fi, 1);
            }
            catch
            {
            }
        }

        private void AjustarDesfasesPerfilALaCurva(FamilyInstance fi, Level nivel, XYZ p1, XYZ p2)
        {
            if (fi == null || nivel == null || p1 == null || p2 == null)
                return;

            double offset1 = p1.Z - nivel.Elevation;
            double offset2 = p2.Z - nivel.Elevation;

            // V53:
            // El perfil debe controlar su cota mediante:
            // - Desfase de nivel inicial
            // - Desfase de nivel final
            //
            // NO debe usar "Valor de desfase Z".
            // En algunas PCs/Revit en español, los nombres traducidos pueden provocar que
            // el valor de inicio/fin se escriba por error en "Valor de desfase Z".
            // Por eso primero se asignan inicio/fin y luego se fuerza SIEMPRE el desfase Z a 0.
            SetParametroLongitudPorNombres(fi, offset1,
                "Start Level Offset",
                "Start z Offset Value",
                "Start Z Offset Value",
                "Desfase de nivel inicial",
                "Desfase nivel inicial",
                "Desfase inicial",
                "Desfase de inicio",
                "Offset inicial",
                "Elevación inicial");

            SetParametroLongitudPorNombres(fi, offset2,
                "End Level Offset",
                "End z Offset Value",
                "End Z Offset Value",
                "Desfase de nivel final",
                "Desfase nivel final",
                "Desfase final",
                "Desfase de fin",
                "Offset final",
                "Elevación final");

            // Siempre al final. Esto evita que "Valor de desfase Z" herede el offset
            // inicial/final en equipos con idioma/traducción distinta.
            ForzarDesfaseZPerfilCero(fi);
        }

        private void ForzarDesfaseZPerfilCero(FamilyInstance fi)
        {
            if (fi == null)
                return;

            // Se usa búsqueda por nombres exactos y normalizados.
            // Se escriben TODOS los parámetros coincidentes, no solo el primero,
            // porque algunas familias/idiomas pueden exponer alias del mismo control.
            ForzarParametroLongitudCeroPorNombres(fi,
                "z Offset Value",
                "Z Offset Value",
                "Valor de desfase Z",
                "Valor desfase Z",
                "Desfase Z",
                "Desfase de Z",
                "Desfase en Z",
                "Offset Z",
                "Z Offset",
                "Z-Offset",
                "Valor de offset Z",
                "Valor offset Z");
        }

        private void ForzarParametroLongitudCeroPorNombres(Element elemento, params string[] nombres)
        {
            if (elemento == null || nombres == null)
                return;

            HashSet<string> objetivos = new HashSet<string>();

            foreach (string n in nombres)
            {
                if (!string.IsNullOrWhiteSpace(n))
                    objetivos.Add(Normalizar(n));
            }

            if (objetivos.Count == 0)
                return;

            try
            {
                foreach (Parameter p in elemento.Parameters)
                {
                    if (p == null || p.Definition == null || p.IsReadOnly)
                        continue;

                    string nombreParam = Normalizar(p.Definition.Name);

                    if (!objetivos.Contains(nombreParam))
                        continue;

                    try
                    {
                        if (p.StorageType == StorageType.Double)
                            p.Set(0.0);
                        else if (p.StorageType == StorageType.Integer)
                            p.Set(0);
                        else if (p.StorageType == StorageType.String)
                            p.Set("0");
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }
        }

        private void AjustarRotacionSeccionTransversalPerfil(FamilyInstance fi, XYZ p1, XYZ p2, XYZ normalPlano)
        {
            if (fi == null || p1 == null || p2 == null || normalPlano == null)
                return;

            try
            {
                XYZ ejePerfil = p2 - p1;

                if (ejePerfil == null || ejePerfil.GetLength() < 0.000001)
                    return;

                ejePerfil = ejePerfil.Normalize();

                XYZ normalObjetivo = OrientarNormalHaciaArriba(normalPlano);

                if (normalObjetivo == null || normalObjetivo.GetLength() < 0.000001)
                    return;

                normalObjetivo = normalObjetivo.Normalize();

                // Vector vertical por defecto de la sección cuando la rotación transversal está en 0.
                // Se proyecta perpendicular al eje del perfil para obtener la referencia inicial real.
                XYZ upInicial = ProyectarVectorPerpendicularAEje(XYZ.BasisZ, ejePerfil);

                if (upInicial == null || upInicial.GetLength() < 0.000001)
                    upInicial = ProyectarVectorPerpendicularAEje(XYZ.BasisY, ejePerfil);

                if (upInicial == null || upInicial.GetLength() < 0.000001)
                    return;

                upInicial = upInicial.Normalize();

                // La normal de la cara se proyecta perpendicular al eje del perfil.
                // Para perfiles longitudinales a la pendiente, esta proyección casi coincide con upInicial
                // y el ángulo resultará 0. Para perfiles transversales, toma la inclinación de la cara.
                XYZ upObjetivo = ProyectarVectorPerpendicularAEje(normalObjetivo, ejePerfil);

                if (upObjetivo == null || upObjetivo.GetLength() < 0.000001)
                    return;

                upObjetivo = upObjetivo.Normalize();

                double angulo = AnguloFirmadoAlrededorDeEje(upInicial, upObjetivo, ejePerfil);

                // V12:
                // En Revit, según la orientación interna de la familia de Armazón estructural,
                // el signo calculado puede verse invertido en el parámetro
                // "Rotación de sección transversal". Para este caso, se invierte el signo
                // para que el perfil acompañe correctamente la inclinación visual de la cara.
                angulo = -angulo;

                if (double.IsNaN(angulo) || double.IsInfinity(angulo))
                    return;

                if (Math.Abs(angulo) <= 0.0000001)
                    return;

                // Revit guarda los ángulos internamente en radianes.
                // El parámetro mostrado como "Rotación de sección transversal" es de instancia.
                SetParametroAnguloPorNombres(fi, angulo,
                    "Rotación de sección transversal",
                    "Rotacion de seccion transversal",
                    "Rotación de la sección transversal",
                    "Rotacion de la seccion transversal",
                    "Cross-Section Rotation",
                    "Cross Section Rotation",
                    "Cross-Section Rotation Angle",
                    "Rotation of Cross Section",
                    "Rotation Angle");
            }
            catch
            {
            }
        }

        private XYZ ProyectarVectorPerpendicularAEje(XYZ vector, XYZ eje)
        {
            if (vector == null || eje == null)
                return XYZ.Zero;

            if (eje.GetLength() < 0.000001)
                return XYZ.Zero;

            XYZ e = eje.Normalize();
            XYZ proyectado = vector - (e * vector.DotProduct(e));

            if (proyectado.GetLength() < 0.000001)
                return XYZ.Zero;

            return proyectado;
        }

        private double AnguloFirmadoAlrededorDeEje(XYZ desde, XYZ hasta, XYZ eje)
        {
            if (desde == null || hasta == null || eje == null)
                return 0.0;

            if (desde.GetLength() < 0.000001 || hasta.GetLength() < 0.000001 || eje.GetLength() < 0.000001)
                return 0.0;

            XYZ a = desde.Normalize();
            XYZ b = hasta.Normalize();
            XYZ e = eje.Normalize();

            double seno = e.DotProduct(a.CrossProduct(b));
            double coseno = a.DotProduct(b);

            return Math.Atan2(seno, coseno);
        }

        private bool SetParametroAnguloPorNombres(Element elemento, double valorRadianes, params string[] nombres)
        {
            if (elemento == null || nombres == null)
                return false;

            foreach (string nombre in nombres)
            {
                Parameter p = BuscarParametro(elemento, nombre);

                if (p == null || p.IsReadOnly)
                    continue;

                try
                {
                    if (p.StorageType == StorageType.Double)
                    {
                        p.Set(valorRadianes);
                        return true;
                    }

                    if (p.StorageType == StorageType.String)
                    {
                        p.Set((valorRadianes * 180.0 / Math.PI).ToString("0.###"));
                        return true;
                    }
                }
                catch
                {
                }
            }

            return false;
        }

        private double ObtenerAltoPerfil(FamilySymbol symbol)
        {
            if (symbol == null)
                return 0.0;

            double alto = LeerParametroLongitud(symbol,
                "Alto",
                "ALTURA",
                "Altura",
                "Height",
                "HEIGHT",
                "h",
                "H",
                "D");

            if (alto > MetersToFeet(0.001))
                return alto;

            return 0.0;
        }

        private double ObtenerAnchoPerfil(FamilySymbol symbol)
        {
            if (symbol == null)
                return 0.0;

            double ancho = LeerParametroLongitud(symbol,
                "Ancho",
                "ANCHO",
                "Width",
                "WIDTH",
                "b",
                "B",
                "Base",
                "BASE");

            if (ancho > MetersToFeet(0.001))
                return ancho;

            return 0.0;
        }

        private double LeerParametroLongitud(Element elemento, params string[] nombres)
        {
            if (elemento == null || nombres == null)
                return 0.0;

            foreach (string nombre in nombres)
            {
                Parameter p = BuscarParametro(elemento, nombre);

                if (p == null)
                    continue;

                try
                {
                    if (p.StorageType == StorageType.Double)
                        return p.AsDouble();

                    if (p.StorageType == StorageType.String)
                    {
                        double metros;
                        string texto = (p.AsString() ?? "").Trim().Replace(",", ".");

                        if (double.TryParse(
                            texto,
                            System.Globalization.NumberStyles.Any,
                            System.Globalization.CultureInfo.InvariantCulture,
                            out metros))
                        {
                            // Si el usuario escribió el valor como texto, se interpreta como metros.
                            return MetersToFeet(metros);
                        }
                    }
                }
                catch
                {
                }
            }

            return 0.0;
        }

        private bool SetParametroLongitudPorNombres(Element elemento, double valorFeet, params string[] nombres)
        {
            if (elemento == null || nombres == null)
                return false;

            foreach (string nombre in nombres)
            {
                if (SetParametroLongitud(elemento, nombre, valorFeet))
                    return true;
            }

            return false;
        }

        private Level ObtenerNivelMasCercano(Document doc, double z)
        {
            List<Level> niveles = new FilteredElementCollector(doc)
                .OfClass(typeof(Level))
                .Cast<Level>()
                .OrderBy(x => Math.Abs(x.Elevation - z))
                .ToList();

            return niveles.FirstOrDefault();
        }

        private bool SetParametroLongitud(Element elemento, string nombreParametro, double valorFeet)
        {
            Parameter p = BuscarParametro(elemento, nombreParametro);

            if (p == null || p.IsReadOnly)
                return false;

            try
            {
                if (p.StorageType == StorageType.Double)
                {
                    p.Set(valorFeet);
                    return true;
                }

                if (p.StorageType == StorageType.String)
                {
                    p.Set(FeetToMeters(valorFeet).ToString("0.###"));
                    return true;
                }
            }
            catch
            {
            }

            return false;
        }

        private bool SetParametroTexto(Element elemento, string nombreParametro, string valor)
        {
            Parameter p = BuscarParametro(elemento, nombreParametro);

            if (p == null || p.IsReadOnly)
                return false;

            try
            {
                if (p.StorageType == StorageType.String)
                {
                    p.Set(valor ?? "");
                    return true;
                }

                if (p.StorageType == StorageType.Integer)
                {
                    int numero;
                    if (int.TryParse(valor, out numero))
                    {
                        p.Set(numero);
                        return true;
                    }
                }

                if (p.StorageType == StorageType.ElementId)
                {
                    long numeroLong;
                    if (long.TryParse(valor, out numeroLong))
                    {
                        p.Set(new ElementId(numeroLong));
                        return true;
                    }
                }
            }
            catch
            {
            }

            return false;
        }

        private Parameter BuscarParametro(Element elemento, string nombreParametro)
        {
            if (elemento == null || string.IsNullOrWhiteSpace(nombreParametro))
                return null;

            Parameter p = elemento.LookupParameter(nombreParametro);

            if (p != null)
                return p;

            string nombreNormalizado = Normalizar(nombreParametro);

            foreach (Parameter param in elemento.Parameters)
            {
                if (param == null || param.Definition == null)
                    continue;

                if (Normalizar(param.Definition.Name) == nombreNormalizado)
                    return param;
            }

            return null;
        }

        private void Mostrar(string texto)
        {
            if (Form != null && !Form.IsDisposed)
                Form.MostrarResultado(texto);
        }

        private static double MetersToFeet(double metros)
        {
            try
            {
                return UnitUtils.ConvertToInternalUnits(metros, UnitTypeId.Meters);
            }
            catch
            {
                return metros / 0.3048;
            }
        }

        private static double FeetToMeters(double feet)
        {
            try
            {
                return UnitUtils.ConvertFromInternalUnits(feet, UnitTypeId.Meters);
            }
            catch
            {
                return feet * 0.3048;
            }
        }

        private static double Feet2ToMeters2(double feet2)
        {
            try
            {
                return UnitUtils.ConvertFromInternalUnits(feet2, UnitTypeId.SquareMeters);
            }
            catch
            {
                return feet2 * 0.09290304;
            }
        }

        private static string Normalizar(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return "";

            return texto
                .Replace('\u00A0', ' ')
                .Replace('\t', ' ')
                .Trim()
                .ToUpperInvariant()
                .Replace("Á", "A")
                .Replace("É", "E")
                .Replace("Í", "I")
                .Replace("Ó", "O")
                .Replace("Ú", "U")
                .Replace("Ñ", "N")
                .Replace("-", "_")
                .Replace("/", "_")
                .Replace(" ", "_");
        }

        // =========================================================
        // FILTROS / CLASES AUXILIARES
        // =========================================================

        internal class FiltroSeleccionLineasGuia : ISelectionFilter
        {
            public bool AllowElement(Element elem)
            {
                if (elem == null)
                    return false;

                if (elem is CurveElement)
                    return true;

                if (elem is Grid)
                    return true;

                if (elem.Location is LocationCurve)
                    return true;

                return false;
            }

            public bool AllowReference(Reference reference, XYZ position)
            {
                return false;
            }
        }

        internal class FiltroSeleccionSuperficie : ISelectionFilter
        {
            public bool AllowElement(Element elem)
            {
                return elem != null;
            }

            public bool AllowReference(Reference reference, XYZ position)
            {
                return reference != null;
            }
        }

        internal class ImpactoSuperior
        {
            public ElementId ElementId { get; set; }
            public Face Face { get; set; }
            public Reference FaceReference { get; set; }
            public XYZ Punto { get; set; }
            public XYZ FaceNormal { get; set; }
            public double DistanciaZ { get; set; }

            // Datos de soporte cuando la cara superior pertenece a un vínculo Revit.
            public bool EsDeVinculo { get; set; }
            public ElementId LinkInstanceId { get; set; }
            public ElementId LinkedElementId { get; set; }
        }

        internal class GrupoDireccionBoceto
        {
            public XYZ Direccion { get; set; }
            public XYZ VectorAcumulado { get; set; }
            public double LongitudAcumulada { get; set; }
            public int CantidadLados { get; set; }
        }

        internal class SuperficiePickada
        {
            public ElementId ElementId { get; set; }
            public string ElementUniqueId { get; set; }
            public Reference FaceReference { get; set; }
            public Face Face { get; set; }
            public PlanarFace PlanarFace { get; set; }
            public XYZ Origin { get; set; }
            public XYZ Normal { get; set; }
            public XYZ DirU { get; set; }
            public XYZ DirV { get; set; }
            public List<XYZ> PoligonoExterior3D { get; set; }
            public double AreaAproximada { get; set; }
        }

        internal class DireccionManual
        {
            public XYZ DirU { get; set; }
            public bool EsCaraGuia { get; set; }
            public bool EsLineasGuia { get; set; }
            public string Descripcion { get; set; }
        }

        internal class GuiaLineasOrtogonales
        {
            public bool Activa { get; set; }
            public XYZ PuntoLineaU { get; set; }
            public XYZ PuntoLineaV { get; set; }
            public XYZ DirUPlanta { get; set; }
            public XYZ DirVPlanta { get; set; }
            public XYZ NormalLibreUPlanta { get; set; }
            public XYZ NormalLibreVPlanta { get; set; }
            public ElementId ElementIdLineaU { get; set; }
            public ElementId ElementIdLineaV { get; set; }
            public bool EsCaraGuia { get; set; }
        }

        internal class CaraGuiaData
        {
            public ElementId ElementId { get; set; }
            public XYZ Punto { get; set; }
            public XYZ DireccionParalelaPlanta { get; set; }
            public XYZ NormalPlanta { get; set; }
        }

        internal class P2
        {
            public double X { get; set; }
            public double Y { get; set; }

            public P2(double x, double y)
            {
                X = x;
                Y = y;
            }
        }

        internal class Segmento2D
        {
            public P2 A { get; set; }
            public P2 B { get; set; }

            public Segmento2D(P2 a, P2 b)
            {
                A = a;
                B = b;
            }
        }

        internal class Linea2D
        {
            public P2 A { get; set; }
            public P2 B { get; set; }
        }

        internal class Intervalo
        {
            public double A { get; set; }
            public double B { get; set; }

            public Intervalo(double a, double b)
            {
                A = a;
                B = b;
            }
        }

        internal class DoubleComparer : IEqualityComparer<double>
        {
            private readonly double tolerancia;

            public DoubleComparer(double tolerancia)
            {
                this.tolerancia = tolerancia <= 0.0 ? 0.000001 : tolerancia;
            }

            public bool Equals(double x, double y)
            {
                return Math.Abs(x - y) <= tolerancia;
            }

            public int GetHashCode(double obj)
            {
                return Math.Round(obj / tolerancia).GetHashCode();
            }
        }

        internal class Bounding2D
        {
            public double MinX { get; set; }
            public double MaxX { get; set; }
            public double MinY { get; set; }
            public double MaxY { get; set; }

            public double Ancho
            {
                get { return MaxX - MinX; }
            }

            public double Alto
            {
                get { return MaxY - MinY; }
            }
        }
    }
}
