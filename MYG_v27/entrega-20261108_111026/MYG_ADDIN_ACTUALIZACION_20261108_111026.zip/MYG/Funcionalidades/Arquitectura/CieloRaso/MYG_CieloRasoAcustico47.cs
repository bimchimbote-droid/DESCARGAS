﻿// =====================================
// VENTANA EXTERNA 4.7 - CIELO RASO ACÚSTICO SUSPENDIDO
// Contenido embebible para MYG_CieloRasoAcustico47MainForm
// CON USING Y NAMESPACE
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using Drawing = System.Drawing;
using WinForms = System.Windows.Forms;

namespace MYG_Addin
{
    // =====================================
    // VENTANA 4.7 - CIELO RASO ACÚSTICO SUSPENDIDO - V51
    // 2 CARAS GUÍA ORTOGONALES + OFFSET SUPERIOR DE COLGADOR
    // CON USING Y NAMESPACE
    // =====================================

    public static class MYG_CieloRasoAcustico47
    {
        public enum Operacion
        {
            Ninguna = 0,
            CargarDatos = 1,
            PickarSuperficie = 2,
            PickarOrientacion = 3,
            GenerarSistema = 4,
            PickarSuperficieYGenerar = 5,
            PickarCaraGuia = 6,
            PickarDosLineasGuia = 7, // ahora picka 2 caras guía ortogonales
            UsarGuiaAutomatica = 8
        }

        public class ComboItem
        {
            public Autodesk.Revit.DB.ElementId Id { get; set; }
            public string Nombre { get; set; }

            public ComboItem()
            {
                Id = Autodesk.Revit.DB.ElementId.InvalidElementId;
                Nombre = "";
            }

            public ComboItem(Autodesk.Revit.DB.ElementId id, string nombre)
            {
                Id = id;
                Nombre = nombre;
            }

            public override string ToString()
            {
                return Nombre;
            }
        }

        public class CieloRasoAcusticoForm : System.Windows.Forms.Form
        {
            private System.Windows.Forms.ComboBox cmbPerfilPrincipal;
            private System.Windows.Forms.ComboBox cmbPerfilSecundario;
            private System.Windows.Forms.ComboBox cmbColgador;
            private System.Windows.Forms.ComboBox cmbNivelReferencia;

            private System.Windows.Forms.Button btnCargarDatos;
            private System.Windows.Forms.Button btnPickarSuperficie;
            private System.Windows.Forms.Button btnPickarCaraGuia;
            private System.Windows.Forms.Button btnPickarOrientacion;
            private System.Windows.Forms.Button btnGenerar;

            private System.Windows.Forms.TextBox txtCamaraTecnica;
            private System.Windows.Forms.TextBox txtSeparacionPrincipal;
            private System.Windows.Forms.TextBox txtSeparacionSecundario;
            private System.Windows.Forms.TextBox txtSeparacionColgador;
            private System.Windows.Forms.TextBox txtOffsetSuperiorColgador;
            private System.Windows.Forms.TextBox txtMargenPerimetral;
            private System.Windows.Forms.TextBox txtLongitudMinima;

            private System.Windows.Forms.TextBox txtParametroLongitudColgador;
            private System.Windows.Forms.TextBox txtParametroSistema;
            private System.Windows.Forms.TextBox txtParametroTipo;
            private System.Windows.Forms.TextBox txtParametroIdSuperficie;
            private System.Windows.Forms.TextBox txtParametroGenId;

            private System.Windows.Forms.CheckBox chkCrearMarco;
            private System.Windows.Forms.CheckBox chkCrearPrincipales;
            private System.Windows.Forms.CheckBox chkCrearSecundarios;
            private System.Windows.Forms.CheckBox chkCrearColgadores;
            private System.Windows.Forms.CheckBox chkProyectarPerfilesAlPerimetro;
            private System.Windows.Forms.CheckBox chkAsignarParametros;

            private System.Windows.Forms.Label lblSuperficie;
            private System.Windows.Forms.Label lblOrientacion;
            private System.Windows.Forms.RichTextBox txtResultado;

            public Autodesk.Revit.UI.ExternalEvent EjecutarEvent;
            public Operacion OperacionSolicitada { get; private set; }

            public Autodesk.Revit.DB.ElementId PerfilPrincipalId
            {
                get
                {
                    ComboItem item = cmbPerfilPrincipal.SelectedItem as ComboItem;
                    return item == null ? Autodesk.Revit.DB.ElementId.InvalidElementId : item.Id;
                }
            }

            public Autodesk.Revit.DB.ElementId PerfilSecundarioId
            {
                get
                {
                    ComboItem item = cmbPerfilSecundario.SelectedItem as ComboItem;
                    return item == null ? Autodesk.Revit.DB.ElementId.InvalidElementId : item.Id;
                }
            }

            public Autodesk.Revit.DB.ElementId ColgadorId
            {
                get
                {
                    ComboItem item = cmbColgador.SelectedItem as ComboItem;
                    return item == null ? Autodesk.Revit.DB.ElementId.InvalidElementId : item.Id;
                }
            }

            public Autodesk.Revit.DB.ElementId NivelReferenciaId
            {
                get
                {
                    ComboItem item = cmbNivelReferencia.SelectedItem as ComboItem;
                    return item == null ? Autodesk.Revit.DB.ElementId.InvalidElementId : item.Id;
                }
            }

            public double CamaraTecnicaMetros => LeerDouble(txtCamaraTecnica.Text, 0.00);
            public double SeparacionPrincipalMetros => LeerDouble(txtSeparacionPrincipal.Text, 1.20);
            public double SeparacionSecundarioMetros => LeerDouble(txtSeparacionSecundario.Text, 0.60);
            public double SeparacionColgadorMetros => LeerDouble(txtSeparacionColgador.Text, 0.00);
            public double OffsetSuperiorColgadorMetros => LeerDouble(txtOffsetSuperiorColgador.Text, 0.00);
            public double MargenPerimetralMetros => LeerDouble(txtMargenPerimetral.Text, 0.05);
            public double LongitudMinimaMetros => LeerDouble(txtLongitudMinima.Text, 0.10);

            public string ParametroLongitudColgador => ObtenerTexto(txtParametroLongitudColgador.Text, "Altura de colgador");
            public string ParametroSistema => ObtenerTexto(txtParametroSistema.Text, "MYG_Sistema");
            public string ParametroTipo => ObtenerTexto(txtParametroTipo.Text, "MYG_Tipo_Elemento");
            public string ParametroIdSuperficie => ObtenerTexto(txtParametroIdSuperficie.Text, "MYG_ID_Superficie");
            public string ParametroGenId => ObtenerTexto(txtParametroGenId.Text, "GEN_ID Elemento");

            public bool CrearMarco => chkCrearMarco.Checked;
            public bool CrearPrincipales => chkCrearPrincipales.Checked;
            public bool CrearSecundarios => chkCrearSecundarios.Checked;
            public bool CrearColgadores => chkCrearColgadores.Checked;
            public bool ProyectarPerfilesAlPerimetro => chkProyectarPerfilesAlPerimetro.Checked;
            public bool AsignarParametros => chkAsignarParametros.Checked;

            public CieloRasoAcusticoForm()
            {
                OperacionSolicitada = Operacion.Ninguna;

                this.Text = "ARQ 4.7 - Cielo Raso Acústico Suspendido";
                this.Width = 760;
                this.Height = 855;
                this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                this.TopLevel = false;
                this.ShowInTaskbar = false;
                this.MaximizeBox = false;
                this.MinimizeBox = false;
                this.Dock = System.Windows.Forms.DockStyle.Fill;
                this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
                this.Font = new System.Drawing.Font("Segoe UI", 9F);
                this.TopMost = false;

                System.Windows.Forms.Label lblAutor = new System.Windows.Forms.Label()
                {
                    Text = "Creado por: Ing. Marlon Yacila  |  ARQ - Sistema suspendido para cielo raso acústico",
                    Left = 20,
                    Top = 10,
                    Width = 700,
                    Height = 20,
                    Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                    ForeColor = System.Drawing.Color.Gray
                };

                System.Windows.Forms.Label lblTitulo01 = CrearTitulo("01. SELECCIÓN Y REFERENCIA", 20, 42, 700);

                // En esta versión, el pick de superficie se hace desde el botón principal inferior.
                // La cara guía permite alinear los perfiles principales con luminarias/equipos existentes.
                btnPickarCaraGuia = CrearBoton("PICKAR 2 CARAS", 20, 72, 170, System.Drawing.Color.FromArgb(90, 90, 90));
                btnPickarOrientacion = CrearBoton("USAR GUÍA AUTOMÁTICA", 205, 72, 215, System.Drawing.Color.FromArgb(90, 90, 90));
                btnCargarDatos = CrearBoton("RECARGAR DATOS", 435, 72, 160, System.Drawing.Color.FromArgb(90, 90, 90));

                lblSuperficie = new System.Windows.Forms.Label()
                {
                    Text = "Superficie activa: no seleccionada.",
                    Left = 20,
                    Top = 112,
                    Width = 700,
                    Height = 20,
                    Font = new System.Drawing.Font("Segoe UI", 8.5F),
                    ForeColor = System.Drawing.Color.FromArgb(130, 60, 60)
                };

                lblOrientacion = new System.Windows.Forms.Label()
                {
                    Text = "Orientación: automática según la cara seleccionada.",
                    Left = 20,
                    Top = 134,
                    Width = 700,
                    Height = 20,
                    Font = new System.Drawing.Font("Segoe UI", 8.5F),
                    ForeColor = System.Drawing.Color.FromArgb(90, 90, 90)
                };

                System.Windows.Forms.Label lblTitulo02 = CrearTitulo("02. FAMILIAS Y NIVEL", 20, 166, 700);

                System.Windows.Forms.Label lblPerfilPrincipal = CrearLabel("Perfil principal / Canal C:", 20, 202, 185);
                cmbPerfilPrincipal = CrearCombo(210, 198, 510);

                System.Windows.Forms.Label lblPerfilSecundario = CrearLabel("Perfil secundario / Omega:", 20, 237, 185);
                cmbPerfilSecundario = CrearCombo(210, 233, 510);

                System.Windows.Forms.Label lblColgador = CrearLabel("Colgador / varilla roscada:", 20, 272, 185);
                cmbColgador = CrearCombo(210, 268, 510);

                System.Windows.Forms.Label lblNivel = CrearLabel("Nivel referencia perfiles:", 20, 307, 185);
                cmbNivelReferencia = CrearCombo(210, 303, 300);
                cmbNivelReferencia.Enabled = false;

                System.Windows.Forms.Label lblTitulo03 = CrearTitulo("03. DIMENSIONES DEL SISTEMA", 20, 346, 700);

                System.Windows.Forms.Label lblCamara = CrearLabel("Desfase base perfiles/perímetro sobre cara (m):", 20, 382, 220);
                txtCamaraTecnica = CrearTextBox("0.00", 245, 379, 80);

                System.Windows.Forms.Label lblSepPrin = CrearLabel("Sep. perfil principal (m):", 355, 382, 180);
                txtSeparacionPrincipal = CrearTextBox("1.20", 640, 379, 80);

                System.Windows.Forms.Label lblSepSec = CrearLabel("Sep. perfil secundario (m):", 20, 417, 220);
                txtSeparacionSecundario = CrearTextBox("0.60", 245, 414, 80);

                System.Windows.Forms.Label lblSepColg = CrearLabel("Sep. colgadores automática = 2 x secundaria:", 355, 417, 270);
                txtSeparacionColgador = CrearTextBox("Auto", 640, 414, 80);
                txtSeparacionColgador.ReadOnly = true;
                txtSeparacionColgador.BackColor = System.Drawing.Color.FromArgb(235, 235, 235);

                System.Windows.Forms.Label lblMargen = CrearLabel("Margen perimetral (m):", 20, 452, 220);
                txtMargenPerimetral = CrearTextBox("0.05", 245, 449, 80);

                System.Windows.Forms.Label lblLongMin = CrearLabel("Long. mín. perfil (m):", 355, 452, 150);
                txtLongitudMinima = CrearTextBox("0.10", 505, 449, 70);

                System.Windows.Forms.Label lblOffsetSupColgador = CrearLabel("Offset sup. colg. (m):", 585, 452, 120);
                txtOffsetSuperiorColgador = CrearTextBox("0.00", 705, 449, 55);

                chkCrearMarco = CrearCheck("Crear marco perimetral con perfil principal", 20, 486, 340, true);
                chkCrearPrincipales = CrearCheck("Crear perfiles principales", 20, 512, 250, true);
                chkCrearSecundarios = CrearCheck("Crear perfiles secundarios", 300, 512, 250, true);
                chkCrearColgadores = CrearCheck("Crear colgadores", 560, 512, 160, true);
                chkProyectarPerfilesAlPerimetro = CrearCheck("Proyectar perfiles internos hasta el perímetro", 20, 540, 430, true);

                System.Windows.Forms.Label lblTitulo04 = CrearTitulo("04. PARÁMETROS A ASIGNAR", 20, 582, 700);

                chkAsignarParametros = CrearCheck("Asignar parámetros MYG a elementos creados", 20, 611, 360, true);

                System.Windows.Forms.Label lblParamLong = CrearLabel("Longitud colgador:", 20, 646, 135);
                txtParametroLongitudColgador = CrearTextBox("Altura de colgador", 155, 643, 205);

                System.Windows.Forms.Label lblParamSistema = CrearLabel("Sistema:", 385, 646, 75);
                txtParametroSistema = CrearTextBox("MYG_Sistema", 465, 643, 255);

                System.Windows.Forms.Label lblParamTipo = CrearLabel("Tipo elemento:", 20, 681, 135);
                txtParametroTipo = CrearTextBox("MYG_Tipo_Elemento", 155, 678, 205);

                System.Windows.Forms.Label lblParamIdSup = CrearLabel("ID superficie:", 385, 681, 90);
                txtParametroIdSuperficie = CrearTextBox("MYG_ID_Superficie", 465, 678, 255);

                System.Windows.Forms.Label lblParamGenId = CrearLabel("GEN ID:", 20, 716, 135);
                txtParametroGenId = CrearTextBox("GEN_ID Elemento", 155, 713, 205);

                txtResultado = new System.Windows.Forms.RichTextBox()
                {
                    Left = 385,
                    Top = 713,
                    Width = 335,
                    Height = 70,
                    ReadOnly = true,
                    BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                    BackColor = System.Drawing.Color.White,
                    Font = new System.Drawing.Font("Consolas", 8.5F),
                    WordWrap = false,
                    ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
                };

                btnGenerar = CrearBoton("PICKAR SUPERFICIE Y GENERAR", 200, 794, 350, System.Drawing.Color.FromArgb(0, 120, 215));
                btnGenerar.Height = 38;

                btnCargarDatos.Click += (s, e) => Ejecutar(Operacion.CargarDatos);
                btnPickarCaraGuia.Click += (s, e) => Ejecutar(Operacion.PickarDosLineasGuia);
                btnPickarOrientacion.Click += (s, e) => Ejecutar(Operacion.UsarGuiaAutomatica);
                btnGenerar.Click += (s, e) => Ejecutar(Operacion.PickarSuperficieYGenerar);

                Controls.Add(lblAutor);
                Controls.Add(lblTitulo01);
                Controls.Add(btnPickarCaraGuia);
                Controls.Add(btnPickarOrientacion);
                Controls.Add(btnCargarDatos);
                Controls.Add(lblSuperficie);
                Controls.Add(lblOrientacion);
                Controls.Add(lblTitulo02);
                Controls.Add(lblPerfilPrincipal);
                Controls.Add(cmbPerfilPrincipal);
                Controls.Add(lblPerfilSecundario);
                Controls.Add(cmbPerfilSecundario);
                Controls.Add(lblColgador);
                Controls.Add(cmbColgador);
                Controls.Add(lblNivel);
                Controls.Add(cmbNivelReferencia);
                Controls.Add(lblTitulo03);
                Controls.Add(lblCamara);
                Controls.Add(txtCamaraTecnica);
                Controls.Add(lblSepPrin);
                Controls.Add(txtSeparacionPrincipal);
                Controls.Add(lblSepSec);
                Controls.Add(txtSeparacionSecundario);
                Controls.Add(lblSepColg);
                Controls.Add(txtSeparacionColgador);
                Controls.Add(lblMargen);
                Controls.Add(txtMargenPerimetral);
                Controls.Add(lblLongMin);
                Controls.Add(txtLongitudMinima);
                Controls.Add(lblOffsetSupColgador);
                Controls.Add(txtOffsetSuperiorColgador);
                Controls.Add(chkCrearMarco);
                Controls.Add(chkCrearPrincipales);
                Controls.Add(chkCrearSecundarios);
                Controls.Add(chkCrearColgadores);
                Controls.Add(chkProyectarPerfilesAlPerimetro);
                Controls.Add(lblTitulo04);
                Controls.Add(chkAsignarParametros);
                Controls.Add(lblParamLong);
                Controls.Add(txtParametroLongitudColgador);
                Controls.Add(lblParamSistema);
                Controls.Add(txtParametroSistema);
                Controls.Add(lblParamTipo);
                Controls.Add(txtParametroTipo);
                Controls.Add(lblParamIdSup);
                Controls.Add(txtParametroIdSuperficie);
                Controls.Add(lblParamGenId);
                Controls.Add(txtParametroGenId);
                Controls.Add(txtResultado);
                Controls.Add(btnGenerar);

                MostrarResultado("Carga datos. Opcionalmente picka 2 caras guía ortogonales; luego usa PICKAR SUPERFICIE Y GENERAR.");
            }

            private System.Windows.Forms.Label CrearTitulo(string texto, int left, int top, int width)
            {
                return new System.Windows.Forms.Label()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 22,
                    Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold),
                    ForeColor = System.Drawing.Color.FromArgb(50, 50, 50)
                };
            }

            private System.Windows.Forms.Label CrearLabel(string texto, int left, int top, int width)
            {
                return new System.Windows.Forms.Label()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 22
                };
            }

            private System.Windows.Forms.ComboBox CrearCombo(int left, int top, int width)
            {
                return new System.Windows.Forms.ComboBox()
                {
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 25,
                    DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
                };
            }

            private System.Windows.Forms.TextBox CrearTextBox(string texto, int left, int top, int width)
            {
                return new System.Windows.Forms.TextBox()
                {
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 24,
                    Text = texto,
                    BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
                };
            }

            private System.Windows.Forms.CheckBox CrearCheck(string texto, int left, int top, int width, bool check)
            {
                return new System.Windows.Forms.CheckBox()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 24,
                    Checked = check
                };
            }

            private System.Windows.Forms.Button CrearBoton(string texto, int left, int top, int width, System.Drawing.Color color)
            {
                System.Windows.Forms.Button boton = new System.Windows.Forms.Button()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 32,
                    BackColor = color,
                    ForeColor = System.Drawing.Color.White,
                    FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                    Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold),
                    Cursor = System.Windows.Forms.Cursors.Hand
                };

                boton.FlatAppearance.BorderSize = 0;
                boton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(
                    System.Math.Max(color.R - 15, 0),
                    System.Math.Max(color.G - 15, 0),
                    System.Math.Max(color.B - 15, 0));

                return boton;
            }

            public void SolicitarCargaInicial()
            {
                Ejecutar(Operacion.CargarDatos);
            }

            private void Ejecutar(Operacion operacion)
            {
                OperacionSolicitada = operacion;

                if (EjecutarEvent == null)
                {
                    MostrarResultado("No se pudo crear el evento externo de Revit.");
                    return;
                }

                EjecutarEvent.Raise();
            }

            internal void SetCatalogos(
                System.Collections.Generic.List<ComboItem> perfiles,
                System.Collections.Generic.List<ComboItem> colgadores,
                System.Collections.Generic.List<ComboItem> niveles)
            {
                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() => SetCatalogos(perfiles, colgadores, niveles)));
                    return;
                }

                cmbPerfilPrincipal.Items.Clear();
                cmbPerfilSecundario.Items.Clear();
                cmbColgador.Items.Clear();
                cmbNivelReferencia.Items.Clear();

                if (perfiles != null)
                {
                    foreach (ComboItem item in perfiles)
                    {
                        cmbPerfilPrincipal.Items.Add(item);
                        cmbPerfilSecundario.Items.Add(item);
                    }
                }

                if (colgadores != null)
                {
                    foreach (ComboItem item in colgadores)
                        cmbColgador.Items.Add(item);
                }

                if (niveles != null)
                {
                    foreach (ComboItem item in niveles)
                        cmbNivelReferencia.Items.Add(item);
                }

                if (cmbPerfilPrincipal.Items.Count > 0)
                    cmbPerfilPrincipal.SelectedIndex = 0;

                if (cmbPerfilSecundario.Items.Count > 0)
                    cmbPerfilSecundario.SelectedIndex = cmbPerfilSecundario.Items.Count > 1 ? 1 : 0;

                if (cmbColgador.Items.Count > 0)
                    cmbColgador.SelectedIndex = 0;

                if (cmbNivelReferencia.Items.Count > 0)
                    cmbNivelReferencia.SelectedIndex = 0;

                MostrarResultado(
                    "Datos cargados.\r\n" +
                    "Perfiles: " + cmbPerfilPrincipal.Items.Count + "\r\n" +
                    "Colgadores: " + cmbColgador.Items.Count + "\r\n" +
                    "Niveles disponibles para detección automática: " + cmbNivelReferencia.Items.Count);
            }

            internal void SetSuperficieSeleccionada(string texto)
            {
                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() => SetSuperficieSeleccionada(texto)));
                    return;
                }

                lblSuperficie.Text = string.IsNullOrWhiteSpace(texto)
                    ? "Superficie activa: seleccionada."
                    : texto;

                lblSuperficie.ForeColor = System.Drawing.Color.FromArgb(0, 100, 180);

                MostrarResultado("Superficie pickada correctamente. Principal/perimetral quedan en la base; secundarios se elevan por Alto del principal; colgadores se elevan por Alto del secundario y buscan la cara superior más cercana.");
            }

            internal void SetOrientacionManual(string texto)
            {
                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() => SetOrientacionManual(texto)));
                    return;
                }

                lblOrientacion.Text = string.IsNullOrWhiteSpace(texto)
                    ? "Orientación: manual activa."
                    : texto;

                lblOrientacion.ForeColor = System.Drawing.Color.FromArgb(0, 100, 180);

                MostrarResultado("Orientación manual registrada. Los perfiles principales seguirán esa dirección.");
            }
            internal void SetOrientacionCaraGuia(string texto)
            {
                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() => SetOrientacionCaraGuia(texto)));
                    return;
                }

                lblOrientacion.Text = string.IsNullOrWhiteSpace(texto)
                    ? "Orientación: cara guía activa."
                    : texto;

                lblOrientacion.ForeColor = System.Drawing.Color.FromArgb(0, 100, 180);

                MostrarResultado("Guía registrada. Se usarán las 2 caras guía ortogonales como ejes base de la parrilla.");
            }


            internal void SetOrientacionLineasGuia(string texto)
            {
                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() => SetOrientacionLineasGuia(texto)));
                    return;
                }

                lblOrientacion.Text = string.IsNullOrWhiteSpace(texto)
                    ? "Orientación: 2 caras guía activas."
                    : texto;

                lblOrientacion.ForeColor = System.Drawing.Color.FromArgb(0, 100, 180);

                MostrarResultado("2 caras guía registradas. Al generar, se creará un perfil principal alineado a cada cara guía y el resto de la parrilla se modulará desde esas referencias.");
            }

            internal void RestaurarOrientacionAutomatica()
            {
                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(RestaurarOrientacionAutomatica));
                    return;
                }

                lblOrientacion.Text = "Orientación: automática según la cara seleccionada.";
                lblOrientacion.ForeColor = System.Drawing.Color.FromArgb(90, 90, 90);
            }

            internal void MostrarResultado(string texto)
            {
                if (txtResultado == null || txtResultado.IsDisposed)
                    return;

                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new System.Action(() => MostrarResultado(texto)));
                    return;
                }

                txtResultado.Clear();
                txtResultado.SelectionColor = System.Drawing.Color.FromArgb(50, 50, 50);
                txtResultado.AppendText(texto ?? "");
                txtResultado.SelectionStart = 0;
                txtResultado.ScrollToCaret();
            }

            private static string ObtenerTexto(string texto, string defecto)
            {
                if (string.IsNullOrWhiteSpace(texto))
                    return defecto;

                return texto.Trim();
            }

            private static double LeerDouble(string texto, double defecto)
            {
                if (string.IsNullOrWhiteSpace(texto))
                    return defecto;

                string t = texto.Trim().Replace(",", ".");
                double valor;

                if (double.TryParse(
                    t,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out valor))
                {
                    return valor;
                }

                return defecto;
            }
        }
    }

}
