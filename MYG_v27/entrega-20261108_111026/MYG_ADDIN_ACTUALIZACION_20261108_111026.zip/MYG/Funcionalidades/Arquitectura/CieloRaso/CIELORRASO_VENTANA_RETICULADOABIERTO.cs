﻿// =====================================
// VENTANA EXTERNA 4.7 - CIELO RASO RETICULADO OPEN CELL - V50
// Pestaña embebible para MYG_CieloRasoAcustico47MainForm
// CON USING Y NAMESPACE
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.IO;
using Drawing = System.Drawing;
using WinForms = System.Windows.Forms;

namespace MYG_Addin
{
    public static class MYG_CieloRasoReticulado47
    {
        public enum Operacion
        {
            Ninguna = 0,
            CargarDatos = 1,
            PickarSuperficieYGenerar = 2
        }

        public class ComboItem
        {
            public ElementId Id { get; set; }
            public string Nombre { get; set; }

            public ComboItem()
            {
                Id = ElementId.InvalidElementId;
                Nombre = "";
            }

            public ComboItem(ElementId id, string nombre)
            {
                Id = id;
                Nombre = nombre ?? "";
            }

            public override string ToString()
            {
                return Nombre;
            }
        }

        public class ReticuladoForm : WinForms.Form
        {
            private WinForms.ComboBox cmbPerfilPrincipal;
            private WinForms.ComboBox cmbPerfilSecundario;
            private WinForms.ComboBox cmbColgador;
            private WinForms.ComboBox cmbNivelReferencia;

            private WinForms.TextBox txtModuloU;
            private WinForms.TextBox txtModuloV;
            private WinForms.TextBox txtDesfasePerfil;
            private WinForms.TextBox txtMargen;
            private WinForms.TextBox txtLongitudMinima;
            private WinForms.TextBox txtSeparacionColgadores;
            private WinForms.TextBox txtParametroLongitudColgador;

            private WinForms.CheckBox chkCrearPrincipales;
            private WinForms.CheckBox chkCrearSecundarios;
            private WinForms.CheckBox chkCrearColgadores;
            private WinForms.CheckBox chkIncluirLineasBorde;
            private WinForms.CheckBox chkEliminarAnfitrion;

            private WinForms.Label lblSuperficie;
            private WinForms.RichTextBox txtResultado;
            private WinForms.Button btnCargarDatos;
            private WinForms.Button btnPickarYGenerar;

            public ExternalEvent EjecutarEvent;
            public Operacion OperacionSolicitada { get; private set; }

            private static readonly string CarpetaPreferencias = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "MYG_Addin");

            private static readonly string ArchivoPreferencias = Path.Combine(
                CarpetaPreferencias,
                "MYG_CieloRasoReticulado47.cfg");

            public ElementId PerfilPrincipalId { get { return ObtenerIdDesdeCombo(cmbPerfilPrincipal); } }
            public ElementId PerfilSecundarioId { get { return ObtenerIdDesdeCombo(cmbPerfilSecundario); } }
            public ElementId ColgadorId { get { return ObtenerIdDesdeCombo(cmbColgador); } }
            public ElementId NivelReferenciaId { get { return ObtenerIdDesdeCombo(cmbNivelReferencia); } }

            public double ModuloUMetros { get { return LeerLongitudMetros(txtModuloU, 0.80); } }
            public double ModuloVMetros { get { return LeerLongitudMetros(txtModuloV, 0.80); } }
            public double DesfasePerfilMetros { get { return LeerLongitudMetros(txtDesfasePerfil, 0.00); } }
            public double MargenMetros { get { return LeerLongitudMetros(txtMargen, 0.00); } }
            public double LongitudMinimaMetros { get { return LeerLongitudMetros(txtLongitudMinima, 0.10); } }
            public double SeparacionColgadoresMetros { get { return LeerLongitudMetros(txtSeparacionColgadores, 1.20); } }

            public string ParametroLongitudColgador
            {
                get
                {
                    return string.IsNullOrWhiteSpace(txtParametroLongitudColgador.Text)
                        ? "Altura de colgador"
                        : txtParametroLongitudColgador.Text.Trim();
                }
            }

            public bool CrearPrincipales { get { return chkCrearPrincipales.Checked; } }
            public bool CrearSecundarios { get { return chkCrearSecundarios.Checked; } }
            public bool CrearColgadores { get { return chkCrearColgadores.Checked; } }
            public bool IncluirLineasBorde { get { return chkIncluirLineasBorde.Checked; } }
            public bool EliminarAnfitrion { get { return chkEliminarAnfitrion != null && chkEliminarAnfitrion.Checked; } }

            public ReticuladoForm()
            {
                this.Text = "Cielo raso reticulado";
                this.StartPosition = WinForms.FormStartPosition.CenterScreen;
                this.FormBorderStyle = WinForms.FormBorderStyle.None;
                this.TopLevel = false;
                this.ShowInTaskbar = false;
                this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
                this.Font = new Drawing.Font("Segoe UI", 9F);
                this.Dock = WinForms.DockStyle.Fill;

                CrearInterfaz();
                CargarPreferencias();
            }

            private void CrearInterfaz()
            {
                WinForms.Label lblTitulo = new WinForms.Label()
                {
                    Text = "Creado por: Ing. Marlon Yacila  |  ARQ - Cielo raso reticulado Open Cell",
                    Left = 20,
                    Top = 18,
                    Width = 720,
                    Height = 24,
                    Font = new Drawing.Font("Segoe UI", 8.6F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(95, 95, 95)
                };
                this.Controls.Add(lblTitulo);

                CrearSeccionSeleccion();
                CrearSeccionFamilias();
                CrearSeccionDimensiones();
                CrearSeccionResultado();
                CrearBotonPrincipal();
            }

            private void CrearSeccionSeleccion()
            {
                this.Controls.Add(CrearTituloSeccion("01. SELECCIÓN Y REFERENCIA", 20, 52));

                btnCargarDatos = CrearBoton("RECARGAR DATOS", 20, 84, 160, 32);
                btnCargarDatos.Click += (s, e) => SolicitarOperacion(Operacion.CargarDatos);
                this.Controls.Add(btnCargarDatos);

                lblSuperficie = new WinForms.Label()
                {
                    Text = "Superficie activa: no seleccionada.",
                    Left = 20,
                    Top = 126,
                    Width = 710,
                    Height = 20,
                    Font = new Drawing.Font("Segoe UI", 8.2F),
                    ForeColor = Drawing.Color.FromArgb(0, 100, 180)
                };
                this.Controls.Add(lblSuperficie);

                WinForms.Label lblNota = new WinForms.Label()
                {
                    Text = "Esta pestaña crea una retícula abierta de un solo nivel, sin perfil perimetral independiente.",
                    Left = 20,
                    Top = 147,
                    Width = 720,
                    Height = 22,
                    Font = new Drawing.Font("Segoe UI", 8.2F),
                    ForeColor = Drawing.Color.Gray
                };
                this.Controls.Add(lblNota);
            }

            private void CrearSeccionFamilias()
            {
                this.Controls.Add(CrearTituloSeccion("02. FAMILIAS Y NIVEL", 20, 184));

                this.Controls.Add(CrearLabel("Perfil principal / portante:", 20, 220, 185));
                cmbPerfilPrincipal = CrearCombo(220, 216, 520);
                this.Controls.Add(cmbPerfilPrincipal);

                this.Controls.Add(CrearLabel("Perfil secundario / retícula:", 20, 252, 185));
                cmbPerfilSecundario = CrearCombo(220, 248, 520);
                this.Controls.Add(cmbPerfilSecundario);

                this.Controls.Add(CrearLabel("Colgador / varilla:", 20, 284, 185));
                cmbColgador = CrearCombo(220, 280, 520);
                this.Controls.Add(cmbColgador);

                this.Controls.Add(CrearLabel("Nivel referencia perfiles:", 20, 316, 185));
                cmbNivelReferencia = CrearCombo(220, 312, 300);
                this.Controls.Add(cmbNivelReferencia);
            }

            private void CrearSeccionDimensiones()
            {
                this.Controls.Add(CrearTituloSeccion("03. DIMENSIONES DEL RETICULADO", 20, 360));

                this.Controls.Add(CrearLabel("Módulo eje U:", 20, 396, 175));
                txtModuloU = CrearTextBox("0.80", 220, 392, 85);
                this.Controls.Add(txtModuloU);

                this.Controls.Add(CrearLabel("Módulo eje V:", 345, 396, 185));
                txtModuloV = CrearTextBox("0.80", 555, 392, 85);
                this.Controls.Add(txtModuloV);

                this.Controls.Add(CrearLabel("Desfase perfiles sobre cara:", 20, 428, 190));
                txtDesfasePerfil = CrearTextBox("0.00", 220, 424, 85);
                this.Controls.Add(txtDesfasePerfil);

                this.Controls.Add(CrearLabel("Sep. colgadores:", 345, 428, 185));
                txtSeparacionColgadores = CrearTextBox("1.20", 555, 424, 85);
                this.Controls.Add(txtSeparacionColgadores);

                this.Controls.Add(CrearLabel("Margen:", 20, 460, 175));
                txtMargen = CrearTextBox("0.00", 220, 456, 85);
                this.Controls.Add(txtMargen);

                this.Controls.Add(CrearLabel("Longitud mínima perfil:", 345, 460, 185));
                txtLongitudMinima = CrearTextBox("0.10", 555, 456, 85);
                this.Controls.Add(txtLongitudMinima);

                this.Controls.Add(CrearLabel("Parámetro longitud colgador:", 20, 492, 190));
                txtParametroLongitudColgador = CrearTextBoxPlano("Altura de colgador", 220, 488, 190);
                this.Controls.Add(txtParametroLongitudColgador);

                chkCrearPrincipales = CrearCheck("Crear perfiles principales", 20, 528, true, 230);
                chkCrearSecundarios = CrearCheck("Crear perfiles secundarios", 270, 528, true, 230);
                chkCrearColgadores = CrearCheck("Crear colgadores", 520, 528, true, 180);
                chkIncluirLineasBorde = CrearCheck("Incluir líneas de borde de la retícula", 20, 556, true, 320);
                chkEliminarAnfitrion = CrearCheck("Eliminar elemento anfitrión de la cara seleccionada", 20, 584, false, 420);

                this.Controls.Add(chkCrearPrincipales);
                this.Controls.Add(chkCrearSecundarios);
                this.Controls.Add(chkCrearColgadores);
                this.Controls.Add(chkIncluirLineasBorde);
                this.Controls.Add(chkEliminarAnfitrion);
            }

            private void CrearSeccionResultado()
            {
                this.Controls.Add(CrearTituloSeccion("04. REPORTE", 20, 620));

                txtResultado = new WinForms.RichTextBox()
                {
                    Left = 20,
                    Top = 652,
                    Width = 720,
                    Height = 125,
                    ReadOnly = true,
                    BorderStyle = WinForms.BorderStyle.FixedSingle,
                    BackColor = Drawing.Color.White,
                    Font = new Drawing.Font("Consolas", 8.3F),
                    Text = "Esperando datos..."
                };

                this.Controls.Add(txtResultado);
            }

            private void CrearBotonPrincipal()
            {
                btnPickarYGenerar = new WinForms.Button()
                {
                    Text = "PICKAR SUPERFICIE Y GENERAR RETICULADO",
                    Left = 180,
                    Top = 794,
                    Width = 420,
                    Height = 38,
                    FlatStyle = WinForms.FlatStyle.Flat,
                    BackColor = Drawing.Color.FromArgb(0, 122, 204),
                    ForeColor = Drawing.Color.White,
                    Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                    Cursor = WinForms.Cursors.Hand
                };
                btnPickarYGenerar.FlatAppearance.BorderSize = 0;
                btnPickarYGenerar.Click += (s, e) => SolicitarOperacion(Operacion.PickarSuperficieYGenerar);
                this.Controls.Add(btnPickarYGenerar);
            }

            private WinForms.ComboBox CrearCombo(int left, int top, int width)
            {
                WinForms.ComboBox cmb = new WinForms.ComboBox()
                {
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 26,
                    DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                    AutoCompleteMode = WinForms.AutoCompleteMode.SuggestAppend,
                    AutoCompleteSource = WinForms.AutoCompleteSource.ListItems
                };

                cmb.Leave += (s, e) => GuardarPreferencias();
                cmb.SelectedIndexChanged += (s, e) => GuardarPreferencias();
                return cmb;
            }

            private WinForms.TextBox CrearTextBox(string texto, int left, int top, int width)
            {
                WinForms.TextBox txt = CrearTextBoxPlano(texto, left, top, width);
                txt.Leave += (s, e) => NormalizarTextBoxLongitud(txt);
                return txt;
            }

            private WinForms.TextBox CrearTextBoxPlano(string texto, int left, int top, int width)
            {
                WinForms.TextBox txt = new WinForms.TextBox()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 24,
                    BorderStyle = WinForms.BorderStyle.FixedSingle
                };

                txt.Leave += (s, e) => GuardarPreferencias();
                return txt;
            }

            private WinForms.Label CrearLabel(string texto, int left, int top, int width)
            {
                return new WinForms.Label()
                {
                    Text = texto,
                    Left = left,
                    Top = top + 4,
                    Width = width,
                    Height = 22,
                    Font = new Drawing.Font("Segoe UI", 8.5F),
                    ForeColor = Drawing.Color.FromArgb(50, 50, 50)
                };
            }

            private WinForms.Label CrearTituloSeccion(string texto, int left, int top)
            {
                return new WinForms.Label()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = 720,
                    Height = 24,
                    Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(45, 45, 45)
                };
            }

            private WinForms.Button CrearBoton(string texto, int left, int top, int width, int height)
            {
                WinForms.Button btn = new WinForms.Button()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = height,
                    FlatStyle = WinForms.FlatStyle.Flat,
                    BackColor = Drawing.Color.FromArgb(70, 70, 70),
                    ForeColor = Drawing.Color.White,
                    Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold),
                    Cursor = WinForms.Cursors.Hand
                };
                btn.FlatAppearance.BorderSize = 0;
                return btn;
            }

            private WinForms.CheckBox CrearCheck(string texto, int left, int top, bool check, int width)
            {
                WinForms.CheckBox chk = new WinForms.CheckBox()
                {
                    Text = texto,
                    Left = left,
                    Top = top,
                    Width = width,
                    Height = 24,
                    Checked = check,
                    Font = new Drawing.Font("Segoe UI", 8.4F),
                    ForeColor = Drawing.Color.FromArgb(40, 40, 40)
                };
                chk.CheckedChanged += (s, e) => GuardarPreferencias();
                return chk;
            }

            public void SetCatalogos(List<ComboItem> perfiles, List<ComboItem> colgadores, List<ComboItem> niveles)
            {
                string perfilPrincipalAnterior = cmbPerfilPrincipal.Text;
                string perfilSecundarioAnterior = cmbPerfilSecundario.Text;
                string colgadorAnterior = cmbColgador.Text;
                string nivelAnterior = cmbNivelReferencia.Text;

                CargarCombo(cmbPerfilPrincipal, perfiles, perfilPrincipalAnterior);
                CargarCombo(cmbPerfilSecundario, perfiles, perfilSecundarioAnterior);
                CargarCombo(cmbColgador, colgadores, colgadorAnterior);
                CargarCombo(cmbNivelReferencia, niveles, nivelAnterior);

                MostrarMensaje("Datos cargados.\nPerfiles: " + (perfiles == null ? 0 : perfiles.Count).ToString() +
                    "\nColgadores: " + (colgadores == null ? 0 : colgadores.Count).ToString() +
                    "\nNiveles: " + (niveles == null ? 0 : niveles.Count).ToString());
            }

            private void CargarCombo(WinForms.ComboBox cmb, List<ComboItem> items, string textoAnterior)
            {
                if (cmb == null)
                    return;

                cmb.BeginUpdate();
                cmb.Items.Clear();

                if (items != null)
                {
                    foreach (ComboItem item in items)
                        cmb.Items.Add(item);
                }

                cmb.EndUpdate();

                SeleccionarPorTexto(cmb, textoAnterior);

                if (cmb.SelectedIndex < 0 && cmb.Items.Count > 0 && string.IsNullOrWhiteSpace(cmb.Text))
                    cmb.SelectedIndex = 0;
            }

            private void SeleccionarPorTexto(WinForms.ComboBox cmb, string texto)
            {
                if (cmb == null || string.IsNullOrWhiteSpace(texto))
                    return;

                string t = texto.Trim();

                for (int i = 0; i < cmb.Items.Count; i++)
                {
                    string item = cmb.Items[i] == null ? "" : cmb.Items[i].ToString();
                    if (string.Equals(item.Trim(), t, StringComparison.OrdinalIgnoreCase))
                    {
                        cmb.SelectedIndex = i;
                        return;
                    }
                }

                for (int i = 0; i < cmb.Items.Count; i++)
                {
                    string item = cmb.Items[i] == null ? "" : cmb.Items[i].ToString();
                    if (item.IndexOf(t, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        cmb.SelectedIndex = i;
                        return;
                    }
                }

                cmb.Text = texto;
            }

            private ElementId ObtenerIdDesdeCombo(WinForms.ComboBox cmb)
            {
                if (cmb == null)
                    return ElementId.InvalidElementId;

                ComboItem item = cmb.SelectedItem as ComboItem;
                if (item != null)
                    return item.Id;

                string texto = (cmb.Text ?? "").Trim();
                if (string.IsNullOrWhiteSpace(texto))
                    return ElementId.InvalidElementId;

                foreach (object obj in cmb.Items)
                {
                    ComboItem ci = obj as ComboItem;
                    if (ci == null)
                        continue;

                    string nombre = ci.Nombre ?? "";
                    if (string.Equals(nombre.Trim(), texto, StringComparison.OrdinalIgnoreCase) ||
                        nombre.IndexOf(texto, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        return ci.Id;
                    }
                }

                return ElementId.InvalidElementId;
            }

            public void ActualizarSuperficie(string texto)
            {
                if (lblSuperficie != null)
                    lblSuperficie.Text = texto ?? "Superficie activa.";
            }

            public void MostrarMensaje(string texto)
            {
                if (txtResultado != null)
                    txtResultado.Text = texto ?? "";
            }

            public void SolicitarCargaInicial()
            {
                SolicitarOperacion(Operacion.CargarDatos);
            }

            private void SolicitarOperacion(Operacion op)
            {
                OperacionSolicitada = op;
                GuardarPreferencias();

                if (EjecutarEvent != null)
                    EjecutarEvent.Raise();
            }

            private void NormalizarTextBoxLongitud(WinForms.TextBox txt)
            {
                if (txt == null)
                    return;

                double valor;
                if (TryParseLongitudMetros(txt.Text, out valor))
                    txt.Text = valor.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture);

                GuardarPreferencias();
            }

            private double LeerLongitudMetros(WinForms.TextBox txt, double def)
            {
                if (txt == null)
                    return def;

                double valor;
                if (TryParseLongitudMetros(txt.Text, out valor))
                    return valor;

                return def;
            }

            public static bool TryParseLongitudMetros(string texto, out double metros)
            {
                metros = 0.0;

                if (string.IsNullOrWhiteSpace(texto))
                    return false;

                string s = texto.Trim().ToLowerInvariant();
                s = s.Replace(",", ".");
                s = s.Replace(" ", "");

                double factor = 1.0;

                if (s.EndsWith("mm"))
                {
                    factor = 0.001;
                    s = s.Substring(0, s.Length - 2);
                }
                else if (s.EndsWith("cm"))
                {
                    factor = 0.01;
                    s = s.Substring(0, s.Length - 2);
                }
                else if (s.EndsWith("m"))
                {
                    factor = 1.0;
                    s = s.Substring(0, s.Length - 1);
                }
                else if (s.EndsWith("ft"))
                {
                    factor = 0.3048;
                    s = s.Substring(0, s.Length - 2);
                }
                else if (s.EndsWith("in"))
                {
                    factor = 0.0254;
                    s = s.Substring(0, s.Length - 2);
                }
                else if (s.EndsWith("\""))
                {
                    factor = 0.0254;
                    s = s.Substring(0, s.Length - 1);
                }
                else if (s.EndsWith("'"))
                {
                    factor = 0.3048;
                    s = s.Substring(0, s.Length - 1);
                }

                double valor;
                if (!double.TryParse(s, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out valor))
                    return false;

                metros = valor * factor;
                return true;
            }

            private void GuardarPreferencias()
            {
                try
                {
                    if (!Directory.Exists(CarpetaPreferencias))
                        Directory.CreateDirectory(CarpetaPreferencias);

                    List<string> lineas = new List<string>();
                    lineas.Add("PerfilPrincipal=" + (cmbPerfilPrincipal == null ? "" : cmbPerfilPrincipal.Text));
                    lineas.Add("PerfilSecundario=" + (cmbPerfilSecundario == null ? "" : cmbPerfilSecundario.Text));
                    lineas.Add("Colgador=" + (cmbColgador == null ? "" : cmbColgador.Text));
                    lineas.Add("Nivel=" + (cmbNivelReferencia == null ? "" : cmbNivelReferencia.Text));
                    lineas.Add("ModuloU=" + (txtModuloU == null ? "" : txtModuloU.Text));
                    lineas.Add("ModuloV=" + (txtModuloV == null ? "" : txtModuloV.Text));
                    lineas.Add("Desfase=" + (txtDesfasePerfil == null ? "" : txtDesfasePerfil.Text));
                    lineas.Add("Margen=" + (txtMargen == null ? "" : txtMargen.Text));
                    lineas.Add("LongitudMinima=" + (txtLongitudMinima == null ? "" : txtLongitudMinima.Text));
                    lineas.Add("SepColgadores=" + (txtSeparacionColgadores == null ? "" : txtSeparacionColgadores.Text));
                    lineas.Add("ParamColgador=" + (txtParametroLongitudColgador == null ? "" : txtParametroLongitudColgador.Text));
                    lineas.Add("CrearPrincipales=" + CrearPrincipales.ToString());
                    lineas.Add("CrearSecundarios=" + CrearSecundarios.ToString());
                    lineas.Add("CrearColgadores=" + CrearColgadores.ToString());
                    lineas.Add("IncluirLineasBorde=" + IncluirLineasBorde.ToString());
                    lineas.Add("EliminarAnfitrion=" + EliminarAnfitrion.ToString());

                    File.WriteAllLines(ArchivoPreferencias, lineas.ToArray());
                }
                catch
                {
                }
            }

            private void CargarPreferencias()
            {
                try
                {
                    if (!File.Exists(ArchivoPreferencias))
                        return;

                    Dictionary<string, string> dic = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    foreach (string linea in File.ReadAllLines(ArchivoPreferencias))
                    {
                        if (string.IsNullOrWhiteSpace(linea))
                            continue;

                        int idx = linea.IndexOf('=');
                        if (idx <= 0)
                            continue;

                        string k = linea.Substring(0, idx).Trim();
                        string v = linea.Substring(idx + 1).Trim();
                        dic[k] = v;
                    }

                    SetText(cmbPerfilPrincipal, Valor(dic, "PerfilPrincipal"));
                    SetText(cmbPerfilSecundario, Valor(dic, "PerfilSecundario"));
                    SetText(cmbColgador, Valor(dic, "Colgador"));
                    SetText(cmbNivelReferencia, Valor(dic, "Nivel"));
                    SetText(txtModuloU, Valor(dic, "ModuloU", "0.80"));
                    SetText(txtModuloV, Valor(dic, "ModuloV", "0.80"));
                    SetText(txtDesfasePerfil, Valor(dic, "Desfase", "0.00"));
                    SetText(txtMargen, Valor(dic, "Margen", "0.00"));
                    SetText(txtLongitudMinima, Valor(dic, "LongitudMinima", "0.10"));
                    SetText(txtSeparacionColgadores, Valor(dic, "SepColgadores", "1.20"));
                    SetText(txtParametroLongitudColgador, Valor(dic, "ParamColgador", "Altura de colgador"));

                    SetCheck(chkCrearPrincipales, Valor(dic, "CrearPrincipales", "True"));
                    SetCheck(chkCrearSecundarios, Valor(dic, "CrearSecundarios", "True"));
                    SetCheck(chkCrearColgadores, Valor(dic, "CrearColgadores", "True"));
                    SetCheck(chkIncluirLineasBorde, Valor(dic, "IncluirLineasBorde", "True"));
                    SetCheck(chkEliminarAnfitrion, Valor(dic, "EliminarAnfitrion", "False"));
                }
                catch
                {
                }
            }

            private string Valor(Dictionary<string, string> dic, string key, string def = "")
            {
                if (dic == null || !dic.ContainsKey(key))
                    return def;
                return dic[key] ?? def;
            }

            private void SetText(WinForms.Control c, string texto)
            {
                if (c != null && texto != null)
                    c.Text = texto;
            }

            private void SetCheck(WinForms.CheckBox chk, string texto)
            {
                bool val;
                if (chk != null && bool.TryParse(texto, out val))
                    chk.Checked = val;
            }
        }
    }
}
