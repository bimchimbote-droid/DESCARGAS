using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{


    // =====================================
    // COMANDO 4.7 - CIELO RASO ACÚSTICO
    // V48: CREA ExternalEvent EN EL COMANDO Y PASA 3 PESTAÑAS AL MAIN
    // SIN USING NI NAMESPACE
    // =====================================

    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class MYG_CieloRasoAcusticoCommand : Autodesk.Revit.UI.IExternalCommand
    {
        public Autodesk.Revit.UI.Result Execute(
            Autodesk.Revit.UI.ExternalCommandData commandData,
            ref string message,
            Autodesk.Revit.DB.ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            Autodesk.Revit.UI.UIDocument uidoc = commandData.Application.ActiveUIDocument;

            if (uidoc == null || uidoc.Document == null)
            {
                message = "No hay documento activo.";
                return Autodesk.Revit.UI.Result.Failed;
            }

            // =========================================================
            // PESTAÑA 01 - SISTEMA SUSPENDIDO
            // =========================================================
            global::MYG_Addin.MYG_CieloRasoAcustico47.CieloRasoAcusticoForm ventanaSistema =
                new global::MYG_Addin.MYG_CieloRasoAcustico47.CieloRasoAcusticoForm();

            global::MYG_Addin.EjecutarCieloRasoAcustico47Handler handlerSistema =
                new global::MYG_Addin.EjecutarCieloRasoAcustico47Handler();

            handlerSistema.UiDoc = uidoc;
            handlerSistema.Form = ventanaSistema;

            Autodesk.Revit.UI.ExternalEvent eventoSistema =
                Autodesk.Revit.UI.ExternalEvent.Create(handlerSistema);

            ventanaSistema.EjecutarEvent = eventoSistema;

            // =========================================================
            // PESTAÑA 02 - BALDOSAS ORTOGONALES
            // =========================================================
            global::MYG_Addin.MYG_BaldosasOrtogonales47.BaldosasOrtogonalesForm ventanaBaldosas =
                new global::MYG_Addin.MYG_BaldosasOrtogonales47.BaldosasOrtogonalesForm();

            global::MYG_Addin.EjecutarBaldosasOrtogonales47Handler handlerBaldosas =
                new global::MYG_Addin.EjecutarBaldosasOrtogonales47Handler();

            handlerBaldosas.UiDoc = uidoc;
            handlerBaldosas.Form = ventanaBaldosas;

            Autodesk.Revit.UI.ExternalEvent eventoBaldosas =
                Autodesk.Revit.UI.ExternalEvent.Create(handlerBaldosas);

            ventanaBaldosas.EjecutarEvent = eventoBaldosas;

            // =========================================================
            // PESTAÑA 03 - RETICULADO OPEN CELL
            // =========================================================
            global::MYG_Addin.MYG_CieloRasoReticulado47.ReticuladoForm ventanaReticulado =
                new global::MYG_Addin.MYG_CieloRasoReticulado47.ReticuladoForm();

            global::MYG_Addin.EjecutarCieloRasoReticulado47Handler handlerReticulado =
                new global::MYG_Addin.EjecutarCieloRasoReticulado47Handler();

            handlerReticulado.UiDoc = uidoc;
            handlerReticulado.Form = ventanaReticulado;

            Autodesk.Revit.UI.ExternalEvent eventoReticulado =
                Autodesk.Revit.UI.ExternalEvent.Create(handlerReticulado);

            ventanaReticulado.EjecutarEvent = eventoReticulado;

            // =========================================================
            // MAIN CON FRANJA LATERAL
            // =========================================================
            MYG_CieloRasoAcustico47MainForm mainForm =
                new MYG_CieloRasoAcustico47MainForm(
                    uidoc,
                    ventanaSistema,
                    handlerSistema,
                    eventoSistema,
                    ventanaBaldosas,
                    handlerBaldosas,
                    eventoBaldosas,
                    ventanaReticulado,
                    handlerReticulado,
                    eventoReticulado);

            mainForm.Show();

            return Autodesk.Revit.UI.Result.Succeeded;
        }
    }

}
