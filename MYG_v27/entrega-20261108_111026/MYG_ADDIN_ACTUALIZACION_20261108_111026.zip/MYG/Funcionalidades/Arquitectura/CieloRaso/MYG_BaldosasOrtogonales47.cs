﻿// =====================================
// VENTANA EXTERNA 4.7 - BALDOSAS ORTOGONALES SIMPLES - V46
// Contenido embebible para MYG_CieloRasoAcustico47MainForm
// CON USING Y NAMESPACE
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.IO;
using Drawing = System.Drawing;
using WinForms = System.Windows.Forms;

namespace MYG_Addin
{
    public static class MYG_BaldosasOrtogonales47
    {
        public enum Operacion
        {
            Ninguna = 0,
            CargarDatos = 1,
            PickarSuperficieYGenerar = 2
        }

        public class ComboItem
        {
            public ElementId Id { get; set; }
            public string Nombre { get; set; }

            public ComboItem()
            {
                Id = ElementId.InvalidElementId;
                Nombre = "";
            }

            public ComboItem(ElementId id, string nombre)
            {
                Id = id;
                Nombre = nombre ?? "";
            }

            public override string ToString()
            {
                return Nombre;
            }
        }

        public class BaldosasOrtogonalesForm : WinForms.Form
        {
            private WinForms.ComboBox cmbPerfilInterior;
            private WinForms.ComboBox cmbPerfilPerimetral;
            private WinForms.ComboBox cmbColgador;
            private WinForms.ComboBox cmbNivelReferencia;

            private WinForms.TextBox txtLargoBaldosa;
            private WinForms.TextBox txtAnchoBaldosa;
            private WinForms.TextBox txtDesfasePerfil;
            private WinForms.TextBox txtMargenPerimetral;
            private WinForms.TextBox txtLongitudMinima;
            private WinForms.TextBox txtEspesorPerfil;
            private WinForms.TextBox txtParametroLongitudColgador;
            private WinForms.TextBox txtOffsetSuperiorColgador;

            private WinForms.CheckBox chkCrearPerimetro;
            private WinForms.CheckBox chkCrearPerfilesInteriores;
            private WinForms.CheckBox chkCrearBaldosas;
            private WinForms.CheckBox chkCrearColgadores;
            private WinForms.CheckBox chkAjustarModuloAlPerimetro;

            private WinForms.Label lblSuperficie;
            private WinForms.RichTextBox txtResultado;

            private WinForms.Button btnCargarDatos;
            private WinForms.Button btnPickarYGenerar;

            public ExternalEvent EjecutarEvent;
            public Operacion OperacionSolicitada { get; private set; }

            private static readonly string CarpetaPreferencias = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "MYG_Addin");

            private static readonly string ArchivoPreferencias = Path.Combine(
                CarpetaPreferencias,
                "MYG_BaldosasOrtogonales47.cfg");

            public ElementId PerfilInteriorId
            {
                get
                {
                    return ObtenerIdDesdeCombo(cmbPerfilInterior);
                }
            }

            public ElementId PerfilPerimetralId
            {
                get
                {
                    return ObtenerIdDesdeCombo(cmbPerfilPerimetral);
                }
            }

            public ElementId ColgadorId
            {
                get
                {
                    return ObtenerIdDesdeCombo(cmbColgador);
                }
            }

            public ElementId NivelReferenciaId
            {
                get
                {
                    return ObtenerIdDesdeCombo(cmbNivelReferencia);
                }
            }

            public double LargoBaldosaM => LeerLongitudMetros(txtLargoBaldosa, 0.60);
            public double AnchoBaldosaM => LeerLongitudMetros(txtAnchoBaldosa, 0.60);
            public double DesfasePerfilM => LeerLongitudMetros(txtDesfasePerfil, 0.00);
            public double EspesorPerfilM => LeerLongitudMetros(txtEspesorPerfil, 0.004);
            public double OffsetSuperiorColgadorM => LeerLongitudMetros(txtOffsetSuperiorColgador, 0.00);
            public string ParametroLongitudColgador => string.IsNullOrWhiteSpace(txtParametroLongitudColgador.Text) ? "Altura de colgador" : txtParametroLongitudColgador.Text.Trim();
            public double MargenPerimetralM => LeerLongitudMetros(txtMargenPerimetral, 0.00);
            public double LongitudMinimaM => LeerLongitudMetros(txtLongitudMinima, 0.10);

            public bool CrearPerimetro => chkCrearPerimetro.Checked;
            public bool CrearPerfilesInteriores => chkCrearPerfilesInteriores.Checked;
            public bool CrearBaldosas => chkCrearBaldosas.Checked;
            public bool CrearColgadores => chkCrearColgadores.Checked;
            public bool AjustarModuloAlPerimetro => chkAjustarModuloAlPerimetro.Checked;

            public BaldosasOrtogonalesForm()
            {
                this.Text = "Baldosas ortogonales";
                this.StartPosition = WinForms.FormStartPosition.CenterScreen;
                this.FormBorderStyle = WinForms.FormBorderStyle.None;
                this.TopLevel = false;
                this.ShowInTaskbar = false;
                this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
                this.Font = new Drawing.Font("Segoe UI", 9F);
                this.Dock = WinForms.DockStyle.Fill;

                CrearInterfaz();
                CargarPreferencias();
            }

            private void CrearInterfaz()
            {
                WinForms.Label lblTitulo = new WinForms.Label()
                {
                    Text = "Creado por: Ing. Marlon Yacila  |  ARQ - Baldosas ortogonales simples",
                    Left = 20,
                    Top = 18,
                    Width = 700,
                    Height = 24,
                    Font = new Drawing.Font("Segoe UI", 8.6F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(95, 95, 95)
                };

                this.Controls.Add(lblTitulo);

                CrearSeccionSeleccion();
                CrearSeccionFamilias();
                CrearSeccionDimensiones();
                CrearSeccionResultado();
                CrearBotonPrincipal();
            }

            private void CrearSeccionSeleccion()
            {
                WinForms.Label lbl = CrearTituloSeccion("01. SELECCIÓN Y REFERENCIA", 20, 52);
                this.Controls.Add(lbl);

                btnCargarDatos = CrearBoton("RECARGAR DATOS", 20, 84, 160, 32);
                btnCargarDatos.Click += (s, e) => SolicitarOperacion(Operacion.CargarDatos);
                this.Controls.Add(btnCargarDatos);

                lblSuperficie = new WinForms.Label()
                {
                    Text = "Superficie activa: no seleccionada.",
                    Left = 20,
                    Top = 126,
                    Width = 710,
                    Height = 20,
                    Font = new Drawing.Font("Segoe UI", 8.2F),
                    ForeColor = Drawing.Color.FromArgb(0, 100, 180)
                };
                this.Controls.Add(lblSuperficie);

                WinForms.Label lblNota = new WinForms.Label()
                {
                    Text = "Esta pestaña crea una parrilla ortogonal y divide el elemento seleccionado en piezas nativas de su misma categoría.",
                    Left = 20,
                    Top = 147,
                    Width = 720,
                    Height = 22,
                    Font = new Drawing.Font("Segoe UI", 8.2F),
                    ForeColor = Drawing.Color.Gray
                };
                this.Controls.Add(lblNota);
            }

            private void CrearSeccionFamilias()
            {
                this.Controls.Add(CrearTituloSeccion("02. FAMILIAS Y NIVEL", 20, 184));

                this.Controls.Add(CrearLabel("Perfil interior / principal:", 20, 220, 170));
                cmbPerfilInterior = CrearCombo(205, 216, 530);
                this.Controls.Add(cmbPerfilInterior);

                this.Controls.Add(CrearLabel("Perfil perimetral:", 20, 252, 170));
                cmbPerfilPerimetral = CrearCombo(205, 248, 530);
                this.Controls.Add(cmbPerfilPerimetral);

                this.Controls.Add(CrearLabel("Colgador / soporte:", 20, 284, 170));
                cmbColgador = CrearCombo(205, 280, 530);
                this.Controls.Add(cmbColgador);

                this.Controls.Add(CrearLabel("Nivel referencia perfiles:", 20, 316, 170));
                cmbNivelReferencia = CrearCombo(205, 312, 300);
                this.Controls.Add(cmbNivelReferencia);
            }

            private void CrearSeccionDimensiones()
            {
                this.Controls.Add(CrearTituloSeccion("03. DIMENSIONES Y DIVISIÓN", 20, 360));

                this.Controls.Add(CrearLabel("Largo baldosa / eje U:", 20, 396, 175));
                txtLargoBaldosa = CrearTextBox("0.60", 205, 392, 85);
                this.Controls.Add(txtLargoBaldosa);

                this.Controls.Add(CrearLabel("Ancho baldosa / eje V:", 330, 396, 185));
                txtAnchoBaldosa = CrearTextBox("0.60", 535, 392, 85);
                this.Controls.Add(txtAnchoBaldosa);

                this.Controls.Add(CrearLabel("Desfase perfiles sobre cara:", 20, 428, 190));
                txtDesfasePerfil = CrearTextBox("0.00", 205, 424, 85);
                this.Controls.Add(txtDesfasePerfil);

                this.Controls.Add(CrearLabel("Espesor perfil/corte:", 330, 428, 205));
                txtEspesorPerfil = CrearTextBox("0.004", 535, 424, 85);
                this.Controls.Add(txtEspesorPerfil);

                this.Controls.Add(CrearLabel("Margen perimetral:", 20, 460, 170));
                txtMargenPerimetral = CrearTextBox("0.00", 205, 456, 85);
                this.Controls.Add(txtMargenPerimetral);

                this.Controls.Add(CrearLabel("Longitud mínima perfil:", 330, 460, 180));
                txtLongitudMinima = CrearTextBox("0.10", 535, 456, 85);
                this.Controls.Add(txtLongitudMinima);

                this.Controls.Add(CrearLabel("Parámetro longitud colgador:", 20, 492, 180));
                txtParametroLongitudColgador = CrearTextBoxPlano("Altura de colgador", 205, 488, 190);
                this.Controls.Add(txtParametroLongitudColgador);

                this.Controls.Add(CrearLabel("Offset sup. colgador:", 420, 492, 165));
                txtOffsetSuperiorColgador = CrearTextBox("0.00", 585, 488, 85);
                this.Controls.Add(txtOffsetSuperiorColgador);

                chkCrearPerimetro = CrearCheck("Crear perfil perimetral", 20, 528, true, 220);
                chkCrearPerfilesInteriores = CrearCheck("Crear perfiles interiores ortogonales", 260, 528, true, 250);
                chkCrearBaldosas = CrearCheck("Dividir elemento en baldosas nativas", 520, 528, true, 230);
                chkCrearColgadores = CrearCheck("Crear colgadores en intersecciones", 20, 556, true, 280);
                chkAjustarModuloAlPerimetro = CrearCheck("Ajustar división al perímetro visible", 330, 556, true, 320);

                this.Controls.Add(chkCrearPerimetro);
                this.Controls.Add(chkCrearPerfilesInteriores);
                this.Controls.Add(chkCrearBaldosas);
                this.Controls.Add(chkCrearColgadores);
                this.Controls.Add(chkAjustarModuloAlPerimetro);
            }

            private void CrearSeccionResultado()
            {
                this.Controls.Add(CrearTituloSeccion("04. REPORTE", 20, 594));

                txtResultado = new WinForms.RichTextBox()
                {
                    Left = 20,
                    Top = 626,
                    Width = 715,
                    Height = 105,
                    ReadOnly = true,
                    BorderStyle = WinForms.BorderStyle.FixedSingle,
                    BackColor = Drawing.Color.White,
                    Font = new Drawing.Font("Consolas", 8.2F),
                    Text = "Datos no cargados."
                };

                this.Controls.Add(txtResultado);
            }

            private void CrearBotonPrincipal()
            {
                btnPickarYGenerar = new WinForms.Button()
                {
                    Text = "PICKAR SUPERFICIE Y DIVIDIR ELEMENTO",
                    Left = 180,
                    Top = 750,
                    Width = 390,
                    Height = 42,
                    FlatStyle = WinForms.FlatStyle.Flat,
                    Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                    BackColor = Drawing.Color.FromArgb(0, 120, 215),
                    ForeColor = Drawing.Color.White,
                    Cursor = WinForms.Cursors.Hand
                };

                btnPickarYGenerar.FlatAppearance.BorderSize = 0;
                btnPickarYGenerar.Click += (s, e) =>
                {
                    SolicitarOperacion(Operacion.PickarSuperficieYGenerar);
                };

                this.Controls.Add(btnPickarYGenerar);
            }

            private WinForms.Label CrearTituloSeccion(string texto, int x, int y)
            {
                return new WinForms.Label()
                {
                    Text = texto,
                    Left = x,
                    Top = y,
                    Width = 700,
                    Height = 22,
                    Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Bold),
                    ForeColor = Drawing.Color.FromArgb(45, 45, 45)
                };
            }

            private WinForms.Label CrearLabel(string texto, int x, int y, int w)
            {
                return new WinForms.Label()
                {
                    Text = texto,
                    Left = x,
                    Top = y,
                    Width = w,
                    Height = 22,
                    Font = new Drawing.Font("Segoe UI", 8.5F),
                    ForeColor = Drawing.Color.FromArgb(40, 40, 40)
                };
            }

            private WinForms.ComboBox CrearCombo(int x, int y, int w)
            {
                return new WinForms.ComboBox()
                {
                    Left = x,
                    Top = y,
                    Width = w,
                    Height = 25,
                    DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                    AutoCompleteMode = WinForms.AutoCompleteMode.SuggestAppend,
                    AutoCompleteSource = WinForms.AutoCompleteSource.ListItems,
                    IntegralHeight = false,
                    MaxDropDownItems = 15
                };
            }

            private WinForms.TextBox CrearTextBox(string texto, int x, int y, int w)
            {
                WinForms.TextBox txt = new WinForms.TextBox()
                {
                    Text = texto,
                    Left = x,
                    Top = y,
                    Width = w,
                    Height = 24,
                    BorderStyle = WinForms.BorderStyle.FixedSingle,
                    TextAlign = WinForms.HorizontalAlignment.Center
                };

                // Similar a Revit: permite escribir 4mm, 4 mm, 3.8cm, 0.038m, 1ft, 2in.
                // Al salir del campo, lo normaliza automáticamente a metros.
                txt.Leave += (s, e) => NormalizarTextBoxLongitud(txt);
                txt.KeyDown += (s, e) =>
                {
                    if (e.KeyCode == WinForms.Keys.Enter)
                    {
                        NormalizarTextBoxLongitud(txt);
                        e.SuppressKeyPress = true;
                    }
                };

                return txt;
            }

            private WinForms.TextBox CrearTextBoxPlano(string texto, int x, int y, int w)
            {
                return new WinForms.TextBox()
                {
                    Text = texto,
                    Left = x,
                    Top = y,
                    Width = w,
                    Height = 24,
                    BorderStyle = WinForms.BorderStyle.FixedSingle,
                    TextAlign = WinForms.HorizontalAlignment.Left
                };
            }

            private WinForms.CheckBox CrearCheck(string texto, int x, int y, bool valor, int w)
            {
                return new WinForms.CheckBox()
                {
                    Text = texto,
                    Left = x,
                    Top = y,
                    Width = w,
                    Height = 22,
                    Checked = valor,
                    BackColor = Drawing.Color.FromArgb(245, 247, 250),
                    Font = new Drawing.Font("Segoe UI", 8.4F)
                };
            }

            private WinForms.Button CrearBoton(string texto, int x, int y, int w, int h)
            {
                WinForms.Button btn = new WinForms.Button()
                {
                    Text = texto,
                    Left = x,
                    Top = y,
                    Width = w,
                    Height = h,
                    FlatStyle = WinForms.FlatStyle.Flat,
                    Font = new Drawing.Font("Segoe UI", 8.4F, Drawing.FontStyle.Bold),
                    BackColor = Drawing.Color.FromArgb(70, 70, 70),
                    ForeColor = Drawing.Color.White,
                    Cursor = WinForms.Cursors.Hand
                };

                btn.FlatAppearance.BorderSize = 0;
                return btn;
            }

            private void SolicitarOperacion(Operacion op)
            {
                GuardarPreferencias();
                OperacionSolicitada = op;

                if (EjecutarEvent == null)
                {
                    MostrarMensaje("No se encontró el ExternalEvent de Revit.");
                    return;
                }

                try
                {
                    EjecutarEvent.Raise();
                }
                catch (Exception ex)
                {
                    MostrarMensaje("No se pudo ejecutar la operación:\n" + ex.Message);
                }
            }

            public void SolicitarCargaInicial()
            {
                SolicitarOperacion(Operacion.CargarDatos);
            }

            internal void CargarDatosDesdeHandler(
                List<ComboItem> perfiles,
                List<ComboItem> colgadores,
                List<ComboItem> niveles)
            {
                string textoPerfilInterior = !string.IsNullOrWhiteSpace(cmbPerfilInterior.Text) ? cmbPerfilInterior.Text : LeerPreferencia("PerfilInterior");
                string textoPerfilPerimetral = !string.IsNullOrWhiteSpace(cmbPerfilPerimetral.Text) ? cmbPerfilPerimetral.Text : LeerPreferencia("PerfilPerimetral");
                string textoColgador = !string.IsNullOrWhiteSpace(cmbColgador.Text) ? cmbColgador.Text : LeerPreferencia("Colgador");
                string textoNivel = !string.IsNullOrWhiteSpace(cmbNivelReferencia.Text) ? cmbNivelReferencia.Text : LeerPreferencia("Nivel");

                cmbPerfilInterior.BeginUpdate();
                cmbPerfilPerimetral.BeginUpdate();
                cmbColgador.BeginUpdate();
                cmbNivelReferencia.BeginUpdate();

                cmbPerfilInterior.Items.Clear();
                cmbPerfilPerimetral.Items.Clear();
                cmbColgador.Items.Clear();
                cmbNivelReferencia.Items.Clear();

                if (perfiles != null)
                {
                    foreach (ComboItem p in perfiles)
                    {
                        cmbPerfilInterior.Items.Add(p);
                        cmbPerfilPerimetral.Items.Add(new ComboItem(p.Id, p.Nombre));
                    }
                }

                if (colgadores != null)
                {
                    foreach (ComboItem c in colgadores)
                        cmbColgador.Items.Add(c);
                }

                if (niveles != null)
                {
                    foreach (ComboItem n in niveles)
                        cmbNivelReferencia.Items.Add(n);
                }

                SeleccionarPorTexto(cmbPerfilInterior, textoPerfilInterior);
                SeleccionarPorTexto(cmbPerfilPerimetral, textoPerfilPerimetral);
                SeleccionarPorTexto(cmbColgador, textoColgador);
                SeleccionarPorTexto(cmbNivelReferencia, textoNivel);

                if (cmbPerfilInterior.SelectedIndex < 0 && cmbPerfilInterior.Items.Count > 0)
                    cmbPerfilInterior.SelectedIndex = 0;

                if (cmbPerfilPerimetral.SelectedIndex < 0 && cmbPerfilPerimetral.Items.Count > 0)
                    cmbPerfilPerimetral.SelectedIndex = 0;

                if (cmbColgador.SelectedIndex < 0 && cmbColgador.Items.Count > 0)
                    cmbColgador.SelectedIndex = 0;

                if (cmbNivelReferencia.SelectedIndex < 0 && cmbNivelReferencia.Items.Count > 0)
                    cmbNivelReferencia.SelectedIndex = 0;

                cmbPerfilInterior.EndUpdate();
                cmbPerfilPerimetral.EndUpdate();
                cmbColgador.EndUpdate();
                cmbNivelReferencia.EndUpdate();

                MostrarMensaje(
                    "Datos cargados.\n" +
                    "Perfiles: " + cmbPerfilInterior.Items.Count + "\n" +
                    "Colgadores: " + cmbColgador.Items.Count + "\n" +
                    "Niveles: " + cmbNivelReferencia.Items.Count);
            }

            private void SeleccionarPorTexto(WinForms.ComboBox cmb, string texto)
            {
                if (cmb == null || string.IsNullOrWhiteSpace(texto))
                    return;

                string buscado = texto.Trim();

                for (int i = 0; i < cmb.Items.Count; i++)
                {
                    ComboItem item = cmb.Items[i] as ComboItem;
                    string nombre = item != null ? item.Nombre : Convert.ToString(cmb.Items[i]);

                    if (string.Equals(nombre, buscado, StringComparison.OrdinalIgnoreCase))
                    {
                        cmb.SelectedIndex = i;
                        return;
                    }
                }

                for (int i = 0; i < cmb.Items.Count; i++)
                {
                    ComboItem item = cmb.Items[i] as ComboItem;
                    string nombre = item != null ? item.Nombre : Convert.ToString(cmb.Items[i]);

                    if (!string.IsNullOrWhiteSpace(nombre) &&
                        nombre.IndexOf(buscado, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        cmb.SelectedIndex = i;
                        return;
                    }
                }

                cmb.Text = buscado;
            }

            private ElementId ObtenerIdDesdeCombo(WinForms.ComboBox cmb)
            {
                if (cmb == null)
                    return ElementId.InvalidElementId;

                ComboItem itemSeleccionado = cmb.SelectedItem as ComboItem;
                if (itemSeleccionado != null)
                    return itemSeleccionado.Id;

                string texto = (cmb.Text ?? "").Trim();
                if (string.IsNullOrWhiteSpace(texto))
                    return ElementId.InvalidElementId;

                foreach (object obj in cmb.Items)
                {
                    ComboItem item = obj as ComboItem;
                    if (item == null)
                        continue;

                    if (string.Equals(item.Nombre, texto, StringComparison.OrdinalIgnoreCase))
                        return item.Id;
                }

                foreach (object obj in cmb.Items)
                {
                    ComboItem item = obj as ComboItem;
                    if (item == null || string.IsNullOrWhiteSpace(item.Nombre))
                        continue;

                    if (item.Nombre.IndexOf(texto, StringComparison.OrdinalIgnoreCase) >= 0)
                        return item.Id;
                }

                return ElementId.InvalidElementId;
            }

            private void CargarPreferencias()
            {
                try
                {
                    string v;

                    v = LeerPreferencia("PerfilInterior");
                    if (!string.IsNullOrWhiteSpace(v)) cmbPerfilInterior.Text = v;

                    v = LeerPreferencia("PerfilPerimetral");
                    if (!string.IsNullOrWhiteSpace(v)) cmbPerfilPerimetral.Text = v;

                    v = LeerPreferencia("Colgador");
                    if (!string.IsNullOrWhiteSpace(v)) cmbColgador.Text = v;

                    v = LeerPreferencia("Nivel");
                    if (!string.IsNullOrWhiteSpace(v)) cmbNivelReferencia.Text = v;

                    v = LeerPreferencia("ParametroLongitudColgador");
                    if (!string.IsNullOrWhiteSpace(v)) txtParametroLongitudColgador.Text = v;

                    v = LeerPreferencia("OffsetSuperiorColgador");
                    if (!string.IsNullOrWhiteSpace(v)) txtOffsetSuperiorColgador.Text = v;
                }
                catch
                {
                }
            }

            private void GuardarPreferencias()
            {
                try
                {
                    if (!Directory.Exists(CarpetaPreferencias))
                        Directory.CreateDirectory(CarpetaPreferencias);

                    List<string> lineas = new List<string>();
                    lineas.Add("PerfilInterior=" + (cmbPerfilInterior.Text ?? ""));
                    lineas.Add("PerfilPerimetral=" + (cmbPerfilPerimetral.Text ?? ""));
                    lineas.Add("Colgador=" + (cmbColgador.Text ?? ""));
                    lineas.Add("Nivel=" + (cmbNivelReferencia.Text ?? ""));
                    lineas.Add("ParametroLongitudColgador=" + (txtParametroLongitudColgador.Text ?? ""));
                    lineas.Add("OffsetSuperiorColgador=" + (txtOffsetSuperiorColgador.Text ?? ""));

                    File.WriteAllLines(ArchivoPreferencias, lineas.ToArray());
                }
                catch
                {
                }
            }

            private string LeerPreferencia(string clave)
            {
                try
                {
                    if (string.IsNullOrWhiteSpace(clave))
                        return "";

                    if (!File.Exists(ArchivoPreferencias))
                        return "";

                    foreach (string linea in File.ReadAllLines(ArchivoPreferencias))
                    {
                        if (string.IsNullOrWhiteSpace(linea))
                            continue;

                        int i = linea.IndexOf('=');
                        if (i <= 0)
                            continue;

                        string k = linea.Substring(0, i).Trim();
                        string v = linea.Substring(i + 1);

                        if (string.Equals(k, clave, StringComparison.OrdinalIgnoreCase))
                            return v;
                    }
                }
                catch
                {
                }

                return "";
            }

            internal void ActualizarSuperficie(string texto)
            {
                if (lblSuperficie != null)
                    lblSuperficie.Text = texto ?? "Superficie activa: no seleccionada.";
            }

            internal void MostrarMensaje(string mensaje)
            {
                if (txtResultado == null)
                    return;

                txtResultado.Text = mensaje ?? "";
            }

            internal void MostrarVentanaDespuesDePick()
            {
                try
                {
                    this.Show();
                    this.Activate();
                    this.BringToFront();
                }
                catch
                {
                }
            }

            internal void OcultarVentanaParaPick()
            {
                try
                {
                    this.Hide();
                }
                catch
                {
                }
            }

            private static double LeerLongitudMetros(WinForms.TextBox txt, double defecto)
            {
                if (txt == null)
                    return defecto;

                double metros;

                if (TryLeerLongitudMetros(txt.Text, out metros))
                    return metros;

                return defecto;
            }

            private static bool TryLeerLongitudMetros(string texto, out double metros)
            {
                metros = 0.0;

                if (string.IsNullOrWhiteSpace(texto))
                    return false;

                string s = texto.Trim().ToLowerInvariant();
                s = s.Replace(",", ".");
                s = s.Replace(" ", "");

                double factor = 1.0; // Sin unidad = metros, igual que antes.

                string[] mm = new string[] { "milimetros", "milímetro", "milimetro", "milímetros", "mm" };
                string[] cm = new string[] { "centimetros", "centímetro", "centimetro", "centímetros", "cm" };
                string[] m = new string[] { "metros", "metro", "mts", "mt", "m" };
                string[] ft = new string[] { "feet", "foot", "pies", "pie", "ft", "'" };
                string[] inch = new string[] { "pulgadas", "pulgada", "pulg", "inches", "inch", "in", "\"" };

                if (QuitarUnidad(ref s, mm))
                    factor = 0.001;
                else if (QuitarUnidad(ref s, cm))
                    factor = 0.01;
                else if (QuitarUnidad(ref s, m))
                    factor = 1.0;
                else if (QuitarUnidad(ref s, ft))
                    factor = 0.3048;
                else if (QuitarUnidad(ref s, inch))
                    factor = 0.0254;

                double valor;

                if (!double.TryParse(
                    s,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out valor))
                {
                    return false;
                }

                metros = valor * factor;
                return !double.IsNaN(metros) && !double.IsInfinity(metros);
            }

            private static bool QuitarUnidad(ref string texto, string[] unidades)
            {
                if (string.IsNullOrWhiteSpace(texto) || unidades == null)
                    return false;

                foreach (string unidad in unidades)
                {
                    if (string.IsNullOrWhiteSpace(unidad))
                        continue;

                    if (texto.EndsWith(unidad, StringComparison.OrdinalIgnoreCase))
                    {
                        texto = texto.Substring(0, texto.Length - unidad.Length);
                        return true;
                    }
                }

                return false;
            }

            private void NormalizarTextBoxLongitud(WinForms.TextBox txt)
            {
                if (txt == null)
                    return;

                double metros;

                if (!TryLeerLongitudMetros(txt.Text, out metros))
                    return;

                txt.Text = metros.ToString(
                    "0.#####",
                    System.Globalization.CultureInfo.InvariantCulture);
            }
        }
    }
}
