﻿// =====================================
// HANDLER EXTERNO 4.7 - CIELO RASO RETICULADO OPEN CELL - V50
// Crea retícula abierta de un solo nivel SIN perfil perimetral independiente
// CON USING Y NAMESPACE
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_Addin
{
    public class EjecutarCieloRasoReticulado47Handler : IExternalEventHandler
    {
        public UIDocument UiDoc;
        public MYG_CieloRasoReticulado47.ReticuladoForm Form;

        private const double Tol = 1e-7;

        private class P2
        {
            public double X;
            public double Y;

            public P2(double x, double y)
            {
                X = x;
                Y = y;
            }
        }

        private class Segmento2D
        {
            public P2 A;
            public P2 B;
            public string Tipo;

            public Segmento2D(P2 a, P2 b, string tipo)
            {
                A = a;
                B = b;
                Tipo = tipo;
            }
        }

        private class SuperficieData
        {
            public Element Elemento;
            public ElementId ElementId;
            public Face Face;
            public PlanarFace PlanarFace;
            public XYZ Origin;
            public XYZ Normal;
            public XYZ DirU;
            public XYZ DirV;
            public List<XYZ> Contorno3D;
            public double Area;
        }

        private class ImpactoSuperior
        {
            public XYZ Punto;
            public Reference FaceReference;
            public Face Face;
            public XYZ FaceNormal;
            public bool EsDeVinculo;
        }

        private class FiltroCara : ISelectionFilter
        {
            public bool AllowElement(Element elem)
            {
                return elem != null;
            }

            public bool AllowReference(Reference reference, XYZ position)
            {
                return reference != null;
            }
        }

        public string GetName()
        {
            return "MYG - Cielo raso reticulado Open Cell";
        }

        public void Execute(UIApplication app)
        {
            UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

            if (uidoc == null || uidoc.Document == null || Form == null || Form.IsDisposed)
                return;

            Document doc = uidoc.Document;

            try
            {
                switch (Form.OperacionSolicitada)
                {
                    case MYG_CieloRasoReticulado47.Operacion.CargarDatos:
                        CargarDatos(doc);
                        break;

                    case MYG_CieloRasoReticulado47.Operacion.PickarSuperficieYGenerar:
                        PickarSuperficieYGenerar(doc);
                        break;
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                Form.MostrarMensaje("Operación cancelada por el usuario.");
            }
            catch (Exception ex)
            {
                Form.MostrarMensaje("ERROR GENERAL:\n" + ex.Message);
            }
        }

        private void CargarDatos(Document doc)
        {
            List<MYG_CieloRasoReticulado47.ComboItem> perfiles = ObtenerPerfilesEstructurales(doc);
            List<MYG_CieloRasoReticulado47.ComboItem> colgadores = ObtenerColgadoresModeloGenerico(doc);
            List<MYG_CieloRasoReticulado47.ComboItem> niveles = ObtenerNiveles(doc);

            Form.SetCatalogos(perfiles, colgadores, niveles);
        }

        private List<MYG_CieloRasoReticulado47.ComboItem> ObtenerPerfilesEstructurales(Document doc)
        {
            return new FilteredElementCollector(doc)
                .OfClass(typeof(FamilySymbol))
                .Cast<FamilySymbol>()
                .Where(x => x != null && x.Category != null && EsCategoria(x.Category, BuiltInCategory.OST_StructuralFraming))
                .OrderBy(x => x.Family != null ? x.Family.Name : "")
                .ThenBy(x => x.Name)
                .Select(x => new MYG_CieloRasoReticulado47.ComboItem(
                    x.Id,
                    (x.Family != null ? x.Family.Name : "") + " : " + x.Name + "  [" + x.Category.Name + "]"))
                .ToList();
        }

        private List<MYG_CieloRasoReticulado47.ComboItem> ObtenerColgadoresModeloGenerico(Document doc)
        {
            List<FamilySymbol> todos = new FilteredElementCollector(doc)
                .OfClass(typeof(FamilySymbol))
                .Cast<FamilySymbol>()
                .Where(x => x != null && x.Category != null && EsCategoria(x.Category, BuiltInCategory.OST_GenericModel))
                .ToList();

            List<FamilySymbol> candidatos = todos
                .Where(x => EsFamiliaCandidataColgador(x))
                .ToList();

            if (candidatos.Count == 0)
                candidatos = todos;

            return candidatos
                .OrderBy(x => x.Family != null ? x.Family.Name : "")
                .ThenBy(x => x.Name)
                .Select(x => new MYG_CieloRasoReticulado47.ComboItem(
                    x.Id,
                    (x.Family != null ? x.Family.Name : "") + " : " + x.Name + "  [" + x.Category.Name + "]"))
                .ToList();
        }

        private List<MYG_CieloRasoReticulado47.ComboItem> ObtenerNiveles(Document doc)
        {
            return new FilteredElementCollector(doc)
                .OfClass(typeof(Level))
                .Cast<Level>()
                .OrderBy(x => x.Elevation)
                .Select(x => new MYG_CieloRasoReticulado47.ComboItem(
                    x.Id,
                    x.Name + " | Elev.: " + UnitUtils.ConvertFromInternalUnits(x.Elevation, UnitTypeId.Meters).ToString("0.###") + " m"))
                .ToList();
        }

        private bool EsCategoria(Category cat, BuiltInCategory bic)
        {
            if (cat == null)
                return false;

            try
            {
                return cat.Id.Value == (long)bic;
            }
            catch
            {
                return false;
            }
        }

        private bool EsFamiliaCandidataColgador(FamilySymbol fs)
        {
            if (fs == null)
                return false;

            string texto = Normalizar(
                (fs.Family != null ? fs.Family.Name : "") + " " +
                fs.Name + " " +
                (fs.Category != null ? fs.Category.Name : ""));

            return texto.Contains("COLGADOR") ||
                   texto.Contains("HANGER") ||
                   texto.Contains("VARILLA") ||
                   texto.Contains("ROSCADA") ||
                   texto.Contains("SOPORTE") ||
                   texto.Contains("SUSPENDIDO") ||
                   texto.Contains("ANCLAJE");
        }

        private void PickarSuperficieYGenerar(Document doc)
        {
            bool estabaVisible = Form != null && Form.Visible;

            try
            {
                if (Form != null && !Form.IsDisposed)
                    Form.Hide();

                Reference referencia = UiDoc.Selection.PickObject(
                    ObjectType.Face,
                    new FiltroCara(),
                    "Picka la cara base del cielo raso reticulado Open Cell");

                if (referencia == null)
                    return;

                SuperficieData superficie = LeerSuperficie(doc, referencia);

                if (superficie == null || superficie.Contorno3D == null || superficie.Contorno3D.Count < 3)
                {
                    Form.MostrarMensaje("No se pudo leer una cara plana válida.");
                    return;
                }

                GenerarReticulado(doc, superficie);
            }
            finally
            {
                try
                {
                    if (estabaVisible && Form != null && !Form.IsDisposed)
                        Form.Show();
                }
                catch
                {
                }
            }
        }

        private SuperficieData LeerSuperficie(Document doc, Reference referencia)
        {
            if (doc == null || referencia == null)
                return null;

            Element elemento = doc.GetElement(referencia.ElementId);

            if (elemento == null)
                return null;

            GeometryObject obj = elemento.GetGeometryObjectFromReference(referencia);
            PlanarFace pf = obj as PlanarFace;

            if (pf == null)
                throw new InvalidOperationException("La cara seleccionada debe ser plana.");

            XYZ normal = pf.FaceNormal;

            if (normal == null || normal.GetLength() <= Tol)
                throw new InvalidOperationException("No se pudo obtener la normal de la cara seleccionada.");

            normal = normal.Normalize();

            XYZ dirU = ObtenerDireccionDominanteDelBoceto(pf, normal);

            if (dirU == null || dirU.GetLength() <= Tol)
                dirU = ProyectarEnPlano(XYZ.BasisX, normal);

            if (dirU == null || dirU.GetLength() <= Tol)
                dirU = ProyectarEnPlano(XYZ.BasisY, normal);

            if (dirU == null || dirU.GetLength() <= Tol)
                dirU = XYZ.BasisX;

            dirU = dirU.Normalize();

            XYZ dirV = normal.CrossProduct(dirU);

            if (dirV == null || dirV.GetLength() <= Tol)
                dirV = XYZ.BasisY;

            dirV = dirV.Normalize();

            List<XYZ> contorno = ObtenerLoopExterior(pf, pf.Origin, dirU, dirV);

            if (contorno == null || contorno.Count < 3)
                throw new InvalidOperationException("No se pudo obtener el contorno exterior de la cara.");

            SuperficieData data = new SuperficieData();
            data.Elemento = elemento;
            data.ElementId = elemento.Id;
            data.Face = pf;
            data.PlanarFace = pf;
            data.Origin = pf.Origin;
            data.Normal = normal;
            data.DirU = dirU;
            data.DirV = dirV;
            data.Contorno3D = contorno;
            data.Area = pf.Area;
            return data;
        }

        private void GenerarReticulado(Document doc, SuperficieData superficie)
        {
            if (doc == null || superficie == null)
                return;

            FamilySymbol perfilPrincipal = doc.GetElement(Form.PerfilPrincipalId) as FamilySymbol;
            FamilySymbol perfilSecundario = doc.GetElement(Form.PerfilSecundarioId) as FamilySymbol;
            FamilySymbol colgador = doc.GetElement(Form.ColgadorId) as FamilySymbol;

            if (Form.CrearPrincipales && perfilPrincipal == null)
            {
                Form.MostrarMensaje("Seleccione el perfil principal / portante.");
                return;
            }

            if (Form.CrearSecundarios && perfilSecundario == null)
            {
                Form.MostrarMensaje("Seleccione el perfil secundario / retícula.");
                return;
            }

            if (Form.CrearColgadores && colgador == null)
            {
                Form.MostrarMensaje("Seleccione el colgador / varilla.");
                return;
            }

            double moduloU = ToInternal(Form.ModuloUMetros);
            double moduloV = ToInternal(Form.ModuloVMetros);
            double desfase = ToInternal(Form.DesfasePerfilMetros);
            double margen = ToInternal(Form.MargenMetros);
            double longitudMinima = ToInternal(Form.LongitudMinimaMetros);
            double sepColgadores = ToInternal(Form.SeparacionColgadoresMetros);

            if (moduloU <= M(0.02) || moduloV <= M(0.02))
            {
                Form.MostrarMensaje("Los módulos U y V deben ser mayores a 0.02 m.");
                return;
            }

            if (sepColgadores <= M(0.05))
                sepColgadores = M(1.20);

            XYZ normal = OrientarNormalHaciaArriba(superficie.Normal);
            XYZ dirU = superficie.DirU;
            XYZ dirV = superficie.DirV;
            XYZ origen = superficie.Origin;

            List<P2> poligono = ProyectarPoligono(superficie.Contorno3D, origen, dirU, dirV);

            if (poligono == null || poligono.Count < 3)
            {
                Form.MostrarMensaje("No se pudo proyectar el contorno de la cara.");
                return;
            }

            if (Area(poligono) < 0.0)
                poligono.Reverse();

            double minX = poligono.Min(p => p.X) + margen;
            double maxX = poligono.Max(p => p.X) - margen;
            double minY = poligono.Min(p => p.Y) + margen;
            double maxY = poligono.Max(p => p.Y) - margen;

            if (maxX <= minX || maxY <= minY)
            {
                Form.MostrarMensaje("El margen deja sin área útil al reticulado.");
                return;
            }

            Level nivel = ObtenerNivelMasCercano(doc, origen.Z);

            if (nivel == null)
            {
                Form.MostrarMensaje("No se pudo detectar un nivel de referencia.");
                return;
            }

            List<double> xs = GenerarValoresGrid(minX, maxX, moduloU, Form.IncluirLineasBorde);
            List<double> ys = GenerarValoresGrid(minY, maxY, moduloV, Form.IncluirLineasBorde);

            List<Segmento2D> segmentosU = new List<Segmento2D>();
            List<Segmento2D> segmentosV = new List<Segmento2D>();

            foreach (double y in ys)
                segmentosU.AddRange(IntersectarHorizontal(poligono, y, longitudMinima, "Perfil principal / portante"));

            foreach (double x in xs)
                segmentosV.AddRange(IntersectarVertical(poligono, x, longitudMinima, "Perfil secundario / retícula"));

            int creadosU = 0;
            int creadosV = 0;
            int colgadoresCreados = 0;
            int omitidos = 0;
            int anfitrionesEliminados = 0;
            string mensajeEliminarAnfitrion = "";
            bool eliminarAnfitrion = Form.EliminarAnfitrion;
            List<Element> elementosCreados = new List<Element>();

            double altoPrincipal = ObtenerAltoPerfil(perfilPrincipal);
            double altoSecundario = ObtenerAltoPerfil(perfilSecundario);

            // V49:
            // En el reticulado Open Cell el colgador NO debe iniciar sumando el Alto del perfil,
            // porque el perfil se modela con su línea/base en la cota de trabajo y la familia del
            // colgador debe quedar al ras del perfil.
            // Si se suma el Alto, la base del colgador queda levantada y se genera el vacío que se ve en corte.
            double altoArranqueColgador = 0.0;

            using (Transaction tx = new Transaction(doc, "MYG - Cielo raso reticulado Open Cell"))
            {
                tx.Start();

                ActivarSimbolo(doc, perfilPrincipal);
                ActivarSimbolo(doc, perfilSecundario);
                ActivarSimbolo(doc, colgador);

                doc.Regenerate();

                XYZ origenPerfil = origen.Add(normal.Multiply(desfase));

                if (Form.CrearPrincipales && perfilPrincipal != null)
                {
                    foreach (Segmento2D s in segmentosU)
                    {
                        Element e = CrearPerfil(doc, perfilPrincipal, nivel, s, origenPerfil, dirU, dirV);
                        if (e != null)
                        {
                            elementosCreados.Add(e);
                            creadosU++;
                        }
                        else
                            omitidos++;
                    }
                }

                if (Form.CrearSecundarios && perfilSecundario != null)
                {
                    foreach (Segmento2D s in segmentosV)
                    {
                        Element e = CrearPerfil(doc, perfilSecundario, nivel, s, origenPerfil, dirU, dirV);
                        if (e != null)
                        {
                            elementosCreados.Add(e);
                            creadosV++;
                        }
                        else
                            omitidos++;
                    }
                }

                if (Form.CrearColgadores && colgador != null)
                {
                    colgadoresCreados = CrearColgadores(
                        doc,
                        colgador,
                        superficie,
                        poligono,
                        origenPerfil,
                        dirU,
                        dirV,
                        xs,
                        ys,
                        sepColgadores,
                        altoArranqueColgador,
                        elementosCreados,
                        Form.ParametroLongitudColgador);
                }

                if (eliminarAnfitrion)
                {
                    anfitrionesEliminados = EliminarElementoAnfitrionSeleccionado(
                        doc,
                        superficie,
                        elementosCreados,
                        out mensajeEliminarAnfitrion);
                }

                tx.Commit();
            }

            Form.ActualizarSuperficie(
                "Superficie activa: Elemento Id " + superficie.ElementId.Value.ToString() +
                " | Área aprox.: " + UnitUtils.ConvertFromInternalUnits(superficie.Area, UnitTypeId.SquareMeters).ToString("0.###") + " m²");

            Form.MostrarMensaje(
                "PROCESO TERMINADO\n" +
                "--------------------------------\n" +
                "Tipo: reticulado Open Cell sin perfil perimetral independiente\n" +
                "Perfiles principales / portantes: " + creadosU + "\n" +
                "Perfiles secundarios / retícula: " + creadosV + "\n" +
                "Colgadores: " + colgadoresCreados + "\n" +
                "Anfitrión eliminado: " + (eliminarAnfitrion ? (anfitrionesEliminados > 0 ? "Sí" : "No") : "No solicitado") + "\n" +
                (string.IsNullOrWhiteSpace(mensajeEliminarAnfitrion) ? "" : "Detalle anfitrión: " + mensajeEliminarAnfitrion + "\n") +
                "Omitidos: " + omitidos + "\n" +
                "Módulo U: " + Form.ModuloUMetros.ToString("0.###") + " m\n" +
                "Módulo V: " + Form.ModuloVMetros.ToString("0.###") + " m\n" +
                "Desfase perfiles: " + Form.DesfasePerfilMetros.ToString("0.###") + " m\n" +
                "Alto principal detectado: " + UnitUtils.ConvertFromInternalUnits(altoPrincipal, UnitTypeId.Meters).ToString("0.###") + " m\n" +
                "Alto secundario detectado: " + UnitUtils.ConvertFromInternalUnits(altoSecundario, UnitTypeId.Meters).ToString("0.###") + " m\n" +
                "Arranque inferior colgador: cara + desfase, al ras del perfil, sin sumar Alto\n" +
                "Eliminar anfitrión de cara seleccionada: " + (eliminarAnfitrion ? "Activado" : "Desactivado") + "\n" +
                "Nota: no se crea ningún elemento de marco/perímetro independiente.");
        }

        private int EliminarElementoAnfitrionSeleccionado(
            Document doc,
            SuperficieData superficie,
            List<Element> elementosCreados,
            out string mensaje)
        {
            mensaje = "";

            if (doc == null || superficie == null || superficie.ElementId == null)
            {
                mensaje = "no se encontró elemento anfitrión.";
                return 0;
            }

            Element host = doc.GetElement(superficie.ElementId);

            if (host == null)
            {
                mensaje = "el elemento anfitrión ya no existe o no pertenece al documento activo.";
                return 0;
            }

            if (host is RevitLinkInstance)
            {
                mensaje = "no se elimina porque la cara pertenece a un vínculo Revit.";
                return 0;
            }

            try
            {
                if (host.Pinned)
                    host.Pinned = false;
            }
            catch
            {
            }

            try
            {
                ICollection<ElementId> idsBorrados = doc.Delete(host.Id);
                int cantidad = idsBorrados == null ? 0 : idsBorrados.Count;

                if (cantidad > 0)
                {
                    mensaje = "se eliminó el anfitrión Id " + superficie.ElementId.Value.ToString() +
                        " y " + cantidad.ToString() + " elemento(s) dependiente(s)/relacionado(s).";
                    return 1;
                }

                mensaje = "Revit no devolvió elementos eliminados para el anfitrión Id " + superficie.ElementId.Value.ToString() + ".";
                return 0;
            }
            catch (Exception ex)
            {
                mensaje = "no se pudo eliminar el anfitrión Id " + superficie.ElementId.Value.ToString() + ": " + ex.Message;
                return 0;
            }
        }

        private Element CrearPerfil(Document doc, FamilySymbol symbol, Level nivel, Segmento2D segmento, XYZ origen, XYZ dirU, XYZ dirV)
        {
            if (doc == null || symbol == null || nivel == null || segmento == null || segmento.A == null || segmento.B == null)
                return null;

            XYZ p1 = To3D(segmento.A, origen, dirU, dirV);
            XYZ p2 = To3D(segmento.B, origen, dirU, dirV);

            if (p1 == null || p2 == null || p1.DistanceTo(p2) <= M(0.02))
                return null;

            Line linea = Line.CreateBound(p1, p2);

            FamilyInstance fi = null;

            try
            {
                fi = doc.Create.NewFamilyInstance(linea, symbol, nivel, StructuralType.Beam);
            }
            catch
            {
                fi = null;
            }

            if (fi == null)
                return null;

            try
            {
                LocationCurve loc = fi.Location as LocationCurve;
                if (loc != null)
                    loc.Curve = linea;
            }
            catch
            {
            }

            AjustarReduccionesJuntaCero(fi);
            SetParametroTexto(fi, "MYG_Tipo_Elemento", segmento.Tipo);
            SetParametroTexto(fi, "MYG_Sistema", "Cielo raso reticulado Open Cell");
            SetParametroTexto(fi, "GEN_ID Elemento", fi.Id.Value.ToString());

            return fi;
        }

        private int CrearColgadores(
            Document doc,
            FamilySymbol symbol,
            SuperficieData superficie,
            List<P2> poligono,
            XYZ origenPerfil,
            XYZ dirU,
            XYZ dirV,
            List<double> xs,
            List<double> ys,
            double separacion,
            double altoArranqueColgador,
            List<Element> elementosCreados,
            string parametroLongitud)
        {
            if (doc == null || symbol == null || poligono == null || xs == null || ys == null)
                return 0;

            HashSet<long> idsExcluir = new HashSet<long>();

            if (superficie != null && superficie.ElementId != null)
                idsExcluir.Add(superficie.ElementId.Value);

            if (elementosCreados != null)
            {
                foreach (Element e in elementosCreados)
                {
                    if (e != null && e.Id != null)
                        idsExcluir.Add(e.Id.Value);
                }
            }

            List<P2> puntos = ObtenerPuntosColgadores(poligono, xs, ys, separacion);
            int contador = 0;

            foreach (P2 p in puntos)
            {
                try
                {
                    XYZ puntoBaseSinAlto = To3D(p, origenPerfil, dirU, dirV);

                    // V49:
                    // Se mantiene el X/Y de la intersección de la retícula y la Z de la cota del perfil.
                    // No se suma AltoPrincipal/AltoSecundario, para que la base del colgador quede al ras.
                    XYZ puntoBase = puntoBaseSinAlto.Add(XYZ.BasisZ.Multiply(altoArranqueColgador));
                    XYZ puntoBusqueda = puntoBase.Add(XYZ.BasisZ.Multiply(M(0.001)));

                    ImpactoSuperior impacto = BuscarCaraMasCercanaHaciaArriba(doc, puntoBusqueda, M(20.0), idsExcluir);

                    if (impacto == null || impacto.Punto == null)
                        continue;

                    double longitud = impacto.Punto.Z - puntoBase.Z;

                    if (longitud <= M(0.02))
                        continue;

                    FamilyInstance fi = CrearColgador(doc, symbol, impacto, puntoBase, dirU, longitud, parametroLongitud);

                    if (fi != null)
                    {
                        contador++;
                        idsExcluir.Add(fi.Id.Value);
                    }
                }
                catch
                {
                }
            }

            return contador;
        }

        private List<P2> ObtenerPuntosColgadores(List<P2> poligono, List<double> xs, List<double> ys, double separacion)
        {
            List<P2> puntos = new List<P2>();

            if (poligono == null || xs == null || ys == null || xs.Count == 0 || ys.Count == 0)
                return puntos;

            double ultimaX = double.MinValue;

            foreach (double x in xs.OrderBy(v => v))
            {
                if (ultimaX != double.MinValue && Math.Abs(x - ultimaX) < separacion - M(0.005))
                    continue;

                double ultimaY = double.MinValue;
                bool agregoEnEstaX = false;

                foreach (double y in ys.OrderBy(v => v))
                {
                    if (ultimaY != double.MinValue && Math.Abs(y - ultimaY) < separacion - M(0.005))
                        continue;

                    P2 p = new P2(x, y);

                    if (PuntoDentroPoligono(p, poligono) || PuntoCercaDelBorde(p, poligono, M(0.005)))
                    {
                        puntos.Add(p);
                        ultimaY = y;
                        agregoEnEstaX = true;
                    }
                }

                if (agregoEnEstaX)
                    ultimaX = x;
            }

            return puntos;
        }

        private FamilyInstance CrearColgador(Document doc, FamilySymbol symbol, ImpactoSuperior impacto, XYZ puntoBase, XYZ direccionReferencia, double longitud, string parametroLongitud)
        {
            if (doc == null || symbol == null || impacto == null || impacto.Punto == null || puntoBase == null)
                return null;

            FamilyInstance fi = null;
            XYZ refDir = direccionReferencia;

            if (refDir == null || refDir.GetLength() <= Tol)
                refDir = XYZ.BasisX;

            if (impacto.FaceNormal != null && impacto.FaceNormal.GetLength() > Tol)
            {
                XYZ p = ProyectarEnPlano(refDir, impacto.FaceNormal);
                if (p != null && p.GetLength() > Tol)
                    refDir = p;
            }

            if (refDir == null || refDir.GetLength() <= Tol)
                refDir = XYZ.BasisX;

            refDir = refDir.Normalize();

            try
            {
                if (impacto.FaceReference != null)
                    fi = doc.Create.NewFamilyInstance(impacto.FaceReference, impacto.Punto, refDir, symbol);
            }
            catch
            {
                fi = null;
            }

            if (fi == null && !impacto.EsDeVinculo && impacto.Face != null)
            {
                try
                {
                    fi = doc.Create.NewFamilyInstance(impacto.Face, impacto.Punto, refDir, symbol);
                }
                catch
                {
                    fi = null;
                }
            }

            if (fi == null)
            {
                try
                {
                    fi = doc.Create.NewFamilyInstance(impacto.Punto, symbol, StructuralType.NonStructural);
                }
                catch
                {
                    fi = null;
                }
            }

            if (fi == null)
                return null;

            SetParametroLongitudPorNombres(fi, longitud, parametroLongitud, "Altura de colgador", "Longitud colgador", "Longitud", "Height", "Hanger Height");
            AjustarBaseColgador(doc, fi, puntoBase);
            ForzarColgadorVertical(doc, fi, puntoBase);
            AjustarBaseColgador(doc, fi, puntoBase);
            SetParametroTexto(fi, "MYG_Tipo_Elemento", "Colgador reticulado");
            SetParametroTexto(fi, "MYG_Sistema", "Cielo raso reticulado Open Cell");
            SetParametroTexto(fi, "GEN_ID Elemento", fi.Id.Value.ToString());
            return fi;
        }

        private ImpactoSuperior BuscarCaraMasCercanaHaciaArriba(Document doc, XYZ punto, double distanciaMax, HashSet<long> idsExcluir)
        {
            if (doc == null || punto == null)
                return null;

            View3D vista3D = ObtenerVista3D(doc);

            if (vista3D == null)
                return null;

            try
            {
                ReferenceIntersector ri = new ReferenceIntersector(vista3D);
                ri.FindReferencesInRevitLinks = true;
                ri.TargetType = FindReferenceTarget.Face;

                IList<ReferenceWithContext> resultados = ri.Find(punto, XYZ.BasisZ);

                if (resultados == null || resultados.Count == 0)
                    return null;

                foreach (ReferenceWithContext rwc in resultados.OrderBy(x => x.Proximity))
                {
                    if (rwc == null || rwc.Proximity <= M(0.001) || rwc.Proximity > distanciaMax)
                        continue;

                    Reference r = rwc.GetReference();
                    if (r == null)
                        continue;

                    if (idsExcluir != null && r.ElementId != null && idsExcluir.Contains(r.ElementId.Value))
                        continue;

                    XYZ puntoImpacto = punto.Add(XYZ.BasisZ.Multiply(rwc.Proximity));

                    ImpactoSuperior imp = new ImpactoSuperior();
                    imp.Punto = puntoImpacto;
                    imp.FaceReference = r;
                    imp.Face = null;
                    imp.FaceNormal = XYZ.BasisZ;
                    imp.EsDeVinculo = r.LinkedElementId != null && r.LinkedElementId != ElementId.InvalidElementId;

                    try
                    {
                        Element e = doc.GetElement(r.ElementId);
                        if (e != null && !imp.EsDeVinculo)
                        {
                            GeometryObject go = e.GetGeometryObjectFromReference(r);
                            Face f = go as Face;
                            if (f != null)
                            {
                                imp.Face = f;
                                PlanarFace pf = f as PlanarFace;
                                if (pf != null && pf.FaceNormal != null && pf.FaceNormal.GetLength() > Tol)
                                    imp.FaceNormal = pf.FaceNormal.Normalize();
                            }
                        }
                    }
                    catch
                    {
                    }

                    return imp;
                }
            }
            catch
            {
                return null;
            }

            return null;
        }

        private View3D ObtenerVista3D(Document doc)
        {
            if (doc == null)
                return null;

            try
            {
                View3D actual = doc.ActiveView as View3D;
                if (actual != null && !actual.IsTemplate)
                    return actual;
            }
            catch
            {
            }

            return new FilteredElementCollector(doc)
                .OfClass(typeof(View3D))
                .Cast<View3D>()
                .FirstOrDefault(v => v != null && !v.IsTemplate);
        }

        private void AjustarBaseColgador(Document doc, FamilyInstance fi, XYZ puntoBase)
        {
            if (doc == null || fi == null || puntoBase == null)
                return;

            try
            {
                doc.Regenerate();
                double zActual = ObtenerZReferenciaInstancia(fi);
                double deltaZ = puntoBase.Z - zActual;

                if (Math.Abs(deltaZ) > M(0.001))
                    ElementTransformUtils.MoveElement(doc, fi.Id, new XYZ(0.0, 0.0, deltaZ));
            }
            catch
            {
            }
        }

        private void ForzarColgadorVertical(Document doc, FamilyInstance fi, XYZ puntoBase)
        {
            if (doc == null || fi == null)
                return;

            try
            {
                doc.Regenerate();
                Transform tr = fi.GetTransform();

                if (tr == null || tr.BasisZ == null || tr.BasisZ.GetLength() <= Tol)
                    return;

                XYZ ejeLocalZ = tr.BasisZ.Normalize();
                double dot = ejeLocalZ.DotProduct(XYZ.BasisZ);

                if (Math.Abs(dot) >= 0.9995)
                    return;

                XYZ objetivo = dot >= 0.0 ? XYZ.BasisZ : XYZ.BasisZ.Multiply(-1.0);
                XYZ ejeRotacion = ejeLocalZ.CrossProduct(objetivo);

                if (ejeRotacion == null || ejeRotacion.GetLength() <= Tol)
                    return;

                Line eje = Line.CreateUnbound(puntoBase, ejeRotacion.Normalize());
                double angulo = ejeLocalZ.AngleTo(objetivo);

                if (Math.Abs(angulo) > Tol)
                    ElementTransformUtils.RotateElement(doc, fi.Id, eje, angulo);
            }
            catch
            {
            }
        }

        private double ObtenerZReferenciaInstancia(FamilyInstance fi)
        {
            if (fi == null)
                return 0.0;

            try
            {
                LocationPoint lp = fi.Location as LocationPoint;
                if (lp != null && lp.Point != null)
                    return lp.Point.Z;
            }
            catch
            {
            }

            try
            {
                BoundingBoxXYZ bb = fi.get_BoundingBox(null);
                if (bb != null)
                    return bb.Min.Z;
            }
            catch
            {
            }

            return 0.0;
        }

        private double ObtenerAltoPerfil(FamilySymbol symbol)
        {
            if (symbol == null)
                return 0.0;

            return ObtenerParametroLongitud(symbol, "Alto", "Altura", "Height", "h", "H");
        }

        private double ObtenerParametroLongitud(Element e, params string[] nombres)
        {
            if (e == null || nombres == null)
                return 0.0;

            foreach (string n in nombres)
            {
                try
                {
                    Parameter p = e.LookupParameter(n);
                    if (p != null && p.StorageType == StorageType.Double)
                    {
                        double v = p.AsDouble();
                        if (v > Tol)
                            return v;
                    }
                }
                catch
                {
                }
            }

            return 0.0;
        }

        private void SetParametroLongitudPorNombres(Element e, double valor, params string[] nombres)
        {
            if (e == null || nombres == null)
                return;

            foreach (string n in nombres)
            {
                if (string.IsNullOrWhiteSpace(n))
                    continue;

                try
                {
                    Parameter p = e.LookupParameter(n);
                    if (p != null && !p.IsReadOnly && p.StorageType == StorageType.Double)
                    {
                        p.Set(valor);
                        return;
                    }
                }
                catch
                {
                }
            }
        }

        private void SetParametroTexto(Element e, string nombre, string valor)
        {
            if (e == null || string.IsNullOrWhiteSpace(nombre))
                return;

            try
            {
                Parameter p = e.LookupParameter(nombre);
                if (p != null && !p.IsReadOnly)
                {
                    if (p.StorageType == StorageType.String)
                        p.Set(valor ?? "");
                    else if (p.StorageType == StorageType.Integer)
                    {
                        int iv;
                        if (int.TryParse(valor, out iv))
                            p.Set(iv);
                    }
                }
            }
            catch
            {
            }
        }

        private void AjustarReduccionesJuntaCero(FamilyInstance fi)
        {
            if (fi == null)
                return;

            SetParametroLongitudPorNombres(fi, 0.0, "Reducción de junta inicial", "Start Join Cutback", "Start Extension", "Extensión inicial");
            SetParametroLongitudPorNombres(fi, 0.0, "Reducción de junta final", "End Join Cutback", "End Extension", "Extensión final");
            SetParametroLongitudPorNombres(fi, 0.0, "Distancia de recorte", "Coping Distance", "Cope Distance");
        }

        private void ActivarSimbolo(Document doc, FamilySymbol symbol)
        {
            if (doc == null || symbol == null)
                return;

            try
            {
                if (!symbol.IsActive)
                    symbol.Activate();
            }
            catch
            {
            }
        }

        private Level ObtenerNivelMasCercano(Document doc, double z)
        {
            return new FilteredElementCollector(doc)
                .OfClass(typeof(Level))
                .Cast<Level>()
                .OrderBy(l => Math.Abs(l.Elevation - z))
                .FirstOrDefault();
        }

        private List<double> GenerarValoresGrid(double min, double max, double paso, bool incluirBorde)
        {
            List<double> vals = new List<double>();

            if (paso <= Tol || max <= min)
                return vals;

            double inicio = incluirBorde ? min : min + paso;

            for (double v = inicio; v <= max + Tol; v += paso)
                vals.Add(Math.Min(v, max));

            if (incluirBorde && (vals.Count == 0 || Math.Abs(vals[vals.Count - 1] - max) > M(0.005)))
                vals.Add(max);

            return vals.Distinct(new DoubleComparer(M(0.001))).OrderBy(x => x).ToList();
        }

        private class DoubleComparer : IEqualityComparer<double>
        {
            private double tol;

            public DoubleComparer(double tolerancia)
            {
                tol = tolerancia;
            }

            public bool Equals(double a, double b)
            {
                return Math.Abs(a - b) <= tol;
            }

            public int GetHashCode(double obj)
            {
                return 0;
            }
        }

        private List<Segmento2D> IntersectarHorizontal(List<P2> poly, double y, double longitudMinima, string tipo)
        {
            List<double> xs = new List<double>();
            List<Segmento2D> segs = new List<Segmento2D>();

            if (poly == null || poly.Count < 3)
                return segs;

            for (int i = 0; i < poly.Count; i++)
            {
                P2 a = poly[i];
                P2 b = poly[(i + 1) % poly.Count];

                if ((a.Y <= y && b.Y > y) || (b.Y <= y && a.Y > y))
                {
                    double t = (y - a.Y) / (b.Y - a.Y);
                    xs.Add(a.X + t * (b.X - a.X));
                }
            }

            xs.Sort();

            for (int i = 0; i + 1 < xs.Count; i += 2)
            {
                double x1 = xs[i];
                double x2 = xs[i + 1];

                if (Math.Abs(x2 - x1) >= longitudMinima)
                    segs.Add(new Segmento2D(new P2(x1, y), new P2(x2, y), tipo));
            }

            return segs;
        }

        private List<Segmento2D> IntersectarVertical(List<P2> poly, double x, double longitudMinima, string tipo)
        {
            List<double> ys = new List<double>();
            List<Segmento2D> segs = new List<Segmento2D>();

            if (poly == null || poly.Count < 3)
                return segs;

            for (int i = 0; i < poly.Count; i++)
            {
                P2 a = poly[i];
                P2 b = poly[(i + 1) % poly.Count];

                if ((a.X <= x && b.X > x) || (b.X <= x && a.X > x))
                {
                    double t = (x - a.X) / (b.X - a.X);
                    ys.Add(a.Y + t * (b.Y - a.Y));
                }
            }

            ys.Sort();

            for (int i = 0; i + 1 < ys.Count; i += 2)
            {
                double y1 = ys[i];
                double y2 = ys[i + 1];

                if (Math.Abs(y2 - y1) >= longitudMinima)
                    segs.Add(new Segmento2D(new P2(x, y1), new P2(x, y2), tipo));
            }

            return segs;
        }

        private bool PuntoDentroPoligono(P2 p, List<P2> poly)
        {
            if (p == null || poly == null || poly.Count < 3)
                return false;

            bool dentro = false;
            int j = poly.Count - 1;

            for (int i = 0; i < poly.Count; i++)
            {
                P2 pi = poly[i];
                P2 pj = poly[j];

                bool cruza = ((pi.Y > p.Y) != (pj.Y > p.Y)) &&
                              (p.X < (pj.X - pi.X) * (p.Y - pi.Y) / (((pj.Y - pi.Y) == 0.0) ? Tol : (pj.Y - pi.Y)) + pi.X);

                if (cruza)
                    dentro = !dentro;

                j = i;
            }

            return dentro;
        }

        private bool PuntoCercaDelBorde(P2 p, List<P2> poly, double tol)
        {
            if (p == null || poly == null)
                return false;

            for (int i = 0; i < poly.Count; i++)
            {
                P2 a = poly[i];
                P2 b = poly[(i + 1) % poly.Count];

                if (DistanciaPuntoSegmento(p, a, b) <= tol)
                    return true;
            }

            return false;
        }

        private double DistanciaPuntoSegmento(P2 p, P2 a, P2 b)
        {
            double vx = b.X - a.X;
            double vy = b.Y - a.Y;
            double wx = p.X - a.X;
            double wy = p.Y - a.Y;
            double c1 = wx * vx + wy * vy;

            if (c1 <= 0.0)
                return Distancia(p, a);

            double c2 = vx * vx + vy * vy;

            if (c2 <= Tol)
                return Distancia(p, a);

            if (c1 >= c2)
                return Distancia(p, b);

            double t = c1 / c2;
            P2 q = new P2(a.X + t * vx, a.Y + t * vy);
            return Distancia(p, q);
        }

        private double Distancia(P2 a, P2 b)
        {
            double dx = a.X - b.X;
            double dy = a.Y - b.Y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

        private List<XYZ> ObtenerLoopExterior(PlanarFace face, XYZ origen, XYZ dirU, XYZ dirV)
        {
            IList<CurveLoop> loops = face.GetEdgesAsCurveLoops();
            List<XYZ> mejor = null;
            double mejorArea = 0.0;

            if (loops == null)
                return null;

            foreach (CurveLoop loop in loops)
            {
                List<XYZ> pts = new List<XYZ>();

                foreach (Curve c in loop)
                {
                    if (c == null)
                        continue;

                    IList<XYZ> tess = c.Tessellate();
                    if (tess == null)
                        continue;

                    foreach (XYZ p in tess)
                        AgregarPuntoUnico(pts, p, M(0.001));
                }

                if (pts.Count > 2 && pts[0].DistanceTo(pts[pts.Count - 1]) <= M(0.001))
                    pts.RemoveAt(pts.Count - 1);

                if (pts.Count < 3)
                    continue;

                double area = Math.Abs(Area(ProyectarPoligono(pts, origen, dirU, dirV)));

                if (area > mejorArea)
                {
                    mejorArea = area;
                    mejor = pts;
                }
            }

            return mejor;
        }

        private void AgregarPuntoUnico(List<XYZ> pts, XYZ p, double tol)
        {
            if (pts == null || p == null)
                return;

            if (pts.Count == 0 || pts[pts.Count - 1].DistanceTo(p) > tol)
                pts.Add(p);
        }

        private XYZ ObtenerDireccionDominanteDelBoceto(PlanarFace face, XYZ normal)
        {
            if (face == null)
                return XYZ.Zero;

            IList<CurveLoop> loops = face.GetEdgesAsCurveLoops();

            if (loops == null || loops.Count == 0)
                return XYZ.Zero;

            CurveLoop mejorLoop = loops.OrderByDescending(l => Math.Abs(AreaLoopAproximada(l, face.Origin, normal))).FirstOrDefault();

            if (mejorLoop == null)
                return XYZ.Zero;

            XYZ mejorDir = XYZ.Zero;
            double mejorLong = 0.0;

            foreach (Curve c in mejorLoop)
            {
                if (c == null)
                    continue;

                XYZ p0 = c.GetEndPoint(0);
                XYZ p1 = c.GetEndPoint(1);
                XYZ dir = ProyectarEnPlano(p1 - p0, normal);
                double len = dir.GetLength();

                if (len > mejorLong)
                {
                    mejorLong = len;
                    mejorDir = dir.Normalize();
                }
            }

            return mejorDir;
        }

        private double AreaLoopAproximada(CurveLoop loop, XYZ origen, XYZ normal)
        {
            if (loop == null)
                return 0.0;

            XYZ dirU = ProyectarEnPlano(XYZ.BasisX, normal);
            if (dirU.GetLength() <= Tol)
                dirU = ProyectarEnPlano(XYZ.BasisY, normal);
            if (dirU.GetLength() <= Tol)
                return 0.0;

            dirU = dirU.Normalize();
            XYZ dirV = normal.CrossProduct(dirU).Normalize();
            List<XYZ> pts = new List<XYZ>();

            foreach (Curve c in loop)
            {
                if (c == null)
                    continue;

                IList<XYZ> tess = c.Tessellate();
                if (tess == null)
                    continue;

                foreach (XYZ p in tess)
                    AgregarPuntoUnico(pts, p, M(0.001));
            }

            return Area(ProyectarPoligono(pts, origen, dirU, dirV));
        }

        private List<P2> ProyectarPoligono(List<XYZ> pts, XYZ origen, XYZ dirU, XYZ dirV)
        {
            List<P2> res = new List<P2>();

            if (pts == null)
                return res;

            foreach (XYZ p in pts)
                res.Add(ProyectarPunto(p, origen, dirU, dirV));

            return res;
        }

        private P2 ProyectarPunto(XYZ p, XYZ origen, XYZ dirU, XYZ dirV)
        {
            XYZ v = p - origen;
            return new P2(v.DotProduct(dirU), v.DotProduct(dirV));
        }

        private XYZ To3D(P2 p, XYZ origen, XYZ dirU, XYZ dirV)
        {
            return origen.Add(dirU.Multiply(p.X)).Add(dirV.Multiply(p.Y));
        }

        private double Area(List<P2> poly)
        {
            if (poly == null || poly.Count < 3)
                return 0.0;

            double a = 0.0;

            for (int i = 0; i < poly.Count; i++)
            {
                P2 p = poly[i];
                P2 q = poly[(i + 1) % poly.Count];
                a += p.X * q.Y - q.X * p.Y;
            }

            return a / 2.0;
        }

        private XYZ ProyectarEnPlano(XYZ v, XYZ normal)
        {
            if (v == null || normal == null || normal.GetLength() <= Tol)
                return XYZ.Zero;

            XYZ n = normal.Normalize();
            return v.Subtract(n.Multiply(v.DotProduct(n)));
        }

        private XYZ OrientarNormalHaciaArriba(XYZ n)
        {
            if (n == null || n.GetLength() <= Tol)
                return XYZ.BasisZ;

            n = n.Normalize();
            return n.DotProduct(XYZ.BasisZ) < 0.0 ? n.Multiply(-1.0) : n;
        }

        private double ToInternal(double metros)
        {
            return UnitUtils.ConvertToInternalUnits(metros, UnitTypeId.Meters);
        }

        private double M(double metros)
        {
            return ToInternal(metros);
        }

        private string Normalizar(string s)
        {
            if (string.IsNullOrWhiteSpace(s))
                return "";

            string t = s.ToUpperInvariant();
            t = t.Replace("Á", "A").Replace("É", "E").Replace("Í", "I").Replace("Ó", "O").Replace("Ú", "U");
            t = t.Replace("Ä", "A").Replace("Ë", "E").Replace("Ï", "I").Replace("Ö", "O").Replace("Ü", "U");
            t = t.Replace("Ñ", "N");
            return t;
        }
    }
}
