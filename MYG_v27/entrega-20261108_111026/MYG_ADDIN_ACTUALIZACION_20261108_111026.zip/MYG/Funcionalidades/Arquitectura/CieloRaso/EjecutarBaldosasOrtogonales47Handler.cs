﻿// =====================================
// HANDLER EXTERNO 4.7 - BALDOSAS ORTOGONALES SIMPLES - V47
// V46: agrega colgadores en intersecciones y combos tipo texto con memoria de último uso
// V47: el arranque inferior del colgador sube automáticamente el Alto de los perfiles
// V52: offset superior de colgador + división nativa en caras L/irregulares
// CON USING Y NAMESPACE
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MYG_Addin
{
    public class EjecutarBaldosasOrtogonales47Handler : IExternalEventHandler
    {
        public UIDocument UiDoc;
        public MYG_BaldosasOrtogonales47.BaldosasOrtogonalesForm Form;

        private const double Tol = 1e-7;

        private class P2
        {
            public double X;
            public double Y;

            public P2()
            {
                X = 0.0;
                Y = 0.0;
            }

            public P2(double x, double y)
            {
                X = x;
                Y = y;
            }
        }

        private class Intervalo
        {
            public double A;
            public double B;

            public Intervalo(double a, double b)
            {
                A = Math.Min(a, b);
                B = Math.Max(a, b);
            }

            public double Longitud
            {
                get { return B - A; }
            }
        }

        private class PerfilCreado
        {
            public FamilyInstance Instancia;
            public string Rol;

            public PerfilCreado(FamilyInstance instancia, string rol)
            {
                Instancia = instancia;
                Rol = rol ?? "";
            }
        }

        public void Execute(UIApplication app)
        {
            UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

            if (uidoc == null || uidoc.Document == null || Form == null)
                return;

            Document doc = uidoc.Document;
            MYG_BaldosasOrtogonales47.Operacion op = Form.OperacionSolicitada;

            try
            {
                if (op == MYG_BaldosasOrtogonales47.Operacion.CargarDatos)
                {
                    CargarDatos(doc);
                    return;
                }

                if (op == MYG_BaldosasOrtogonales47.Operacion.PickarSuperficieYGenerar)
                {
                    Reference referencia = PickarCara(uidoc);

                    if (referencia == null)
                        return;

                    GenerarSistema(doc, referencia);
                    return;
                }
            }
            catch (Exception ex)
            {
                Form.MostrarMensaje("ERROR:\n" + ex.Message);
            }
            finally
            {
                Form.MostrarVentanaDespuesDePick();
            }
        }

        public string GetName()
        {
            return "MYG - Baldosas ortogonales simples";
        }

        private void CargarDatos(Document doc)
        {
            List<MYG_BaldosasOrtogonales47.ComboItem> perfiles =
                new FilteredElementCollector(doc)
                .OfCategory(BuiltInCategory.OST_StructuralFraming)
                .OfClass(typeof(FamilySymbol))
                .Cast<FamilySymbol>()
                .OrderBy(x => ObtenerNombreCompleto(x))
                .Select(x => new MYG_BaldosasOrtogonales47.ComboItem(
                    x.Id,
                    ObtenerNombreCompleto(x) + "  [Armazón estructural]"))
                .ToList();

            List<MYG_BaldosasOrtogonales47.ComboItem> colgadores =
                ObtenerColgadoresModeloGenerico(doc);

            List<MYG_BaldosasOrtogonales47.ComboItem> niveles =
                new FilteredElementCollector(doc)
                .OfClass(typeof(Level))
                .Cast<Level>()
                .OrderBy(x => x.Elevation)
                .Select(x => new MYG_BaldosasOrtogonales47.ComboItem(
                    x.Id,
                    x.Name + " | Elev.: " +
                    UnitUtils.ConvertFromInternalUnits(x.Elevation, UnitTypeId.Meters).ToString("0.00") + " m"))
                .ToList();

            Form.CargarDatosDesdeHandler(perfiles, colgadores, niveles);
        }

        private List<MYG_BaldosasOrtogonales47.ComboItem> ObtenerColgadoresModeloGenerico(Document doc)
        {
            List<FamilySymbol> todos = new FilteredElementCollector(doc)
                .OfClass(typeof(FamilySymbol))
                .Cast<FamilySymbol>()
                .Where(x => x != null && x.Family != null && x.Category != null)
                .ToList();

            List<FamilySymbol> candidatos = todos
                .Where(x => EsModeloGenerico(x) && EsFamiliaCandidataColgador(x))
                .OrderBy(x => ObtenerNombreCompleto(x))
                .ToList();

            if (candidatos.Count == 0)
            {
                candidatos = todos
                    .Where(EsModeloGenerico)
                    .OrderBy(x => ObtenerNombreCompleto(x))
                    .ToList();
            }

            return candidatos
                .Select(x => new MYG_BaldosasOrtogonales47.ComboItem(
                    x.Id,
                    ObtenerNombreCompleto(x) + "  [Modelos genéricos]"))
                .ToList();
        }

        private bool EsModeloGenerico(FamilySymbol fs)
        {
            if (fs == null || fs.Category == null)
                return false;

            try
            {
                if (fs.Category.Id.Value == (long)BuiltInCategory.OST_GenericModel)
                    return true;
            }
            catch
            {
            }

            string cat = NormalizarTexto(fs.Category.Name);
            return cat.Contains("MODELOS_GENERICOS") ||
                   cat.Contains("GENERIC_MODELS") ||
                   cat.Contains("GENERICMODEL");
        }

        private bool EsFamiliaCandidataColgador(FamilySymbol fs)
        {
            if (fs == null)
                return false;

            string texto = NormalizarTexto(
                (fs.Family != null ? fs.Family.Name : "") + " " +
                fs.Name + " " +
                (fs.Category != null ? fs.Category.Name : ""));

            return texto.Contains("COLGADOR") ||
                   texto.Contains("HANGER") ||
                   texto.Contains("VARILLA") ||
                   texto.Contains("ROSCADA") ||
                   texto.Contains("SOPORTE") ||
                   texto.Contains("SUSPENDIDO") ||
                   texto.Contains("ANCLAJE");
        }

        private string ObtenerNombreCompleto(FamilySymbol fs)
        {
            if (fs == null)
                return "";

            string familia = "";

            try
            {
                if (fs.Family != null)
                    familia = fs.Family.Name;
            }
            catch
            {
            }

            if (string.IsNullOrWhiteSpace(familia))
                return fs.Name;

            return familia + " : " + fs.Name;
        }

        private Reference PickarCara(UIDocument uidoc)
        {
            try
            {
                Form.OcultarVentanaParaPick();

                return uidoc.Selection.PickObject(
                    ObjectType.Face,
                    "Seleccione la cara del piso/cielo raso/panel donde se dividirán las baldosas ortogonales.");
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                Form.MostrarMensaje("Selección cancelada por el usuario.");
                return null;
            }
            catch (Exception ex)
            {
                Form.MostrarMensaje("No se pudo seleccionar la cara:\n" + ex.Message);
                return null;
            }
        }

        private void GenerarSistema(Document doc, Reference referencia)
        {
            if (doc == null || referencia == null || Form == null)
                return;

            Element elemento = doc.GetElement(referencia.ElementId);

            if (elemento == null)
            {
                Form.MostrarMensaje("No se encontró el elemento de la cara seleccionada.");
                return;
            }

            GeometryObject go = elemento.GetGeometryObjectFromReference(referencia);
            PlanarFace face = go as PlanarFace;

            if (face == null)
            {
                Form.MostrarMensaje("La cara seleccionada no es plana.\n\nEsta versión trabaja con caras planas.");
                return;
            }

            FamilySymbol perfilInterior = doc.GetElement(Form.PerfilInteriorId) as FamilySymbol;
            FamilySymbol perfilPerimetral = doc.GetElement(Form.PerfilPerimetralId) as FamilySymbol;
            FamilySymbol colgador = doc.GetElement(Form.ColgadorId) as FamilySymbol;

            if ((Form.CrearPerfilesInteriores && perfilInterior == null) ||
                (Form.CrearPerimetro && perfilPerimetral == null))
            {
                Form.MostrarMensaje("Seleccione los tipos de perfil de armazón estructural.");
                return;
            }

            if (Form.CrearColgadores && colgador == null)
            {
                Form.MostrarMensaje("Seleccione el tipo de colgador / soporte.");
                return;
            }

            Level nivel = doc.GetElement(Form.NivelReferenciaId) as Level;
            if (nivel == null)
                nivel = ObtenerNivelMasCercano(doc, face.Origin.Z);

            if (nivel == null)
            {
                Form.MostrarMensaje("No se pudo detectar un nivel de referencia para los perfiles.");
                return;
            }

            double largo = M(Form.LargoBaldosaM);
            double ancho = M(Form.AnchoBaldosaM);
            double desfase = M(Form.DesfasePerfilM);
            double margen = M(Form.MargenPerimetralM);
            double longitudMinima = M(Form.LongitudMinimaM);
            double espesorPerfil = M(Form.EspesorPerfilM);
            double offsetSuperiorColgador = M(Form.OffsetSuperiorColgadorM);

            // V47:
            // Para que el arranque inferior del colgador no quede embebido en los perfiles,
            // se lee el parámetro de TIPO "Alto" de los perfiles interiores/principales
            // y perimetrales. El colgador arranca por encima del perfil que corresponde
            // a cada intersección.
            double altoPerfilInterior = ObtenerAltoPerfil(perfilInterior);
            double altoPerfilPerimetral = ObtenerAltoPerfil(perfilPerimetral);

            if (largo <= Tol || ancho <= Tol)
            {
                Form.MostrarMensaje("El largo y ancho de baldosa deben ser mayores que cero.");
                return;
            }

            if (espesorPerfil < 0.0)
            {
                Form.MostrarMensaje("El espesor de perfil/corte no puede ser negativo.");
                return;
            }

            if (offsetSuperiorColgador < 0.0)
            {
                Form.MostrarMensaje("El offset superior del colgador no puede ser negativo.");
                return;
            }

            XYZ normal = face.FaceNormal;
            if (normal == null || normal.GetLength() <= Tol)
                normal = XYZ.BasisZ;
            normal = normal.Normalize();

            XYZ dirU = ProyectarEnPlano(XYZ.BasisX, normal);
            if (dirU.GetLength() <= Tol)
                dirU = ProyectarEnPlano(XYZ.BasisY, normal);
            if (dirU.GetLength() <= Tol)
                dirU = XYZ.BasisX;
            dirU = dirU.Normalize();

            XYZ dirV = normal.CrossProduct(dirU);
            if (dirV.GetLength() <= Tol)
                dirV = XYZ.BasisY;
            dirV = dirV.Normalize();

            XYZ origen = face.Origin;
            List<P2> poligono = ObtenerPoligonoPrincipal2D(face, origen, dirU, dirV);

            if (poligono == null || poligono.Count < 3)
            {
                Form.MostrarMensaje("No se pudo leer el perímetro de la cara seleccionada.");
                return;
            }

            double areaPol = Area(poligono);
            if (Math.Abs(areaPol) <= Tol)
            {
                Form.MostrarMensaje("El perímetro de la cara no tiene área válida.");
                return;
            }

            if (areaPol < 0.0)
                poligono.Reverse();

            double minX = poligono.Min(p => p.X) + margen;
            double maxX = poligono.Max(p => p.X) - margen;
            double minY = poligono.Min(p => p.Y) + margen;
            double maxY = poligono.Max(p => p.Y) - margen;

            if (maxX <= minX || maxY <= minY)
            {
                Form.MostrarMensaje("El margen perimetral es mayor que el área útil de la cara.");
                return;
            }

            int perfilesPerimetro = 0;
            int perfilesInteriores = 0;
            int baldosas = 0;
            int colgadoresCreados = 0;
            int recortesAplicados = 0;
            List<PerfilCreado> perfilesCreados = new List<PerfilCreado>();

            using (Transaction tx = new Transaction(doc, "MYG - Baldosas ortogonales simples"))
            {
                tx.Start();

                if (perfilInterior != null && !perfilInterior.IsActive)
                    perfilInterior.Activate();

                if (perfilPerimetral != null && !perfilPerimetral.IsActive)
                    perfilPerimetral.Activate();

                if (colgador != null && !colgador.IsActive)
                    colgador.Activate();

                doc.Regenerate();

                XYZ origenPerfil = origen.Add(normal.Multiply(desfase));

                if (Form.CrearPerimetro && perfilPerimetral != null)
                {
                    perfilesPerimetro = CrearPerimetro(
                        doc,
                        perfilPerimetral,
                        nivel,
                        poligono,
                        origenPerfil,
                        dirU,
                        dirV,
                        longitudMinima,
                        perfilesCreados);
                }

                if (Form.CrearPerfilesInteriores && perfilInterior != null)
                {
                    perfilesInteriores = CrearPerfilesInteriores(
                        doc,
                        perfilInterior,
                        nivel,
                        poligono,
                        origenPerfil,
                        dirU,
                        dirV,
                        minX,
                        maxX,
                        minY,
                        maxY,
                        largo,
                        ancho,
                        longitudMinima,
                        perfilesCreados);
                }

                if (perfilesCreados.Count > 1)
                {
                    try
                    {
                        doc.Regenerate();
                    }
                    catch
                    {
                    }

                    recortesAplicados = AplicarRecorteNativoEnIntersecciones(doc, perfilesCreados);

                    if (recortesAplicados > 0)
                    {
                        try
                        {
                            doc.Regenerate();
                        }
                        catch
                        {
                        }
                    }
                }

                if (Form.CrearColgadores && colgador != null)
                {
                    colgadoresCreados = CrearColgadoresEnIntersecciones(
                        doc,
                        colgador,
                        elemento,
                        perfilesCreados,
                        poligono,
                        origenPerfil,
                        dirU,
                        dirV,
                        minX,
                        maxX,
                        minY,
                        maxY,
                        largo,
                        ancho,
                        altoPerfilInterior,
                        altoPerfilPerimetral,
                        offsetSuperiorColgador,
                        Form.ParametroLongitudColgador);
                }

                if (Form.CrearBaldosas)
                {
                    baldosas = CrearBaldosasNativasYEliminarOriginal(
                        doc,
                        elemento,
                        nivel,
                        poligono,
                        origen,
                        dirU,
                        dirV,
                        normal,
                        minX,
                        maxX,
                        minY,
                        maxY,
                        largo,
                        ancho,
                        espesorPerfil);
                }

                tx.Commit();
            }

            Form.ActualizarSuperficie(
                "Superficie activa: Elemento Id " + elemento.Id.ToString() +
                " | Área aprox.: " +
                UnitUtils.ConvertFromInternalUnits(face.Area, UnitTypeId.SquareMeters).ToString("0.###") + " m²");

            Form.MostrarMensaje(
                "PROCESO TERMINADO\n" +
                "------------------------------\n" +
                "Perfil perimetral: " + perfilesPerimetro + "\n" +
                "Perfiles interiores: " + perfilesInteriores + "\n" +
                "Colgadores creados: " + colgadoresCreados + "\n" +
                "Baldosas nativas creadas: " + baldosas + "\n" +
                "Largo baldosa: " + Form.LargoBaldosaM.ToString("0.###") + " m\n" +
                "Ancho baldosa: " + Form.AnchoBaldosaM.ToString("0.###") + " m\n" +
                "Espesor perfil/corte: " + Form.EspesorPerfilM.ToString("0.###") + " m\n" +
                "Offset superior colgador: " + Form.OffsetSuperiorColgadorM.ToString("0.###") + " m\n" +
                "Alto perfil interior detectado: " + UnitUtils.ConvertFromInternalUnits(altoPerfilInterior, UnitTypeId.Meters).ToString("0.###") + " m\n" +
                "Alto perfil perimetral detectado: " + UnitUtils.ConvertFromInternalUnits(altoPerfilPerimetral, UnitTypeId.Meters).ToString("0.###") + " m\n" +
                "Base de colgadores: cara + desfase + Alto del perfil correspondiente\n" +
                "Parámetro longitud colgador: " + Form.ParametroLongitudColgador + "\n" +
                "Nota: se elimina el elemento original solo si se pudo crear al menos una baldosa nativa.");
        }

        private int CrearPerimetro(
            Document doc,
            FamilySymbol symbol,
            Level nivel,
            List<P2> poligono,
            XYZ origen,
            XYZ dirU,
            XYZ dirV,
            double longitudMinima,
            List<PerfilCreado> perfilesCreados)
        {
            int contador = 0;

            for (int i = 0; i < poligono.Count; i++)
            {
                P2 a2 = poligono[i];
                P2 b2 = poligono[(i + 1) % poligono.Count];

                if (Distancia(a2, b2) < longitudMinima)
                    continue;

                XYZ a = To3D(a2, origen, dirU, dirV);
                XYZ b = To3D(b2, origen, dirU, dirV);

                FamilyInstance fi = CrearPerfil(doc, symbol, nivel, a, b);

                if (fi != null)
                {
                    contador++;
                    if (perfilesCreados != null)
                        perfilesCreados.Add(new PerfilCreado(fi, "Perimetral"));
                }
            }

            return contador;
        }

        private int CrearPerfilesInteriores(
            Document doc,
            FamilySymbol symbol,
            Level nivel,
            List<P2> poligono,
            XYZ origen,
            XYZ dirU,
            XYZ dirV,
            double minX,
            double maxX,
            double minY,
            double maxY,
            double largo,
            double ancho,
            double longitudMinima,
            List<PerfilCreado> perfilesCreados)
        {
            int contador = 0;

            // Líneas paralelas a U, cada ancho de baldosa.
            for (double y = minY + ancho; y < maxY - Tol; y += ancho)
            {
                List<Intervalo> ints = InterseccionesHorizontal(poligono, y);

                foreach (Intervalo inter in ints)
                {
                    double a = Math.Max(inter.A, minX);
                    double b = Math.Min(inter.B, maxX);

                    if (b - a < longitudMinima)
                        continue;

                    FamilyInstance fi = CrearPerfil(
                        doc,
                        symbol,
                        nivel,
                        To3D(new P2(a, y), origen, dirU, dirV),
                        To3D(new P2(b, y), origen, dirU, dirV));

                    if (fi != null)
                    {
                        contador++;
                        if (perfilesCreados != null)
                            perfilesCreados.Add(new PerfilCreado(fi, "Interior"));
                    }
                }
            }

            // Líneas paralelas a V, cada largo de baldosa.
            for (double x = minX + largo; x < maxX - Tol; x += largo)
            {
                List<Intervalo> ints = InterseccionesVertical(poligono, x);

                foreach (Intervalo inter in ints)
                {
                    double a = Math.Max(inter.A, minY);
                    double b = Math.Min(inter.B, maxY);

                    if (b - a < longitudMinima)
                        continue;

                    FamilyInstance fi = CrearPerfil(
                        doc,
                        symbol,
                        nivel,
                        To3D(new P2(x, a), origen, dirU, dirV),
                        To3D(new P2(x, b), origen, dirU, dirV));

                    if (fi != null)
                    {
                        contador++;
                        if (perfilesCreados != null)
                            perfilesCreados.Add(new PerfilCreado(fi, "Interior"));
                    }
                }
            }

            return contador;
        }

        private int CrearColgadoresEnIntersecciones(
            Document doc,
            FamilySymbol symbol,
            Element hostOriginal,
            List<PerfilCreado> perfilesCreados,
            List<P2> poligono,
            XYZ origen,
            XYZ dirU,
            XYZ dirV,
            double minX,
            double maxX,
            double minY,
            double maxY,
            double largo,
            double ancho,
            double altoPerfilInterior,
            double altoPerfilPerimetral,
            double offsetSuperiorColgador,
            string nombreParametroLongitud)
        {
            if (doc == null || symbol == null || poligono == null || poligono.Count < 3)
                return 0;

            int contador = 0;
            List<P2> puntos = ObtenerPuntosColgadoresIntersecciones(
                poligono,
                minX,
                maxX,
                minY,
                maxY,
                largo,
                ancho);

            if (puntos == null || puntos.Count == 0)
                return 0;

            HashSet<long> idsExcluir = new HashSet<long>();

            if (hostOriginal != null && hostOriginal.Id != null)
                idsExcluir.Add(hostOriginal.Id.Value);

            if (perfilesCreados != null)
            {
                foreach (PerfilCreado pc in perfilesCreados)
                {
                    if (pc != null && pc.Instancia != null && pc.Instancia.Id != null)
                        idsExcluir.Add(pc.Instancia.Id.Value);
                }
            }

            double distanciaMaximaBusqueda = M(20.0);
            XYZ refDir = dirU != null && dirU.GetLength() > Tol ? dirU.Normalize() : XYZ.BasisX;

            foreach (P2 p in puntos)
            {
                try
                {
                    XYZ puntoBaseSinAlto = To3D(p, origen, dirU, dirV);
                    double altoArranqueColgador = ObtenerAltoArranqueColgadorPorInterseccion(
                        p,
                        minX,
                        maxX,
                        minY,
                        maxY,
                        altoPerfilInterior,
                        altoPerfilPerimetral);

                    // El colgador se mantiene vertical, por eso la corrección del arranque inferior
                    // se hace en +Z global, no en la normal de la cara.
                    XYZ puntoBase = puntoBaseSinAlto.Add(XYZ.BasisZ.Multiply(altoArranqueColgador));
                    XYZ puntoBusqueda = puntoBase.Add(XYZ.BasisZ.Multiply(M(0.001)));

                    ImpactoSuperior impacto = BuscarCaraMasCercanaHaciaArriba(
                        doc,
                        puntoBusqueda,
                        distanciaMaximaBusqueda,
                        idsExcluir);

                    if (impacto == null || impacto.Punto == null)
                        continue;

                    // V52:
                    // El offset superior solo recorta la parte alta del colgador respecto
                    // a la cara superior detectada. La base inferior NO se mueve.
                    double zSuperiorConOffset = impacto.Punto.Z - Math.Max(0.0, offsetSuperiorColgador);
                    double longitud = zSuperiorConOffset - puntoBase.Z;

                    if (longitud <= M(0.02))
                        continue;

                    FamilyInstance fi = CrearColgador(
                        doc,
                        symbol,
                        impacto,
                        puntoBase,
                        refDir,
                        longitud,
                        nombreParametroLongitud);

                    if (fi != null)
                    {
                        contador++;
                        idsExcluir.Add(fi.Id.Value);
                    }
                }
                catch
                {
                }
            }

            return contador;
        }

        private double ObtenerAltoArranqueColgadorPorInterseccion(
            P2 punto,
            double minX,
            double maxX,
            double minY,
            double maxY,
            double altoPerfilInterior,
            double altoPerfilPerimetral)
        {
            if (punto == null)
                return 0.0;

            double tolBorde = M(0.01);

            bool enBordeX =
                Math.Abs(punto.X - minX) <= tolBorde ||
                Math.Abs(punto.X - maxX) <= tolBorde;

            bool enBordeY =
                Math.Abs(punto.Y - minY) <= tolBorde ||
                Math.Abs(punto.Y - maxY) <= tolBorde;

            bool esBorde = enBordeX || enBordeY;
            bool esEsquina = enBordeX && enBordeY;

            double alto = 0.0;

            // En borde existe perfil perimetral.
            if (esBorde && altoPerfilPerimetral > alto)
                alto = altoPerfilPerimetral;

            // En intersecciones interiores existe perfil interior/principal.
            // En borde no-esquina también llega un perfil interior contra el perimetral,
            // por eso se toma el mayor de ambos.
            if (!esEsquina && altoPerfilInterior > alto)
                alto = altoPerfilInterior;

            return Math.Max(0.0, alto);
        }

        private List<P2> ObtenerPuntosColgadoresIntersecciones(
            List<P2> poligono,
            double minX,
            double maxX,
            double minY,
            double maxY,
            double largo,
            double ancho)
        {
            List<P2> puntos = new List<P2>();

            if (poligono == null || poligono.Count < 3 || largo <= Tol || ancho <= Tol)
                return puntos;

            List<double> xs = new List<double>();
            List<double> ys = new List<double>();

            for (double x = minX; x <= maxX + Tol; x += largo)
                xs.Add(Math.Min(x, maxX));

            if (xs.Count == 0 || Math.Abs(xs[xs.Count - 1] - maxX) > M(0.005))
                xs.Add(maxX);

            for (double y = minY; y <= maxY + Tol; y += ancho)
                ys.Add(Math.Min(y, maxY));

            if (ys.Count == 0 || Math.Abs(ys[ys.Count - 1] - maxY) > M(0.005))
                ys.Add(maxY);

            foreach (double x in xs.Distinct().OrderBy(v => v))
            {
                foreach (double y in ys.Distinct().OrderBy(v => v))
                {
                    P2 p = new P2(x, y);

                    if (PuntoDentroPoligono(p, poligono) || PuntoCercaDelBorde(p, poligono, M(0.005)))
                        puntos.Add(p);
                }
            }

            return puntos;
        }

        private bool PuntoDentroPoligono(P2 p, List<P2> poly)
        {
            if (p == null || poly == null || poly.Count < 3)
                return false;

            bool dentro = false;
            int j = poly.Count - 1;

            for (int i = 0; i < poly.Count; i++)
            {
                P2 pi = poly[i];
                P2 pj = poly[j];

                bool cruza = ((pi.Y > p.Y) != (pj.Y > p.Y)) &&
                              (p.X < (pj.X - pi.X) * (p.Y - pi.Y) / ((pj.Y - pi.Y) == 0.0 ? Tol : (pj.Y - pi.Y)) + pi.X);

                if (cruza)
                    dentro = !dentro;

                j = i;
            }

            return dentro;
        }

        private bool PuntoCercaDelBorde(P2 p, List<P2> poly, double tol)
        {
            if (p == null || poly == null || poly.Count < 2)
                return false;

            for (int i = 0; i < poly.Count; i++)
            {
                P2 a = poly[i];
                P2 b = poly[(i + 1) % poly.Count];

                if (DistanciaPuntoSegmento2D(p, a, b) <= tol)
                    return true;
            }

            return false;
        }

        private double DistanciaPuntoSegmento2D(P2 p, P2 a, P2 b)
        {
            if (p == null || a == null || b == null)
                return double.MaxValue;

            double vx = b.X - a.X;
            double vy = b.Y - a.Y;
            double wx = p.X - a.X;
            double wy = p.Y - a.Y;
            double c1 = wx * vx + wy * vy;

            if (c1 <= 0.0)
                return Distancia(p, a);

            double c2 = vx * vx + vy * vy;

            if (c2 <= Tol)
                return Distancia(p, a);

            if (c1 >= c2)
                return Distancia(p, b);

            double t = c1 / c2;
            P2 q = new P2(a.X + t * vx, a.Y + t * vy);
            return Distancia(p, q);
        }

        private FamilyInstance CrearColgador(
            Document doc,
            FamilySymbol symbol,
            ImpactoSuperior impacto,
            XYZ puntoBase,
            XYZ direccionReferencia,
            double longitud,
            string nombreParametroLongitud)
        {
            if (doc == null || symbol == null || impacto == null || impacto.Punto == null || puntoBase == null)
                return null;

            FamilyInstance fi = null;
            XYZ refDir = direccionReferencia;

            if (refDir == null || refDir.GetLength() <= Tol)
                refDir = XYZ.BasisX;

            if (impacto.FaceNormal != null && impacto.FaceNormal.GetLength() > Tol)
            {
                XYZ proyectada = ProyectarEnPlano(refDir, impacto.FaceNormal);
                if (proyectada != null && proyectada.GetLength() > Tol)
                    refDir = proyectada;
            }

            if (refDir == null || refDir.GetLength() <= Tol)
                refDir = XYZ.BasisX;

            refDir = refDir.Normalize();

            try
            {
                if (impacto.FaceReference != null)
                {
                    try
                    {
                        fi = doc.Create.NewFamilyInstance(
                            impacto.FaceReference,
                            impacto.Punto,
                            refDir,
                            symbol);
                    }
                    catch
                    {
                        fi = null;
                    }
                }

                if (fi == null && !impacto.EsDeVinculo && impacto.Face != null)
                {
                    try
                    {
                        fi = doc.Create.NewFamilyInstance(
                            impacto.Face,
                            impacto.Punto,
                            refDir,
                            symbol);
                    }
                    catch
                    {
                        fi = null;
                    }
                }
            }
            catch
            {
                fi = null;
            }

            if (fi == null)
            {
                try
                {
                    fi = doc.Create.NewFamilyInstance(
                        impacto.Punto,
                        symbol,
                        StructuralType.NonStructural);
                }
                catch
                {
                    fi = null;
                }
            }

            if (fi == null)
                return null;

            SetParametroLongitudPorNombres(
                fi,
                longitud,
                nombreParametroLongitud,
                "Altura de colgador",
                "Longitud colgador",
                "Longitud",
                "Height",
                "Hanger Height");

            AjustarBaseColgador(doc, fi, puntoBase);
            ForzarColgadorVertical(doc, fi, puntoBase);
            AjustarBaseColgador(doc, fi, puntoBase);

            return fi;
        }

        private void AjustarBaseColgador(Document doc, FamilyInstance fi, XYZ puntoBase)
        {
            if (doc == null || fi == null || puntoBase == null)
                return;

            Parameter pOffset = ObtenerParametroOffsetHost(fi);

            if (pOffset != null && !pOffset.IsReadOnly && pOffset.StorageType == StorageType.Double)
            {
                try
                {
                    double offsetOriginal = pOffset.AsDouble();
                    double zObjetivo = puntoBase.Z;

                    doc.Regenerate();

                    double zActual = ObtenerZReferenciaInstancia(fi);
                    double deltaZ = zObjetivo - zActual;

                    if (Math.Abs(deltaZ) <= M(0.001))
                        return;

                    if (ProbarOffsetHost(doc, fi, pOffset, offsetOriginal + deltaZ, zObjetivo))
                        return;

                    if (ProbarOffsetHost(doc, fi, pOffset, offsetOriginal - deltaZ, zObjetivo))
                        return;
                }
                catch
                {
                }
            }

            MoverSoloZHastaBase(doc, fi, puntoBase);
        }

        private Parameter ObtenerParametroOffsetHost(FamilyInstance fi)
        {
            if (fi == null)
                return null;

            try
            {
                Parameter p = fi.get_Parameter(BuiltInParameter.INSTANCE_FREE_HOST_OFFSET_PARAM);
                if (p != null)
                    return p;
            }
            catch
            {
            }

            return BuscarParametro(fi,
                "Offset from Host",
                "Offset del anfitrión",
                "Desfase desde anfitrión",
                "Desfase de anfitrión",
                "Host Offset",
                "Offset");
        }

        private bool ProbarOffsetHost(Document doc, FamilyInstance fi, Parameter pOffset, double valorOffset, double zObjetivo)
        {
            if (doc == null || fi == null || pOffset == null || pOffset.IsReadOnly)
                return false;

            try
            {
                pOffset.Set(valorOffset);
                doc.Regenerate();

                double zNuevo = ObtenerZReferenciaInstancia(fi);
                return Math.Abs(zNuevo - zObjetivo) <= M(0.005);
            }
            catch
            {
                return false;
            }
        }

        private Parameter BuscarParametro(Element e, params string[] nombres)
        {
            if (e == null || nombres == null)
                return null;

            foreach (string nombre in nombres)
            {
                if (string.IsNullOrWhiteSpace(nombre))
                    continue;

                try
                {
                    Parameter p = e.LookupParameter(nombre);
                    if (p != null)
                        return p;
                }
                catch
                {
                }
            }

            return null;
        }

        private double ObtenerZReferenciaInstancia(FamilyInstance fi)
        {
            if (fi == null)
                return 0.0;

            try
            {
                LocationPoint lp = fi.Location as LocationPoint;
                if (lp != null && lp.Point != null)
                    return lp.Point.Z;
            }
            catch
            {
            }

            try
            {
                BoundingBoxXYZ bb = fi.get_BoundingBox(null);
                if (bb != null)
                    return bb.Min.Z;
            }
            catch
            {
            }

            return 0.0;
        }

        private void MoverSoloZHastaBase(Document doc, FamilyInstance fi, XYZ puntoBase)
        {
            if (doc == null || fi == null || puntoBase == null)
                return;

            try
            {
                double zActual = ObtenerZReferenciaInstancia(fi);
                double deltaZ = puntoBase.Z - zActual;

                if (Math.Abs(deltaZ) <= M(0.001))
                    return;

                ElementTransformUtils.MoveElement(doc, fi.Id, new XYZ(0.0, 0.0, deltaZ));
            }
            catch
            {
            }
        }

        private void ForzarColgadorVertical(Document doc, FamilyInstance fi, XYZ puntoBase)
        {
            if (doc == null || fi == null)
                return;

            try
            {
                doc.Regenerate();

                Transform tr = fi.GetTransform();
                if (tr == null || tr.BasisZ == null || tr.BasisZ.GetLength() <= Tol)
                    return;

                XYZ ejeLocalZ = tr.BasisZ.Normalize();
                double dot = ejeLocalZ.DotProduct(XYZ.BasisZ);

                if (Math.Abs(dot) >= 0.9995)
                    return;

                XYZ objetivo = dot >= 0.0 ? XYZ.BasisZ : XYZ.BasisZ.Multiply(-1.0);
                XYZ ejeRotacion = ejeLocalZ.CrossProduct(objetivo);

                if (ejeRotacion == null || ejeRotacion.GetLength() <= Tol)
                    return;

                XYZ puntoRotacion = puntoBase;

                if (puntoRotacion == null)
                {
                    LocationPoint lp = fi.Location as LocationPoint;
                    puntoRotacion = lp != null ? lp.Point : XYZ.Zero;
                }

                double angulo = ejeLocalZ.AngleTo(objetivo);

                if (Math.Abs(angulo) > Tol)
                {
                    Line eje = Line.CreateUnbound(puntoRotacion, ejeRotacion.Normalize());
                    ElementTransformUtils.RotateElement(doc, fi.Id, eje, angulo);
                }
            }
            catch
            {
            }
        }

        private int CrearBaldosasNativasYEliminarOriginal(
            Document doc,
            Element hostOriginal,
            Level nivel,
            List<P2> poligono,
            XYZ origen,
            XYZ dirU,
            XYZ dirV,
            XYZ normal,
            double minX,
            double maxX,
            double minY,
            double maxY,
            double largo,
            double ancho,
            double espesorPerfil)
        {
            int contador = 0;

            if (doc == null || hostOriginal == null || nivel == null)
                return 0;

            bool esFloor = hostOriginal is Floor;
            bool esCeiling = hostOriginal is Ceiling;

            if (!esFloor && !esCeiling)
            {
                Form.MostrarMensaje(
                    "El elemento seleccionado no se puede dividir como elemento nativo en esta versión.\n\n" +
                    "Soportado por ahora:\n" +
                    "- Suelos / Floors\n" +
                    "- Cielos rasos / Ceilings\n\n" +
                    "Categoría seleccionada: " +
                    (hostOriginal.Category != null ? hostOriginal.Category.Name : "sin categoría"));

                return 0;
            }

            // Floor/Ceiling por boceto funcionan de forma estable con perfiles horizontales.
            // Si la cara está inclinada, la división nativa por sketch no es segura para Floor/Ceiling.
            if (Math.Abs(normal.Normalize().DotProduct(XYZ.BasisZ)) < 0.95)
            {
                Form.MostrarMensaje(
                    "La cara seleccionada es inclinada.\n\n" +
                    "Para dividir el elemento en piezas nativas por boceto, esta versión requiere una cara casi horizontal.\n" +
                    "La parrilla de perfiles sí puede trabajar en la cara, pero la división nativa del host no se ejecutó.");

                return 0;
            }

            ElementId tipoId = hostOriginal.GetTypeId();

            if (tipoId == null || tipoId == ElementId.InvalidElementId)
                return 0;

            double offsetHost = ObtenerOffsetNivel(hostOriginal, origen.Z - nivel.Elevation);
            List<ElementId> nuevos = new List<ElementId>();

            double espesorCorte = Math.Max(0.0, espesorPerfil);
            double medioEspesorCorte = espesorCorte / 2.0;

            // V45:
            // Cada corte interno deja espesor/2 a cada lado para que la junta total
            // coincida con el espesor del perfil. En el perímetro se descuenta
            // el espesor completo hacia adentro.
            List<P2> poligonoCorte = poligono;

            if (espesorCorte > Tol)
            {
                List<P2> offsetInterior = OffsetPoligonoInterior(poligono, espesorCorte);

                if (offsetInterior != null && offsetInterior.Count >= 3 && Math.Abs(Area(offsetInterior)) > M(0.01) * M(0.01))
                    poligonoCorte = offsetInterior;
            }

            int ix = 0;
            for (double x = minX; x < maxX - Tol; x += largo, ix++)
            {
                double x2 = Math.Min(x + largo, maxX);

                int iy = 0;
                for (double y = minY; y < maxY - Tol; y += ancho, iy++)
                {
                    double y2 = Math.Min(y + ancho, maxY);

                    double xIniCorte = x + (Math.Abs(x - minX) <= Tol ? espesorCorte : medioEspesorCorte);
                    double xFinCorte = x2 - (Math.Abs(x2 - maxX) <= Tol ? espesorCorte : medioEspesorCorte);
                    double yIniCorte = y + (Math.Abs(y - minY) <= Tol ? espesorCorte : medioEspesorCorte);
                    double yFinCorte = y2 - (Math.Abs(y2 - maxY) <= Tol ? espesorCorte : medioEspesorCorte);

                    if (xFinCorte <= xIniCorte + Tol || yFinCorte <= yIniCorte + Tol)
                        continue;

                    List<P2> rect = new List<P2>()
                    {
                        new P2(xIniCorte, yIniCorte),
                        new P2(xFinCorte, yIniCorte),
                        new P2(xFinCorte, yFinCorte),
                        new P2(xIniCorte, yFinCorte)
                    };

                    List<P2> celda = ClipPoligonoPorRectangulo(poligonoCorte, xIniCorte, yIniCorte, xFinCorte, yFinCorte);

                    if (celda == null || celda.Count < 3)
                        continue;

                    double area = Math.Abs(Area(celda));
                    if (area < M(0.01) * M(0.01))
                        continue;

                    CurveLoop loop = CrearCurveLoopHorizontal(celda, origen, dirU, dirV, nivel.Elevation);

                    if (loop == null)
                        continue;

                    Element nuevo = CrearElementoNativoPorCategoria(
                        doc,
                        hostOriginal,
                        tipoId,
                        nivel.Id,
                        loop);

                    if (nuevo == null)
                        continue;

                    CopiarParametrosInstanciaCompatibles(hostOriginal, nuevo);
                    SetOffsetNivel(nuevo, offsetHost);

                    nuevos.Add(nuevo.Id);
                    contador++;
                }
            }

            if (contador > 0)
            {
                try
                {
                    doc.Delete(hostOriginal.Id);
                }
                catch
                {
                    Form.MostrarMensaje(
                        "Se crearon " + contador + " baldosas nativas, pero no se pudo eliminar el elemento original.\n" +
                        "Revise si el elemento está bloqueado, en grupo, vinculado o con restricción.");
                }
            }

            return contador;
        }

        private List<P2> OffsetPoligonoInterior(List<P2> poligono, double distancia)
        {
            if (poligono == null || poligono.Count < 3 || distancia <= Tol)
                return poligono;

            try
            {
                List<P2> pts = new List<P2>(poligono);

                if (Area(pts) < 0.0)
                    pts.Reverse();

                int n = pts.Count;
                List<Linea2D> lineasOffset = new List<Linea2D>();

                for (int i = 0; i < n; i++)
                {
                    P2 a = pts[i];
                    P2 b = pts[(i + 1) % n];

                    double dx = b.X - a.X;
                    double dy = b.Y - a.Y;
                    double len = Math.Sqrt(dx * dx + dy * dy);

                    if (len <= Tol)
                        return null;

                    // Polígono CCW: el interior queda a la izquierda de cada lado.
                    double nx = -dy / len;
                    double ny = dx / len;

                    P2 ao = new P2(a.X + nx * distancia, a.Y + ny * distancia);
                    P2 bo = new P2(b.X + nx * distancia, b.Y + ny * distancia);
                    lineasOffset.Add(new Linea2D(ao, bo));
                }

                List<P2> resultado = new List<P2>();

                for (int i = 0; i < n; i++)
                {
                    Linea2D anterior = lineasOffset[(i - 1 + n) % n];
                    Linea2D actual = lineasOffset[i];

                    P2 inter;
                    if (!IntersectarLineasInfinitas(anterior, actual, out inter))
                        inter = actual.A;

                    if (inter == null)
                        return null;

                    resultado.Add(inter);
                }

                if (resultado.Count < 3 || Math.Abs(Area(resultado)) <= Tol)
                    return null;

                return resultado;
            }
            catch
            {
                return null;
            }
        }

        private class Linea2D
        {
            public P2 A;
            public P2 B;

            public Linea2D(P2 a, P2 b)
            {
                A = a;
                B = b;
            }
        }

        private bool IntersectarLineasInfinitas(Linea2D l1, Linea2D l2, out P2 inter)
        {
            inter = null;

            if (l1 == null || l2 == null || l1.A == null || l1.B == null || l2.A == null || l2.B == null)
                return false;

            double x1 = l1.A.X;
            double y1 = l1.A.Y;
            double x2 = l1.B.X;
            double y2 = l1.B.Y;
            double x3 = l2.A.X;
            double y3 = l2.A.Y;
            double x4 = l2.B.X;
            double y4 = l2.B.Y;

            double den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);

            if (Math.Abs(den) <= Tol)
                return false;

            double px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / den;
            double py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / den;

            if (double.IsNaN(px) || double.IsInfinity(px) || double.IsNaN(py) || double.IsInfinity(py))
                return false;

            inter = new P2(px, py);
            return true;
        }

        private Element CrearElementoNativoPorCategoria(
            Document doc,
            Element hostOriginal,
            ElementId tipoId,
            ElementId nivelId,
            CurveLoop loop)
        {
            if (doc == null || hostOriginal == null || tipoId == null || nivelId == null || loop == null)
                return null;

            try
            {
                IList<CurveLoop> loops = new List<CurveLoop>() { loop };

                if (hostOriginal is Floor)
                {
                    return Floor.Create(
                        doc,
                        loops,
                        tipoId,
                        nivelId);
                }

                if (hostOriginal is Ceiling)
                {
                    return Ceiling.Create(
                        doc,
                        loops,
                        tipoId,
                        nivelId);
                }
            }
            catch
            {
                // Se omite el mensaje por cada celda para evitar lentitud cuando
                // alguna pieza de borde no puede convertirse a boceto nativo.
            }

            return null;
        }

        private CurveLoop CrearCurveLoopHorizontal(
            List<P2> pts,
            XYZ origen,
            XYZ dirU,
            XYZ dirV,
            double zPerfil)
        {
            if (pts == null || pts.Count < 3)
                return null;

            try
            {
                CurveLoop loop = new CurveLoop();

                List<XYZ> puntos = new List<XYZ>();

                foreach (P2 p2 in pts)
                {
                    XYZ p = To3D(p2, origen, dirU, dirV);
                    puntos.Add(new XYZ(p.X, p.Y, zPerfil));
                }

                for (int i = 0; i < puntos.Count; i++)
                {
                    XYZ a = puntos[i];
                    XYZ b = puntos[(i + 1) % puntos.Count];

                    if (a.DistanceTo(b) <= Tol)
                        continue;

                    loop.Append(Line.CreateBound(a, b));
                }

                if (loop.IsOpen())
                    return null;

                return loop;
            }
            catch
            {
                return null;
            }
        }

        private double ObtenerOffsetNivel(Element e, double defecto)
        {
            if (e == null)
                return defecto;

            Parameter p = null;

            try
            {
                if (e is Floor)
                    p = e.get_Parameter(BuiltInParameter.FLOOR_HEIGHTABOVELEVEL_PARAM);
            }
            catch
            {
            }

            if (p == null)
            {
                try
                {
                    if (e is Ceiling)
                        p = e.get_Parameter(BuiltInParameter.CEILING_HEIGHTABOVELEVEL_PARAM);
                }
                catch
                {
                }
            }

            if (p != null && p.StorageType == StorageType.Double)
                return p.AsDouble();

            string[] nombres = new string[]
            {
                "Desfase de altura desde nivel",
                "Desfase de nivel",
                "Altura desde nivel",
                "Height Offset From Level",
                "Offset From Level"
            };

            foreach (string n in nombres)
            {
                try
                {
                    p = e.LookupParameter(n);
                    if (p != null && p.StorageType == StorageType.Double)
                        return p.AsDouble();
                }
                catch
                {
                }
            }

            return defecto;
        }

        private void SetOffsetNivel(Element e, double valor)
        {
            if (e == null)
                return;

            Parameter p = null;

            try
            {
                if (e is Floor)
                    p = e.get_Parameter(BuiltInParameter.FLOOR_HEIGHTABOVELEVEL_PARAM);
            }
            catch
            {
            }

            if (p == null)
            {
                try
                {
                    if (e is Ceiling)
                        p = e.get_Parameter(BuiltInParameter.CEILING_HEIGHTABOVELEVEL_PARAM);
                }
                catch
                {
                }
            }

            if (p != null && !p.IsReadOnly && p.StorageType == StorageType.Double)
            {
                try
                {
                    p.Set(valor);
                    return;
                }
                catch
                {
                }
            }

            SetParametroLongitudPorNombres(e, valor,
                "Desfase de altura desde nivel",
                "Desfase de nivel",
                "Altura desde nivel",
                "Height Offset From Level",
                "Offset From Level");
        }

        private void CopiarParametrosInstanciaCompatibles(Element origen, Element destino)
        {
            if (origen == null || destino == null)
                return;

            try
            {
                foreach (Parameter p0 in origen.Parameters)
                {
                    if (p0 == null || p0.Definition == null)
                        continue;

                    string nombre = p0.Definition.Name;

                    if (string.IsNullOrWhiteSpace(nombre))
                        continue;

                    Parameter p1 = destino.LookupParameter(nombre);

                    if (p1 == null || p1.IsReadOnly)
                        continue;

                    if (p0.StorageType != p1.StorageType)
                        continue;

                    try
                    {
                        if (p0.StorageType == StorageType.Double)
                            p1.Set(p0.AsDouble());
                        else if (p0.StorageType == StorageType.Integer)
                            p1.Set(p0.AsInteger());
                        else if (p0.StorageType == StorageType.String)
                            p1.Set(p0.AsString());
                        else if (p0.StorageType == StorageType.ElementId)
                        {
                            ElementId id = p0.AsElementId();
                            if (id != null)
                                p1.Set(id);
                        }
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }
        }

        private Solid CrearSolidoPrisma(
            List<P2> pts,
            XYZ origen,
            XYZ dirU,
            XYZ dirV,
            XYZ normal,
            double espesor)
        {
            if (pts == null || pts.Count < 3)
                return null;

            try
            {
                CurveLoop loop = new CurveLoop();

                for (int i = 0; i < pts.Count; i++)
                {
                    XYZ a = To3D(pts[i], origen, dirU, dirV);
                    XYZ b = To3D(pts[(i + 1) % pts.Count], origen, dirU, dirV);

                    if (a.DistanceTo(b) <= Tol)
                        continue;

                    loop.Append(Line.CreateBound(a, b));
                }

                if (loop.IsOpen())
                    return null;

                return GeometryCreationUtilities.CreateExtrusionGeometry(
                    new List<CurveLoop>() { loop },
                    normal,
                    espesor);
            }
            catch
            {
                return null;
            }
        }

        private FamilyInstance CrearPerfil(Document doc, FamilySymbol symbol, Level nivel, XYZ p0, XYZ p1)
        {
            if (doc == null || symbol == null || nivel == null || p0 == null || p1 == null)
                return null;

            if (p0.DistanceTo(p1) <= Tol)
                return null;

            try
            {
                Line linea = Line.CreateBound(p0, p1);

                FamilyInstance fi = doc.Create.NewFamilyInstance(
                    linea,
                    symbol,
                    nivel,
                    StructuralType.Beam);

                try
                {
                    LocationCurve loc = fi.Location as LocationCurve;
                    if (loc != null)
                        loc.Curve = linea;
                }
                catch
                {
                }

                AjustarDesfasesPerfilALaCurva(fi, nivel, p0, p1);
                ForzarParametrosPerfil(fi);

                return fi;
            }
            catch
            {
                return null;
            }
        }

        private void AjustarDesfasesPerfilALaCurva(FamilyInstance fi, Level nivel, XYZ p0, XYZ p1)
        {
            if (fi == null || nivel == null || p0 == null || p1 == null)
                return;

            double offsetInicial = p0.Z - nivel.Elevation;
            double offsetFinal = p1.Z - nivel.Elevation;

            SetParametroLongitudPorNombres(fi, offsetInicial,
                "Desfase de nivel inicial",
                "Start Level Offset",
                "z Offset Value");

            SetParametroLongitudPorNombres(fi, offsetFinal,
                "Desfase de nivel final",
                "End Level Offset",
                "z Offset Value");
        }

        private void ForzarParametrosPerfil(FamilyInstance fi)
        {
            if (fi == null)
                return;

            SetParametroLongitudPorNombres(fi, 0.0,
                "Reducción de junta inicial",
                "Reduccion de junta inicial",
                "Start Join Cutback");

            SetParametroLongitudPorNombres(fi, 0.0,
                "Reducción de junta final",
                "Reduccion de junta final",
                "End Join Cutback");

            SetParametroEnteroTextoPorNombres(fi, "Parte superior",
                "Justificación Z",
                "z Justification",
                "Z Justification");

            try
            {
                StructuralFramingUtils.DisallowJoinAtEnd(fi, 0);
                StructuralFramingUtils.DisallowJoinAtEnd(fi, 1);
            }
            catch
            {
            }
        }

        private double ObtenerAltoPerfil(FamilySymbol symbol)
        {
            if (symbol == null)
                return 0.0;

            double valor = 0.0;

            if (TryLeerParametroLongitud(symbol, out valor,
                "Alto",
                "ALTURA",
                "Altura",
                "Height",
                "HEIGHT",
                "h",
                "H"))
            {
                return valor;
            }

            try
            {
                foreach (Parameter p in symbol.Parameters)
                {
                    if (p == null || p.StorageType != StorageType.Double)
                        continue;

                    Definition def = p.Definition;
                    string nombre = def != null ? def.Name : "";
                    string n = NormalizarTexto(nombre);

                    // Coincidencia exacta/controlada para no confundirlo con "Height Offset"
                    // u otros parámetros que también contienen la palabra Height.
                    if (n == "ALTO" || n == "ALTURA" || n == "HEIGHT" || n == "H")
                    {
                        double v = p.AsDouble();

                        if (!double.IsNaN(v) && !double.IsInfinity(v) && v > Tol)
                            return v;
                    }
                }
            }
            catch
            {
            }

            return 0.0;
        }

        private bool TryLeerParametroLongitud(Element e, out double valor, params string[] nombres)
        {
            valor = 0.0;

            if (e == null || nombres == null)
                return false;

            foreach (string nombre in nombres)
            {
                if (string.IsNullOrWhiteSpace(nombre))
                    continue;

                try
                {
                    Parameter p = e.LookupParameter(nombre);

                    if (p == null || p.StorageType != StorageType.Double)
                        continue;

                    double v = p.AsDouble();

                    if (double.IsNaN(v) || double.IsInfinity(v) || v <= Tol)
                        continue;

                    valor = v;
                    return true;
                }
                catch
                {
                }
            }

            return false;
        }

        private bool SetParametroLongitudPorNombres(Element e, double valor, params string[] nombres)
        {
            if (e == null || nombres == null)
                return false;

            foreach (string nombre in nombres)
            {
                if (string.IsNullOrWhiteSpace(nombre))
                    continue;

                try
                {
                    Parameter p = e.LookupParameter(nombre);
                    if (p != null && !p.IsReadOnly && p.StorageType == StorageType.Double)
                    {
                        p.Set(valor);
                        return true;
                    }
                }
                catch
                {
                }
            }

            return false;
        }

        private bool SetParametroEnteroTextoPorNombres(Element e, string valorTexto, params string[] nombres)
        {
            if (e == null || nombres == null)
                return false;

            foreach (string nombre in nombres)
            {
                try
                {
                    Parameter p = e.LookupParameter(nombre);

                    if (p == null || p.IsReadOnly)
                        continue;

                    if (p.StorageType == StorageType.Integer)
                    {
                        // Revit suele usar 0/1/2 para justificación Z.
                        // Parte superior normalmente corresponde a 2, pero si la familia
                        // usa otro mapeo, Revit simplemente ignorará o mantendrá el valor.
                        p.Set(2);
                        return true;
                    }

                    if (p.StorageType == StorageType.String)
                    {
                        p.Set(valorTexto);
                        return true;
                    }
                }
                catch
                {
                }
            }

            return false;
        }

        // =========================================================
        // BÚSQUEDA DE CARA SUPERIOR PARA COLGADORES
        // =========================================================
        private class ImpactoSuperior
        {
            public ElementId ElementId;
            public Face Face;
            public Reference FaceReference;
            public XYZ Punto;
            public XYZ FaceNormal;
            public double DistanciaZ;
            public bool EsDeVinculo;
            public ElementId LinkInstanceId;
            public ElementId LinkedElementId;
        }

        private ImpactoSuperior BuscarCaraMasCercanaHaciaArriba(
            Document doc,
            XYZ puntoBase,
            double distanciaMaxima,
            HashSet<long> idsExcluir)
        {
            if (doc == null || puntoBase == null)
                return null;

            double tol = M(0.005);
            XYZ pInicio = puntoBase.Add(XYZ.BasisZ.Multiply(tol));
            XYZ pFin = puntoBase.Add(XYZ.BasisZ.Multiply(distanciaMaxima));

            if (pInicio.DistanceTo(pFin) <= tol)
                return null;

            Line lineaBusqueda = Line.CreateBound(pInicio, pFin);

            Options opciones = new Options();
            opciones.ComputeReferences = true;
            opciones.IncludeNonVisibleObjects = false;
            opciones.DetailLevel = ViewDetailLevel.Fine;

            try
            {
                if (doc.ActiveView != null && !doc.ActiveView.IsTemplate)
                    opciones.View = doc.ActiveView;
            }
            catch
            {
            }

            FilteredElementCollector collector;

            try
            {
                collector = new FilteredElementCollector(doc, doc.ActiveView.Id);
            }
            catch
            {
                collector = new FilteredElementCollector(doc);
            }

            ImpactoSuperior mejor = null;
            double mejorDistanciaZ = double.MaxValue;

            foreach (Element e in collector.WhereElementIsNotElementType().ToElements())
            {
                if (!EsElementoCandidatoParaCaraSuperior(e, idsExcluir))
                    continue;

                try
                {
                    GeometryElement ge = e.get_Geometry(opciones);
                    if (ge == null)
                        continue;

                    List<Solid> solidos = new List<Solid>();
                    RecolectarSolidos(ge, solidos, Transform.Identity);

                    foreach (Solid solid in solidos)
                    {
                        ImpactoSuperior impacto = BuscarImpactoEnSolido(
                            solid,
                            lineaBusqueda,
                            puntoBase,
                            tol,
                            mejorDistanciaZ,
                            e.Id,
                            false,
                            ElementId.InvalidElementId,
                            ElementId.InvalidElementId,
                            Transform.Identity,
                            null);

                        if (impacto != null && impacto.DistanciaZ < mejorDistanciaZ)
                        {
                            mejorDistanciaZ = impacto.DistanciaZ;
                            mejor = impacto;
                        }
                    }
                }
                catch
                {
                }
            }

            ImpactoSuperior impactoVinculo = BuscarCaraMasCercanaHaciaArribaEnVinculos(
                doc,
                pInicio,
                pFin,
                puntoBase,
                tol,
                mejorDistanciaZ);

            if (impactoVinculo != null && impactoVinculo.DistanciaZ < mejorDistanciaZ)
                mejor = impactoVinculo;

            return mejor;
        }

        private bool EsElementoCandidatoParaCaraSuperior(Element e, HashSet<long> idsExcluir)
        {
            if (e == null || e.Id == null)
                return false;

            try
            {
                if (idsExcluir != null && idsExcluir.Contains(e.Id.Value))
                    return false;
            }
            catch
            {
            }

            if (e is ElementType)
                return false;

            if (e is View || e is RevitLinkInstance)
                return false;

            try
            {
                if (e.Category == null || e.Category.CategoryType != CategoryType.Model)
                    return false;
            }
            catch
            {
                return false;
            }

            return true;
        }

        private ImpactoSuperior BuscarCaraMasCercanaHaciaArribaEnVinculos(
            Document doc,
            XYZ pInicioHost,
            XYZ pFinHost,
            XYZ puntoBaseHost,
            double tol,
            double mejorDistanciaActual)
        {
            if (doc == null || pInicioHost == null || pFinHost == null || puntoBaseHost == null)
                return null;

            ImpactoSuperior mejor = null;
            double mejorDistanciaZ = mejorDistanciaActual;

            List<RevitLinkInstance> vinculos = new FilteredElementCollector(doc)
                .OfClass(typeof(RevitLinkInstance))
                .Cast<RevitLinkInstance>()
                .ToList();

            foreach (RevitLinkInstance link in vinculos)
            {
                if (link == null || link.Id == null)
                    continue;

                Document linkDoc = null;

                try
                {
                    linkDoc = link.GetLinkDocument();
                }
                catch
                {
                    linkDoc = null;
                }

                if (linkDoc == null)
                    continue;

                Transform trLinkToHost;
                Transform trHostToLink;

                try
                {
                    trLinkToHost = link.GetTotalTransform();
                    if (trLinkToHost == null)
                        trLinkToHost = Transform.Identity;

                    trHostToLink = trLinkToHost.Inverse;
                }
                catch
                {
                    continue;
                }

                XYZ pInicioLink;
                XYZ pFinLink;

                try
                {
                    pInicioLink = trHostToLink.OfPoint(pInicioHost);
                    pFinLink = trHostToLink.OfPoint(pFinHost);
                }
                catch
                {
                    continue;
                }

                if (pInicioLink == null || pFinLink == null || pInicioLink.DistanceTo(pFinLink) <= tol)
                    continue;

                Line lineaLink;

                try
                {
                    lineaLink = Line.CreateBound(pInicioLink, pFinLink);
                }
                catch
                {
                    continue;
                }

                Options opciones = new Options();
                opciones.ComputeReferences = true;
                opciones.IncludeNonVisibleObjects = false;
                opciones.DetailLevel = ViewDetailLevel.Fine;

                List<Element> elementosLink;

                try
                {
                    elementosLink = new FilteredElementCollector(linkDoc)
                        .WhereElementIsNotElementType()
                        .ToElements()
                        .Where(x => EsElementoCandidatoLinkParaCaraSuperior(x))
                        .ToList();
                }
                catch
                {
                    continue;
                }

                foreach (Element eLink in elementosLink)
                {
                    try
                    {
                        GeometryElement ge = eLink.get_Geometry(opciones);
                        if (ge == null)
                            continue;

                        List<Solid> solidos = new List<Solid>();
                        RecolectarSolidos(ge, solidos, Transform.Identity);

                        foreach (Solid solid in solidos)
                        {
                            ImpactoSuperior impacto = BuscarImpactoEnSolido(
                                solid,
                                lineaLink,
                                trHostToLink.OfPoint(puntoBaseHost),
                                tol,
                                mejorDistanciaZ,
                                eLink.Id,
                                true,
                                link.Id,
                                eLink.Id,
                                trLinkToHost,
                                link);

                            if (impacto != null && impacto.DistanciaZ < mejorDistanciaZ)
                            {
                                mejorDistanciaZ = impacto.DistanciaZ;
                                mejor = impacto;
                            }
                        }
                    }
                    catch
                    {
                    }
                }
            }

            return mejor;
        }

        private bool EsElementoCandidatoLinkParaCaraSuperior(Element e)
        {
            if (e == null || e is ElementType || e is View)
                return false;

            try
            {
                if (e.Category == null || e.Category.CategoryType != CategoryType.Model)
                    return false;
            }
            catch
            {
                return false;
            }

            return true;
        }

        private ImpactoSuperior BuscarImpactoEnSolido(
            Solid solid,
            Line lineaBusqueda,
            XYZ puntoBase,
            double tol,
            double mejorDistanciaActual,
            ElementId elementId,
            bool esVinculo,
            ElementId linkInstanceId,
            ElementId linkedElementId,
            Transform trLocalAHost,
            RevitLinkInstance linkInstance)
        {
            if (solid == null || solid.Faces == null || solid.Faces.Size == 0 || lineaBusqueda == null || puntoBase == null)
                return null;

            ImpactoSuperior mejor = null;
            double mejorDistanciaZ = mejorDistanciaActual;

            foreach (Face face in solid.Faces)
            {
                if (face == null)
                    continue;

                try
                {
                    IntersectionResultArray resultados;
                    SetComparisonResult comparacion = face.Intersect(lineaBusqueda, out resultados);

                    if (resultados == null || resultados.Size == 0)
                        continue;

                    for (int i = 0; i < resultados.Size; i++)
                    {
                        IntersectionResult ir = resultados.get_Item(i);

                        if (ir == null || ir.XYZPoint == null)
                            continue;

                        XYZ puntoLocal = ir.XYZPoint;
                        XYZ puntoHost = esVinculo && trLocalAHost != null
                            ? trLocalAHost.OfPoint(puntoLocal)
                            : puntoLocal;

                        XYZ puntoBaseHost = esVinculo && trLocalAHost != null
                            ? trLocalAHost.OfPoint(puntoBase)
                            : puntoBase;

                        double dz = puntoHost.Z - puntoBaseHost.Z;

                        if (dz <= tol || dz >= mejorDistanciaZ)
                            continue;

                        XYZ normalFace = ObtenerNormalCaraEnPunto(face, ir);

                        if (esVinculo && normalFace != null && trLocalAHost != null)
                            normalFace = trLocalAHost.OfVector(normalFace).Normalize();

                        Reference refCara = null;

                        try
                        {
                            refCara = face.Reference;

                            if (esVinculo && refCara != null && linkInstance != null)
                                refCara = refCara.CreateLinkReference(linkInstance);
                        }
                        catch
                        {
                            refCara = null;
                        }

                        mejorDistanciaZ = dz;
                        mejor = new ImpactoSuperior();
                        mejor.ElementId = elementId;
                        mejor.Face = esVinculo ? null : face;
                        mejor.FaceReference = refCara;
                        mejor.Punto = puntoHost;
                        mejor.FaceNormal = normalFace;
                        mejor.DistanciaZ = dz;
                        mejor.EsDeVinculo = esVinculo;
                        mejor.LinkInstanceId = linkInstanceId;
                        mejor.LinkedElementId = linkedElementId;
                    }
                }
                catch
                {
                }
            }

            return mejor;
        }

        private XYZ ObtenerNormalCaraEnPunto(Face face, IntersectionResult ir)
        {
            if (face == null)
                return XYZ.BasisZ;

            try
            {
                if (ir != null && ir.UVPoint != null)
                    return face.ComputeNormal(ir.UVPoint).Normalize();
            }
            catch
            {
            }

            try
            {
                PlanarFace pf = face as PlanarFace;
                if (pf != null && pf.FaceNormal != null)
                    return pf.FaceNormal.Normalize();
            }
            catch
            {
            }

            return XYZ.BasisZ;
        }

        private void RecolectarSolidos(GeometryElement ge, List<Solid> solidos, Transform transform)
        {
            if (ge == null || solidos == null)
                return;

            foreach (GeometryObject go in ge)
            {
                if (go == null)
                    continue;

                Solid solid = go as Solid;

                if (solid != null && solid.Faces != null && solid.Faces.Size > 0 && solid.Volume > 1e-9)
                {
                    try
                    {
                        if (transform != null && !transform.IsIdentity)
                            solid = SolidUtils.CreateTransformed(solid, transform);
                    }
                    catch
                    {
                    }

                    solidos.Add(solid);
                    continue;
                }

                GeometryInstance gi = go as GeometryInstance;

                if (gi != null)
                {
                    try
                    {
                        Transform tr = transform == null ? gi.Transform : transform.Multiply(gi.Transform);
                        GeometryElement inst = gi.GetInstanceGeometry();
                        RecolectarSolidos(inst, solidos, tr);
                    }
                    catch
                    {
                    }
                }
            }
        }

        // =========================================================
        // RECORTE NATIVO DE ARMAZÓN ESTRUCTURAL EN INTERSECCIONES
        // =========================================================
        private int AplicarRecorteNativoEnIntersecciones(Document doc, List<PerfilCreado> perfiles)
        {
            if (doc == null || perfiles == null || perfiles.Count < 2)
                return 0;

            int aplicados = 0;
            double toleranciaBounding = M(0.15);
            double toleranciaCruce = M(0.08);

            for (int i = 0; i < perfiles.Count; i++)
            {
                PerfilCreado pa = perfiles[i];
                FamilyInstance a = pa != null ? pa.Instancia : null;

                if (!EsInstanciaArmazonEstructural(a))
                    continue;

                for (int j = i + 1; j < perfiles.Count; j++)
                {
                    PerfilCreado pb = perfiles[j];
                    FamilyInstance b = pb != null ? pb.Instancia : null;

                    if (!EsInstanciaArmazonEstructural(b))
                        continue;

                    if (!BoundingBoxesIntersectan(a, b, toleranciaBounding))
                        continue;

                    if (!CurvasSeCruzanOSeTocanEnProyeccion(a, b, toleranciaCruce))
                        continue;

                    FamilyInstance elementoARecortar;
                    FamilyInstance elementoCortante;
                    ElegirElementoRecorte(pa, pb, out elementoARecortar, out elementoCortante);

                    if (elementoARecortar == null || elementoCortante == null)
                        continue;

                    bool ok = IntentarAplicarCopingNativo(doc, elementoARecortar, elementoCortante);

                    if (!ok)
                    {
                        // Respaldo: si Revit no acepta el orden elegido, prueba el orden inverso.
                        // Esto ayuda con algunas familias de armazón estructural.
                        ok = IntentarAplicarCopingNativo(doc, elementoCortante, elementoARecortar);
                    }

                    if (ok)
                        aplicados++;
                }
            }

            return aplicados;
        }

        private void ElegirElementoRecorte(PerfilCreado a, PerfilCreado b, out FamilyInstance elementoARecortar, out FamilyInstance elementoCortante)
        {
            elementoARecortar = null;
            elementoCortante = null;

            if (a == null || b == null)
                return;

            int pa = PrioridadPerfilParaRecorte(a);
            int pb = PrioridadPerfilParaRecorte(b);

            // Mayor prioridad = pasa completo. Menor prioridad = recibe el recorte.
            // Perimetral debe cortar a interiores para que el marco no se afecte.
            if (pa > pb)
            {
                elementoCortante = a.Instancia;
                elementoARecortar = b.Instancia;
                return;
            }

            if (pb > pa)
            {
                elementoCortante = b.Instancia;
                elementoARecortar = a.Instancia;
                return;
            }

            long ida = a.Instancia != null && a.Instancia.Id != null ? a.Instancia.Id.Value : 0;
            long idb = b.Instancia != null && b.Instancia.Id != null ? b.Instancia.Id.Value : 0;

            if (ida > idb)
            {
                elementoARecortar = a.Instancia;
                elementoCortante = b.Instancia;
            }
            else
            {
                elementoARecortar = b.Instancia;
                elementoCortante = a.Instancia;
            }
        }

        private int PrioridadPerfilParaRecorte(PerfilCreado perfil)
        {
            string rol = perfil != null ? (perfil.Rol ?? "") : "";
            rol = NormalizarTexto(rol);

            if (rol.Contains("PERIMETRAL") || rol.Contains("MARCO"))
                return 300;

            if (rol.Contains("INTERIOR") || rol.Contains("PRINCIPAL"))
                return 100;

            return 50;
        }

        private bool IntentarAplicarCopingNativo(Document doc, FamilyInstance elementoARecortar, FamilyInstance elementoCortante)
        {
            if (doc == null || elementoARecortar == null || elementoCortante == null)
                return false;

            if (elementoARecortar.Id.Value == elementoCortante.Id.Value)
                return false;

            try
            {
                if (YaTieneCopingCon(elementoARecortar, elementoCortante))
                {
                    SetDistanciaRecorteCero(elementoARecortar);
                    ForzarParametrosPerfil(elementoARecortar);
                    return true;
                }
            }
            catch
            {
            }

            SetDistanciaRecorteCero(elementoARecortar);
            ForzarParametrosPerfil(elementoARecortar);

            bool aplicado = InvocarAddCopingDesdeFamilyInstance(doc, elementoARecortar, elementoCortante);

            if (!aplicado)
                return false;

            try
            {
                doc.Regenerate();
            }
            catch
            {
            }

            SetDistanciaRecorteCero(elementoARecortar);
            ForzarParametrosPerfil(elementoARecortar);

            return true;
        }

        private bool InvocarAddCopingDesdeFamilyInstance(Document doc, FamilyInstance elementoARecortar, FamilyInstance elementoCortante)
        {
            if (doc == null || elementoARecortar == null || elementoCortante == null)
                return false;

            try
            {
                System.Reflection.MethodInfo[] metodos = typeof(FamilyInstance).GetMethods(
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance);

                foreach (System.Reflection.MethodInfo metodo in metodos)
                {
                    if (metodo == null || metodo.Name != "AddCoping")
                        continue;

                    System.Reflection.ParameterInfo[] ps = metodo.GetParameters();
                    object[] args;

                    if (!ConstruirArgumentosAddCopingFamilyInstance(ps, doc, elementoARecortar, elementoCortante, out args))
                        continue;

                    try
                    {
                        object resultado = metodo.Invoke(elementoARecortar, args);

                        if (metodo.ReturnType == typeof(bool))
                        {
                            bool ok = resultado != null && (bool)resultado;
                            if (!ok)
                                continue;
                        }

                        return true;
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }

            return false;
        }

        private bool ConstruirArgumentosAddCopingFamilyInstance(System.Reflection.ParameterInfo[] parametros, Document doc, FamilyInstance elementoARecortar, FamilyInstance elementoCortante, out object[] args)
        {
            args = null;

            if (parametros == null)
                return false;

            object[] temp = new object[parametros.Length];
            bool tieneCortante = false;

            for (int i = 0; i < parametros.Length; i++)
            {
                Type pt = parametros[i].ParameterType;

                if (pt == typeof(Document))
                {
                    temp[i] = doc;
                    continue;
                }

                if (pt == typeof(FamilyInstance) || pt.IsAssignableFrom(typeof(FamilyInstance)))
                {
                    temp[i] = elementoCortante;
                    tieneCortante = true;
                    continue;
                }

                if (pt == typeof(Element) || pt.IsAssignableFrom(typeof(Element)))
                {
                    temp[i] = (Element)elementoCortante;
                    tieneCortante = true;
                    continue;
                }

                if (pt == typeof(ElementId))
                {
                    temp[i] = elementoCortante.Id;
                    tieneCortante = true;
                    continue;
                }

                if (pt == typeof(double))
                {
                    temp[i] = 0.0;
                    continue;
                }

                if (pt == typeof(int))
                {
                    temp[i] = 0;
                    continue;
                }

                if (pt == typeof(bool))
                {
                    temp[i] = false;
                    continue;
                }

                return false;
            }

            if (!tieneCortante)
                return false;

            args = temp;
            return true;
        }

        private bool YaTieneCopingCon(FamilyInstance elementoARecortar, FamilyInstance elementoCortante)
        {
            if (elementoARecortar == null || elementoCortante == null)
                return false;

            try
            {
                System.Reflection.MethodInfo[] metodos = typeof(FamilyInstance).GetMethods(
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance);

                foreach (System.Reflection.MethodInfo metodo in metodos)
                {
                    if (metodo == null)
                        continue;

                    string nombre = metodo.Name;

                    if (nombre != "GetCopingIds" && nombre != "GetCopingCuttingElementIds" && nombre != "GetCopingElementIds")
                        continue;

                    object resultado = metodo.Invoke(elementoARecortar, null);
                    System.Collections.IEnumerable enumerable = resultado as System.Collections.IEnumerable;

                    if (enumerable == null)
                        continue;

                    foreach (object obj in enumerable)
                    {
                        ElementId id = obj as ElementId;
                        if (id != null && id.Value == elementoCortante.Id.Value)
                            return true;
                    }
                }
            }
            catch
            {
            }

            return false;
        }

        private void SetDistanciaRecorteCero(FamilyInstance fi)
        {
            if (fi == null)
                return;

            SetParametroLongitudPorNombres(fi, 0.0,
                "Distancia de recorte",
                "Distancia recorte",
                "Coping Distance",
                "Cope Distance",
                "Coping Offset",
                "Cope Offset",
                "Cutback Distance");

            InvocarSetCopingDistanceFamilyInstance(fi);
        }

        private void InvocarSetCopingDistanceFamilyInstance(FamilyInstance fi)
        {
            if (fi == null)
                return;

            try
            {
                System.Reflection.MethodInfo[] metodos = typeof(FamilyInstance).GetMethods(
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.Instance);

                foreach (System.Reflection.MethodInfo metodo in metodos)
                {
                    if (metodo == null || metodo.Name != "SetCopingDistance")
                        continue;

                    object[] args;

                    if (!ConstruirArgumentosSetCopingDistanceFamilyInstance(metodo.GetParameters(), fi, out args))
                        continue;

                    try
                    {
                        metodo.Invoke(fi, args);
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }
        }

        private bool ConstruirArgumentosSetCopingDistanceFamilyInstance(System.Reflection.ParameterInfo[] parametros, FamilyInstance fi, out object[] args)
        {
            args = null;

            if (parametros == null || fi == null)
                return false;

            object[] temp = new object[parametros.Length];
            bool tieneDistancia = false;

            for (int i = 0; i < parametros.Length; i++)
            {
                Type pt = parametros[i].ParameterType;

                if (pt == typeof(Document))
                {
                    temp[i] = fi.Document;
                    continue;
                }

                if (pt == typeof(ElementId))
                {
                    temp[i] = fi.Id;
                    continue;
                }

                if (pt == typeof(Element) || pt.IsAssignableFrom(typeof(Element)))
                {
                    temp[i] = (Element)fi;
                    continue;
                }

                if (pt == typeof(FamilyInstance) || pt.IsAssignableFrom(typeof(FamilyInstance)))
                {
                    temp[i] = fi;
                    continue;
                }

                if (pt == typeof(double))
                {
                    temp[i] = 0.0;
                    tieneDistancia = true;
                    continue;
                }

                return false;
            }

            if (!tieneDistancia)
                return false;

            args = temp;
            return true;
        }

        private bool EsInstanciaArmazonEstructural(FamilyInstance fi)
        {
            if (fi == null || fi.Category == null)
                return false;

            try
            {
                if (fi.Category.Id.Value == (long)BuiltInCategory.OST_StructuralFraming)
                    return true;
            }
            catch
            {
            }

            string cat = NormalizarTexto(fi.Category.Name);
            return cat.Contains("ARMAZON_ESTRUCTURAL") || cat.Contains("STRUCTURAL_FRAMING") || cat.Contains("STRUCTURALFRAMING");
        }

        private bool BoundingBoxesIntersectan(Element a, Element b, double tol)
        {
            if (a == null || b == null)
                return false;

            BoundingBoxXYZ ba = null;
            BoundingBoxXYZ bb = null;

            try
            {
                ba = a.get_BoundingBox(null);
                bb = b.get_BoundingBox(null);
            }
            catch
            {
                return false;
            }

            if (ba == null || bb == null)
                return false;

            if ((ba.Max.X + tol) < (bb.Min.X - tol)) return false;
            if ((bb.Max.X + tol) < (ba.Min.X - tol)) return false;
            if ((ba.Max.Y + tol) < (bb.Min.Y - tol)) return false;
            if ((bb.Max.Y + tol) < (ba.Min.Y - tol)) return false;
            if ((ba.Max.Z + tol) < (bb.Min.Z - tol)) return false;
            if ((bb.Max.Z + tol) < (ba.Min.Z - tol)) return false;

            return true;
        }

        private bool CurvasSeCruzanOSeTocanEnProyeccion(FamilyInstance a, FamilyInstance b, double tol)
        {
            Curve ca = ObtenerCurvaUbicacion(a);
            Curve cb = ObtenerCurvaUbicacion(b);

            if (ca == null || cb == null)
                return true;

            XYZ a1 = ca.GetEndPoint(0);
            XYZ a2 = ca.GetEndPoint(1);
            XYZ b1 = cb.GetEndPoint(0);
            XYZ b2 = cb.GetEndPoint(1);

            if (Segmentos2DIntersectan(a1, a2, b1, b2, tol))
                return true;

            double d1 = DistanciaPuntoSegmento2D(a1, b1, b2);
            double d2 = DistanciaPuntoSegmento2D(a2, b1, b2);
            double d3 = DistanciaPuntoSegmento2D(b1, a1, a2);
            double d4 = DistanciaPuntoSegmento2D(b2, a1, a2);

            return Math.Min(Math.Min(d1, d2), Math.Min(d3, d4)) <= tol;
        }

        private Curve ObtenerCurvaUbicacion(Element e)
        {
            try
            {
                LocationCurve loc = e != null ? e.Location as LocationCurve : null;
                if (loc != null)
                    return loc.Curve;
            }
            catch
            {
            }

            return null;
        }

        private bool Segmentos2DIntersectan(XYZ a1, XYZ a2, XYZ b1, XYZ b2, double tol)
        {
            double x1 = a1.X;
            double y1 = a1.Y;
            double x2 = a2.X;
            double y2 = a2.Y;
            double x3 = b1.X;
            double y3 = b1.Y;
            double x4 = b2.X;
            double y4 = b2.Y;

            double den = ((x1 - x2) * (y3 - y4)) - ((y1 - y2) * (x3 - x4));

            if (Math.Abs(den) < 1e-12)
                return DistanciaSegmentoSegmento2D(a1, a2, b1, b2) <= tol;

            double px = (((x1 * y2) - (y1 * x2)) * (x3 - x4) - (x1 - x2) * ((x3 * y4) - (y3 * x4))) / den;
            double py = (((x1 * y2) - (y1 * x2)) * (y3 - y4) - (y1 - y2) * ((x3 * y4) - (y3 * x4))) / den;

            return
                px >= Math.Min(x1, x2) - tol && px <= Math.Max(x1, x2) + tol &&
                py >= Math.Min(y1, y2) - tol && py <= Math.Max(y1, y2) + tol &&
                px >= Math.Min(x3, x4) - tol && px <= Math.Max(x3, x4) + tol &&
                py >= Math.Min(y3, y4) - tol && py <= Math.Max(y3, y4) + tol;
        }

        private double DistanciaSegmentoSegmento2D(XYZ a1, XYZ a2, XYZ b1, XYZ b2)
        {
            double d1 = DistanciaPuntoSegmento2D(a1, b1, b2);
            double d2 = DistanciaPuntoSegmento2D(a2, b1, b2);
            double d3 = DistanciaPuntoSegmento2D(b1, a1, a2);
            double d4 = DistanciaPuntoSegmento2D(b2, a1, a2);
            return Math.Min(Math.Min(d1, d2), Math.Min(d3, d4));
        }

        private double DistanciaPuntoSegmento2D(XYZ p, XYZ a, XYZ b)
        {
            double vx = b.X - a.X;
            double vy = b.Y - a.Y;
            double wx = p.X - a.X;
            double wy = p.Y - a.Y;
            double c1 = (wx * vx) + (wy * vy);

            if (c1 <= 0.0)
                return Math.Sqrt((p.X - a.X) * (p.X - a.X) + (p.Y - a.Y) * (p.Y - a.Y));

            double c2 = (vx * vx) + (vy * vy);

            if (c2 <= 1e-12)
                return Math.Sqrt((p.X - a.X) * (p.X - a.X) + (p.Y - a.Y) * (p.Y - a.Y));

            if (c2 <= c1)
                return Math.Sqrt((p.X - b.X) * (p.X - b.X) + (p.Y - b.Y) * (p.Y - b.Y));

            double t = c1 / c2;
            double qx = a.X + (t * vx);
            double qy = a.Y + (t * vy);
            return Math.Sqrt((p.X - qx) * (p.X - qx) + (p.Y - qy) * (p.Y - qy));
        }

        private string NormalizarTexto(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return "";

            string s = texto.ToUpperInvariant();
            s = s.Replace("Á", "A").Replace("É", "E").Replace("Í", "I").Replace("Ó", "O").Replace("Ú", "U");
            s = s.Replace("Ñ", "N");
            s = s.Replace(" ", "_");
            return s;
        }

        // =========================================================
        // GEOMETRÍA 2D
        // =========================================================
        private List<P2> ObtenerPoligonoPrincipal2D(PlanarFace face, XYZ origen, XYZ dirU, XYZ dirV)
        {
            List<List<P2>> loops = new List<List<P2>>();

            try
            {
                IList<CurveLoop> curveLoops = face.GetEdgesAsCurveLoops();

                foreach (CurveLoop cl in curveLoops)
                {
                    List<P2> pts = new List<P2>();

                    foreach (Curve c in cl)
                    {
                        IList<XYZ> tess = c.Tessellate();

                        foreach (XYZ p in tess)
                        {
                            P2 pp = To2D(p, origen, dirU, dirV);
                            AgregarPunto2D(pts, pp);
                        }
                    }

                    pts = LimpiarPoligono(pts);

                    if (pts.Count >= 3)
                        loops.Add(pts);
                }
            }
            catch
            {
            }

            if (loops.Count == 0)
                return new List<P2>();

            return loops
                .OrderByDescending(l => Math.Abs(Area(l)))
                .First();
        }

        private void AgregarPunto2D(List<P2> pts, P2 p)
        {
            if (pts == null || p == null)
                return;

            if (pts.Count > 0 && Distancia(pts[pts.Count - 1], p) <= Tol)
                return;

            pts.Add(p);
        }

        private List<P2> LimpiarPoligono(List<P2> pts)
        {
            if (pts == null)
                return new List<P2>();

            List<P2> res = new List<P2>();

            foreach (P2 p in pts)
                AgregarPunto2D(res, p);

            if (res.Count > 1 && Distancia(res[0], res[res.Count - 1]) <= Tol)
                res.RemoveAt(res.Count - 1);

            return res;
        }

        private List<Intervalo> InterseccionesHorizontal(List<P2> poly, double y)
        {
            List<double> xs = new List<double>();

            for (int i = 0; i < poly.Count; i++)
            {
                P2 a = poly[i];
                P2 b = poly[(i + 1) % poly.Count];

                if (Math.Abs(a.Y - b.Y) <= Tol)
                    continue;

                bool cruza = (a.Y <= y && b.Y > y) || (b.Y <= y && a.Y > y);

                if (!cruza)
                    continue;

                double t = (y - a.Y) / (b.Y - a.Y);
                double x = a.X + t * (b.X - a.X);
                xs.Add(x);
            }

            xs.Sort();
            return ConstruirIntervalos(xs);
        }

        private List<Intervalo> InterseccionesVertical(List<P2> poly, double x)
        {
            List<double> ys = new List<double>();

            for (int i = 0; i < poly.Count; i++)
            {
                P2 a = poly[i];
                P2 b = poly[(i + 1) % poly.Count];

                if (Math.Abs(a.X - b.X) <= Tol)
                    continue;

                bool cruza = (a.X <= x && b.X > x) || (b.X <= x && a.X > x);

                if (!cruza)
                    continue;

                double t = (x - a.X) / (b.X - a.X);
                double y = a.Y + t * (b.Y - a.Y);
                ys.Add(y);
            }

            ys.Sort();
            return ConstruirIntervalos(ys);
        }

        private List<Intervalo> ConstruirIntervalos(List<double> valores)
        {
            List<Intervalo> res = new List<Intervalo>();

            if (valores == null || valores.Count < 2)
                return res;

            List<double> limpios = new List<double>();

            foreach (double v in valores)
            {
                if (limpios.Count == 0 || Math.Abs(limpios[limpios.Count - 1] - v) > Tol)
                    limpios.Add(v);
            }

            for (int i = 0; i + 1 < limpios.Count; i += 2)
            {
                if (Math.Abs(limpios[i + 1] - limpios[i]) > Tol)
                    res.Add(new Intervalo(limpios[i], limpios[i + 1]));
            }

            return res;
        }


        private List<P2> ClipPoligonoPorRectangulo(
            List<P2> poligonoOriginal,
            double minX,
            double minY,
            double maxX,
            double maxY)
        {
            if (poligonoOriginal == null || poligonoOriginal.Count < 3)
                return new List<P2>();

            if (maxX <= minX + Tol || maxY <= minY + Tol)
                return new List<P2>();

            // V52:
            // Para caras en L o contornos irregulares, NO se debe recortar el rectángulo
            // contra el polígono como si el polígono fuera convexo. Se hace al revés:
            // se recorta el polígono real de la cara contra cada rectángulo de módulo.
            // El rectángulo sí es convexo, por eso Sutherland-Hodgman es estable.
            List<P2> output = poligonoOriginal.Select(p => new P2(p.X, p.Y)).ToList();

            output = ClipContraLimiteRectangular(output, 0, minX); // x >= minX
            output = ClipContraLimiteRectangular(output, 1, maxX); // x <= maxX
            output = ClipContraLimiteRectangular(output, 2, minY); // y >= minY
            output = ClipContraLimiteRectangular(output, 3, maxY); // y <= maxY

            return LimpiarPoligono(output);
        }

        private List<P2> ClipContraLimiteRectangular(List<P2> input, int tipoLimite, double valor)
        {
            List<P2> output = new List<P2>();

            if (input == null || input.Count == 0)
                return output;

            P2 s = input[input.Count - 1];
            bool sInside = DentroLimiteRectangular(s, tipoLimite, valor);

            foreach (P2 e in input)
            {
                bool eInside = DentroLimiteRectangular(e, tipoLimite, valor);

                if (eInside)
                {
                    if (!sInside)
                    {
                        P2 inter = InterseccionSegmentoConLimiteRectangular(s, e, tipoLimite, valor);
                        if (inter != null)
                            output.Add(inter);
                    }

                    output.Add(e);
                }
                else if (sInside)
                {
                    P2 inter = InterseccionSegmentoConLimiteRectangular(s, e, tipoLimite, valor);
                    if (inter != null)
                        output.Add(inter);
                }

                s = e;
                sInside = eInside;
            }

            return output;
        }

        private bool DentroLimiteRectangular(P2 p, int tipoLimite, double valor)
        {
            if (p == null)
                return false;

            switch (tipoLimite)
            {
                case 0: return p.X >= valor - Tol; // izquierda
                case 1: return p.X <= valor + Tol; // derecha
                case 2: return p.Y >= valor - Tol; // abajo
                case 3: return p.Y <= valor + Tol; // arriba
            }

            return false;
        }

        private P2 InterseccionSegmentoConLimiteRectangular(P2 a, P2 b, int tipoLimite, double valor)
        {
            if (a == null || b == null)
                return null;

            double dx = b.X - a.X;
            double dy = b.Y - a.Y;
            double t = 0.0;

            if (tipoLimite == 0 || tipoLimite == 1)
            {
                if (Math.Abs(dx) <= Tol)
                    return new P2(valor, a.Y);

                t = (valor - a.X) / dx;
                return new P2(valor, a.Y + t * dy);
            }

            if (Math.Abs(dy) <= Tol)
                return new P2(a.X, valor);

            t = (valor - a.Y) / dy;
            return new P2(a.X + t * dx, valor);
        }

        private List<P2> ClipPolygonConvex(List<P2> subject, List<P2> clip)
        {
            if (subject == null || clip == null || subject.Count < 3 || clip.Count < 3)
                return new List<P2>();

            List<P2> output = subject.Select(p => new P2(p.X, p.Y)).ToList();

            if (Area(clip) < 0.0)
                clip = clip.AsEnumerable().Reverse().ToList();

            for (int i = 0; i < clip.Count; i++)
            {
                P2 a = clip[i];
                P2 b = clip[(i + 1) % clip.Count];

                List<P2> input = output;
                output = new List<P2>();

                if (input.Count == 0)
                    break;

                P2 s = input[input.Count - 1];

                foreach (P2 e in input)
                {
                    bool eInside = Inside(a, b, e);
                    bool sInside = Inside(a, b, s);

                    if (eInside)
                    {
                        if (!sInside)
                            output.Add(InterseccionLineas(s, e, a, b));

                        output.Add(e);
                    }
                    else if (sInside)
                    {
                        output.Add(InterseccionLineas(s, e, a, b));
                    }

                    s = e;
                }
            }

            return LimpiarPoligono(output);
        }

        private bool Inside(P2 a, P2 b, P2 p)
        {
            return Cross(b.X - a.X, b.Y - a.Y, p.X - a.X, p.Y - a.Y) >= -Tol;
        }

        private P2 InterseccionLineas(P2 p1, P2 p2, P2 a, P2 b)
        {
            double x1 = p1.X;
            double y1 = p1.Y;
            double x2 = p2.X;
            double y2 = p2.Y;
            double x3 = a.X;
            double y3 = a.Y;
            double x4 = b.X;
            double y4 = b.Y;

            double den = (x1 - x2) * (y3 - y4) -
                         (y1 - y2) * (x3 - x4);

            if (Math.Abs(den) <= Tol)
                return new P2(p2.X, p2.Y);

            double px = ((x1 * y2 - y1 * x2) * (x3 - x4) -
                         (x1 - x2) * (x3 * y4 - y3 * x4)) / den;

            double py = ((x1 * y2 - y1 * x2) * (y3 - y4) -
                         (y1 - y2) * (x3 * y4 - y3 * x4)) / den;

            return new P2(px, py);
        }

        private static double Cross(double ax, double ay, double bx, double by)
        {
            return ax * by - ay * bx;
        }

        private double Area(List<P2> pts)
        {
            if (pts == null || pts.Count < 3)
                return 0.0;

            double a = 0.0;

            for (int i = 0; i < pts.Count; i++)
            {
                P2 p = pts[i];
                P2 q = pts[(i + 1) % pts.Count];
                a += p.X * q.Y - q.X * p.Y;
            }

            return a * 0.5;
        }

        private double Distancia(P2 a, P2 b)
        {
            if (a == null || b == null)
                return 0.0;

            double dx = a.X - b.X;
            double dy = a.Y - b.Y;

            return Math.Sqrt(dx * dx + dy * dy);
        }

        private P2 To2D(XYZ p, XYZ origen, XYZ dirU, XYZ dirV)
        {
            XYZ v = p - origen;
            return new P2(v.DotProduct(dirU), v.DotProduct(dirV));
        }

        private XYZ To3D(P2 p, XYZ origen, XYZ dirU, XYZ dirV)
        {
            return origen
                .Add(dirU.Multiply(p.X))
                .Add(dirV.Multiply(p.Y));
        }

        private XYZ ProyectarEnPlano(XYZ v, XYZ normal)
        {
            if (v == null || normal == null)
                return XYZ.Zero;

            return v - normal.Multiply(v.DotProduct(normal));
        }

        private double M(double metros)
        {
            return UnitUtils.ConvertToInternalUnits(
                metros,
                UnitTypeId.Meters);
        }

        private Level ObtenerNivelMasCercano(Document doc, double z)
        {
            return new FilteredElementCollector(doc)
                .OfClass(typeof(Level))
                .Cast<Level>()
                .OrderBy(l => Math.Abs(l.Elevation - z))
                .FirstOrDefault();
        }
    }
}
