using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // VENTANA - MUROS POR CONTORNO DE ESTRUCTURA VINCULADA
    // =====================================

    public class CrearMurosContornoEstructuraForm : WinForms.Form
    {
        // =========================================================
        // ENUM INTERNO
        // =========================================================

        public enum MurosContornoEstructuraAccion
        {
            Ninguna,
            SeleccionarElementosVinculados,
            CrearMuros
        }

        // =========================================================
        // VARIABLES
        // =========================================================

        private UIDocument _uidoc;
        private Document _doc;

        private WinForms.Label lblElementosSeleccionados;
        private WinForms.Label lblResultado;
        private WinForms.Label lblInfo;
        private WinForms.Label lblTipoMuro;
        private WinForms.Label lblOpciones;

        private WinForms.ComboBox cmbTipoMuro;
        private WinForms.CheckBox chkEvitarDuplicados;

        private WinForms.Button btnSeleccionarElementos;
        private WinForms.Button btnCrearMuros;
        private WinForms.Button btnCerrar;

        private List<WallTypeItemMYG> _tiposMuro = new List<WallTypeItemMYG>();
        private string _ultimoResultado = "";

        public ExternalEvent EjecutarEvent;
        public EjecutarMurosContornoEstructuraHandler Handler;

        public List<ElementoEstructuraVinculadoMYG> ElementosSeleccionados { get; set; }

        public ElementId TipoMuroSeleccionadoId
        {
            get
            {
                if (cmbTipoMuro == null)
                    return ElementId.InvalidElementId;

                WallTypeItemMYG item = cmbTipoMuro.SelectedItem as WallTypeItemMYG;

                if (item != null && item.Id != null)
                    return item.Id;

                return ElementId.InvalidElementId;
            }
        }

        public bool EvitarDuplicados
        {
            get
            {
                if (chkEvitarDuplicados == null)
                    return true;

                return chkEvitarDuplicados.Checked;
            }
        }

        public CrearMurosContornoEstructuraForm(UIDocument uidoc)
        {
            _uidoc = uidoc;
            _doc = uidoc.Document;

            ElementosSeleccionados = new List<ElementoEstructuraVinculadoMYG>();

            this.Text = "🏗 Muros por Contorno de Estructura Vinculada";
            this.Width = 640;
            this.Height = 455;
            this.MinimumSize = new Drawing.Size(640, 455);
            this.MaximumSize = new Drawing.Size(640, 455);
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;
            this.AutoScaleMode = WinForms.AutoScaleMode.Dpi;

            WinForms.Label lblAutor = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                Left = 20,
                Top = 8,
                Width = 590,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.Gray
            };

            WinForms.Label lblTitulo = new WinForms.Label()
            {
                Text = "01. SELECCIONAR ELEMENTOS DEL VÍNCULO ESTRUCTURAL",
                Left = 20,
                Top = 38,
                Width = 590,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            lblInfo = new WinForms.Label()
            {
                Text = "Seleccione columnetas y vigas de confinamiento del vínculo. Solo se aceptan categorías: Pilar estructural y Armazón estructural.",
                Left = 20,
                Top = 62,
                Width = 590,
                Height = 38,
                ForeColor = Drawing.Color.FromArgb(80, 80, 80)
            };

            btnSeleccionarElementos = new WinForms.Button()
            {
                Text = "SELECCIONAR EN VÍNCULO",
                Width = 210,
                Height = 34,
                Left = 20,
                Top = 105,
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnSeleccionarElementos.FlatAppearance.BorderSize = 0;

            btnSeleccionarElementos.Click += (s, e) =>
            {
                if (Handler == null)
                    return;

                Handler.Accion = MurosContornoEstructuraAccion.SeleccionarElementosVinculados;
                EjecutarEvent?.Raise();
            };

            lblElementosSeleccionados = new WinForms.Label()
            {
                Text = "Elementos seleccionados: Ninguno",
                Left = 20,
                Top = 150,
                Width = 590,
                Height = 58,
                ForeColor = Drawing.Color.FromArgb(70, 70, 70)
            };

            WinForms.Label lblTituloTipo = new WinForms.Label()
            {
                Text = "02. TIPO DE MURO A CREAR",
                Left = 20,
                Top = 218,
                Width = 590,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            lblTipoMuro = new WinForms.Label()
            {
                Text = "Seleccione el tipo de muro que se creará en el contorno de cada elemento estructural:",
                Left = 20,
                Top = 245,
                Width = 590,
                Height = 20,
                ForeColor = Drawing.Color.FromArgb(80, 80, 80)
            };

            cmbTipoMuro = new WinForms.ComboBox()
            {
                Left = 20,
                Top = 270,
                Width = 595,
                Height = 26,
                DropDownStyle = WinForms.ComboBoxStyle.DropDownList,
                IntegralHeight = false,
                DropDownHeight = 220
            };

            lblOpciones = new WinForms.Label()
            {
                Text = "Opciones:",
                Left = 20,
                Top = 306,
                Width = 100,
                Height = 20,
                ForeColor = Drawing.Color.FromArgb(80, 80, 80)
            };

            chkEvitarDuplicados = new WinForms.CheckBox()
            {
                Text = "Evitar duplicar segmentos exactamente iguales",
                Left = 20,
                Top = 330,
                Width = 360,
                Height = 24,
                Checked = true,
                ForeColor = Drawing.Color.FromArgb(70, 70, 70)
            };

            btnCrearMuros = new WinForms.Button()
            {
                Text = "CREAR MUROS",
                Width = 155,
                Height = 36,
                Left = 20,
                Top = 365,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnCrearMuros.FlatAppearance.BorderSize = 0;
            btnCrearMuros.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(0, 100, 190);
            btnCrearMuros.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(0, 84, 160);

            btnCrearMuros.Click += (s, e) =>
            {
                if (ElementosSeleccionados == null || ElementosSeleccionados.Count == 0)
                {
                    MostrarResultado("Debe seleccionar columnetas o vigas del vínculo estructural.");
                    return;
                }

                if (TipoMuroSeleccionadoId == ElementId.InvalidElementId)
                {
                    MostrarResultado("Debe seleccionar un tipo de muro válido.");
                    return;
                }

                if (Handler == null)
                    return;

                Handler.Accion = MurosContornoEstructuraAccion.CrearMuros;
                EjecutarEvent?.Raise();
            };

            btnCerrar = new WinForms.Button()
            {
                Text = "CERRAR",
                Width = 120,
                Height = 36,
                Left = 495,
                Top = 365,
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnCerrar.FlatAppearance.BorderSize = 0;

            btnCerrar.Click += (s, e) =>
            {
                this.Close();
            };

            lblResultado = new WinForms.Label()
            {
                Text = "",
                Left = 190,
                Top = 360,
                Width = 290,
                Height = 60,
                Visible = true,
                ForeColor = Drawing.Color.FromArgb(90, 90, 90)
            };

            Controls.Add(lblAutor);
            Controls.Add(lblTitulo);
            Controls.Add(lblInfo);
            Controls.Add(btnSeleccionarElementos);
            Controls.Add(lblElementosSeleccionados);

            Controls.Add(lblTituloTipo);
            Controls.Add(lblTipoMuro);
            Controls.Add(cmbTipoMuro);
            Controls.Add(lblOpciones);
            Controls.Add(chkEvitarDuplicados);

            Controls.Add(btnCrearMuros);
            Controls.Add(btnCerrar);
            Controls.Add(lblResultado);

            CargarTiposDeMuro();

            MostrarResultado("Seleccione los elementos del vínculo, elija el tipo de muro y cree los muros.");
        }

        // =========================================================
        // CARGAR TIPOS DE MURO
        // =========================================================

        private void CargarTiposDeMuro()
        {
            if (cmbTipoMuro == null || _doc == null)
                return;

            _tiposMuro.Clear();
            cmbTipoMuro.Items.Clear();

            try
            {
                List<WallType> tipos = new List<WallType>();

                FilteredElementCollector collector = new FilteredElementCollector(_doc);
                collector.OfClass(typeof(WallType));

                foreach (Element elemento in collector)
                {
                    WallType tipo = elemento as WallType;

                    if (tipo == null)
                        continue;

                    try
                    {
                        if (tipo.Kind != WallKind.Basic)
                            continue;
                    }
                    catch
                    {
                    }

                    tipos.Add(tipo);
                }

                tipos.Sort(delegate (WallType a, WallType b)
                {
                    if (a == null && b == null) return 0;
                    if (a == null) return -1;
                    if (b == null) return 1;

                    string na = "";
                    string nb = "";

                    try { na = a.FamilyName + " : " + a.Name; } catch { }
                    try { nb = b.FamilyName + " : " + b.Name; } catch { }

                    return string.Compare(na, nb, System.StringComparison.CurrentCultureIgnoreCase);
                });

                foreach (WallType tipo in tipos)
                {
                    WallTypeItemMYG item = new WallTypeItemMYG();
                    item.Id = tipo.Id;

                    string nombre = "";

                    try
                    {
                        nombre = tipo.FamilyName + " : " + tipo.Name;
                    }
                    catch
                    {
                        nombre = tipo.Name;
                    }

                    item.Nombre = nombre;

                    _tiposMuro.Add(item);
                    cmbTipoMuro.Items.Add(item);
                }

                if (cmbTipoMuro.Items.Count > 0)
                    cmbTipoMuro.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MostrarResultado("Error al cargar tipos de muro: " + ex.Message);
            }
        }

        // =========================================================
        // ACTUALIZAR SELECCIÓN
        // =========================================================

        public void ActualizarElementosSeleccionados(List<ElementoEstructuraVinculadoMYG> elementos)
        {
            ElementosSeleccionados = new List<ElementoEstructuraVinculadoMYG>();

            if (elementos == null || elementos.Count == 0)
            {
                lblElementosSeleccionados.Text = "Elementos seleccionados: Ninguno";
                MostrarResultado("No se seleccionó ningún elemento válido.");
                return;
            }

            List<string> nombres = new List<string>();
            HashSet<string> unicos = new HashSet<string>();

            foreach (ElementoEstructuraVinculadoMYG item in elementos)
            {
                if (item == null || item.LinkInstanceId == null || item.LinkedElementId == null)
                    continue;

                string clave =
                    item.LinkInstanceId.Value.ToString() + "|" +
                    item.LinkedElementId.Value.ToString();

                if (unicos.Contains(clave))
                    continue;

                unicos.Add(clave);
                ElementosSeleccionados.Add(item);

                string texto = item.Categoria + " - " + item.Nombre;

                if (!string.IsNullOrWhiteSpace(item.NombreVinculo))
                    texto = item.NombreVinculo + " | " + texto;

                nombres.Add(texto);
            }

            if (ElementosSeleccionados.Count == 0)
            {
                lblElementosSeleccionados.Text = "Elementos seleccionados: Ninguno";
                MostrarResultado("No se seleccionó ningún elemento válido.");
                return;
            }

            string textoNombres = "";
            int maximo = Math.Min(4, nombres.Count);

            for (int i = 0; i < maximo; i++)
            {
                if (i > 0)
                    textoNombres += "\r\n";

                textoNombres += nombres[i];
            }

            if (nombres.Count > 4)
                textoNombres += "\r\n...";

            lblElementosSeleccionados.Text =
                "Elementos seleccionados: " + ElementosSeleccionados.Count.ToString() + "\r\n" +
                textoNombres;

            MostrarResultado("Elementos seleccionados: " + ElementosSeleccionados.Count.ToString());
        }

        public void MostrarResultado(string texto)
        {
            _ultimoResultado = texto ?? "";

            if (lblResultado == null)
                return;

            lblResultado.Text = _ultimoResultado;
            lblResultado.Visible = true;

            if (string.IsNullOrWhiteSpace(_ultimoResultado))
                return;

            if (_ultimoResultado.StartsWith("ERROR", System.StringComparison.OrdinalIgnoreCase) ||
                _ultimoResultado.StartsWith("Debe", System.StringComparison.OrdinalIgnoreCase) ||
                _ultimoResultado.StartsWith("No se", System.StringComparison.OrdinalIgnoreCase) ||
                _ultimoResultado.StartsWith("Selección cancelada", System.StringComparison.OrdinalIgnoreCase))
            {
                lblResultado.ForeColor = Drawing.Color.FromArgb(190, 40, 40);
            }
            else
            {
                lblResultado.ForeColor = Drawing.Color.FromArgb(70, 70, 70);
            }
        }

        public void OcultarTemporalmenteParaSeleccion()
        {
            try
            {
                this.Hide();
            }
            catch
            {
            }
        }

        public void MostrarLuegoDeSeleccion()
        {
            try
            {
                if (!this.IsDisposed)
                {
                    this.Show();
                    this.Activate();
                    this.TopMost = true;
                }
            }
            catch
            {
            }
        }

        // =========================================================
        // CLASES INTERNAS
        // =========================================================

        private class WallTypeItemMYG
        {
            public ElementId Id { get; set; }
            public string Nombre { get; set; }

            public override string ToString()
            {
                return Nombre;
            }
        }

        public class ElementoEstructuraVinculadoMYG
        {
            public ElementId LinkInstanceId { get; set; }
            public ElementId LinkedElementId { get; set; }

            public string NombreVinculo { get; set; }
            public string Nombre { get; set; }
            public string Categoria { get; set; }

            public override string ToString()
            {
                return NombreVinculo + " | " + Categoria + " | " + Nombre;
            }
        }
    }

}
