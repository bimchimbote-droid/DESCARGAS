﻿// =====================================
// HANDLER EXTERNO - MUROS DENTRO DE MARCOS DE ESTRUCTURA VINCULADA
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Linq;
using WinForms = System.Windows.Forms;
using Drawing = System.Drawing;

public class EjecutarMurosContornoEstructuraHandler : IExternalEventHandler
{
    public UIDocument UiDoc { get; set; }
    public CrearMurosContornoEstructuraForm Form { get; set; }

    public CrearMurosContornoEstructuraForm.MurosContornoEstructuraAccion Accion { get; set; } =
        CrearMurosContornoEstructuraForm.MurosContornoEstructuraAccion.Ninguna;

    public string GetName()
    {
        return "MYG - Muros dentro de marcos de estructura vinculada";
    }

    public void Execute(UIApplication app)
    {
        if (UiDoc == null || UiDoc.Document == null)
            return;

        if (Form == null || Form.IsDisposed)
            return;

        try
        {
            if (Accion == CrearMurosContornoEstructuraForm.MurosContornoEstructuraAccion.SeleccionarElementosVinculados)
            {
                SeleccionarElementosVinculados();
                return;
            }

            if (Accion == CrearMurosContornoEstructuraForm.MurosContornoEstructuraAccion.CrearMuros)
            {
                CrearMurosDentroDeMarcos();
                return;
            }
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            MostrarEnVentana("Selección cancelada.");
        }
        catch (Exception ex)
        {
            MostrarEnVentana("ERROR:\r\n" + ex.Message);
        }
        finally
        {
            Accion = CrearMurosContornoEstructuraForm.MurosContornoEstructuraAccion.Ninguna;
        }
    }

    // =========================================================
    // SELECCIÓN DE ELEMENTOS DEL VÍNCULO
    // =========================================================

    private void SeleccionarElementosVinculados()
    {
        Document doc = UiDoc.Document;

        try
        {
            Form.OcultarTemporalmenteParaSeleccion();

            IList<Reference> referencias = UiDoc.Selection.PickObjects(
                ObjectType.LinkedElement,
                new FiltroSeleccionEstructuraVinculadaMYG(doc),
                "Seleccione columnetas y vigas de confinamiento del vínculo estructural");

            if (referencias == null || referencias.Count == 0)
                return;

            List<CrearMurosContornoEstructuraForm.ElementoEstructuraVinculadoMYG> seleccion =
                new List<CrearMurosContornoEstructuraForm.ElementoEstructuraVinculadoMYG>();

            HashSet<string> unicos = new HashSet<string>();

            foreach (Reference referencia in referencias)
            {
                if (referencia == null)
                    continue;

                RevitLinkInstance link = doc.GetElement(referencia.ElementId) as RevitLinkInstance;

                if (link == null)
                    continue;

                Document docLink = link.GetLinkDocument();

                if (docLink == null)
                    continue;

                ElementId linkedElementId = referencia.LinkedElementId;

                if (linkedElementId == null || linkedElementId == ElementId.InvalidElementId)
                    continue;

                Element elementoLink = docLink.GetElement(linkedElementId);

                if (elementoLink == null)
                    continue;

                if (!EsCategoriaEstructuralPermitida(elementoLink))
                    continue;

                string clave =
                    link.Id.Value.ToString() + "|" +
                    linkedElementId.Value.ToString();

                if (unicos.Contains(clave))
                    continue;

                unicos.Add(clave);

                CrearMurosContornoEstructuraForm.ElementoEstructuraVinculadoMYG item =
                    new CrearMurosContornoEstructuraForm.ElementoEstructuraVinculadoMYG();

                item.LinkInstanceId = link.Id;
                item.LinkedElementId = linkedElementId;
                item.NombreVinculo = ObtenerNombreElemento(link);
                item.Nombre = ObtenerNombreElemento(elementoLink);
                item.Categoria = ObtenerCategoriaElemento(elementoLink);

                seleccion.Add(item);
            }

            if (seleccion.Count == 0)
            {
                MostrarEnVentana("No se seleccionó ningún elemento válido. Solo se aceptan Pilar estructural y Armazón estructural desde vínculo.");
                return;
            }

            Form.ActualizarElementosSeleccionados(seleccion);
        }
        finally
        {
            Form.MostrarLuegoDeSeleccion();
        }
    }

    // =========================================================
    // CREAR MUROS DENTRO DEL MARCO
    // =========================================================

    private void CrearMurosDentroDeMarcos()
    {
        Document doc = UiDoc.Document;

        if (doc == null)
            return;

        List<CrearMurosContornoEstructuraForm.ElementoEstructuraVinculadoMYG> seleccion =
            Form.ElementosSeleccionados;

        if (seleccion == null || seleccion.Count == 0)
        {
            MostrarEnVentana("Debe seleccionar columnetas y vigas del vínculo estructural.");
            return;
        }

        ElementId wallTypeId = Form.TipoMuroSeleccionadoId;

        if (wallTypeId == null || wallTypeId == ElementId.InvalidElementId)
        {
            MostrarEnVentana("Debe seleccionar un tipo de muro válido.");
            return;
        }

        WallType wallType = doc.GetElement(wallTypeId) as WallType;

        if (wallType == null)
        {
            MostrarEnVentana("No se encontró el tipo de muro seleccionado.");
            return;
        }

        bool evitarDuplicados = Form.EvitarDuplicados;
        double anchoMuro = ObtenerAnchoMuro(wallType);

        List<ElementoMarcoMYG> elementosMarco = ObtenerElementosMarcoSeleccionados(doc, seleccion);

        if (elementosMarco == null || elementosMarco.Count == 0)
        {
            MostrarEnVentana("No se pudo leer geometría válida de los elementos seleccionados.");
            return;
        }

        List<ElementoMarcoMYG> columnas = elementosMarco.Where(x => x != null && x.EsColumna).ToList();
        List<ElementoMarcoMYG> vigas = elementosMarco.Where(x => x != null && x.EsVigaConfinamiento).ToList();

        if (columnas.Count < 2)
        {
            MostrarEnVentana("Debe seleccionar al menos 2 columnetas / pilares estructurales para formar un paño.");
            return;
        }

        if (vigas.Count == 0)
        {
            MostrarEnVentana("No se detectaron vigas de confinamiento válidas. Se omiten armazones diagonales, inclinados o que no funcionen como límite horizontal del paño.");
            return;
        }

        List<XYZ> ejesUEvaluacion = ObtenerEjesUEvaluacion(elementosMarco);

        if (ejesUEvaluacion == null || ejesUEvaluacion.Count == 0)
        {
            MostrarEnVentana("No se pudo obtener las direcciones principales del marco.");
            return;
        }

        int direccionesEvaluadas = 0;
        int gruposProcesados = 0;
        int panosCalculados = 0;
        int panosOmitidos = 0;
        int murosCreados = 0;
        int errores = 0;

        List<ElementId> idsMurosCreados = new List<ElementId>();
        HashSet<string> clavesPanos = new HashSet<string>();
        List<PanoMuroMYG> panosAceptadosGlobales = new List<PanoMuroMYG>();

        // V24:
        // Se precargan los elementos existentes que podrían interferir con los muros nuevos,
        // pero SOLO si están visibles en la vista activa y excluyendo las propias
        // columnetas/vigas seleccionadas que forman el marco.
        // Esos elementos ya definen los límites del paño y no deben generar descuentos falsos.
        HashSet<string> clavesElementosMarcoExcluir = ObtenerClavesElementosMarcoParaExcluir(elementosMarco);

        List<SobrecimientoMYG> sobrecimientosExistentes = ObtenerSobrecimientosExistentes(
            doc,
            doc.ActiveView,
            clavesElementosMarcoExcluir);

        using (Transaction t = new Transaction(doc, "MYG - Crear muros dentro de marcos vinculados"))
        {
            t.Start();

            FailureHandlingOptions opcionesFallo = t.GetFailureHandlingOptions();
            opcionesFallo.SetFailuresPreprocessor(new EliminarAdvertenciasMurosContornoMYG());
            t.SetFailureHandlingOptions(opcionesFallo);

            foreach (XYZ ejeUActual in ejesUEvaluacion)
            {
                if (ejeUActual == null)
                    continue;

                XYZ ejeVActual = new XYZ(-ejeUActual.Y, ejeUActual.X, 0.0);

                foreach (ElementoMarcoMYG e in elementosMarco)
                {
                    if (e == null)
                        continue;

                    e.ActualizarUV(ejeUActual, ejeVActual);
                }

                List<GrupoMarcoMYG> grupos = AgruparPorPlano(elementosMarco, ejeUActual, ejeVActual);

                if (grupos == null || grupos.Count == 0)
                    continue;

                direccionesEvaluadas++;

                foreach (GrupoMarcoMYG grupo in grupos)
                {
                    if (grupo == null)
                        continue;

                    try
                    {
                        List<PanoMuroMYG> panos = CalcularPanosDentroDeMarco(grupo, anchoMuro);

                        if (panos == null || panos.Count == 0)
                        {
                            panosOmitidos++;
                            continue;
                        }

                        panosCalculados += panos.Count;

                        foreach (PanoMuroMYG pano in panos)
                        {
                            if (pano == null)
                            {
                                panosOmitidos++;
                                continue;
                            }

                            string clave = ObtenerClavePano(pano);

                            if (evitarDuplicados && clavesPanos.Contains(clave))
                            {
                                panosOmitidos++;
                                continue;
                            }

                            // V13:
                            // Aunque la clave exacta sea distinta por una mínima inclinación,
                            // no se debe crear otro muro si ya existe un paño prácticamente
                            // en la misma franja, con la misma altura y con solape en planta.
                            if (evitarDuplicados && ExistePanoSolapadoYaCreado(pano, panosAceptadosGlobales, anchoMuro))
                            {
                                panosOmitidos++;
                                continue;
                            }

                            Wall muro = CrearMuroPano(doc, pano, wallTypeId, sobrecimientosExistentes);

                            if (muro == null)
                            {
                                panosOmitidos++;
                                continue;
                            }

                            try
                            {
                                WallUtils.DisallowWallJoinAtEnd(muro, 0);
                                WallUtils.DisallowWallJoinAtEnd(muro, 1);
                            }
                            catch
                            {
                            }

                            idsMurosCreados.Add(muro.Id);
                            murosCreados++;

                            if (evitarDuplicados && !clavesPanos.Contains(clave))
                                clavesPanos.Add(clave);

                            if (evitarDuplicados)
                                panosAceptadosGlobales.Add(pano);
                        }

                        gruposProcesados++;
                    }
                    catch
                    {
                        errores++;
                    }
                }
            }

            t.Commit();
        }

        try
        {
            if (idsMurosCreados.Count > 0)
                UiDoc.Selection.SetElementIds(idsMurosCreados);
        }
        catch
        {
        }

        MostrarEnVentana(
            "Proceso terminado.\r\n" +
            "Direcciones evaluadas: " + direccionesEvaluadas.ToString() +
            " | Grupos procesados: " + gruposProcesados.ToString() +
            " | Paños detectados: " + panosCalculados.ToString() +
            " | Muros creados: " + murosCreados.ToString() +
            " | Omitidos: " + panosOmitidos.ToString() +
            " | Errores: " + errores.ToString());
    }

    private List<ElementoMarcoMYG> ObtenerElementosMarcoSeleccionados(
        Document docHost,
        List<CrearMurosContornoEstructuraForm.ElementoEstructuraVinculadoMYG> seleccion)
    {
        List<ElementoMarcoMYG> resultado = new List<ElementoMarcoMYG>();
        HashSet<string> unicos = new HashSet<string>();

        if (docHost == null || seleccion == null)
            return resultado;

        foreach (CrearMurosContornoEstructuraForm.ElementoEstructuraVinculadoMYG item in seleccion)
        {
            if (item == null || item.LinkInstanceId == null || item.LinkedElementId == null)
                continue;

            string clave = item.LinkInstanceId.Value.ToString() + "|" + item.LinkedElementId.Value.ToString();

            if (unicos.Contains(clave))
                continue;

            unicos.Add(clave);

            RevitLinkInstance link = docHost.GetElement(item.LinkInstanceId) as RevitLinkInstance;

            if (link == null)
                continue;

            Document docLink = null;

            try
            {
                docLink = link.GetLinkDocument();
            }
            catch
            {
                docLink = null;
            }

            if (docLink == null)
                continue;

            Element elementoLink = docLink.GetElement(item.LinkedElementId);

            if (elementoLink == null || !EsCategoriaEstructuralPermitida(elementoLink))
                continue;

            Transform transformLink = ObtenerTransformVinculo(link);

            List<XYZ> puntos = ObtenerPuntosGeometriaHost(elementoLink, transformLink);

            if (puntos == null || puntos.Count < 4)
                puntos = ObtenerPuntosBoundingBoxHost(elementoLink, transformLink);

            if (puntos == null || puntos.Count < 4)
                continue;

            ElementoMarcoMYG info = new ElementoMarcoMYG();
            info.LinkInstanceId = item.LinkInstanceId;
            info.LinkedElementId = item.LinkedElementId;
            info.Nombre = item.Nombre;
            info.Categoria = item.Categoria;
            info.ElementoLink = elementoLink;
            info.TransformLink = transformLink;
            info.PuntosHost = puntos;
            info.EsColumna = EsColumnaEstructural(elementoLink);
            info.EsViga = EsVigaEstructural(elementoLink);

            CalcularZMinMax(info);
            info.Centro = CalcularCentroPuntos(puntos);
            info.LongitudEje = ObtenerLongitudEjeElementoHost(elementoLink, transformLink);
            info.DeltaZEje = ObtenerDeltaZEjeElementoHost(elementoLink, transformLink);
            info.EsVigaConfinamiento = EsVigaDeConfinamientoValida(info);

            if (info.Centro == null)
                continue;

            if ((info.ZMax - info.ZMin) <= MetrosAPies(0.02))
                continue;

            resultado.Add(info);
        }

        return resultado;
    }

    // =========================================================
    // CÁLCULO DE PAÑOS
    // =========================================================

    private List<PanoMuroMYG> CalcularPanosDentroDeMarco(GrupoMarcoMYG grupo, double anchoMuro)
    {
        List<PanoMuroMYG> resultado = new List<PanoMuroMYG>();

        if (grupo == null || grupo.Elementos == null || grupo.Elementos.Count == 0)
            return resultado;

        List<ElementoMarcoMYG> columnas = grupo.Elementos
            .Where(x => x != null && x.EsColumna)
            .OrderBy(x => x.UCentro)
            .ToList();

        List<ElementoMarcoMYG> vigas = grupo.Elementos
            .Where(x => x != null && x.EsVigaConfinamiento)
            .OrderBy(x => x.ZMin)
            .ToList();

        if (columnas.Count < 2)
            return resultado;

        double alturaMinimaPano = MetrosAPies(0.15);
        double longitudMinimaPano = MetrosAPies(0.15);
        double longitudMaximaPano = MetrosAPies(9.00);

        // V11:
        // Antes solo se evaluaban columnas consecutivas en el grupo ordenado por U.
        // Con selecciones grandes, otras columnetas de marcos cercanos podían quedar intercaladas
        // y el par real dejaba de evaluarse. Por eso el paño sí salía cuando seleccionabas
        // solo esa zona, pero no cuando seleccionabas todo el conjunto.
        // Ahora se evalúan pares posibles de columnas, pero se exige:
        // - viga real cubriendo el claro,
        // - cara efectiva en ambas columnetas,
        // - que no exista una columneta intermedia real dividiendo ese mismo plano.
        for (int i = 0; i < columnas.Count - 1; i++)
        {
            ElementoMarcoMYG colIzq = columnas[i];

            if (colIzq == null)
                continue;

            for (int j = i + 1; j < columnas.Count; j++)
            {
                ElementoMarcoMYG colDer = columnas[j];

                if (colDer == null)
                    continue;

                double uInicioPreliminar = colIzq.UMax;
                double uFinPreliminar = colDer.UMin;

                if (uFinPreliminar <= uInicioPreliminar)
                    continue;

                double longitudPreliminar = uFinPreliminar - uInicioPreliminar;

                if (longitudPreliminar < longitudMinimaPano)
                    continue;

                if (longitudPreliminar > longitudMaximaPano)
                    continue;

                double zMarcoMin = Math.Max(colIzq.ZMin, colDer.ZMin);
                double zMarcoMax = Math.Min(colIzq.ZMax, colDer.ZMax);

                if ((zMarcoMax - zMarcoMin) < alturaMinimaPano)
                    continue;

                List<ElementoMarcoMYG> vigasPreliminares = new List<ElementoMarcoMYG>();

                foreach (ElementoMarcoMYG viga in vigas)
                {
                    if (viga == null)
                        continue;

                    if (!VigaCubreTramoEntreColumnetas(viga, colIzq, colDer, uInicioPreliminar, uFinPreliminar))
                        continue;

                    vigasPreliminares.Add(viga);
                }

                if (vigasPreliminares.Count == 0)
                    continue;

                double vReferencia = ObtenerVReferenciaPano(grupo, colIzq, colDer, vigasPreliminares);

                double uCaraIzq = 0.0;
                double uCaraDer = 0.0;

                bool tieneCaraIzq = TryObtenerUCaraEfectivaColumna(
                    colIzq,
                    grupo.EjeU,
                    grupo.EjeV,
                    vReferencia,
                    true,
                    out uCaraIzq);

                bool tieneCaraDer = TryObtenerUCaraEfectivaColumna(
                    colDer,
                    grupo.EjeU,
                    grupo.EjeV,
                    vReferencia,
                    false,
                    out uCaraDer);

                if (!tieneCaraIzq || !tieneCaraDer)
                    continue;

                double uInicio = uCaraIzq;
                double uFin = uCaraDer;

                if (uFin <= uInicio)
                    continue;

                if ((uFin - uInicio) < longitudMinimaPano)
                    continue;

                if ((uFin - uInicio) > longitudMaximaPano)
                    continue;

                // Evita que se cree un paño largo pasando por encima de otra columneta real.
                // Pero solo bloquea cuando esa columneta intermedia pertenece al mismo plano del paño.
                if (ExisteColumnaIntermediaQueDividePano(
                    columnas,
                    colIzq,
                    colDer,
                    uInicio,
                    uFin,
                    vReferencia))
                {
                    continue;
                }

                List<ElementoMarcoMYG> vigasTramo = new List<ElementoMarcoMYG>();

                foreach (ElementoMarcoMYG viga in vigas)
                {
                    if (viga == null)
                        continue;

                    if (!VigaCubreTramoEntreColumnetas(viga, colIzq, colDer, uInicio, uFin))
                        continue;

                    vigasTramo.Add(viga);
                }

                if (vigasTramo.Count == 0)
                    vigasTramo = vigasPreliminares;

                List<IntervaloZMYG> bandasVigas = new List<IntervaloZMYG>();

                foreach (ElementoMarcoMYG viga in vigasTramo)
                {
                    if (viga == null)
                        continue;

                    double zi = Math.Max(viga.ZMin, zMarcoMin);
                    double zf = Math.Min(viga.ZMax, zMarcoMax);

                    if ((zf - zi) <= MetrosAPies(0.02))
                        continue;

                    IntervaloZMYG banda = new IntervaloZMYG();
                    banda.Min = zi;
                    banda.Max = zf;
                    bandasVigas.Add(banda);
                }

                bandasVigas = UnirBandasZ(bandasVigas, MetrosAPies(0.03));

                if (bandasVigas == null || bandasVigas.Count == 0)
                    continue;

                List<IntervaloZMYG> vacios = ObtenerVaciosVerticales(zMarcoMin, zMarcoMax, bandasVigas);

                foreach (IntervaloZMYG vacio in vacios)
                {
                    if (vacio == null)
                        continue;

                    if ((vacio.Max - vacio.Min) < alturaMinimaPano)
                        continue;

                    double vCentro = ObtenerVCentroPanoAlineadoPorCaras(
                        grupo,
                        colIzq,
                        colDer,
                        vigasTramo,
                        uInicio,
                        uFin,
                        anchoMuro,
                        vReferencia);

                    if (double.IsNaN(vCentro) || double.IsInfinity(vCentro))
                        continue;

                    if (!PanoTieneEncierroReal(
                        grupo,
                        colIzq,
                        colDer,
                        vigasTramo,
                        uInicio,
                        uFin,
                        vCentro,
                        anchoMuro))
                    {
                        continue;
                    }

                    PanoMuroMYG pano = new PanoMuroMYG();
                    pano.EjeU = grupo.EjeU;
                    pano.EjeV = grupo.EjeV;
                    pano.VCentro = vCentro;
                    pano.UInicio = uInicio;
                    pano.UFin = uFin;
                    pano.ZBase = vacio.Min;
                    pano.ZTop = vacio.Max;
                    pano.Altura = vacio.Max - vacio.Min;

                    resultado.Add(pano);
                }
            }
        }

        return resultado;
    }

    private bool ExisteColumnaIntermediaQueDividePano(
        List<ElementoMarcoMYG> columnas,
        ElementoMarcoMYG colIzq,
        ElementoMarcoMYG colDer,
        double uInicio,
        double uFin,
        double vReferencia)
    {
        if (columnas == null || columnas.Count == 0)
            return false;

        if (colIzq == null || colDer == null)
            return false;

        double toleranciaU = MetrosAPies(0.04);
        double toleranciaV = MetrosAPies(0.10);

        foreach (ElementoMarcoMYG columna in columnas)
        {
            if (columna == null)
                continue;

            if (columna == colIzq || columna == colDer)
                continue;

            if (columna.LinkInstanceId != null && colIzq.LinkInstanceId != null &&
                columna.LinkedElementId != null && colIzq.LinkedElementId != null &&
                columna.LinkInstanceId.Value == colIzq.LinkInstanceId.Value &&
                columna.LinkedElementId.Value == colIzq.LinkedElementId.Value)
                continue;

            if (columna.LinkInstanceId != null && colDer.LinkInstanceId != null &&
                columna.LinkedElementId != null && colDer.LinkedElementId != null &&
                columna.LinkInstanceId.Value == colDer.LinkInstanceId.Value &&
                columna.LinkedElementId.Value == colDer.LinkedElementId.Value)
                continue;

            if (columna.UCentro <= uInicio + toleranciaU || columna.UCentro >= uFin - toleranciaU)
                continue;

            if (columna.UMax <= uInicio + toleranciaU || columna.UMin >= uFin - toleranciaU)
                continue;

            // Solo bloquea si la columneta intermedia realmente cruza el mismo plano V del paño.
            if (vReferencia >= columna.VMin - toleranciaV &&
                vReferencia <= columna.VMax + toleranciaV)
            {
                return true;
            }
        }

        return false;
    }

    private bool VigaCubreTramoEntreColumnetas(
        ElementoMarcoMYG viga,
        ElementoMarcoMYG colIzq,
        ElementoMarcoMYG colDer,
        double uInicio,
        double uFin)
    {
        if (viga == null || !viga.EsVigaConfinamiento)
            return false;

        if (colIzq == null || colDer == null)
            return false;

        if (uFin <= uInicio)
            return false;

        double longitudSpan = uFin - uInicio;

        if (longitudSpan < MetrosAPies(0.15))
            return false;

        // 1) La viga debe cubrir una parte importante del claro entre columnetas.
        // Antes bastaba con tocar el intervalo, y eso generaba muros falsos.
        double solape = Math.Min(viga.UMax, uFin) - Math.Max(viga.UMin, uInicio);

        if (solape <= 0.0)
            return false;

        double porcentajeCobertura = solape / longitudSpan;

        if (porcentajeCobertura < 0.65)
            return false;

        // 2) La viga debe estar aproximadamente en la misma franja V de las columnetas.
        // Primero se intenta con intersección de caras. Si no intersectan por geometría
        // irregular, se usa cercanía al eje promedio de las 2 columnetas.
        double toleranciaV = MetrosAPies(0.18);
        double vComunMin = Math.Max(colIzq.VMin, colDer.VMin);
        double vComunMax = Math.Min(colIzq.VMax, colDer.VMax);

        if (vComunMax > vComunMin)
        {
            double interMin = Math.Max(viga.VMin, vComunMin);
            double interMax = Math.Min(viga.VMax, vComunMax);

            if ((interMax - interMin) >= MetrosAPies(0.005))
                return true;
        }

        double vRef = (colIzq.VCentro + colDer.VCentro) / 2.0;

        if (Math.Abs(viga.VCentro - vRef) <= toleranciaV)
            return true;

        return false;
    }

    private double ObtenerVReferenciaPano(
        GrupoMarcoMYG grupo,
        ElementoMarcoMYG colIzq,
        ElementoMarcoMYG colDer,
        List<ElementoMarcoMYG> vigasTramo)
    {
        List<double> valores = new List<double>();

        if (vigasTramo != null)
        {
            foreach (ElementoMarcoMYG viga in vigasTramo)
            {
                if (viga == null)
                    continue;

                valores.Add(viga.VCentro);
            }
        }

        if (valores.Count > 0)
            return ObtenerMediana(valores);

        if (colIzq != null)
            valores.Add(colIzq.VCentro);

        if (colDer != null)
            valores.Add(colDer.VCentro);

        if (valores.Count > 0)
            return ObtenerMediana(valores);

        if (grupo != null)
            return grupo.VCentro;

        return 0.0;
    }

    private bool TryObtenerUCaraEfectivaColumna(
        ElementoMarcoMYG columna,
        XYZ ejeU,
        XYZ ejeV,
        double vReferencia,
        bool esColumnaIzquierda,
        out double uCara)
    {
        uCara = 0.0;

        if (columna == null || columna.PuntosHost == null || columna.PuntosHost.Count == 0)
            return false;

        if (ejeU == null || ejeV == null)
            return false;

        double anchoV = Math.Abs(columna.VMax - columna.VMin);
        double toleranciaBase = Math.Max(MetrosAPies(0.12), Math.Min(MetrosAPies(0.30), anchoV * 0.35));

        double[] factores = new double[] { 1.0, 1.75, 2.50 };

        foreach (double factor in factores)
        {
            double toleranciaV = toleranciaBase * factor;
            List<double> valoresU = new List<double>();

            foreach (XYZ p in columna.PuntosHost)
            {
                if (p == null)
                    continue;

                double u = DotXY(p, ejeU);
                double v = DotXY(p, ejeV);

                if (Math.Abs(v - vReferencia) <= toleranciaV)
                    valoresU.Add(u);
            }

            if (valoresU.Count > 0)
            {
                if (esColumnaIzquierda)
                    uCara = valoresU.Max();
                else
                    uCara = valoresU.Min();

                return true;
            }
        }

        // Último filtro seguro: si el plano de referencia pasa dentro del rango V de la columneta,
        // se toma la cara global. Si ni siquiera pasa por su rango V, no se debe crear muro.
        double toleranciaRango = MetrosAPies(0.05);

        if (vReferencia >= columna.VMin - toleranciaRango &&
            vReferencia <= columna.VMax + toleranciaRango)
        {
            if (esColumnaIzquierda)
                uCara = columna.UMax;
            else
                uCara = columna.UMin;

            return true;
        }

        return false;
    }

    private bool TryObtenerIntervaloVEnCaraEfectiva(
        ElementoMarcoMYG columna,
        XYZ ejeU,
        XYZ ejeV,
        double uCara,
        double vReferencia,
        out IntervaloZMYG intervalo)
    {
        intervalo = null;

        if (columna == null || columna.PuntosHost == null || columna.PuntosHost.Count == 0)
            return false;

        if (ejeU == null || ejeV == null)
            return false;

        double anchoU = Math.Abs(columna.UMax - columna.UMin);
        double anchoV = Math.Abs(columna.VMax - columna.VMin);

        double toleranciaUBase = Math.Max(MetrosAPies(0.025), Math.Min(MetrosAPies(0.10), anchoU * 0.20));
        double toleranciaVBase = Math.Max(MetrosAPies(0.12), Math.Min(MetrosAPies(0.30), anchoV * 0.35));

        double[] factores = new double[] { 1.0, 1.75, 2.50 };

        foreach (double factor in factores)
        {
            double toleranciaU = toleranciaUBase * factor;
            double toleranciaV = toleranciaVBase * factor;

            List<double> valoresV = new List<double>();

            foreach (XYZ p in columna.PuntosHost)
            {
                if (p == null)
                    continue;

                double u = DotXY(p, ejeU);
                double v = DotXY(p, ejeV);

                if (Math.Abs(u - uCara) <= toleranciaU && Math.Abs(v - vReferencia) <= toleranciaV)
                    valoresV.Add(v);
            }

            if (valoresV.Count > 0)
            {
                intervalo = new IntervaloZMYG();
                intervalo.Min = valoresV.Min();
                intervalo.Max = valoresV.Max();

                if ((intervalo.Max - intervalo.Min) < MetrosAPies(0.02))
                {
                    intervalo.Min = vReferencia - toleranciaVBase;
                    intervalo.Max = vReferencia + toleranciaVBase;
                }

                return true;
            }
        }

        if (vReferencia >= columna.VMin - MetrosAPies(0.05) &&
            vReferencia <= columna.VMax + MetrosAPies(0.05))
        {
            intervalo = new IntervaloZMYG();
            intervalo.Min = columna.VMin;
            intervalo.Max = columna.VMax;
            return true;
        }

        return false;
    }

    private bool IntervaloContieneValor(IntervaloZMYG intervalo, double valor, double tolerancia)
    {
        if (intervalo == null)
            return false;

        return valor >= intervalo.Min - tolerancia && valor <= intervalo.Max + tolerancia;
    }

    private double ObtenerVCentroPanoAlineadoPorCaras(
        GrupoMarcoMYG grupo,
        ElementoMarcoMYG colIzq,
        ElementoMarcoMYG colDer,
        List<ElementoMarcoMYG> vigas,
        double uInicio,
        double uFin,
        double anchoMuro,
        double vReferencia)
    {
        // V9:
        // Para columnetas en L/U/abiertas se evita usar el bounding box completo.
        // Se busca la cara efectiva de cada columneta en el plano de la viga que cierra el paño.
        // Si ambas caras contienen esa referencia, el muro se crea exactamente en ese plano.
        double toleranciaMinima = MetrosAPies(0.01);
        double toleranciaReferencia = Math.Max(MetrosAPies(0.04), anchoMuro * 0.75);

        IntervaloZMYG vIzq = null;
        IntervaloZMYG vDer = null;

        bool tieneVIzq = TryObtenerIntervaloVEnCaraEfectiva(
            colIzq,
            grupo != null ? grupo.EjeU : null,
            grupo != null ? grupo.EjeV : null,
            uInicio,
            vReferencia,
            out vIzq);

        bool tieneVDer = TryObtenerIntervaloVEnCaraEfectiva(
            colDer,
            grupo != null ? grupo.EjeU : null,
            grupo != null ? grupo.EjeV : null,
            uFin,
            vReferencia,
            out vDer);

        if (tieneVIzq && tieneVDer)
        {
            bool referenciaEnColumnas =
                IntervaloContieneValor(vIzq, vReferencia, toleranciaReferencia) &&
                IntervaloContieneValor(vDer, vReferencia, toleranciaReferencia);

            bool referenciaEnVigas = true;

            if (vigas != null && vigas.Count > 0)
            {
                foreach (ElementoMarcoMYG viga in vigas)
                {
                    if (viga == null)
                        continue;

                    if (!VigaCubreTramoEntreColumnetas(viga, colIzq, colDer, uInicio, uFin))
                        continue;

                    if (vReferencia < viga.VMin - toleranciaReferencia ||
                        vReferencia > viga.VMax + toleranciaReferencia)
                    {
                        referenciaEnVigas = false;
                        break;
                    }
                }
            }

            if (referenciaEnColumnas && referenciaEnVigas)
                return vReferencia;

            double vMin = Math.Max(vIzq.Min, vDer.Min);
            double vMax = Math.Min(vIzq.Max, vDer.Max);

            if (vigas != null)
            {
                foreach (ElementoMarcoMYG viga in vigas)
                {
                    if (viga == null)
                        continue;

                    if (!VigaCubreTramoEntreColumnetas(viga, colIzq, colDer, uInicio, uFin))
                        continue;

                    double nuevoMin = Math.Max(vMin, viga.VMin);
                    double nuevoMax = Math.Min(vMax, viga.VMax);

                    if ((nuevoMax - nuevoMin) > toleranciaMinima)
                    {
                        vMin = nuevoMin;
                        vMax = nuevoMax;
                    }
                }
            }

            if ((vMax - vMin) > toleranciaMinima)
                return (vMin + vMax) / 2.0;
        }

        // V10:
        // En versiones anteriores aquí se hacía fallback al eje de las columnetas.
        // Eso ayudaba en columnas rectangulares, pero en columnas tipo L/U/abiertas
        // podía crear muros en una cara exterior o en una proyección que no cerraba el paño.
        // Ahora, si no hay intersección común real de caras, se omite el paño.
        return double.NaN;
    }

    private bool PanoTieneEncierroReal(
        GrupoMarcoMYG grupo,
        ElementoMarcoMYG colIzq,
        ElementoMarcoMYG colDer,
        List<ElementoMarcoMYG> vigas,
        double uInicio,
        double uFin,
        double vCentro,
        double anchoMuro)
    {
        if (grupo == null || grupo.EjeU == null || grupo.EjeV == null)
            return false;

        if (colIzq == null || colDer == null)
            return false;

        if (uFin <= uInicio)
            return false;

        if ((uFin - uInicio) < MetrosAPies(0.15))
            return false;

        if (double.IsNaN(vCentro) || double.IsInfinity(vCentro))
            return false;

        double toleranciaV = Math.Max(MetrosAPies(0.025), anchoMuro * 0.60);

        IntervaloZMYG intervaloIzq = null;
        IntervaloZMYG intervaloDer = null;

        bool tieneIzq = TryObtenerIntervaloVEnCaraEfectiva(
            colIzq,
            grupo.EjeU,
            grupo.EjeV,
            uInicio,
            vCentro,
            out intervaloIzq);

        bool tieneDer = TryObtenerIntervaloVEnCaraEfectiva(
            colDer,
            grupo.EjeU,
            grupo.EjeV,
            uFin,
            vCentro,
            out intervaloDer);

        if (!tieneIzq || !tieneDer)
            return false;

        if (!IntervaloContieneValor(intervaloIzq, vCentro, toleranciaV))
            return false;

        if (!IntervaloContieneValor(intervaloDer, vCentro, toleranciaV))
            return false;

        if (vigas == null || vigas.Count == 0)
            return false;

        double longitudSpan = uFin - uInicio;
        int vigasValidasEnPlano = 0;

        foreach (ElementoMarcoMYG viga in vigas)
        {
            if (viga == null || !viga.EsVigaConfinamiento)
                continue;

            if (!VigaCubreTramoEntreColumnetas(viga, colIzq, colDer, uInicio, uFin))
                continue;

            double solape = Math.Min(viga.UMax, uFin) - Math.Max(viga.UMin, uInicio);

            if (solape <= 0.0)
                continue;

            double porcentajeCobertura = solape / longitudSpan;

            // V12:
            // Se vuelve a 65% porque con columnetas irregulares la viga puede entrar o terminar
            // dentro de la propia columneta y no cubrir el 80% del claro geométrico leído.
            // Los falsos positivos ahora se controlan con la validación angular estricta
            // y con la comprobación del mismo plano V.
            if (porcentajeCobertura < 0.65)
                continue;

            if (vCentro < viga.VMin - toleranciaV || vCentro > viga.VMax + toleranciaV)
                continue;

            vigasValidasEnPlano++;
        }

        if (vigasValidasEnPlano == 0)
            return false;

        // V11:
        // Ya no se compara contra grupo.VCentro, porque con selecciones grandes el grupo
        // puede contener marcos paralelos/cercanos y ese centro global se desplaza.
        // La validación queda local: ambas columnetas + vigas del tramo deben contener
        // el plano calculado del paño.
        double vComunMin = Math.Max(intervaloIzq.Min, intervaloDer.Min);
        double vComunMax = Math.Min(intervaloIzq.Max, intervaloDer.Max);

        if (vCentro < vComunMin - toleranciaV || vCentro > vComunMax + toleranciaV)
            return false;

        return true;
    }

    private double ObtenerVCentroPanoAlEje(
        GrupoMarcoMYG grupo,
        ElementoMarcoMYG colIzq,
        ElementoMarcoMYG colDer,
        List<ElementoMarcoMYG> vigas,
        double uInicio,
        double uFin)
    {
        List<double> valores = new List<double>();

        // Prioridad 1: eje de las columnetas que delimitan el paño.
        // Este es el plano más confiable para que el muro quede centrado
        // dentro del confinamiento y no se vaya hacia una cara exterior.
        if (colIzq != null)
            valores.Add(colIzq.VCentro);

        if (colDer != null)
            valores.Add(colDer.VCentro);

        double referenciaColumnas = 0.0;

        if (valores.Count > 0)
            referenciaColumnas = valores.Average();
        else if (grupo != null)
            referenciaColumnas = grupo.VCentro;

        // Prioridad 2: vigas que cruzan ese paño y que están cerca del mismo eje.
        // Solo se usan como apoyo, no como único criterio, para evitar que una viga
        // ligeramente desfasada empuje el muro hacia fuera.
        double toleranciaViga = MetrosAPies(0.18);
        double toleranciaSolape = MetrosAPies(0.05);

        if (vigas != null)
        {
            foreach (ElementoMarcoMYG viga in vigas)
            {
                if (viga == null)
                    continue;

                if (!VigaCubreTramoEntreColumnetas(viga, colIzq, colDer, uInicio, uFin))
                    continue;

                if (valores.Count > 0 && Math.Abs(viga.VCentro - referenciaColumnas) > toleranciaViga)
                    continue;

                valores.Add(viga.VCentro);
            }
        }

        if (valores.Count > 0)
            return ObtenerMediana(valores);

        if (grupo != null)
            return grupo.VCentro;

        return 0.0;
    }

    private double ObtenerMediana(List<double> valores)
    {
        if (valores == null || valores.Count == 0)
            return 0.0;

        List<double> ordenados = valores
            .OrderBy(x => x)
            .ToList();

        int n = ordenados.Count;

        if (n == 1)
            return ordenados[0];

        if (n % 2 == 1)
            return ordenados[n / 2];

        return (ordenados[(n / 2) - 1] + ordenados[n / 2]) / 2.0;
    }

    private List<IntervaloZMYG> ObtenerVaciosVerticales(
        double zMarcoMin,
        double zMarcoMax,
        List<IntervaloZMYG> bandasVigas)
    {
        List<IntervaloZMYG> vacios = new List<IntervaloZMYG>();
        double alturaMinimaPano = MetrosAPies(0.15);

        if (zMarcoMax <= zMarcoMin)
            return vacios;

        if (bandasVigas == null || bandasVigas.Count == 0)
        {
            // V8: sin viga de confinamiento real no hay encierro del paño.
            // No se crea muro solo por existir 2 columnetas.
            return vacios;
        }

        List<IntervaloZMYG> bandas = bandasVigas
            .Where(x => x != null && x.Max > x.Min)
            .OrderBy(x => x.Min)
            .ToList();

        if (bandas.Count == 0)
        {
            return vacios;
        }

        // 1) Paño inferior: desde base común de columnetas hasta la cara inferior de la primera viga.
        // Si existe una viga inferior casi pegada a la base, no se crea nada debajo de esa viga.
        IntervaloZMYG primera = bandas[0];
        double alturaDebajo = primera.Min - zMarcoMin;

        if (alturaDebajo >= alturaMinimaPano && alturaDebajo > MetrosAPies(0.20))
        {
            vacios.Add(new IntervaloZMYG()
            {
                Min = zMarcoMin,
                Max = primera.Min
            });
        }

        // 2) Paños entre vigas: desde la cara superior de la viga inferior
        // hasta la cara inferior de la viga superior.
        for (int i = 0; i < bandas.Count - 1; i++)
        {
            IntervaloZMYG inferior = bandas[i];
            IntervaloZMYG superior = bandas[i + 1];

            if (inferior == null || superior == null)
                continue;

            double zi = inferior.Max;
            double zf = superior.Min;

            if ((zf - zi) >= alturaMinimaPano)
            {
                vacios.Add(new IntervaloZMYG()
                {
                    Min = zi,
                    Max = zf
                });
            }
        }

        // 3) Paño superior: desde la cara superior de la viga más alta
        // hasta la parte superior común de las 2 columnetas.
        // Antes se omitía para evitar muros sobre vigas superiores; pero en este flujo
        // también se necesita crear paños cuando el vacío está delimitado solo por 2 pilares,
        // aunque no exista otra viga/armazón encima.
        IntervaloZMYG ultimaBanda = bandas[bandas.Count - 1];

        if (ultimaBanda != null)
        {
            double ziSuperior = ultimaBanda.Max;
            double zfSuperior = zMarcoMax;
            double alturaSuperior = zfSuperior - ziSuperior;

            if (alturaSuperior >= alturaMinimaPano && alturaSuperior > MetrosAPies(0.20))
            {
                vacios.Add(new IntervaloZMYG()
                {
                    Min = ziSuperior,
                    Max = zfSuperior
                });
            }
        }

        return vacios;
    }

    private Wall CrearMuroPano(Document doc, PanoMuroMYG pano, ElementId wallTypeId, List<SobrecimientoMYG> sobrecimientosExistentes)
    {
        if (doc == null || pano == null || wallTypeId == null || wallTypeId == ElementId.InvalidElementId)
            return null;

        if (pano.EjeU == null || pano.EjeV == null)
            return null;

        if (pano.UFin <= pano.UInicio)
            return null;

        if (pano.Altura <= MetrosAPies(0.02))
            return null;

        Level nivelBase = ObtenerNivelBase(doc, pano.ZBase);

        if (nivelBase == null)
            return null;

        // V16:
        // Si el sobrecimiento cubre TODO el paño de manera rectangular, no conviene usar
        // Wall.Create con perfil/boceto porque en tablas la altura puede leerse como la altura
        // total del boceto. En ese caso se crea un muro simple con ZBase = cara superior
        // del sobrecimiento y Altura = ZTop - ZBase.
        // Solo se usa perfil/boceto cuando el descuento es parcial o escalonado.
        List<IntervaloSobrecimientoMYG> intervalosSobrecimiento =
            ObtenerIntervalosSobrecimientoParaPano(pano, sobrecimientosExistentes);

        if (intervalosSobrecimiento != null && intervalosSobrecimiento.Count > 0)
        {
            double zBaseRectangular = 0.0;

            if (TryObtenerBaseRectangularSobreSobrecimiento(
                pano,
                intervalosSobrecimiento,
                out zBaseRectangular))
            {
                PanoMuroMYG panoRectangular = CrearPanoRectangularSobreSobrecimiento(
                    pano,
                    zBaseRectangular);

                if (panoRectangular != null && panoRectangular.Altura > MetrosAPies(0.02))
                {
                    Level nivelBaseRectangular = ObtenerNivelBase(doc, panoRectangular.ZBase);

                    if (nivelBaseRectangular != null)
                    {
                        Wall muroSimpleSobreSobrecimiento = CrearMuroPanoSimple(
                            doc,
                            panoRectangular,
                            wallTypeId,
                            nivelBaseRectangular);

                        if (muroSimpleSobreSobrecimiento != null)
                            return muroSimpleSobreSobrecimiento;
                    }
                }
            }

            Wall muroPerfil = CrearMuroPanoConPerfil(
                doc,
                pano,
                wallTypeId,
                nivelBase,
                intervalosSobrecimiento);

            if (muroPerfil != null)
                return muroPerfil;
        }

        return CrearMuroPanoSimple(doc, pano, wallTypeId, nivelBase);
    }

    private Wall CrearMuroPanoSimple(Document doc, PanoMuroMYG pano, ElementId wallTypeId, Level nivelBase)
    {
        if (doc == null || pano == null || nivelBase == null)
            return null;

        double baseOffset = pano.ZBase - nivelBase.Elevation;

        XYZ p0 = CrearPuntoDesdeUV(pano.UInicio, pano.VCentro, nivelBase.Elevation, pano.EjeU, pano.EjeV);
        XYZ p1 = CrearPuntoDesdeUV(pano.UFin, pano.VCentro, nivelBase.Elevation, pano.EjeU, pano.EjeV);

        if (p0 == null || p1 == null)
            return null;

        if (DistanciaXY(p0, p1) <= MetrosAPies(0.02))
            return null;

        Line linea = null;

        try
        {
            linea = Line.CreateBound(p0, p1);
        }
        catch
        {
            linea = null;
        }

        if (linea == null)
            return null;

        Wall muro = null;

        try
        {
            muro = Wall.Create(
                doc,
                linea,
                wallTypeId,
                nivelBase.Id,
                pano.Altura,
                baseOffset,
                false,
                false);
        }
        catch
        {
            muro = null;
        }

        if (muro == null)
            return null;

        ConfigurarParametrosMuroCreado(muro, baseOffset, pano.Altura, linea);

        return muro;
    }

    private Wall CrearMuroPanoConPerfil(
        Document doc,
        PanoMuroMYG pano,
        ElementId wallTypeId,
        Level nivelBase,
        List<IntervaloSobrecimientoMYG> intervalosSobrecimiento)
    {
        if (doc == null || pano == null || nivelBase == null)
            return null;

        List<Curve> perfil = CrearPerfilConDescuentoSobrecimiento(pano, intervalosSobrecimiento);

        if (perfil == null || perfil.Count < 4)
            return null;

        Wall muro = null;

        try
        {
            muro = Wall.Create(
                doc,
                perfil,
                wallTypeId,
                nivelBase.Id,
                false);
        }
        catch
        {
            muro = null;
        }

        if (muro == null)
            return null;

        double baseOffset = pano.ZBase - nivelBase.Elevation;
        ConfigurarParametrosMuroCreado(muro, baseOffset, pano.Altura, null);

        return muro;
    }

    private void ConfigurarParametrosMuroCreado(Wall muro, double baseOffset, double altura, Line linea)
    {
        if (muro == null)
            return;

        try
        {
            Parameter pBaseOffset = muro.get_Parameter(BuiltInParameter.WALL_BASE_OFFSET);

            if (pBaseOffset != null && !pBaseOffset.IsReadOnly)
                pBaseOffset.Set(baseOffset);
        }
        catch
        {
        }

        try
        {
            Parameter pAltura = muro.get_Parameter(BuiltInParameter.WALL_USER_HEIGHT_PARAM);

            if (pAltura != null && !pAltura.IsReadOnly)
                pAltura.Set(altura);
        }
        catch
        {
        }

        try
        {
            Parameter pLineaUbicacion = muro.get_Parameter(BuiltInParameter.WALL_KEY_REF_PARAM);

            if (pLineaUbicacion != null && !pLineaUbicacion.IsReadOnly)
                pLineaUbicacion.Set(0); // 0 = Eje del muro / Wall Centerline
        }
        catch
        {
        }

        if (linea != null)
        {
            try
            {
                LocationCurve loc = muro.Location as LocationCurve;

                if (loc != null)
                    loc.Curve = linea;
            }
            catch
            {
            }
        }

        AsignarGENIDElemento(muro);
    }

    private void AsignarGENIDElemento(Wall muro)
    {
        if (muro == null)
            return;

        try
        {
            Parameter parametro = muro.LookupParameter("GEN_ID Elemento");

            if (parametro == null || parametro.IsReadOnly)
                return;

            string valorId = muro.Id.Value.ToString();

            if (string.IsNullOrWhiteSpace(valorId))
                return;

            if (parametro.StorageType == StorageType.String)
            {
                parametro.Set(valorId);
                return;
            }

            if (parametro.StorageType == StorageType.Integer)
            {
                int valorEntero = 0;

                if (int.TryParse(valorId, out valorEntero))
                    parametro.Set(valorEntero);

                return;
            }

            if (parametro.StorageType == StorageType.Double)
            {
                double valorDouble = 0.0;

                if (double.TryParse(valorId, out valorDouble))
                    parametro.Set(valorDouble);

                return;
            }

            if (parametro.StorageType == StorageType.ElementId)
            {
                parametro.Set(muro.Id);
                return;
            }
        }
        catch
        {
        }
    }

    private bool TryObtenerBaseRectangularSobreSobrecimiento(
        PanoMuroMYG pano,
        List<IntervaloSobrecimientoMYG> intervalosSobrecimiento,
        out double zBaseRectangular)
    {
        zBaseRectangular = 0.0;

        if (pano == null || intervalosSobrecimiento == null || intervalosSobrecimiento.Count == 0)
            return false;

        if (pano.UFin <= pano.UInicio || pano.ZTop <= pano.ZBase)
            return false;

        double toleranciaU = Math.Max(MetrosAPies(0.04), (pano.UFin - pano.UInicio) * 0.03);
        double toleranciaZ = MetrosAPies(0.025);

        List<IntervaloSobrecimientoMYG> intervalos = UnirIntervalosSobrecimiento(
            intervalosSobrecimiento,
            MetrosAPies(0.02));

        if (intervalos == null || intervalos.Count != 1)
            return false;

        IntervaloSobrecimientoMYG intervalo = intervalos[0];

        if (intervalo == null)
            return false;

        // Debe cubrir prácticamente todo el largo del paño. Si solo cubre una parte,
        // entonces sí corresponde usar perfil/boceto con descuento parcial.
        bool cubreInicio = intervalo.UInicio <= pano.UInicio + toleranciaU;
        bool cubreFin = intervalo.UFin >= pano.UFin - toleranciaU;

        if (!cubreInicio || !cubreFin)
            return false;

        double zSob = intervalo.ZTop;

        if (zSob <= pano.ZBase + MetrosAPies(0.02))
            return false;

        if (zSob >= pano.ZTop - MetrosAPies(0.02))
            return false;

        // Si el sobrecimiento queda casi a la base, no se cambia nada.
        if (Math.Abs(zSob - pano.ZBase) <= toleranciaZ)
            return false;

        zBaseRectangular = zSob;
        return true;
    }

    private PanoMuroMYG CrearPanoRectangularSobreSobrecimiento(
        PanoMuroMYG panoOriginal,
        double zBaseRectangular)
    {
        if (panoOriginal == null)
            return null;

        if (zBaseRectangular <= panoOriginal.ZBase)
            return null;

        if (zBaseRectangular >= panoOriginal.ZTop)
            return null;

        PanoMuroMYG pano = new PanoMuroMYG();
        pano.EjeU = panoOriginal.EjeU;
        pano.EjeV = panoOriginal.EjeV;
        pano.UInicio = panoOriginal.UInicio;
        pano.UFin = panoOriginal.UFin;
        pano.VCentro = panoOriginal.VCentro;
        pano.ZBase = zBaseRectangular;
        pano.ZTop = panoOriginal.ZTop;
        pano.Altura = pano.ZTop - pano.ZBase;

        return pano;
    }

    private List<Curve> CrearPerfilConDescuentoSobrecimiento(
        PanoMuroMYG pano,
        List<IntervaloSobrecimientoMYG> intervalosSobrecimiento)
    {
        List<Curve> perfil = new List<Curve>();

        if (pano == null || pano.EjeU == null || pano.EjeV == null)
            return perfil;

        if (intervalosSobrecimiento == null || intervalosSobrecimiento.Count == 0)
            return perfil;

        List<IntervaloSobrecimientoMYG> intervalos = UnirIntervalosSobrecimiento(
            intervalosSobrecimiento,
            MetrosAPies(0.02));

        if (intervalos == null || intervalos.Count == 0)
            return perfil;

        double uInicio = pano.UInicio;
        double uFin = pano.UFin;
        double zBase = pano.ZBase;
        double zTop = pano.ZTop;
        double tolerancia = MetrosAPies(0.005);

        List<XYZ> puntosPerfil = new List<XYZ>();

        // El perfil se arma en sentido horario dentro del plano vertical del muro:
        // parte inferior con escalones por sobrecimiento, lado derecho, borde superior y cierre.
        puntosPerfil.Add(CrearPuntoDesdeUV(uInicio, pano.VCentro, zBase, pano.EjeU, pano.EjeV));

        double uActual = uInicio;

        foreach (IntervaloSobrecimientoMYG intervalo in intervalos)
        {
            if (intervalo == null)
                continue;

            double ui = Math.Max(uInicio, intervalo.UInicio);
            double uf = Math.Min(uFin, intervalo.UFin);
            double zSob = Math.Max(zBase, Math.Min(intervalo.ZTop, zTop - MetrosAPies(0.02)));

            if (uf <= ui + tolerancia)
                continue;

            if (zSob <= zBase + MetrosAPies(0.02))
                continue;

            if (ui > uActual + tolerancia)
                puntosPerfil.Add(CrearPuntoDesdeUV(ui, pano.VCentro, zBase, pano.EjeU, pano.EjeV));

            puntosPerfil.Add(CrearPuntoDesdeUV(ui, pano.VCentro, zSob, pano.EjeU, pano.EjeV));
            puntosPerfil.Add(CrearPuntoDesdeUV(uf, pano.VCentro, zSob, pano.EjeU, pano.EjeV));
            puntosPerfil.Add(CrearPuntoDesdeUV(uf, pano.VCentro, zBase, pano.EjeU, pano.EjeV));

            uActual = uf;
        }

        if (uActual < uFin - tolerancia)
            puntosPerfil.Add(CrearPuntoDesdeUV(uFin, pano.VCentro, zBase, pano.EjeU, pano.EjeV));

        puntosPerfil.Add(CrearPuntoDesdeUV(uFin, pano.VCentro, zTop, pano.EjeU, pano.EjeV));
        puntosPerfil.Add(CrearPuntoDesdeUV(uInicio, pano.VCentro, zTop, pano.EjeU, pano.EjeV));

        for (int i = 0; i < puntosPerfil.Count; i++)
        {
            XYZ a = puntosPerfil[i];
            XYZ b = puntosPerfil[(i + 1) % puntosPerfil.Count];

            AgregarLineaPerfil(perfil, a, b);
        }

        return perfil;
    }

    private void AgregarLineaPerfil(List<Curve> perfil, XYZ a, XYZ b)
    {
        if (perfil == null || a == null || b == null)
            return;

        double dx = b.X - a.X;
        double dy = b.Y - a.Y;
        double dz = b.Z - a.Z;
        double longitud = Math.Sqrt(dx * dx + dy * dy + dz * dz);

        if (longitud <= MetrosAPies(0.005))
            return;

        try
        {
            perfil.Add(Line.CreateBound(a, b));
        }
        catch
        {
        }
    }

    private List<IntervaloSobrecimientoMYG> ObtenerIntervalosSobrecimientoParaPano(
        PanoMuroMYG pano,
        List<SobrecimientoMYG> sobrecimientosExistentes)
    {
        List<IntervaloSobrecimientoMYG> resultado = new List<IntervaloSobrecimientoMYG>();

        if (pano == null || sobrecimientosExistentes == null || sobrecimientosExistentes.Count == 0)
            return resultado;

        if (pano.EjeU == null || pano.EjeV == null)
            return resultado;

        // V19:
        // Ya NO se interpreta la interferencia como "sobrecimiento" ni se exige
        // que el sólido sea bajo, alargado o parecido a un muro.
        // Criterio nuevo:
        // Si CUALQUIER sólido nativo o vinculado intersecta la envolvente del muro a crear,
        // se toma su proyección U + su Z superior para descontar el perfil del muro.
        // Esto permite descontar suelos, losas, cimentaciones, muros, modelos genéricos,
        // familias cargables y cualquier categoría de modelo con sólido real.
        double toleranciaU = MetrosAPies(0.01);
        double toleranciaV = MetrosAPies(0.08);
        double toleranciaZ = MetrosAPies(0.003);
        double longitudMinimaSolape = MetrosAPies(0.02);
        double alturaMinimaDescuento = MetrosAPies(0.005);

        foreach (SobrecimientoMYG sobrecimiento in sobrecimientosExistentes)
        {
            if (sobrecimiento == null || sobrecimiento.PuntosHost == null || sobrecimiento.PuntosHost.Count == 0)
                continue;

            double uMin = double.MaxValue;
            double uMax = double.MinValue;
            double vMin = double.MaxValue;
            double vMax = double.MinValue;
            double zMin = double.MaxValue;
            double zMax = double.MinValue;

            foreach (XYZ p in sobrecimiento.PuntosHost)
            {
                if (p == null)
                    continue;

                double u = DotXY(p, pano.EjeU);
                double v = DotXY(p, pano.EjeV);

                if (u < uMin) uMin = u;
                if (u > uMax) uMax = u;
                if (v < vMin) vMin = v;
                if (v > vMax) vMax = v;
                if (p.Z < zMin) zMin = p.Z;
                if (p.Z > zMax) zMax = p.Z;
            }

            if (uMin == double.MaxValue || vMin == double.MaxValue || zMin == double.MaxValue)
                continue;

            // 1) Debe intersectar el tramo horizontal del muro.
            double uInterInicio = Math.Max(uMin, pano.UInicio);
            double uInterFin = Math.Min(uMax, pano.UFin);
            double solapeU = uInterFin - uInterInicio;

            if (solapeU < longitudMinimaSolape)
                continue;

            // 2) Debe cruzar la franja/plano real del muro.
            // Se evalúa como volumen de interferencia, no como sobrecimiento.
            if (pano.VCentro < vMin - toleranciaV || pano.VCentro > vMax + toleranciaV)
                continue;

            // 3) Debe intersectar verticalmente el muro que se va a crear.
            double zInterInicio = Math.Max(zMin, pano.ZBase);
            double zInterFin = Math.Min(zMax, pano.ZTop);

            if ((zInterFin - zInterInicio) <= toleranciaZ)
                continue;

            // 4) Para el perfil de muro se descuenta hasta la cara superior del sólido
            // que interfiere. Si el sólido sube por encima del paño, se limita al ZTop
            // del propio paño para no generar perfiles inválidos.
            double zDescuento = Math.Min(zMax, pano.ZTop - toleranciaZ);

            if (zDescuento <= pano.ZBase + alturaMinimaDescuento)
                continue;

            IntervaloSobrecimientoMYG intervalo = new IntervaloSobrecimientoMYG();
            intervalo.UInicio = Math.Max(uInterInicio - toleranciaU, pano.UInicio);
            intervalo.UFin = Math.Min(uInterFin + toleranciaU, pano.UFin);
            intervalo.ZTop = zDescuento;
            resultado.Add(intervalo);
        }

        return UnirIntervalosSobrecimiento(resultado, MetrosAPies(0.01));
    }

    private List<IntervaloSobrecimientoMYG> UnirIntervalosSobrecimiento(
        List<IntervaloSobrecimientoMYG> intervalos,
        double tolerancia)
    {
        List<IntervaloSobrecimientoMYG> resultado = new List<IntervaloSobrecimientoMYG>();

        if (intervalos == null || intervalos.Count == 0)
            return resultado;

        List<IntervaloSobrecimientoMYG> ordenados = intervalos
            .Where(x => x != null && x.UFin > x.UInicio)
            .OrderBy(x => x.UInicio)
            .ToList();

        foreach (IntervaloSobrecimientoMYG intervalo in ordenados)
        {
            if (resultado.Count == 0)
            {
                resultado.Add(new IntervaloSobrecimientoMYG()
                {
                    UInicio = intervalo.UInicio,
                    UFin = intervalo.UFin,
                    ZTop = intervalo.ZTop
                });
                continue;
            }

            IntervaloSobrecimientoMYG ultimo = resultado[resultado.Count - 1];

            if (intervalo.UInicio <= ultimo.UFin + tolerancia)
            {
                if (intervalo.UFin > ultimo.UFin)
                    ultimo.UFin = intervalo.UFin;

                if (intervalo.ZTop > ultimo.ZTop)
                    ultimo.ZTop = intervalo.ZTop;
            }
            else
            {
                resultado.Add(new IntervaloSobrecimientoMYG()
                {
                    UInicio = intervalo.UInicio,
                    UFin = intervalo.UFin,
                    ZTop = intervalo.ZTop
                });
            }
        }

        return resultado;
    }

    private List<SobrecimientoMYG> ObtenerSobrecimientosExistentes(Document docHost, Autodesk.Revit.DB.View vistaHost, HashSet<string> clavesElementosMarcoExcluir)
    {
        List<SobrecimientoMYG> resultado = new List<SobrecimientoMYG>();

        if (docHost == null)
            return resultado;

        if (vistaHost == null)
        {
            try
            {
                vistaHost = docHost.ActiveView;
            }
            catch
            {
                vistaHost = null;
            }
        }

        // V23 - 1) Elementos nativos VISIBLES en la vista activa.
        // Se usa FilteredElementCollector(doc, view.Id), así no se toman elementos
        // ocultos en la vista, apagados por categoría, fuera del rango/caja de sección
        // o no visibles según la configuración de esa vista.
        AgregarSobrecimientosDocumento(
            docHost,
            Transform.Identity,
            ElementId.InvalidElementId,
            false,
            resultado,
            vistaHost,
            true,
            clavesElementosMarcoExcluir);

        // V23 - 2) Elementos de vínculos Revit, pero solo desde instancias de vínculo
        // visibles en la vista activa del host. Si un vínculo completo está oculto en
        // la vista, sus sólidos ya no se usan para descontar.
        HashSet<string> documentosVisitados = new HashSet<string>();
        AgregarSobrecimientosVinculosRecursivo(
            docHost,
            Transform.Identity,
            0,
            documentosVisitados,
            resultado,
            vistaHost,
            clavesElementosMarcoExcluir);

        return resultado;
    }

    private void AgregarSobrecimientosVinculosRecursivo(
        Document docOrigen,
        Transform transformOrigenAHost,
        int profundidad,
        HashSet<string> documentosVisitados,
        List<SobrecimientoMYG> resultado,
        Autodesk.Revit.DB.View vistaHost,
        HashSet<string> clavesElementosMarcoExcluir)
    {
        if (docOrigen == null || resultado == null)
            return;

        if (transformOrigenAHost == null)
            transformOrigenAHost = Transform.Identity;

        if (documentosVisitados == null)
            documentosVisitados = new HashSet<string>();

        if (profundidad > 4)
            return;

        string claveDoc = ObtenerClaveDocumento(docOrigen);

        if (!string.IsNullOrWhiteSpace(claveDoc))
        {
            string claveProfundidad = profundidad.ToString() + "|" + claveDoc;

            if (documentosVisitados.Contains(claveProfundidad))
                return;

            documentosVisitados.Add(claveProfundidad);
        }

        try
        {
            FilteredElementCollector collectorLinks = null;

            // En el documento host se buscan solo vínculos visibles en la vista activa.
            // En vínculos anidados no se puede aplicar directamente la vista del host
            // sobre el documento vinculado, por eso se filtra el primer nivel por vista
            // y luego se aplica la transformación acumulada.
            if (profundidad == 0 && vistaHost != null && vistaHost.Document != null && vistaHost.Document.Equals(docOrigen))
            {
                try
                {
                    collectorLinks = new FilteredElementCollector(docOrigen, vistaHost.Id);
                }
                catch
                {
                    collectorLinks = null;
                }
            }

            if (collectorLinks == null)
                collectorLinks = new FilteredElementCollector(docOrigen);

            collectorLinks.OfClass(typeof(RevitLinkInstance));
            collectorLinks.WhereElementIsNotElementType();

            foreach (Element elemento in collectorLinks)
            {
                RevitLinkInstance link = elemento as RevitLinkInstance;

                if (link == null)
                    continue;

                // Si estamos en el host, se valida explícitamente que el vínculo esté visible.
                if (profundidad == 0 && vistaHost != null && !EsElementoVisibleEnVistaHost(link, vistaHost))
                    continue;

                Document docLink = null;

                try
                {
                    docLink = link.GetLinkDocument();
                }
                catch
                {
                    docLink = null;
                }

                if (docLink == null)
                    continue;

                Transform transformLink = ObtenerTransformVinculo(link);

                if (transformLink == null)
                    transformLink = Transform.Identity;

                Transform transformLinkAHost = transformOrigenAHost.Multiply(transformLink);

                AgregarSobrecimientosDocumento(
                    docLink,
                    transformLinkAHost,
                    link.Id,
                    true,
                    resultado,
                    null,
                    false,
                    clavesElementosMarcoExcluir);

                AgregarSobrecimientosVinculosRecursivo(
                    docLink,
                    transformLinkAHost,
                    profundidad + 1,
                    documentosVisitados,
                    resultado,
                    vistaHost,
                    clavesElementosMarcoExcluir);
            }
        }
        catch
        {
        }
    }

    private string ObtenerClaveDocumento(Document doc)
    {
        if (doc == null)
            return "";

        try
        {
            if (!string.IsNullOrWhiteSpace(doc.PathName))
                return doc.PathName;
        }
        catch
        {
        }

        try
        {
            return doc.Title + "|" + doc.GetHashCode().ToString();
        }
        catch
        {
        }

        return "";
    }

    private void AgregarSobrecimientosDocumento(
        Document docOrigen,
        Transform transformAHost,
        ElementId linkInstanceId,
        bool esVinculado,
        List<SobrecimientoMYG> resultado,
        Autodesk.Revit.DB.View vistaFiltro,
        bool usarFiltroVista,
        HashSet<string> clavesElementosMarcoExcluir)
    {
        if (docOrigen == null || resultado == null)
            return;

        if (transformAHost == null)
            transformAHost = Transform.Identity;

        try
        {
            FilteredElementCollector collector = null;

            // V23:
            // Para el documento anfitrión se recolecta únicamente lo visible en la vista activa.
            // Este constructor respeta ocultar/aislar, categorías apagadas, caja de sección,
            // rango/corte de vista y visibilidad propia de la vista.
            if (usarFiltroVista && vistaFiltro != null && vistaFiltro.Document != null && vistaFiltro.Document.Equals(docOrigen))
            {
                try
                {
                    collector = new FilteredElementCollector(docOrigen, vistaFiltro.Id);
                }
                catch
                {
                    collector = null;
                }
            }

            if (collector == null)
            {
                // Si no se puede usar filtro por vista, no se deben tomar elementos nativos ocultos.
                // Para vínculos sí se permite este fallback porque ya se validó que la instancia
                // del vínculo esté visible en el host.
                if (usarFiltroVista && !esVinculado)
                    return;

                collector = new FilteredElementCollector(docOrigen);
            }

            collector.WhereElementIsNotElementType();

            foreach (Element elemento in collector)
            {
                if (elemento == null)
                    continue;

                // V24:
                // No se usa como descuento la propia estructura seleccionada para formar el marco
                // porque genera cortes falsos dentro del muro nuevo.
                if (EsElementoExcluidoDelDescuento(
                    elemento,
                    linkInstanceId,
                    esVinculado,
                    clavesElementosMarcoExcluir))
                {
                    continue;
                }

                if (!ElementoPuedeSerDescuentoPorSolido(elemento))
                    continue;

                if (usarFiltroVista && vistaFiltro != null && !EsElementoVisibleEnVistaHost(elemento, vistaFiltro))
                    continue;

                SobrecimientoMYG sobrecimiento = CrearSobrecimientoDesdeElementoSolido(
                    elemento,
                    transformAHost,
                    linkInstanceId,
                    esVinculado);

                if (sobrecimiento != null)
                    resultado.Add(sobrecimiento);
            }
        }
        catch
        {
        }
    }

    private bool EsElementoVisibleEnVistaHost(Element elemento, Autodesk.Revit.DB.View vista)
    {
        if (elemento == null)
            return false;

        if (vista == null)
            return true;

        try
        {
            if (!elemento.IsValidObject)
                return false;
        }
        catch
        {
        }

        try
        {
            if (elemento.IsHidden(vista))
                return false;
        }
        catch
        {
        }

        try
        {
            Category categoria = elemento.Category;

            if (categoria != null && vista.GetCategoryHidden(categoria.Id))
                return false;
        }
        catch
        {
        }

        try
        {
            BoundingBoxXYZ bbVista = elemento.get_BoundingBox(vista);

            if (bbVista == null)
                return false;
        }
        catch
        {
            // Si Revit no permite leer bounding box para ese elemento en esa vista,
            // se deja pasar porque el collector por vista ya hizo el filtro principal.
        }

        return true;
    }

    private HashSet<string> ObtenerClavesElementosMarcoParaExcluir(List<ElementoMarcoMYG> elementosMarco)
    {
        HashSet<string> claves = new HashSet<string>();

        if (elementosMarco == null)
            return claves;

        foreach (ElementoMarcoMYG elemento in elementosMarco)
        {
            if (elemento == null)
                continue;

            if (elemento.LinkInstanceId == null || elemento.LinkedElementId == null)
                continue;

            string clave = CrearClaveElementoDescuento(
                elemento.LinkInstanceId,
                true,
                elemento.LinkedElementId);

            if (!string.IsNullOrWhiteSpace(clave) && !claves.Contains(clave))
                claves.Add(clave);
        }

        return claves;
    }

    private bool EsElementoExcluidoDelDescuento(
        Element elemento,
        ElementId linkInstanceId,
        bool esVinculado,
        HashSet<string> clavesElementosMarcoExcluir)
    {
        if (elemento == null)
            return false;

        if (clavesElementosMarcoExcluir == null || clavesElementosMarcoExcluir.Count == 0)
            return false;

        string clave = CrearClaveElementoDescuento(
            linkInstanceId,
            esVinculado,
            elemento.Id);

        if (string.IsNullOrWhiteSpace(clave))
            return false;

        return clavesElementosMarcoExcluir.Contains(clave);
    }

    private string CrearClaveElementoDescuento(
        ElementId linkInstanceId,
        bool esVinculado,
        ElementId elementoId)
    {
        if (elementoId == null || elementoId == ElementId.InvalidElementId)
            return "";

        if (esVinculado)
        {
            string link = "LINK_INVALID";

            try
            {
                if (linkInstanceId != null && linkInstanceId != ElementId.InvalidElementId)
                    link = linkInstanceId.Value.ToString();
            }
            catch
            {
            }

            return "LINK|" + link + "|" + elementoId.Value.ToString();
        }

        return "HOST|" + elementoId.Value.ToString();
    }

    private bool ElementoPuedeSerDescuentoPorSolido(Element elemento)
    {
        if (elemento == null)
            return false;

        // Evita procesar vínculos como sólidos nativos. Los vínculos se leen aparte
        // entrando a su documento y aplicando su transform hacia el host.
        if (elemento is RevitLinkInstance)
            return false;

        Category categoria = null;

        try
        {
            categoria = elemento.Category;
        }
        catch
        {
            categoria = null;
        }

        if (categoria == null)
            return false;

        try
        {
            if (categoria.CategoryType != CategoryType.Model)
                return false;
        }
        catch
        {
            return false;
        }

        // Evita tipos, vistas, niveles, materiales, grids u objetos sin geometría sólida útil.
        if (elemento is ElementType)
            return false;

        if (elemento is Autodesk.Revit.DB.View)
            return false;

        if (elemento is Level)
            return false;

        if (elemento is Grid)
            return false;

        return true;
    }

    private SobrecimientoMYG CrearSobrecimientoDesdeElementoSolido(
        Element elemento,
        Transform transformAHost,
        ElementId linkInstanceId,
        bool esVinculado)
    {
        if (elemento == null)
            return null;

        if (transformAHost == null)
            transformAHost = Transform.Identity;

        // V17:
        // Se usa geometría sólida real. No se usa bounding box como criterio principal,
        // porque el objetivo es descontar por la forma real del sólido y no por su caja.
        List<XYZ> puntos = ObtenerPuntosGeometriaHost(elemento, transformAHost);

        if (puntos == null || puntos.Count < 4)
            return null;

        double zMin = double.MaxValue;
        double zMax = double.MinValue;

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            if (p.Z < zMin) zMin = p.Z;
            if (p.Z > zMax) zMax = p.Z;
        }

        if (zMin == double.MaxValue || zMax == double.MinValue)
            return null;

        if ((zMax - zMin) <= MetrosAPies(0.02))
            return null;

        SobrecimientoMYG sobrecimiento = new SobrecimientoMYG();
        sobrecimiento.PuntosHost = puntos;
        sobrecimiento.ZMin = zMin;
        sobrecimiento.ZMax = zMax;
        sobrecimiento.ElementId = elemento.Id;
        sobrecimiento.LinkInstanceId = linkInstanceId;
        sobrecimiento.EsVinculado = esVinculado;
        sobrecimiento.Nombre = ObtenerNombreElemento(elemento);
        sobrecimiento.Categoria = ObtenerCategoriaElemento(elemento);

        return sobrecimiento;
    }

    // =========================================================
    // AGRUPAR POR PLANO DE MURO
    // =========================================================

    private List<GrupoMarcoMYG> AgruparPorPlano(
        List<ElementoMarcoMYG> elementos,
        XYZ ejeU,
        XYZ ejeV)
    {
        List<GrupoMarcoMYG> grupos = new List<GrupoMarcoMYG>();

        if (elementos == null || elementos.Count == 0 || ejeU == null || ejeV == null)
            return grupos;

        // V7:
        // Para cada dirección local solo deben participar:
        // - las columnetas/pilares, porque pueden delimitar el paño en cualquier sentido;
        // - las vigas/armazones que realmente son paralelas a ese eje U.
        // Antes entraban todas las vigas en todos los sentidos y eso podía formar muros
        // amarrados a X/Y global o cruzando zonas que no pertenecían al marco real.
        List<ElementoMarcoMYG> compatibles = elementos
            .Where(x => EsElementoCompatibleConEjeActual(x, ejeU))
            .ToList();

        if (compatibles.Count == 0)
            return grupos;

        // Tolerancia de plano. Se usa una tolerancia moderada para agrupar elementos
        // que están en la misma franja real del confinamiento, pero sin mezclar
        // marcos paralelos cercanos.
        double toleranciaPlano = MetrosAPies(0.22);

        List<ElementoMarcoMYG> ordenados = compatibles
            .Where(x => x != null)
            .OrderBy(x => x.VCentro)
            .ToList();

        foreach (ElementoMarcoMYG elemento in ordenados)
        {
            if (elemento == null)
                continue;

            GrupoMarcoMYG grupoEncontrado = null;
            double menorDistancia = double.MaxValue;

            foreach (GrupoMarcoMYG grupo in grupos)
            {
                if (grupo == null)
                    continue;

                double distancia = Math.Abs(elemento.VCentro - grupo.VCentro);

                if (distancia < toleranciaPlano && distancia < menorDistancia)
                {
                    menorDistancia = distancia;
                    grupoEncontrado = grupo;
                }
            }

            if (grupoEncontrado == null)
            {
                grupoEncontrado = new GrupoMarcoMYG();
                grupoEncontrado.EjeU = ejeU;
                grupoEncontrado.EjeV = ejeV;
                grupoEncontrado.Elementos = new List<ElementoMarcoMYG>();
                grupoEncontrado.VCentro = elemento.VCentro;
                grupos.Add(grupoEncontrado);
            }

            grupoEncontrado.Elementos.Add(elemento);
            grupoEncontrado.VCentro = ObtenerVCentroGrupoAlEje(grupoEncontrado);
        }

        // Solo quedan grupos con al menos 2 columnas.
        grupos = grupos
            .Where(g => g != null && g.Elementos != null && g.Elementos.Count(x => x != null && x.EsColumna) >= 2)
            .ToList();

        return grupos;
    }

    private bool EsElementoCompatibleConEjeActual(ElementoMarcoMYG elemento, XYZ ejeUActual)
    {
        if (elemento == null)
            return false;

        if (elemento.EsColumna)
            return true;

        if (!elemento.EsVigaConfinamiento)
            return false;

        // V12:
        // En versiones anteriores bastaba que el bounding box local tuviera mayor desarrollo en U.
        // Eso mezclaba vigas de direcciones cercanas, pero no realmente paralelas, y el muro
        // podía salir con una dirección distinta a la cara real de las columnetas/vigas.
        // Ahora primero se valida el EJE REAL de la viga contra el eje que se está evaluando.
        XYZ dirViga = ObtenerDireccionEjeElementoHost(elemento);

        if (dirViga != null && ejeUActual != null)
        {
            double dot = Math.Abs(DotXY(dirViga, ejeUActual));

            // 0.985 ≈ hasta 10°. Si se baja más, se puede perder geometría ligeramente imprecisa.
            // Lo importante es que ya no se aceptan direcciones cercanas de 15° a 20° como antes.
            if (dot < 0.985)
                return false;
        }

        // En el sistema local U/V ya calculado para la dirección actual:
        // si la viga de confinamiento tiene mayor desarrollo en U que en V,
        // entonces sí pertenece a ese sentido del marco.
        double desarrolloU = elemento.UMax - elemento.UMin;
        double desarrolloV = elemento.VMax - elemento.VMin;

        if (desarrolloU <= MetrosAPies(0.10))
            return false;

        if (desarrolloU >= desarrolloV * 1.20)
            return true;

        return false;
    }

    private double ObtenerVCentroGrupoAlEje(GrupoMarcoMYG grupo)
    {
        if (grupo == null || grupo.Elementos == null || grupo.Elementos.Count == 0)
            return 0.0;

        // El eje del grupo se toma principalmente desde las columnetas,
        // porque ellas definen el plano real del confinamiento.
        List<double> valoresColumnas = grupo.Elementos
            .Where(x => x != null && x.EsColumna)
            .Select(x => x.VCentro)
            .ToList();

        if (valoresColumnas.Count > 0)
            return ObtenerMediana(valoresColumnas);

        List<double> valoresTodos = grupo.Elementos
            .Where(x => x != null)
            .Select(x => x.VCentro)
            .ToList();

        if (valoresTodos.Count > 0)
            return ObtenerMediana(valoresTodos);

        return 0.0;
    }

    private List<XYZ> ObtenerEjesUEvaluacion(List<ElementoMarcoMYG> elementos)
    {
        List<XYZ> ejes = new List<XYZ>();

        if (elementos == null || elementos.Count == 0)
        {
            AgregarEjeBaseYPerpendicular(ejes, XYZ.BasisX);
            return ejes;
        }

        double longitudMinima = MetrosAPies(0.20);

        // V8 - Prioridad 1:
        // tomar solo direcciones reales de VIGAS DE CONFINAMIENTO válidas.
        // Se omiten diagonales, riostras e inclinados que también pertenecen a
        // Armazón estructural pero no encierran paños de albañilería.
        foreach (ElementoMarcoMYG elemento in elementos)
        {
            if (elemento == null || !elemento.EsVigaConfinamiento || elemento.ElementoLink == null)
                continue;

            try
            {
                LocationCurve locCurve = elemento.ElementoLink.Location as LocationCurve;

                if (locCurve == null || locCurve.Curve == null)
                    continue;

                XYZ p0 = elemento.TransformLink.OfPoint(locCurve.Curve.GetEndPoint(0));
                XYZ p1 = elemento.TransformLink.OfPoint(locCurve.Curve.GetEndPoint(1));

                if (DistanciaXY(p0, p1) < longitudMinima)
                    continue;

                XYZ dir = new XYZ(p1.X - p0.X, p1.Y - p0.Y, 0.0);
                XYZ dirN = OrientarEjeDeterministico(dir);

                AgregarEjeSiNoEsParalelo(ejes, dirN);
            }
            catch
            {
            }
        }

        // V7 - Prioridad 2:
        // si hay tramos delimitados solo por columnetas, se agregan direcciones
        // entre pares de columnetas cercanas, pero solo cuando son coherentes con
        // alguna dirección de viga ya detectada. Si no hay vigas, se usan como base.
        List<ElementoMarcoMYG> columnas = elementos
            .Where(x => x != null && x.EsColumna && x.Centro != null)
            .ToList();

        bool existenEjesDeViga = ejes.Count > 0;

        // V13:
        // Si ya hay direcciones reales tomadas de vigas de confinamiento, no se agregan
        // direcciones entre pares de columnetas. Esas diagonales de centro a centro podían
        // generar varios muros inclinados dentro de un solo paño.
        if (existenEjesDeViga)
            return ejes;

        double distanciaMaximaColumnas = MetrosAPies(8.00);

        for (int i = 0; i < columnas.Count; i++)
        {
            for (int j = i + 1; j < columnas.Count; j++)
            {
                XYZ a = columnas[i].Centro;
                XYZ b = columnas[j].Centro;

                if (a == null || b == null)
                    continue;

                double distancia = DistanciaXY(a, b);

                if (distancia < longitudMinima || distancia > distanciaMaximaColumnas)
                    continue;

                XYZ dirCol = OrientarEjeDeterministico(new XYZ(b.X - a.X, b.Y - a.Y, 0.0));

                if (dirCol == null)
                    continue;

                if (existenEjesDeViga && !ExisteEjeParalelo(ejes, dirCol, 0.93))
                    continue;

                AgregarEjeSiNoEsParalelo(ejes, dirCol);
            }
        }

        if (ejes.Count == 0)
        {
            XYZ ejePrincipal = ObtenerEjeUPrincipal(elementos);

            if (ejePrincipal == null)
                ejePrincipal = XYZ.BasisX;

            AgregarEjeSiNoEsParalelo(ejes, OrientarEjeDeterministico(ejePrincipal));
        }

        // V8:
        // Ya NO se agregan perpendiculares automáticas.
        // Cada sentido se evalúa únicamente si existe una viga de confinamiento real
        // en esa dirección. Esto evita muros falsos en diagonales o proyecciones.

        if (ejes.Count == 0)
            AgregarEjeBaseYPerpendicular(ejes, XYZ.BasisX);

        return ejes;
    }

    private void AgregarEjeBaseYPerpendicular(List<XYZ> ejes, XYZ ejeBase)
    {
        if (ejes == null)
            return;

        XYZ eje = OrientarEjeDeterministico(ejeBase);
        AgregarEjeSiNoEsParalelo(ejes, eje);

        if (eje != null)
        {
            XYZ ejePerpendicular = new XYZ(-eje.Y, eje.X, 0.0);
            AgregarEjeSiNoEsParalelo(ejes, OrientarEjeDeterministico(ejePerpendicular));
        }
    }

    private bool ExisteEjeParalelo(List<XYZ> ejes, XYZ eje, double toleranciaDot)
    {
        if (ejes == null || eje == null)
            return false;

        XYZ n = NormalizarXY(eje);

        if (n == null)
            return false;

        foreach (XYZ existente in ejes)
        {
            if (existente == null)
                continue;

            double dot = Math.Abs(DotXY(n, existente));

            if (dot >= toleranciaDot)
                return true;
        }

        return false;
    }

    private void AgregarEjeSiNoEsParalelo(List<XYZ> ejes, XYZ eje)
    {
        if (ejes == null || eje == null)
            return;

        XYZ n = NormalizarXY(eje);

        if (n == null)
            return;

        foreach (XYZ existente in ejes)
        {
            if (existente == null)
                continue;

            double dot = Math.Abs(DotXY(n, existente));

            // V12:
            // Antes era 0.95, equivalente a mezclar direcciones con hasta ±18°.
            // En tramos ligeramente inclinados eso hacía que un paño se cree con el eje de otro.
            // 0.995 separa direcciones que difieren más de aprox. 5.7°.
            if (dot > 0.995)
                return;
        }

        ejes.Add(n);
    }

    private XYZ ObtenerEjeUPrincipal(List<ElementoMarcoMYG> elementos)
    {
        if (elementos == null || elementos.Count == 0)
            return XYZ.BasisX;

        XYZ mejorDir = null;
        double mayorLongitud = 0.0;

        foreach (ElementoMarcoMYG elemento in elementos)
        {
            if (elemento == null || !elemento.EsVigaConfinamiento || elemento.ElementoLink == null)
                continue;

            try
            {
                LocationCurve locCurve = elemento.ElementoLink.Location as LocationCurve;

                if (locCurve == null || locCurve.Curve == null)
                    continue;

                XYZ p0 = elemento.TransformLink.OfPoint(locCurve.Curve.GetEndPoint(0));
                XYZ p1 = elemento.TransformLink.OfPoint(locCurve.Curve.GetEndPoint(1));

                XYZ dir = new XYZ(p1.X - p0.X, p1.Y - p0.Y, 0.0);
                XYZ dirN = NormalizarXY(dir);

                if (dirN == null)
                    continue;

                double longitud = DistanciaXY(p0, p1);

                if (longitud > mayorLongitud)
                {
                    mayorLongitud = longitud;
                    mejorDir = dirN;
                }
            }
            catch
            {
            }
        }

        if (mejorDir != null)
            return OrientarEjeDeterministico(mejorDir);

        List<ElementoMarcoMYG> columnas = elementos.Where(x => x != null && x.EsColumna && x.Centro != null).ToList();

        double mayorDistancia = 0.0;

        for (int i = 0; i < columnas.Count; i++)
        {
            for (int j = i + 1; j < columnas.Count; j++)
            {
                XYZ a = columnas[i].Centro;
                XYZ b = columnas[j].Centro;

                if (a == null || b == null)
                    continue;

                double distancia = DistanciaXY(a, b);

                if (distancia > mayorDistancia)
                {
                    mayorDistancia = distancia;
                    mejorDir = NormalizarXY(new XYZ(b.X - a.X, b.Y - a.Y, 0.0));
                }
            }
        }

        if (mejorDir != null)
            return OrientarEjeDeterministico(mejorDir);

        return XYZ.BasisX;
    }

    private XYZ OrientarEjeDeterministico(XYZ eje)
    {
        if (eje == null)
            return XYZ.BasisX;

        XYZ n = NormalizarXY(eje);

        if (n == null)
            return XYZ.BasisX;

        if (n.X < -0.0001)
            return new XYZ(-n.X, -n.Y, 0.0);

        if (Math.Abs(n.X) <= 0.0001 && n.Y < 0.0)
            return new XYZ(-n.X, -n.Y, 0.0);

        return n;
    }

    // =========================================================
    // PUNTOS DE GEOMETRÍA
    // =========================================================

    private List<XYZ> ObtenerPuntosGeometriaHost(
        Element elementoLink,
        Transform transformLink)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (elementoLink == null)
            return puntos;

        if (transformLink == null)
            transformLink = Transform.Identity;

        Options opciones = new Options();
        opciones.ComputeReferences = false;
        opciones.IncludeNonVisibleObjects = false;
        opciones.DetailLevel = ViewDetailLevel.Fine;

        GeometryElement geo = null;

        try
        {
            geo = elementoLink.get_Geometry(opciones);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return puntos;

        ProcesarGeometryElementHost(geo, transformLink, puntos);

        return puntos;
    }

    private void ProcesarGeometryElementHost(
        GeometryElement geo,
        Transform transformAcumulado,
        List<XYZ> puntos)
    {
        if (geo == null || puntos == null)
            return;

        if (transformAcumulado == null)
            transformAcumulado = Transform.Identity;

        foreach (GeometryObject obj in geo)
        {
            if (obj == null)
                continue;

            Solid solid = obj as Solid;

            if (solid != null)
            {
                AgregarPuntosSolidHost(solid, transformAcumulado, puntos);
                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi != null)
            {
                try
                {
                    Transform tInstancia = gi.Transform;

                    if (tInstancia == null)
                        tInstancia = Transform.Identity;

                    Transform transformNuevo = transformAcumulado.Multiply(tInstancia);
                    GeometryElement geoInst = gi.GetSymbolGeometry();

                    if (geoInst != null)
                        ProcesarGeometryElementHost(geoInst, transformNuevo, puntos);
                }
                catch
                {
                    try
                    {
                        GeometryElement geoInstFallback = gi.GetInstanceGeometry();

                        if (geoInstFallback != null)
                            ProcesarGeometryElementHost(geoInstFallback, transformAcumulado, puntos);
                    }
                    catch
                    {
                    }
                }
            }
        }
    }

    private void AgregarPuntosSolidHost(
        Solid solid,
        Transform transform,
        List<XYZ> puntos)
    {
        if (solid == null || puntos == null)
            return;

        try
        {
            if (solid.Volume <= 0.0000001)
                return;
        }
        catch
        {
        }

        try
        {
            EdgeArray edges = solid.Edges;

            if (edges == null)
                return;

            foreach (Edge edge in edges)
            {
                if (edge == null)
                    continue;

                IList<XYZ> tess = null;

                try
                {
                    tess = edge.Tessellate();
                }
                catch
                {
                    tess = null;
                }

                if (tess == null)
                    continue;

                foreach (XYZ pLocal in tess)
                {
                    if (pLocal == null)
                        continue;

                    try
                    {
                        XYZ pHost = transform.OfPoint(pLocal);

                        if (pHost != null)
                            puntos.Add(pHost);
                    }
                    catch
                    {
                    }
                }
            }
        }
        catch
        {
        }
    }

    private List<XYZ> ObtenerPuntosBoundingBoxHost(
        Element elementoLink,
        Transform transformLink)
    {
        List<XYZ> puntos = new List<XYZ>();

        if (elementoLink == null)
            return puntos;

        if (transformLink == null)
            transformLink = Transform.Identity;

        BoundingBoxXYZ bb = null;

        try
        {
            bb = elementoLink.get_BoundingBox(null);
        }
        catch
        {
            bb = null;
        }

        if (bb == null)
            return puntos;

        Transform tfBB = null;

        try
        {
            tfBB = bb.Transform;
        }
        catch
        {
            tfBB = null;
        }

        if (tfBB == null)
            tfBB = Transform.Identity;

        XYZ min = bb.Min;
        XYZ max = bb.Max;

        List<XYZ> corners = new List<XYZ>();

        corners.Add(new XYZ(min.X, min.Y, min.Z));
        corners.Add(new XYZ(max.X, min.Y, min.Z));
        corners.Add(new XYZ(max.X, max.Y, min.Z));
        corners.Add(new XYZ(min.X, max.Y, min.Z));

        corners.Add(new XYZ(min.X, min.Y, max.Z));
        corners.Add(new XYZ(max.X, min.Y, max.Z));
        corners.Add(new XYZ(max.X, max.Y, max.Z));
        corners.Add(new XYZ(min.X, max.Y, max.Z));

        foreach (XYZ pLocal in corners)
        {
            try
            {
                XYZ pLink = tfBB.OfPoint(pLocal);
                XYZ pHost = transformLink.OfPoint(pLink);

                puntos.Add(pHost);
            }
            catch
            {
            }
        }

        return puntos;
    }

    // =========================================================
    // INTERVALOS / GEOMETRÍA BASE
    // =========================================================

    private void CalcularZMinMax(ElementoMarcoMYG info)
    {
        if (info == null || info.PuntosHost == null)
            return;

        info.ZMin = double.MaxValue;
        info.ZMax = double.MinValue;

        foreach (XYZ p in info.PuntosHost)
        {
            if (p == null)
                continue;

            if (p.Z < info.ZMin)
                info.ZMin = p.Z;

            if (p.Z > info.ZMax)
                info.ZMax = p.Z;
        }
    }

    private XYZ CalcularCentroPuntos(List<XYZ> puntos)
    {
        if (puntos == null || puntos.Count == 0)
            return null;

        double x = 0.0;
        double y = 0.0;
        double z = 0.0;
        int n = 0;

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            x += p.X;
            y += p.Y;
            z += p.Z;
            n++;
        }

        if (n == 0)
            return null;

        return new XYZ(x / n, y / n, z / n);
    }

    private double ObtenerLongitudEjeElementoHost(Element elementoLink, Transform transformLink)
    {
        if (elementoLink == null)
            return 0.0;

        if (transformLink == null)
            transformLink = Transform.Identity;

        try
        {
            LocationCurve locCurve = elementoLink.Location as LocationCurve;

            if (locCurve != null && locCurve.Curve != null)
            {
                XYZ p0 = transformLink.OfPoint(locCurve.Curve.GetEndPoint(0));
                XYZ p1 = transformLink.OfPoint(locCurve.Curve.GetEndPoint(1));

                return DistanciaXY(p0, p1);
            }
        }
        catch
        {
        }

        return 0.0;
    }

    private double ObtenerDeltaZEjeElementoHost(Element elementoLink, Transform transformLink)
    {
        if (elementoLink == null)
            return 0.0;

        if (transformLink == null)
            transformLink = Transform.Identity;

        try
        {
            LocationCurve locCurve = elementoLink.Location as LocationCurve;

            if (locCurve != null && locCurve.Curve != null)
            {
                XYZ p0 = transformLink.OfPoint(locCurve.Curve.GetEndPoint(0));
                XYZ p1 = transformLink.OfPoint(locCurve.Curve.GetEndPoint(1));

                return Math.Abs(p1.Z - p0.Z);
            }
        }
        catch
        {
        }

        return 0.0;
    }

    private XYZ ObtenerDireccionEjeElementoHost(ElementoMarcoMYG elemento)
    {
        if (elemento == null || elemento.ElementoLink == null)
            return null;

        Transform transformLink = elemento.TransformLink;

        if (transformLink == null)
            transformLink = Transform.Identity;

        try
        {
            LocationCurve locCurve = elemento.ElementoLink.Location as LocationCurve;

            if (locCurve != null && locCurve.Curve != null)
            {
                XYZ p0 = transformLink.OfPoint(locCurve.Curve.GetEndPoint(0));
                XYZ p1 = transformLink.OfPoint(locCurve.Curve.GetEndPoint(1));

                XYZ dir = new XYZ(p1.X - p0.X, p1.Y - p0.Y, 0.0);
                return NormalizarXY(dir);
            }
        }
        catch
        {
        }

        return null;
    }

    private bool EsVigaDeConfinamientoValida(ElementoMarcoMYG elemento)
    {
        if (elemento == null || !elemento.EsViga)
            return false;

        if (elemento.LongitudEje < MetrosAPies(0.20))
            return false;

        // Las vigas de confinamiento que cierran paños son prácticamente horizontales.
        // Los armazones diagonales o inclinados pueden estar en la misma categoría,
        // pero no deben generar muros.
        double pendienteMaxima = Math.Max(MetrosAPies(0.08), elemento.LongitudEje * 0.08);

        if (Math.Abs(elemento.DeltaZEje) > pendienteMaxima)
            return false;

        double altoElemento = elemento.ZMax - elemento.ZMin;

        // Si el propio armazón tiene demasiada variación vertical, suele ser riostra,
        // diagonal o elemento inclinado; se descarta como confinamiento.
        if (altoElemento > MetrosAPies(0.80))
            return false;

        return true;
    }

    private List<IntervaloZMYG> UnirBandasZ(List<IntervaloZMYG> bandas, double tolerancia)
    {
        List<IntervaloZMYG> resultado = new List<IntervaloZMYG>();

        if (bandas == null || bandas.Count == 0)
            return resultado;

        List<IntervaloZMYG> ordenadas = bandas
            .Where(x => x != null && x.Max > x.Min)
            .OrderBy(x => x.Min)
            .ToList();

        foreach (IntervaloZMYG banda in ordenadas)
        {
            if (resultado.Count == 0)
            {
                resultado.Add(new IntervaloZMYG() { Min = banda.Min, Max = banda.Max });
                continue;
            }

            IntervaloZMYG ultima = resultado[resultado.Count - 1];

            if (banda.Min <= ultima.Max + tolerancia)
            {
                if (banda.Max > ultima.Max)
                    ultima.Max = banda.Max;
            }
            else
            {
                resultado.Add(new IntervaloZMYG() { Min = banda.Min, Max = banda.Max });
            }
        }

        return resultado;
    }

    private bool IntervalosSeSolapan(
        double aMin,
        double aMax,
        double bMin,
        double bMax,
        double tolerancia)
    {
        if (aMax < bMin - tolerancia)
            return false;

        if (bMax < aMin - tolerancia)
            return false;

        double solape = Math.Min(aMax, bMax) - Math.Max(aMin, bMin);

        if (solape >= -tolerancia)
            return true;

        return false;
    }

    // =========================================================
    // NIVELES
    // =========================================================

    private Level ObtenerNivelBase(Document doc, double zBase)
    {
        if (doc == null)
            return null;

        List<Level> niveles = new List<Level>();

        FilteredElementCollector collector = new FilteredElementCollector(doc);
        collector.OfClass(typeof(Level));

        foreach (Element elemento in collector)
        {
            Level nivel = elemento as Level;

            if (nivel == null)
                continue;

            niveles.Add(nivel);
        }

        if (niveles.Count == 0)
            return null;

        niveles.Sort(delegate (Level a, Level b)
        {
            return a.Elevation.CompareTo(b.Elevation);
        });

        Level nivelInferior = null;

        foreach (Level nivel in niveles)
        {
            if (nivel == null)
                continue;

            if (nivel.Elevation <= zBase + MetrosAPies(0.005))
                nivelInferior = nivel;
        }

        if (nivelInferior != null)
            return nivelInferior;

        Level nivelMasCercano = null;
        double menorDistancia = double.MaxValue;

        foreach (Level nivel in niveles)
        {
            double distancia = Math.Abs(nivel.Elevation - zBase);

            if (distancia < menorDistancia)
            {
                menorDistancia = distancia;
                nivelMasCercano = nivel;
            }
        }

        return nivelMasCercano;
    }

    // =========================================================
    // FILTRO DE SELECCIÓN
    // =========================================================

    private class FiltroSeleccionEstructuraVinculadaMYG : ISelectionFilter
    {
        private Document _docHost;

        public FiltroSeleccionEstructuraVinculadaMYG(Document docHost)
        {
            _docHost = docHost;
        }

        public bool AllowElement(Element elem)
        {
            if (elem == null)
                return false;

            return elem is RevitLinkInstance;
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            if (_docHost == null || reference == null)
                return false;

            RevitLinkInstance link = _docHost.GetElement(reference.ElementId) as RevitLinkInstance;

            if (link == null)
                return false;

            Document docLink = null;

            try
            {
                docLink = link.GetLinkDocument();
            }
            catch
            {
                docLink = null;
            }

            if (docLink == null)
                return false;

            ElementId linkedId = reference.LinkedElementId;

            if (linkedId == null || linkedId == ElementId.InvalidElementId)
                return false;

            Element elementoLink = docLink.GetElement(linkedId);

            if (elementoLink == null || elementoLink.Category == null)
                return false;

            long catId = elementoLink.Category.Id.Value;

            if (catId == (long)BuiltInCategory.OST_StructuralFraming)
                return true;

            if (catId == (long)BuiltInCategory.OST_StructuralColumns)
                return true;

            return false;
        }
    }

    // =========================================================
    // UTILIDADES
    // =========================================================

    private bool EsCategoriaEstructuralPermitida(Element elemento)
    {
        if (elemento == null || elemento.Category == null)
            return false;

        long catId = elemento.Category.Id.Value;

        if (catId == (long)BuiltInCategory.OST_StructuralFraming)
            return true;

        if (catId == (long)BuiltInCategory.OST_StructuralColumns)
            return true;

        return false;
    }

    private bool EsColumnaEstructural(Element elemento)
    {
        if (elemento == null || elemento.Category == null)
            return false;

        return elemento.Category.Id.Value == (long)BuiltInCategory.OST_StructuralColumns;
    }

    private bool EsVigaEstructural(Element elemento)
    {
        if (elemento == null || elemento.Category == null)
            return false;

        return elemento.Category.Id.Value == (long)BuiltInCategory.OST_StructuralFraming;
    }

    private string ObtenerCategoriaElemento(Element elemento)
    {
        if (elemento == null || elemento.Category == null)
            return "Elemento";

        try
        {
            return elemento.Category.Name;
        }
        catch
        {
            return "Elemento";
        }
    }

    private string ObtenerNombreElemento(Element elemento)
    {
        if (elemento == null)
            return "Elemento";

        string nombre = "";

        try
        {
            nombre = elemento.Name;
        }
        catch
        {
            nombre = "";
        }

        if (!string.IsNullOrWhiteSpace(nombre))
            return nombre;

        try
        {
            return "ID " + elemento.Id.Value.ToString();
        }
        catch
        {
            return "Elemento";
        }
    }

    private double ObtenerAnchoMuro(WallType wallType)
    {
        if (wallType == null)
            return MetrosAPies(0.13);

        try
        {
            double ancho = wallType.Width;

            if (ancho > MetrosAPies(0.01))
                return ancho;
        }
        catch
        {
        }

        return MetrosAPies(0.13);
    }

    private Transform ObtenerTransformVinculo(RevitLinkInstance link)
    {
        if (link == null)
            return Transform.Identity;

        try
        {
            Transform t = link.GetTotalTransform();

            if (t != null)
                return t;
        }
        catch
        {
        }

        try
        {
            Transform t = link.GetTransform();

            if (t != null)
                return t;
        }
        catch
        {
        }

        return Transform.Identity;
    }

    private XYZ NormalizarXY(XYZ v)
    {
        if (v == null)
            return null;

        double x = v.X;
        double y = v.Y;

        double longitud = Math.Sqrt(x * x + y * y);

        if (longitud < 0.0000001)
            return null;

        return new XYZ(x / longitud, y / longitud, 0.0);
    }

    private double DotXY(XYZ a, XYZ b)
    {
        if (a == null || b == null)
            return 0.0;

        return a.X * b.X + a.Y * b.Y;
    }

    private double DistanciaXY(XYZ a, XYZ b)
    {
        if (a == null || b == null)
            return 0.0;

        double dx = b.X - a.X;
        double dy = b.Y - a.Y;

        return Math.Sqrt(dx * dx + dy * dy);
    }

    private XYZ CrearPuntoDesdeUV(
        double u,
        double v,
        double z,
        XYZ ejeU,
        XYZ ejeV)
    {
        if (ejeU == null || ejeV == null)
            return null;

        return new XYZ(
            ejeU.X * u + ejeV.X * v,
            ejeU.Y * u + ejeV.Y * v,
            z);
    }


    private bool ExistePanoSolapadoYaCreado(
        PanoMuroMYG pano,
        List<PanoMuroMYG> panosAceptados,
        double anchoMuro)
    {
        if (pano == null || panosAceptados == null || panosAceptados.Count == 0)
            return false;

        XYZ p0 = CrearPuntoDesdeUV(pano.UInicio, pano.VCentro, pano.ZBase, pano.EjeU, pano.EjeV);
        XYZ p1 = CrearPuntoDesdeUV(pano.UFin, pano.VCentro, pano.ZBase, pano.EjeU, pano.EjeV);

        if (p0 == null || p1 == null)
            return false;

        XYZ dir = NormalizarXY(new XYZ(p1.X - p0.X, p1.Y - p0.Y, 0.0));

        if (dir == null)
            return false;

        double longitud = DistanciaXY(p0, p1);

        if (longitud <= MetrosAPies(0.02))
            return false;

        XYZ centro = new XYZ((p0.X + p1.X) / 2.0, (p0.Y + p1.Y) / 2.0, 0.0);
        double toleranciaPlano = Math.Max(MetrosAPies(0.10), anchoMuro * 1.50);

        foreach (PanoMuroMYG existente in panosAceptados)
        {
            if (existente == null)
                continue;

            double zSolape = Math.Min(pano.ZTop, existente.ZTop) - Math.Max(pano.ZBase, existente.ZBase);
            double alturaMinima = Math.Min(pano.Altura, existente.Altura);

            if (alturaMinima <= MetrosAPies(0.02))
                continue;

            // Si están en bandas verticales distintas, no son duplicados.
            if (zSolape < alturaMinima * 0.45)
                continue;

            XYZ e0 = CrearPuntoDesdeUV(existente.UInicio, existente.VCentro, existente.ZBase, existente.EjeU, existente.EjeV);
            XYZ e1 = CrearPuntoDesdeUV(existente.UFin, existente.VCentro, existente.ZBase, existente.EjeU, existente.EjeV);

            if (e0 == null || e1 == null)
                continue;

            XYZ dirExistente = NormalizarXY(new XYZ(e1.X - e0.X, e1.Y - e0.Y, 0.0));

            if (dirExistente == null)
                continue;

            double longitudExistente = DistanciaXY(e0, e1);

            if (longitudExistente <= MetrosAPies(0.02))
                continue;

            // Permite detectar duplicados aunque una segunda dirección esté levemente inclinada.
            double paralelismo = Math.Abs(DotXY(dir, dirExistente));

            if (paralelismo < 0.93)
                continue;

            XYZ centroExistente = new XYZ((e0.X + e1.X) / 2.0, (e0.Y + e1.Y) / 2.0, 0.0);

            double distanciaCentroALineaExistente = DistanciaPuntoALineaXY(centro, e0, e1);
            double distanciaCentroExistenteALinea = DistanciaPuntoALineaXY(centroExistente, p0, p1);

            if (distanciaCentroALineaExistente > toleranciaPlano &&
                distanciaCentroExistenteALinea > toleranciaPlano)
                continue;

            double a0 = 0.0;
            double a1 = longitud;
            double b0 = ProyectarSobreEjeXY(e0, p0, dir);
            double b1 = ProyectarSobreEjeXY(e1, p0, dir);

            if (b1 < b0)
            {
                double temp = b0;
                b0 = b1;
                b1 = temp;
            }

            double solapeHorizontal = Math.Min(a1, b1) - Math.Max(a0, b0);
            double longitudMenor = Math.Min(longitud, longitudExistente);

            if (longitudMenor <= MetrosAPies(0.02))
                continue;

            if (solapeHorizontal >= longitudMenor * 0.45)
                return true;
        }

        return false;
    }

    private double DistanciaPuntoALineaXY(XYZ punto, XYZ linea0, XYZ linea1)
    {
        if (punto == null || linea0 == null || linea1 == null)
            return double.MaxValue;

        XYZ dir = NormalizarXY(new XYZ(linea1.X - linea0.X, linea1.Y - linea0.Y, 0.0));

        if (dir == null)
            return double.MaxValue;

        double vx = punto.X - linea0.X;
        double vy = punto.Y - linea0.Y;

        // Producto cruzado 2D = distancia perpendicular si dir está normalizado.
        return Math.Abs(vx * dir.Y - vy * dir.X);
    }

    private double ProyectarSobreEjeXY(XYZ punto, XYZ origen, XYZ eje)
    {
        if (punto == null || origen == null || eje == null)
            return 0.0;

        return (punto.X - origen.X) * eje.X + (punto.Y - origen.Y) * eje.Y;
    }

    private string ObtenerClavePano(PanoMuroMYG pano)
    {
        if (pano == null)
            return "";

        double tol = MetrosAPies(0.002);

        XYZ p0 = CrearPuntoDesdeUV(pano.UInicio, pano.VCentro, pano.ZBase, pano.EjeU, pano.EjeV);
        XYZ p1 = CrearPuntoDesdeUV(pano.UFin, pano.VCentro, pano.ZBase, pano.EjeU, pano.EjeV);

        string k0 = ObtenerClavePunto3D(p0, tol);
        string k1 = ObtenerClavePunto3D(p1, tol);

        string a = k0;
        string b = k1;

        if (string.Compare(a, b, StringComparison.Ordinal) > 0)
        {
            string temp = a;
            a = b;
            b = temp;
        }

        double zt = Math.Round(pano.ZTop / tol) * tol;

        return a + "|" + b + "|ZT=" +
               zt.ToString("0.0000", System.Globalization.CultureInfo.InvariantCulture);
    }

    private string ObtenerClavePunto3D(XYZ p, double tol)
    {
        if (p == null)
            return "0.0000,0.0000,0.0000";

        double x = Math.Round(p.X / tol) * tol;
        double y = Math.Round(p.Y / tol) * tol;
        double z = Math.Round(p.Z / tol) * tol;

        return x.ToString("0.0000", System.Globalization.CultureInfo.InvariantCulture) + "," +
               y.ToString("0.0000", System.Globalization.CultureInfo.InvariantCulture) + "," +
               z.ToString("0.0000", System.Globalization.CultureInfo.InvariantCulture);
    }

    private double MetrosAPies(double metros)
    {
        return metros / 0.3048;
    }

    private void MostrarEnVentana(string texto)
    {
        try
        {
            if (Form != null && !Form.IsDisposed)
                Form.MostrarResultado(texto);
        }
        catch
        {
        }
    }

    // =========================================================
    // CLASES AUXILIARES
    // =========================================================

    private class ElementoMarcoMYG
    {
        public ElementId LinkInstanceId { get; set; }
        public ElementId LinkedElementId { get; set; }
        public string Nombre { get; set; }
        public string Categoria { get; set; }

        public Element ElementoLink { get; set; }
        public Transform TransformLink { get; set; }
        public List<XYZ> PuntosHost { get; set; }
        public XYZ Centro { get; set; }

        public bool EsColumna { get; set; }
        public bool EsViga { get; set; }

        public double ZMin { get; set; }
        public double ZMax { get; set; }
        public double LongitudEje { get; set; }
        public double DeltaZEje { get; set; }
        public bool EsVigaConfinamiento { get; set; }

        public double UMin { get; set; }
        public double UMax { get; set; }
        public double UCentro { get; set; }

        public double VMin { get; set; }
        public double VMax { get; set; }
        public double VCentro { get; set; }

        public void ActualizarUV(XYZ ejeU, XYZ ejeV)
        {
            UMin = double.MaxValue;
            UMax = double.MinValue;
            VMin = double.MaxValue;
            VMax = double.MinValue;

            if (PuntosHost == null)
                return;

            foreach (XYZ p in PuntosHost)
            {
                if (p == null)
                    continue;

                double u = p.X * ejeU.X + p.Y * ejeU.Y;
                double v = p.X * ejeV.X + p.Y * ejeV.Y;

                if (u < UMin) UMin = u;
                if (u > UMax) UMax = u;
                if (v < VMin) VMin = v;
                if (v > VMax) VMax = v;
            }

            UCentro = (UMin + UMax) / 2.0;
            VCentro = (VMin + VMax) / 2.0;
        }
    }

    private class GrupoMarcoMYG
    {
        public XYZ EjeU { get; set; }
        public XYZ EjeV { get; set; }
        public double VCentro { get; set; }
        public List<ElementoMarcoMYG> Elementos { get; set; }
    }

    private class SobrecimientoMYG
    {
        public List<XYZ> PuntosHost { get; set; }
        public double ZMin { get; set; }
        public double ZMax { get; set; }
        public ElementId ElementId { get; set; }
        public ElementId LinkInstanceId { get; set; }
        public bool EsVinculado { get; set; }
        public string Nombre { get; set; }
        public string Categoria { get; set; }
    }

    private class IntervaloSobrecimientoMYG
    {
        public double UInicio { get; set; }
        public double UFin { get; set; }
        public double ZTop { get; set; }
    }

    private class IntervaloZMYG
    {
        public double Min { get; set; }
        public double Max { get; set; }
    }

    private class PanoMuroMYG
    {
        public XYZ EjeU { get; set; }
        public XYZ EjeV { get; set; }
        public double UInicio { get; set; }
        public double UFin { get; set; }
        public double VCentro { get; set; }
        public double ZBase { get; set; }
        public double ZTop { get; set; }
        public double Altura { get; set; }
    }

    private class EliminarAdvertenciasMurosContornoMYG : IFailuresPreprocessor
    {
        public FailureProcessingResult PreprocessFailures(FailuresAccessor failuresAccessor)
        {
            if (failuresAccessor == null)
                return FailureProcessingResult.Continue;

            IList<FailureMessageAccessor> mensajes = null;

            try
            {
                mensajes = failuresAccessor.GetFailureMessages();
            }
            catch
            {
                mensajes = null;
            }

            if (mensajes == null || mensajes.Count == 0)
                return FailureProcessingResult.Continue;

            foreach (FailureMessageAccessor mensaje in mensajes)
            {
                if (mensaje == null)
                    continue;

                try
                {
                    if (mensaje.GetSeverity() == FailureSeverity.Warning)
                        failuresAccessor.DeleteWarning(mensaje);
                }
                catch
                {
                }
            }

            return FailureProcessingResult.Continue;
        }
    }
}
