﻿// MYG NAVIS -> REVIT 2027 | SELECCION NATIVO + ELEMENTO RVT VINCULADO
// No exige alterar csproj, comando, ventana ni paquetes NuGet.
// Lector JSON incluido en este archivo, sin ensamblados JSON externos.
// El importador usa el documento ACTIVO real y no ReferenceEquals de wrappers Revit.
// Archivo INDEPENDIENTE del antiguo MYG_InterferenciasHandler.
// Con using y namespace, como se solicitó.
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Forms = System.Windows.Forms;

namespace MYG_Addin
{
    public enum MYG_NavisworksRequest
    {
        None, Importar, Aislar, Seleccionar, Restaurar, ActualizarVinculos, GestionarVinculos,
        VincularRvt, AbrirSelectorRvt, VerificarUno, VerificarTodos, MarcarCorregido, Justificar, ReiniciarSeguimiento
    }

    public sealed class MYG_NavisIssue
    {
        public int Numero { get; set; }
        public string TestName { get; set; } = "";
        public string ClashName { get; set; } = "";
        public string ClashId { get; set; } = "";
        public string TargetModel { get; set; } = "";
        public string NativeName { get; set; } = "";
        public string NativeUniqueId { get; set; } = "";
        public string NativeIdRaw { get; set; } = "";
        public long NativeId { get; set; }
        public string NativeIdText { get { return NativeId > 0 ? NativeId.ToString() : NativeIdRaw; } }
        public string LinkModel { get; set; } = "";
        public string CounterpartName { get; set; } = "";
        public string CounterpartUniqueId { get; set; } = "";
        public string CounterpartIdRaw { get; set; } = "";
        public long CounterpartId { get; set; }
        public string CounterpartIdText { get { return CounterpartId > 0 ? CounterpartId.ToString() : CounterpartIdRaw; } }
        public long LinkInstanceId { get; set; }
        public bool CounterpartIsHost { get; set; }
        public string Instruction { get; set; } = "";
        public string Resultado { get; set; } = "";
        // Seguimiento independiente del resultado de localización Navis/Revit.
        public string SourceJsonPath { get; set; } = "";
        public string SeguimientoKey
        {
            get
            {
                return (ClashId ?? "").Trim().Length > 0
                    ? "ID|" + ClashId.Trim()
                    : "NOMBRE|" + (TestName ?? "") + "|" + (ClashName ?? "") +
                      "|" + (NativeIdRaw ?? "") + "|" + (CounterpartIdRaw ?? "");
            }
        }
        public bool NativeIdCandidato { get; set; }
        public bool CounterpartIdCandidato { get; set; }
        public string EstadoMYG { get; set; } = "SIN VERIFICAR";
        public string VerificadoEn { get; set; } = "";
        public string VolumenComun { get; set; } = "";
        public string ObservacionMYG { get; set; } = "";
    }

    // Estado de cada RVT involucrado, obtenido comparando JSON con RVT anfitrión y vínculos.
    public sealed class MYG_NavisRvtStatus
    {
        public string Modelo { get; set; } = "";
        public string Clave { get; set; } = "";
        public string Papel { get; set; } = "";
        public int Conflictos { get; set; }
        public string Estado { get; set; } = "";
        public int Instancias { get; set; }
        public string Accion { get; set; } = "";
    }

    public sealed class MYG_NavisworksImportHandler : IExternalEventHandler
    {
        public UIDocument UiDoc { get; set; }
        public MYG_NavisworksImportForm Form { get; set; }
        public MYG_NavisworksRequest Request { get; set; }

        private Document originalDocument;
        private long previous3DViewId = -1;
        private bool hadSectionBox;
        private BoundingBoxXYZ previousSectionBox;
        private bool changedView;

        public string GetName() { return "MYG - Importar conflictos de Navisworks JSON"; }

        // Revit puede proporcionar distintos wrappers administrados para el MISMO RVT.
        // ReferenceEquals() comprueba la instancia C# y no la identidad del documento.
        // Para archivos locales usamos la ruta; para documentos ACC sin ruta fisica,
        // usamos el titulo como alternativa (y el JSON se valida por modelo al importar).
        private static bool EsMismoDocumento(Document primero, Document segundo)
        {
            if (primero == null || segundo == null) return false;
            try
            {
                if (!primero.IsValidObject || !segundo.IsValidObject) return false;
                if (Object.ReferenceEquals(primero, segundo) || primero.Equals(segundo))
                    return true;

                string rutaA = (primero.PathName ?? "").Trim();
                string rutaB = (segundo.PathName ?? "").Trim();
                if (rutaA.Length > 0 && rutaB.Length > 0)
                    return string.Equals(rutaA, rutaB,
                        StringComparison.OrdinalIgnoreCase);

                return string.Equals((primero.Title ?? "").Trim(),
                    (segundo.Title ?? "").Trim(),
                    StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }

        public void Execute(UIApplication app)
        {
            MYG_NavisworksRequest req = Request;
            Request = MYG_NavisworksRequest.None;
            try
            {
                if (Form == null || Form.IsDisposed) return;
                UIDocument activo = app.ActiveUIDocument;
                if (activo == null || activo.Document == null)
                    throw new InvalidOperationException(
                        "Activa el documento RVT responsable antes de continuar.");

                if (req == MYG_NavisworksRequest.Importar)
                {
                    // IMPORTAR siempre utiliza el RVT ACTIVO ahora, no un wrapper
                    // retenido desde que se abrio la ventana modeless.
                    // El nombre del modelo se valida contra cada JSON en Importar().
                    if (UiDoc == null || UiDoc.Document == null ||
                        !EsMismoDocumento(activo.Document, UiDoc.Document))
                    {
                        previous3DViewId = -1;
                        previousSectionBox = null;
                        originalDocument = null;
                        changedView = false;
                    }
                    UiDoc = activo;
                }
                else
                {
                    // Para aislar/seleccionar no se deben reutilizar ID de OTRO RVT.
                    // Solo se rechaza un documento REALMENTE distinto; ya no se
                    // comparan referencias C# mediante ReferenceEquals().
                    if (UiDoc == null || UiDoc.Document == null ||
                        !EsMismoDocumento(activo.Document, UiDoc.Document))
                        throw new InvalidOperationException(
                            "El RVT activo es diferente del usado para importar. " +
                            "Vuelve a pulsar IMPORTAR JSON desde el documento responsable. " +
                            "RVT activo: " + activo.Document.Title +
                            " | RVT anterior: " +
                            (UiDoc == null || UiDoc.Document == null
                                ? "(ninguno)" : UiDoc.Document.Title));
                    UiDoc = activo;
                }

                switch (req)
                {
                    case MYG_NavisworksRequest.Importar: Importar(); break;
                    case MYG_NavisworksRequest.Aislar: Mostrar(true); break;
                    case MYG_NavisworksRequest.Seleccionar: Mostrar(false); break;
                    case MYG_NavisworksRequest.Restaurar: Restaurar(); break;
                    case MYG_NavisworksRequest.VerificarUno: VerificarUno(); break;
                    case MYG_NavisworksRequest.VerificarTodos: VerificarTodos(); break;
                    case MYG_NavisworksRequest.MarcarCorregido:
                        CambiarEstadoManual("CORREGIDO SIN VERIFICAR", "Declarado por el modelador; geometría aún no evaluada."); break;
                    case MYG_NavisworksRequest.Justificar:
                        CambiarEstadoManual("JUSTIFICADO", "Interferencia aceptada manualmente por coordinación; no significa ausencia de intersección."); break;
                    case MYG_NavisworksRequest.ReiniciarSeguimiento:
                        CambiarEstadoManual("SIN VERIFICAR", ""); break;
                    case MYG_NavisworksRequest.ActualizarVinculos: Importar(); break;
                    case MYG_NavisworksRequest.VincularRvt: VincularRvt(); break;
                    case MYG_NavisworksRequest.AbrirSelectorRvt:
                        {
                            RevitCommandId id = RevitCommandId.LookupPostableCommandId(
                                PostableCommand.LinkRevit);
                            if (id == null || !app.CanPostCommand(id))
                                throw new InvalidOperationException(
                                    "No se puede abrir Vincular Revit ahora. " +
                                    "Usa Insertar > Vincular Revit y selecciona Autodesk Docs.");
                            Form.PrepararSelectorRvtNativo();
                            app.PostCommand(id);
                            break;
                        }
                    case MYG_NavisworksRequest.GestionarVinculos:
                        var commandId = RevitCommandId.LookupPostableCommandId(
                            PostableCommand.ManageLinks);
                        if (!app.CanPostCommand(commandId))
                            throw new InvalidOperationException(
                                "Gestionar vínculos no está disponible ahora. Abre Gestionar > Gestionar vínculos manualmente.");
                        app.PostCommand(commandId);
                        Form.SetEstado("Abriendo Gestionar vínculos. Al terminar, pulsa ACTUALIZAR ESTADO en CONTROL RVT.");
                        break;
                }
            }
            catch (Exception ex)
            {
                if (Form != null && !Form.IsDisposed)
                    Form.SetEstado("ERROR: " + ex.Message);
                Forms.MessageBox.Show(ex.ToString(), "MYG NAVIS - Error",
                    Forms.MessageBoxButtons.OK, Forms.MessageBoxIcon.Error);
            }
            finally
            {
                if (Form != null && !Form.IsDisposed) Form.EventoFinalizado();
            }
        }

        // Los JSON de MYG NAVIS se leen usando MYG_NavisJsonReader.
        // Evita cargar System.Text.Json 8.x desde el AssemblyLoadContext temporal
        // del Add-In Manager: el contexto puede estar descargandose.
        private static string V(object obj, string key)
        {
            object p = O(obj, key);
            if (p == null) return "";
            if (p is bool) return (bool)p ? "true" : "false";
            return p as string ?? Convert.ToString(p,
                System.Globalization.CultureInfo.InvariantCulture) ?? "";
        }

        private static bool B(object obj, string key)
        {
            object p = O(obj, key);
            return p is bool ? (bool)p :
                string.Equals(V(obj, key), "true", StringComparison.OrdinalIgnoreCase);
        }

        private static object O(object obj, string key)
        {
            Dictionary<string, object> map = obj as Dictionary<string, object>;
            object p;
            return map != null && map.TryGetValue(key, out p) ? p : null;
        }

        // NO usar Path.GetFileName sobre nombres de nodos Navisworks: a veces
        // contienen caracteres especiales y no son rutas fisicas de Windows.
        // Los nombres visibles de Navisworks suelen incluir etiquetas de exportacion:
        // "modelo.rvt - NAVIWORKS" (sin S) o "modelo.rvt - NAVISWORKS".
        // El titulo de Revit puede no mostrar ".rvt". Comparamos solamente
        // nombres normalizados completos: NUNCA por "Contains" ni prefijos.
        private static string ModelKey(string name)
        {
            string s = (name ?? "").Trim().Replace('\\', '/');
            int slash = s.LastIndexOf('/');
            if (slash >= 0) s = s.Substring(slash + 1);
            int delim = s.IndexOf(" : ", StringComparison.Ordinal);
            if (delim >= 0) s = s.Substring(0, delim);

            // Se eliminan las etiquetas DESPUES de la extension RVT/NWC,
            // antes de eliminar la extension propiamente dicha.
            string[] etiquetas = {
                " - NAVIWORKS",   // grafia presente en el JSON real de MYG
                " - NAVISWORKS",  // grafia convencional de Autodesk
                " - 3D NAVIS"
            };
            bool cambio;
            do
            {
                cambio = false;
                s = s.Trim();
                foreach (string etiqueta in etiquetas)
                {
                    if (s.EndsWith(etiqueta, StringComparison.OrdinalIgnoreCase))
                    {
                        s = s.Substring(0, s.Length - etiqueta.Length).TrimEnd();
                        cambio = true;
                        break;
                    }
                }
            } while (cambio);

            foreach (string ext in new[] { ".rvt", ".nwc", ".nwd", ".nwf" })
            {
                if (s.EndsWith(ext, StringComparison.OrdinalIgnoreCase))
                {
                    s = s.Substring(0, s.Length - ext.Length);
                    break;
                }
            }
            return s.Trim().ToUpperInvariant();
        }

        private static long ReadId(string s)
        {
            long n;
            return long.TryParse((s ?? "").Trim(), out n) && n > 0 ? n : 0;
        }

        private static Element ResolverElemento(Document doc, string id, string uid,
            bool candidato, bool permitir, out string razon)
        {
            razon = "";
            if (doc == null) { razon = "MODELO NO CARGADO"; return null; }
            if (!string.IsNullOrWhiteSpace(uid))
            {
                try
                {
                    Element porUid = doc.GetElement(uid.Trim());
                    if (porUid != null && !(porUid is ElementType))
                        return porUid;
                }
                catch { }
                razon = "UNIQUE ID NO EXISTE EN ESTE MODELO (NO SE USARA ID NUMERICO)";
                return null;
            }
            // Los ID candidatos se evalúan siempre; el resultado debe ser verificado
            // contra el modelo y el tipo porque pueden proceder de un nombre visible.
            long numero = ReadId(id);
            if (numero == 0) { razon = "NO HAY IDENTIFICADOR REVIT VALIDO"; return null; }
            try
            {
                Element e = doc.GetElement(new ElementId(numero));
                if (e != null && !(e is ElementType)) return e;
            }
            catch { }
            razon = candidato ? "ID CANDIDATO NO ENCONTRADO EN RVT" : "ELEMENT ID NO ENCONTRADO EN RVT";
            return null;
        }

        private static List<RevitLinkInstance> Vinculos(Document host, string modelName)
        {
            var result = new List<RevitLinkInstance>();
            string needle = ModelKey(modelName);
            if (needle.Length == 0) return result;
            foreach (RevitLinkInstance link in new FilteredElementCollector(host)
                .OfClass(typeof(RevitLinkInstance)).Cast<RevitLinkInstance>())
            {
                Document linked = null;
                try { linked = link.GetLinkDocument(); } catch { }
                if (linked == null) continue;
                if (ModelKey(linked.Title) == needle || ModelKey(link.Name) == needle)
                    result.Add(link);
            }
            return result;
        }


        // Todas las especialidades detectadas se conservan aunque el JSON por
        // modelo responsable corresponda a otro RVT y sus conflictos se omitan.
        private static void RegistrarModelo(
            Dictionary<string, MYG_NavisRvtStatus> inventario,
            string nombre, string papel, int apariciones)
        {
            string key = ModelKey(nombre);
            if (key.Length == 0) return;
            MYG_NavisRvtStatus m;
            if (!inventario.TryGetValue(key, out m))
            {
                m = new MYG_NavisRvtStatus();
                m.Clave = key;
                // El JSON puede nombrar NWC / RVT / sufijos Navisworks:
                // el nombre normalizado es una REFERENCIA para localizar el RVT;
                // no constituye una ruta real ni garantiza nombre exacto de archivo.
                m.Modelo = key + ".rvt";
                m.Papel = papel;
                inventario.Add(key, m);
            }
            else if (m.Papel != papel && !m.Papel.Contains(papel))
                m.Papel += " / " + papel;
            m.Conflictos += apariciones;
        }

        private static List<MYG_NavisRvtStatus> EstadoModelos(
            Document host, Dictionary<string, MYG_NavisRvtStatus> inventario)
        {
            var instances = new FilteredElementCollector(host)
                .OfClass(typeof(RevitLinkInstance)).Cast<RevitLinkInstance>().ToList();
            var types = new FilteredElementCollector(host)
                .OfClass(typeof(RevitLinkType)).Cast<RevitLinkType>().ToList();
            foreach (MYG_NavisRvtStatus m in inventario.Values)
            {
                if (m.Clave == ModelKey(host.Title))
                {
                    m.Estado = "RVT ACTIVO";
                    m.Instancias = 0;
                    m.Accion = "Nada que cargar";
                    continue;
                }
                var matches = new List<RevitLinkInstance>();
                foreach (var li in instances)
                {
                    Document linked = null;
                    try { linked = li.GetLinkDocument(); } catch { }
                    if (linked == null) continue;
                    bool coincide = ModelKey(linked.Title) == m.Clave;
                    if (!coincide)
                    {
                        try { coincide = ModelKey(li.Name) == m.Clave; } catch { }
                    }
                    if (coincide) matches.Add(li);
                }
                m.Instancias = matches.Count;
                if (matches.Count > 0)
                {
                    m.Estado = matches.Count > 1 ? "VARIAS INSTANCIAS" : "CARGADO";
                    m.Accion = matches.Count > 1
                        ? "Comprobar instancia" : "Listo para revisar";
                    continue;
                }
                bool tipoEncontrado = false;
                foreach (var t in types)
                {
                    string titulo = "";
                    try { titulo = t.Name; } catch { }
                    if (ModelKey(titulo) == m.Clave)
                    {
                        tipoEncontrado = true;
                        break;
                    }
                }
                m.Estado = tipoEncontrado ? "NO CARGADO / SIN INSTANCIA" : "NO VINCULADO";
                m.Accion = tipoEncontrado ? "Cargar / revisar" : "Vincular RVT";
            }
            return inventario.Values.OrderBy(m => m.Estado == "RVT ACTIVO" ? 0 :
                m.Estado == "CARGADO" ? 1 : 2).ThenBy(m => m.Modelo).ToList();
        }

        // ============================================
        // VINCULAR / RECARGAR UN SOLO RVT SELECCIONADO
        // Ejecutado solamente desde ExternalEvent (contexto API de Revit).
        // ============================================
        private void VincularRvt()
        {
            Document host = UiDoc.Document;
            if (host == null || host.IsFamilyDocument || host.IsReadOnly)
                throw new InvalidOperationException(
                    "Abre el proyecto RVT en modo editable antes de cargar vínculos.");
            string solicitado = Form.ModeloParaVincular;
            string esperado = ModelKey(solicitado);
            string ruta = Form.RutaRvtParaVincular;
            if (esperado.Length == 0 || esperado == ModelKey(host.Title))
                throw new InvalidOperationException("Selecciona un RVT contraparte, distinto al anfitrión.");

            var tipos = new FilteredElementCollector(host)
                .OfClass(typeof(RevitLinkType)).Cast<RevitLinkType>()
                .Where(t => ModelKey(t.Name) == esperado).ToList();
            if (tipos.Count > 1)
                throw new InvalidOperationException(
                    "Existen varios tipos RVT con el nombre solicitado. Abre Gestionar vínculos " +
                    "para distinguirlos antes de añadir nada.");
            RevitLinkType tipo = tipos.Count == 1 ? tipos[0] : null;
            ImportPlacement colocacion = Form.UsarCoordenadasCompartidas
                ? ImportPlacement.Shared : ImportPlacement.Origin;
            bool vinculoCreado = false;
            bool recargado = false;
            bool instanciaCreada = false;

            if (tipo == null)
            {
                // Los nombres de archivo del JSON NO permiten deducir GUID de ACC.
                // Para NUBE: los GUID se proporcionan y confirman explícitamente.
                // Para LOCAL: se comprueba que el archivo coincide exactamente.
                ModelPath origen;
                if (Form.VincularDesdeNube)
                {
                    if (!host.IsModelInCloud)
                        throw new InvalidOperationException(
                            "Revit no permite vincular un modelo cloud a un anfitrión " +
                            "local con esta operación. Abre el anfitrión desde Autodesk Docs.");
                    Guid projectGuid;
                    Guid modelGuid;
                    if (!Guid.TryParse(Form.ProyectoGuidNube, out projectGuid) ||
                        !Guid.TryParse(Form.ModeloGuidNube, out modelGuid) ||
                        projectGuid == Guid.Empty || modelGuid == Guid.Empty ||
                        string.IsNullOrWhiteSpace(Form.RegionNube))
                        throw new InvalidOperationException(
                            "Región, Project GUID o Model GUID inválidos.");
                    // Revit 2027: obtener ambos GUID desde ModelPath del RVT cloud.
                    // Document.CloudModelGUID no está disponible en la referencia
                    // RevitAPI.dll utilizada por este proyecto.
                    ModelPath modeloActivoCloud = host.GetCloudModelPath();
                    if (modeloActivoCloud.GetModelGUID() == modelGuid &&
                        modeloActivoCloud.GetProjectGUID() == projectGuid)
                        throw new InvalidOperationException(
                            "El Project GUID y Model GUID corresponden al propio RVT activo.");
                    origen = ModelPathUtils.ConvertCloudGUIDsToCloudPath(
                        Form.RegionNube, projectGuid, modelGuid);
                }
                else
                {
                    if (string.IsNullOrWhiteSpace(ruta) || !File.Exists(ruta) ||
                        ModelKey(Path.GetFileName(ruta)) != esperado)
                        throw new InvalidOperationException(
                            "Selecciona el RVT local correspondiente al JSON. " +
                            "Para Autodesk Docs elige el modo nube.");
                    origen = new FilePath(ruta);
                }
                using (Transaction tr = new Transaction(host, "MYG NAVIS - Vincular RVT seleccionado"))
                {
                    tr.Start();
                    LinkLoadResult resultado = RevitLinkType.Create(host,
                        origen, new RevitLinkOptions(false));
                    if (resultado.LoadResult != LinkLoadResultType.LinkLoaded)
                    {
                        tr.RollBack();
                        throw new InvalidOperationException(
                            "Revit no pudo cargar el RVT: " + resultado.LoadResult);
                    }
                    tipo = host.GetElement(resultado.ElementId) as RevitLinkType;
                    if (tipo == null)
                    {
                        tr.RollBack(); throw new InvalidOperationException(
                        "Revit no devolvió el tipo de vínculo creado.");
                    }
                    // Verificación adicional cuando Revit expone el nombre del vínculo.
                    // Si no lo expone hasta el commit, la confirmación de GUID del usuario
                    // sigue siendo indispensable para evitar enlazar la especialidad errónea.
                    string nombreCargado = "";
                    try { nombreCargado = ModelKey(tipo.Name); } catch { }
                    if (nombreCargado.Length > 0 && nombreCargado != esperado)
                    {
                        tr.RollBack();
                        throw new InvalidOperationException(
                            "El modelo cargado no coincide con el esperado. " +
                            "Esperado: " + solicitado + " | Revit: " + tipo.Name);
                    }
                    RevitLinkInstance.Create(host, tipo.Id, colocacion);
                    tr.Commit();
                    vinculoCreado = true;
                    instanciaCreada = true;
                }
            }
            else
            {
                // Evitar duplicados incluso cuando GetLinkDocument() es null por estar descargado.
                Func<List<RevitLinkInstance>> obtenerInstancias = () =>
                    new FilteredElementCollector(host).OfClass(typeof(RevitLinkInstance))
                    .Cast<RevitLinkInstance>()
                    .Where(li => li.GetTypeId().Equals(tipo.Id)).ToList();
                if (obtenerInstancias().Count > 1)
                    throw new InvalidOperationException(
                        "Este modelo ya tiene varias instancias. No se agregará otra. " +
                        "Comprueba la colocación en Gestionar vínculos.");

                if (!RevitLinkType.IsLoaded(host, tipo.Id))
                {
                    // NO usar Transaction para Reload(): la API exige que no haya una fase abierta.
                    LinkLoadResult carga = tipo.Reload();
                    if (carga.LoadResult != LinkLoadResultType.LinkLoaded)
                        throw new InvalidOperationException(
                            "Revit no pudo recargar el vínculo: " + carga.LoadResult +
                            ". Comprueba ruta/acceso en Gestionar vínculos.");
                    recargado = true;
                }
                if (obtenerInstancias().Count == 0)
                {
                    using (Transaction tr = new Transaction(host,
                        "MYG NAVIS - Colocar instancia RVT"))
                    {
                        tr.Start();
                        RevitLinkInstance.Create(host, tipo.Id, colocacion);
                        tr.Commit();
                        instanciaCreada = true;
                    }
                }
            }

            // Leer los mismos JSON para actualizar estado de cada interferencia
            // sin que el usuario tenga que cerrar el importador.
            Importar();
            Form.SetEstado("RVT: " + solicitado + " | " +
                (vinculoCreado ? "VINCULADO" : recargado ? "RECARGADO" : "YA CARGADO") +
                (instanciaCreada ? " | instancia creada" : " | instancia existente") +
                (Form.VincularDesdeNube && vinculoCreado ? " | AUTODESK DOCS" : "") +
                " | Revisa la alineación de coordenadas en vista 3D.");
        }

        private void Importar()
        {
            Document host = UiDoc.Document;
            var files = Form.JsonPaths;
            var list = new List<MYG_NavisIssue>();
            int descartados = 0, errores = 0, cand = 0, faltaLink = 0;
            var keys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var messages = new List<string>();
            var inventario = new Dictionary<string, MYG_NavisRvtStatus>(
                StringComparer.OrdinalIgnoreCase);

            foreach (string file in files)
            {
                try
                {
                    // Archivo por modelo generado por BuildJsonIssue de MYG NAVIS.
                    {
                        object root = MYG_NavisJsonReader.Parse(File.ReadAllText(file));
                        if (V(root, "schema") != "MYG_BIM_CLASH" ||
                            V(root, "schemaVersion") != "1")
                        {
                            errores++;
                            messages.Add(Path.GetFileName(file) + ": esquema no reconocido.");
                            continue;
                        }
                        string model = V(root, "modelName");
                        RegistrarModelo(inventario, model, "Archivo JSON", 0);
                        // El inventario incluye todas las especialidades de la carpeta,
                        // incluso archivos exportados para OTRO modelo responsable.
                        var allIssues = O(root, "issues") as List<object>;
                        if (allIssues != null)
                            foreach (object j0 in allIssues)
                            {
                                string nombreResponsable = V(O(j0, "target"), "modelName");
                                string nombreContraparte = V(O(j0, "counterpart"), "modelName");
                                RegistrarModelo(inventario, nombreResponsable, "Responsable", 1);
                                // Si ambas piezas están en el mismo RVT es UN conflicto,
                                // no dos conflictos para la columna de conteo.
                                RegistrarModelo(inventario, nombreContraparte, "Contraparte",
                                    ModelKey(nombreResponsable) == ModelKey(nombreContraparte) ? 0 : 1);
                            }
                        if (ModelKey(model) != ModelKey(host.Title))
                        {
                            descartados++;
                            messages.Add(Path.GetFileName(file) +
                                ": archivo de otro modelo. JSON: " + model +
                                " | RVT activo: " + host.Title);
                            continue; // Evitar ID iguales de documentos distintos.
                        }
                        List<object> issues = O(root, "issues") as List<object>;
                        if (issues == null)
                        {
                            errores++;
                            messages.Add(Path.GetFileName(file) + ": falta lista issues.");
                            continue;
                        }
                        foreach (object j in issues)
                        {
                            object target = O(j, "target");
                            object other = O(j, "counterpart");
                            var x = new MYG_NavisIssue();
                            x.Numero = list.Count + 1;
                            x.SourceJsonPath = Path.GetFullPath(file);
                            x.TestName = V(j, "testName");
                            x.ClashName = V(j, "clashName");
                            x.ClashId = V(j, "clashId");
                            x.Instruction = V(j, "instruction");
                            x.TargetModel = V(target, "modelName");
                            x.NativeName = V(target, "elementName");
                            x.NativeIdRaw = V(target, "revitElementId");
                            x.NativeUniqueId = V(target, "revitUniqueId");
                            x.LinkModel = V(other, "modelName");
                            x.CounterpartName = V(other, "elementName");
                            x.CounterpartIdRaw = V(other, "revitElementId");
                            x.CounterpartUniqueId = V(other, "revitUniqueId");
                            string identity = x.ClashId.Length > 0
                                ? x.ClashId : x.TestName + "|" + x.ClashName;
                            if (!keys.Add(ModelKey(model) + "|" + identity)) continue;

                            if (ModelKey(x.TargetModel) != ModelKey(host.Title))
                            {
                                x.Resultado = "MODELO RESPONSABLE DISTINTO";
                                list.Add(x);
                                continue;
                            }
                            string reason;
                            bool candidate = B(target, "revitElementIdRequiresValidation") ||
                                V(target, "revitElementIdSource") == "DISPLAY_NAME_CANDIDATE";
                            x.NativeIdCandidato = candidate && string.IsNullOrWhiteSpace(x.NativeUniqueId);
                            x.CounterpartIdCandidato =
                                (B(other, "revitElementIdRequiresValidation") ||
                                 V(other, "revitElementIdSource") == "DISPLAY_NAME_CANDIDATE") &&
                                string.IsNullOrWhiteSpace(x.CounterpartUniqueId);
                            Element native = ResolverElemento(host, x.NativeIdRaw,
                                x.NativeUniqueId, candidate, Form.PermitirIdCandidato, out reason);
                            if (native == null)
                            {
                                x.Resultado = reason;
                                if (candidate) cand++;
                                list.Add(x);
                                continue;
                            }
                            x.NativeId = native.Id.Value;
                            if (candidate && string.IsNullOrWhiteSpace(x.NativeUniqueId))
                                x.Resultado = "ID CANDIDATO ENCONTRADO (VALIDAR TIPO)";
                            if (ModelKey(x.LinkModel) == ModelKey(host.Title))
                            {
                                x.CounterpartIsHost = true;
                                string reason2;
                                Element second = ResolverElemento(host, x.CounterpartIdRaw,
                                    x.CounterpartUniqueId, B(other, "revitElementIdRequiresValidation"),
                                    Form.PermitirIdCandidato, out reason2);
                                if (second != null)
                                {
                                    x.CounterpartId = second.Id.Value;
                                    x.Resultado = "DOS ELEMENTOS NATIVOS";
                                }
                                else x.Resultado = "NATIVO OK; ELEMENTO 2: " + reason2;
                            }
                            else
                            {
                                var matches = Vinculos(host, x.LinkModel);
                                if (matches.Count == 0)
                                {
                                    faltaLink++;
                                    x.Resultado = "NATIVO OK; VÍNCULO NO CARGADO/NO COINCIDE";
                                }
                                else if (matches.Count > 1)
                                {
                                    faltaLink++;
                                    x.Resultado = "NATIVO OK; MÚLTIPLES INSTANCIAS DE VÍNCULO";
                                }
                                else
                                {
                                    RevitLinkInstance link = matches[0];
                                    Document linked = link.GetLinkDocument();
                                    string reason2;
                                    Element second = ResolverElemento(linked,
                                        x.CounterpartIdRaw, x.CounterpartUniqueId,
                                        B(other, "revitElementIdRequiresValidation"),
                                        Form.PermitirIdCandidato, out reason2);
                                    if (second != null)
                                    {
                                        x.LinkInstanceId = link.Id.Value;
                                        x.CounterpartId = second.Id.Value;
                                        x.Resultado = "NATIVO + VÍNCULO LOCALIZADOS";
                                    }
                                    else x.Resultado = "NATIVO OK; ELEMENTO VÍNCULO: " + reason2;
                                }
                            }
                            if (candidate && string.IsNullOrWhiteSpace(x.NativeUniqueId)
                                && x.NativeId > 0)
                                x.Resultado += " | ID CANDIDATO: VALIDAR";
                            list.Add(x);
                        }
                    }
                }
                catch (Exception ex)
                {
                    errores++;
                    messages.Add(Path.GetFileName(file) + ": " + ex.Message);
                }
            }
            // Cargar estado persistido sin modificar nunca los JSON originales.
            // La clave se asocia a cada archivo fuente (modelo responsable).
            foreach (var grupo in list.GroupBy(x => x.SourceJsonPath,
                StringComparer.OrdinalIgnoreCase))
                CargarSeguimiento(grupo.Key, grupo.ToList(), messages);
            Form.SetResultados(list);
            Form.SetModelos(EstadoModelos(host, inventario));
            int found = list.Count(x => x.NativeId > 0);
            Form.SetEstado("Importados: " + list.Count +
                " | Elementos nativos: " + found +
                " | Sin vínculo/asociación: " + faltaLink +
                " | ID candidatos sin resolver: " + cand +
                " | Archivos de otro RVT: " + descartados +
                " | Errores: " + errores);
            if (messages.Count > 0)
                Forms.MessageBox.Show(string.Join("\r\n", messages.Take(12)),
                    "MYG NAVIS - Archivos no importados");
        }

        // Transformar correctamente las 8 esquinas del bounding box del
        // documento vinculado al sistema de coordenadas del anfitrión.
        private static List<XYZ> Corners(Element element, Transform link)
        {
            var result = new List<XYZ>();
            BoundingBoxXYZ bb = element == null ? null : element.get_BoundingBox(null);
            if (bb == null) return result;
            for (int i = 0; i < 8; i++)
            {
                XYZ p = new XYZ((i & 1) == 0 ? bb.Min.X : bb.Max.X,
                    (i & 2) == 0 ? bb.Min.Y : bb.Max.Y,
                    (i & 4) == 0 ? bb.Min.Z : bb.Max.Z);
                p = bb.Transform.OfPoint(p);
                result.Add(link == null ? p : link.OfPoint(p));
            }
            return result;
        }

        // ===============================================================
        // MYG - LEVANTAMIENTO / VERIFICACION GEOMETRICA (SIN NUGET)
        // ===============================================================
        // Advertencia: comprueba interseccion de SOLIDOS con volumen.
        // No sustituye las pruebas clearance/soft ni la reejecucion del
        // Clash Detective en el federado actualizado de Navisworks.

        private const double PieACm3 = 28316.846592; // 1 pie cubico en cm cubicos

        private static string RutaSeguimiento(string jsonPath)
        {
            // proyecto.ST-000001.json -> proyecto.ST-000001.mygavance
            return Path.ChangeExtension(jsonPath, ".mygavance");
        }

        private static string B64(string valor)
        {
            return Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(valor ?? ""));
        }
        private static string UnB64(string valor)
        {
            return System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(valor));
        }

        private static void CargarSeguimiento(string jsonPath,
            List<MYG_NavisIssue> issues, List<string> mensajes)
        {
            if (String.IsNullOrWhiteSpace(jsonPath)) return;
            string ruta = RutaSeguimiento(jsonPath);
            if (!File.Exists(ruta)) return;
            var porClave = issues.GroupBy(x => x.SeguimientoKey)
                .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.Ordinal);
            try
            {
                foreach (string linea in File.ReadAllLines(ruta,
                    System.Text.Encoding.UTF8).Skip(1))
                {
                    if (String.IsNullOrWhiteSpace(linea)) continue;
                    string[] c = linea.Split('\t');
                    if (c.Length < 5) continue;
                    string key = UnB64(c[0]);
                    List<MYG_NavisIssue> grupo;
                    if (!porClave.TryGetValue(key, out grupo)) continue;
                    foreach (MYG_NavisIssue x in grupo)
                    {
                        x.EstadoMYG = UnB64(c[1]);
                        x.VerificadoEn = UnB64(c[2]);
                        x.VolumenComun = UnB64(c[3]);
                        x.ObservacionMYG = UnB64(c[4]);
                    }
                }
            }
            catch (Exception ex)
            {
                mensajes.Add(Path.GetFileName(ruta) + ": no se pudo cargar seguimiento: " + ex.Message);
            }
        }

        private static void GuardarSeguimiento(List<MYG_NavisIssue> issues)
        {
            // Guardar archivo por modelo, junto al JSON de origen. No se escribe
            // en el RVT ni en el JSON y no se borra historial por cambiar la vista.
            foreach (var g in issues.Where(x => !String.IsNullOrWhiteSpace(x.SourceJsonPath))
                .GroupBy(x => x.SourceJsonPath, StringComparer.OrdinalIgnoreCase))
            {
                string ruta = RutaSeguimiento(g.Key);
                string tmp = ruta + ".tmp";
                var lineas = new List<string> { "MYG_NAVIS_REVIT_SEGUIMIENTO\t1" };
                foreach (MYG_NavisIssue x in g)
                    lineas.Add(String.Join("\t", new[] {
                        B64(x.SeguimientoKey), B64(x.EstadoMYG), B64(x.VerificadoEn),
                        B64(x.VolumenComun), B64(x.ObservacionMYG)
                    }));
                try
                {
                    File.WriteAllLines(tmp, lineas, new System.Text.UTF8Encoding(false));
                    // Reemplazo atomico en disco local cuando el destino existe.
                    // No borrar el avance anterior antes de comprobar el nuevo.
                    if (File.Exists(ruta)) File.Replace(tmp, ruta, null);
                    else File.Move(tmp, ruta);
                }
                catch
                {
                    try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
                    throw;
                }
            }
        }

        private void CambiarEstadoManual(string estado, string observacion)
        {
            MYG_NavisIssue issue = Form.SeleccionActual;
            if (issue == null) { Form.SetEstado("Selecciona un conflicto."); return; }
            if (estado == "JUSTIFICADO")
            {
                var r = Forms.MessageBox.Show(
                    "Se registrará como JUSTIFICADO (aceptado manualmente), " +
                    "NO como levantado geométricamente. ¿Confirmas?",
                    "MYG - Justificar interferencia", Forms.MessageBoxButtons.YesNo,
                    Forms.MessageBoxIcon.Question);
                if (r != Forms.DialogResult.Yes) return;
            }
            issue.EstadoMYG = estado;
            issue.ObservacionMYG = observacion;
            issue.VolumenComun = "";
            issue.VerificadoEn = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            Form.RefrescarSeguimiento();
            GuardarSeguimiento(Form.TodosLosConflictos);
            Form.SetEstado(issue.ClashName + ": " + issue.EstadoMYG +
                " | Guardado en .mygavance");
        }

        private static void RecogerSolidos(GeometryElement geometria,
            List<Solid> resultado, int profundidad)
        {
            if (geometria == null || profundidad > 8) return;
            foreach (GeometryObject o in geometria)
            {
                Solid solido = o as Solid;
                if (solido != null)
                {
                    try
                    {
                        if (solido.Faces.Size > 0 && solido.Volume > 1.0e-10)
                            resultado.Add(solido);
                    }
                    catch { }
                    continue;
                }
                GeometryInstance instancia = o as GeometryInstance;
                if (instancia != null)
                {
                    // GetInstanceGeometry: copia ya en coordenadas del
                    // documento PROPIETARIO (host o documento vinculado).
                    RecogerSolidos(instancia.GetInstanceGeometry(), resultado,
                        profundidad + 1);
                }
            }
        }

        private static List<Solid> Solidos(Element elem, Transform aHost)
        {
            var res = new List<Solid>();
            var opts = new Options
            {
                DetailLevel = ViewDetailLevel.Fine,
                IncludeNonVisibleObjects = false,
                ComputeReferences = false
            };
            GeometryElement geo = elem.get_Geometry(opts);
            RecogerSolidos(geo, res, 0);
            if (aHost != null)
            {
                // Los solidos del RVT vinculado se convierten al sistema del host.
                for (int i = 0; i < res.Count; i++)
                    res[i] = SolidUtils.CreateTransformed(res[i], aHost);
            }
            return res;
        }

        private static bool SolapanCajas(Solid a, Solid b)
        {
            BoundingBoxXYZ aa = a.GetBoundingBox();
            BoundingBoxXYZ bb = b.GetBoundingBox();
            if (aa == null || bb == null) return true; // no descartar por datos incompletos
            var va = new List<XYZ>(); var vb = new List<XYZ>();
            for (int i = 0; i < 8; i++)
            {
                va.Add(aa.Transform.OfPoint(new XYZ((i & 1) == 0 ? aa.Min.X : aa.Max.X,
                    (i & 2) == 0 ? aa.Min.Y : aa.Max.Y,
                    (i & 4) == 0 ? aa.Min.Z : aa.Max.Z)));
                vb.Add(bb.Transform.OfPoint(new XYZ((i & 1) == 0 ? bb.Min.X : bb.Max.X,
                    (i & 2) == 0 ? bb.Min.Y : bb.Max.Y,
                    (i & 4) == 0 ? bb.Min.Z : bb.Max.Z)));
            }
            const double eps = 1.0e-8;
            return va.Max(v => v.X) >= vb.Min(v => v.X) - eps &&
                   vb.Max(v => v.X) >= va.Min(v => v.X) - eps &&
                   va.Max(v => v.Y) >= vb.Min(v => v.Y) - eps &&
                   vb.Max(v => v.Y) >= va.Min(v => v.Y) - eps &&
                   va.Max(v => v.Z) >= vb.Min(v => v.Z) - eps &&
                   vb.Max(v => v.Z) >= va.Min(v => v.Z) - eps;
        }

        private static List<Solid> SolidosCacheados(
            Dictionary<string, List<Solid>> cache, string key,
            Element elemento, Transform transf)
        {
            List<Solid> res;
            if (!cache.TryGetValue(key, out res))
            {
                res = Solidos(elemento, transf);
                cache[key] = res;
            }
            return res;
        }

        private void VerificarUno()
        {
            MYG_NavisIssue x = Form.SeleccionActual;
            if (x == null) { Form.SetEstado("Selecciona un conflicto."); return; }
            if (x.EstadoMYG == "JUSTIFICADO")
            {
                var a = Forms.MessageBox.Show("Este conflicto está JUSTIFICADO. " +
                    "¿Quieres sustituir la justificación por la comprobación geométrica?",
                    "MYG", Forms.MessageBoxButtons.YesNo, Forms.MessageBoxIcon.Question);
                if (a != Forms.DialogResult.Yes) return;
            }
            VerificarGeometria(x, new Dictionary<string, List<Solid>>());
            Form.RefrescarSeguimiento();
            GuardarSeguimiento(Form.TodosLosConflictos);
            Form.SetEstado(x.ClashName + ": " + x.EstadoMYG +
                " | Volumen común: " + x.VolumenComun + " cm³" +
                " | seguimiento guardado.");
        }

        private void VerificarTodos()
        {
            List<MYG_NavisIssue> todos = Form.TodosLosConflictos;
            if (todos.Count == 0) { Form.SetEstado("Importa primero los JSON."); return; }
            var res = Forms.MessageBox.Show(
                "Se comprobarán " + todos.Count + " conflictos en el RVT activo. " +
                "Las justificaciones manuales se conservarán. " +
                "Esta operación puede tardar varios minutos. ¿Continuar?",
                "MYG - Verificación masiva", Forms.MessageBoxButtons.YesNo,
                Forms.MessageBoxIcon.Question);
            if (res != Forms.DialogResult.Yes) return;
            var cache = new Dictionary<string, List<Solid>>();
            int n = 0;
            foreach (MYG_NavisIssue x in todos)
            {
                if (x.EstadoMYG == "JUSTIFICADO") continue;
                try { VerificarGeometria(x, cache); }
                catch (Exception ex)
                {
                    x.EstadoMYG = "INDETERMINADO";
                    x.ObservacionMYG = "Excepción al verificar: " + ex.Message;
                    x.VolumenComun = "";
                    x.VerificadoEn = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                }
                n++;
                if (n % 25 == 0) Form.SetEstado("Verificando " + n + " / " + todos.Count + "...");
            }
            Form.RefrescarSeguimiento();
            GuardarSeguimiento(todos);
            Form.SetEstado("Verificación masiva terminada: " + n +
                " evaluados. Revisa ESTADO MYG y actualiza Navisworks para confirmar.");
        }

        private void VerificarGeometria(MYG_NavisIssue x,
            Dictionary<string, List<Solid>> cache)
        {
            x.VerificadoEn = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            x.VolumenComun = "";
            x.ObservacionMYG = "";
            Document host = UiDoc.Document;
            Element nativo = x.NativeId > 0
                ? host.GetElement(new ElementId(x.NativeId)) : null;
            if (nativo == null || (x.NativeUniqueId.Length > 0 &&
                !String.Equals(nativo.UniqueId, x.NativeUniqueId, StringComparison.Ordinal)))
            {
                x.EstadoMYG = "NO LOCALIZADO";
                x.ObservacionMYG = "El nativo falta o su UniqueId cambió; reimportar JSON.";
                return;
            }
            Element otro = null;
            RevitLinkInstance li = null;
            if (x.CounterpartIsHost)
                otro = x.CounterpartId > 0
                    ? host.GetElement(new ElementId(x.CounterpartId)) : null;
            else if (x.LinkInstanceId > 0)
            {
                li = host.GetElement(new ElementId(x.LinkInstanceId)) as RevitLinkInstance;
                Document ld = li == null ? null : li.GetLinkDocument();
                if (ld != null && x.CounterpartId > 0)
                    otro = ld.GetElement(new ElementId(x.CounterpartId));
            }
            if (otro == null || (x.CounterpartUniqueId.Length > 0 &&
                !String.Equals(otro.UniqueId, x.CounterpartUniqueId, StringComparison.Ordinal)))
            {
                x.EstadoMYG = "NO LOCALIZADO";
                x.ObservacionMYG = "Contraparte o vínculo faltante, ambiguo o UniqueId distinto; actualizar RVT.";
                return;
            }
            try
            {
                List<Solid> a = SolidosCacheados(cache, "HOST:" + nativo.Id.Value,
                    nativo, null);
                List<Solid> b = SolidosCacheados(cache,
                    (li == null ? "HOST:" : "LINK:" + li.Id.Value + ":") + otro.Id.Value,
                    otro, li == null ? null : li.GetTotalTransform());
                if (a.Count == 0 || b.Count == 0)
                {
                    x.EstadoMYG = "INDETERMINADO";
                    x.ObservacionMYG = "No se recuperaron sólidos válidos de ambos elementos.";
                    return;
                }
                // El volumen en Revit es pie³; la tolerancia se recibe en cm³.
                double umbral = Math.Max(0.0, Form.ToleranciaCm3) / PieACm3;
                double volumen = 0.0;
                bool errorBooleano = false;
                string primerError = "";
                foreach (Solid sa in a)
                    foreach (Solid sb in b)
                    {
                        if (!SolapanCajas(sa, sb)) continue;
                        try
                        {
                            Solid inter = BooleanOperationsUtils.ExecuteBooleanOperation(
                                sa, sb, BooleanOperationsType.Intersect);
                            if (inter != null) volumen += Math.Max(0.0, inter.Volume);
                        }
                        catch (Exception ex)
                        {
                            errorBooleano = true;
                            if (primerError.Length == 0) primerError = ex.Message;
                        }
                    }
                x.VolumenComun = (volumen * PieACm3).ToString("0.###",
                    System.Globalization.CultureInfo.InvariantCulture);
                if (volumen > umbral)
                {
                    x.EstadoMYG = "PERSISTE";
                    x.ObservacionMYG = "Volumen común mayor que la tolerancia. " +
                        (errorBooleano ? "Algunas suboperaciones booleanas fallaron." : "");
                }
                else if (errorBooleano)
                {
                    x.EstadoMYG = "INDETERMINADO";
                    x.ObservacionMYG = "Fallo en intersección de sólidos: " + primerError;
                }
                else if (x.NativeIdCandidato || x.CounterpartIdCandidato)
                {
                    x.EstadoMYG = "REVISAR ID";
                    x.ObservacionMYG = "Volumen bajo tolerancia pero hay ID derivado del nombre; " +
                        "confirmar identidad antes de declarar levantamiento.";
                }
                else
                {
                    x.EstadoMYG = "LEVANTADO EN REVIT";
                    x.ObservacionMYG = "Sin intersección volumétrica superior a " +
                        Form.ToleranciaCm3.ToString("0.###") + " cm³. " +
                        "PENDIENTE de reejecutar Clash Detective del federado.";
                }
            }
            catch (Exception ex)
            {
                x.EstadoMYG = "INDETERMINADO";
                x.ObservacionMYG = "Error al recuperar geometría: " + ex.Message;
            }
        }

        private void Mostrar(bool aislar)
        {
            var x = Form.SeleccionActual;
            if (x == null) { Form.SetEstado("Selecciona una fila."); return; }
            Document doc = UiDoc.Document;
            if (x.NativeId <= 0)
            {
                Form.SetEstado("No se puede localizar: " + x.Resultado);
                return;
            }
            Element native = doc.GetElement(new ElementId(x.NativeId));
            if (native == null)
            {
                Form.SetEstado("El elemento nativo ya no existe; reimporta el JSON.");
                return;
            }
            Element other = null;
            RevitLinkInstance linkInstance = null;
            if (x.CounterpartIsHost && x.CounterpartId > 0)
                other = doc.GetElement(new ElementId(x.CounterpartId));
            if (x.LinkInstanceId > 0 && x.CounterpartId > 0)
            {
                linkInstance = doc.GetElement(new ElementId(x.LinkInstanceId))
                    as RevitLinkInstance;
                Document ld = linkInstance == null ? null : linkInstance.GetLinkDocument();
                if (ld != null)
                    other = ld.GetElement(new ElementId(x.CounterpartId));
            }
            var ids = new List<ElementId> { native.Id };
            if (x.CounterpartIsHost && other != null && other.Id != native.Id)
                ids.Add(other.Id);
            if (linkInstance != null && other != null)
                ids.Add(linkInstance.Id);

            View view = UiDoc.ActiveView;
            if (aislar)
            {
                if (view.TemporaryViewModes == null ||
                    !view.TemporaryViewModes.IsModeAvailable(
                        TemporaryViewMode.TemporaryHideIsolate))
                    throw new InvalidOperationException(
                        "La vista activa no permite aislamiento temporal. Abre una vista 3D.");
                View3D v3d = view as View3D;
                using (Transaction t = new Transaction(doc, "MYG NAVIS - Aislar conflicto"))
                {
                    t.Start();
                    if (view.IsInTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate))
                        view.DisableTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate);
                    // La API de IsolateElementsTemporary recibe IDs del HOST.
                    // Por eso se aísla la instancia del vínculo y el nativo;
                    // luego se recorta el área al elemento exacto del vínculo.
                    view.IsolateElementsTemporary(ids);
                    changedView = true;
                    if (v3d != null)
                    {
                        var all = Corners(native, null);
                        if (other != null && linkInstance != null)
                            all.AddRange(Corners(other, linkInstance.GetTotalTransform()));
                        else if (other != null)
                            all.AddRange(Corners(other, null));
                        if (all.Count > 0)
                        {
                            if (previous3DViewId != v3d.Id.Value)
                            {
                                previous3DViewId = v3d.Id.Value;
                                previousSectionBox = v3d.GetSectionBox();
                                hadSectionBox = v3d.IsSectionBoxActive;
                                originalDocument = doc;
                            }
                            double minX = all.Min(p => p.X), minY = all.Min(p => p.Y),
                                   minZ = all.Min(p => p.Z), maxX = all.Max(p => p.X),
                                   maxY = all.Max(p => p.Y), maxZ = all.Max(p => p.Z);
                            const double marginFt = 3.0;
                            var bb = new BoundingBoxXYZ();
                            bb.Min = new XYZ(minX - marginFt, minY - marginFt, minZ - marginFt);
                            bb.Max = new XYZ(maxX + marginFt, maxY + marginFt, maxZ + marginFt);
                            v3d.SetSectionBox(bb);
                            v3d.IsSectionBoxActive = true;
                        }
                    }
                    t.Commit();
                }
            }
            // IMPORTANTE: zoom/redibujo ANTES de la selección final. Dejar
            // ShowElements() después de SetReferences() puede cambiar el foco y
            // dificultar que Revit muestre la selección del elemento vinculado.
            try { UiDoc.ShowElements(native.Id); } catch { }
            UiDoc.RefreshActiveView();

            // No seleccionar el RevitLinkInstance en la selección principal:
            // eso resaltaría el RVT completo, no su elemento del conflicto.
            // Los IDs de la instancia SOLO son necesarios para el aislamiento.
            var referencias = new List<Reference> { new Reference(native) };
            bool contraparteVinculada = other != null && linkInstance != null;
            if (contraparteVinculada)
                referencias.Add(new Reference(other).CreateLinkReference(linkInstance));
            else if (other != null && x.CounterpartIsHost && other.Id != native.Id)
                referencias.Add(new Reference(other));

            string estadoSeleccion = "";
            bool seleccionExacta = false;
            try
            {
                UiDoc.Selection.SetReferences(referencias);
                // GetReferences, a diferencia de GetElementIds, también devuelve
                // LinkedElementId de la contraparte seleccionada dentro de RVT.
                IList<Reference> actuales = UiDoc.Selection.GetReferences();
                bool nativoSeleccionado = actuales != null && actuales.Any(r =>
                    r != null && r.ElementId != null &&
                    r.ElementId.Equals(native.Id) &&
                    (r.LinkedElementId == null ||
                     r.LinkedElementId.Equals(ElementId.InvalidElementId)));
                bool segundoSeleccionado = other != null && actuales != null &&
                    actuales.Any(r => r != null && r.ElementId != null &&
                        (contraparteVinculada
                            ? r.ElementId.Equals(linkInstance.Id) &&
                              r.LinkedElementId != null &&
                              r.LinkedElementId.Equals(other.Id)
                            : r.ElementId.Equals(other.Id) &&
                              (r.LinkedElementId == null ||
                               r.LinkedElementId.Equals(ElementId.InvalidElementId))));
                seleccionExacta = nativoSeleccionado &&
                    (other == null || segundoSeleccionado);
                estadoSeleccion = other == null
                    ? " | SELECCIÓN: solo nativo; elemento 2 no localizado"
                    : seleccionExacta
                        ? " | SELECCIONADOS AMBOS (referencias verificadas)"
                        : " | AVISO: Revit no devolvió las dos referencias esperadas";
            }
            catch (Exception exSeleccion)
            {
                // Si la selección de referencias falla, no fingir que el
                // elemento del RVT quedó seleccionado: la alternativa básica
                // de Revit trabaja con IDs del documento anfitrión.
                try { UiDoc.Selection.SetElementIds(ids); }
                catch
                {
                    UiDoc.Selection.SetElementIds(
                    new List<ElementId> { native.Id });
                }
                estadoSeleccion = " | AVISO: selección exacta no disponible (" +
                    exSeleccion.GetType().Name + ": " +
                    exSeleccion.Message + "); selección anfitrión/instancia";
            }

            Form.SetEstado((aislar ? "AISLADO" : "SELECCIONADO") +
                ": nativo " + x.NativeIdText +
                (other != null ? " + contraparte " + x.CounterpartIdText :
                    " | contraparte no localizada") + estadoSeleccion);
        }

        private void Restaurar()
        {
            Document doc = UiDoc.Document;
            View view = UiDoc.ActiveView;
            using (Transaction t = new Transaction(doc, "MYG NAVIS - Restaurar vista"))
            {
                t.Start();
                if (changedView &&
                    view.IsInTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate))
                    view.DisableTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate);
                View3D v3d = view as View3D;
                if (v3d != null && previousSectionBox != null &&
                    previous3DViewId == v3d.Id.Value &&
                    EsMismoDocumento(doc, originalDocument))
                {
                    v3d.SetSectionBox(previousSectionBox);
                    v3d.IsSectionBoxActive = hadSectionBox;
                    previousSectionBox = null;
                    previous3DViewId = -1;
                }
                t.Commit();
            }
            changedView = false;
            UiDoc.Selection.SetElementIds(new List<ElementId>());
            UiDoc.RefreshActiveView();
            Form.SetEstado("Vista/restos de selección MYG restaurados.");
        }
    }

    // Lector JSON autonómo para el formato MYG_BIM_CLASH.
    // Admite objetos, arrays, cadenas con escapes Unicode, numeros, booleanos y null.
    // No requiere System.Text.Json, Newtonsoft.Json ni System.Web.Extensions.
    internal sealed class MYG_NavisJsonReader
    {
        private readonly string input;
        private int index;
        private int nesting;
        private const int MaxDepth = 128;

        private MYG_NavisJsonReader(string json)
        {
            input = json ?? throw new ArgumentNullException("json");
        }

        internal static object Parse(string json)
        {
            var reader = new MYG_NavisJsonReader(json);
            reader.Space();
            object value = reader.Value();
            reader.Space();
            if (reader.index != reader.input.Length)
                throw reader.Error("Contenido adicional despues del JSON");
            return value;
        }

        private Exception Error(string message)
        {
            return new FormatException("JSON MYG invalido en posicion " +
                index.ToString() + ": " + message);
        }

        private void Space()
        {
            while (index < input.Length &&
                (input[index] == ' ' || input[index] == '\r' ||
                 input[index] == '\n' || input[index] == '\t' ||
                 input[index] == '\uFEFF')) index++;
        }

        private char Peek()
        {
            return index < input.Length ? input[index] : '\0';
        }

        private void Expect(char expected)
        {
            Space();
            if (Peek() != expected)
                throw Error("Se esperaba '" + expected + "'");
            index++;
        }

        private object Value()
        {
            Space();
            switch (Peek())
            {
                case '{': return Object();
                case '[': return Array();
                case '"': return QuotedString();
                case 't': Literal("true"); return true;
                case 'f': Literal("false"); return false;
                case 'n': Literal("null"); return null;
                default:
                    if (Peek() == '-' || (Peek() >= '0' && Peek() <= '9'))
                        return NumberText();
                    throw Error("Valor JSON inesperado");
            }
        }

        private void Literal(string word)
        {
            if (input.Length - index < word.Length ||
                string.CompareOrdinal(input, index, word, 0, word.Length) != 0)
                throw Error("Se esperaba " + word);
            index += word.Length;
        }

        private Dictionary<string, object> Object()
        {
            if (++nesting > MaxDepth) throw Error("Anidamiento JSON excesivo");
            Expect('{');
            var map = new Dictionary<string, object>(StringComparer.Ordinal);
            Space();
            if (Peek() == '}') { index++; nesting--; return map; }
            while (true)
            {
                Space();
                if (Peek() != '"') throw Error("Nombre de propiedad esperado");
                string key = QuotedString();
                Expect(':');
                map[key] = Value();
                Space();
                if (Peek() == '}') { index++; nesting--; return map; }
                Expect(',');
            }
        }

        private List<object> Array()
        {
            if (++nesting > MaxDepth) throw Error("Anidamiento JSON excesivo");
            Expect('[');
            var list = new List<object>();
            Space();
            if (Peek() == ']') { index++; nesting--; return list; }
            while (true)
            {
                list.Add(Value());
                Space();
                if (Peek() == ']') { index++; nesting--; return list; }
                Expect(',');
            }
        }

        private string QuotedString()
        {
            Expect('"');
            var sb = new System.Text.StringBuilder();
            while (index < input.Length)
            {
                char ch = input[index++];
                if (ch == '"') return sb.ToString();
                if (ch < 0x20) throw Error("Caracter de control en cadena");
                if (ch != '\\') { sb.Append(ch); continue; }
                if (index >= input.Length) throw Error("Escape incompleto");
                ch = input[index++];
                switch (ch)
                {
                    case '"': sb.Append('"'); break;
                    case '\\': sb.Append('\\'); break;
                    case '/': sb.Append('/'); break;
                    case 'b': sb.Append('\b'); break;
                    case 'f': sb.Append('\f'); break;
                    case 'n': sb.Append('\n'); break;
                    case 'r': sb.Append('\r'); break;
                    case 't': sb.Append('\t'); break;
                    case 'u':
                        if (input.Length - index < 4)
                            throw Error("Secuencia Unicode incompleta");
                        int code = 0;
                        for (int k = 0; k < 4; k++)
                        {
                            char h = input[index++];
                            int hex = h >= '0' && h <= '9' ? h - '0' :
                                h >= 'A' && h <= 'F' ? h - 'A' + 10 :
                                h >= 'a' && h <= 'f' ? h - 'a' + 10 : -1;
                            if (hex < 0) throw Error("Digito Unicode no valido");
                            code = code * 16 + hex;
                        }
                        sb.Append((char)code);
                        break;
                    default: throw Error("Escape de cadena no valido");
                }
            }
            throw Error("Cadena sin cerrar");
        }

        // Mantener el valor numerico como texto evita perder precision en IDs
        // de Revit (pueden exceder el limite exacto de un double).
        private string NumberText()
        {
            int start = index;
            if (Peek() == '-') index++;
            if (Peek() == '0') index++;
            else
            {
                if (Peek() < '1' || Peek() > '9')
                    throw Error("Numero JSON invalido");
                while (Peek() >= '0' && Peek() <= '9') index++;
            }
            if (Peek() == '.')
            {
                index++;
                if (Peek() < '0' || Peek() > '9')
                    throw Error("Decimal JSON invalido");
                while (Peek() >= '0' && Peek() <= '9') index++;
            }
            if (Peek() == 'e' || Peek() == 'E')
            {
                index++;
                if (Peek() == '+' || Peek() == '-') index++;
                if (Peek() < '0' || Peek() > '9')
                    throw Error("Exponente JSON invalido");
                while (Peek() >= '0' && Peek() <= '9') index++;
            }
            return input.Substring(start, index - start);
        }
    }

}
