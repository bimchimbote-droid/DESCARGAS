using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================================
    // COMANDO - NAVISWORKS IMPORT
    // =====================================================

    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class MYG_NavisworksImportCommand : Autodesk.Revit.UI.IExternalCommand
    {
        private static MYG_NavisworksImportForm ventana;
        private static MYG_Addin.MYG_NavisworksImportHandler handler;
        private static Autodesk.Revit.UI.ExternalEvent evento;

        public Autodesk.Revit.UI.Result Execute(
            Autodesk.Revit.UI.ExternalCommandData commandData,
            ref string message,
            Autodesk.Revit.DB.ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            try
            {
                Autodesk.Revit.UI.UIDocument ui = commandData.Application.ActiveUIDocument;
                if (ui == null || ui.Document == null)
                {
                    Autodesk.Revit.UI.TaskDialog.Show("MYG NAVIS", "Abre primero el modelo RVT responsable.");
                    return Autodesk.Revit.UI.Result.Cancelled;
                }

                if (ventana != null && !ventana.IsDisposed)
                {
                    ventana.Show();
                    ventana.WindowState = System.Windows.Forms.FormWindowState.Normal;
                    ventana.BringToFront();
                    ventana.Activate();
                    return Autodesk.Revit.UI.Result.Succeeded;
                }

                handler = new MYG_Addin.MYG_NavisworksImportHandler();
                handler.UiDoc = ui;
                evento = Autodesk.Revit.UI.ExternalEvent.Create(handler);
                ventana = new MYG_NavisworksImportForm(handler, evento, ui.Document.Title);
                handler.Form = ventana;
                ventana.FormClosed += (sender, args) =>
                {
                    try { if (evento != null) evento.Dispose(); } catch { }
                    evento = null;
                    handler = null;
                    ventana = null;
                };
                ventana.Show();
                return Autodesk.Revit.UI.Result.Succeeded;
            }
            catch (System.Exception ex)
            {
                message = ex.Message;
                Autodesk.Revit.UI.TaskDialog.Show("MYG NAVIS - Error", ex.ToString());
                return Autodesk.Revit.UI.Result.Failed;
            }
        }
    }

}
