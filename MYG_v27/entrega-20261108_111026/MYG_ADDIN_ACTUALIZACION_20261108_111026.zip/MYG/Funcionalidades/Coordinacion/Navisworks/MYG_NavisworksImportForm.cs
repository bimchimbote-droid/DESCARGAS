using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // PEGAR ESTA CLASE EN TU MYGCommand.cs, REEMPLAZANDO SOLO LA CLASE MYG_NavisworksImportForm.
    // Sin using ni namespace.

    public class MYG_NavisworksImportForm : System.Windows.Forms.Form
    {
        private readonly MYG_Addin.MYG_NavisworksImportHandler handler;
        private readonly Autodesk.Revit.UI.ExternalEvent externalEvent;
        private readonly System.Collections.Generic.List<string> paths =
            new System.Collections.Generic.List<string>();
        private System.ComponentModel.BindingList<MYG_Addin.MYG_NavisIssue> data =
            new System.ComponentModel.BindingList<MYG_Addin.MYG_NavisIssue>();
        private System.Windows.Forms.DataGridView grid;
        private System.Windows.Forms.TextBox detail;
        private System.Windows.Forms.Label status;
        private readonly System.Collections.Generic.List<MYG_Addin.MYG_NavisRvtStatus> modelos =
            new System.Collections.Generic.List<MYG_Addin.MYG_NavisRvtStatus>();
        // Elección confirmada por el usuario para la siguiente petición al ExternalEvent.
        // No se accede a la API de Revit desde eventos WinForms.
        public string ModeloParaVincular { get; private set; } = "";
        public string RutaRvtParaVincular { get; private set; } = "";
        public bool UsarCoordenadasCompartidas { get; private set; }
        // El JSON solo contiene nombres, NO contiene GUID de modelo Autodesk Docs.
        // Estos datos los confirma el usuario para enlace directo por API.
        public bool VincularDesdeNube { get; private set; }
        public string RegionNube { get; private set; } = "";
        public string ProyectoGuidNube { get; private set; } = "";
        public string ModeloGuidNube { get; private set; } = "";
        private System.Windows.Forms.Button btnModelos;
        private System.Windows.Forms.Form ventanaModelos;
        private System.Windows.Forms.ListView listadoModelos;
        private System.Windows.Forms.Label resumenModelos;
        private System.Windows.Forms.Button btnAislar;
        private string resumenAvance = "";
        private System.Windows.Forms.NumericUpDown controlTolerancia;
        private bool pending;

        public MYG_NavisworksImportForm(
            MYG_Addin.MYG_NavisworksImportHandler h,
            Autodesk.Revit.UI.ExternalEvent e,
            string hostTitle)
        {
            handler = h;
            externalEvent = e;
            Text = "MYG | Interferencias importadas desde Navisworks";
            Width = 1450;
            Height = 800;
            MinimumSize = new System.Drawing.Size(1100, 600);
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Font = new System.Drawing.Font("Segoe UI", 9F);
            ConstruirVentana(hostTitle);
        }

        public System.Collections.Generic.List<string> JsonPaths
        {
            get { return new System.Collections.Generic.List<string>(paths); }
        }
        // Los ID candidatos se intentan resolver siempre, sin casilla.
        // Siguen sujetos a comprobación contra el elemento real del RVT.
        public bool PermitirIdCandidato { get { return true; } }
        public System.Collections.Generic.List<MYG_Addin.MYG_NavisIssue> TodosLosConflictos
        {
            get { return new System.Collections.Generic.List<MYG_Addin.MYG_NavisIssue>(data); }
        }
        public double ToleranciaCm3
        {
            get { return controlTolerancia == null ? 1.0 : (double)controlTolerancia.Value; }
        }

        public MYG_Addin.MYG_NavisIssue SeleccionActual
        {
            get
            {
                if (grid.CurrentRow == null) return null;
                return grid.CurrentRow.DataBoundItem as MYG_Addin.MYG_NavisIssue;
            }
        }

        private System.Windows.Forms.Button CrearBoton(string texto, int ancho,
            System.EventHandler click)
        {
            var b = new System.Windows.Forms.Button();
            b.Text = texto;
            b.Width = ancho;
            b.Height = 32;
            b.Margin = new System.Windows.Forms.Padding(3);
            b.Click += click;
            return b;
        }

        private void ConstruirVentana(string titulo)
        {
            var layout = new System.Windows.Forms.TableLayoutPanel();
            layout.Dock = System.Windows.Forms.DockStyle.Fill;
            layout.ColumnCount = 1;
            layout.RowCount = 3;
            layout.Padding = new System.Windows.Forms.Padding(10);
            layout.RowStyles.Add(new System.Windows.Forms.RowStyle(
                System.Windows.Forms.SizeType.Absolute, 92));
            layout.RowStyles.Add(new System.Windows.Forms.RowStyle(
                System.Windows.Forms.SizeType.Percent, 100));
            layout.RowStyles.Add(new System.Windows.Forms.RowStyle(
                System.Windows.Forms.SizeType.Absolute, 40));
            Controls.Add(layout);

            var top = new System.Windows.Forms.FlowLayoutPanel();
            top.Dock = System.Windows.Forms.DockStyle.Fill;
            top.WrapContents = true;
            top.Controls.Add(CrearBoton("IMPORTAR JSON", 125, (s, e) => ImportarArchivos()));
            top.Controls.Add(CrearBoton("IMPORTAR CARPETA", 145, (s, e) => ImportarCarpeta()));
            btnAislar = CrearBoton("AISLAR CONFLICTO", 145,
                (s, e) => Raise(MYG_Addin.MYG_NavisworksRequest.Aislar));
            top.Controls.Add(btnAislar);
            top.Controls.Add(CrearBoton("SELECCIONAR", 115,
                (s, e) => Raise(MYG_Addin.MYG_NavisworksRequest.Seleccionar)));
            top.Controls.Add(CrearBoton("RESTAURAR VISTA", 125,
                (s, e) => Raise(MYG_Addin.MYG_NavisworksRequest.Restaurar)));
            top.Controls.Add(CrearBoton("EXPORTAR AVANCE CSV", 160,
                (s, e) => ExportarAvance()));
            btnModelos = CrearBoton("MODELOS RVT (0)", 160,
                (s, e) => AbrirControlModelos());
            top.Controls.Add(btnModelos);
            // Dos filas independientes para que los botones no queden recortados.
            var barra = new System.Windows.Forms.TableLayoutPanel();
            barra.Dock = System.Windows.Forms.DockStyle.Fill;
            barra.RowCount = 2;
            barra.ColumnCount = 1;
            barra.RowStyles.Add(new System.Windows.Forms.RowStyle(
                System.Windows.Forms.SizeType.Percent, 50));
            barra.RowStyles.Add(new System.Windows.Forms.RowStyle(
                System.Windows.Forms.SizeType.Percent, 50));
            barra.Controls.Add(top, 0, 0);
            var verificacion = new System.Windows.Forms.FlowLayoutPanel();
            verificacion.Dock = System.Windows.Forms.DockStyle.Fill;
            verificacion.WrapContents = false;
            verificacion.Controls.Add(CrearBoton("VERIFICAR CONFLICTO", 167,
                (s, e) => Raise(MYG_Addin.MYG_NavisworksRequest.VerificarUno)));
            verificacion.Controls.Add(CrearBoton("VERIFICAR TODOS", 145,
                (s, e) => Raise(MYG_Addin.MYG_NavisworksRequest.VerificarTodos)));
            verificacion.Controls.Add(CrearBoton("MARCAR CORREGIDO", 150,
                (s, e) => Raise(MYG_Addin.MYG_NavisworksRequest.MarcarCorregido)));
            verificacion.Controls.Add(CrearBoton("JUSTIFICAR", 112,
                (s, e) => Raise(MYG_Addin.MYG_NavisworksRequest.Justificar)));
            verificacion.Controls.Add(CrearBoton("REABRIR ESTADO", 132,
                (s, e) => Raise(MYG_Addin.MYG_NavisworksRequest.ReiniciarSeguimiento)));
            verificacion.Controls.Add(new System.Windows.Forms.Label
            {
                Text = "Tolerancia (cm³):",
                AutoSize = true,
                Margin = new System.Windows.Forms.Padding(12, 10, 2, 0)
            });
            controlTolerancia = new System.Windows.Forms.NumericUpDown();
            controlTolerancia.DecimalPlaces = 2;
            controlTolerancia.Minimum = 0.01M;
            controlTolerancia.Maximum = 100000M;
            controlTolerancia.Value = 1.00M;
            controlTolerancia.Increment = 0.25M;
            controlTolerancia.Width = 84;
            controlTolerancia.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            verificacion.Controls.Add(controlTolerancia);
            barra.Controls.Add(verificacion, 0, 1);
            layout.Controls.Add(barra, 0, 0);

            // El SplitContainer aún NO tiene ancho definitivo durante la construcción.
            // No establecer aquí ni SplitterDistance=910 ni tamaños mínimos fijos:
            // WinForms arroja InvalidOperationException cuando el ancho es provisional.
            var split = new System.Windows.Forms.SplitContainer();
            split.Dock = System.Windows.Forms.DockStyle.Fill;
            split.Orientation = System.Windows.Forms.Orientation.Vertical;
            split.Panel1MinSize = 0;
            split.Panel2MinSize = 0;
            layout.Controls.Add(split, 0, 1);

            // Ajustar el separador solo al mostrarse la ventana, después del layout.
            // Funciona con diferentes escalas de pantalla y tamaños de ventana.
            Shown += (s, e) =>
            {
                if (split.IsDisposed) return;
                int anchoUtil = split.ClientSize.Width - split.SplitterWidth;
                if (anchoUtil <= 0) return;
                int objetivo = (int)System.Math.Round(anchoUtil * 0.66);
                objetivo = System.Math.Max(0, System.Math.Min(objetivo, anchoUtil));
                split.SplitterDistance = objetivo;
            };

            grid = new System.Windows.Forms.DataGridView();
            grid.Dock = System.Windows.Forms.DockStyle.Fill;
            grid.AutoGenerateColumns = false;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.RowHeadersVisible = false;
            grid.MultiSelect = false;
            grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            grid.ReadOnly = true;
            grid.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            grid.BackgroundColor = System.Drawing.Color.White;
            grid.RowTemplate.Height = 26;
            grid.AutoSizeColumnsMode =
                System.Windows.Forms.DataGridViewAutoSizeColumnsMode.None;
            Col("N°", "Numero", 45);
            Col("Prueba", "TestName", 120);
            Col("Conflicto", "ClashName", 120);
            Col("Elemento nativo", "NativeName", 190);
            Col("ID nativo", "NativeIdText", 90);
            Col("Modelo vinculado", "LinkModel", 210);
            Col("ID vínculo", "CounterpartIdText", 90);
            Col("Resultado", "Resultado", 215);
            Col("ESTADO MYG", "EstadoMYG", 165);
            Col("Verificado", "VerificadoEn", 155);
            Col("Vol. común cm³", "VolumenComun", 112);
            Col("Instrucción", "Instruction", 240);
            grid.DataSource = data;
            // Un SOLO clic sobre una fila ya solicita aislar el conflicto.
            // No se usa SelectionChanged para ejecutar Revit: se dispara tambien
            // durante DataSource, carga inicial y movimientos programaticos.
            grid.CellClick += (s, e) =>
            {
                if (e.RowIndex < 0 || e.ColumnIndex < 0 || pending) return;
                if (grid.CurrentCell == null || grid.CurrentCell.RowIndex != e.RowIndex)
                    grid.CurrentCell = grid[e.ColumnIndex, e.RowIndex];
                MYG_Addin.MYG_NavisIssue issue = SeleccionActual;
                if (issue == null) return;
                if (issue.NativeId <= 0)
                {
                    SetEstado("No se puede aislar: " + issue.Resultado +
                        ". Comprueba el ID nativo y vuelve a importar el JSON.");
                    return;
                }
                SetEstado("Localizando " + issue.ClashName + " en Revit...");
                Raise(MYG_Addin.MYG_NavisworksRequest.Aislar);
            };
            // Doble clic conserva la funcionalidad anterior; el guard pending
            // evita dos ExternalEvent simultaneos.
            grid.CellDoubleClick += (s, e) =>
            {
                if (e.RowIndex >= 0 && !pending)
                    Raise(MYG_Addin.MYG_NavisworksRequest.Aislar);
            };
            grid.SelectionChanged += (s, e) => MostrarDetalle();
            grid.DataBindingComplete += (s, e) => PintarFilas();
            split.Panel1.Controls.Add(grid);

            var group = new System.Windows.Forms.GroupBox();
            group.Dock = System.Windows.Forms.DockStyle.Fill;
            group.Text = "DETALLE / INSTRUCCIÓN DE COORDINACIÓN";
            group.Padding = new System.Windows.Forms.Padding(10);
            detail = new System.Windows.Forms.TextBox();
            detail.Dock = System.Windows.Forms.DockStyle.Fill;
            detail.Multiline = true;
            detail.ReadOnly = true;
            detail.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            detail.Font = new System.Drawing.Font("Segoe UI", 10F);
            group.Controls.Add(detail);
            split.Panel2.Controls.Add(group);

            status = new System.Windows.Forms.Label();
            status.Dock = System.Windows.Forms.DockStyle.Fill;
            status.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            status.Text = "RVT abierto: " + titulo + "  |  Selecciona IMPORTAR JSON. " +
                "Un clic = aislar nativo + instancia del vínculo. Comprueba columna Resultado.";
            layout.Controls.Add(status, 0, 2);
        }

        private void Col(string header, string prop, int width)
        {
            grid.Columns.Add(new System.Windows.Forms.DataGridViewTextBoxColumn
            {
                HeaderText = header,
                DataPropertyName = prop,
                Width = width,
                ReadOnly = true
            });
        }

        private void ImportarArchivos()
        {
            using (var dlg = new System.Windows.Forms.OpenFileDialog())
            {
                dlg.Title = "Seleccionar JSON exportados por MYG NAVIS";
                dlg.Filter = "MYG NAVIS (*.json)|*.json";
                dlg.Multiselect = true;
                if (dlg.ShowDialog(this) != System.Windows.Forms.DialogResult.OK) return;
                paths.Clear();
                paths.AddRange(dlg.FileNames);
                Raise(MYG_Addin.MYG_NavisworksRequest.Importar);
            }
        }

        private void ImportarCarpeta()
        {
            using (var dlg = new System.Windows.Forms.FolderBrowserDialog())
            {
                dlg.Description = "Carpeta con JSON por modelo de MYG NAVIS";
                if (dlg.ShowDialog(this) != System.Windows.Forms.DialogResult.OK) return;
                paths.Clear();
                paths.AddRange(System.IO.Directory.GetFiles(
                    dlg.SelectedPath, "*.json", System.IO.SearchOption.TopDirectoryOnly));
                if (paths.Count == 0)
                {
                    SetEstado("No hay archivos .json en la carpeta seleccionada.");
                    return;
                }
                Raise(MYG_Addin.MYG_NavisworksRequest.Importar);
            }
        }

        private void Raise(MYG_Addin.MYG_NavisworksRequest req)
        {
            if (handler == null || externalEvent == null || pending) return;
            pending = true;
            handler.Request = req;
            try
            {
                var result = externalEvent.Raise();
                if (result != Autodesk.Revit.UI.ExternalEventRequest.Accepted)
                {
                    pending = false;
                    SetEstado("Revit está ocupado (evento " + result + "). Intenta de nuevo.");
                }
            }
            catch (System.Exception ex)
            {
                pending = false;
                SetEstado("No se pudo solicitar la operación: " + ex.Message);
            }
        }

        public void EventoFinalizado()
        {
            pending = false;
        }

        public void SetResultados(System.Collections.Generic.List<MYG_Addin.MYG_NavisIssue> items)
        {
            data = new System.ComponentModel.BindingList<MYG_Addin.MYG_NavisIssue>(
                items ?? new System.Collections.Generic.List<MYG_Addin.MYG_NavisIssue>());
            grid.DataSource = data;
            RefrescarSeguimiento();
        }

        public void RefrescarSeguimiento()
        {
            if (IsDisposed) return;
            int total = data.Count;
            int ok = System.Linq.Enumerable.Count(data, x => x.EstadoMYG == "LEVANTADO EN REVIT");
            int pendientes = System.Linq.Enumerable.Count(data, x => x.EstadoMYG == "PERSISTE");
            int justificados = System.Linq.Enumerable.Count(data, x => x.EstadoMYG == "JUSTIFICADO");
            int revisar = System.Linq.Enumerable.Count(data, x => x.EstadoMYG == "INDETERMINADO" ||
                x.EstadoMYG == "NO LOCALIZADO" || x.EstadoMYG == "REVISAR ID");
            int noVerificados = total - ok - pendientes - justificados - revisar;
            resumenAvance = "TOTAL " + total + " | LEVANTADOS REVIT " + ok +
                " | PERSISTEN " + pendientes + " | JUSTIFICADOS " + justificados +
                " | REVISAR " + revisar + " | SIN VERIFICAR " + noVerificados;
            grid.Refresh();
            PintarFilas();
            MostrarDetalle();
            if (status != null) status.Text = resumenAvance;
        }

        public void SetEstado(string msg)
        {
            if (!IsDisposed) status.Text = resumenAvance + "  |  " + msg;
        }

        private void MostrarDetalle()
        {
            if (detail == null) return;
            var x = SeleccionActual;
            if (x == null) { detail.Clear(); return; }
            detail.Text = "PRUEBA: " + x.TestName + "\r\nCONFLICTO: " + x.ClashName +
                "\r\n\r\nMODELO RESPONSABLE:\r\n" + x.TargetModel +
                "\r\nELEMENTO NATIVO:\r\n" + x.NativeName +
                "\r\nID REVIT: " + x.NativeIdText +
                "\r\nUNIQUE ID: " + x.NativeUniqueId +
                "\r\n\r\nMODELO CONTRAPARTE:\r\n" + x.LinkModel +
                "\r\nELEMENTO 2:\r\n" + x.CounterpartName +
                "\r\nID REVIT: " + x.CounterpartIdText +
                "\r\nUNIQUE ID: " + x.CounterpartUniqueId +
                "\r\n\r\nRESULTADO DE LOCALIZACIÓN: " + x.Resultado +
                "\r\nESTADO MYG: " + x.EstadoMYG +
                "\r\nÚLTIMA VERIFICACIÓN: " + x.VerificadoEn +
                "\r\nVOLUMEN COMÚN (cm³): " + x.VolumenComun +
                "\r\nOBSERVACIÓN: " + x.ObservacionMYG +
                "\r\n\r\nINSTRUCCIÓN:\r\n" + x.Instruction;
        }

        private void PintarFilas()
        {
            foreach (System.Windows.Forms.DataGridViewRow row in grid.Rows)
            {
                var x = row.DataBoundItem as MYG_Addin.MYG_NavisIssue;
                if (x == null) continue;
                row.DefaultCellStyle.BackColor = x.EstadoMYG == "LEVANTADO EN REVIT"
                    ? System.Drawing.Color.FromArgb(210, 247, 218)
                    : x.EstadoMYG == "PERSISTE"
                    ? System.Drawing.Color.FromArgb(255, 233, 203)
                    : x.EstadoMYG == "JUSTIFICADO"
                    ? System.Drawing.Color.FromArgb(222, 236, 255)
                    : x.EstadoMYG == "INDETERMINADO" || x.EstadoMYG == "NO LOCALIZADO"
                    ? System.Drawing.Color.MistyRose
                    : x.NativeId <= 0 ? System.Drawing.Color.MistyRose
                    : x.LinkInstanceId > 0 ? System.Drawing.Color.FromArgb(230, 246, 233)
                    : System.Drawing.Color.FromArgb(255, 248, 226);
            }
        }

        private static string Csv(string s)
        {
            return "\"" + (s ?? "").Replace("\"", "\"\"") + "\"";
        }

        private void ExportarAvance()
        {
            if (data.Count == 0) return;
            using (var dlg = new System.Windows.Forms.SaveFileDialog())
            {
                dlg.Filter = "CSV para Excel (*.csv)|*.csv";
                dlg.FileName = "MYG_NAVIS_REVIT_AVANCE.csv";
                if (dlg.ShowDialog(this) != System.Windows.Forms.DialogResult.OK) return;
                var b = new System.Text.StringBuilder();
                b.AppendLine("Prueba;Conflicto;Modelo responsable;ID nativo;Modelo contraparte;ID vinculo;Resultado;Estado MYG;Fecha;Volumen comun cm3;Observacion MYG;Instruccion");
                foreach (var x in data)
                    b.AppendLine(string.Join(";", new[] {
                    Csv(x.TestName), Csv(x.ClashName), Csv(x.TargetModel),
                    Csv(x.NativeIdText), Csv(x.LinkModel), Csv(x.CounterpartIdText),
                    Csv(x.Resultado), Csv(x.EstadoMYG), Csv(x.VerificadoEn),
                    Csv(x.VolumenComun), Csv(x.ObservacionMYG), Csv(x.Instruction)
                }));
                System.IO.File.WriteAllText(dlg.FileName, b.ToString(),
                    new System.Text.UTF8Encoding(true));
                SetEstado("CSV de avance guardado: " + dlg.FileName);
            }
        }

        // ===========================================
        // CONTROL DE RVT DEL FEDERADO / NAVIS JSON
        // ===========================================
        public void SetModelos(System.Collections.Generic.List<MYG_Addin.MYG_NavisRvtStatus> items)
        {
            modelos.Clear();
            if (items != null) modelos.AddRange(items);
            if (btnModelos != null)
                btnModelos.Text = "MODELOS RVT (" + modelos.Count + ")";
            ActualizarListaModelos();
        }

        private void AbrirControlModelos()
        {
            if (ventanaModelos != null && !ventanaModelos.IsDisposed)
            {
                ventanaModelos.Show();
                ventanaModelos.BringToFront();
                ventanaModelos.Activate();
                return;
            }
            ventanaModelos = new System.Windows.Forms.Form();
            ventanaModelos.Text = "MYG | Control de modelos RVT involucrados";
            ventanaModelos.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            ventanaModelos.Size = new System.Drawing.Size(1090, 620);
            ventanaModelos.MinimumSize = new System.Drawing.Size(780, 420);
            ventanaModelos.Font = new System.Drawing.Font("Segoe UI", 9F);

            var table = new System.Windows.Forms.TableLayoutPanel();
            table.Dock = System.Windows.Forms.DockStyle.Fill;
            table.RowCount = 3;
            table.ColumnCount = 1;
            table.Padding = new System.Windows.Forms.Padding(12);
            table.RowStyles.Add(new System.Windows.Forms.RowStyle(
                System.Windows.Forms.SizeType.Absolute, 50));
            table.RowStyles.Add(new System.Windows.Forms.RowStyle(
                System.Windows.Forms.SizeType.Percent, 100));
            table.RowStyles.Add(new System.Windows.Forms.RowStyle(
                System.Windows.Forms.SizeType.Absolute, 60));
            ventanaModelos.Controls.Add(table);

            resumenModelos = new System.Windows.Forms.Label();
            resumenModelos.Dock = System.Windows.Forms.DockStyle.Fill;
            resumenModelos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            resumenModelos.Font = new System.Drawing.Font("Segoe UI", 10F,
                System.Drawing.FontStyle.Bold);
            table.Controls.Add(resumenModelos, 0, 0);

            listadoModelos = new System.Windows.Forms.ListView();
            listadoModelos.Dock = System.Windows.Forms.DockStyle.Fill;
            listadoModelos.View = System.Windows.Forms.View.Details;
            listadoModelos.FullRowSelect = true;
            listadoModelos.GridLines = true;
            listadoModelos.HideSelection = false;
            listadoModelos.Columns.Add("RVT requerido", 385);
            listadoModelos.Columns.Add("Papel en interferencias", 155);
            listadoModelos.Columns.Add("Conflictos", 75);
            listadoModelos.Columns.Add("Estado en Revit", 195);
            listadoModelos.Columns.Add("Instancias", 80);
            listadoModelos.Columns.Add("Acción", 145);
            table.Controls.Add(listadoModelos, 0, 1);

            var barra = new System.Windows.Forms.FlowLayoutPanel();
            barra.Dock = System.Windows.Forms.DockStyle.Fill;
            barra.WrapContents = true;
            barra.Controls.Add(CrearBoton("ACTUALIZAR ESTADO", 155,
                (s, e) => Raise(MYG_Addin.MYG_NavisworksRequest.ActualizarVinculos)));
            var botonVincular = CrearBoton("CARGAR / VINCULAR RVT", 178,
                (s, e) => CargarVinculoSeleccionado());
            barra.Controls.Add(botonVincular);
            barra.Controls.Add(CrearBoton("GESTIONAR VÍNCULOS", 160,
                (s, e) =>
                {
                    // Evita que este cuadro flotante tape Gestionar vínculos de Revit.
                    ventanaModelos.Hide();
                    Raise(MYG_Addin.MYG_NavisworksRequest.GestionarVinculos);
                }));
            barra.Controls.Add(CrearBoton("COPIAR LISTA RVT", 142,
                (s, e) => CopiarListaModelos()));
            barra.Controls.Add(CrearBoton("CERRAR", 90,
                (s, e) => ventanaModelos.Close()));
            table.Controls.Add(barra, 0, 2);

            var tip = new System.Windows.Forms.ToolTip();
            tip.SetToolTip(barra.Controls[0],
                "Después de cargar/revincular RVT en Revit, vuelve a comprobar la lista y los conflictos.");
            tip.SetToolTip(botonVincular,
                "Selecciona origen LOCAL o AUTODESK DOCS. Los vínculos existentes se recargan sin duplicar.");
            tip.SetToolTip(barra.Controls[2],
                "Abre la ventana nativa de Revit. Usa esta opción para vincular modelos de Autodesk Docs / ACC.");
            ActualizarListaModelos();
            ventanaModelos.Show(this);
        }

        private void ActualizarListaModelos()
        {
            if (listadoModelos == null || listadoModelos.IsDisposed) return;
            listadoModelos.BeginUpdate();
            try
            {
                listadoModelos.Items.Clear();
                foreach (MYG_Addin.MYG_NavisRvtStatus item in modelos)
                {
                    var fila = new System.Windows.Forms.ListViewItem(item.Modelo);
                    fila.SubItems.Add(item.Papel);
                    fila.SubItems.Add(item.Conflictos.ToString());
                    fila.SubItems.Add(item.Estado);
                    fila.SubItems.Add(item.Instancias.ToString());
                    fila.SubItems.Add(item.Accion);
                    fila.Tag = item.Clave;
                    if (item.Estado == "RVT ACTIVO" || item.Estado == "CARGADO")
                        fila.BackColor = System.Drawing.Color.FromArgb(223, 245, 229);
                    else if (item.Estado == "NO VINCULADO")
                        fila.BackColor = System.Drawing.Color.FromArgb(255, 230, 230);
                    else
                        fila.BackColor = System.Drawing.Color.FromArgb(255, 248, 215);
                    listadoModelos.Items.Add(fila);
                }
                if (resumenModelos != null)
                {
                    int cargados = modelos.FindAll(m =>
                        m.Estado == "CARGADO" || m.Estado == "RVT ACTIVO").Count;
                    resumenModelos.Text = "RVT DETECTADOS: " + modelos.Count +
                        "     LISTOS: " + cargados +
                        "     PENDIENTES: " + (modelos.Count - cargados) +
                        "     |     Nombres deducidos del JSON; verificar archivo origen";
                }
            }
            finally { listadoModelos.EndUpdate(); }
        }

        // ============================================
        // VINCULAR EL RVT SELECCIONADO (LOCAL / AUTODESK DOCS)
        // ============================================
        private static string ClaveNombreRvt(string valor)
        {
            string nombre = (valor ?? "").Trim().Replace('\\', '/');
            int slash = nombre.LastIndexOf('/');
            if (slash >= 0) nombre = nombre.Substring(slash + 1);
            int dosPuntos = nombre.IndexOf(" : ", System.StringComparison.Ordinal);
            if (dosPuntos >= 0) nombre = nombre.Substring(0, dosPuntos);
            foreach (string etiqueta in new[] { " - NAVISWORKS", " - NAVIWORKS", " - 3D NAVIS" })
                if (nombre.EndsWith(etiqueta, System.StringComparison.OrdinalIgnoreCase))
                    nombre = nombre.Substring(0, nombre.Length - etiqueta.Length);
            foreach (string ext in new[] { ".rvt", ".nwc", ".nwd", ".nwf" })
                if (nombre.EndsWith(ext, System.StringComparison.OrdinalIgnoreCase))
                {
                    nombre = nombre.Substring(0, nombre.Length - ext.Length);
                    break;
                }
            return nombre.Trim().ToUpperInvariant();
        }

        // Solicita SOLO los datos que no están en el JSON de Navisworks.
        // No inventar GUID a partir del nombre: dos proyectos pueden compartir nombre RVT.
        private bool SolicitarDatosNube(string modelo)
        {
            using (var dlg = new System.Windows.Forms.Form())
            {
                dlg.Text = "MYG | Vincular desde Autodesk Docs por GUID";
                dlg.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
                dlg.ClientSize = new System.Drawing.Size(690, 330);
                dlg.MinimumSize = new System.Drawing.Size(630, 330);
                dlg.Font = new System.Drawing.Font("Segoe UI", 9F);
                dlg.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
                dlg.MinimizeBox = false;
                dlg.MaximizeBox = false;

                var table = new System.Windows.Forms.TableLayoutPanel();
                table.Dock = System.Windows.Forms.DockStyle.Fill;
                table.Padding = new System.Windows.Forms.Padding(15);
                table.ColumnCount = 2;
                table.RowCount = 6;
                table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(
                    System.Windows.Forms.SizeType.Absolute, 135));
                table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(
                    System.Windows.Forms.SizeType.Percent, 100));
                table.RowStyles.Add(new System.Windows.Forms.RowStyle(
                    System.Windows.Forms.SizeType.Absolute, 64));
                table.RowStyles.Add(new System.Windows.Forms.RowStyle(
                    System.Windows.Forms.SizeType.Absolute, 36));
                table.RowStyles.Add(new System.Windows.Forms.RowStyle(
                    System.Windows.Forms.SizeType.Absolute, 36));
                table.RowStyles.Add(new System.Windows.Forms.RowStyle(
                    System.Windows.Forms.SizeType.Absolute, 36));
                table.RowStyles.Add(new System.Windows.Forms.RowStyle(
                    System.Windows.Forms.SizeType.Percent, 100));
                table.RowStyles.Add(new System.Windows.Forms.RowStyle(
                    System.Windows.Forms.SizeType.Absolute, 43));
                dlg.Controls.Add(table);

                var title = new System.Windows.Forms.Label();
                title.Dock = System.Windows.Forms.DockStyle.Fill;
                title.Text = "MODELO ESPERADO: " + modelo + "\r\n" +
                    "La región y los GUID deben provenir de Autodesk Docs/APS; NO se obtienen del JSON.";
                title.AutoEllipsis = true;
                table.Controls.Add(title, 0, 0);
                table.SetColumnSpan(title, 2);

                var region = new System.Windows.Forms.ComboBox();
                region.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown;
                region.Items.AddRange(new object[] { "US", "EMEA" });
                region.Text = "US";
                region.Dock = System.Windows.Forms.DockStyle.Fill;
                var proyecto = new System.Windows.Forms.TextBox();
                proyecto.Dock = System.Windows.Forms.DockStyle.Fill;
                var archivo = new System.Windows.Forms.TextBox();
                archivo.Dock = System.Windows.Forms.DockStyle.Fill;
                System.Windows.Forms.Control[] inputs = { region, proyecto, archivo };
                string[] titulos = { "Región", "Project GUID", "Model GUID" };
                for (int i = 0; i < inputs.Length; ++i)
                {
                    var lbl = new System.Windows.Forms.Label();
                    lbl.Text = titulos[i];
                    lbl.Dock = System.Windows.Forms.DockStyle.Fill;
                    lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
                    table.Controls.Add(lbl, 0, i + 1);
                    table.Controls.Add(inputs[i], 1, i + 1);
                }
                var nota = new System.Windows.Forms.Label();
                nota.Dock = System.Windows.Forms.DockStyle.Fill;
                nota.Text = "Este modo enlaza directamente un modelo cloud identificado por GUID. " +
                    "Confirma su identidad y que el RVT anfitrión también esté alojado en la nube.";
                table.Controls.Add(nota, 0, 4);
                table.SetColumnSpan(nota, 2);

                var barra = new System.Windows.Forms.FlowLayoutPanel();
                barra.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
                barra.Dock = System.Windows.Forms.DockStyle.Fill;
                var cancelar = CrearBoton("CANCELAR", 110, (s, e) =>
                { dlg.DialogResult = System.Windows.Forms.DialogResult.Cancel; });
                var aceptar = CrearBoton("VINCULAR POR GUID", 155, (s, e) =>
                {
                    System.Guid projectId;
                    System.Guid modelId;
                    string zona = (region.Text ?? "").Trim().ToUpperInvariant();
                    if (zona.Length == 0 ||
                        !System.Guid.TryParse(proyecto.Text.Trim(), out projectId) ||
                        !System.Guid.TryParse(archivo.Text.Trim(), out modelId) ||
                        projectId == System.Guid.Empty || modelId == System.Guid.Empty)
                    {
                        System.Windows.Forms.MessageBox.Show(dlg,
                            "Indica región, Project GUID y Model GUID válidos y no vacíos.",
                            "MYG NAVIS - Datos cloud", System.Windows.Forms.MessageBoxButtons.OK,
                            System.Windows.Forms.MessageBoxIcon.Warning);
                        return;
                    }
                    var ok = System.Windows.Forms.MessageBox.Show(dlg,
                        "¿Confirmas que este Model GUID corresponde a " + modelo + "?\r\n" +
                        "Región: " + zona + "\r\nProject GUID: " + projectId +
                        "\r\nModel GUID: " + modelId,
                        "MYG NAVIS - Confirmar modelo Autodesk Docs",
                        System.Windows.Forms.MessageBoxButtons.YesNo,
                        System.Windows.Forms.MessageBoxIcon.Question);
                    if (ok != System.Windows.Forms.DialogResult.Yes) return;
                    RegionNube = zona;
                    ProyectoGuidNube = projectId.ToString();
                    ModeloGuidNube = modelId.ToString();
                    dlg.DialogResult = System.Windows.Forms.DialogResult.OK;
                });
                barra.Controls.Add(cancelar);
                barra.Controls.Add(aceptar);
                table.Controls.Add(barra, 0, 5);
                table.SetColumnSpan(barra, 2);
                dlg.AcceptButton = aceptar;
                dlg.CancelButton = cancelar;
                return dlg.ShowDialog(ventanaModelos ?? this) ==
                    System.Windows.Forms.DialogResult.OK;
            }
        }

        // El selector nativo Revit permite explorar Autodesk Docs sin disponer de GUID.
        // PostCommand se llama DESDE ExternalEvent y NO desde este método.
        public void PrepararSelectorRvtNativo()
        {
            if (ventanaModelos != null && !ventanaModelos.IsDisposed)
                ventanaModelos.Hide();
            SetEstado("Selecciona en Revit el modelo Autodesk Docs: " + ModeloParaVincular +
                ". Al finalizar, pulsa MODELOS RVT > ACTUALIZAR ESTADO.");
        }

        private void CargarVinculoSeleccionado()
        {
            if (pending)
            {
                System.Windows.Forms.MessageBox.Show(ventanaModelos,
                    "Espera a que termine la operación anterior de Revit.", "MYG NAVIS");
                return;
            }
            if (listadoModelos == null || listadoModelos.SelectedItems.Count != 1)
            {
                System.Windows.Forms.MessageBox.Show(ventanaModelos,
                    "Selecciona una fila del RVT que deseas cargar.", "MYG NAVIS");
                return;
            }
            string clave = listadoModelos.SelectedItems[0].Tag as string;
            var model = modelos.Find(m => m.Clave == clave);
            if (model == null) return;
            if (model.Estado == "RVT ACTIVO" || model.Estado == "CARGADO")
            {
                System.Windows.Forms.MessageBox.Show(ventanaModelos,
                    "El modelo ya está listo. No se creará otro vínculo: " + model.Modelo,
                    "MYG NAVIS");
                return;
            }
            if (model.Estado == "VARIAS INSTANCIAS")
            {
                System.Windows.Forms.MessageBox.Show(ventanaModelos,
                    "Hay varias instancias del modelo. Revisa la colocación; no se agregará otra.",
                    "MYG NAVIS");
                return;
            }
            if (model.Estado != "NO VINCULADO" &&
                model.Estado != "NO CARGADO / SIN INSTANCIA")
            {
                System.Windows.Forms.MessageBox.Show(ventanaModelos,
                    "Actualiza la lista antes de intentar vincular el modelo.", "MYG NAVIS");
                return;
            }

            ModeloParaVincular = model.Modelo;
            RutaRvtParaVincular = "";
            VincularDesdeNube = false;
            RegionNube = ProyectoGuidNube = ModeloGuidNube = "";

            if (model.Estado == "NO VINCULADO")
            {
                var origen = System.Windows.Forms.MessageBox.Show(ventanaModelos,
                    "RVT requerido: " + model.Modelo + "\r\n\r\n" +
                    "SÍ: Autodesk Docs / Forma (nube).\r\n" +
                    "NO: Archivo RVT local.\r\n" +
                    "CANCELAR: No cargar.", "MYG NAVIS - Origen del vínculo",
                    System.Windows.Forms.MessageBoxButtons.YesNoCancel,
                    System.Windows.Forms.MessageBoxIcon.Question);
                if (origen == System.Windows.Forms.DialogResult.Cancel) return;
                if (origen == System.Windows.Forms.DialogResult.Yes)
                {
                    var modoNube = System.Windows.Forms.MessageBox.Show(ventanaModelos,
                        "Vincular desde Autodesk Docs / Forma\r\n\r\n" +
                        "SÍ: Abrir el selector nativo Vincular Revit (recomendado).\r\n" +
                        "NO: Vinculación directa por región + Project GUID + Model GUID.\r\n" +
                        "CANCELAR: Volver.\r\n\r\n" +
                        "El JSON por sí solo NO identifica el modelo cloud por GUID.",
                        "MYG NAVIS - Método de selección",
                        System.Windows.Forms.MessageBoxButtons.YesNoCancel,
                        System.Windows.Forms.MessageBoxIcon.Question);
                    if (modoNube == System.Windows.Forms.DialogResult.Cancel) return;
                    if (modoNube == System.Windows.Forms.DialogResult.Yes)
                    {
                        Raise(MYG_Addin.MYG_NavisworksRequest.AbrirSelectorRvt);
                        return;
                    }
                    if (!SolicitarDatosNube(model.Modelo)) return;
                    VincularDesdeNube = true;
                }
                else
                {
                    using (var dialogo = new System.Windows.Forms.OpenFileDialog())
                    {
                        dialogo.Title = "Selecciona el RVT local: " + model.Modelo;
                        dialogo.Filter = "Modelos Revit (*.rvt)|*.rvt";
                        dialogo.CheckFileExists = true;
                        dialogo.Multiselect = false;
                        if (dialogo.ShowDialog(ventanaModelos) !=
                            System.Windows.Forms.DialogResult.OK) return;
                        RutaRvtParaVincular = dialogo.FileName;
                    }
                    if (ClaveNombreRvt(System.IO.Path.GetFileName(RutaRvtParaVincular))
                        != model.Clave)
                    {
                        System.Windows.Forms.MessageBox.Show(ventanaModelos,
                            "El archivo no coincide con el RVT solicitado por el JSON.\r\n" +
                            "Esperado: " + model.Modelo + "\r\nElegido: " +
                            System.IO.Path.GetFileName(RutaRvtParaVincular),
                            "MYG NAVIS - Modelo diferente");
                        return;
                    }
                }
            }
            // Un RevitLinkType existente se recarga desde su ubicación guardada,
            // incluidas ubicaciones cloud. No se duplica ni pide GUID otra vez.

            var colocacion = System.Windows.Forms.MessageBox.Show(ventanaModelos,
                "Modelo: " + model.Modelo + "\r\n\r\n" +
                "¿Colocación para una instancia nueva?\r\n" +
                "SÍ = Coordenadas compartidas.\r\n" +
                "NO = Origen a origen.\r\n" +
                "CANCELAR = No modificar Revit.\r\n\r\n" +
                "Verifica la alineación en 3D después de vincular.",
                "MYG NAVIS - Posicionamiento",
                System.Windows.Forms.MessageBoxButtons.YesNoCancel,
                System.Windows.Forms.MessageBoxIcon.Question);
            if (colocacion == System.Windows.Forms.DialogResult.Cancel) return;
            UsarCoordenadasCompartidas =
                colocacion == System.Windows.Forms.DialogResult.Yes;
            Raise(MYG_Addin.MYG_NavisworksRequest.VincularRvt);
        }

        private void CopiarListaModelos()
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("RVT requerido\tPapel\tConflictos\tEstado\tInstancias\tAcción");
            foreach (var m in modelos)
                sb.AppendLine(string.Join("\t", new[] {
                m.Modelo, m.Papel, m.Conflictos.ToString(), m.Estado,
                m.Instancias.ToString(), m.Accion }));
            try
            {
                System.Windows.Forms.Clipboard.SetText(sb.ToString());
                SetEstado("Lista de RVT copiada al portapapeles.");
            }
            catch (System.Exception e)
            {
                SetEstado("No se pudo copiar: " + e.Message);
            }
        }

    }

}
