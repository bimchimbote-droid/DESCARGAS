﻿//---------------------------------------------------------
// PANEL 2 - BOTON 2.5 (COMPROBACIÓN DE INTERFERENCIAS)
// HANDLER EXTERNO - OPTIMIZADO SIN VOLUMEN
//---------------------------------------------------------

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using MYG_Addin;
using OfficeOpenXml;
using OfficeOpenXml.Drawing;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Globalization;
using System.Linq;
using System.Security;
using System.Text;
using Forms = System.Windows.Forms;
using SD = System.Drawing;

public enum MYG_InterferenciasRequest
{
    None,
    Detectar,
    Aislar,
    Restaurar,
    Seleccionar,
    GrabarDatos,
    CargarData,
    ExportarRfiExcel
}

public class MYG_InterferenciasHandler : IExternalEventHandler
{
    public UIDocument UiDoc { get; set; }
    public MYG_InterferenciasForm Form { get; set; }
    public MYG_InterferenciasRequest Request { get; set; }

    private const string DataHeader = "#MYG_INTERFERENCIAS_DATA_V1";

    public string GetName()
    {
        return "MYG - Handler de comprobación de interferencias";
    }

    public void Execute(UIApplication app)
    {
        try
        {
            if (UiDoc == null)
                UiDoc = app.ActiveUIDocument;

            if (UiDoc == null || UiDoc.Document == null || Form == null)
                return;

            switch (Request)
            {
                case MYG_InterferenciasRequest.Detectar:
                    EjecutarDeteccion();
                    break;

                case MYG_InterferenciasRequest.Aislar:
                    AislarSeleccion();
                    break;

                case MYG_InterferenciasRequest.Restaurar:
                    RestaurarVista();
                    break;

                case MYG_InterferenciasRequest.Seleccionar:
                    SeleccionarElementos();
                    break;

                case MYG_InterferenciasRequest.GrabarDatos:
                    GrabarDatos();
                    break;

                case MYG_InterferenciasRequest.CargarData:
                    CargarData();
                    break;

                case MYG_InterferenciasRequest.ExportarRfiExcel:
                    ExportarRfiExcel();
                    break;
            }
        }
        catch (Exception ex)
        {
            if (Form != null)
                Form.SetEstado("Error: " + ex.Message);

            Forms.MessageBox.Show(
                ex.ToString(),
                "MYG - Error",
                Forms.MessageBoxButtons.OK,
                Forms.MessageBoxIcon.Error);
        }
        finally
        {
            Request = MYG_InterferenciasRequest.None;
        }
    }

    // =====================================================
    // OBTENER CATEGORÍAS CON ELEMENTOS
    // Solo muestra categorías realmente modeladas/colocadas en el proyecto.
    // =====================================================

    public static List<CategoriaItem> ObtenerCategoriasConElementos(Document doc)
    {
        Dictionary<long, CategoriaItem> dict = new Dictionary<long, CategoriaItem>();

        FilteredElementCollector collector =
            new FilteredElementCollector(doc)
            .WhereElementIsNotElementType();

        foreach (Element e in collector)
        {
            if (!ElementoValidoParaListaDeCategorias(e))
                continue;

            long idCatLong;

            try
            {
                idCatLong = e.Category.Id.Value;
            }
            catch
            {
                continue;
            }

            BuiltInCategory bic;

            try
            {
                bic = (BuiltInCategory)System.Enum.ToObject(
                    typeof(BuiltInCategory),
                    idCatLong);
            }
            catch
            {
                continue;
            }

            try
            {
                if (!System.Enum.IsDefined(typeof(BuiltInCategory), bic))
                    continue;
            }
            catch
            {
                continue;
            }

            if (!dict.ContainsKey(idCatLong))
            {
                dict.Add(idCatLong, new CategoriaItem
                {
                    Nombre = e.Category.Name,
                    Bic = bic
                });
            }
        }

        return dict.Values
            .OrderBy(x => x.Nombre)
            .ToList();
    }

    private static bool ElementoValidoParaListaDeCategorias(Element e)
    {
        if (e == null)
            return false;

        if (e.Category == null)
            return false;

        if (e.Category.CategoryType != CategoryType.Model)
            return false;

        if (!CategoriaPermitidaParaLista(e.Category))
            return false;

        try
        {
            if (e is View)
                return false;

            if (e is Material)
                return false;

            if (e is Level)
                return false;

            if (e is Grid)
                return false;
        }
        catch
        {
        }

        try
        {
            BoundingBoxXYZ bb = e.get_BoundingBox(null);

            if (bb == null)
                return false;
        }
        catch
        {
            return false;
        }

        return true;
    }

    private static bool CategoriaPermitidaParaLista(Category cat)
    {
        if (cat == null)
            return false;

        string nombre = cat.Name;

        if (string.IsNullOrWhiteSpace(nombre))
            return false;

        nombre = nombre.Trim();

        if (nombre.StartsWith("<") || nombre.EndsWith(">"))
            return false;

        if (nombre.IndexOf("Boceto", StringComparison.OrdinalIgnoreCase) >= 0)
            return false;

        string normal = NormalizarNombreCategoria(nombre);

        string[] excluir = new string[]
        {
            "ACTIVOS DE MATERIALES",
            "MATERIALES",
            "MATERIALS",
            "INFORMACION DE PROYECTO",
            "PROJECT INFORMATION",
            "COMPONENTES DE LEYENDA",
            "LEGEND COMPONENTS",
            "LINEAS",
            "LINES",
            "LINEAS DE DETALLE",
            "DETAIL LINES",
            "ELEMENTOS DE DETALLE",
            "DETAIL ITEMS",
            "CURVAS DE NIVEL PRINCIPALES",
            "CURVAS DE NIVEL SECUNDARIAS",
            "CAMARAS",
            "CAMERAS",
            "ORIGEN INTERNO",
            "INTERNAL ORIGIN",
            "PUNTO BASE DEL PROYECTO",
            "PROJECT BASE POINT",
            "PUNTO DE RECONOCIMIENTO",
            "SURVEY POINT",
            "PLANOS DE REFERENCIA",
            "REFERENCE PLANES",
            "REJILLAS",
            "GRIDS",
            "NIVELES",
            "LEVELS",
            "SEGMENTOS DE TUBERIA",
            "PIPE SEGMENTS"
        };

        foreach (string item in excluir)
        {
            if (normal.Equals(item, StringComparison.OrdinalIgnoreCase))
                return false;
        }

        return true;
    }

    private static string NormalizarNombreCategoria(string texto)
    {
        if (string.IsNullOrWhiteSpace(texto))
            return "";

        string formD = texto.Normalize(NormalizationForm.FormD);
        StringBuilder sb = new StringBuilder();

        foreach (char ch in formD)
        {
            UnicodeCategory cat = CharUnicodeInfo.GetUnicodeCategory(ch);

            if (cat != UnicodeCategory.NonSpacingMark)
                sb.Append(ch);
        }

        return sb.ToString()
            .Normalize(NormalizationForm.FormC)
            .Trim()
            .ToUpperInvariant();
    }

    // =====================================================
    // DETECTAR INTERFERENCIAS
    // =====================================================

    private void EjecutarDeteccion()
    {
        if (Form.DataCargada)
        {
            EvaluarDataCargada();
            return;
        }

        Document doc = UiDoc.Document;
        View vista = UiDoc.ActiveView;

        List<CategoriaItem> categoriasA = Form.CategoriasASeleccionadas;
        List<CategoriaItem> categoriasB = Form.CategoriasBSeleccionadas;

        if (categoriasA == null || categoriasA.Count == 0 ||
            categoriasB == null || categoriasB.Count == 0)
        {
            Forms.MessageBox.Show(
                "Selecciona al menos una categoría en A y una categoría en B.",
                "MYG",
                Forms.MessageBoxButtons.OK,
                Forms.MessageBoxIcon.Warning);

            return;
        }

        bool soloVista = Form.SoloVistaActiva;
        double precisionCm = Form.PrecisionCm;

        Form.SetEstado("Preparando detección optimizada...");

        List<Element> elementosA = new List<Element>();
        HashSet<long> idsAAgregados = new HashSet<long>();

        foreach (CategoriaItem catA in categoriasA)
        {
            if (catA == null)
                continue;

            List<Element> elementosCategoria =
                ObtenerElementosPorCategoria(doc, vista, catA.Bic, soloVista);

            foreach (Element e in elementosCategoria)
            {
                if (e == null)
                    continue;

                if (idsAAgregados.Contains(e.Id.Value))
                    continue;

                idsAAgregados.Add(e.Id.Value);
                elementosA.Add(e);
            }
        }

        if (elementosA.Count == 0)
        {
            Form.SetResultados(new List<ClashInfo>());
            Form.SetEstado("No se encontraron elementos en las categorías A seleccionadas.");
            return;
        }

        ElementFilter filtroCategoriasB = CrearFiltroCategorias(categoriasB);

        if (filtroCategoriasB == null)
        {
            Form.SetResultados(new List<ClashInfo>());
            Form.SetEstado("No se pudo crear el filtro de categorías B.");
            return;
        }

        List<ClashInfo> resultados = new List<ClashInfo>();
        HashSet<string> paresProcesados = new HashSet<string>();

        int procesados = 0;

        foreach (Element elemA in elementosA)
        {
            procesados++;

            if (procesados % 25 == 0)
            {
                Form.SetEstado(
                    "Revisando elemento " +
                    procesados +
                    " de " +
                    elementosA.Count +
                    "...");
            }

            if (elemA == null)
                continue;

            BoundingBoxXYZ bbA = null;

            try
            {
                bbA = elemA.get_BoundingBox(null);
            }
            catch
            {
                bbA = null;
            }

            if (bbA == null)
                continue;

            ElementIntersectsElementFilter filtroInterseccion;

            try
            {
                filtroInterseccion = new ElementIntersectsElementFilter(elemA);
            }
            catch
            {
                continue;
            }

            BoundingBoxIntersectsFilter filtroCaja = null;

            try
            {
                filtroCaja = new BoundingBoxIntersectsFilter(CrearOutlineExpandido(bbA, 0.01));
            }
            catch
            {
                filtroCaja = null;
            }

            ElementFilter filtroFinal;

            if (filtroCaja != null)
            {
                LogicalAndFilter filtroCategoriaYCaja =
                    new LogicalAndFilter(filtroCategoriasB, filtroCaja);

                filtroFinal =
                    new LogicalAndFilter(filtroCategoriaYCaja, filtroInterseccion);
            }
            else
            {
                LogicalAndFilter filtroCategoriaEInterseccion =
                    new LogicalAndFilter(filtroCategoriasB, filtroInterseccion);

                filtroFinal = filtroCategoriaEInterseccion;
            }

            FilteredElementCollector collectorB =
                soloVista
                    ? new FilteredElementCollector(doc, vista.Id)
                    : new FilteredElementCollector(doc);

            List<ElementId> idsB;

            try
            {
                idsB = collectorB
                    .WhereElementIsNotElementType()
                    .WherePasses(filtroFinal)
                    .ToElementIds()
                    .ToList();
            }
            catch
            {
                continue;
            }

            foreach (ElementId idB in idsB)
            {
                if (idB == null)
                    continue;

                if (idB.Value == elemA.Id.Value)
                    continue;

                long idMenor = Math.Min(elemA.Id.Value, idB.Value);
                long idMayor = Math.Max(elemA.Id.Value, idB.Value);

                string keyPar = idMenor + "-" + idMayor;

                if (paresProcesados.Contains(keyPar))
                    continue;

                paresProcesados.Add(keyPar);

                Element elemB = doc.GetElement(idB);

                if (elemB == null)
                    continue;

                if (precisionCm > 0.0)
                {
                    double dimensionMinimaCm =
                        ObtenerDimensionMinimaInterseccionBoundingBoxCm(elemA, elemB);

                    if (dimensionMinimaCm < precisionCm)
                        continue;
                }

                ClashInfo info = new ClashInfo
                {
                    Numero = resultados.Count + 1,

                    IdA = elemA.Id,
                    IdB = elemB.Id,

                    CategoriaA = ObtenerNombreCategoria(elemA),
                    CategoriaB = ObtenerNombreCategoria(elemB),

                    NombreA = ObtenerNombreElemento(doc, elemA),
                    NombreB = ObtenerNombreElemento(doc, elemB),

                    Levantado = false
                };

                resultados.Add(info);
            }
        }

        Form.SetResultados(resultados);
        Form.SetDataCargada(false, "");
        Form.SetEstado("Interferencias encontradas: " + resultados.Count);
    }

    private ElementFilter CrearFiltroCategorias(List<CategoriaItem> categorias)
    {
        if (categorias == null || categorias.Count == 0)
            return null;

        List<ElementFilter> filtros = new List<ElementFilter>();

        foreach (CategoriaItem cat in categorias)
        {
            if (cat == null)
                continue;

            try
            {
                filtros.Add(new ElementCategoryFilter(cat.Bic));
            }
            catch
            {
            }
        }

        if (filtros.Count == 0)
            return null;

        if (filtros.Count == 1)
            return filtros[0];

        return new LogicalOrFilter(filtros);
    }

    private Outline CrearOutlineExpandido(BoundingBoxXYZ bb, double margenFt)
    {
        XYZ min = new XYZ(
            bb.Min.X - margenFt,
            bb.Min.Y - margenFt,
            bb.Min.Z - margenFt);

        XYZ max = new XYZ(
            bb.Max.X + margenFt,
            bb.Max.Y + margenFt,
            bb.Max.Z + margenFt);

        return new Outline(min, max);
    }

    private double ObtenerDimensionMinimaInterseccionBoundingBoxCm(
        Element elemA,
        Element elemB)
    {
        if (elemA == null || elemB == null)
            return 0.0;

        BoundingBoxXYZ bbA = null;
        BoundingBoxXYZ bbB = null;

        try
        {
            bbA = elemA.get_BoundingBox(null);
            bbB = elemB.get_BoundingBox(null);
        }
        catch
        {
            return 0.0;
        }

        if (bbA == null || bbB == null)
            return 0.0;

        double dxFt = Math.Min(bbA.Max.X, bbB.Max.X) - Math.Max(bbA.Min.X, bbB.Min.X);
        double dyFt = Math.Min(bbA.Max.Y, bbB.Max.Y) - Math.Max(bbA.Min.Y, bbB.Min.Y);
        double dzFt = Math.Min(bbA.Max.Z, bbB.Max.Z) - Math.Max(bbA.Min.Z, bbB.Min.Z);

        if (dxFt <= 0.0 || dyFt <= 0.0 || dzFt <= 0.0)
            return 0.0;

        double minFt = Math.Min(dxFt, Math.Min(dyFt, dzFt));
        return minFt * 30.48;
    }

    private void EvaluarDataCargada()
    {
        Document doc = UiDoc.Document;

        List<ClashInfo> data = Form.GetTodasLasInterferencias();

        if (data == null || data.Count == 0)
        {
            Forms.MessageBox.Show(
                "No hay data cargada para evaluar.",
                "MYG",
                Forms.MessageBoxButtons.OK,
                Forms.MessageBoxIcon.Information);

            return;
        }

        List<ClashInfo> evaluados = new List<ClashInfo>();

        int levantados = 0;
        int pendientes = 0;
        int inexistentes = 0;

        double precisionCm = Form.PrecisionCm;

        for (int i = 0; i < data.Count; i++)
        {
            ClashInfo item = data[i];

            if (item == null)
                continue;

            Form.SetEstado(
                "Evaluando par guardado " +
                (i + 1) +
                " de " +
                data.Count +
                "...");

            Element elemA = null;
            Element elemB = null;

            try
            {
                elemA = doc.GetElement(item.IdA);
            }
            catch
            {
                elemA = null;
            }

            try
            {
                elemB = doc.GetElement(item.IdB);
            }
            catch
            {
                elemB = null;
            }

            ClashInfo nuevo = new ClashInfo
            {
                Numero = i + 1,

                IdA = item.IdA,
                IdB = item.IdB,

                CategoriaA = item.CategoriaA,
                CategoriaB = item.CategoriaB,

                NombreA = item.NombreA,
                NombreB = item.NombreB,

                Levantado = false
            };

            if (elemA == null || elemB == null)
            {
                nuevo.Levantado = true;
                inexistentes++;

                if (elemA != null)
                {
                    nuevo.CategoriaA = ObtenerNombreCategoria(elemA);
                    nuevo.NombreA = ObtenerNombreElemento(doc, elemA);
                }

                if (elemB != null)
                {
                    nuevo.CategoriaB = ObtenerNombreCategoria(elemB);
                    nuevo.NombreB = ObtenerNombreElemento(doc, elemB);
                }

                evaluados.Add(nuevo);
                levantados++;
                continue;
            }

            nuevo.CategoriaA = ObtenerNombreCategoria(elemA);
            nuevo.CategoriaB = ObtenerNombreCategoria(elemB);
            nuevo.NombreA = ObtenerNombreElemento(doc, elemA);
            nuevo.NombreB = ObtenerNombreElemento(doc, elemB);

            bool sigueInterfiriendo =
                ElementosSiguenInterfiriendo(doc, elemA, elemB, precisionCm);

            nuevo.Levantado = !sigueInterfiriendo;

            if (sigueInterfiriendo)
            {
                pendientes++;

            }
            else
            {
                levantados++;
            }

            evaluados.Add(nuevo);
        }

        Form.SetResultados(evaluados);
        Form.SetDataCargada(true, Form.RutaDataCargada);

        Form.SetEstado(
            "Evaluación terminada. Levantadas: " +
            levantados +
            " | Pendientes: " +
            pendientes +
            " | Elementos eliminados/no encontrados: " +
            inexistentes);
    }

    private bool ElementosSiguenInterfiriendo(
        Document doc,
        Element elemA,
        Element elemB,
        double precisionCm)
    {
        if (doc == null || elemA == null || elemB == null)
            return false;

        if (precisionCm > 0.0)
        {
            double dimensionMinimaCm =
                ObtenerDimensionMinimaInterseccionBoundingBoxCm(elemA, elemB);

            if (dimensionMinimaCm < precisionCm)
                return false;
        }

        try
        {
            ElementIntersectsElementFilter filtro =
                new ElementIntersectsElementFilter(elemA);

            List<ElementId> ids =
                new FilteredElementCollector(doc)
                .WhereElementIsNotElementType()
                .WherePasses(filtro)
                .ToElementIds()
                .ToList();

            foreach (ElementId id in ids)
            {
                if (id != null && id.Value == elemB.Id.Value)
                    return true;
            }

            return false;
        }
        catch
        {
            return ObtenerDimensionMinimaInterseccionBoundingBoxCm(elemA, elemB) > 0.0;
        }
    }

    // =====================================================
    // OBTENER ELEMENTOS POR CATEGORÍA
    // =====================================================

    private static List<Element> ObtenerElementosPorCategoria(
        Document doc,
        View vista,
        BuiltInCategory bic,
        bool soloVista)
    {
        FilteredElementCollector collector =
            soloVista
                ? new FilteredElementCollector(doc, vista.Id)
                : new FilteredElementCollector(doc);

        ElementCategoryFilter filtroCategoria;

        try
        {
            filtroCategoria = new ElementCategoryFilter(bic);
        }
        catch
        {
            return new List<Element>();
        }

        List<Element> elementos = new List<Element>();

        try
        {
            elementos = collector
                .WhereElementIsNotElementType()
                .WherePasses(filtroCategoria)
                .ToElements()
                .Where(e => e != null)
                .Where(e => e.get_BoundingBox(null) != null)
                .ToList();
        }
        catch
        {
            elementos = new List<Element>();
        }

        return elementos;
    }

    // =====================================================
    // AISLAR ELEMENTOS
    // =====================================================

    private void AislarSeleccion()
    {
        ClashInfo info = Form.GetInterferenciaSeleccionada();

        if (info == null)
        {
            Forms.MessageBox.Show(
                "Selecciona una interferencia de la lista.",
                "MYG",
                Forms.MessageBoxButtons.OK,
                Forms.MessageBoxIcon.Information);

            return;
        }

        Document doc = UiDoc.Document;
        View vista = UiDoc.ActiveView;

        if (vista.TemporaryViewModes == null ||
            !vista.TemporaryViewModes.IsModeAvailable(TemporaryViewMode.TemporaryHideIsolate))
        {
            Forms.MessageBox.Show(
                "La vista activa no permite aislar elementos temporalmente.",
                "MYG",
                Forms.MessageBoxButtons.OK,
                Forms.MessageBoxIcon.Warning);

            return;
        }

        List<ElementId> ids = new List<ElementId>();
        ids.Add(info.IdA);
        ids.Add(info.IdB);

        using (Transaction t = new Transaction(doc, "MYG - Aislar interferencia"))
        {
            t.Start();

            if (vista.IsInTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate))
            {
                vista.DisableTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate);
            }

            vista.IsolateElementsTemporary(ids);

            t.Commit();
        }

        UiDoc.Selection.SetElementIds(ids);
        UiDoc.ShowElements(ids);
        UiDoc.RefreshActiveView();

        Form.SetEstado(
            "Elementos aislados: " +
            info.IdAValor +
            " y " +
            info.IdBValor);
    }

    // =====================================================
    // RESTAURAR VISTA
    // =====================================================

    private void RestaurarVista()
    {
        Document doc = UiDoc.Document;
        View vista = UiDoc.ActiveView;

        if (!vista.IsInTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate))
        {
            Form.SetEstado("La vista no tiene aislamiento temporal activo.");
            return;
        }

        using (Transaction t = new Transaction(doc, "MYG - Restaurar vista"))
        {
            t.Start();
            vista.DisableTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate);
            t.Commit();
        }

        UiDoc.RefreshActiveView();
        Form.SetEstado("Vista restaurada.");
    }

    // =====================================================
    // SELECCIONAR ELEMENTOS
    // =====================================================

    private void SeleccionarElementos()
    {
        ClashInfo info = Form.GetInterferenciaSeleccionada();

        if (info == null)
        {
            Forms.MessageBox.Show(
                "Selecciona una interferencia de la lista.",
                "MYG",
                Forms.MessageBoxButtons.OK,
                Forms.MessageBoxIcon.Information);

            return;
        }

        List<ElementId> ids = new List<ElementId>();
        ids.Add(info.IdA);
        ids.Add(info.IdB);

        UiDoc.Selection.SetElementIds(ids);
        UiDoc.ShowElements(ids);
        UiDoc.RefreshActiveView();

        Form.SetEstado(
            "Elementos seleccionados: " +
            info.IdAValor +
            " y " +
            info.IdBValor);
    }

    // =====================================================
    // GRABAR DATA
    // Ya no exporta XML ni HTML.
    // Guarda solo la data de IDs y datos base para cargarla después.
    // =====================================================

    private void GrabarDatos()
    {
        if (Form == null)
            return;

        List<ClashInfo> interferencias = Form.GetTodasLasInterferencias();

        if (interferencias == null || interferencias.Count == 0)
        {
            Forms.MessageBox.Show(
                "No hay interferencias para grabar. Primero ejecuta la detección.",
                "MYG",
                Forms.MessageBoxButtons.OK,
                Forms.MessageBoxIcon.Information);

            return;
        }

        using (Forms.SaveFileDialog dialog = new Forms.SaveFileDialog())
        {
            dialog.Title = "Grabar data de interferencias";
            dialog.Filter = "MYG Interferencias (*.mygclash)|*.mygclash|Archivo CSV (*.csv)|*.csv";
            dialog.FileName = "MYG_INTERFERENCIAS_DATA_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".mygclash";
            dialog.OverwritePrompt = true;

            if (dialog.ShowDialog() != Forms.DialogResult.OK)
                return;

            string ruta = dialog.FileName;

            try
            {
                if (Path.GetExtension(ruta).Equals(".csv", StringComparison.OrdinalIgnoreCase))
                    GuardarDataCsv(interferencias, ruta);
                else
                    GuardarDataMyg(interferencias, ruta);

                if (Form.DataCargada)
                    Form.SetDataCargada(true, ruta);
                else
                    Form.SetEstado("Data grabada correctamente: " + ruta);

                Forms.MessageBox.Show(
                    "Data grabada correctamente en:\n\n" + ruta,
                    "MYG - Grabar data",
                    Forms.MessageBoxButtons.OK,
                    Forms.MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Forms.MessageBox.Show(
                    "No se pudo grabar la data.\n\n" + ex.ToString(),
                    "MYG - Error",
                    Forms.MessageBoxButtons.OK,
                    Forms.MessageBoxIcon.Error);
            }
        }
    }

    private void GuardarDataMyg(
        List<ClashInfo> interferencias,
        string ruta)
    {
        List<string> lineas = new List<string>();
        lineas.Add(DataHeader);
        lineas.Add("#Numero|IdA|IdB|CategoriaA|NombreA|CategoriaB|NombreB|Levantado");

        int numero = 0;

        foreach (ClashInfo c in interferencias)
        {
            if (c == null)
                continue;

            numero++;

            string linea =
                numero.ToString(CultureInfo.InvariantCulture) + "|" +
                c.IdAValor.ToString(CultureInfo.InvariantCulture) + "|" +
                c.IdBValor.ToString(CultureInfo.InvariantCulture) + "|" +
                B64(c.CategoriaA) + "|" +
                B64(c.NombreA) + "|" +
                B64(c.CategoriaB) + "|" +
                B64(c.NombreB) + "|" +
                c.Levantado.ToString(CultureInfo.InvariantCulture);

            lineas.Add(linea);
        }

        File.WriteAllLines(ruta, lineas.ToArray(), new UTF8Encoding(true));
    }

    private void GuardarDataCsv(
        List<ClashInfo> interferencias,
        string ruta)
    {
        List<string> lineas = new List<string>();

        lineas.Add(
            "N°;Id A;Categoría A;Elemento A;Id B;Categoría B;Elemento B;Levantado");

        int numero = 0;

        foreach (ClashInfo c in interferencias)
        {
            if (c == null)
                continue;

            numero++;

            lineas.Add(
                Csv(numero.ToString()) + ";" +
                Csv(c.IdAValor.ToString()) + ";" +
                Csv(c.CategoriaA) + ";" +
                Csv(c.NombreA) + ";" +
                Csv(c.IdBValor.ToString()) + ";" +
                Csv(c.CategoriaB) + ";" +
                Csv(c.NombreB) + ";" +
                Csv(c.Levantado ? "SI" : "NO"));
        }

        File.WriteAllLines(ruta, lineas.ToArray(), new UTF8Encoding(true));
    }

    private void CargarData()
    {
        using (Forms.OpenFileDialog dialog = new Forms.OpenFileDialog())
        {
            dialog.Title = "Cargar data de interferencias";
            dialog.Filter = "MYG Interferencias (*.mygclash)|*.mygclash|Todos los archivos (*.*)|*.*";
            dialog.Multiselect = false;

            if (dialog.ShowDialog() != Forms.DialogResult.OK)
                return;

            string ruta = dialog.FileName;

            try
            {
                List<ClashInfo> data = LeerDataMyg(ruta);

                if (data == null || data.Count == 0)
                {
                    Forms.MessageBox.Show(
                        "No se encontró data válida en el archivo seleccionado.",
                        "MYG",
                        Forms.MessageBoxButtons.OK,
                        Forms.MessageBoxIcon.Warning);

                    return;
                }

                Form.SetResultados(data);
                Form.SetDataCargada(true, ruta);

                Forms.MessageBox.Show(
                    "Data cargada correctamente.\n\n" +
                    "Ahora presiona Detectar interferencias para evaluar si los pares ID A / ID B fueron levantados.",
                    "MYG - Cargar data",
                    Forms.MessageBoxButtons.OK,
                    Forms.MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Forms.MessageBox.Show(
                    "No se pudo cargar la data.\n\n" + ex.ToString(),
                    "MYG - Error",
                    Forms.MessageBoxButtons.OK,
                    Forms.MessageBoxIcon.Error);
            }
        }
    }

    private List<ClashInfo> LeerDataMyg(string ruta)
    {
        List<ClashInfo> lista = new List<ClashInfo>();

        string[] lineas = File.ReadAllLines(ruta, Encoding.UTF8);

        foreach (string lineaOriginal in lineas)
        {
            if (string.IsNullOrWhiteSpace(lineaOriginal))
                continue;

            string linea = lineaOriginal.Trim();

            if (linea.StartsWith("#"))
                continue;

            string[] p = linea.Split('|');

            if (p.Length < 8)
                continue;

            long idA;
            long idB;

            if (!long.TryParse(p[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out idA))
                continue;

            if (!long.TryParse(p[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out idB))
                continue;

            bool levantado = false;

            // Formato nuevo: Numero|IdA|IdB|CategoriaA|NombreA|CategoriaB|NombreB|Levantado
            // Formato antiguo compatible con archivos guardados antes de esta versión.
            if (p.Length >= 10)
                bool.TryParse(p[9], out levantado);
            else
                bool.TryParse(p[7], out levantado);

            ClashInfo info = new ClashInfo
            {
                Numero = lista.Count + 1,

                IdA = CrearElementId(idA),
                IdB = CrearElementId(idB),

                CategoriaA = FromB64(p[3]),
                NombreA = FromB64(p[4]),
                CategoriaB = FromB64(p[5]),
                NombreB = FromB64(p[6]),

                Levantado = levantado
            };

            lista.Add(info);
        }

        return lista;
    }

    private ElementId CrearElementId(long valor)
    {
        return new ElementId(valor);
    }

    private string B64(string texto)
    {
        if (texto == null)
            texto = "";

        return Convert.ToBase64String(Encoding.UTF8.GetBytes(texto));
    }

    private string FromB64(string texto)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(texto))
                return "";

            return Encoding.UTF8.GetString(Convert.FromBase64String(texto));
        }
        catch
        {
            return "";
        }
    }

    private string Csv(string texto)
    {
        if (texto == null)
            texto = "";

        texto = texto.Replace("\"", "\"\"");

        return "\"" + texto + "\"";
    }

    // =====================================================
    // ACTUALIZAR PROGRESO EN VENTANA
    // =====================================================

    private void ActualizarProgreso(string texto)
    {
        try
        {
            if (Form != null)
                Form.SetEstado(texto);

            Forms.Application.DoEvents();
        }
        catch
        {
        }
    }

    // =====================================================
    // EXPORTAR RFI EXCEL - MATRIZ CON CAMPOS MANUALES VACÍOS
    // =====================================================

    private void ExportarRfiExcel()
    {
        if (Form == null)
            return;

        List<ClashInfo> interferencias = Form.GetTodasLasInterferencias();

        if (interferencias == null || interferencias.Count == 0)
        {
            Forms.MessageBox.Show(
                "No hay interferencias para exportar. Primero ejecuta la detección.",
                "MYG",
                Forms.MessageBoxButtons.OK,
                Forms.MessageBoxIcon.Information);

            return;
        }

        string carpetaBase = null;

        using (Forms.FolderBrowserDialog dialog = new Forms.FolderBrowserDialog())
        {
            dialog.Description = "Selecciona la carpeta donde se guardará el Excel RFI de interferencias";
            dialog.ShowNewFolderButton = true;

            if (dialog.ShowDialog() != Forms.DialogResult.OK)
                return;

            carpetaBase = dialog.SelectedPath;
        }

        if (string.IsNullOrWhiteSpace(carpetaBase))
            return;

        Document doc = UiDoc.Document;
        View vistaOriginal = UiDoc.ActiveView;

        string nombreCarpetaReporte =
            "MYG_RFI_Interferencias_" + DateTime.Now.ToString("yyyyMMdd_HHmmss");

        string carpetaReporte = Path.Combine(carpetaBase, nombreCarpetaReporte);
        string carpetaImagenes = Path.Combine(carpetaReporte, "IMAGENES_RFI");

        Directory.CreateDirectory(carpetaReporte);
        Directory.CreateDirectory(carpetaImagenes);

        ActualizarProgreso(
            "Preparando exportación de matriz: 0/" +
            interferencias.Count +
            "...");

        List<ClashExportInfo> exportados = new List<ClashExportInfo>();
        VistaExportacionContext contexto = null;

        try
        {
            contexto = CrearContextoExportacionInterferencias(doc, vistaOriginal);

            if (contexto == null || contexto.Vista3D == null)
            {
                ActualizarProgreso("No se pudo crear la vista temporal. Se exportará la matriz sin imágenes.");
            }

            int contador = 0;

            foreach (ClashInfo info in interferencias)
            {
                contador++;

                ActualizarProgreso(
                    "Exportando imagen " +
                    contador +
                    "/" +
                    interferencias.Count +
                    "...");

                string rutaAbsolutaImagen = "";
                string rutaRelativaImagen = "";

                try
                {
                    if (contexto != null && contexto.Vista3D != null)
                    {
                        rutaAbsolutaImagen =
                            ExportarImagenInterferenciaOptimizada(
                                doc,
                                contexto,
                                info,
                                carpetaImagenes,
                                contador);

                        if (!string.IsNullOrWhiteSpace(rutaAbsolutaImagen))
                        {
                            rutaRelativaImagen =
                                "IMAGENES_RFI/" +
                                Path.GetFileName(rutaAbsolutaImagen);
                        }
                    }
                }
                catch
                {
                    rutaAbsolutaImagen = "";
                    rutaRelativaImagen = "";
                }

                exportados.Add(new ClashExportInfo
                {
                    Numero = contador,
                    Clash = info,
                    ImagenAbsoluta = rutaAbsolutaImagen,
                    ImagenRelativa = rutaRelativaImagen
                });

                ActualizarProgreso(
                    "Exportado " +
                    contador +
                    "/" +
                    interferencias.Count);
            }
        }
        finally
        {
            CerrarContextoExportacionInterferencias(doc, contexto);
        }

        string rutaExcel = Path.Combine(carpetaReporte, "MATRIZ_RFI_INTERFERENCIAS_MYG.xlsx");

        ActualizarProgreso("Creando archivo Excel RFI...");

        try
        {
            CrearExcelRfi(doc, exportados, rutaExcel);
        }
        catch (Exception ex)
        {
            Forms.MessageBox.Show(
                "No se pudo crear el Excel RFI.\n\n" + ex.ToString(),
                "MYG - Error Excel",
                Forms.MessageBoxButtons.OK,
                Forms.MessageBoxIcon.Error);

            return;
        }

        ActualizarProgreso("Excel RFI generado correctamente.");

        Forms.MessageBox.Show(
            "Excel RFI generado correctamente en:\n\n" +
            rutaExcel,
            "MYG - RFI Excel",
            Forms.MessageBoxButtons.OK,
            Forms.MessageBoxIcon.Information);

        try
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = rutaExcel,
                UseShellExecute = true
            });
        }
        catch
        {
        }
    }

    // =====================================================
    // CREAR EXCEL RFI
    // =====================================================

    private void CrearExcelRfi(
        Document doc,
        List<ClashExportInfo> exportados,
        string rutaExcel)
    {
        ConfigurarLicenciaEpplus();

        FileInfo file = new FileInfo(rutaExcel);

        if (file.Exists)
            file.Delete();

        using (ExcelPackage package = new ExcelPackage(file))
        {
            ExcelWorksheet ws = package.Workbook.Worksheets.Add("MATRIZ RFI");

            ws.View.ShowGridLines = false;
            ws.Cells.Style.Font.Name = "Arial Narrow";
            ws.Cells.Style.Font.Size = 9;

            ws.PrinterSettings.Orientation = eOrientation.Landscape;
            ws.PrinterSettings.PaperSize = ePaperSize.A4;
            ws.PrinterSettings.FitToPage = true;
            ws.PrinterSettings.FitToWidth = 1;
            ws.PrinterSettings.FitToHeight = 0;

            int totalCols = 17;

            ws.Cells[1, 1, 1, totalCols].Merge = true;
            ws.Cells[1, 1].Value = "MATRIZ RFI - INTERFERENCIAS DEL MODELO";
            ws.Cells[1, 1].Style.Font.Bold = true;
            ws.Cells[1, 1].Style.Font.Size = 18;
            ws.Cells[1, 1].Style.Font.Color.SetColor(SD.Color.White);
            ws.Cells[1, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            ws.Cells[1, 1].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
            ws.Cells[1, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
            ws.Cells[1, 1].Style.Fill.BackgroundColor.SetColor(SD.Color.FromArgb(0, 32, 96));
            ws.Row(1).Height = 28;

            string proyecto = ObtenerNombreProyecto(doc);

            ws.Cells[3, 1].Value = "PROYECTO:";
            ws.Cells[3, 2, 3, 5].Merge = true;
            ws.Cells[3, 2].Value = proyecto;

            ws.Cells[3, 6].Value = "ARCHIVO:";
            ws.Cells[3, 7, 3, 10].Merge = true;
            ws.Cells[3, 7].Value = doc.Title;

            ws.Cells[3, 11].Value = "FECHA:";
            ws.Cells[3, 12].Value = DateTime.Now.ToString("dd/MM/yyyy");

            ws.Cells[3, 13].Value = "RESPONSABLE:";
            ws.Cells[3, 14, 3, 17].Merge = true;
            ws.Cells[3, 14].Value = "";

            ws.Cells[4, 1].Value = "ESPECIALIDAD:";
            ws.Cells[4, 2, 4, 5].Merge = true;
            ws.Cells[4, 2].Value = "";

            ws.Cells[4, 6].Value = "REVISIÓN:";
            ws.Cells[4, 7].Value = "";

            ws.Cells[4, 8].Value = "TOTAL INTERFERENCIAS:";
            ws.Cells[4, 9].Value = exportados.Count;

            int totalLevantados = exportados.Count(x => x.Clash != null && x.Clash.Levantado);
            int totalPersisten = exportados.Count - totalLevantados;

            ws.Cells[4, 11].Value = "ESTADO GENERAL:";
            ws.Cells[4, 12, 4, 17].Merge = true;
            ws.Cells[4, 12].Value = "LEVANTADAS: " + totalLevantados + " | PERSISTEN: " + totalPersisten;

            AplicarFormatoBloqueDatos(ws, 3, 1, 4, totalCols);

            int headerRow = 6;

            string[] headers = new string[]
            {
                "N°",
                "CÓDIGO RFI",
                "IMAGEN",
                "ID A",
                "CATEGORÍA A",
                "ELEMENTO A",
                "ID B",
                "CATEGORÍA B",
                "ELEMENTO B",
                "DESCRIPCIÓN DEL CONFLICTO",
                "PRIORIDAD",
                "DISCIPLINA RESPONSABLE",
                "RESPONSABLE",
                "ESTADO",
                "FECHA COMPROMISO",
                "RESPUESTA",
                "OBSERVACIONES"
            };

            for (int i = 0; i < headers.Length; i++)
            {
                ws.Cells[headerRow, i + 1].Value = headers[i];
            }

            using (ExcelRange rng = ws.Cells[headerRow, 1, headerRow, totalCols])
            {
                rng.Style.Font.Bold = true;
                rng.Style.Font.Color.SetColor(SD.Color.White);
                rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                rng.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                rng.Style.WrapText = true;
                rng.Style.Fill.PatternType = ExcelFillStyle.Solid;
                rng.Style.Fill.BackgroundColor.SetColor(SD.Color.FromArgb(0, 32, 96));
                rng.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                rng.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                rng.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                rng.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
            }

            ws.Row(headerRow).Height = 32;

            int row = headerRow + 1;

            foreach (ClashExportInfo item in exportados)
            {
                ClashInfo c = item.Clash;
                string codigoRfi = "RFI-INT-" + item.Numero.ToString("000");

                ws.Cells[row, 1].Value = item.Numero;
                ws.Cells[row, 2].Value = codigoRfi;

                ws.Cells[row, 4].Value = c.IdAValor;
                ws.Cells[row, 5].Value = c.CategoriaA;
                ws.Cells[row, 6].Value = c.NombreA;

                ws.Cells[row, 7].Value = c.IdBValor;
                ws.Cells[row, 8].Value = c.CategoriaB;
                ws.Cells[row, 9].Value = c.NombreB;

                ws.Cells[row, 10].Value = "";
                ws.Cells[row, 11].Value = "";
                ws.Cells[row, 12].Value = "";
                ws.Cells[row, 13].Value = "";

                string estadoInterferencia = c.Levantado ? "LEVANTADO" : "PERSISTE";
                ws.Cells[row, 14].Value = estadoInterferencia;
                ws.Cells[row, 14].Style.Font.Bold = true;
                ws.Cells[row, 14].Style.Font.Color.SetColor(SD.Color.White);
                ws.Cells[row, 14].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                ws.Cells[row, 14].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                ws.Cells[row, 14].Style.Fill.PatternType = ExcelFillStyle.Solid;

                if (c.Levantado)
                {
                    ws.Cells[row, 14].Style.Fill.BackgroundColor.SetColor(SD.Color.FromArgb(0, 176, 80));
                }
                else
                {
                    ws.Cells[row, 14].Style.Fill.BackgroundColor.SetColor(SD.Color.FromArgb(192, 0, 0));
                }

                ws.Cells[row, 15].Value = "";
                ws.Cells[row, 16].Value = "";
                ws.Cells[row, 17].Value = "";

                ws.Row(row).Height = 75;

                if (!string.IsNullOrWhiteSpace(item.ImagenAbsoluta) &&
                    File.Exists(item.ImagenAbsoluta))
                {
                    try
                    {
                        ExcelPicture pic =
                            ws.Drawings.AddPicture(
                                "IMG_" + codigoRfi,
                                new FileInfo(item.ImagenAbsoluta));

                        pic.SetPosition(row - 1, 5, 2, 5);
                        pic.SetSize(145, 80);
                    }
                    catch
                    {
                    }
                }

                row++;
            }

            int lastRow = row - 1;

            using (ExcelRange rng = ws.Cells[headerRow, 1, lastRow, totalCols])
            {
                rng.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                rng.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                rng.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                rng.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                rng.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                rng.Style.WrapText = true;
            }

            using (ExcelRange rng = ws.Cells[headerRow + 1, 1, lastRow, totalCols])
            {
                rng.Style.Font.Size = 9;
            }

            ws.Cells[headerRow + 1, 1, lastRow, 2].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            ws.Cells[headerRow + 1, 3, lastRow, 3].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            ws.Cells[headerRow + 1, 4, lastRow, 4].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            ws.Cells[headerRow + 1, 7, lastRow, 7].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            ws.Cells[headerRow + 1, 11, lastRow, 15].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

            ws.Column(1).Width = 6;
            ws.Column(2).Width = 14;
            ws.Column(3).Width = 24;
            ws.Column(4).Width = 12;
            ws.Column(5).Width = 18;
            ws.Column(6).Width = 28;
            ws.Column(7).Width = 12;
            ws.Column(8).Width = 18;
            ws.Column(9).Width = 28;
            ws.Column(10).Width = 38;
            ws.Column(11).Width = 14;
            ws.Column(12).Width = 20;
            ws.Column(13).Width = 20;
            ws.Column(14).Width = 16;
            ws.Column(15).Width = 18;
            ws.Column(16).Width = 35;
            ws.Column(17).Width = 35;

            try
            {
                ws.Cells[headerRow, 1, lastRow, totalCols].AutoFilter = true;
            }
            catch
            {
            }

            try
            {
                ws.View.FreezePanes(headerRow + 1, 1);
            }
            catch
            {
            }

            AgregarListasDesplegablesRfi(ws, headerRow + 1, lastRow);

            CrearHojaAyudaRfi(package);

            package.SaveAs(file);
        }
    }

    private void ConfigurarLicenciaEpplus()
    {
        try
        {
            System.Reflection.PropertyInfo prop =
                typeof(ExcelPackage).GetProperty("LicenseContext");

            if (prop != null)
            {
                object valor =
                    System.Enum.Parse(prop.PropertyType, "NonCommercial");

                prop.SetValue(null, valor, null);
            }
        }
        catch
        {
        }
    }

    private void AplicarFormatoBloqueDatos(
        ExcelWorksheet ws,
        int filaInicio,
        int colInicio,
        int filaFin,
        int colFin)
    {
        using (ExcelRange rng = ws.Cells[filaInicio, colInicio, filaFin, colFin])
        {
            rng.Style.Border.Top.Style = ExcelBorderStyle.Thin;
            rng.Style.Border.Left.Style = ExcelBorderStyle.Thin;
            rng.Style.Border.Right.Style = ExcelBorderStyle.Thin;
            rng.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
            rng.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        }

        int[] columnasLabel = new int[]
        {
            1, 6, 8, 11, 13
        };

        foreach (int col in columnasLabel)
        {
            for (int fila = filaInicio; fila <= filaFin; fila++)
            {
                try
                {
                    ws.Cells[fila, col].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    ws.Cells[fila, col].Style.Fill.BackgroundColor.SetColor(SD.Color.FromArgb(0, 32, 96));
                    ws.Cells[fila, col].Style.Font.Color.SetColor(SD.Color.White);
                    ws.Cells[fila, col].Style.Font.Bold = true;
                    ws.Cells[fila, col].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                }
                catch
                {
                }
            }
        }

        ws.Row(3).Height = 22;
        ws.Row(4).Height = 22;
    }

    private void AgregarListasDesplegablesRfi(
        ExcelWorksheet ws,
        int filaInicio,
        int filaFin)
    {
        if (filaFin < filaInicio)
            return;

        try
        {
            var dvPrioridad =
                ws.DataValidations.AddListValidation(
                    "K" + filaInicio + ":K" + filaFin);

            dvPrioridad.ShowErrorMessage = true;
            dvPrioridad.ErrorTitle = "Prioridad no válida";
            dvPrioridad.Error = "Seleccione una prioridad de la lista.";
            dvPrioridad.Formula.Values.Add("ALTA");
            dvPrioridad.Formula.Values.Add("MEDIA");
            dvPrioridad.Formula.Values.Add("BAJA");
        }
        catch
        {
        }

        try
        {
            var dvEstado =
                ws.DataValidations.AddListValidation(
                    "N" + filaInicio + ":N" + filaFin);

            dvEstado.ShowErrorMessage = true;
            dvEstado.ErrorTitle = "Estado no válido";
            dvEstado.Error = "Seleccione un estado de la lista.";
            dvEstado.Formula.Values.Add("LEVANTADO");
            dvEstado.Formula.Values.Add("PERSISTE");
        }
        catch
        {
        }
    }

    private void CrearHojaAyudaRfi(ExcelPackage package)
    {
        ExcelWorksheet ws = package.Workbook.Worksheets.Add("AYUDA");

        ws.View.ShowGridLines = false;
        ws.Cells.Style.Font.Name = "Arial Narrow";
        ws.Cells.Style.Font.Size = 9;

        ws.Cells[1, 1, 1, 4].Merge = true;
        ws.Cells[1, 1].Value = "CAMPOS MANUALES PARA COMPLETAR EN EXCEL";
        ws.Cells[1, 1].Style.Font.Bold = true;
        ws.Cells[1, 1].Style.Font.Size = 14;
        ws.Cells[1, 1].Style.Font.Color.SetColor(SD.Color.White);
        ws.Cells[1, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
        ws.Cells[1, 1].Style.Fill.BackgroundColor.SetColor(SD.Color.FromArgb(0, 32, 96));
        ws.Cells[1, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

        ws.Cells[3, 1].Value = "Campo";
        ws.Cells[3, 2].Value = "Descripción";
        ws.Cells[3, 3].Value = "Quién lo completa";
        ws.Cells[3, 4].Value = "Observación";

        using (ExcelRange rng = ws.Cells[3, 1, 3, 4])
        {
            rng.Style.Font.Bold = true;
            rng.Style.Font.Color.SetColor(SD.Color.White);
            rng.Style.Fill.PatternType = ExcelFillStyle.Solid;
            rng.Style.Fill.BackgroundColor.SetColor(SD.Color.FromArgb(0, 32, 96));
            rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        }

        string[,] datos = new string[,]
        {
            { "DESCRIPCIÓN DEL CONFLICTO", "Describe técnicamente la interferencia detectada.", "Coordinador BIM / Especialista", "Puede redactarse después de revisar la imagen." },
            { "PRIORIDAD", "ALTA, MEDIA o BAJA.", "Coordinador BIM", "Tiene lista desplegable." },
            { "DISCIPLINA RESPONSABLE", "Especialidad que debe responder o resolver.", "Coordinador BIM", "Ejemplo: Estructuras, Sanitarias, HVAC, Eléctricas." },
            { "RESPONSABLE", "Persona o equipo asignado.", "Coordinador BIM", "Campo libre." },
            { "ESTADO", "Automático según evaluación: LEVANTADO o PERSISTE.", "MYG Add-in", "Se rellena con color verde o rojo." },
            { "FECHA COMPROMISO", "Fecha límite para respuesta o solución.", "Coordinador BIM", "Campo editable." },
            { "RESPUESTA", "Respuesta técnica del responsable.", "Especialista / Consultor", "Se completa luego de la revisión." },
            { "OBSERVACIONES", "Comentarios adicionales.", "Cualquier responsable autorizado", "Campo libre." }
        };

        int fila = 4;

        for (int i = 0; i < datos.GetLength(0); i++)
        {
            ws.Cells[fila, 1].Value = datos[i, 0];
            ws.Cells[fila, 2].Value = datos[i, 1];
            ws.Cells[fila, 3].Value = datos[i, 2];
            ws.Cells[fila, 4].Value = datos[i, 3];
            fila++;
        }

        using (ExcelRange rng = ws.Cells[3, 1, fila - 1, 4])
        {
            rng.Style.Border.Top.Style = ExcelBorderStyle.Thin;
            rng.Style.Border.Left.Style = ExcelBorderStyle.Thin;
            rng.Style.Border.Right.Style = ExcelBorderStyle.Thin;
            rng.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
            rng.Style.WrapText = true;
            rng.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        }

        ws.Column(1).Width = 30;
        ws.Column(2).Width = 55;
        ws.Column(3).Width = 35;
        ws.Column(4).Width = 55;
    }

    // =====================================================
    // EXPORTAR IMAGEN POR INTERFERENCIA
    // =====================================================

    private VistaExportacionContext CrearContextoExportacionInterferencias(
        Document doc,
        View vistaOriginal)
    {
        ViewFamilyType tipo3D =
            new FilteredElementCollector(doc)
            .OfClass(typeof(ViewFamilyType))
            .Cast<ViewFamilyType>()
            .FirstOrDefault(x => x.ViewFamily == ViewFamily.ThreeDimensional);

        if (tipo3D == null)
            return null;

        View3D vista3D = null;

        using (Transaction t = new Transaction(doc, "MYG - Crear vista temporal de exportación"))
        {
            t.Start();

            vista3D = View3D.CreateIsometric(doc, tipo3D.Id);
            vista3D.Name = "MYG_EXPORT_CLASH_TEMP_" + DateTime.Now.Ticks.ToString();

            try
            {
                vista3D.DetailLevel = ViewDetailLevel.Fine;
            }
            catch
            {
            }

            try
            {
                vista3D.DisplayStyle = DisplayStyle.ShadingWithEdges;
            }
            catch
            {
                try
                {
                    vista3D.DisplayStyle = DisplayStyle.Shading;
                }
                catch
                {
                }
            }

            try
            {
                vista3D.IsSectionBoxActive = true;
            }
            catch
            {
            }

            OcultarCategoriasAuxiliares(doc, vista3D);

            t.Commit();
        }

        if (vista3D == null)
            return null;

        try
        {
            UiDoc.ActiveView = vista3D;
            UiDoc.RefreshActiveView();
        }
        catch
        {
        }

        return new VistaExportacionContext
        {
            VistaOriginal = vistaOriginal,
            Vista3D = vista3D
        };
    }

    private void CerrarContextoExportacionInterferencias(
        Document doc,
        VistaExportacionContext contexto)
    {
        if (contexto == null)
            return;

        try
        {
            if (contexto.VistaOriginal != null &&
                doc.GetElement(contexto.VistaOriginal.Id) != null)
            {
                UiDoc.ActiveView = contexto.VistaOriginal;
                UiDoc.RefreshActiveView();
            }
        }
        catch
        {
        }

        try
        {
            using (Transaction t = new Transaction(doc, "MYG - Eliminar vista temporal de exportación"))
            {
                t.Start();

                if (contexto.Vista3D != null && doc.GetElement(contexto.Vista3D.Id) != null)
                {
                    try
                    {
                        if (contexto.Vista3D.IsInTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate))
                        {
                            contexto.Vista3D.DisableTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate);
                        }
                    }
                    catch
                    {
                    }

                    doc.Delete(contexto.Vista3D.Id);
                }

                t.Commit();
            }
        }
        catch
        {
        }
    }

    private string ExportarImagenInterferenciaOptimizada(
        Document doc,
        VistaExportacionContext contexto,
        ClashInfo info,
        string carpetaImagenes,
        int numero)
    {
        if (contexto == null || contexto.Vista3D == null)
            return "";

        Element elemA = doc.GetElement(info.IdA);
        Element elemB = doc.GetElement(info.IdB);

        if (elemA == null || elemB == null)
            return "";

        BoundingBoxXYZ caja = ObtenerCajaInterferencia(elemA, elemB);

        if (!PrepararVistaTemporalParaInterferencia(doc, contexto.Vista3D, elemA, elemB, caja))
            return "";

        string nombreBaseImagen = "Interferencia_" + numero.ToString("000");
        string rutaBaseImagen = Path.Combine(carpetaImagenes, nombreBaseImagen);
        string rutaImagenFinal = "";

        try
        {
            ImageExportOptions opciones = new ImageExportOptions();
            opciones.ExportRange = ExportRange.CurrentView;
            opciones.FilePath = rutaBaseImagen;
            opciones.HLRandWFViewsFileType = ImageFileType.PNG;
            opciones.ShadowViewsFileType = ImageFileType.PNG;
            opciones.ImageResolution = ImageResolution.DPI_150;
            opciones.ZoomType = ZoomFitType.FitToPage;
            opciones.PixelSize = 1000;
            opciones.FitDirection = FitDirectionType.Horizontal;

            doc.ExportImage(opciones);

            rutaImagenFinal = BuscarImagenExportada(carpetaImagenes, nombreBaseImagen);
        }
        catch
        {
            rutaImagenFinal = "";
        }

        return rutaImagenFinal;
    }

    private bool PrepararVistaTemporalParaInterferencia(
        Document doc,
        View3D vista3D,
        Element elemA,
        Element elemB,
        BoundingBoxXYZ caja)
    {
        if (doc == null || vista3D == null || elemA == null || elemB == null)
            return false;

        try
        {
            using (Transaction t = new Transaction(doc, "MYG - Preparar vista temporal de exportación"))
            {
                t.Start();

                try
                {
                    if (vista3D.IsInTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate))
                    {
                        vista3D.DisableTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate);
                    }
                }
                catch
                {
                }

                try
                {
                    vista3D.SetElementOverrides(elemA.Id, new OverrideGraphicSettings());
                }
                catch
                {
                }

                try
                {
                    vista3D.SetElementOverrides(elemB.Id, new OverrideGraphicSettings());
                }
                catch
                {
                }

                if (caja != null)
                {
                    try
                    {
                        vista3D.IsSectionBoxActive = true;
                        vista3D.SetSectionBox(caja);
                    }
                    catch
                    {
                    }
                }

                List<ElementId> ids = new List<ElementId>();
                ids.Add(elemA.Id);
                ids.Add(elemB.Id);

                try
                {
                    vista3D.IsolateElementsTemporary(ids);
                }
                catch
                {
                }

                AplicarColoresAElementos(doc, vista3D, elemA.Id, elemB.Id);
                AjustarOrientacionVista3D(vista3D, caja);

                t.Commit();
            }

            return true;
        }
        catch
        {
            return false;
        }
    }

    private string ExportarImagenInterferencia(
        Document doc,
        View vistaOriginal,
        ClashInfo info,
        string carpetaImagenes,
        int numero)
    {
        VistaExportacionContext contexto = null;

        try
        {
            contexto = CrearContextoExportacionInterferencias(doc, vistaOriginal);

            if (contexto == null || contexto.Vista3D == null)
                return "";

            return ExportarImagenInterferenciaOptimizada(
                doc,
                contexto,
                info,
                carpetaImagenes,
                numero);
        }
        finally
        {
            CerrarContextoExportacionInterferencias(doc, contexto);
        }
    }

    // =====================================================
    // OCULTAR TODO EXCEPTO LOS 2 ELEMENTOS
    // =====================================================

    private void OcultarTodoExceptoElementos(
        Document doc,
        View3D vista3D,
        List<ElementId> idsVisibles)
    {
        if (doc == null || vista3D == null || idsVisibles == null)
            return;

        HashSet<long> visibles = new HashSet<long>();

        foreach (ElementId id in idsVisibles)
        {
            if (id != null)
                visibles.Add(id.Value);
        }

        List<ElementId> ocultar = new List<ElementId>();

        try
        {
            List<ElementId> idsEnVista =
                new FilteredElementCollector(doc, vista3D.Id)
                .WhereElementIsNotElementType()
                .ToElementIds()
                .ToList();

            foreach (ElementId id in idsEnVista)
            {
                if (id == null)
                    continue;

                if (visibles.Contains(id.Value))
                    continue;

                try
                {
                    Element elemOcultar = doc.GetElement(id);

                    if (elemOcultar != null && elemOcultar.CanBeHidden(vista3D))
                        ocultar.Add(id);
                }
                catch
                {
                }
            }

            if (ocultar.Count > 0)
            {
                int bloque = 500;

                for (int i = 0; i < ocultar.Count; i += bloque)
                {
                    List<ElementId> parte =
                        ocultar
                        .Skip(i)
                        .Take(bloque)
                        .ToList();

                    try
                    {
                        vista3D.HideElements(parte);
                    }
                    catch
                    {
                    }
                }
            }
        }
        catch
        {
        }
    }

    // =====================================================
    // APLICAR COLORES A LOS 2 ELEMENTOS
    // =====================================================

    private void AplicarColoresAElementos(
        Document doc,
        View3D vista3D,
        ElementId idA,
        ElementId idB)
    {
        ElementId solidFillId = ObtenerSolidFillPatternId(doc);

        Color colorA = new Color(220, 50, 47);
        Color colorB = new Color(38, 139, 210);

        OverrideGraphicSettings ogsA =
            CrearOverrideColor(colorA, solidFillId);

        OverrideGraphicSettings ogsB =
            CrearOverrideColor(colorB, solidFillId);

        try
        {
            vista3D.SetElementOverrides(idA, ogsA);
        }
        catch
        {
        }

        try
        {
            vista3D.SetElementOverrides(idB, ogsB);
        }
        catch
        {
        }
    }

    private OverrideGraphicSettings CrearOverrideColor(
        Color color,
        ElementId solidFillId)
    {
        OverrideGraphicSettings ogs = new OverrideGraphicSettings();

        try
        {
            ogs.SetProjectionLineColor(color);
        }
        catch
        {
        }

        try
        {
            ogs.SetCutLineColor(color);
        }
        catch
        {
        }

        try
        {
            ogs.SetProjectionLineWeight(6);
        }
        catch
        {
        }

        try
        {
            ogs.SetCutLineWeight(6);
        }
        catch
        {
        }

        try
        {
            ogs.SetSurfaceTransparency(0);
        }
        catch
        {
        }

        if (solidFillId != null && solidFillId != ElementId.InvalidElementId)
        {
            try
            {
                ogs.SetSurfaceForegroundPatternId(solidFillId);
            }
            catch
            {
            }

            try
            {
                ogs.SetSurfaceForegroundPatternColor(color);
            }
            catch
            {
            }

            try
            {
                ogs.SetCutForegroundPatternId(solidFillId);
            }
            catch
            {
            }

            try
            {
                ogs.SetCutForegroundPatternColor(color);
            }
            catch
            {
            }
        }

        return ogs;
    }

    private ElementId ObtenerSolidFillPatternId(Document doc)
    {
        try
        {
            FillPatternElement fpe =
                new FilteredElementCollector(doc)
                .OfClass(typeof(FillPatternElement))
                .Cast<FillPatternElement>()
                .FirstOrDefault(x => x.GetFillPattern() != null && x.GetFillPattern().IsSolidFill);

            if (fpe != null)
                return fpe.Id;
        }
        catch
        {
        }

        return ElementId.InvalidElementId;
    }

    // =====================================================
    // ORIENTAR MEJOR LA VISTA 3D
    // =====================================================

    private void AjustarOrientacionVista3D(View3D vista3D, BoundingBoxXYZ bb)
    {
        if (vista3D == null || bb == null)
            return;

        XYZ center = new XYZ(
            (bb.Min.X + bb.Max.X) * 0.5,
            (bb.Min.Y + bb.Max.Y) * 0.5,
            (bb.Min.Z + bb.Max.Z) * 0.5);

        double dx = Math.Abs(bb.Max.X - bb.Min.X);
        double dy = Math.Abs(bb.Max.Y - bb.Min.Y);
        double dz = Math.Abs(bb.Max.Z - bb.Min.Z);

        double maxDim = Math.Max(dx, Math.Max(dy, dz));

        if (maxDim < 1.0)
            maxDim = 1.0;

        double d = maxDim * 2.2;

        XYZ eye = new XYZ(
            center.X - d,
            center.Y - d,
            center.Z + d);

        XYZ up = XYZ.BasisZ;
        XYZ forward = (center - eye).Normalize();

        try
        {
            ViewOrientation3D orientacion =
                new ViewOrientation3D(eye, up, forward);

            vista3D.SetOrientation(orientacion);
        }
        catch
        {
        }
    }

    // =====================================================
    // OCULTAR CATEGORÍAS AUXILIARES
    // =====================================================

    private void OcultarCategoriasAuxiliares(Document doc, View3D vista3D)
    {
        if (doc == null || vista3D == null)
            return;

        string[] nombresBuiltIn = new string[]
        {
            "OST_Levels",
            "OST_Grids",
            "OST_CLines",
            "OST_Cameras",
            "OST_SectionBox",
            "OST_IOS_GeoSite"
        };

        foreach (string nombreBic in nombresBuiltIn)
        {
            try
            {
                BuiltInCategory bic;

                if (!System.Enum.TryParse<BuiltInCategory>(nombreBic, out bic))
                    continue;

                Category cat = Category.GetCategory(doc, bic);

                if (cat == null)
                    continue;

                if (!vista3D.CanCategoryBeHidden(cat.Id))
                    continue;

                vista3D.SetCategoryHidden(cat.Id, true);
            }
            catch
            {
            }
        }

        string[] nombresCategorias = new string[]
        {
            "Niveles",
            "Levels",
            "Rejillas",
            "Grids",
            "Planos de referencia",
            "Reference Planes",
            "Líneas de referencia",
            "Reference Lines",
            "Cámaras",
            "Cameras",
            "Cajas de sección",
            "Section Boxes"
        };

        foreach (Category cat in doc.Settings.Categories)
        {
            if (cat == null)
                continue;

            try
            {
                bool ocultar = false;

                foreach (string nombre in nombresCategorias)
                {
                    if (cat.Name.Equals(nombre, StringComparison.OrdinalIgnoreCase))
                    {
                        ocultar = true;
                        break;
                    }
                }

                if (!ocultar)
                    continue;

                if (!vista3D.CanCategoryBeHidden(cat.Id))
                    continue;

                vista3D.SetCategoryHidden(cat.Id, true);
            }
            catch
            {
            }
        }
    }

    // =====================================================
    // BUSCAR IMAGEN EXPORTADA
    // =====================================================

    private string BuscarImagenExportada(
        string carpetaImagenes,
        string nombreBaseImagen)
    {
        try
        {
            string[] archivos =
                Directory.GetFiles(carpetaImagenes)
                .Where(x =>
                    Path.GetFileNameWithoutExtension(x)
                    .StartsWith(nombreBaseImagen, StringComparison.OrdinalIgnoreCase))
                .ToArray();

            if (archivos != null && archivos.Length > 0)
            {
                return archivos
                    .OrderByDescending(x => File.GetCreationTime(x))
                    .First();
            }
        }
        catch
        {
        }

        return "";
    }

    // =====================================================
    // OBTENER CAJA LOCAL DE INTERFERENCIA
    // =====================================================

    private BoundingBoxXYZ ObtenerCajaInterferencia(
        Element elemA,
        Element elemB)
    {
        BoundingBoxXYZ bbA = elemA.get_BoundingBox(null);
        BoundingBoxXYZ bbB = elemB.get_BoundingBox(null);

        if (bbA == null && bbB == null)
            return null;

        if (bbA == null)
            return ExpandirBoundingBox(bbB, 4.0);

        if (bbB == null)
            return ExpandirBoundingBox(bbA, 4.0);

        XYZ interMin = new XYZ(
            Math.Max(bbA.Min.X, bbB.Min.X),
            Math.Max(bbA.Min.Y, bbB.Min.Y),
            Math.Max(bbA.Min.Z, bbB.Min.Z));

        XYZ interMax = new XYZ(
            Math.Min(bbA.Max.X, bbB.Max.X),
            Math.Min(bbA.Max.Y, bbB.Max.Y),
            Math.Min(bbA.Max.Z, bbB.Max.Z));

        bool hayInterseccionCaja =
            interMin.X <= interMax.X &&
            interMin.Y <= interMax.Y &&
            interMin.Z <= interMax.Z;

        if (hayInterseccionCaja)
        {
            BoundingBoxXYZ bbInter = new BoundingBoxXYZ();
            bbInter.Min = interMin;
            bbInter.Max = interMax;

            return ExpandirBoundingBox(bbInter, 4.0);
        }

        XYZ min = new XYZ(
            Math.Min(bbA.Min.X, bbB.Min.X),
            Math.Min(bbA.Min.Y, bbB.Min.Y),
            Math.Min(bbA.Min.Z, bbB.Min.Z));

        XYZ max = new XYZ(
            Math.Max(bbA.Max.X, bbB.Max.X),
            Math.Max(bbA.Max.Y, bbB.Max.Y),
            Math.Max(bbA.Max.Z, bbB.Max.Z));

        BoundingBoxXYZ bb = new BoundingBoxXYZ();
        bb.Min = min;
        bb.Max = max;

        return ExpandirBoundingBox(bb, 4.0);
    }

    private BoundingBoxXYZ ExpandirBoundingBox(
        BoundingBoxXYZ bb,
        double minimoFt)
    {
        if (bb == null)
            return null;

        double dx = Math.Abs(bb.Max.X - bb.Min.X);
        double dy = Math.Abs(bb.Max.Y - bb.Min.Y);
        double dz = Math.Abs(bb.Max.Z - bb.Min.Z);

        double maxDim = Math.Max(dx, Math.Max(dy, dz));
        double margen = maxDim * 2.50;

        if (margen < minimoFt)
            margen = minimoFt;

        BoundingBoxXYZ nuevo = new BoundingBoxXYZ();

        nuevo.Min = new XYZ(
            bb.Min.X - margen,
            bb.Min.Y - margen,
            bb.Min.Z - margen);

        nuevo.Max = new XYZ(
            bb.Max.X + margen,
            bb.Max.Y + margen,
            bb.Max.Z + margen);

        return nuevo;
    }

    // =====================================================
    // CREAR REPORTE HTML
    // =====================================================

    private void CrearReporteHtml(
        Document doc,
        List<ClashExportInfo> exportados,
        string rutaHtml)
    {
        StringBuilder sb = new StringBuilder();

        string nombreProyecto = ObtenerNombreProyecto(doc);

        sb.AppendLine("<!DOCTYPE html>");
        sb.AppendLine("<html lang='es'>");
        sb.AppendLine("<head>");
        sb.AppendLine("<meta charset='UTF-8'>");
        sb.AppendLine("<title>Reporte de Interferencias MYG</title>");

        sb.AppendLine("<style>");
        sb.AppendLine("body{font-family:Arial,Segoe UI,sans-serif;background:#f3f4f6;margin:0;padding:24px;color:#111827;}");
        sb.AppendLine(".header{background:#111827;color:white;padding:20px;border-radius:14px;margin-bottom:20px;}");
        sb.AppendLine(".header h1{margin:0;font-size:26px;}");
        sb.AppendLine(".header p{margin:6px 0 0 0;color:#d1d5db;}");
        sb.AppendLine(".card{background:white;border-radius:14px;margin-bottom:18px;padding:18px;box-shadow:0 4px 14px rgba(0,0,0,.10);}");
        sb.AppendLine(".clash-title{font-size:20px;font-weight:bold;margin-bottom:10px;color:#1f2937;}");
        sb.AppendLine(".grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:12px;}");
        sb.AppendLine(".box{background:#f9fafb;border:1px solid #e5e7eb;border-radius:10px;padding:12px;}");
        sb.AppendLine(".box h3{margin:0 0 8px 0;font-size:15px;color:#374151;}");
        sb.AppendLine(".dato{font-size:13px;margin:4px 0;}");
        sb.AppendLine(".dato b{color:#111827;}");
        sb.AppendLine(".imagen{margin-top:12px;text-align:center;}");
        sb.AppendLine(".imagen img{max-width:100%;border-radius:12px;border:1px solid #d1d5db;background:white;}");
        sb.AppendLine(".sinimagen{padding:16px;background:#fff7ed;border:1px solid #fed7aa;border-radius:10px;color:#9a3412;}");
        sb.AppendLine("</style>");

        sb.AppendLine("</head>");
        sb.AppendLine("<body>");

        sb.AppendLine("<div class='header'>");
        sb.AppendLine("<h1>Reporte de Interferencias - MYG</h1>");
        sb.AppendLine("<p><b>Proyecto:</b> " + Html(nombreProyecto) + "</p>");
        sb.AppendLine("<p><b>Archivo:</b> " + Html(doc.Title) + "</p>");
        sb.AppendLine("<p><b>Fecha:</b> " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + "</p>");
        sb.AppendLine("<p><b>Total de interferencias:</b> " + exportados.Count + "</p>");
        sb.AppendLine("</div>");

        foreach (ClashExportInfo item in exportados)
        {
            ClashInfo c = item.Clash;

            sb.AppendLine("<div class='card'>");

            sb.AppendLine("<div class='clash-title'>Interferencia " + item.Numero.ToString("000") + "</div>");

            sb.AppendLine("<div class='grid'>");

            sb.AppendLine("<div class='box'>");
            sb.AppendLine("<h3 style='color:#dc322f;'>Elemento A</h3>");
            sb.AppendLine("<div class='dato'><b>ID:</b> " + c.IdAValor + "</div>");
            sb.AppendLine("<div class='dato'><b>Categoría:</b> " + Html(c.CategoriaA) + "</div>");
            sb.AppendLine("<div class='dato'><b>Nombre:</b> " + Html(c.NombreA) + "</div>");
            sb.AppendLine("</div>");

            sb.AppendLine("<div class='box'>");
            sb.AppendLine("<h3 style='color:#268bd2;'>Elemento B</h3>");
            sb.AppendLine("<div class='dato'><b>ID:</b> " + c.IdBValor + "</div>");
            sb.AppendLine("<div class='dato'><b>Categoría:</b> " + Html(c.CategoriaB) + "</div>");
            sb.AppendLine("<div class='dato'><b>Nombre:</b> " + Html(c.NombreB) + "</div>");
            sb.AppendLine("</div>");

            sb.AppendLine("</div>");

            if (!string.IsNullOrWhiteSpace(item.ImagenRelativa))
            {
                sb.AppendLine("<div class='imagen'>");
                sb.AppendLine("<img src='" + Html(item.ImagenRelativa) + "' alt='Interferencia " + item.Numero + "'>");
                sb.AppendLine("</div>");
            }
            else
            {
                sb.AppendLine("<div class='sinimagen'>No se pudo generar imagen para esta interferencia.</div>");
            }

            sb.AppendLine("</div>");
        }

        sb.AppendLine("</body>");
        sb.AppendLine("</html>");

        File.WriteAllText(rutaHtml, sb.ToString(), Encoding.UTF8);
    }

    // =====================================================
    // CREAR REPORTE XML
    // =====================================================

    private void CrearReporteXml(
        Document doc,
        List<ClashExportInfo> exportados,
        string rutaXml)
    {
        StringBuilder sb = new StringBuilder();

        sb.AppendLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
        sb.AppendLine("<MYG_Interferencias>");
        sb.AppendLine("  <Proyecto>" + Xml(doc.Title) + "</Proyecto>");
        sb.AppendLine("  <Fecha>" + Xml(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")) + "</Fecha>");
        sb.AppendLine("  <Total>" + exportados.Count + "</Total>");
        sb.AppendLine("  <Items>");

        foreach (ClashExportInfo item in exportados)
        {
            ClashInfo c = item.Clash;

            sb.AppendLine("    <Interferencia numero=\"" + item.Numero.ToString("000") + "\">");

            sb.AppendLine("      <ElementoA>");
            sb.AppendLine("        <Id>" + c.IdAValor + "</Id>");
            sb.AppendLine("        <Categoria>" + Xml(c.CategoriaA) + "</Categoria>");
            sb.AppendLine("        <Nombre>" + Xml(c.NombreA) + "</Nombre>");
            sb.AppendLine("      </ElementoA>");

            sb.AppendLine("      <ElementoB>");
            sb.AppendLine("        <Id>" + c.IdBValor + "</Id>");
            sb.AppendLine("        <Categoria>" + Xml(c.CategoriaB) + "</Categoria>");
            sb.AppendLine("        <Nombre>" + Xml(c.NombreB) + "</Nombre>");
            sb.AppendLine("      </ElementoB>");

            sb.AppendLine("      <Imagen>" + Xml(item.ImagenRelativa) + "</Imagen>");

            sb.AppendLine("    </Interferencia>");
        }

        sb.AppendLine("  </Items>");
        sb.AppendLine("</MYG_Interferencias>");

        File.WriteAllText(rutaXml, sb.ToString(), Encoding.UTF8);
    }

    // =====================================================
    // UTILIDADES HTML / XML
    // =====================================================

    private string Html(string texto)
    {
        if (texto == null)
            return "";

        return System.Net.WebUtility.HtmlEncode(texto);
    }

    private string Xml(string texto)
    {
        if (texto == null)
            return "";

        return SecurityElement.Escape(texto);
    }

    // =====================================================
    // NOMBRES
    // =====================================================

    private string ObtenerNombreProyecto(Document doc)
    {
        string valor = "";

        try
        {
            if (doc != null && doc.ProjectInformation != null)
            {
                Parameter p = doc.ProjectInformation.get_Parameter(BuiltInParameter.PROJECT_NAME);

                if (p != null && p.StorageType == StorageType.String)
                {
                    valor = p.AsString();

                    if (EsNombreProyectoValido(valor))
                        return valor.Trim();
                }
            }
        }
        catch
        {
        }

        try
        {
            if (doc != null && doc.ProjectInformation != null)
            {
                valor = doc.ProjectInformation.Name;

                if (EsNombreProyectoValido(valor))
                    return valor.Trim();
            }
        }
        catch
        {
        }

        try
        {
            if (doc != null && doc.ProjectInformation != null)
            {
                string[] nombresParametros = new string[]
                {
                    "Nombre de proyecto",
                    "Project Name",
                    "PROYECTO",
                    "Proyecto"
                };

                foreach (string nombreParametro in nombresParametros)
                {
                    Parameter p = doc.ProjectInformation.LookupParameter(nombreParametro);

                    if (p == null || p.StorageType != StorageType.String)
                        continue;

                    valor = p.AsString();

                    if (EsNombreProyectoValido(valor))
                        return valor.Trim();
                }
            }
        }
        catch
        {
        }

        try
        {
            if (doc != null && !string.IsNullOrWhiteSpace(doc.Title))
                return doc.Title;
        }
        catch
        {
        }

        return "-";
    }

    private bool EsNombreProyectoValido(string valor)
    {
        if (string.IsNullOrWhiteSpace(valor))
            return false;

        string limpio = valor.Trim();

        if (limpio.Equals("Nombre de proyecto", StringComparison.OrdinalIgnoreCase))
            return false;

        if (limpio.Equals("Project Name", StringComparison.OrdinalIgnoreCase))
            return false;

        if (limpio.Equals("-", StringComparison.OrdinalIgnoreCase))
            return false;

        return true;
    }

    private static string ObtenerNombreCategoria(Element e)
    {
        if (e == null || e.Category == null)
            return "-";

        return e.Category.Name;
    }

    private static string ObtenerNombreElemento(Document doc, Element e)
    {
        if (e == null)
            return "-";

        FamilyInstance fi = e as FamilyInstance;

        if (fi != null && fi.Symbol != null)
        {
            string familia = fi.Symbol.FamilyName;
            string tipo = fi.Symbol.Name;

            if (!string.IsNullOrWhiteSpace(familia) ||
                !string.IsNullOrWhiteSpace(tipo))
            {
                return familia + " : " + tipo;
            }
        }

        ElementType tipoElem = doc.GetElement(e.GetTypeId()) as ElementType;

        if (tipoElem != null && !string.IsNullOrWhiteSpace(tipoElem.Name))
            return tipoElem.Name;

        if (!string.IsNullOrWhiteSpace(e.Name))
            return e.Name;

        return e.GetType().Name;
    }

    // =====================================================
    // CLASE AUXILIAR EXPORTACIÓN
    // =====================================================


    private class VistaExportacionContext
    {
        public View VistaOriginal { get; set; }
        public View3D Vista3D { get; set; }
    }

    private class ClashExportInfo
    {
        public int Numero { get; set; }
        public ClashInfo Clash { get; set; }
        public string ImagenRelativa { get; set; }
        public string ImagenAbsoluta { get; set; }
    }
}

// =====================================================
// CLASE - ITEM DE CATEGORÍA
// =====================================================

public class CategoriaItem
{
    public string Nombre { get; set; }
    public BuiltInCategory Bic { get; set; }

    public override string ToString()
    {
        return Nombre;
    }
}

// =====================================================
// CLASE - INFORMACIÓN DE INTERFERENCIA
// =====================================================

public class ClashInfo
{
    public int Numero { get; set; }

    [Browsable(false)]
    public ElementId IdA { get; set; }

    [Browsable(false)]
    public ElementId IdB { get; set; }

    public long IdAValor
    {
        get
        {
            if (IdA == null)
                return 0;

            return IdA.Value;
        }
    }

    public long IdBValor
    {
        get
        {
            if (IdB == null)
                return 0;

            return IdB.Value;
        }
    }

    public string CategoriaA { get; set; }
    public string NombreA { get; set; }

    public string CategoriaB { get; set; }
    public string NombreB { get; set; }

    public bool Levantado { get; set; }

}
