using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================================
    // COMANDO - COMPROBACIÓN DE INTERFERENCIAS
    // =====================================================

    [Transaction(TransactionMode.Manual)]
    public class MYG_InterferenciasCommand : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            UIDocument uidoc = commandData.Application.ActiveUIDocument;
            Document doc = uidoc.Document;

            try
            {
                //-------------------------------------------------
                // OBTENER CATEGORÍAS DEL MODELO
                //-------------------------------------------------

                List<CategoriaItem> categorias =
                    MYG_InterferenciasHandler.ObtenerCategoriasConElementos(doc);

                if (categorias == null || categorias.Count == 0)
                {
                    TaskDialog.Show(
                        "MYG",
                        "No se encontraron categorías de modelo con elementos en el proyecto.");

                    return Result.Cancelled;
                }

                //-------------------------------------------------
                // HANDLER EXTERNO
                //-------------------------------------------------

                MYG_InterferenciasHandler interferenciasHandler =
                    new MYG_InterferenciasHandler();

                interferenciasHandler.UiDoc = uidoc;

                ExternalEvent interferenciasEvent =
                    ExternalEvent.Create(interferenciasHandler);

                //-------------------------------------------------
                // MOSTRAR VENTANA
                //-------------------------------------------------

                MYG_InterferenciasForm form =
                    new MYG_InterferenciasForm(
                        categorias,
                        interferenciasHandler,
                        interferenciasEvent);

                interferenciasHandler.Form = form;

                //-------------------------------------------------
                // MOSTRAR
                //-------------------------------------------------

                form.Show();

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                TaskDialog.Show("MYG - Error", ex.ToString());
                return Result.Failed;
            }
        }
    }

}
