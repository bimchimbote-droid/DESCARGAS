using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    //---------------------------------------------------------
    // VENTANA (COMPROBACIÓN DE INTERFERENCIAS)
    //---------------------------------------------------------
    public class MYG_InterferenciasForm : System.Windows.Forms.Form
    {
        private readonly MYG_InterferenciasHandler _handler;
        private readonly Autodesk.Revit.UI.ExternalEvent _externalEvent;

        private System.Windows.Forms.TreeView tvCatA;
        private System.Windows.Forms.TreeView tvCatB;

        private System.Windows.Forms.CheckBox chkSoloVista;
        private System.Windows.Forms.NumericUpDown nudPrecisionCm;

        private System.Windows.Forms.Button btnDetectar;
        private System.Windows.Forms.Button btnAislar;
        private System.Windows.Forms.Button btnSeleccionar;
        private System.Windows.Forms.Button btnRestaurar;
        private System.Windows.Forms.Button btnGrabarDatos;
        private System.Windows.Forms.Button btnCargarData;
        private System.Windows.Forms.Button btnExportarRfiExcel;
        private System.Windows.Forms.Button btnCerrar;

        private System.Windows.Forms.Button btnTodoA;
        private System.Windows.Forms.Button btnNingunaA;
        private System.Windows.Forms.Button btnInvertirA;

        private System.Windows.Forms.Button btnTodoB;
        private System.Windows.Forms.Button btnNingunaB;
        private System.Windows.Forms.Button btnInvertirB;

        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Label lblEstado;

        private System.ComponentModel.BindingList<ClashInfo> _data =
            new System.ComponentModel.BindingList<ClashInfo>();

        private bool _dataCargada = false;
        private string _rutaDataCargada = "";

        private System.Collections.Generic.List<CategoriaItem> _categoriasOriginales =
            new System.Collections.Generic.List<CategoriaItem>();

        public MYG_InterferenciasForm(
            System.Collections.Generic.List<CategoriaItem> categorias,
            MYG_InterferenciasHandler handler,
            Autodesk.Revit.UI.ExternalEvent externalEvent)
        {
            _handler = handler;
            _externalEvent = externalEvent;

            if (categorias != null)
                _categoriasOriginales = FiltrarCategoriasVisibles(categorias);

            ConstruirUI();
            CargarCategorias(_categoriasOriginales);
        }

        // =====================================================
        // PROPIEDADES USADAS POR EL HANDLER
        // =====================================================

        public bool DataCargada
        {
            get { return _dataCargada; }
        }

        public string RutaDataCargada
        {
            get { return _rutaDataCargada; }
        }

        public CategoriaItem CategoriaA
        {
            get
            {
                System.Collections.Generic.List<CategoriaItem> lista = GetCategoriasSeleccionadasA();

                if (lista != null && lista.Count > 0)
                    return lista[0];

                return null;
            }
        }

        public CategoriaItem CategoriaB
        {
            get
            {
                System.Collections.Generic.List<CategoriaItem> lista = GetCategoriasSeleccionadasB();

                if (lista != null && lista.Count > 0)
                    return lista[0];

                return null;
            }
        }

        public System.Collections.Generic.List<CategoriaItem> CategoriasASeleccionadas
        {
            get { return GetCategoriasSeleccionadasA(); }
        }

        public System.Collections.Generic.List<CategoriaItem> CategoriasBSeleccionadas
        {
            get { return GetCategoriasSeleccionadasB(); }
        }

        public bool SoloVistaActiva
        {
            get { return chkSoloVista.Checked; }
        }

        public double PrecisionCm
        {
            get { return (double)nudPrecisionCm.Value; }
        }

        // =====================================================
        // CONSTRUIR UI
        // =====================================================

        private void ConstruirUI()
        {
            Text = "MYG - Comprobación de interferencias";

            // Ventana más ancha para que entren mejor las columnas.
            Width = 1480;
            Height = 730;
            MinimumSize = new System.Drawing.Size(1320, 650);
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;

            System.Windows.Forms.TableLayoutPanel layoutPrincipal =
                new System.Windows.Forms.TableLayoutPanel();

            layoutPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            layoutPrincipal.ColumnCount = 3;
            layoutPrincipal.RowCount = 3;
            layoutPrincipal.Padding = new System.Windows.Forms.Padding(10);
            layoutPrincipal.BackColor = System.Drawing.SystemColors.Control;

            layoutPrincipal.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250));

            layoutPrincipal.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250));

            layoutPrincipal.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100));

            layoutPrincipal.RowStyles.Add(
                new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100));

            layoutPrincipal.RowStyles.Add(
                new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 58));

            layoutPrincipal.RowStyles.Add(
                new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46));

            Controls.Add(layoutPrincipal);

            // -------------------------------------------------
            // PANEL CATEGORÍAS A
            // -------------------------------------------------

            System.Windows.Forms.GroupBox grpA = new System.Windows.Forms.GroupBox();
            grpA.Text = "Categorías A";
            grpA.Dock = System.Windows.Forms.DockStyle.Fill;
            grpA.Padding = new System.Windows.Forms.Padding(8);

            tvCatA = new System.Windows.Forms.TreeView();
            tvCatA.CheckBoxes = true;
            tvCatA.HideSelection = false;
            tvCatA.FullRowSelect = true;
            tvCatA.ShowLines = true;
            tvCatA.ShowRootLines = false;
            tvCatA.Dock = System.Windows.Forms.DockStyle.Fill;
            tvCatA.AfterCheck += TreeAfterCheck;

            System.Windows.Forms.Panel panelBotonesA = CrearPanelBotonesCategorias(
                out btnTodoA,
                out btnNingunaA,
                out btnInvertirA);

            btnTodoA.Click += delegate { MarcarTodos(tvCatA, true); };
            btnNingunaA.Click += delegate { MarcarTodos(tvCatA, false); };
            btnInvertirA.Click += delegate { InvertirChecks(tvCatA); };

            grpA.Controls.Add(tvCatA);
            grpA.Controls.Add(panelBotonesA);

            layoutPrincipal.Controls.Add(grpA, 0, 0);

            // -------------------------------------------------
            // PANEL CATEGORÍAS B
            // -------------------------------------------------

            System.Windows.Forms.GroupBox grpB = new System.Windows.Forms.GroupBox();
            grpB.Text = "Categorías B";
            grpB.Dock = System.Windows.Forms.DockStyle.Fill;
            grpB.Padding = new System.Windows.Forms.Padding(8);

            tvCatB = new System.Windows.Forms.TreeView();
            tvCatB.CheckBoxes = true;
            tvCatB.HideSelection = false;
            tvCatB.FullRowSelect = true;
            tvCatB.ShowLines = true;
            tvCatB.ShowRootLines = false;
            tvCatB.Dock = System.Windows.Forms.DockStyle.Fill;
            tvCatB.AfterCheck += TreeAfterCheck;

            System.Windows.Forms.Panel panelBotonesB = CrearPanelBotonesCategorias(
                out btnTodoB,
                out btnNingunaB,
                out btnInvertirB);

            btnTodoB.Click += delegate { MarcarTodos(tvCatB, true); };
            btnNingunaB.Click += delegate { MarcarTodos(tvCatB, false); };
            btnInvertirB.Click += delegate { InvertirChecks(tvCatB); };

            grpB.Controls.Add(tvCatB);
            grpB.Controls.Add(panelBotonesB);

            layoutPrincipal.Controls.Add(grpB, 1, 0);

            // -------------------------------------------------
            // TABLA DE INTERFERENCIAS
            // -------------------------------------------------

            System.Windows.Forms.GroupBox grpTabla = new System.Windows.Forms.GroupBox();
            grpTabla.Text = "Interferencias detectadas / data cargada";
            grpTabla.Dock = System.Windows.Forms.DockStyle.Fill;
            grpTabla.Padding = new System.Windows.Forms.Padding(8);

            dgv = new System.Windows.Forms.DataGridView();
            dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            dgv.AutoGenerateColumns = false;
            dgv.ReadOnly = false;
            dgv.MultiSelect = false;
            dgv.AllowUserToAddRows = false;
            dgv.AllowUserToDeleteRows = false;
            dgv.AllowUserToResizeRows = false;
            dgv.RowHeadersVisible = false;
            dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            dgv.BackgroundColor = System.Drawing.Color.White;
            dgv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dgv.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.None;
            dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.None;
            dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv.ColumnHeadersHeight = 30;
            dgv.RowTemplate.Height = 26;

            dgv.CurrentCellDirtyStateChanged += Dgv_CurrentCellDirtyStateChanged;
            dgv.CellValueChanged += Dgv_CellValueChanged;
            dgv.DataBindingComplete += Dgv_DataBindingComplete;
            dgv.RowPrePaint += Dgv_RowPrePaint;

            AgregarColumnas();

            dgv.DataSource = _data;

            dgv.CellDoubleClick += delegate
            {
                RaiseRequest(MYG_InterferenciasRequest.Aislar);
            };

            grpTabla.Controls.Add(dgv);
            layoutPrincipal.Controls.Add(grpTabla, 2, 0);

            // -------------------------------------------------
            // OPCIONES
            // -------------------------------------------------

            System.Windows.Forms.TableLayoutPanel panelOpciones =
                new System.Windows.Forms.TableLayoutPanel();

            panelOpciones.Dock = System.Windows.Forms.DockStyle.Fill;
            panelOpciones.Padding = new System.Windows.Forms.Padding(0, 7, 0, 0);
            panelOpciones.ColumnCount = 3;
            panelOpciones.RowCount = 1;

            panelOpciones.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.AutoSize));

            panelOpciones.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100));

            panelOpciones.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 190));

            System.Windows.Forms.FlowLayoutPanel panelOpcionesIzq =
                new System.Windows.Forms.FlowLayoutPanel();

            panelOpcionesIzq.Dock = System.Windows.Forms.DockStyle.Fill;
            panelOpcionesIzq.AutoSize = true;
            panelOpcionesIzq.WrapContents = false;
            panelOpcionesIzq.FlowDirection = System.Windows.Forms.FlowDirection.LeftToRight;
            panelOpcionesIzq.Padding = new System.Windows.Forms.Padding(0, 0, 0, 0);
            panelOpcionesIzq.Margin = new System.Windows.Forms.Padding(0);

            chkSoloVista = new System.Windows.Forms.CheckBox();
            chkSoloVista.Text = "Solo elementos visibles en la vista activa";
            chkSoloVista.AutoSize = true;
            chkSoloVista.Checked = true;
            chkSoloVista.Margin = new System.Windows.Forms.Padding(0, 8, 20, 0);

            System.Windows.Forms.Label lblPrecision = new System.Windows.Forms.Label();
            lblPrecision.Text = "Precisión (cm):";
            lblPrecision.AutoSize = true;
            lblPrecision.Margin = new System.Windows.Forms.Padding(0, 10, 6, 0);

            nudPrecisionCm = new System.Windows.Forms.NumericUpDown();
            nudPrecisionCm.Width = 70;
            nudPrecisionCm.DecimalPlaces = 2;
            nudPrecisionCm.Minimum = 0;
            nudPrecisionCm.Maximum = 100000;
            nudPrecisionCm.Increment = 0.50M;
            nudPrecisionCm.Value = 0;
            nudPrecisionCm.Margin = new System.Windows.Forms.Padding(0, 6, 0, 0);

            panelOpcionesIzq.Controls.Add(chkSoloVista);
            panelOpcionesIzq.Controls.Add(lblPrecision);
            panelOpcionesIzq.Controls.Add(nudPrecisionCm);

            btnDetectar = new System.Windows.Forms.Button();
            btnDetectar.Text = "Detectar interferencias";
            btnDetectar.Width = 170;
            btnDetectar.Height = 28;
            btnDetectar.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            btnDetectar.Margin = new System.Windows.Forms.Padding(10, 5, 0, 0);
            btnDetectar.Click += delegate
            {
                RaiseRequest(MYG_InterferenciasRequest.Detectar);
            };

            panelOpciones.Controls.Add(panelOpcionesIzq, 0, 0);
            panelOpciones.Controls.Add(new System.Windows.Forms.Label(), 1, 0);
            panelOpciones.Controls.Add(btnDetectar, 2, 0);

            layoutPrincipal.SetColumnSpan(panelOpciones, 3);
            layoutPrincipal.Controls.Add(panelOpciones, 0, 1);

            // -------------------------------------------------
            // BOTONERA INFERIOR
            // -------------------------------------------------

            System.Windows.Forms.Panel panelBottom =
                new System.Windows.Forms.Panel();

            panelBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            panelBottom.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);

            btnAislar = CrearBotonInferior("Aislar elementos", 0, 118);
            btnAislar.Click += delegate
            {
                RaiseRequest(MYG_InterferenciasRequest.Aislar);
            };

            btnSeleccionar = CrearBotonInferior("Seleccionar", 126, 105);
            btnSeleccionar.Click += delegate
            {
                RaiseRequest(MYG_InterferenciasRequest.Seleccionar);
            };

            btnRestaurar = CrearBotonInferior("Restaurar vista", 239, 120);
            btnRestaurar.Click += delegate
            {
                RaiseRequest(MYG_InterferenciasRequest.Restaurar);
            };

            btnGrabarDatos = CrearBotonInferior("Grabar data", 367, 110);
            btnGrabarDatos.Click += delegate
            {
                RaiseRequest(MYG_InterferenciasRequest.GrabarDatos);
            };

            btnCargarData = CrearBotonInferior("Cargar data", 485, 120);
            btnCargarData.Click += delegate
            {
                if (_dataCargada)
                {
                    SetDataCargada(false, "");
                    SetResultados(new System.Collections.Generic.List<ClashInfo>());
                    SetEstado("Data descargada. Listo para detectar interferencias nuevas.");
                }
                else
                {
                    RaiseRequest(MYG_InterferenciasRequest.CargarData);
                }
            };

            btnExportarRfiExcel = CrearBotonInferior("Exportar Matriz", 613, 128);
            btnExportarRfiExcel.Click += delegate
            {
                RaiseRequest(MYG_InterferenciasRequest.ExportarRfiExcel);
            };

            btnCerrar = CrearBotonInferior("Cerrar", 0, 90);
            btnCerrar.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            btnCerrar.Click += delegate
            {
                Close();
            };

            lblEstado = new System.Windows.Forms.Label();
            lblEstado.Text = "Listo.";
            lblEstado.AutoSize = false;
            lblEstado.Location = new System.Drawing.Point(0, 32);
            lblEstado.Height = 18;
            lblEstado.Width = 1000;
            lblEstado.Anchor =
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right |
                System.Windows.Forms.AnchorStyles.Bottom;

            panelBottom.Controls.Add(btnAislar);
            panelBottom.Controls.Add(btnSeleccionar);
            panelBottom.Controls.Add(btnRestaurar);
            panelBottom.Controls.Add(btnGrabarDatos);
            panelBottom.Controls.Add(btnCargarData);
            panelBottom.Controls.Add(btnExportarRfiExcel);
            panelBottom.Controls.Add(btnCerrar);
            panelBottom.Controls.Add(lblEstado);

            layoutPrincipal.SetColumnSpan(panelBottom, 3);
            layoutPrincipal.Controls.Add(panelBottom, 0, 2);

            panelBottom.Resize += delegate
            {
                btnCerrar.Left = panelBottom.ClientSize.Width - btnCerrar.Width - 5;
                lblEstado.Width = panelBottom.ClientSize.Width - 10;
            };
        }

        private System.Windows.Forms.Panel CrearPanelBotonesCategorias(
            out System.Windows.Forms.Button btnTodo,
            out System.Windows.Forms.Button btnNinguna,
            out System.Windows.Forms.Button btnInvertir)
        {
            System.Windows.Forms.Panel panel =
                new System.Windows.Forms.Panel();

            panel.Dock = System.Windows.Forms.DockStyle.Bottom;
            panel.Height = 44;
            panel.Padding = new System.Windows.Forms.Padding(0, 8, 0, 0);

            btnTodo = new System.Windows.Forms.Button();
            btnTodo.Text = "Todo";
            btnTodo.Width = 68;
            btnTodo.Height = 27;
            btnTodo.Location = new System.Drawing.Point(0, 9);

            btnNinguna = new System.Windows.Forms.Button();
            btnNinguna.Text = "Ninguna";
            btnNinguna.Width = 78;
            btnNinguna.Height = 27;
            btnNinguna.Location = new System.Drawing.Point(74, 9);

            btnInvertir = new System.Windows.Forms.Button();
            btnInvertir.Text = "Invertir";
            btnInvertir.Width = 72;
            btnInvertir.Height = 27;
            btnInvertir.Location = new System.Drawing.Point(158, 9);

            panel.Controls.Add(btnTodo);
            panel.Controls.Add(btnNinguna);
            panel.Controls.Add(btnInvertir);

            return panel;
        }

        private System.Windows.Forms.Button CrearBotonInferior(
            string texto,
            int x,
            int ancho)
        {
            System.Windows.Forms.Button btn = new System.Windows.Forms.Button();
            btn.Text = texto;
            btn.Location = new System.Drawing.Point(x, 6);
            btn.Width = ancho;
            btn.Height = 28;
            return btn;
        }

        // =====================================================
        // COLUMNAS
        // =====================================================

        private void AgregarColumnas()
        {
            dgv.Columns.Clear();

            dgv.Columns.Add(new System.Windows.Forms.DataGridViewTextBoxColumn
            {
                DataPropertyName = "Numero",
                HeaderText = "#",
                Width = 45
            });

            dgv.Columns.Add(new System.Windows.Forms.DataGridViewTextBoxColumn
            {
                DataPropertyName = "IdAValor",
                HeaderText = "Id A",
                Width = 90
            });

            dgv.Columns.Add(new System.Windows.Forms.DataGridViewTextBoxColumn
            {
                DataPropertyName = "CategoriaA",
                HeaderText = "Categoría A",
                Width = 135
            });

            dgv.Columns.Add(new System.Windows.Forms.DataGridViewTextBoxColumn
            {
                DataPropertyName = "NombreA",
                HeaderText = "Elemento A",
                Width = 250
            });

            dgv.Columns.Add(new System.Windows.Forms.DataGridViewTextBoxColumn
            {
                DataPropertyName = "IdBValor",
                HeaderText = "Id B",
                Width = 90
            });

            dgv.Columns.Add(new System.Windows.Forms.DataGridViewTextBoxColumn
            {
                DataPropertyName = "CategoriaB",
                HeaderText = "Categoría B",
                Width = 135
            });

            dgv.Columns.Add(new System.Windows.Forms.DataGridViewTextBoxColumn
            {
                DataPropertyName = "NombreB",
                HeaderText = "Elemento B",
                Width = 250
            });

            dgv.Columns.Add(new System.Windows.Forms.DataGridViewCheckBoxColumn
            {
                Name = "colLevantado",
                DataPropertyName = "Levantado",
                HeaderText = "Levantado",
                Width = 90
            });

            foreach (System.Windows.Forms.DataGridViewColumn col in dgv.Columns)
            {
                col.ReadOnly = true;

                if (col.DataPropertyName == "Levantado")
                    col.ReadOnly = false;
            }
        }

        // =====================================================
        // CARGAR CATEGORÍAS
        // =====================================================

        private void CargarCategorias(System.Collections.Generic.List<CategoriaItem> categorias)
        {
            tvCatA.Nodes.Clear();
            tvCatB.Nodes.Clear();

            if (categorias == null)
                categorias = new System.Collections.Generic.List<CategoriaItem>();

            System.Collections.Generic.List<CategoriaItem> categoriasOrdenadas =
                new System.Collections.Generic.List<CategoriaItem>(categorias);

            categoriasOrdenadas.Sort(delegate (CategoriaItem a, CategoriaItem b)
            {
                string na = a != null && a.Nombre != null ? a.Nombre : "";
                string nb = b != null && b.Nombre != null ? b.Nombre : "";
                return string.Compare(na, nb, true);
            });

            foreach (CategoriaItem cat in categoriasOrdenadas)
            {
                if (cat == null)
                    continue;

                System.Windows.Forms.TreeNode nA = CrearNodoCategoria(cat);
                System.Windows.Forms.TreeNode nB = CrearNodoCategoria(cat);

                tvCatA.Nodes.Add(nA);
                tvCatB.Nodes.Add(nB);
            }

            MarcarCategoriaPorBic(tvCatA, Autodesk.Revit.DB.BuiltInCategory.OST_StructuralFraming, true);
            MarcarCategoriaPorBic(tvCatB, Autodesk.Revit.DB.BuiltInCategory.OST_StructuralFraming, true);
        }

        private System.Windows.Forms.TreeNode CrearNodoCategoria(CategoriaItem cat)
        {
            System.Windows.Forms.TreeNode node =
                new System.Windows.Forms.TreeNode(cat.Nombre);

            node.Tag = cat;
            node.Checked = false;

            return node;
        }

        private System.Collections.Generic.List<CategoriaItem> FiltrarCategoriasVisibles(System.Collections.Generic.List<CategoriaItem> categorias)
        {
            System.Collections.Generic.List<CategoriaItem> filtradas = new System.Collections.Generic.List<CategoriaItem>();

            foreach (CategoriaItem item in categorias)
            {
                if (item == null)
                    continue;

                if (string.IsNullOrWhiteSpace(item.Nombre))
                    continue;

                string n = item.Nombre.Trim();

                if (n.StartsWith("<"))
                    continue;

                if (n.Equals("Activos de materiales", System.StringComparison.OrdinalIgnoreCase))
                    continue;

                if (n.Equals("Información de proyecto", System.StringComparison.OrdinalIgnoreCase))
                    continue;

                if (n.Equals("Materiales", System.StringComparison.OrdinalIgnoreCase))
                    continue;

                if (n.Equals("Origen interno", System.StringComparison.OrdinalIgnoreCase))
                    continue;

                if (n.Equals("Punto base del proyecto", System.StringComparison.OrdinalIgnoreCase))
                    continue;

                if (n.Equals("Punto de reconocimiento", System.StringComparison.OrdinalIgnoreCase))
                    continue;

                if (n.Equals("Cámaras", System.StringComparison.OrdinalIgnoreCase))
                    continue;

                if (n.Equals("Camino de sol", System.StringComparison.OrdinalIgnoreCase))
                    continue;

                if (n.Equals("Líneas", System.StringComparison.OrdinalIgnoreCase))
                    continue;

                if (n.Equals("Niveles", System.StringComparison.OrdinalIgnoreCase))
                    continue;

                if (n.Equals("Rejillas", System.StringComparison.OrdinalIgnoreCase))
                    continue;

                filtradas.Add(item);
            }

            System.Collections.Generic.Dictionary<string, CategoriaItem> unicas =
                new System.Collections.Generic.Dictionary<string, CategoriaItem>(System.StringComparer.OrdinalIgnoreCase);

            foreach (CategoriaItem item in filtradas)
            {
                if (item == null || string.IsNullOrWhiteSpace(item.Nombre))
                    continue;

                if (!unicas.ContainsKey(item.Nombre))
                    unicas.Add(item.Nombre, item);
            }

            System.Collections.Generic.List<CategoriaItem> resultado =
                new System.Collections.Generic.List<CategoriaItem>(unicas.Values);

            resultado.Sort(delegate (CategoriaItem a, CategoriaItem b)
            {
                string na = a != null && a.Nombre != null ? a.Nombre : "";
                string nb = b != null && b.Nombre != null ? b.Nombre : "";
                return string.Compare(na, nb, true);
            });

            return resultado;
        }

        // =====================================================
        // ACCIONES DE TREEVIEW
        // =====================================================

        private bool _actualizandoChecks = false;

        private void TreeAfterCheck(object sender, System.Windows.Forms.TreeViewEventArgs e)
        {
            if (_actualizandoChecks)
                return;

            if (e == null || e.Node == null)
                return;

            try
            {
                _actualizandoChecks = true;

                foreach (System.Windows.Forms.TreeNode child in e.Node.Nodes)
                {
                    child.Checked = e.Node.Checked;
                }
            }
            finally
            {
                _actualizandoChecks = false;
            }
        }

        private void MarcarTodos(System.Windows.Forms.TreeView tree, bool valor)
        {
            if (tree == null)
                return;

            try
            {
                _actualizandoChecks = true;

                foreach (System.Windows.Forms.TreeNode node in tree.Nodes)
                {
                    node.Checked = valor;

                    foreach (System.Windows.Forms.TreeNode child in node.Nodes)
                        child.Checked = valor;
                }
            }
            finally
            {
                _actualizandoChecks = false;
            }
        }

        private void InvertirChecks(System.Windows.Forms.TreeView tree)
        {
            if (tree == null)
                return;

            try
            {
                _actualizandoChecks = true;

                foreach (System.Windows.Forms.TreeNode node in tree.Nodes)
                {
                    node.Checked = !node.Checked;

                    foreach (System.Windows.Forms.TreeNode child in node.Nodes)
                        child.Checked = !child.Checked;
                }
            }
            finally
            {
                _actualizandoChecks = false;
            }
        }

        private void MarcarCategoriaPorBic(
            System.Windows.Forms.TreeView tree,
            Autodesk.Revit.DB.BuiltInCategory bic,
            bool valor)
        {
            if (tree == null)
                return;

            foreach (System.Windows.Forms.TreeNode node in tree.Nodes)
            {
                CategoriaItem item = node.Tag as CategoriaItem;

                if (item != null && item.Bic == bic)
                {
                    node.Checked = valor;
                    return;
                }
            }
        }

        public System.Collections.Generic.List<CategoriaItem> GetCategoriasSeleccionadasA()
        {
            return GetCategoriasSeleccionadas(tvCatA);
        }

        public System.Collections.Generic.List<CategoriaItem> GetCategoriasSeleccionadasB()
        {
            return GetCategoriasSeleccionadas(tvCatB);
        }

        public System.Collections.Generic.List<CategoriaItem> ObtenerCategoriasSeleccionadasA()
        {
            return GetCategoriasSeleccionadasA();
        }

        public System.Collections.Generic.List<CategoriaItem> ObtenerCategoriasSeleccionadasB()
        {
            return GetCategoriasSeleccionadasB();
        }

        private System.Collections.Generic.List<CategoriaItem> GetCategoriasSeleccionadas(System.Windows.Forms.TreeView tree)
        {
            System.Collections.Generic.List<CategoriaItem> lista = new System.Collections.Generic.List<CategoriaItem>();

            if (tree == null)
                return lista;

            foreach (System.Windows.Forms.TreeNode node in tree.Nodes)
            {
                if (!node.Checked)
                    continue;

                CategoriaItem item = node.Tag as CategoriaItem;

                if (item != null)
                    lista.Add(item);
            }

            return lista;
        }

        // =====================================================
        // EXTERNAL EVENT
        // =====================================================

        private void RaiseRequest(MYG_InterferenciasRequest request)
        {
            if (_handler == null || _externalEvent == null)
                return;

            _handler.Request = request;
            _externalEvent.Raise();
        }

        // =====================================================
        // COLOREADO DE FILAS LEVANTADAS EN TIEMPO REAL
        // =====================================================

        private void Dgv_CurrentCellDirtyStateChanged(object sender, System.EventArgs e)
        {
            try
            {
                if (dgv.IsCurrentCellDirty)
                {
                    dgv.CommitEdit(System.Windows.Forms.DataGridViewDataErrorContexts.Commit);
                }
            }
            catch
            {
            }
        }

        private void Dgv_CellValueChanged(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            AplicarColorFilaLevantado(e.RowIndex);
        }

        private void Dgv_DataBindingComplete(object sender, System.Windows.Forms.DataGridViewBindingCompleteEventArgs e)
        {
            AplicarColoresLevantado();
        }

        private void Dgv_RowPrePaint(object sender, System.Windows.Forms.DataGridViewRowPrePaintEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            AplicarColorFilaLevantado(e.RowIndex);
        }

        private void AplicarColoresLevantado()
        {
            if (dgv == null || dgv.Rows == null)
                return;

            foreach (System.Windows.Forms.DataGridViewRow row in dgv.Rows)
            {
                if (row == null || row.IsNewRow)
                    continue;

                AplicarColorFilaLevantado(row.Index);
            }
        }

        private void AplicarColorFilaLevantado(int rowIndex)
        {
            if (dgv == null)
                return;

            if (rowIndex < 0 || rowIndex >= dgv.Rows.Count)
                return;

            System.Windows.Forms.DataGridViewRow row = dgv.Rows[rowIndex];

            if (row == null || row.IsNewRow)
                return;

            ClashInfo info = row.DataBoundItem as ClashInfo;

            bool levantado = false;

            if (info != null)
            {
                levantado = info.Levantado;
            }
            else
            {
                try
                {
                    object valor = row.Cells["colLevantado"].Value;

                    if (valor != null)
                        levantado = System.Convert.ToBoolean(valor);
                }
                catch
                {
                    levantado = false;
                }
            }

            if (levantado)
            {
                row.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(226, 239, 218);
                row.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
                row.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(112, 173, 71);
                row.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            }
            else
            {
                row.DefaultCellStyle.BackColor = System.Drawing.Color.White;
                row.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
                row.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
                row.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            }
        }

        // =====================================================
        // DATA
        // =====================================================

        public ClashInfo GetInterferenciaSeleccionada()
        {
            if (dgv.CurrentRow == null)
                return null;

            return dgv.CurrentRow.DataBoundItem as ClashInfo;
        }

        public System.Collections.Generic.List<ClashInfo> GetTodasLasInterferencias()
        {
            System.Collections.Generic.List<ClashInfo> lista =
                new System.Collections.Generic.List<ClashInfo>();

            if (_data == null)
                return lista;

            foreach (ClashInfo item in _data)
            {
                if (item != null)
                    lista.Add(item);
            }

            return lista;
        }

        public void SetResultados(System.Collections.Generic.List<ClashInfo> resultados)
        {
            if (IsDisposed)
                return;

            System.Action action = delegate
            {
                if (resultados == null)
                    resultados = new System.Collections.Generic.List<ClashInfo>();

                _data = new System.ComponentModel.BindingList<ClashInfo>(resultados);
                dgv.DataSource = _data;
                AplicarColoresLevantado();

                lblEstado.Text = "Interferencias encontradas: " + resultados.Count;
            };

            if (InvokeRequired)
                BeginInvoke(action);
            else
                action();
        }

        public void SetDataCargada(bool dataCargada, string ruta)
        {
            if (IsDisposed)
                return;

            System.Action action = delegate
            {
                _dataCargada = dataCargada;
                _rutaDataCargada = ruta ?? "";

                if (_dataCargada)
                {
                    lblEstado.Text = "Data cargada: " + _rutaDataCargada;
                    btnDetectar.Text = "Evaluar data cargada";
                    btnCargarData.Text = "Descargar data";
                }
                else
                {
                    btnDetectar.Text = "Detectar interferencias";
                    btnCargarData.Text = "Cargar data";
                }
            };

            if (InvokeRequired)
                BeginInvoke(action);
            else
                action();
        }

        public void SetEstado(string texto)
        {
            if (IsDisposed)
                return;

            System.Action action = delegate
            {
                lblEstado.Text = texto;
            };

            if (InvokeRequired)
                BeginInvoke(action);
            else
                action();
        }
    }

}
