﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using MYG_Addin;
using System.Collections.Generic;
using System.Linq;

public class EjecutarCopiarParametrosHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public CopiarParametrosForm Form;
    public SeleccionarElementosCopiarParametrosHandler SeleccionHandler;

    public void Execute(UIApplication app)
    {
        Document doc = UiDoc.Document;

        string parametroOrigen = Form.ParametroOrigen;

        List<string> parametrosDestino = new List<string>()
        {
            Form.ParametroDestino1,
            Form.ParametroDestino2
        }
        .Where(x => !string.IsNullOrWhiteSpace(x))
        .ToList();

        if (parametrosDestino.Count == 0)
        {
            TaskDialog.Show("Error", "Debe ingresar al menos un parámetro destino.");
            return;
        }

        var referencias = SeleccionHandler.ElementosSeleccionados;

        if (referencias == null || referencias.Count == 0)
        {
            TaskDialog.Show("Error", "Debe seleccionar elementos primero.");
            return;
        }

        int contador = 0;

        using (Transaction t = new Transaction(doc, "Copiar parámetros"))
        {
            t.Start();

            foreach (ElementId id in referencias)
            {
                Element elem = doc.GetElement(id);

                Parameter pOrigen = elem.LookupParameter(parametroOrigen);

                if (pOrigen == null)
                    continue;

                string valor = pOrigen.AsString();

                if (string.IsNullOrEmpty(valor))
                    continue;

                foreach (string nombreDestino in parametrosDestino)
                {
                    Parameter pDestino = elem.LookupParameter(nombreDestino);

                    if (pDestino == null)
                        continue;

                    if (pDestino.IsReadOnly)
                        continue;

                    pDestino.Set(valor);
                }

                contador++;
            }

            t.Commit();
        }

        TaskDialog.Show("MYG",
            contador + " elementos actualizados correctamente.");
    }

    public string GetName() => "Ejecutar copiar parámetros";
}