﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using MYG_Addin;
using System.Collections.Generic;
using System.Linq;

public class SeleccionarElementosCopiarParametrosHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public CopiarParametrosForm Form;
    public List<ElementId> ElementosSeleccionados = new List<ElementId>();

    public void Execute(UIApplication app)
    {
        try
        {
            // 🔥 LIMPIAR SELECCION PREVIA
            UiDoc.Selection.SetElementIds(new List<ElementId>());
            Form?.ActualizarCantidad(0);

            IList<Reference> refs;

            if (Form != null && Form.AplicarFiltro &&
                !string.IsNullOrEmpty(Form.CategoriaSeleccionada))
            {
                refs = UiDoc.Selection.PickObjects(
                    Autodesk.Revit.UI.Selection.ObjectType.Element,
                    new FiltroInterno(Form.CategoriaSeleccionada),
                    "Seleccione elementos filtrados");
            }
            else
            {
                refs = UiDoc.Selection.PickObjects(
                    Autodesk.Revit.UI.Selection.ObjectType.Element,
                    "Seleccione los elementos");
            }

            // 🔥 GUARDAR ELEMENTOS SELECCIONADOS
            ElementosSeleccionados = refs
                .Select(r => r.ElementId)
                .ToList();

            // 🔥 ACTUALIZAR CONTADOR
            Form?.ActualizarCantidad(ElementosSeleccionados.Count);
        }
        catch
        {
            // Usuario canceló la selección
        }
    }

    public string GetName() => "Seleccionar elementos copiar parámetros";
}

class FiltroInterno : Autodesk.Revit.UI.Selection.ISelectionFilter
{
    private string categoria;

    public FiltroInterno(string categoriaSeleccionada)
    {
        categoria = categoriaSeleccionada;
    }

    public bool AllowElement(Element elem)
    {
        return elem.Category != null &&
               elem.Category.Name == categoria;
    }

    public bool AllowReference(Reference reference, XYZ position)
    {
        return true;
    }
}