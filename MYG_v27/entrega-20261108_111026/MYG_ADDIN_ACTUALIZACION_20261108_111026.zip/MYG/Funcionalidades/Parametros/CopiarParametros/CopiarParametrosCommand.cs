using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{


    // ===============================
    // COMANDO 4 (COPIAR PARAMETROS)
    // ===============================

    [Transaction(TransactionMode.Manual)]
    public class CopiarParametrosCommand : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            if (!global::MYG_Addin.MYG_ControlAccesoComandos.Comprobar())
                return Autodesk.Revit.UI.Result.Cancelled;

            UIDocument uidoc = commandData.Application.ActiveUIDocument;
            Document doc = uidoc.Document;

            //-------------------------------------------------
            // MOSTRAR VENTANA
            //-------------------------------------------------

            CopiarParametrosForm form = new CopiarParametrosForm();

            // ===== LLENAR COMBO DE CATEGORIAS =====
            var categorias = doc.Settings.Categories
                .Cast<Category>()
                .Where(c => c.CategoryType == CategoryType.Model)
                .OrderBy(c => c.Name)
                .Select(c => c.Name)
                .ToList();

            form.cmbCategorias.Items.AddRange(categorias.ToArray());
            form.categoriasOriginales = categorias;

            // ===== HANDLER SELECCIONAR =====
            var handler = new SeleccionarElementosCopiarParametrosHandler();
            handler.UiDoc = uidoc;

            handler.Form = form;

            var externalEvent = ExternalEvent.Create(handler);

            form.SeleccionarHandler = handler;
            form.SeleccionarEvent = externalEvent;

            // ===== HANDLER EJECUTAR =====
            var ejecutarHandler = new EjecutarCopiarParametrosHandler();
            ejecutarHandler.UiDoc = uidoc;
            ejecutarHandler.Form = form;
            ejecutarHandler.SeleccionHandler = handler;

            var ejecutarEvent = ExternalEvent.Create(ejecutarHandler);

            form.EjecutarHandler = ejecutarHandler;
            form.EjecutarEvent = ejecutarEvent;

            // ===== MOSTRAR =====
            form.Show();

            return Result.Succeeded;
        }
    }

}
