using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{


    // =====================================
    // VENTANA EMERGENTE 4 (COPIAR PARAMETROS)
    // =====================================
    public class CopiarParametrosForm : WinForms.Form
    {
        public string ParametroOrigen => txtOrigen.Text;
        public string ParametroDestino1 => txtDestino1.Text;
        public string ParametroDestino2 => txtDestino2.Text;

        WinForms.TextBox txtOrigen;
        WinForms.TextBox txtDestino1;
        WinForms.TextBox txtDestino2;
        WinForms.CheckBox chkFiltro;
        public WinForms.ComboBox cmbCategorias;
        WinForms.Label lblCantidad;
        public List<string> categoriasOriginales = new List<string>();
        bool borrarTextoCombo = false;


        WinForms.Button btnEjecutar;

        public WinForms.Button btnSeleccionar;
        public ExternalEvent SeleccionarEvent;
        public SeleccionarElementosCopiarParametrosHandler SeleccionarHandler;
        public ExternalEvent EjecutarEvent;
        public EjecutarCopiarParametrosHandler EjecutarHandler;
        public bool AplicarFiltro => chkFiltro.Checked;
        public string CategoriaSeleccionada => cmbCategorias.SelectedItem?.ToString();

        public CopiarParametrosForm()
        {
            this.Text = "📋 Copiar Parámetros";
            this.Width = 400;
            this.Height = 450;
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new Drawing.Font("Segoe UI", 9F);

            this.TopMost = true;

            // ===== AUTOR =====
            var lblAutor = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                Left = 20,
                Top = 5,
                Width = 340,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.Gray
            };

            // ===== ORIGEN =====
            var lblOrigen = new WinForms.Label()
            {
                Text = "01. PARÁMETRO ORIGEN",
                Left = 20,
                Top = 30,
                Width = 250,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtOrigen = new WinForms.TextBox()
            {
                Left = 20,
                Top = 55,
                Width = 340,
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };
            txtOrigen.TabIndex = 0;

            // ===== DESTINO 1 =====
            var lblDestino1 = new WinForms.Label()
            {
                Text = "02. PARÁMETRO DESTINO 1",
                Left = 20,
                Top = 95,
                Width = 250,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtDestino1 = new WinForms.TextBox()
            {
                Left = 20,
                Top = 120,
                Width = 340,
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };
            txtDestino1.TabIndex = 1;

            // ===== DESTINO 2 =====
            var lblDestino2 = new WinForms.Label()
            {
                Text = "03. PARÁMETRO DESTINO 2",
                Left = 20,
                Top = 160,
                Width = 250,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtDestino2 = new WinForms.TextBox()
            {
                Left = 20,
                Top = 185,
                Width = 340,
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };

            txtDestino2.TabIndex = 2;

            // ===== CHECK FILTRO =====
            chkFiltro = new WinForms.CheckBox()
            {
                Text = "Aplicar Filtro",
                Left = 20,
                Top = 215,
                Width = 150
            };

            chkFiltro.TabIndex = 3;

            // ===== COMBO CATEGORIAS =====
            cmbCategorias = new WinForms.ComboBox()
            {
                Left = 20,
                Top = 240,
                Width = 340,
                DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                Enabled = false,
                MaxDropDownItems = 6,
                IntegralHeight = false
            };

            cmbCategorias.AutoCompleteMode = WinForms.AutoCompleteMode.None;
            cmbCategorias.AutoCompleteSource = WinForms.AutoCompleteSource.None;

            cmbCategorias.Enter += (s, e) =>
            {
                cmbCategorias.SelectAll();
                borrarTextoCombo = true;
            };

            cmbCategorias.MouseClick += (s, e) =>
            {
                cmbCategorias.SelectAll();
                borrarTextoCombo = true;
            };

            cmbCategorias.KeyDown += (s, e) =>
            {
                if (borrarTextoCombo && !char.IsControl((char)e.KeyCode))
                {
                    cmbCategorias.SelectedIndex = -1;
                    cmbCategorias.Text = "";
                    borrarTextoCombo = false;
                }
            };
            // ===== FIN =====

            cmbCategorias.KeyUp += (s, e) =>
            {
                if (e.KeyCode == WinForms.Keys.Up || e.KeyCode == WinForms.Keys.Down)
                    return;

                string texto = cmbCategorias.Text;

                var filtrados = string.IsNullOrWhiteSpace(texto)
                    ? categoriasOriginales
                    : categoriasOriginales
                        .Where(x => x.IndexOf(texto, StringComparison.OrdinalIgnoreCase) >= 0)
                        .ToList();

                cmbCategorias.BeginUpdate();
                cmbCategorias.Items.Clear();

                if (filtrados.Count > 0)
                {
                    cmbCategorias.Items.AddRange(filtrados.ToArray());
                    cmbCategorias.DroppedDown = true;
                }
                else
                {
                    cmbCategorias.DroppedDown = false;
                }

                cmbCategorias.EndUpdate();

                // 🔥 ESTO ES LO QUE EVITA TODOS LOS BUGS
                cmbCategorias.SelectionStart = cmbCategorias.Text.Length;
                cmbCategorias.SelectionLength = 0;
            };


            cmbCategorias.TabIndex = 4;
            // Activar / desactivar combo
            chkFiltro.CheckedChanged += (s, e) =>
            {
                cmbCategorias.Enabled = chkFiltro.Checked;
            };


            // ===== BOTON SELECCIONAR =====
            btnSeleccionar = new WinForms.Button()
            {
                Text = "SELECCIONAR ELEMENTOS",
                Width = 340,
                Height = 34,
                Left = 20,
                Top = 280,
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };
            btnSeleccionar.TabIndex = 5;

            btnSeleccionar.FlatAppearance.BorderSize = 0;

            btnSeleccionar.Click += (s, e) =>
            {
                SeleccionarEvent?.Raise();
            };

            // ===== BOTON EJECUTAR =====
            btnEjecutar = new WinForms.Button()
            {
                Text = "EJECUTAR",
                Width = 180,
                Height = 34,
                Left = 100,
                Top = 350,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnEjecutar.TabIndex = 6;

            btnEjecutar.FlatAppearance.BorderSize = 0;
            btnEjecutar.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(0, 100, 190);
            btnEjecutar.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(0, 84, 160);

            btnEjecutar.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtOrigen.Text))
                {
                    WinForms.MessageBox.Show(
                        "Debe ingresar el parámetro origen",
                        "MYG",
                        WinForms.MessageBoxButtons.OK,
                        WinForms.MessageBoxIcon.Warning);

                    return;
                }

                this.EjecutarEvent?.Raise();

                GuardarConfiguracion();

                this.DialogResult = WinForms.DialogResult.OK;
            };

            // ENTER ejecuta
            this.AcceptButton = btnEjecutar;

            // ===== AGREGAR CONTROLES =====
            Controls.Add(lblAutor);

            Controls.Add(lblOrigen);
            Controls.Add(txtOrigen);

            Controls.Add(lblDestino1);
            Controls.Add(txtDestino1);

            Controls.Add(lblDestino2);
            Controls.Add(txtDestino2);

            Controls.Add(btnEjecutar);
            Controls.Add(btnSeleccionar);

            Controls.Add(chkFiltro);
            Controls.Add(cmbCategorias);

            this.ActiveControl = txtOrigen;

            // ===== LABEL CANTIDAD =====
            lblCantidad = new WinForms.Label()
            {
                Text = "Elementos seleccionados: 0",
                Left = 20,
                Top = 320,
                Width = 340,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            Controls.Add(lblCantidad);

            // ===== GUARDAR CONFIGURACIÓN AL CERRAR =====
            this.FormClosing += (s, e) =>
            {
                GuardarConfiguracion();
            };

            // ===== CARGAR CONFIGURACIÓN GUARDADA =====
            txtOrigen.Text = MYG.Properties.Settings.Default.V4ParamOrigen;
            txtDestino1.Text = MYG.Properties.Settings.Default.V4ParamDestino1;
            txtDestino2.Text = MYG.Properties.Settings.Default.V4ParamDestino2;

            chkFiltro.Checked = MYG.Properties.Settings.Default.V4AplicarFiltro;

            // activar/desactivar combo
            cmbCategorias.Enabled = chkFiltro.Checked;

            // cargar categoría
            cmbCategorias.Text = MYG.Properties.Settings.Default.V4Categoria;

        }

        private void GuardarConfiguracion()
        {
            MYG.Properties.Settings.Default.V4ParamOrigen = txtOrigen.Text;
            MYG.Properties.Settings.Default.V4ParamDestino1 = txtDestino1.Text;
            MYG.Properties.Settings.Default.V4ParamDestino2 = txtDestino2.Text;

            MYG.Properties.Settings.Default.V4AplicarFiltro = chkFiltro.Checked;
            MYG.Properties.Settings.Default.V4Categoria = cmbCategorias.Text;

            MYG.Properties.Settings.Default.Save();
        }
        public void ActualizarCantidad(int cantidad)
        {
            lblCantidad.Text = $"Elementos seleccionados: {cantidad}";
        }
    }

}
