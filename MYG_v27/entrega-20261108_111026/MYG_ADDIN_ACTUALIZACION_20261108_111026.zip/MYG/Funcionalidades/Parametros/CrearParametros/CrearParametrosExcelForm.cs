using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =====================================
    // VENTANA 2.3 - CREAR PARÁMETROS DESDE EXCEL
    // =====================================

    public class CrearParametrosExcelForm : WinForms.Form
    {
        private WinForms.TextBox txtRutaExcel;
        private WinForms.Button btnBuscarExcel;
        private WinForms.Button btnLeerExcel;
        private WinForms.Button btnEjecutar;
        private WinForms.Button btnAbrirTxt;
        private WinForms.CheckBox chkActualizarExistentes;
        private WinForms.RichTextBox txtResultado;

        private WinForms.CheckBox chkGeneral;
        private WinForms.CheckBox chkEstructura;
        private WinForms.CheckBox chkArquitectura;
        private WinForms.CheckBox chkSanitarias;
        private WinForms.CheckBox chkElectricas;
        private WinForms.CheckBox chkMecanicas;
        private WinForms.CheckBox chkObrasProvisionales;

        public ExternalEvent EjecutarEvent;

        public string RutaExcel => txtRutaExcel.Text;
        public bool ActualizarExistentes => chkActualizarExistentes.Checked;

        // TRUE = solo lee Excel
        // FALSE = crea parámetros
        public bool SoloLeerExcel { get; private set; } = true;

        public System.Collections.Generic.List<string> EspecialidadesSeleccionadas
        {
            get
            {
                System.Collections.Generic.List<string> lista =
                    new System.Collections.Generic.List<string>();

                if (chkGeneral.Checked)
                    lista.Add("GENERAL");

                if (chkEstructura.Checked)
                    lista.Add("ESTRUCTURA");

                if (chkArquitectura.Checked)
                    lista.Add("ARQUITECTURA");

                if (chkSanitarias.Checked)
                    lista.Add("SANITARIAS");

                if (chkElectricas.Checked)
                    lista.Add("ELECTRICAS");

                if (chkMecanicas.Checked)
                    lista.Add("MECANICAS");

                if (chkObrasProvisionales.Checked)
                    lista.Add("OBRAS PROVISIONALES");

                return lista;
            }
        }

        public CrearParametrosExcelForm()
        {
            this.Text = "📘 Crear Parámetros desde Excel";
            this.Width = 540;
            this.Height = 640;
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Drawing.Color.FromArgb(245, 247, 250);
            this.Font = new Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;

            // ===== AUTOR =====
            WinForms.Label lblAutor = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila  |  CIP: 294466",
                Left = 20,
                Top = 8,
                Width = 480,
                Font = new Drawing.Font("Segoe UI", 8.5F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.Gray
            };

            // ===== TITULO =====
            WinForms.Label lblTitulo = new WinForms.Label()
            {
                Text = "01. SELECCIONAR ARCHIVO EXCEL",
                Left = 20,
                Top = 38,
                Width = 440,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtRutaExcel = new WinForms.TextBox()
            {
                Left = 20,
                Top = 65,
                Width = 370,
                Height = 24,
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };

            btnBuscarExcel = new WinForms.Button()
            {
                Text = "...",
                Width = 45,
                Height = 25,
                Left = 400,
                Top = 64,
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnBuscarExcel.FlatAppearance.BorderSize = 0;

            btnBuscarExcel.Click += (s, e) =>
            {
                using (WinForms.OpenFileDialog ofd = new WinForms.OpenFileDialog())
                {
                    ofd.Title = "Seleccionar Excel de parámetros";
                    ofd.Filter = "Archivos Excel (*.xlsx)|*.xlsx";
                    ofd.Multiselect = false;

                    if (ofd.ShowDialog() == WinForms.DialogResult.OK)
                    {
                        txtRutaExcel.Text = ofd.FileName;
                        MostrarResultado("Archivo seleccionado:\r\n" + ofd.FileName);

                        GuardarConfiguracion();
                    }
                }
            };

            // ===== CHECK ACTUALIZAR =====
            chkActualizarExistentes = new WinForms.CheckBox()
            {
                Text = "Actualizar parámetro si ya existe en el proyecto",
                Left = 20,
                Top = 105,
                Width = 440,
                Checked = true,
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            chkActualizarExistentes.CheckedChanged += (s, e) =>
            {
                GuardarConfiguracion();
            };

            // ===== ESPECIALIDADES =====
            WinForms.Label lblEspecialidades = new WinForms.Label()
            {
                Text = "02. FILTRAR POR ESPECIALIDAD",
                Left = 20,
                Top = 135,
                Width = 440,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            chkGeneral = new WinForms.CheckBox()
            {
                Text = "General",
                Left = 20,
                Top = 162,
                Width = 105,
                Checked = true
            };

            chkEstructura = new WinForms.CheckBox()
            {
                Text = "Estructura",
                Left = 145,
                Top = 162,
                Width = 115,
                Checked = true
            };

            chkArquitectura = new WinForms.CheckBox()
            {
                Text = "Arquitectura",
                Left = 280,
                Top = 162,
                Width = 130,
                Checked = true
            };

            chkSanitarias = new WinForms.CheckBox()
            {
                Text = "Sanitarias",
                Left = 20,
                Top = 187,
                Width = 105,
                Checked = true
            };

            chkElectricas = new WinForms.CheckBox()
            {
                Text = "Eléctricas",
                Left = 145,
                Top = 187,
                Width = 115,
                Checked = true
            };

            chkMecanicas = new WinForms.CheckBox()
            {
                Text = "Mecánicas",
                Left = 280,
                Top = 187,
                Width = 130,
                Checked = true
            };

            chkObrasProvisionales = new WinForms.CheckBox()
            {
                Text = "Obras Provisionales",
                Left = 20,
                Top = 212,
                Width = 180,
                Checked = true
            };

            chkGeneral.CheckedChanged += (s, e) => { GuardarConfiguracion(); };
            chkEstructura.CheckedChanged += (s, e) => { GuardarConfiguracion(); };
            chkArquitectura.CheckedChanged += (s, e) => { GuardarConfiguracion(); };
            chkSanitarias.CheckedChanged += (s, e) => { GuardarConfiguracion(); };
            chkElectricas.CheckedChanged += (s, e) => { GuardarConfiguracion(); };
            chkMecanicas.CheckedChanged += (s, e) => { GuardarConfiguracion(); };
            chkObrasProvisionales.CheckedChanged += (s, e) => { GuardarConfiguracion(); };

            // ===== NOTA =====
            WinForms.Label lblNota = new WinForms.Label()
            {
                Text =
                    "El Excel debe tener una hoja llamada PARAMETROS.\n" +
                    "La columna A debe llamarse ESPECIALIDAD.\n" +
                    "Ejemplos: GENERAL, ESTRUCTURA, ARQUITECTURA,\n" +
                    "SANITARIAS, ELECTRICAS, MECANICAS,\n" +
                    "OBRAS PROVISIONALES.",
                Left = 20,
                Top = 245,
                Width = 370,
                Height = 90,
                ForeColor = Drawing.Color.FromArgb(80, 80, 80)
            };

            // ===== BOTON ABRIR UBICACIÓN TXT =====
            btnAbrirTxt = new WinForms.Button()
            {
                Text = "ABRIR TXT",
                Width = 95,
                Height = 26,
                Left = 405,
                Top = 280,
                BackColor = Drawing.Color.FromArgb(90, 90, 90),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 8F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnAbrirTxt.FlatAppearance.BorderSize = 0;

            btnAbrirTxt.Click += (s, e) =>
            {
                AbrirUbicacionArchivoTxt();
            };

            // ===== RESULTADO =====
            WinForms.Label lblResultado = new WinForms.Label()
            {
                Text = "03. RESULTADO / PREVISUALIZACIÓN",
                Left = 20,
                Top = 335,
                Width = 440,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = Drawing.Color.FromArgb(50, 50, 50)
            };

            txtResultado = new WinForms.RichTextBox()
            {
                Left = 20,
                Top = 360,
                Width = 480,
                Height = 145,
                Multiline = true,
                ScrollBars = WinForms.RichTextBoxScrollBars.Vertical,
                ReadOnly = true,
                BorderStyle = WinForms.BorderStyle.FixedSingle,
                BackColor = Drawing.Color.White,
                Font = new Drawing.Font("Consolas", 8.5F),
                WordWrap = false,
                ShortcutsEnabled = true,
                HideSelection = false,
                DetectUrls = false
            };

            // ===== MENÚ CLIC DERECHO PARA COPIAR =====
            WinForms.ContextMenuStrip menuResultado = new WinForms.ContextMenuStrip();

            WinForms.ToolStripMenuItem itemCopiar = new WinForms.ToolStripMenuItem("Copiar");
            itemCopiar.Click += (s, e) =>
            {
                if (!string.IsNullOrEmpty(txtResultado.SelectedText))
                    txtResultado.Copy();
            };

            WinForms.ToolStripMenuItem itemSeleccionarTodo = new WinForms.ToolStripMenuItem("Seleccionar todo");
            itemSeleccionarTodo.Click += (s, e) =>
            {
                txtResultado.SelectAll();
            };

            WinForms.ToolStripMenuItem itemCopiarTodo = new WinForms.ToolStripMenuItem("Copiar todo");
            itemCopiarTodo.Click += (s, e) =>
            {
                if (!string.IsNullOrWhiteSpace(txtResultado.Text))
                    WinForms.Clipboard.SetText(txtResultado.Text);
            };

            menuResultado.Items.Add(itemCopiar);
            menuResultado.Items.Add(itemSeleccionarTodo);
            menuResultado.Items.Add(itemCopiarTodo);

            txtResultado.ContextMenuStrip = menuResultado;

            // ===== BOTON LEER EXCEL =====
            btnLeerExcel = new WinForms.Button()
            {
                Text = "LEER EXCEL",
                Width = 180,
                Height = 36,
                Left = 80,
                Top = 535,
                BackColor = Drawing.Color.FromArgb(100, 100, 100),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnLeerExcel.FlatAppearance.BorderSize = 0;

            btnLeerExcel.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtRutaExcel.Text))
                {
                    MostrarResultado("Debe seleccionar un archivo Excel antes de leer.");
                    return;
                }

                if (EspecialidadesSeleccionadas.Count == 0)
                {
                    MostrarResultado("Debe seleccionar al menos una especialidad.");
                    return;
                }

                SoloLeerExcel = true;
                MostrarResultado("Leyendo Excel...");

                GuardarConfiguracion();

                EjecutarEvent?.Raise();
            };

            // ===== BOTON CREAR PARÁMETROS =====
            btnEjecutar = new WinForms.Button()
            {
                Text = "CREAR PARÁMETROS",
                Width = 180,
                Height = 36,
                Left = 280,
                Top = 535,
                BackColor = Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnEjecutar.FlatAppearance.BorderSize = 0;
            btnEjecutar.FlatAppearance.MouseOverBackColor = Drawing.Color.FromArgb(0, 100, 190);
            btnEjecutar.FlatAppearance.MouseDownBackColor = Drawing.Color.FromArgb(0, 84, 160);

            btnEjecutar.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtRutaExcel.Text))
                {
                    MostrarResultado("Debe seleccionar un archivo Excel antes de crear parámetros.");
                    return;
                }

                if (EspecialidadesSeleccionadas.Count == 0)
                {
                    MostrarResultado("Debe seleccionar al menos una especialidad.");
                    return;
                }

                SoloLeerExcel = false;
                MostrarResultado("Creando parámetros...");

                GuardarConfiguracion();

                EjecutarEvent?.Raise();
            };

            // ===== AGREGAR CONTROLES =====
            Controls.Add(lblAutor);
            Controls.Add(lblTitulo);
            Controls.Add(txtRutaExcel);
            Controls.Add(btnBuscarExcel);
            Controls.Add(chkActualizarExistentes);

            Controls.Add(lblEspecialidades);
            Controls.Add(chkGeneral);
            Controls.Add(chkEstructura);
            Controls.Add(chkArquitectura);
            Controls.Add(chkSanitarias);
            Controls.Add(chkElectricas);
            Controls.Add(chkMecanicas);
            Controls.Add(chkObrasProvisionales);

            Controls.Add(lblNota);
            Controls.Add(btnAbrirTxt);
            Controls.Add(lblResultado);
            Controls.Add(txtResultado);
            Controls.Add(btnLeerExcel);
            Controls.Add(btnEjecutar);

            // ===== CARGAR CONFIGURACIÓN GUARDADA =====
            CargarConfiguracion();

            // ===== GUARDAR CONFIGURACIÓN AL CERRAR =====
            this.FormClosing += (s, e) =>
            {
                GuardarConfiguracion();
            };
        }

        private void CargarConfiguracion()
        {
            try
            {
                txtRutaExcel.Text = MYG.Properties.Settings.Default.V23RutaExcel;
                chkActualizarExistentes.Checked = MYG.Properties.Settings.Default.V23ActualizarExistentes;

                chkGeneral.Checked = MYG.Properties.Settings.Default.V23FiltroGeneral;
                chkEstructura.Checked = MYG.Properties.Settings.Default.V23FiltroEstructura;
                chkArquitectura.Checked = MYG.Properties.Settings.Default.V23FiltroArquitectura;
                chkSanitarias.Checked = MYG.Properties.Settings.Default.V23FiltroSanitarias;
                chkElectricas.Checked = MYG.Properties.Settings.Default.V23FiltroElectricas;
                chkMecanicas.Checked = MYG.Properties.Settings.Default.V23FiltroMecanicas;

                // Este nuevo check queda activo por defecto.
                // No se usa Settings strongly typed para evitar errores si aún no creaste V23FiltroObrasProvisionales.
                chkObrasProvisionales.Checked = true;

                if (!string.IsNullOrWhiteSpace(txtRutaExcel.Text))
                {
                    MostrarResultado("Último archivo usado:\r\n" + txtRutaExcel.Text);
                }
            }
            catch
            {
            }
        }

        private void GuardarConfiguracion()
        {
            try
            {
                MYG.Properties.Settings.Default.V23RutaExcel = txtRutaExcel.Text;
                MYG.Properties.Settings.Default.V23ActualizarExistentes = chkActualizarExistentes.Checked;

                MYG.Properties.Settings.Default.V23FiltroGeneral = chkGeneral.Checked;
                MYG.Properties.Settings.Default.V23FiltroEstructura = chkEstructura.Checked;
                MYG.Properties.Settings.Default.V23FiltroArquitectura = chkArquitectura.Checked;
                MYG.Properties.Settings.Default.V23FiltroSanitarias = chkSanitarias.Checked;
                MYG.Properties.Settings.Default.V23FiltroElectricas = chkElectricas.Checked;
                MYG.Properties.Settings.Default.V23FiltroMecanicas = chkMecanicas.Checked;

                MYG.Properties.Settings.Default.Save();
            }
            catch
            {
            }
        }

        private void AbrirUbicacionArchivoTxt()
        {
            try
            {
                string carpeta = System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "MYG");

                string rutaTxt = System.IO.Path.Combine(
                    carpeta,
                    "MYG_ParametrosCompartidos_Excel.txt");

                if (!System.IO.Directory.Exists(carpeta))
                    System.IO.Directory.CreateDirectory(carpeta);

                if (System.IO.File.Exists(rutaTxt))
                {
                    System.Diagnostics.Process.Start(
                        "explorer.exe",
                        "/select,\"" + rutaTxt + "\"");
                }
                else
                {
                    System.Diagnostics.Process.Start(
                        "explorer.exe",
                        "\"" + carpeta + "\"");

                    MostrarResultado(
                        "Todavía no existe el archivo TXT de parámetros compartidos.\r\n\r\n" +
                        "Ubicación esperada:\r\n" +
                        rutaTxt + "\r\n\r\n" +
                        "Se creará automáticamente cuando ejecutes CREAR PARÁMETROS.");
                }
            }
            catch (Exception ex)
            {
                MostrarResultado(
                    "No se pudo abrir la ubicación del archivo TXT.\r\n\r\n" +
                    ex.Message);
            }
        }

        public void MostrarResultado(string texto)
        {
            if (txtResultado == null || txtResultado.IsDisposed)
                return;

            txtResultado.Clear();

            string[] lineas = texto.Replace("\r\n", "\n").Split('\n');

            foreach (string linea in lineas)
            {
                if (string.IsNullOrWhiteSpace(linea))
                {
                    txtResultado.AppendText(Environment.NewLine);
                    continue;
                }

                bool esLineaParametro = linea.Contains("|");

                bool esOk =
                    linea.Trim().EndsWith("| OK", StringComparison.OrdinalIgnoreCase) ||
                    linea.Trim().Contains("| OK");

                if (esLineaParametro && !esOk)
                {
                    txtResultado.SelectionColor = Drawing.Color.Red;
                    txtResultado.SelectionFont = new Drawing.Font("Consolas", 8.5F, Drawing.FontStyle.Bold);
                }
                else if (esLineaParametro && esOk)
                {
                    txtResultado.SelectionColor = Drawing.Color.FromArgb(30, 120, 30);
                    txtResultado.SelectionFont = new Drawing.Font("Consolas", 8.5F, Drawing.FontStyle.Regular);
                }
                else
                {
                    txtResultado.SelectionColor = Drawing.Color.FromArgb(50, 50, 50);
                    txtResultado.SelectionFont = new Drawing.Font("Consolas", 8.5F, Drawing.FontStyle.Bold);
                }

                txtResultado.AppendText(linea + Environment.NewLine);
            }

            txtResultado.SelectionStart = 0;
            txtResultado.ScrollToCaret();
        }
    }

}
