﻿// =====================================
// HANDLER EXTERNO 2.3
// CREAR PARÁMETROS COMPARTIDOS DESDE EXCEL
// COMO PARÁMETROS DE PROYECTO
// FILTRO POR ESPECIALIDAD
// SIN VENTANAS EMERGENTES
// CORREGIDO PARA REVIT 2027
// =====================================

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using DBApplication = Autodesk.Revit.ApplicationServices.Application;

namespace MYG_Addin
{
    public class EjecutarCrearParametrosExcelHandler : IExternalEventHandler
    {
        public UIDocument UiDoc { get; set; }
        public CrearParametrosExcelForm Form { get; set; }

        public string GetName()
        {
            return "MYG - Crear parámetros desde Excel";
        }

        public void Execute(UIApplication app)
        {
            if (UiDoc == null || UiDoc.Document == null)
                return;

            if (Form == null)
                return;

            Document doc = UiDoc.Document;
            DBApplication revitApp = app.Application;

            string rutaExcel = Form.RutaExcel;

            if (string.IsNullOrWhiteSpace(rutaExcel) || !File.Exists(rutaExcel))
            {
                MostrarEnVentana("No se encontró el archivo Excel seleccionado.");
                return;
            }

            string rutaCompartidosAnterior = revitApp.SharedParametersFilename;

            int creados = 0;
            int actualizados = 0;
            int omitidos = 0;
            int errores = 0;

            StringBuilder reporte = new StringBuilder();

            try
            {
                ConfigurarLicenciaEpplus();

                List<ParametroExcelMYG> parametrosLeidos = LeerParametrosDesdeExcel(rutaExcel);

                if (parametrosLeidos.Count == 0)
                {
                    MostrarEnVentana(
                        "No se encontraron parámetros válidos en el Excel.\r\n\r\n" +
                        "Verifica que exista una hoja llamada PARAMETROS y que tenga columnas como:\r\n" +
                        "ESPECIALIDAD, NOMBRE_PARAMETRO, TIPO_DATO, CATEGORIAS, TIPO_BINDING, GRUPO_REVIT.");

                    return;
                }

                List<string> especialidadesSeleccionadas = Form.EspecialidadesSeleccionadas;

                List<ParametroExcelMYG> parametros = FiltrarPorEspecialidad(
                    parametrosLeidos,
                    especialidadesSeleccionadas);

                if (parametros.Count == 0)
                {
                    MostrarEnVentana(
                        "No hay parámetros para las especialidades seleccionadas.\r\n\r\n" +
                        "Especialidades seleccionadas:\r\n" +
                        string.Join(", ", especialidadesSeleccionadas) +
                        "\r\n\r\nVerifica que la columna A se llame ESPECIALIDAD y que sus valores sean:\r\n" +
                        "GENERAL, ESTRUCTURA, ARQUITECTURA, SANITARIAS, ELECTRICAS o MECANICAS.");

                    return;
                }

                // =========================================================
                // SOLO LEER EXCEL / PREVISUALIZAR
                // =========================================================
                if (Form.SoloLeerExcel)
                {
                    string vistaPrevia = GenerarVistaPreviaParametros(
                        doc,
                        parametros,
                        parametrosLeidos.Count,
                        especialidadesSeleccionadas);

                    MostrarEnVentana(vistaPrevia);
                    return;
                }

                // =========================================================
                // CREAR TXT TEMPORAL LIMPIO
                // IMPORTANTE:
                // true = borra/regenera el TXT para que no queden parámetros antiguos
                // =========================================================

                string rutaSharedTemporal = ObtenerRutaArchivoCompartidosTemporal(true);

                revitApp.SharedParametersFilename = rutaSharedTemporal;

                DefinitionFile defFile = revitApp.OpenSharedParameterFile();

                if (defFile == null)
                {
                    MostrarEnVentana("No se pudo abrir el archivo temporal de parámetros compartidos.");
                    return;
                }

                using (Transaction trans = new Transaction(doc, "MYG - Crear parámetros desde Excel"))
                {
                    trans.Start();

                    foreach (ParametroExcelMYG fila in parametros)
                    {
                        try
                        {
                            if (string.IsNullOrWhiteSpace(fila.NombreParametro))
                            {
                                omitidos++;
                                reporte.AppendLine("Fila " + fila.FilaExcel + ": omitida porque no tiene nombre de parámetro.");
                                continue;
                            }

                            if (string.IsNullOrWhiteSpace(fila.CategoriasTexto))
                            {
                                omitidos++;
                                reporte.AppendLine("Fila " + fila.FilaExcel + ": " + fila.NombreParametro + " omitido porque no tiene categorías.");
                                continue;
                            }

                            List<Category> categorias = ObtenerCategorias(
                                doc,
                                fila.CategoriasTexto,
                                reporte,
                                fila.FilaExcel);

                            if (categorias.Count == 0)
                            {
                                omitidos++;
                                reporte.AppendLine("Fila " + fila.FilaExcel + ": " + fila.NombreParametro + " omitido porque no se encontró ninguna categoría válida.");
                                continue;
                            }

                            ForgeTypeId tipoDato = ObtenerTipoDato(fila.TipoDato);
                            ForgeTypeId grupoRevit = ObtenerGrupoRevit(fila.GrupoRevit);

                            ExternalDefinition externalDef = ObtenerOCrearDefinicionCompartida(
                                defFile,
                                fila,
                                tipoDato);

                            if (externalDef == null)
                            {
                                errores++;
                                reporte.AppendLine("Fila " + fila.FilaExcel + ": no se pudo crear la definición compartida de " + fila.NombreParametro + ".");
                                continue;
                            }

                            Definition definicionExistente;
                            Binding bindingExistente = BuscarBindingExistente(
                                doc,
                                fila.NombreParametro,
                                out definicionExistente);

                            // =========================================================
                            // SI EL PARÁMETRO YA EXISTE PERO CON OTRO TIPO DE DATO,
                            // REVIT NO PERMITE CAMBIARLO CON ReInsert.
                            // SE ELIMINA Y SE VUELVE A CREAR.
                            // Ejemplo: antes TEXTO, ahora MATERIAL.
                            // =========================================================
                            if (definicionExistente != null)
                            {
                                ForgeTypeId tipoDatoExistente = definicionExistente.GetDataType();

                                if (!MismoForgeTypeId(tipoDatoExistente, tipoDato))
                                {
                                    ParameterElement pe = BuscarParameterElementPorNombre(
                                        doc,
                                        fila.NombreParametro);

                                    if (pe != null)
                                    {
                                        doc.Delete(pe.Id);

                                        bindingExistente = null;
                                        definicionExistente = null;

                                        reporte.AppendLine(
                                            "RECREADO POR CAMBIO DE TIPO_DATO: [" +
                                            fila.Especialidad + "] " +
                                            fila.NombreParametro);
                                    }
                                    else
                                    {
                                        omitidos++;
                                        reporte.AppendLine(
                                            "OMITIDO: [" +
                                            fila.Especialidad + "] " +
                                            fila.NombreParametro +
                                            " ya existe con otro tipo de dato, pero no se pudo eliminar para recrearlo.");

                                        continue;
                                    }
                                }
                            }

                            CategorySet categorySet = CrearCategorySet(
                                revitApp,
                                categorias,
                                bindingExistente);

                            Binding nuevoBinding;

                            if (fila.EsTipo)
                                nuevoBinding = revitApp.Create.NewTypeBinding(categorySet);
                            else
                                nuevoBinding = revitApp.Create.NewInstanceBinding(categorySet);

                            Definition definicionParaBinding = definicionExistente ?? externalDef;

                            bool yaExiste = bindingExistente != null;
                            bool resultado = false;

                            if (!yaExiste)
                            {
                                resultado = doc.ParameterBindings.Insert(
                                    definicionParaBinding,
                                    nuevoBinding,
                                    grupoRevit);

                                if (resultado)
                                {
                                    creados++;
                                    reporte.AppendLine("CREADO: [" + fila.Especialidad + "] " + fila.NombreParametro);
                                }
                                else
                                {
                                    omitidos++;
                                    reporte.AppendLine("OMITIDO: [" + fila.Especialidad + "] " + fila.NombreParametro + " no se pudo insertar en el proyecto.");
                                }
                            }
                            else
                            {
                                if (!Form.ActualizarExistentes)
                                {
                                    omitidos++;
                                    reporte.AppendLine("OMITIDO: [" + fila.Especialidad + "] " + fila.NombreParametro + " ya existe en el proyecto.");
                                    continue;
                                }

                                resultado = doc.ParameterBindings.ReInsert(
                                    definicionParaBinding,
                                    nuevoBinding,
                                    grupoRevit);

                                if (resultado)
                                {
                                    actualizados++;
                                    reporte.AppendLine("ACTUALIZADO: [" + fila.Especialidad + "] " + fila.NombreParametro);
                                }
                                else
                                {
                                    omitidos++;
                                    reporte.AppendLine("OMITIDO: [" + fila.Especialidad + "] " + fila.NombreParametro + " ya existe, pero no se pudo actualizar.");
                                }
                            }
                        }
                        catch (Exception exFila)
                        {
                            errores++;
                            reporte.AppendLine("ERROR fila " + fila.FilaExcel + " - " + fila.NombreParametro + ": " + exFila.Message);
                        }
                    }

                    trans.Commit();
                }

                string resumen =
                    "PROCESO TERMINADO\r\n" +
                    "----------------------------------------\r\n" +
                    "Especialidades seleccionadas: " + string.Join(", ", especialidadesSeleccionadas) + "\r\n" +
                    "Filas leídas del Excel: " + parametrosLeidos.Count + "\r\n" +
                    "Filas filtradas: " + parametros.Count + "\r\n\r\n" +
                    "Parámetros creados: " + creados + "\r\n" +
                    "Parámetros actualizados: " + actualizados + "\r\n" +
                    "Omitidos: " + omitidos + "\r\n" +
                    "Errores: " + errores + "\r\n\r\n" +
                    reporte.ToString();

                MostrarEnVentana(resumen);
            }
            catch (Exception ex)
            {
                MostrarEnVentana("ERROR GENERAL:\r\n" + ex.Message);
            }
            finally
            {
                try
                {
                    if (rutaCompartidosAnterior != null)
                        revitApp.SharedParametersFilename = rutaCompartidosAnterior;
                }
                catch
                {
                }
            }
        }

        // =========================================================
        // MOSTRAR RESULTADO EN VENTANA
        // =========================================================

        private void MostrarEnVentana(string texto)
        {
            if (Form != null && !Form.IsDisposed)
                Form.MostrarResultado(texto);
        }

        // =========================================================
        // LECTURA DE EXCEL
        // =========================================================

        private static List<ParametroExcelMYG> LeerParametrosDesdeExcel(string rutaExcel)
        {
            List<ParametroExcelMYG> lista = new List<ParametroExcelMYG>();

            FileInfo file = new FileInfo(rutaExcel);

            using (ExcelPackage package = new ExcelPackage(file))
            {
                ExcelWorksheet ws = package.Workbook.Worksheets
                    .FirstOrDefault(x => x.Name.Equals("PARAMETROS", StringComparison.OrdinalIgnoreCase));

                if (ws == null)
                    ws = package.Workbook.Worksheets.FirstOrDefault();

                if (ws == null || ws.Dimension == null)
                    return lista;

                int ultimaFila = ws.Dimension.End.Row;
                int ultimaColumna = ws.Dimension.End.Column;

                int filaCabecera = BuscarFilaCabecera(ws, ultimaFila, ultimaColumna);

                if (filaCabecera <= 0)
                    return lista;

                Dictionary<string, int> columnas = ObtenerColumnas(
                    ws,
                    filaCabecera,
                    ultimaColumna);

                for (int fila = filaCabecera + 1; fila <= ultimaFila; fila++)
                {
                    string tipoFila = LeerTexto(ws, fila, columnas, "TIPO_FILA", "ROWTYPE", "PARAM");

                    if (!string.IsNullOrWhiteSpace(tipoFila))
                    {
                        string tipoFilaNorm = NormalizarClave(tipoFila);

                        if (tipoFilaNorm == "GROUP" || tipoFilaNorm == "GRUPO" || tipoFilaNorm == "META")
                            continue;
                    }

                    string nombre = LeerTexto(
                        ws,
                        fila,
                        columnas,
                        "NOMBRE_PARAMETRO",
                        "NOMBRE",
                        "NAME",
                        "PARAMETER_NAME",
                        "PARAMETRO");

                    if (string.IsNullOrWhiteSpace(nombre))
                        continue;

                    ParametroExcelMYG item = new ParametroExcelMYG();

                    item.FilaExcel = fila;

                    item.Especialidad = LeerTexto(
                        ws,
                        fila,
                        columnas,
                        "ESPECIALIDAD",
                        "DISCIPLINA",
                        "DISCIPLINE",
                        "SPECIALTY");

                    item.GrupoArchivo = LeerTexto(
                        ws,
                        fila,
                        columnas,
                        "GRUPO_ARCHIVO",
                        "GRUPO_PARAMETROS",
                        "GROUP_NAME",
                        "GRUPO",
                        "GROUP");

                    item.NombreParametro = nombre;

                    item.TipoDato = LeerTexto(
                        ws,
                        fila,
                        columnas,
                        "TIPO_DATO",
                        "DATATYPE",
                        "PARAMETERTYPE",
                        "TIPO");

                    item.CategoriasTexto = LeerTexto(
                        ws,
                        fila,
                        columnas,
                        "CATEGORIAS",
                        "CATEGORIA",
                        "CATEGORÍA",
                        "CATEGORIES",
                        "CATEGORY");

                    item.TipoBinding = LeerTexto(
                        ws,
                        fila,
                        columnas,
                        "TIPO_BINDING",
                        "BINDING",
                        "INSTANCIA_TIPO",
                        "TIPO_INSTANCIA",
                        "INSTANCE_TYPE");

                    item.GrupoRevit = LeerTexto(
                        ws,
                        fila,
                        columnas,
                        "GRUPO_REVIT",
                        "PARAM_GROUP",
                        "PARAMETER_GROUP",
                        "GRUPO_PROPIEDADES",
                        "GROUP_REVIT");

                    item.Descripcion = LeerTexto(
                        ws,
                        fila,
                        columnas,
                        "DESCRIPCION",
                        "DESCRIPCIÓN",
                        "DESCRIPTION");

                    item.Visible = LeerBooleano(
                        ws,
                        fila,
                        columnas,
                        true,
                        "VISIBLE");

                    item.Modificable = LeerBooleano(
                        ws,
                        fila,
                        columnas,
                        true,
                        "MODIFICABLE",
                        "USERMODIFIABLE",
                        "USER_MODIFIABLE");

                    item.OcultarCuandoSinValor = LeerBooleano(
                        ws,
                        fila,
                        columnas,
                        false,
                        "HIDEWHENNOVALUE",
                        "OCULTAR_SIN_VALOR",
                        "OCULTAR_CUANDO_SIN_VALOR");

                    string guidTexto = LeerTexto(ws, fila, columnas, "GUID");

                    Guid guid;

                    if (Guid.TryParse(guidTexto, out guid))
                        item.Guid = guid;

                    lista.Add(item);
                }
            }

            return lista;
        }

        private static int BuscarFilaCabecera(
            ExcelWorksheet ws,
            int ultimaFila,
            int ultimaColumna)
        {
            int maxFila = Math.Min(ultimaFila, 30);

            int mejorFila = -1;
            int mejorPuntaje = 0;

            for (int fila = 1; fila <= maxFila; fila++)
            {
                int puntaje = 0;

                for (int col = 1; col <= ultimaColumna; col++)
                {
                    string texto = NormalizarClave(ws.Cells[fila, col].Text);

                    if (texto == "ESPECIALIDAD" || texto == "DISCIPLINA" || texto == "SPECIALTY")
                        puntaje += 4;

                    if (texto == "NOMBRE_PARAMETRO" || texto == "NAME" || texto == "PARAMETER_NAME" || texto == "PARAMETRO")
                        puntaje += 5;

                    if (texto == "TIPO_DATO" || texto == "DATATYPE" || texto == "PARAMETERTYPE" || texto == "TIPO")
                        puntaje += 3;

                    if (texto == "CATEGORIAS" || texto == "CATEGORIA" || texto == "CATEGORIES" || texto == "CATEGORY")
                        puntaje += 4;

                    if (texto == "GUID")
                        puntaje += 2;

                    if (texto == "TIPO_BINDING" || texto == "BINDING" || texto == "INSTANCE_TYPE")
                        puntaje += 2;
                }

                if (puntaje > mejorPuntaje)
                {
                    mejorPuntaje = puntaje;
                    mejorFila = fila;
                }
            }

            if (mejorPuntaje >= 5)
                return mejorFila;

            return -1;
        }

        private static Dictionary<string, int> ObtenerColumnas(
            ExcelWorksheet ws,
            int filaCabecera,
            int ultimaColumna)
        {
            Dictionary<string, int> columnas = new Dictionary<string, int>();

            for (int col = 1; col <= ultimaColumna; col++)
            {
                string cabecera = ws.Cells[filaCabecera, col].Text;

                if (string.IsNullOrWhiteSpace(cabecera))
                    continue;

                string clave = NormalizarClave(cabecera);

                if (!columnas.ContainsKey(clave))
                    columnas.Add(clave, col);
            }

            return columnas;
        }

        private static string LeerTexto(
            ExcelWorksheet ws,
            int fila,
            Dictionary<string, int> columnas,
            params string[] posiblesNombres)
        {
            foreach (string nombre in posiblesNombres)
            {
                string clave = NormalizarClave(nombre);

                if (columnas.ContainsKey(clave))
                {
                    string texto = ws.Cells[fila, columnas[clave]].Text;

                    if (texto == null)
                        return "";

                    return texto.Trim();
                }
            }

            return "";
        }

        private static bool LeerBooleano(
            ExcelWorksheet ws,
            int fila,
            Dictionary<string, int> columnas,
            bool valorPorDefecto,
            params string[] posiblesNombres)
        {
            string texto = LeerTexto(ws, fila, columnas, posiblesNombres);

            if (string.IsNullOrWhiteSpace(texto))
                return valorPorDefecto;

            texto = NormalizarClave(texto);

            if (texto == "1" || texto == "SI" || texto == "SÍ" || texto == "YES" || texto == "TRUE" || texto == "VERDADERO" || texto == "X")
                return true;

            if (texto == "0" || texto == "NO" || texto == "FALSE" || texto == "FALSO")
                return false;

            return valorPorDefecto;
        }

        // =========================================================
        // FILTRO POR ESPECIALIDAD
        // =========================================================

        private static List<ParametroExcelMYG> FiltrarPorEspecialidad(
            List<ParametroExcelMYG> parametros,
            List<string> especialidadesSeleccionadas)
        {
            if (especialidadesSeleccionadas == null || especialidadesSeleccionadas.Count == 0)
                return parametros;

            HashSet<string> filtros = new HashSet<string>();

            foreach (string esp in especialidadesSeleccionadas)
            {
                string normalizada = NormalizarEspecialidad(esp);

                if (!string.IsNullOrWhiteSpace(normalizada))
                    filtros.Add(normalizada);
            }

            List<ParametroExcelMYG> resultado = new List<ParametroExcelMYG>();

            foreach (ParametroExcelMYG p in parametros)
            {
                string especialidadFila = NormalizarEspecialidad(p.Especialidad);

                if (filtros.Contains(especialidadFila))
                    resultado.Add(p);
            }

            return resultado;
        }

        private static string NormalizarEspecialidad(string texto)
        {
            string t = NormalizarClave(texto);

            if (t == "GENERAL" || t == "GEN")
                return "GENERAL";

            if (t == "ESTRUCTURA" || t == "ESTRUCTURAS" || t == "STRUCTURE" || t == "STRUCTURAL")
                return "ESTRUCTURA";

            if (t == "ARQUITECTURA" || t == "ARQUITECTURAS" || t == "ARCHITECTURE" || t == "ARCHITECTURAL")
                return "ARQUITECTURA";

            if (t == "SANITARIA" || t == "SANITARIAS" || t == "IISS" || t == "INSTALACIONES_SANITARIAS" || t == "PLUMBING")
                return "SANITARIAS";

            if (t == "ELECTRICA" || t == "ELECTRICAS" || t == "IIEE" || t == "INSTALACIONES_ELECTRICAS" || t == "ELECTRICAL")
                return "ELECTRICAS";

            if (t == "MECANICA" || t == "MECANICAS" || t == "MECHANICAL" || t == "HVAC" || t == "CLIMATIZACION")
                return "MECANICAS";

            return t;
        }

        // =========================================================
        // PREVISUALIZACIÓN
        // =========================================================

        private static string GenerarVistaPreviaParametros(
            Document doc,
            List<ParametroExcelMYG> parametrosFiltrados,
            int totalLeidos,
            List<string> especialidadesSeleccionadas)
        {
            StringBuilder sb = new StringBuilder();

            int ok = 0;
            int conFaltantes = 0;

            sb.AppendLine("PARÁMETROS LEÍDOS");
            sb.AppendLine("----------------------------------------");

            foreach (ParametroExcelMYG p in parametrosFiltrados)
            {
                List<string> faltantes = new List<string>();

                if (string.IsNullOrWhiteSpace(p.Especialidad))
                    faltantes.Add("ESPECIALIDAD");

                if (string.IsNullOrWhiteSpace(p.NombreParametro))
                    faltantes.Add("NOMBRE");

                if (string.IsNullOrWhiteSpace(p.TipoDato))
                    faltantes.Add("TIPO_DATO");

                if (string.IsNullOrWhiteSpace(p.CategoriasTexto))
                    faltantes.Add("CATEGORIAS");

                if (string.IsNullOrWhiteSpace(p.TipoBinding))
                    faltantes.Add("TIPO_BINDING");

                if (string.IsNullOrWhiteSpace(p.GrupoRevit))
                    faltantes.Add("GRUPO_REVIT");

                if (!string.IsNullOrWhiteSpace(p.CategoriasTexto))
                {
                    string[] categorias = SepararCategorias(p.CategoriasTexto);

                    List<string> categoriasNoEncontradas = new List<string>();
                    List<string> categoriasNoPermitidas = new List<string>();

                    foreach (string nombreCat in categorias)
                    {
                        Category cat = BuscarCategoriaPorNombre(doc, nombreCat);

                        if (cat == null)
                        {
                            categoriasNoEncontradas.Add(nombreCat);
                        }
                        else if (!cat.AllowsBoundParameters)
                        {
                            categoriasNoPermitidas.Add(cat.Name);
                        }
                    }

                    if (categoriasNoEncontradas.Count > 0)
                    {
                        faltantes.Add(
                            "CATEGORIA NO ENCONTRADA: " +
                            string.Join(", ", categoriasNoEncontradas));
                    }

                    if (categoriasNoPermitidas.Count > 0)
                    {
                        faltantes.Add(
                            "CATEGORIA NO PERMITIDA: " +
                            string.Join(", ", categoriasNoPermitidas));
                    }
                }

                string nombreParametro = ObtenerTextoSeguro(p.NombreParametro, "(SIN NOMBRE)");

                if (faltantes.Count == 0)
                {
                    ok++;
                    sb.AppendLine(nombreParametro + " | OK");
                }
                else
                {
                    conFaltantes++;
                    sb.AppendLine(nombreParametro + " | FALTA " + string.Join(" / ", faltantes));
                }
            }

            sb.AppendLine("----------------------------------------");
            sb.AppendLine("Total leídos: " + totalLeidos);
            sb.AppendLine("Filtrados: " + parametrosFiltrados.Count);
            sb.AppendLine("OK: " + ok);
            sb.AppendLine("Con observaciones: " + conFaltantes);

            return sb.ToString();
        }

        // =========================================================
        // ARCHIVO TEMPORAL DE PARÁMETROS COMPARTIDOS
        // =========================================================

        private static string ObtenerRutaArchivoCompartidosTemporal(bool regenerarArchivo)
        {
            string carpeta = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "MYG");

            if (!Directory.Exists(carpeta))
                Directory.CreateDirectory(carpeta);

            string ruta = Path.Combine(carpeta, "MYG_ParametrosCompartidos_Excel.txt");

            bool crearArchivo = regenerarArchivo;

            if (!File.Exists(ruta))
            {
                crearArchivo = true;
            }
            else if (!crearArchivo)
            {
                FileInfo info = new FileInfo(ruta);

                if (info.Length == 0)
                {
                    crearArchivo = true;
                }
                else
                {
                    string contenidoActual = File.ReadAllText(ruta);

                    if (!contenidoActual.Contains("*META") ||
                        !contenidoActual.Contains("*GROUP") ||
                        !contenidoActual.Contains("*PARAM"))
                    {
                        crearArchivo = true;
                    }
                }
            }

            if (crearArchivo)
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendLine("# This is a Revit shared parameter file.");
                sb.AppendLine("# Do not edit manually.");
                sb.AppendLine("*META\tVERSION\tMINVERSION");
                sb.AppendLine("META\t2\t1");
                sb.AppendLine("*GROUP\tID\tNAME");
                sb.AppendLine("*PARAM\tGUID\tNAME\tDATATYPE\tDATACATEGORY\tGROUP\tVISIBLE\tDESCRIPTION\tUSERMODIFIABLE\tHIDEWHENNOVALUE");

                File.WriteAllText(ruta, sb.ToString(), Encoding.UTF8);
            }

            return ruta;
        }

        private static ExternalDefinition ObtenerOCrearDefinicionCompartida(
            DefinitionFile defFile,
            ParametroExcelMYG fila,
            ForgeTypeId tipoDato)
        {
            ExternalDefinition existente = BuscarDefinicionEnArchivo(
                defFile,
                fila.NombreParametro);

            if (existente != null)
                return existente;

            string nombreGrupo = fila.GrupoArchivo;

            if (string.IsNullOrWhiteSpace(nombreGrupo))
                nombreGrupo = "MYG_PARAMETROS";

            if (EsNumeroEntero(nombreGrupo))
                nombreGrupo = "GRUPO_" + nombreGrupo;

            DefinitionGroup grupo = defFile.Groups.get_Item(nombreGrupo);

            if (grupo == null)
                grupo = defFile.Groups.Create(nombreGrupo);

            ExternalDefinitionCreationOptions opciones =
                new ExternalDefinitionCreationOptions(fila.NombreParametro, tipoDato);

            opciones.Visible = fila.Visible;
            opciones.UserModifiable = fila.Modificable;

            if (!string.IsNullOrWhiteSpace(fila.Descripcion))
                opciones.Description = fila.Descripcion;

            if (fila.Guid.HasValue)
                opciones.GUID = fila.Guid.Value;

            AplicarHideWhenNoValueSiExiste(
                opciones,
                fila.OcultarCuandoSinValor);

            Definition nueva = grupo.Definitions.Create(opciones);

            return nueva as ExternalDefinition;
        }

        private static ExternalDefinition BuscarDefinicionEnArchivo(
            DefinitionFile defFile,
            string nombreParametro)
        {
            foreach (DefinitionGroup grupo in defFile.Groups)
            {
                foreach (Definition def in grupo.Definitions)
                {
                    if (def.Name.Equals(nombreParametro, StringComparison.OrdinalIgnoreCase))
                        return def as ExternalDefinition;
                }
            }

            return null;
        }

        private static void AplicarHideWhenNoValueSiExiste(
            ExternalDefinitionCreationOptions opciones,
            bool valor)
        {
            try
            {
                PropertyInfo prop = typeof(ExternalDefinitionCreationOptions).GetProperty(
                    "HideWhenNoValue",
                    BindingFlags.Public | BindingFlags.Instance);

                if (prop != null && prop.CanWrite && prop.PropertyType == typeof(bool))
                    prop.SetValue(opciones, valor, null);
            }
            catch
            {
            }
        }

        // =========================================================
        // BINDING Y CATEGORÍAS
        // =========================================================

        private static Binding BuscarBindingExistente(
            Document doc,
            string nombreParametro,
            out Definition definicionExistente)
        {
            definicionExistente = null;

            DefinitionBindingMapIterator iterator = doc.ParameterBindings.ForwardIterator();

            while (iterator.MoveNext())
            {
                Definition def = iterator.Key;

                if (def == null)
                    continue;

                if (def.Name.Equals(nombreParametro, StringComparison.OrdinalIgnoreCase))
                {
                    definicionExistente = def;
                    return iterator.Current as Binding;
                }
            }

            return null;
        }

        private static CategorySet CrearCategorySet(
            DBApplication app,
            List<Category> categoriasNuevas,
            Binding bindingExistente)
        {
            CategorySet set = app.Create.NewCategorySet();

            ElementBinding elementBinding = bindingExistente as ElementBinding;

            if (elementBinding != null)
            {
                foreach (Category cat in elementBinding.Categories)
                {
                    AgregarCategoriaSiNoExiste(set, cat);
                }
            }

            foreach (Category cat in categoriasNuevas)
            {
                AgregarCategoriaSiNoExiste(set, cat);
            }

            return set;
        }

        private static void AgregarCategoriaSiNoExiste(
            CategorySet set,
            Category categoria)
        {
            if (categoria == null)
                return;

            foreach (Category cat in set)
            {
                if (MismoElementId(cat.Id, categoria.Id))
                    return;
            }

            set.Insert(categoria);
        }

        private static string[] SepararCategorias(string categoriasTexto)
        {
            if (string.IsNullOrWhiteSpace(categoriasTexto))
                return new string[0];

            // Acepta categorías separadas por punto y coma, coma, barra vertical o dos puntos.
            // Esto corrige casos como: "Suelos: Bordes de losa".
            return categoriasTexto
                .Split(new char[] { ';', ',', '|', ':' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim())
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .ToArray();
        }

        private static List<Category> ObtenerCategorias(
            Document doc,
            string categoriasTexto,
            StringBuilder reporte,
            int filaExcel)
        {
            List<Category> resultado = new List<Category>();

            string[] nombres = SepararCategorias(categoriasTexto);

            foreach (string nombre in nombres)
            {
                Category categoria = BuscarCategoriaPorNombre(doc, nombre);

                if (categoria == null)
                {
                    reporte.AppendLine("Fila " + filaExcel + ": categoría no encontrada: " + nombre);
                    continue;
                }

                if (!categoria.AllowsBoundParameters)
                {
                    reporte.AppendLine("Fila " + filaExcel + ": la categoría no permite parámetros de proyecto: " + categoria.Name);
                    continue;
                }

                bool existe = false;

                foreach (Category catExistente in resultado)
                {
                    if (MismoElementId(catExistente.Id, categoria.Id))
                    {
                        existe = true;
                        break;
                    }
                }

                if (!existe)
                    resultado.Add(categoria);
            }

            return resultado;
        }

        private static Category BuscarCategoriaPorNombre(
            Document doc,
            string nombre)
        {
            if (doc == null || string.IsNullOrWhiteSpace(nombre))
                return null;

            string nombreNormalizado = NormalizarClave(nombre);

            // 1) Busca por el nombre exacto que Revit muestra en el idioma actual.
            //    Ejemplo: "Bordes de losa", "Accesorios de conductos", "Tuberías", etc.
            foreach (Category cat in doc.Settings.Categories)
            {
                if (cat == null)
                    continue;

                if (NormalizarClave(cat.Name) == nombreNormalizado)
                    return cat;
            }

            // 2) Busca por alias manuales para casos donde el nombre venga en singular,
            //    plural, sin tilde, abreviado o en inglés.
            Category porAlias = BuscarCategoriaPorAlias(doc, nombreNormalizado);

            if (porAlias != null)
                return porAlias;

            // 3) Busca recorriendo todas las BuiltInCategory y comparando contra la etiqueta
            //    oficial visible de Revit. Esto permite reconocer la lista tal como la pegaste
            //    desde Revit, aunque no esté escrita en el diccionario de alias.
            Category porEtiquetaRevit = BuscarCategoriaPorEtiquetaRevit(doc, nombreNormalizado);

            if (porEtiquetaRevit != null)
                return porEtiquetaRevit;

            return null;
        }

        private static Category BuscarCategoriaPorEtiquetaRevit(
            Document doc,
            string nombreNormalizado)
        {
            if (doc == null || string.IsNullOrWhiteSpace(nombreNormalizado))
                return null;

            Array categoriasApi = Enum.GetValues(typeof(BuiltInCategory));

            foreach (object item in categoriasApi)
            {
                try
                {
                    BuiltInCategory bic = (BuiltInCategory)item;

                    string etiqueta = LabelUtils.GetLabelFor(bic);

                    if (string.IsNullOrWhiteSpace(etiqueta))
                        continue;

                    if (NormalizarClave(etiqueta) != nombreNormalizado)
                        continue;

                    Category categoria = Category.GetCategory(doc, bic);

                    if (categoria != null)
                        return categoria;
                }
                catch
                {
                    // Algunas BuiltInCategory no tienen etiqueta visible o no aplican al documento.
                }
            }

            return null;
        }

        private static Category BuscarCategoriaPorAlias(
            Document doc,
            string nombreNormalizado)
        {
            Dictionary<string, BuiltInCategory> alias =
                new Dictionary<string, BuiltInCategory>();

            alias["MUROS"] = BuiltInCategory.OST_Walls;
            alias["WALLS"] = BuiltInCategory.OST_Walls;

            alias["SUELOS"] = BuiltInCategory.OST_Floors;
            alias["PISOS"] = BuiltInCategory.OST_Floors;
            alias["FLOORS"] = BuiltInCategory.OST_Floors;

            // IMPORTANTE: Categoría "Bordes de losa"
            alias["BORDE_DE_LOSA"] = BuiltInCategory.OST_EdgeSlab;
            alias["BORDES_DE_LOSA"] = BuiltInCategory.OST_EdgeSlab;
            alias["BORDE_DE_LOSAS"] = BuiltInCategory.OST_EdgeSlab;
            alias["BORDES_DE_LOSAS"] = BuiltInCategory.OST_EdgeSlab;
            alias["SLAB_EDGE"] = BuiltInCategory.OST_EdgeSlab;
            alias["SLAB_EDGES"] = BuiltInCategory.OST_EdgeSlab;
            alias["EDGE_SLAB"] = BuiltInCategory.OST_EdgeSlab;
            alias["OST_EDGESLAB"] = BuiltInCategory.OST_EdgeSlab;
            alias["EDGE_SLABS"] = BuiltInCategory.OST_EdgeSlab;
            alias["EDGESLAB"] = BuiltInCategory.OST_EdgeSlab;
            alias["SLABEDGES"] = BuiltInCategory.OST_EdgeSlab;

            alias["TECHOS"] = BuiltInCategory.OST_Ceilings;
            alias["CEILINGS"] = BuiltInCategory.OST_Ceilings;

            alias["CUBIERTAS"] = BuiltInCategory.OST_Roofs;
            alias["ROOFS"] = BuiltInCategory.OST_Roofs;

            alias["PUERTAS"] = BuiltInCategory.OST_Doors;
            alias["DOORS"] = BuiltInCategory.OST_Doors;

            alias["VENTANAS"] = BuiltInCategory.OST_Windows;
            alias["WINDOWS"] = BuiltInCategory.OST_Windows;

            alias["COLUMNAS"] = BuiltInCategory.OST_Columns;
            alias["COLUMNS"] = BuiltInCategory.OST_Columns;

            alias["COLUMNAS_ESTRUCTURALES"] = BuiltInCategory.OST_StructuralColumns;
            alias["STRUCTURAL_COLUMNS"] = BuiltInCategory.OST_StructuralColumns;

            alias["PILARES_ESTRUCTURALES"] = BuiltInCategory.OST_StructuralColumns;
            alias["PILARES"] = BuiltInCategory.OST_Columns;

            alias["ARMAZON_ESTRUCTURAL"] = BuiltInCategory.OST_StructuralFraming;
            alias["ARMAZÓN_ESTRUCTURAL"] = BuiltInCategory.OST_StructuralFraming;
            alias["STRUCTURAL_FRAMING"] = BuiltInCategory.OST_StructuralFraming;
            alias["VIGAS"] = BuiltInCategory.OST_StructuralFraming;
            alias["BEAMS"] = BuiltInCategory.OST_StructuralFraming;

            alias["CIMENTACION_ESTRUCTURAL"] = BuiltInCategory.OST_StructuralFoundation;
            alias["CIMENTACIÓN_ESTRUCTURAL"] = BuiltInCategory.OST_StructuralFoundation;
            alias["STRUCTURAL_FOUNDATIONS"] = BuiltInCategory.OST_StructuralFoundation;
            alias["FOUNDATIONS"] = BuiltInCategory.OST_StructuralFoundation;

            alias["MODELOS_GENERICOS"] = BuiltInCategory.OST_GenericModel;
            alias["MODELOS_GENÉRICOS"] = BuiltInCategory.OST_GenericModel;
            alias["GENERIC_MODELS"] = BuiltInCategory.OST_GenericModel;

            alias["MOBILIARIO"] = BuiltInCategory.OST_Furniture;
            alias["FURNITURE"] = BuiltInCategory.OST_Furniture;

            alias["HABITACIONES"] = BuiltInCategory.OST_Rooms;
            alias["ROOMS"] = BuiltInCategory.OST_Rooms;

            alias["ESPACIOS"] = BuiltInCategory.OST_MEPSpaces;
            alias["SPACES"] = BuiltInCategory.OST_MEPSpaces;

            alias["TUBERIAS"] = BuiltInCategory.OST_PipeCurves;
            alias["TUBERÍAS"] = BuiltInCategory.OST_PipeCurves;
            alias["PIPES"] = BuiltInCategory.OST_PipeCurves;

            alias["CONDUCTOS"] = BuiltInCategory.OST_DuctCurves;
            alias["DUCTS"] = BuiltInCategory.OST_DuctCurves;

            alias["BANDEJAS_PORTACABLES"] = BuiltInCategory.OST_CableTray;
            alias["BANDEJAS_DE_CABLES"] = BuiltInCategory.OST_CableTray;
            alias["CABLE_TRAYS"] = BuiltInCategory.OST_CableTray;

            alias["TUBOS_CONDUIT"] = BuiltInCategory.OST_Conduit;
            alias["TUBOS"] = BuiltInCategory.OST_Conduit;
            alias["CONDUITS"] = BuiltInCategory.OST_Conduit;

            if (!alias.ContainsKey(nombreNormalizado))
                return null;

            try
            {
                return Category.GetCategory(doc, alias[nombreNormalizado]);
            }
            catch
            {
                return null;
            }
        }

        // =========================================================
        // MAPEO DE TIPO DE DATO
        // =========================================================

        private static ForgeTypeId ObtenerTipoDato(string tipoDato)
        {
            string t = NormalizarClave(tipoDato);

            switch (t)
            {
                case "TEXTO":
                case "TEXT":
                case "STRING":
                    return ObtenerSpecTypeIdPorRuta("String.Text", SpecTypeId.Number);

                case "URL":
                    return ObtenerSpecTypeIdPorRuta(
                        "String.Url",
                        ObtenerSpecTypeIdPorRuta("String.Text", SpecTypeId.Number));

                case "MULTILINE_TEXT":
                case "TEXTO_MULTILINEA":
                case "TEXTO_MULTILINEA_LARGA":
                    return ObtenerSpecTypeIdPorRuta(
                        "String.MultilineText",
                        ObtenerSpecTypeIdPorRuta("String.Text", SpecTypeId.Number));

                case "SI_NO":
                case "SINO":
                case "YESNO":
                case "YES_NO":
                case "BOOLEAN":
                case "BOOL":
                    return ObtenerSpecTypeIdPorRuta("Boolean.YesNo", SpecTypeId.Number);

                case "ENTERO":
                case "INTEGER":
                case "INT":
                    return ObtenerSpecTypeIdPorRuta("Int.Integer", SpecTypeId.Number);

                case "NUMERO":
                case "NUMERO_DECIMAL":
                case "NÚMERO":
                case "NUMBER":
                case "DOUBLE":
                case "REAL":
                    return SpecTypeId.Number;

                case "LONGITUD":
                case "LENGTH":
                    return ObtenerSpecTypeIdPorRuta("Length", SpecTypeId.Number);

                case "AREA":
                case "ÁREA":
                    return ObtenerSpecTypeIdPorRuta("Area", SpecTypeId.Number);

                case "VOLUMEN":
                case "VOLUME":
                    return ObtenerSpecTypeIdPorRuta("Volume", SpecTypeId.Number);

                case "ANGULO":
                case "ÁNGULO":
                case "ANGLE":
                    return ObtenerSpecTypeIdPorRuta("Angle", SpecTypeId.Number);

                case "MONEDA":
                case "CURRENCY":
                    return ObtenerSpecTypeIdPorRuta("Currency", SpecTypeId.Number);

                case "PENDIENTE":
                case "SLOPE":
                    return ObtenerSpecTypeIdPorRuta("Slope", SpecTypeId.Number);

                case "MASA":
                case "MASS":
                    return ObtenerSpecTypeIdPorRuta("Mass", SpecTypeId.Number);

                case "DENSIDAD":
                case "DENSITY":
                    return SpecTypeId.Number;

                case "MATERIAL":
                case "MATERIALES":
                case "MATERIALS":
                    return SpecTypeId.Reference.Material;

                default:
                    return ObtenerSpecTypeIdPorRuta("String.Text", SpecTypeId.Number);
            }
        }

        private static ForgeTypeId ObtenerSpecTypeIdPorRuta(
            string ruta,
            ForgeTypeId valorPorDefecto)
        {
            try
            {
                string[] partes = ruta.Split('.');

                Type tipoActual = typeof(SpecTypeId);

                for (int i = 0; i < partes.Length - 1; i++)
                {
                    Type tipoAnidado = tipoActual.GetNestedType(
                        partes[i],
                        BindingFlags.Public);

                    if (tipoAnidado == null)
                        return valorPorDefecto;

                    tipoActual = tipoAnidado;
                }

                string nombrePropiedad = partes[partes.Length - 1];

                PropertyInfo prop = tipoActual.GetProperty(
                    nombrePropiedad,
                    BindingFlags.Public | BindingFlags.Static);

                if (prop == null)
                    return valorPorDefecto;

                object valor = prop.GetValue(null, null);

                if (valor is ForgeTypeId)
                    return (ForgeTypeId)valor;

                return valorPorDefecto;
            }
            catch
            {
                return valorPorDefecto;
            }
        }

        // =========================================================
        // MAPEO DE GRUPO REVIT
        // =========================================================

        private static ForgeTypeId ObtenerGrupoRevit(string grupo)
        {
            if (string.IsNullOrWhiteSpace(grupo))
                return GroupTypeId.Data;

            string g = NormalizarClave(grupo);

            HashSet<string> candidatos = new HashSet<string>();

            if (!string.IsNullOrWhiteSpace(g))
                candidatos.Add(g);

            Dictionary<string, string[]> alias = new Dictionary<string, string[]>();

            alias["ALINEACION_ANALITICA"] = new string[] { "Analytical Alignment", "Alineación analítica" };
            alias["ANALISIS_ELECTRICO"] = new string[] { "Electrical Analysis", "Análisis eléctrico" };
            alias["ANALISIS_ENERGETICO"] = new string[] { "Energy Analysis", "Análisis energético" };
            alias["ANALISIS_ESTRUCTURAL"] = new string[] { "Structural Analysis", "Análisis estructural" };
            alias["CANALES"] = new string[] { "Channels", "Canales" };
            alias["COLOCACION_DE_LA_VISTA_EN_PLANO"] = new string[] { "View Placement", "Colocación de la vista en plano" };
            alias["CONJUNTO"] = new string[] { "Assembly", "Conjunto" };
            alias["CONJUNTO_DE_ARMADURAS"] = new string[] { "Rebar Set", "Conjunto de armaduras" };
            alias["CONSTRUCCION"] = new string[] { "Construction", "Construcción" };
            alias["COTAS"] = new string[] { "Dimensions", "Cotas" };
            alias["COTAS_DE_SECCION_ESTRUCTURAL"] = new string[] { "Structural Section Geometry", "Cotas de sección estructural" };
            alias["DATOS"] = new string[] { "Data", "Datos" };
            alias["DATOS_DE_IDENTIDAD"] = new string[] { "Identity Data", "IdentityData", "Datos de identidad" };
            alias["DATOS_IDENTIDAD"] = new string[] { "Identity Data", "IdentityData", "Datos de identidad" };
            alias["EDICION_DE_FORMA_DE_LOSA"] = new string[] { "Slab Shape Edit", "Edición de forma de losa" };
            alias["ELECTRICIDAD"] = new string[] { "Electrical", "Electricidad" };
            alias["ELECTRICO_CARGAS"] = new string[] { "Electrical - Loads", "Electrical Loads", "Eléctrico - Cargas" };
            alias["ELECTRICO_CIRCUITOS"] = new string[] { "Electrical - Circuiting", "Electrical Circuiting", "Eléctrico - Circuitos" };
            alias["ELECTRICO_ILUMINACION"] = new string[] { "Electrical - Lighting", "Electrical Lighting", "Eléctrico - Iluminación" };
            alias["ESFUERZOS_FUERZAS_DE_ELEMENTOS"] = new string[] { "Element Forces", "Forces", "Esfuerzos / Fuerzas de elementos" };
            alias["ESTRUCTURA"] = new string[] { "Structural", "Structure", "Estructura" };
            alias["EXTREMO_PRIMARIO"] = new string[] { "Primary End", "Extremo primario" };
            alias["EXTREMO_SECUNDARIO"] = new string[] { "Secondary End", "Extremo secundario" };
            alias["FONTANERIA"] = new string[] { "Plumbing", "Fontanería" };
            alias["FOTOMETRIA"] = new string[] { "Photometrics", "Fotometría" };
            alias["FUERZAS"] = new string[] { "Forces", "Fuerzas" };
            alias["GENERAL"] = new string[] { "General", "General" };
            alias["GEOMETRIA_DE_DIVISION"] = new string[] { "Division Geometry", "Geometría de división" };
            alias["GRAFICOS"] = new string[] { "Graphics", "Gráficos" };
            alias["INGENIERIA_ELECTRICA"] = new string[] { "Electrical Engineering", "Ingeniería eléctrica" };
            alias["LEYENDA_GLOBAL"] = new string[] { "Overall Legend", "Leyenda global" };
            alias["MATERIALES_Y_ACABADOS"] = new string[] { "Materials and Finishes", "Materials", "Materiales y acabados" };
            alias["MECANICA"] = new string[] { "Mechanical", "Mecánica" };
            alias["MECANICO_CARGAS"] = new string[] { "Mechanical - Loads", "Mechanical Loads", "Mecánico - Cargas" };
            alias["MECANICO_FLUJO"] = new string[] { "Mechanical - Flow", "Mechanical Flow", "Mecánico - Flujo" };
            alias["MODELO_ANALITICO"] = new string[] { "Analytical Model", "Modelo analítico" };
            alias["MOMENTOS"] = new string[] { "Moments", "Momentos" };
            alias["OTROS"] = new string[] { "Other", "Others", "Otros" };
            alias["PARAMETROS_IFC"] = new string[] { "IFC Parameters", "Ifc", "Parámetros IFC" };
            alias["PROCESO_POR_FASES"] = new string[] { "Phasing", "Proceso por fases" };
            alias["PROPIEDADES_DE_GREEN_BUILDING"] = new string[] { "Green Building Properties", "Green Building", "Propiedades de Green Building" };
            alias["PROPIEDADES_DE_MODELO"] = new string[] { "Model Properties", "Propiedades de modelo" };
            alias["PROTECCION_CONTRA_INCENDIOS"] = new string[] { "Fire Protection", "Protección contra incendios" };
            alias["RESTRICCIONES"] = new string[] { "Constraints", "Restricciones" };
            alias["RESULTADOS_DE_ANALISIS"] = new string[] { "Analysis Results", "Resultados de análisis" };
            alias["ROTATION_ABOUT"] = new string[] { "Rotation About", "Rotation about" };
            alias["SEGMENTOS_Y_UNIONES"] = new string[] { "Segments and Fittings", "Segmentos y uniones" };
            alias["SEGURIDAD_PERSONAL"] = new string[] { "Personal Safety", "Seguridad personal" };
            alias["SOSTENIBILIDAD"] = new string[] { "Sustainability", "Sostenibilidad" };
            alias["SUBDIVISION"] = new string[] { "Subdivision", "Subdivisión" };
            alias["TEXTO"] = new string[] { "Text", "Texto" };
            alias["TEXTO_DE_TITULO"] = new string[] { "Title Text", "TitleText", "Texto de título" };
            alias["VISIBILIDAD"] = new string[] { "Visibility", "Visibilidad" };
            alias["VISUALIZACION"] = new string[] { "Visualization", "Visualización" };

            if (alias.ContainsKey(g))
            {
                foreach (string textoAlias in alias[g])
                {
                    string claveAlias = NormalizarClave(textoAlias);

                    if (!string.IsNullOrWhiteSpace(claveAlias))
                        candidatos.Add(claveAlias);
                }
            }

            PropertyInfo[] propiedades = typeof(GroupTypeId)
                .GetProperties(BindingFlags.Public | BindingFlags.Static);

            foreach (PropertyInfo prop in propiedades)
            {
                if (prop.PropertyType != typeof(ForgeTypeId))
                    continue;

                object valor = prop.GetValue(null, null);

                if (!(valor is ForgeTypeId))
                    continue;

                ForgeTypeId id = (ForgeTypeId)valor;

                string nombreApi = NormalizarClave(prop.Name);

                if (candidatos.Contains(nombreApi))
                    return id;

                try
                {
                    string etiquetaVisible = LabelUtils.GetLabelForGroup(id);
                    string etiquetaNormalizada = NormalizarClave(etiquetaVisible);

                    if (candidatos.Contains(etiquetaNormalizada))
                        return id;
                }
                catch
                {
                }
            }

            ForgeTypeId intentoDirecto = ObtenerGroupTypeIdPorNombre(grupo.Trim());

            if (intentoDirecto != null && !string.IsNullOrWhiteSpace(intentoDirecto.TypeId))
                return intentoDirecto;

            return GroupTypeId.Data;
        }

        private static ForgeTypeId ObtenerGroupTypeIdPorNombre(string nombrePropiedad)
        {
            if (string.IsNullOrWhiteSpace(nombrePropiedad))
                return null;

            string nombreNormalizado = NormalizarClave(nombrePropiedad);

            PropertyInfo[] propiedades = typeof(GroupTypeId)
                .GetProperties(BindingFlags.Public | BindingFlags.Static);

            foreach (PropertyInfo prop in propiedades)
            {
                if (prop.PropertyType != typeof(ForgeTypeId))
                    continue;

                string nombreApi = NormalizarClave(prop.Name);

                if (nombreApi != nombreNormalizado)
                    continue;

                object valor = prop.GetValue(null, null);

                if (valor is ForgeTypeId)
                    return (ForgeTypeId)valor;
            }

            return null;
        }

        // =========================================================
        // EPPLUS
        // =========================================================

        private static void ConfigurarLicenciaEpplus()
        {
            try
            {
                PropertyInfo licenseContextProp = typeof(ExcelPackage).GetProperty(
                    "LicenseContext",
                    BindingFlags.Public | BindingFlags.Static);

                if (licenseContextProp != null)
                {
                    object valor = Enum.Parse(
                        licenseContextProp.PropertyType,
                        "NonCommercial");

                    licenseContextProp.SetValue(null, valor, null);
                    return;
                }
            }
            catch
            {
            }

            try
            {
                PropertyInfo licenseProp = typeof(ExcelPackage).GetProperty(
                    "License",
                    BindingFlags.Public | BindingFlags.Static);

                if (licenseProp != null)
                {
                    object licenseObj = licenseProp.GetValue(null, null);

                    if (licenseObj != null)
                    {
                        MethodInfo metodo = licenseObj.GetType().GetMethod(
                            "SetNonCommercialPersonal",
                            new Type[] { typeof(string) });

                        if (metodo != null)
                            metodo.Invoke(licenseObj, new object[] { "MYG - Ing. Marlon Yacila" });
                    }
                }
            }
            catch
            {
            }
        }

        // =========================================================
        // UTILIDADES
        // =========================================================

        private static string ObtenerTextoSeguro(string texto, string valorDefecto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return valorDefecto;

            return texto.Trim();
        }

        private static bool MismoElementId(ElementId id1, ElementId id2)
        {
            if (id1 == null || id2 == null)
                return false;

            return id1.Value == id2.Value;
        }

        private static bool MismoForgeTypeId(ForgeTypeId id1, ForgeTypeId id2)
        {
            if (id1 == null || id2 == null)
                return false;

            if (id1.Equals(id2))
                return true;

            string t1 = id1.TypeId;
            string t2 = id2.TypeId;

            if (string.IsNullOrWhiteSpace(t1) || string.IsNullOrWhiteSpace(t2))
                return false;

            return t1.Equals(t2, StringComparison.OrdinalIgnoreCase);
        }

        private static ParameterElement BuscarParameterElementPorNombre(
            Document doc,
            string nombreParametro)
        {
            if (doc == null || string.IsNullOrWhiteSpace(nombreParametro))
                return null;

            return new FilteredElementCollector(doc)
                .OfClass(typeof(ParameterElement))
                .Cast<ParameterElement>()
                .FirstOrDefault(x =>
                    x.GetDefinition() != null &&
                    x.GetDefinition().Name.Equals(
                        nombreParametro,
                        StringComparison.OrdinalIgnoreCase));
        }

        private static string NormalizarClave(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return "";

            string resultado = texto
                .Replace('\u00A0', ' ')
                .Replace('\t', ' ')
                .Trim()
                .ToUpperInvariant()
                .Replace("Á", "A")
                .Replace("É", "E")
                .Replace("Í", "I")
                .Replace("Ó", "O")
                .Replace("Ú", "U")
                .Replace("Ñ", "N")
                .Replace(" ", "_")
                .Replace("-", "_")
                .Replace(".", "_")
                .Replace(":", "_")
                .Replace(";", "_")
                .Replace(",", "_")
                .Replace("/", "_")
                .Replace("\\", "_")
                .Replace("(", "")
                .Replace(")", "")
                .Replace("[", "")
                .Replace("]", "")
                .Replace("\"", "")
                .Replace("'", "");

            while (resultado.Contains("__"))
                resultado = resultado.Replace("__", "_");

            return resultado;
        }

        private static bool EsNumeroEntero(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return false;

            int valor;
            return int.TryParse(texto.Trim(), out valor);
        }

        private class ParametroExcelMYG
        {
            public int FilaExcel { get; set; }
            public string Especialidad { get; set; }
            public string GrupoArchivo { get; set; }
            public string NombreParametro { get; set; }
            public string TipoDato { get; set; }
            public string CategoriasTexto { get; set; }
            public string TipoBinding { get; set; }
            public string GrupoRevit { get; set; }
            public bool Visible { get; set; }
            public bool Modificable { get; set; }
            public bool OcultarCuandoSinValor { get; set; }
            public string Descripcion { get; set; }
            public Guid? Guid { get; set; }

            public bool EsTipo
            {
                get
                {
                    string t = NormalizarClave(TipoBinding);

                    if (t == "TIPO" || t == "TYPE")
                        return true;

                    return false;
                }
            }
        }
    }
}