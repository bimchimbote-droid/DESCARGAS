using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{












    // =======================================
    // SESIÓN MYG
    // =======================================
    // Acceso común a los comandos MYG.
    // La detección de Add-In Manager es compatible con sus nombres habituales;
    // no constituye una protección contra modificaciones maliciosas de la DLL.
    internal static class MYG_ControlAccesoComandos
    {
        private static bool _inicioNormal = false;

        [System.Runtime.CompilerServices.MethodImpl(
            System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        internal static bool RequiereIngresoAutomatico()
        {
            return !_inicioNormal || EsAddinManager();
        }

        [System.Runtime.CompilerServices.MethodImpl(
            System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        internal static void RegistrarInicioNormal()
        {
            _inicioNormal = !EsAddinManager();
        }

        internal static void Finalizar()
        {
            _inicioNormal = false;
        }

        [System.Runtime.CompilerServices.MethodImpl(
            System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        private static bool EsAddinManager()
        {
            try
            {
                var frames = new System.Diagnostics.StackTrace(false).GetFrames();
                if (frames == null) return true;

                foreach (var frame in frames)
                {
                    var metodo = frame.GetMethod();
                    if (metodo == null) continue;
                    string nombre = metodo.Module.Assembly.GetName().Name ?? "";
                    string tipo = metodo.DeclaringType == null
                        ? "" : (metodo.DeclaringType.FullName ?? "");
                    string identificador = (nombre + " " + tipo)
                        .Replace("-", "").Replace("_", "").Replace(" ", "");
                    if (identificador.IndexOf("AddinManager",
                        System.StringComparison.OrdinalIgnoreCase) >= 0)
                        return true;
                }
                return false;
            }
            catch
            {
                // Ante una detección fallida exigir autorización automática.
                return true;
            }
        }

        [System.Runtime.CompilerServices.MethodImpl(
            System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        internal static bool Comprobar()
        {
            if (RequiereIngresoAutomatico())
            {
                // Lectura local: la revisión de red se realiza en segundo plano.
                if (!LicenciaManager.IngresoAutomaticoDisponible())
                {
                    Autodesk.Revit.UI.TaskDialog.Show("MYG LICENCIA",
                        "No se pudo autorizar el uso de esta herramienta.\n\n" +
                        "Verifica tu conexión a internet. Si el problema persiste, contacta al administrador de MYG.");
                    return false;
                }
                MYG_Sesion.IniciarSesion();
                return true;
            }

            if (MYG_Sesion.Logueado) return true;

            // Permite recuperar un ingreso automático si hubo un fallo de red al arrancar.
            if (LicenciaManager.IntentarIngresoAutomatico())
            {
                MYG_Sesion.IniciarSesion();
                MYG_RibbonControl.HabilitarBotones(true);
                return true;
            }

            Autodesk.Revit.UI.TaskDialog.Show("MYG LICENCIA",
                "Inicia sesión desde la pestaña MYG antes de utilizar este comando.");
            return false;
        }
    }

}
