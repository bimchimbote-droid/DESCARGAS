using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =======================================
    // LICENCIA MANAGER - LOGIN SIN license.key
    // MACHINE_ID SEGURO POR HASH DE WINDOWS
    // OPTIMIZADO CON CACHE Y TIMEOUT
    // =======================================
    public static class LicenciaManager
    {
        private static readonly string URL =
            "https://script.google.com/macros/s/AKfycbxf1vZ2DL3PNw92OXFPrhnQcLd9eqHT4z6o0T3obdKdFWzG-1UVynK1cTOIfj_CfjCU/exec";

        private static string _machineIdCache = "";

        private static string RutaToken
        {
            get
            {
                string carpeta = System.IO.Path.Combine(
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.LocalApplicationData),
                    "MYG_Addin");

                return System.IO.Path.Combine(
                    carpeta,
                    "sesion_automatica.dat");
            }
        }

        public static bool Login(
            string usuario,
            string clave,
            out string mensaje)
        {
            mensaje = "";

            try
            {
                if (string.IsNullOrWhiteSpace(usuario))
                {
                    mensaje = "Ingrese el usuario.";
                    return false;
                }

                if (string.IsNullOrWhiteSpace(clave))
                {
                    mensaje = "Ingrese la contraseña.";
                    return false;
                }

                ServicePointManager.SecurityProtocol =
                    SecurityProtocolType.Tls12;

                string fullUrl =
                    URL +
                    "?usuario=" + Uri.EscapeDataString(usuario.Trim()) +
                    "&clave=" + Uri.EscapeDataString(clave.Trim()) +
                    "&pc=" + Uri.EscapeDataString(ObtenerMachineId());

                using (WebClientConTimeout client =
                    new WebClientConTimeout())
                {
                    client.Timeout = 15000;
                    client.Encoding = System.Text.Encoding.UTF8;
                    client.Headers.Add(
                        HttpRequestHeader.CacheControl,
                        "no-cache");

                    string respuesta =
                        client.DownloadString(fullUrl).Trim();

                    if (respuesta.StartsWith(
                        "OK|",
                        StringComparison.Ordinal))
                    {
                        string token = respuesta.Substring(3).Trim();

                        if (token.Length < 32)
                        {
                            mensaje = "El servidor devolvió un token inválido.";
                            return false;
                        }

                        // El login manual es válido aunque Windows no permita
                        // guardar el token; en tal caso pedirá clave la próxima vez.
                        bool guardado = GuardarToken(usuario.Trim(), token);
                        LimpiarCacheAutomatica();
                        if (guardado)
                            GuardarCacheAutomatica(IdentidadCache(usuario.Trim(), token));

                        mensaje = guardado
                            ? "Sesión iniciada correctamente. El ingreso automático quedó configurado."
                            : "Sesión iniciada correctamente. No se pudo guardar el ingreso automático en esta PC.";

                        return true;
                    }

                    if (respuesta == "OK")
                    {
                        BorrarToken();
                        mensaje = "Sesión iniciada correctamente.";
                        return true;
                    }

                    if (respuesta == "EXPIRADO")
                        mensaje = "Licencia expirada.";
                    else if (respuesta == "BLOQUEADO")
                        mensaje = "Licencia bloqueada.";
                    else if (respuesta == "OTRA_PC")
                        mensaje = "Este usuario ya está registrado en otra computadora.";
                    else if (respuesta == "CLAVE_ERROR")
                        mensaje = "Contraseña incorrecta.";
                    else if (respuesta == "NO_EXISTE")
                        mensaje = "Usuario no registrado.";
                    else if (respuesta == "DATOS_INCOMPLETOS")
                        mensaje = "Datos incompletos para validar la licencia.";
                    else if (respuesta == "SIN_HOJA")
                        mensaje = "No se encontró la hoja LICENCIAS.";
                    else if (respuesta == "FECHA_INVALIDA")
                        mensaje = "La fecha de expiración no es válida.";
                    else
                        mensaje = "No se pudo validar la licencia.";

                    return false;
                }
            }
            catch
            {
                mensaje =
                    "Error verificando licencia.\nVerifique su conexión a internet.";
                return false;
            }
        }

        // Compartir únicamente datos de tipos del runtime entre las copias
        // cargadas en el mismo AppDomain de Revit (incluido Add-In Manager).
        private const string ClaveCacheAutomatica = "MYG.AutoAcceso.Cache.v1";
        private const int SegundosCacheAutomatica = 45;

        private static string IdentidadCache(string usuario, string token)
        {
            return Sha256(URL + "|" + usuario.Trim().ToLowerInvariant() + "|" +
                ObtenerMachineId() + "|" + token);
        }

        private static bool CacheAutomaticaValida(string identidad)
        {
            try
            {
                string valor = AppDomain.CurrentDomain.GetData(
                    ClaveCacheAutomatica) as string;
                if (string.IsNullOrEmpty(valor)) return false;
                string[] partes = valor.Split('|');
                long vence;
                if (partes.Length != 2 || partes[0] != identidad ||
                    !long.TryParse(partes[1], System.Globalization.NumberStyles.Integer,
                        System.Globalization.CultureInfo.InvariantCulture, out vence))
                    return false;
                return System.Diagnostics.Stopwatch.GetTimestamp() < vence;
            }
            catch { return false; }
        }

        private static void GuardarCacheAutomatica(string identidad)
        {
            try
            {
                long vence = System.Diagnostics.Stopwatch.GetTimestamp() +
                    System.Diagnostics.Stopwatch.Frequency * (long)SegundosCacheAutomatica;
                AppDomain.CurrentDomain.SetData(ClaveCacheAutomatica,
                    identidad + "|" + vence.ToString(
                        System.Globalization.CultureInfo.InvariantCulture));
                IniciarRevisionEnSegundoPlano();
            }
            catch { }
        }

        private static void LimpiarCacheAutomatica()
        {
            try { AppDomain.CurrentDomain.SetData(ClaveCacheAutomatica, null); }
            catch { }
        }

        private const string ClaveMonitorAutomatico = "MYG.AutoAcceso.Monitor.v2";
        private const string ClaveMonitorOcupado = "MYG.AutoAcceso.MonitorOcupado.v2";
        private const string ClaveMonitorCandado = "MYG.AutoAcceso.Candado.v2";

        // Este método no espera ninguna respuesta HTTP.
        public static bool IngresoAutomaticoDisponible()
        {
            IniciarRevisionEnSegundoPlano();
            string usuario;
            string token;
            if (!LeerToken(out usuario, out token))
            {
                LimpiarCacheAutomatica();
                return false;
            }
            return CacheAutomaticaValida(IdentidadCache(usuario, token));
        }

        private static void IniciarRevisionEnSegundoPlano()
        {
            try
            {
                // Solo tipos del runtime en AppDomain: compartir el monitor
                // entre las cargas de la DLL sin conversiones entre tipos MYG.
                lock (string.Intern(ClaveMonitorCandado))
                {
                    if (AppDomain.CurrentDomain.GetData(ClaveMonitorAutomatico)
                        is System.Threading.Timer)
                        return;

                    var timer = new System.Threading.Timer(
                        RevisarAccesoEnSegundoPlano, null,
                        System.Threading.Timeout.Infinite,
                        System.Threading.Timeout.Infinite);
                    AppDomain.CurrentDomain.SetData(ClaveMonitorAutomatico, timer);

                    // Si acaba de verificarse al iniciar Revit, esperar 15 s.
                    string usuario;
                    string token;
                    bool vigente = LeerToken(out usuario, out token) &&
                        CacheAutomaticaValida(IdentidadCache(usuario, token));
                    timer.Change(vigente ? 15000 : 0, 15000);
                }
            }
            catch { }
        }

        private static void RevisarAccesoEnSegundoPlano(object estado)
        {
            try
            {
                lock (string.Intern(ClaveMonitorCandado))
                {
                    object ocupado = AppDomain.CurrentDomain.GetData(ClaveMonitorOcupado);
                    if (ocupado is bool && (bool)ocupado) return;
                    AppDomain.CurrentDomain.SetData(ClaveMonitorOcupado, true);
                }
            }
            catch { return; }

            try
            {
                // No usar Revit API, ventanas ni botones desde este hilo.
                IntentarIngresoAutomatico(true);
            }
            catch
            {
                LimpiarCacheAutomatica();
            }
            finally
            {
                try
                {
                    lock (string.Intern(ClaveMonitorCandado))
                        AppDomain.CurrentDomain.SetData(ClaveMonitorOcupado, false);
                }
                catch { }
            }
        }

        public static bool IntentarIngresoAutomatico(bool forzarConsulta = false)
        {
            try
            {
                string usuario;
                string token;
                if (!LeerToken(out usuario, out token))
                {
                    LimpiarCacheAutomatica();
                    return false;
                }

                string identidad = IdentidadCache(usuario, token);
                if (!forzarConsulta && CacheAutomaticaValida(identidad))
                    return true;

                // Conservar la autorización vigente mientras llega la respuesta.
                // Solo un OK la renueva; cualquier rechazo/error la invalida.
                // El plazo local de 45 s limita una solicitud atascada.
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                using (WebClientConTimeout client = new WebClientConTimeout())
                {
                    client.Timeout = 15000;
                    client.Encoding = System.Text.Encoding.UTF8;
                    var datos = new System.Collections.Specialized.NameValueCollection();
                    datos["usuario"] = usuario;
                    datos["pc"] = ObtenerMachineId();
                    datos["token"] = token;
                    byte[] bytes = client.UploadValues(URL, "POST", datos);
                    string respuesta = System.Text.Encoding.UTF8.GetString(bytes).Trim();
                    if (respuesta == "OK")
                    {
                        GuardarCacheAutomatica(identidad);
                        return true;
                    }
                    LimpiarCacheAutomatica();
                    // Una suspensión temporal (H=NO, E=NO o vencimiento)
                    // no borra el token local; el servidor decide si lo acepta.
                    if (respuesta == "TOKEN_INVALIDO" ||
                        respuesta == "OTRA_PC" || respuesta == "NO_EXISTE")
                        BorrarToken();
                    return false;
                }
            }
            catch
            {
                LimpiarCacheAutomatica();
                return false;
            }
        }

        private static bool GuardarToken(
            string usuario,
            string token)
        {
            try
            {
                string carpeta =
                    System.IO.Path.GetDirectoryName(RutaToken);

                System.IO.Directory.CreateDirectory(carpeta);

                string contenido =
                    usuario + "\n" + token;

                byte[] datos =
                    System.Text.Encoding.UTF8.GetBytes(contenido);

                byte[] protegidos =
                    System.Security.Cryptography.ProtectedData.Protect(
                        datos,
                        null,
                        System.Security.Cryptography.DataProtectionScope.CurrentUser);

                System.IO.File.WriteAllBytes(
                    RutaToken,
                    protegidos);

                return true;
            }
            catch
            {
                return false;
            }
        }

        private static bool LeerToken(
            out string usuario,
            out string token)
        {
            usuario = "";
            token = "";

            try
            {
                if (!System.IO.File.Exists(RutaToken))
                    return false;

                byte[] protegidos =
                    System.IO.File.ReadAllBytes(RutaToken);

                byte[] datos =
                    System.Security.Cryptography.ProtectedData.Unprotect(
                        protegidos,
                        null,
                        System.Security.Cryptography.DataProtectionScope.CurrentUser);

                string contenido =
                    System.Text.Encoding.UTF8.GetString(datos);

                int separador = contenido.IndexOf('\n');

                if (separador <= 0 ||
                    separador >= contenido.Length - 1)
                {
                    return false;
                }

                usuario = contenido
                    .Substring(0, separador)
                    .Trim();

                token = contenido
                    .Substring(separador + 1)
                    .Trim();

                return usuario.Length > 0 &&
                       token.Length >= 32;
            }
            catch
            {
                return false;
            }
        }

        private static void BorrarToken()
        {
            LimpiarCacheAutomatica();
            try
            {
                if (System.IO.File.Exists(RutaToken))
                    System.IO.File.Delete(RutaToken);
            }
            catch
            {
            }
        }

        private static string ObtenerMachineId()
        {
            if (!string.IsNullOrWhiteSpace(_machineIdCache))
                return _machineIdCache;

            try
            {
                string machineGuid = "";

                using (Microsoft.Win32.RegistryKey key =
                    Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                        @"SOFTWARE\Microsoft\Cryptography"))
                {
                    if (key != null)
                    {
                        object value = key.GetValue("MachineGuid");

                        if (value != null)
                            machineGuid = value.ToString();
                    }
                }

                if (!string.IsNullOrWhiteSpace(machineGuid))
                {
                    _machineIdCache = Sha256(machineGuid);
                    return _machineIdCache;
                }
            }
            catch
            {
            }

            string respaldo =
                Environment.MachineName + "|" +
                Environment.UserName + "|" +
                Environment.UserDomainName;

            _machineIdCache = Sha256(respaldo);
            return _machineIdCache;
        }

        private static string Sha256(string texto)
        {
            using (System.Security.Cryptography.SHA256 sha =
                System.Security.Cryptography.SHA256.Create())
            {
                byte[] bytes =
                    System.Text.Encoding.UTF8.GetBytes(texto);

                byte[] hash = sha.ComputeHash(bytes);
                System.Text.StringBuilder sb =
                    new System.Text.StringBuilder();

                foreach (byte b in hash)
                    sb.Append(b.ToString("X2"));

                return sb.ToString();
            }
        }
    }

}
