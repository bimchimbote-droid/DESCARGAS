using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{

    // =======================================
    // WEBCLIENT CON TIMEOUT
    // =======================================
    public class WebClientConTimeout : WebClient
    {
        public int Timeout { get; set; }

        public WebClientConTimeout()
        {
            Timeout = 15000;
        }

        protected override WebRequest GetWebRequest(Uri address)
        {
            WebRequest request = base.GetWebRequest(address);

            if (request != null)
            {
                request.Timeout = Timeout;

                HttpWebRequest httpRequest = request as HttpWebRequest;

                if (httpRequest != null)
                {
                    httpRequest.ReadWriteTimeout = Timeout;
                    httpRequest.KeepAlive = false;
                }
            }

            return request;
        }
    }

}
