﻿// =====================================
// HANDLER - SIMPLE WARNING SWALLOWER
// =====================================
using Autodesk.Revit.DB;
using System.Collections.Generic;

public class SimpleWarningSwallower : IFailuresPreprocessor
{
    public FailureProcessingResult PreprocessFailures(
        FailuresAccessor failuresAccessor)
    {
        IList<FailureMessageAccessor> failures =
            failuresAccessor.GetFailureMessages();

        foreach (FailureMessageAccessor failure in failures)
        {
            if (failure.GetSeverity() == FailureSeverity.Warning)
            {
                failuresAccessor.DeleteWarning(failure);
            }
        }

        return FailureProcessingResult.Continue;
    }
}