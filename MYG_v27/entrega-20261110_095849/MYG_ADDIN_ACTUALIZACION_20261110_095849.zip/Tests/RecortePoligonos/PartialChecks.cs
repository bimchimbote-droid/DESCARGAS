using System;
using System.Collections.Generic;
using System.Linq;

public partial class Motor
{
    private void RunPartialCases()
    {
        frame = new MarcoMuro {Origen=new XYZ(0,0,0),U=new XYZ(1,0,0),V=new XYZ(0,1,0),Normal=new XYZ(0,0,1)};
        var subject=Component(Poly(0,0,10,0,10,10,0,10));
        List<LoopMuro> loops;List<ComponenteMuro> owners;int omitted;string why;
        var thinSplit=Component(Poly(.001,-1,4,-1,4,11,.001,11));
        Check(CalcularRestaPoligonosEnPlano(subject,new List<ComponenteMuro>{thinSplit},out loops,out owners,out omitted,out why),"valid island survives a separate short island");
        Check(omitted==1&&owners.Count==1&&!string.IsNullOrEmpty(why),"one omitted island is counted and diagnosed");
        Near(MaterialArea(loops),60,"only valid right island retained");
        Check(owners[0].Exterior.MinU>=4-TOL,"omitted sliver is not restored to original rectangle");

        var split=Component(Poly(4,-1,6,-1,6,11,4,11));
        var triangle=Component(Poly(1,1,3,1,1,3));
        var shiftedTriangle=Component(Poly(1.001,1,3.001,1,1.001,3));
        Check(CalcularRestaPoligonosEnPlano(subject,new List<ComponenteMuro>{split,triangle,shiftedTriangle},out loops,out owners,out omitted,out why),"one invalid union-hole does not abort the other owner");
        Check(omitted==1&&owners.Count==1,"invalid hole omits exactly its owner");
        Near(MaterialArea(loops),40,"owner with short hole edge omitted as whole material");
        Check(owners[0].Exterior.MinU>=6-TOL,"invalid hole never becomes filled material");

        var annulusA=Component(Poly(1,1,5,1,1,5),Poly(1.5,1.5,2,1.5,2,2,1.5,2));
        var annulusB=Component(Poly(1.001,1,5.001,1,1.001,5),Poly(1.5,1.5,2,1.5,2,2,1.5,2));
        Check(CalcularRestaPoligonosEnPlano(subject,new List<ComponenteMuro>{annulusA,annulusB},out loops,out owners,out omitted,out why),"nested material island survives rejected outer owner");
        Check(omitted==1&&owners.Count==1,"nested material owner remains independent");
        Near(MaterialArea(loops),.25,"nested retained island preserves its true area");

        var disjoint=Component(Poly(11,0,12,0,12,10,11,10));
        Check(CalcularRestaPoligonosEnPlano(subject,new List<ComponenteMuro>{disjoint},out loops,out owners,out omitted,out why),"disjoint cutter succeeds");
        Check(omitted==0&&owners.Count==1&&why.Length==0,"no false omission warning for no-cut");
        var cover=Component(Poly(-1,-1,11,-1,11,11,-1,11));
        Check(CalcularRestaPoligonosEnPlano(subject,new List<ComponenteMuro>{cover},out loops,out owners,out omitted,out why),"full coverage succeeds");
        Check(omitted==0&&owners.Count==0&&loops.Count==0,"full coverage remains distinct from omitted islands");
        var onlyThin=Component(Poly(.001,-1,11,-1,11,11,.001,11));
        Check(CalcularRestaPoligonosEnPlano(subject,new List<ComponenteMuro>{onlyThin},out loops,out owners,out omitted,out why),"all uncreatable islands return a completed subtraction");
        Check(omitted==1&&owners.Count==0&&loops.Count==0&&why.Length>0,"all omitted is explicitly counted rather than claimed coverage");

        var pts=new List<MYG_Addin.RecorteClipper.IntPoint>{new MYG_Addin.RecorteClipper.IntPoint(0,0),new MYG_Addin.RecorteClipper.IntPoint(1,0),new MYG_Addin.RecorteClipper.IntPoint(100000000,0),new MYG_Addin.RecorteClipper.IntPoint(100000000,100000000),new MYG_Addin.RecorteClipper.IntPoint(0,100000000)};
        var exact=LoopDesdeCaminoClipper(pts,frame,0,0,10000000);
        Check(exact.Puntos2D.Count==5,"only exact redundant collinear vertex removed");
        Check(ValidarLoopResultado2D(exact,0,out why),"exact simplification preserves a representable loop");
        Near(exact.AreaAbs,100,"exact collinear removal preserves area");
        pts[1]=new MYG_Addin.RecorteClipper.IntPoint(1,1);
        Check(QuitarVerticesRedundantes2D(pts).Count==pts.Count,"a real small notch is never simplified away");

        // Two valid cutter rectangles overlap through a narrow neck. Old PTOL
        // topology treats close nonadjacent edges as touching; the output topology
        // uses TOL while retaining the same minimum edge-creation requirement.
        var nearA=Component(Poly(1,1,3,1,3,3,1,3));var nearB=Component(Poly(2.999,2.999,3.5,2.999,3.5,3.5,2.999,3.5));
        Check(CalcularRestaPoligonosEnPlano(subject,new List<ComponenteMuro>{nearA,nearB},out loops,out owners,out omitted,out why),"real narrow separation does not become an artificial self-crossing");
        Check(omitted==0&&owners.Count==1&&owners[0].Huecos.Count==1,"near topology keeps complete owner and union hole");
        Near(MaterialArea(loops),100-(4+.501*.501-.001*.001),"near topology subtracts exact union area");
        Console.WriteLine("Partial-island regression assertions total: "+checks+" (production helpers; no Revit).");
    }
}
