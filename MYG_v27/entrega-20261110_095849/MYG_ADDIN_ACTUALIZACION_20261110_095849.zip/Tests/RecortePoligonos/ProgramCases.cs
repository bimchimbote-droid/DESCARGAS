using System;
using System.Collections.Generic;
using System.Linq;

public partial class Motor
{
    private int checks;
    private MarcoMuro frame = new MarcoMuro {Origen=new XYZ(0,0,0),U=new XYZ(1,0,0),V=new XYZ(0,1,0),Normal=new XYZ(0,0,1)};
    private void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    private LoopMuro Poly(params double[] xy)
    {
        var p=new List<UV2>();for(int i=0;i<xy.Length;i+=2)p.Add(new UV2(xy[i],xy[i+1]));
        p.Add(new UV2(p[0].U,p[0].V));double ar=Area(p);
        return new LoopMuro{Marco=frame,Puntos2D=p,Puntos3D=p.Select(v=>frame.Origen+frame.U.Multiply(v.U)+frame.V.Multiply(v.V)).ToList(),Area=ar,AreaAbs=Math.Abs(ar),MinU=p.Min(v=>v.U),MaxU=p.Max(v=>v.U),MinV=p.Min(v=>v.V),MaxV=p.Max(v=>v.V)};
    }
    private ComponenteMuro Component(LoopMuro ext,params LoopMuro[] holes){return new ComponenteMuro{Exterior=ext,Huecos=holes.ToList()};}
    private List<LoopMuro> Difference(ComponenteMuro subject,List<ComponenteMuro> cuts)
    {
        List<LoopMuro> result;string diagnostic;
        if(!RestarPoligonosEnPlano(subject,cuts,out result,out diagnostic))throw new Exception(diagnostic);
        return result;
    }
    private double MaterialArea(List<LoopMuro> loops){return ClasificarComponentes(loops).Sum(c=>c.Exterior.AreaAbs-c.Huecos.Sum(h=>h.AreaAbs));}
    private void Near(double a,double b,string label){Check(Math.Abs(a-b)<1e-5,label+" actual="+a+" expected="+b);}
    private void RunCases()
    {
        var subject=Component(Poly(0,0,10,0,10,10,0,10));
        var triangle=Component(Poly(2,2,8,2,5,8));var result=Difference(subject,new List<ComponenteMuro>{triangle});
        Near(MaterialArea(result),82,"triangle cut area");Check(result.Count==2,"triangle keeps hole");
        var annulus=Component(Poly(2,2,8,2,8,8,2,8),Poly(4,4,6,4,6,6,4,6));
        result=Difference(subject,new List<ComponenteMuro>{annulus});Near(MaterialArea(result),68,"annular cut keeps inner island");Check(ClasificarComponentes(result).Count==2,"annulus two components");
        var second=Component(Poly(5,1,9,1,9,9,5,9));
        var a=Difference(subject,new List<ComponenteMuro>{annulus,second});var b=Difference(subject,new List<ComponenteMuro>{second,annulus});Near(MaterialArea(a),MaterialArea(b),"cut union order invariant");
        var concave=Component(Poly(0,0,10,0,10,3,3,3,3,10,0,10));
        result=Difference(concave,new List<ComponenteMuro>{Component(Poly(1,1,7,1,1,7))});Near(MaterialArea(result),MaterialArea(Difference(concave,new List<ComponenteMuro>{Component(Poly(1,7,7,1,1,1))})),"orientation invariant");
        result=Difference(subject,new List<ComponenteMuro>{Component(Poly(4,-1,6,-1,6,11,4,11))});Near(MaterialArea(result),80,"split area");Check(ClasificarComponentes(result).Count==2,"split keeps both islands");
        result=Difference(subject,new List<ComponenteMuro>{Component(Poly(-1,-1,11,-1,11,11,-1,11))});Check(result.Count==0,"full cover is no profile");
        foreach(double mm in new[]{1.0,2.0,3.0}){
            double gap=mm/304.8;result=Difference(subject,new List<ComponenteMuro>{Component(Poly(10+gap,0,11+gap,0,11+gap,10,10+gap,10))});Near(MaterialArea(result),100,"external gap "+mm+"mm");}
        result=Difference(subject,new List<ComponenteMuro>{Component(Poly(10,0,11,0,11,10,10,10))});Near(MaterialArea(result),100,"tangent does not cut material");
        List<LoopMuro> bad;string why;
        Check(!RestarPoligonosEnPlano(subject,new List<ComponenteMuro>{Component(Poly(2,2,8,2,8,8,2,8),Poly(3,3,3.001,3,3.001,4,3,4))},out bad,out why),"invalid short input hole rejected");
        Check(bad.Count==0&&!string.IsNullOrEmpty(why),"rejection clears partial result");
        Check(RestarPoligonosEnPlano(subject,new List<ComponenteMuro>{Component(Poly(0.001,-1,11,-1,11,11,0.001,11))},out bad,out why),"short output island omitted without aborting other components");
        Check(!string.IsNullOrEmpty(why),"omission diagnostic retained");
        Check(bad.Count==0,"short output cannot leak partial result");
        Check(RestarPoligonosEnPlano(subject,new List<ComponenteMuro>{Component(Poly(2,2,8,2,5,8))},out bad,out why,7) && bad.Count==0 && !string.IsNullOrEmpty(why),"invalid projected hole omits its owner without filling it");
        Check(!RestarPoligonosEnPlano(subject,new List<ComponenteMuro>{Component(Poly(double.NaN,0,2,0,2,2,0,2))},out bad,out why),"nonfinite coordinates rejected");
        var uShape=Component(Poly(0,0,10,0,10,10,7,10,7,3,3,3,3,10,0,10),Poly(1,8,9,8,5,1));
        Check(!RestarPoligonosEnPlano(uShape,new List<ComponenteMuro>{triangle},out bad,out why),"hole edge crossing concave notch rejected despite inside vertices");
        var overlappingHoles=Component(Poly(0,0,10,0,10,10,0,10),Poly(1,1,6,1,6,6,1,6),Poly(4,4,9,4,9,9,4,9));
        Check(!RestarPoligonosEnPlano(overlappingHoles,new List<ComponenteMuro>{triangle},out bad,out why),"overlapping subject holes rejected instead of winding phantom fill");
        var nestedHoles=Component(Poly(0,0,10,0,10,10,0,10),Poly(1,1,9,1,9,9,1,9),Poly(3,3,7,3,7,7,3,7));
        Check(!RestarPoligonosEnPlano(subject,new List<ComponenteMuro>{nestedHoles},out bad,out why),"nested holes in same cutter rejected");
        foreach(double theta in new[]{0.17,0.61,1.41}){
            Func<LoopMuro,LoopMuro> tx=lp=>Poly(lp.Puntos2D.Take(lp.Puntos2D.Count-1).SelectMany(v=>new[]{1000+v.U*Math.Cos(theta)-v.V*Math.Sin(theta),-500+v.U*Math.Sin(theta)+v.V*Math.Cos(theta)}).ToArray());
            var movedSubject=Component(tx(subject.Exterior));var movedCut=Component(tx(annulus.Exterior),tx(annulus.Huecos[0]));
            Near(MaterialArea(Difference(movedSubject,new List<ComponenteMuro>{movedCut})),68,"translation/rotation keeps ring and island "+theta);
        }
        var open=Poly(0,0,10,0,10,10,0,10);open.Puntos2D.RemoveAt(open.Puntos2D.Count-1);
        Check(!RestarPoligonosEnPlano(Component(open),new List<ComponenteMuro>{triangle},out bad,out why),"open input rejected instead of silently dropping last vertex");
        frame=new MarcoMuro{Origen=new XYZ(12,-7,30),U=new XYZ(1,0,0),V=new XYZ(0,0.8,0.6),Normal=new XYZ(0,-0.6,0.8)};
        var inclinedSubject=Component(Poly(0,0,10,0,10,10,0,10));var inclinedCut=Component(Poly(2,2,8,2,5,8));
        var inclined=Difference(inclinedSubject,new List<ComponenteMuro>{inclinedCut});
        Near(MaterialArea(inclined),82,"inclined frame preserves physical area");
        foreach(var lp in inclined){
            Check(object.ReferenceEquals(lp.Marco,frame),"inclined result retains original frame");
            foreach(var point in lp.Puntos3D){
                double dot=(point.X-frame.Origen.X)*frame.Normal.X+(point.Y-frame.Origen.Y)*frame.Normal.Y+(point.Z-frame.Origen.Z)*frame.Normal.Z;
                Near(dot,0,"inclined result stays in source plane");
            }
        }
        Console.WriteLine("Polygon fallback: "+checks+" assertions passed (production helpers; Clipper; no Revit).");
    }
    public static int Main(){try{var m=new Motor();m.RunCases();m.RunPartialCases();MembershipChecks.Run(m.Difference,xy=>m.Poly(xy));AdversarialChecks.Run(m.Difference,xy=>m.Poly(xy));return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}
