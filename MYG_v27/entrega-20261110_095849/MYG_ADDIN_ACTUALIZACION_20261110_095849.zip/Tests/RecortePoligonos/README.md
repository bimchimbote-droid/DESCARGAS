# Regresión del respaldo general de polígonos

Requiere Python3 y SDK .NET10. Desde la raíz del código (después de instalar los archivos de esta entrega):

```sh
python3 Tests/RecortePoligonos/run.py .
```

En Windows puedes usar `py` en lugar de `python3`. No agregues este proyecto al add-in. No necesita descargar paquetes NuGet. El script extrae del handler los métodos reales de diferencia, conversión, clasificación y validación; usa también la fuente Clipper vendorizada real. Genera GeneratedMotor.cs y GeneratedClipper.cs en la carpeta de las pruebas; son salidas locales, no archivos para instalar en el add-in.

Las pruebas directas cubren contornos cóncavos/oblicuos, huecos, islas, cortes solapados y orden invertido, tangencia, cobertura completa, separaciones de1/2/3mm, traslación/rotación, coordenadas inválidas, contornos abiertos y rechazo de resultados no creables. Verifican además el retorno de puntos al marco inclinado original con origen XYZ no nulo, sin desplazamiento fuera de su plano.

Un oráculo independiente compara la pertenencia de103896 puntos con `perfil original MENOS unión de regiones cortantes`; calcula su propia inclusión por raycast y no utiliza Clipper ni la clasificación de producción para determinar el resultado esperado. Dos pruebas adversariales exigen rechazar un hueco cuya arista atraviesa la mordida de un exterior cóncavo y huecos solapados del mismo componente.

La implementación conserva el respaldo rectangular anterior cuando devuelve restos válidos. Si no devuelve ninguno, PolyTree distingue cobertura total de piezas pequeñas omitidas. La omisión histórica de bandas pequeñas del respaldo rectangular con otros restos válidos se mantiene sin cambiar ese recorrido. El respaldo general se ejecuta únicamente después de obtener todas las huellas y reconstruye desde el componente original, sin reutilizar un sólido parcialmente descontado. Un resultado vacío representa eliminación total. Las coordenadas enteras usan una rejilla de0.00003048mm con origen local; no se amplían cortantes para cerrar separaciones. PolyTree conserva cada pieza material y sus huecos. Si un exterior o uno de sus huecos no cumple las tolerancias, se omite esa pieza completa con diagnóstico y se mantienen las piezas independientes válidas, incluidas las islas anidadas. Nunca se quita solo un hueco para rellenarlo. Si ninguna pieza es creable, el contador lo distingue de la ocupación total. La rejilla introduce una cuantización pequeña; no es una promesa de exactitud matemática ilimitada.

**Alcance:** se verifica el cálculo2D real con una sustitución mínima de XYZ para las operaciones algebraicas del marco. No se ejecuta el kernel3D de Revit ni se prueban Floor.Create, uniones, materiales, transacciones o el modelo de las capturas. La compilación y prueba funcional en Revit/Windows siguen siendo necesarias.

## Omisión independiente de piezas

Las pruebas nuevas verifican una isla corta junto a otra válida, un hueco inválido que solo invalida a su propietario, la conservación de una isla anidada aunque su antecesor no sea creable, la diferencia entre cobertura total y piezas omitidas, simplificación exclusivamente colineal exacta y separación topológica real inferior a PTOL. Las longitudes mínimas de creación se mantienen; la topología de salida se comprueba con TOL en lugar de confundir proximidad con cruce. Los contactos puntuales entre anillos de PolyTree conservan sus huecos: la creación nativa de Revit decide si el propietario puede crearse. Si falla, el handler de suelos lo omite de forma independiente.

Resultado actual: 39 aserciones de casos previos adaptadas a la omisión autorizada y 24 nuevas (63 en total), 103896 puntos de pertenencia independientes y dos entradas adversariales. El script probar_perfil_inclinado_tarrajeo.py actualizado ejecuta 584 aserciones del adaptador con motor programado, incluida la conservación de perfiles válidos si otro falla. No reproduce el kernel de Revit.
