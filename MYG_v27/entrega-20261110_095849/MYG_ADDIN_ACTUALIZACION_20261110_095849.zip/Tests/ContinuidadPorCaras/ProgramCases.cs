using System;
using System.Collections.Generic;
using System.Linq;

namespace Autodesk.Revit.Exceptions { public class OperationCanceledException : Exception { } }
class Element { public int Id; }
class RevitLinkInstance : Element { }
class Face { }
class PlanarFace : Face { }
class Wall { public string Id; }
class FloorType { }
class WallType { }
class Transform { public static readonly Transform Identity=new Transform(); }
class UIDocument { }
class Document { public readonly List<string> Retained=new List<string>(); }
class CaraTrabajo {
    public Element HostElem,GeoElem; public RevitLinkInstance LinkOrigen;
    public Face Cara; public Transform TransformCara; public bool CrearComoMuro;
}
class Report {
    public int Walls,Floors,SkippedFaces,SkippedProfiles;
    public List<string> Diagnostics;
}
class Behavior {
    public int Count,Skipped; public string Warning="",Diagnostic="";
    public Exception ConfigException,CreateException;
    public bool NullWalls;
}
abstract class Engine {
    public readonly Dictionary<int,Behavior> Plans=new Dictionary<int,Behavior>();
    public readonly List<int> Configured=new List<int>();
    public readonly List<int> CreatedCalls=new List<int>();
    public readonly List<int> ConfiguredLinks=new List<int>();
    public void ConfigurarOrigenDeRecorte(Element origin,RevitLinkInstance link) {
        Configured.Add(origin.Id);ConfiguredLinks.Add(link!=null?link.Id:-1);
        Behavior plan;
        if(Plans.TryGetValue(origin.Id,out plan)&&plan.ConfigException!=null)throw plan.ConfigException;
    }
    protected Behavior Call(Element host) {
        CreatedCalls.Add(host.Id);Behavior result;
        if(!Plans.TryGetValue(host.Id,out result))throw new Exception("Test plan missing for host "+host.Id);
        if(result.CreateException!=null)throw result.CreateException;
        return result;
    }
}
class WallEngine : Engine {
    public List<Wall> CrearMurosDesdeFaceProcesada(Document doc,UIDocument ui,Element host,Face face,Transform tx,WallType type,bool join) {
        Behavior b=Call(host);if(b.NullWalls)return null;
        var result=new List<Wall>();
        for(int i=0;i<b.Count;i++){var w=new Wall{Id="wall-"+host.Id+"-"+i};result.Add(w);doc.Retained.Add(w.Id);}
        return result;
    }
}
class FloorEngine : Engine {
    public int UltimaCantidadPerfilesOmitidos,UltimaCantidadSuelosCreados;
    public string UltimoAvisoParcial="",UltimoDiagnostico="";
    public bool CrearSueloDesdeCaraPlanarProcesada(Document doc,UIDocument ui,Element host,PlanarFace face,Transform tx,FloorType type) {
        Behavior b=Call(host);UltimaCantidadPerfilesOmitidos=b.Skipped;UltimaCantidadSuelosCreados=b.Count;
        UltimoAvisoParcial=b.Warning;UltimoDiagnostico=b.Diagnostic;
        for(int i=0;i<b.Count;i++)doc.Retained.Add("floor-"+host.Id+"-"+i);
        return b.Count>0;
    }
}
class UV2 { }
class LoopMuro { public double AreaAbs=1; public List<UV2> Puntos2D=new List<UV2>{new UV2()}; }
class ComponenteMuro { public int Id;public LoopMuro Exterior=new LoopMuro();public List<LoopMuro> Huecos; }
class Program {
    static int cases,failed,assertions;
    static void Check(bool value,string name){assertions++;if(!value)throw new Exception(name);}
    static CaraTrabajo F(int id,bool wall=false){return new CaraTrabajo{HostElem=new Element{Id=id},Cara=wall?(Face)new Face():new PlanarFace(),CrearComoMuro=wall,TransformCara=Transform.Identity};}
    static List<CaraTrabajo> Faces(params CaraTrabajo[] values){return values.ToList();}
    static void Case(string name,Action action){cases++;try{action();Console.WriteLine("PASS "+name);}catch(Exception e){failed++;Console.Error.WriteLine("FAIL "+name+": "+e.GetType().Name+" "+e.Message);}}
    static List<ComponenteMuro> Owners() {
        var duplicate=new LoopMuro();
        return new List<ComponenteMuro>{
            new ComponenteMuro{Id=1,Huecos=new List<LoopMuro>{null}},
            new ComponenteMuro{Id=2,Huecos=new List<LoopMuro>{new LoopMuro()}},
            new ComponenteMuro{Id=3,Huecos=new List<LoopMuro>()},
            new ComponenteMuro{Id=4,Huecos=new List<LoopMuro>{new LoopMuro{AreaAbs=0}}},
            new ComponenteMuro{Id=5,Huecos=new List<LoopMuro>{duplicate,duplicate}},
            new ComponenteMuro{Id=6,Huecos=null}};
    }
    static int Main(){
        Case("failed floor face does not block later face or undercount its islands",()=>{
            var f=new FloorEngine();var w=new WallEngine();var d=new Document();
            f.Plans[1]=new Behavior{Diagnostic="source wall ID 1318941"};f.Plans[2]=new Behavior{Count=2};
            var r=new BatchHarness().Run(Faces(F(1),F(2)),d,f,w);
            Check(r.Floors==2&&r.SkippedFaces==1,"actual committed island count, skipped failed face");
            Check(f.CreatedCalls.SequenceEqual(new[]{1,2}),"both floor faces processed");
            Check(r.Diagnostics.Any(x=>x.Contains("1318941")),"failed face diagnostic preserved");
        });
        Case("unexpected floor exception preserves earlier creation and processes later face",()=>{
            var f=new FloorEngine();var w=new WallEngine();var d=new Document();
            f.Plans[1]=new Behavior{Count=1};f.Plans[2]=new Behavior{CreateException=new InvalidOperationException("bad face")};f.Plans[3]=new Behavior{Count=3};
            var r=new BatchHarness().Run(Faces(F(1),F(2),F(3)),d,f,w);
            Check(r.Floors==4&&r.SkippedFaces==1,"only middle face skipped");
            Check(d.Retained.SequenceEqual(new[]{"floor-1-0","floor-3-0","floor-3-1","floor-3-2"}),"existing created items retained");
            Check(r.Diagnostics.Any(x=>x.Contains("bad face")),"exception details retained");
        });
        Case("failed wall creation does not stop a horizontal floor",()=>{
            var f=new FloorEngine();var w=new WallEngine();var d=new Document();
            w.Plans[1]=new Behavior{CreateException=new InvalidOperationException("wall failed")};f.Plans[2]=new Behavior{Count=1};
            var r=new BatchHarness().Run(Faces(F(1,true),F(2)),d,f,w);
            Check(r.Walls==0&&r.Floors==1&&r.SkippedFaces==1,"floor remains independent of failed wall");
        });
        Case("origin configuration exception affects only its face",()=>{
            var f=new FloorEngine();var w=new WallEngine();var d=new Document();
            f.Plans[1]=new Behavior{ConfigException=new InvalidOperationException("invalid source")};f.Plans[2]=new Behavior{Count=1};
            var r=new BatchHarness().Run(Faces(F(1),F(2)),d,f,w);
            Check(r.Floors==1&&r.SkippedFaces==1,"later floor still created");
            Check(f.CreatedCalls.SequenceEqual(new[]{2}),"failed origin was never sent to create");
        });
        Case("partial success records omitted profiles and actual floor count without skipping whole face",()=>{
            var f=new FloorEngine();var w=new WallEngine();var d=new Document();
            f.Plans[1]=new Behavior{Count=2,Skipped=3,Warning="three owner profiles omitted"};f.Plans[2]=new Behavior{Count=1};
            var r=new BatchHarness().Run(Faces(F(1),F(2)),d,f,w);
            Check(r.Floors==3&&r.SkippedProfiles==3&&r.SkippedFaces==0,"partial face contributes creations and omitted profile count");
            Check(r.Diagnostics.Any(x=>x.Contains("three owner")),"successful partial result warning recorded");
        });
        Case("invalid face entries do not prevent later valid work",()=>{
            var f=new FloorEngine();var w=new WallEngine();var d=new Document();f.Plans[5]=new Behavior{Count=1};
            var r=new BatchHarness().Run(Faces(null,new CaraTrabajo{Cara=new PlanarFace()},new CaraTrabajo{HostElem=new Element{Id=3}},new CaraTrabajo{HostElem=new Element{Id=4},Cara=new Face()},F(5)),d,f,w);
            Check(r.SkippedFaces==4&&r.Floors==1,"all invalid entries skipped individually");
            Check(f.CreatedCalls.SequenceEqual(new[]{5}),"only valid planar floor reached engine");
        });
        Case("null wall results and missing floor diagnostics allow following faces",()=>{
            var f=new FloorEngine();var w=new WallEngine();var d=new Document();
            w.Plans[1]=new Behavior{NullWalls=true};w.Plans[2]=new Behavior{Count=2};f.Plans[3]=new Behavior();f.Plans[4]=new Behavior{Count=1};
            var r=new BatchHarness().Run(Faces(F(1,true),F(2,true),F(3),F(4)),d,f,w);
            Check(r.Walls==2&&r.Floors==1&&r.SkippedFaces==2,"false/null affects only failing entries");
            Check(r.Diagnostics.Any(x=>x.Contains("false sin diagnóstico")),"missing floor diagnostic gets explicit fallback message");
        });
        Case("user cancellation propagates rather than being swallowed as a bad face",()=>{
            var f=new FloorEngine();var w=new WallEngine();var d=new Document();
            f.Plans[1]=new Behavior{Count=1};f.Plans[2]=new Behavior{CreateException=new Autodesk.Revit.Exceptions.OperationCanceledException()};f.Plans[3]=new Behavior{Count=1};
            bool canceled=false;try{new BatchHarness().Run(Faces(F(1),F(2),F(3)),d,f,w);}catch(Autodesk.Revit.Exceptions.OperationCanceledException){canceled=true;}
            Check(canceled,"cancellation remains cancellation");Check(f.CreatedCalls.SequenceEqual(new[]{1,2}),"nothing after cancellation processed");
            Check(d.Retained.SequenceEqual(new[]{"floor-1-0"}),"committed earlier floor still retained");
        });
        Case("native and linked origin configuration remains correctly routed",()=>{
            var f=new FloorEngine();var w=new WallEngine();var d=new Document();f.Plans[1]=new Behavior{Count=1};
            var face=F(1);face.GeoElem=new Element{Id=100};face.LinkOrigen=new RevitLinkInstance{Id=77};
            var r=new BatchHarness().Run(Faces(face),d,f,w);
            Check(f.Configured.SequenceEqual(new[]{100})&&f.ConfiguredLinks.SequenceEqual(new[]{77}),"link extraction owner preserved");
            Check(f.CreatedCalls.SequenceEqual(new[]{1})&&r.Floors==1,"host remains creation host");
        });
        Case("wall category in an interference diagnostic does not route a horizontal face to the wall engine",()=>{
            var f=new FloorEngine();var w=new WallEngine();var d=new Document();
            f.Plans[1]=new Behavior{Count=1,Skipped=1,Warning="candidate native ID 1318941 category Muros"};
            var r=new BatchHarness().Run(Faces(F(1)),d,f,w);
            Check(r.Floors==1&&w.CreatedCalls.Count==0,"horizontal face stays a floor");
            Check(r.Diagnostics.Any(x=>x.Contains("Muros")),"interference category retained as diagnostic only");
        });
        Case("snapshot wall path skips owner instead of filling rejected holes, keeps following owners",()=>{
            var created=new WallGuardHarness().RunSnapshot(Owners());
            Check(created.SequenceEqual(new[]{2,3,6}),"snapshot creation cannot follow removal of an owned hole");
        });
        Case("face wall path skips owner instead of filling rejected holes, keeps following owners",()=>{
            var created=new WallGuardHarness().RunFace(Owners());
            Check(created.SequenceEqual(new[]{2,3,6}),"face creation cannot follow removal of an owned hole");
        });
        Console.WriteLine("Batch face loop: "+cases+" cases; "+assertions+" assertions; "+failed+" failures (programmed engines; no Revit).");return failed==0?0:1;
    }
}
