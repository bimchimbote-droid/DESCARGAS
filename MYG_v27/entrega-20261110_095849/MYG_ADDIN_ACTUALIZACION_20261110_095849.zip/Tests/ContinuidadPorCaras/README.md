# Regresión del procesamiento independiente por cara

Requiere Python 3 y SDK .NET 10. No agregar este proyecto a la solución del add-in ni copiar sus salidas a Revit.

Desde la raíz del código instalado:

```sh
python3 Tests/ContinuidadPorCaras/run.py .
```

En Windows puede usarse `py` en lugar de `python3`; `dotnet` debe estar en PATH. El script extrae el bloque `foreach (CaraTrabajo item in carasParaCrear)` REAL del handler de selección de losas y lo compila con motores programados. No mantiene una copia alternativa del bucle. Genera `GeneratedBatch.cs`, `bin/` y `obj/` localmente; no son archivos para incorporar al add-in.

Doce casos verifican que una cara que devuelve false, una excepción creando un suelo o un muro y una excepción al configurar el origen no interrumpen las siguientes caras. Comprueban también que se conservan creaciones anteriores, se cuentan las islas realmente creadas y los perfiles omitidos, los avisos de éxito parcial se registran, los elementos nulos se omiten por separado, los vínculos conservan su origen, la cancelación del usuario se propaga y la palabra Muros en un diagnóstico de interferencia no cambia la creación horizontal a un muro.

Resultado de esta entrega: 12 casos, 24 aserciones, 0 fallos. La versión anterior de ese selector (base de la entrega 195450) produce 6 casos fallidos. Dos casos adicionales ejecutan los bloques reales de sanitización y omisión del propietario en los caminos de muros por cara y por contorno; si un hueco se pierde, debe omitirse su propietario y conservar los propietarios siguientes. El handler de muros anterior falla esos dos casos. Puede contrastarse sin reemplazar el código con:

```sh
python3 Tests/ContinuidadPorCaras/run.py . --source /ruta/al/selector-anterior.cs
```

Para contrastar específicamente el guardado de huecos anterior, añade `--wall-source /ruta/al/handler-muros-anterior.cs` en lugar de `--source`. El control negativo debe devolver código distinto de cero. No modifica los archivos de producción.

Alcance: prueba de control de flujo con el bucle real y dobles de motores/documento. No ejecuta collectors, selección nativa, kernel geométrico, Floor.Create, Wall.Create ni transacciones reales de Revit. Que una creación programada anterior siga en la lista no demuestra por sí solo el comportamiento de las transacciones de Autodesk; el aislamiento del TransactionGroup por isla se revisa en el código de producción y debe validarse dentro de Revit.

Los casos de huecos extraen SanitizarHuecos y el control real anterior a la creación. Los dobles modelan la inclusión del punto interior y la similitud por identidad; verifican la omisión cuando la sanitización devuelve un subconjunto (hueco nulo, área degenerada o duplicado), no la geometría real de la sanitización. La propiedad jerárquica PolyTree se valida en la suite de polígonos separada.
