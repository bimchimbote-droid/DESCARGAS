#!/usr/bin/env python3
"""Exercise the real batch face loop with programmed engines; does not run Revit."""
import argparse
from pathlib import Path
import re
import subprocess
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('repository',type=Path)
p.add_argument('--source',type=Path,help='Optional SelectorLosas source override for baseline checks')
p.add_argument('--wall-source',type=Path,help='Optional wall handler override for ownership guard baseline checks')
a=p.parse_args()
root=Path(__file__).resolve().parent
source=a.source or a.repository/'MYG/Funcionalidades/Estructuras/Tarrajeo/SeleccionarLosasTarrajeoHandler.cs'
s=source.read_text(encoding='utf-8-sig')
m=re.search(r'            foreach \(CaraTrabajo item in carasParaCrear\)',s)
if not m:raise ValueError('Batch face loop not found in real source')
start=s.index('{',m.start());end=start+1;depth=1
while depth:
    depth+=(s[end]=='{')-(s[end]=='}');end+=1
loop=s[m.start():end]
wrapper='''// Generated from the selected production loop; do not edit.
using System;
using System.Collections.Generic;
using System.Linq;
class BatchHarness {
    public WallType TipoMuro=new WallType();
    public FloorType TipoSuelo=new FloorType();
    public bool PermitirUnion=false;
    private string ConstruirDiagnosticoCara(CaraTrabajo item,string detail) {
        return "Face " + (item.HostElem != null ? item.HostElem.Id : -1) + ": " + detail;
    }
    public Report Run(List<CaraTrabajo> carasParaCrear, Document doc, FloorEngine creadorSuelos, WallEngine creadorMuros) {
        var uidoc=new UIDocument();
        int murosCreados=0, suelosCreados=0, carasOmitidas=0, perfilesOmitidos=0;
        var diagnosticos=new List<string>();
__LOOP__
        return new Report {Walls=murosCreados,Floors=suelosCreados,SkippedFaces=carasOmitidas,SkippedProfiles=perfilesOmitidos,Diagnostics=diagnosticos};
    }
}
'''
wall_path=a.wall_source or a.repository/'MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs'
wall=wall_path.read_text(encoding='utf-8-sig')
def member(text,pattern):
    m=re.search(pattern,text)
    if not m:raise ValueError('Production member missing: '+pattern)
    start=text.index('{',m.start());end=start+1;depth=1
    while depth:
        depth+=(text[end]=='{')-(text[end]=='}');end+=1
    return text[m.start():end]
def owner_guard(method_name):
    method=member(wall,r'    public List<Wall> '+method_name+r'\s*\(')
    start=method.index('                List<LoopMuro> huecos = SanitizarHuecos(')
    end=method.index('                double zMin =',start)
    return method[start:end]
sanitizer=member(wall,r'    private List<LoopMuro> SanitizarHuecos\s*\(')
guards='''
class WallGuardHarness {
    private UV2 PuntoInteriorSeguro(LoopMuro loop) { return new UV2(); }
    private bool PuntoEnPoligono(UV2 p,List<UV2> points) { return true; }
    private bool Similar(LoopMuro a,LoopMuro b) { return object.ReferenceEquals(a,b); }
__SANITIZER__
    public List<int> RunSnapshot(List<ComponenteMuro> componentes) {
        var created=new List<int>();
        foreach(ComponenteMuro componente in componentes) {
__SNAPSHOT__
            created.Add(componente.Id);
        }
        return created;
    }
    public List<int> RunFace(List<ComponenteMuro> componentes) {
        var created=new List<int>();
        foreach(ComponenteMuro componente in componentes) {
__FACE__
            created.Add(componente.Id);
        }
        return created;
    }
}
'''.replace('__SANITIZER__',sanitizer).replace('__SNAPSHOT__',owner_guard('CrearMurosDesdeLoopPlanarProcesado')).replace('__FACE__',owner_guard('CrearMurosDesdeCaraPlanarProcesada'))
(root/'GeneratedBatch.cs').write_text(wrapper.replace('__LOOP__',loop)+guards,encoding='utf-8')
raise SystemExit(subprocess.run(['dotnet','run','--project',str(root/'Regression.csproj')]).returncode)
