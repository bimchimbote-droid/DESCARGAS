# Descontar la interferencia y continuar con las demás piezas

A. COMPORTAMIENTO
La categoría Muros del diagnóstico identifica al elemento interferente; la cara horizontal sigue generando suelos. Se resta del revestimiento la huella que ocupa su espesor. Se conservan piezas y huecos válidos. Una pieza no creable se omite sin abortar sus hermanas ni otras caras. Si falla un hueco se omite su pieza completa, nunca se rellena la interferencia. Todos omitidos se distingue de cobertura completa. La limpieza solo elimina vértices exactamente colineales redundantes; no mueve bordes para forzar resultados. Se mantiene el respaldo rectangular anterior cuando devuelve restos válidos.

B. ARCHIVOS DEL ADD-IN: REEMPLAZAR JUNTOS
- MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs
- MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs
- MYG/Funcionalidades/Estructuras/Tarrajeo/SeleccionarLosasTarrajeoHandler.cs
Los tres archivos ya están incluidos en el proyecto. El lote conserva su reporte silencioso en archivo; por cara puede mostrarse un único resumen al terminar. No hay diálogos por cada isla del lote.

C. CONTENIDO Y BASE
Solo archivos modificados/nuevos, pruebas y documentación. Base fuente: bimchimbote-droid/MYG_v27_reestructurado, 56682a0299f9cb62dacecce6ef269a13c864c4b3, con avances acumulados. Base handlers: ZIP195450, DESCARGAS commit f656f2b5678354c076c71ac80ff433bce687d535. Selector de losas: última entrega180759, idéntica al checkout antes de este cambio. Se conservan Clipper, buscador, orientación y dependencias anteriores. No se sustituye por MYG_v27/main.

D. INSTALACIÓN
Cierra Revit y respalda tu solución y DLL. Compara cambios locales: reemplazar archivos completos puede sobrescribir modificaciones posteriores. Copia juntos los tres archivos sobre sus mismas rutas y ejecuta Limpiar solución y Recompilar solución en Visual Studio/Windows. Instala la DLL resultante con Revit cerrado en una copia de prueba; conserva manifiesto e iconos. No se entrega DLL.
Alternativa al reemplazo: desde la raíz compatible, git apply --check RUTA/ACTUALIZACION.patch y luego git apply RUTA/ACTUALIZACION.patch. No aplicar ambas opciones. El parche se comprobó sobre las bases indicadas.

E. CONFIGURACIÓN
Sin nuevos paquetes, referencias ni cambios de proyecto. CONSERVAR Clipper.cs y su Compile instalados con195450. TarrajeoForm.cs, proyecto y biblioteca Clipper quedan SIN CAMBIOS y fuera de este ZIP. No hay eliminaciones.

F. PRUEBAS Y ALCANCE
Ver VALIDACION.md. Tests son opcionales, NO incorporarlos al add-in. Tests/RecortePoligonos actualiza la suite de195450: conservar run.py, MembershipChecks.cs y AdversarialChecks.cs anteriores, que no se duplican por estar sin cambios. La suite nueva Tests/ContinuidadPorCaras se incluye completa. Python3 y SDK.NET10 para pruebas aisladas. Desde la raíz del código instalado:
python3 Tests/RecortePoligonos/run.py .
python3 Pruebas/probar_perfil_inclinado_tarrajeo.py --source MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs
python3 Pruebas/probar_respaldo_suelos_tarrajeo.py --source MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs
python3 Tests/ContinuidadPorCaras/run.py .
En Windows puede usarse py en vez de python3.

G. GITHUB
Se publica únicamente este ZIP en una ruta nueva de bimchimbote-droid/DESCARGAS por autorización vigente. Se mantienen entregas previas. No se hace commit/push al repositorio del código ni se instala en tu PC. En Visual Studio revisa Cambios de Git, compila/prueba, después Commit y Push cuando decidas sincronizar.

H. LIMITACIONES
El RVT de las capturas no se reprodujo. Las pruebas usan helpers reales y dobles de API; no ejecutan el kernel, transacciones ni Floor.Create reales. Compilación completa pendiente en Windows/MSBuild Framework/COM. Un contorno realmente no creable puede seguir omitiéndose; no se garantiza crear todo el material matemático. Prueba huecos, piezas separadas, vínculos y continuación después de errores en una copia del modelo.
