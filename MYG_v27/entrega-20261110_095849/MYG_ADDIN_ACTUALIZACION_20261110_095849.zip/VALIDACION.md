# Validación
- 63 aserciones de recorte/omisiones, 103896 puntos de pertenencia independientes y 2 casos adversariales aprobados.
- Adaptador planar: 584 aserciones aprobadas.
- Flujo de suelo: 47 aserciones aprobadas, incluidos éxitos parciales, huecos, excepciones por isla y todos omitidos con retorno false.
- Lote por caras: 12 casos/24 aserciones aprobados: fallos false/throw no bloquean caras siguientes, éxitos previos se mantienen, conteos reales y guardas de huecos en consumidores verticales.
- Roslyn C#7.3:180 fuentes activas,9 recursos,3 None sin errores sintácticos ni rutas faltantes.
- git diff --check y parche aplicado/reproducido byte por byte correctos.
- Estos resultados son aislados; no certifican geometría/transacciones de Revit ni el RVT de las capturas. El proyecto completo depende de Windows/MSBuild Framework/COM y sigue pendiente allí; no se entrega DLL compilada.
