# Regresión de unión suelo-muro

Estas pruebas ejecutan el método `UnirSueloConMurosIntersectantes` extraído del handler entregado. También extraen `MetrosAPies`; no mantienen una copia manual de las implementaciones.

Usan dobles deterministas de documento, geometría, consulta y transacción. Verifican la secuencia de operaciones y sus decisiones, **no** la geometría ni las transacciones reales de Autodesk Revit. Los cambios de unión y orden solo son visibles en los dobles después de `Regenerate`, para detectar consultas prematuras.

Requisitos: .NET SDK 8 y Python 3. Desde esta carpeta:

```bash
bash run.sh ../../MYG/Funcionalidades/Arquitectura/Habitaciones/SUELOSDESDEROOM_EJECUCION_HANDLER.cs
```

Si el SDK está fuera de PATH, use `DOTNET_CMD=/ruta/dotnet bash run.sh /ruta/al/handler.cs`.

Se genera `GeneratedHandler.cs` con el SHA-256 del handler leído. No agregue este proyecto a la solución del add-in ni sus dobles al proyecto MYG. La entrega excluye `GeneratedHandler.cs`, `bin/` y `obj/`.

Casos (14): unión nueva con muro inicialmente cortante; corrección y conteo de unión existente con orden incorrecto; unión correcta conservada; rechazo nativo aislado y continuación; fallo explícito o silencioso al invertir orden; rollback que preserva una unión previa; caja del suelo en su altura real; contacto solo por cara aceptado por la API nativa simulada; unión existente fuera de la caja actual; dos capas que cortan el mismo muro de forma independiente; deduplicación; propagación de fallos de regeneración.

Pendiente en Windows/Revit: comprobar contactos y sólidos reales, aceptación de JoinGeometry, muros automáticamente unidos, geometría tras regeneración/commit, corte visible y orden final en una o dos capas usando el modelo de la captura.
