// Deterministic contract doubles for orchestration tests. These do not implement Revit geometry.
namespace Autodesk.Revit.Exceptions
{
    public class RegenerationFailedException : System.Exception { public RegenerationFailedException(string message):base(message){} }
}
namespace Autodesk.Revit.DB
{
    public class ElementId
    {
        public long Value {get;} public ElementId(long value){Value=value;}
        public static ElementId InvalidElementId=new(-1);
        public override bool Equals(object value)=>value is ElementId id&&id.Value==Value;
        public override int GetHashCode()=>Value.GetHashCode();
        public static bool operator==(ElementId a,ElementId b)=>ReferenceEquals(a,b)||(a is not null&&b is not null&&a.Value==b.Value);
        public static bool operator!=(ElementId a,ElementId b)=>!(a==b);
    }
    public class XYZ
    {
        public double X{get;}public double Y{get;}public double Z{get;}
        public XYZ(double x,double y,double z){X=x;Y=y;Z=z;}
    }
    public class BoundingBoxXYZ { public XYZ Min{get;set;}public XYZ Max{get;set;} }
    public class Outline:System.IDisposable
    {
        public XYZ MinimumPoint{get;}public XYZ MaximumPoint{get;}
        public Outline(XYZ min,XYZ max){MinimumPoint=min;MaximumPoint=max;}
        public void Dispose(){}
    }
    public abstract class ElementFilter:System.IDisposable
    {
        public abstract bool PassesFilter(Document doc,ElementId id);
        public void Dispose(){}
    }
    public class BoundingBoxIntersectsFilter:ElementFilter
    {
        readonly Outline box;
        public BoundingBoxIntersectsFilter(Outline outline){box=outline;}
        public override bool PassesFilter(Document doc,ElementId id)
        {
            var b=doc.GetElement(id).Box;
            doc.LastFilterBox=box;
            return b is not null&&b.Min.X<=box.MaximumPoint.X&&b.Max.X>=box.MinimumPoint.X&&b.Min.Y<=box.MaximumPoint.Y&&b.Max.Y>=box.MinimumPoint.Y&&b.Min.Z<=box.MaximumPoint.Z&&b.Max.Z>=box.MinimumPoint.Z;
        }
    }
    public class Element
    {
        public ElementId Id{get;set;}
        public BoundingBoxXYZ Box{get;set;}
        public virtual BoundingBoxXYZ get_BoundingBox(object view)=>Box;
    }
    public class Floor:Element{}
    public class Wall:Element
    {
        public bool JoinAccept=true;
        public bool DefaultFloorCutter=false;
        public bool SwitchThrows=false;
        public bool SwitchSilent=false;
    }
    public readonly record struct Pair(long FloorId,long WallId);
    public readonly record struct JoinState(bool Joined,bool FloorCuts);
    public class Document
    {
        public List<Element> Elements=new();
        public Dictionary<Pair,JoinState> Joins=new();
        public Dictionary<Pair,JoinState> Pending=new();
        public List<string> Calls=new();
        public Outline LastFilterBox;
        public int RegenerationCount;
        public bool ThrowOnRegenerate;
        public Element GetElement(ElementId id)=>Elements.FirstOrDefault(x=>x.Id==id);
        public void Regenerate()
        {
            Calls.Add("regenerate");RegenerationCount++;
            if(ThrowOnRegenerate)throw new Autodesk.Revit.Exceptions.RegenerationFailedException("regeneration failed");
            foreach(var pair in Pending)Joins[pair.Key]=pair.Value;
            Pending.Clear();
        }
    }
    public class FilteredElementCollector:IEnumerable<Element>
    {
        readonly Document doc;IEnumerable<Element> query;
        public FilteredElementCollector(Document document){doc=document;query=document.Elements;}
        public FilteredElementCollector OfClass(Type t){query=query.Where(x=>t.IsAssignableFrom(x.GetType()));return this;}
        public FilteredElementCollector WhereElementIsNotElementType()=>this;
        public FilteredElementCollector WherePasses(ElementFilter filter){query=query.Where(x=>filter.PassesFilter(doc,x.Id));return this;}
        public ICollection<ElementId> ToElementIds()=>query.Select(x=>x.Id).ToList();
        public IEnumerator<Element> GetEnumerator()=>query.GetEnumerator();
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()=>GetEnumerator();
    }
    public enum TransactionStatus{Uninitialized,Started,Committed,RolledBack}
    public class SubTransaction:System.IDisposable
    {
        readonly Document doc;
        Dictionary<Pair,JoinState> savedJoins,savedPending;
        TransactionStatus status;
        public SubTransaction(Document document){doc=document;}
        public TransactionStatus Start(){savedJoins=new(doc.Joins);savedPending=new(doc.Pending);status=TransactionStatus.Started;doc.Calls.Add("start");return status;}
        public TransactionStatus GetStatus()=>status;
        public TransactionStatus Commit(){status=TransactionStatus.Committed;doc.Calls.Add("commit");return status;}
        public TransactionStatus RollBack(){doc.Joins=new(savedJoins);doc.Pending=new(savedPending);status=TransactionStatus.RolledBack;doc.Calls.Add("rollback");return status;}
        public void Dispose(){if(status==TransactionStatus.Started)RollBack();}
    }
    public static class JoinGeometryUtils
    {
        static Pair Key(Element floor,Element wall)=>new(floor.Id.Value,wall.Id.Value);
        public static bool AreElementsJoined(Document doc,Element floor,Element wall)=>doc.Joins.TryGetValue(Key(floor,wall),out var state)&&state.Joined;
        public static ICollection<ElementId> GetJoinedElements(Document doc,Element floor)=>doc.Joins.Where(x=>x.Key.FloorId==floor.Id.Value&&x.Value.Joined).Select(x=>new ElementId(x.Key.WallId)).ToList();
        public static void JoinGeometry(Document doc,Element floor,Element wall)
        {
            doc.Calls.Add("join:"+wall.Id.Value);
            var w=(Wall)wall;
            if(!w.JoinAccept)throw new InvalidOperationException("Native join rejected this pair");
            doc.Pending[Key(floor,wall)]=new(true,w.DefaultFloorCutter);
        }
        public static bool IsCuttingElementInJoin(Document doc,Element floor,Element wall)
        {
            doc.Calls.Add("is-cutting:"+wall.Id.Value);
            if(!AreElementsJoined(doc,floor,wall))throw new InvalidOperationException("Query requires regenerated join");
            return doc.Joins[Key(floor,wall)].FloorCuts;
        }
        public static void SwitchJoinOrder(Document doc,Element floor,Element wall)
        {
            doc.Calls.Add("switch:"+wall.Id.Value);
            var w=(Wall)wall;
            if(w.SwitchThrows)throw new InvalidOperationException("Switch order rejected");
            if(!AreElementsJoined(doc,floor,wall))throw new InvalidOperationException("Switch requires regenerated join");
            if(!w.SwitchSilent)doc.Pending[Key(floor,wall)]=new(true,!doc.Joins[Key(floor,wall)].FloorCuts);
        }
    }
}
