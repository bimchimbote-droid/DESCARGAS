#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
handler_path=${1:-../../MYG/Funcionalidades/Arquitectura/Habitaciones/SUELOSDESDEROOM_EJECUCION_HANDLER.cs}
python3 extract_methods.py "$handler_path"
"${DOTNET_CMD:-dotnet}" run --project Regression.csproj --configuration Release
