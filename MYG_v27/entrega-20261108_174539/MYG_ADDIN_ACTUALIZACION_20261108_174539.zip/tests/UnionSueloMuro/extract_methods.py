#!/usr/bin/env python3
"""Extract production methods at run time; no manually copied implementation."""
from pathlib import Path
import hashlib,re,sys
source_path=Path(sys.argv[1]).resolve()
source=source_path.read_text(encoding='utf-8-sig')
methods=[]
for name in ['UnirSueloConMurosIntersectantes','MetrosAPies']:
    match=re.search(r'^        private[^\n]*\b'+re.escape(name)+r'\s*\(',source,re.M)
    if not match:raise SystemExit('Production method not found: '+name)
    end=re.search(r'^        }\s*$',source[match.start():],re.M)
    if not end:raise SystemExit('Closing brace not found: '+name)
    methods.append(source[match.start():match.start()+end.end()])
output=Path(__file__).parent/'GeneratedHandler.cs'
output.write_text('// Generated from production source. Do not edit.\n// SHA256 '+hashlib.sha256(source_path.read_bytes()).hexdigest()+'\nusing Autodesk.Revit.DB;\nusing System;\nusing System.Collections.Generic;\nusing System.Linq;\npartial class Handler\n{\n'+'\n\n'.join(methods)+'\n}\n')
print('Extracted',len(methods),'production methods from',source_path.name)
