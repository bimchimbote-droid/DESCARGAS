using Autodesk.Revit.DB;
using System.Reflection;
partial class Handler
{
    static BoundingBoxXYZ Box(double z=10)=>new(){Min=new XYZ(0,0,z),Max=new XYZ(5,5,z+.2)};
    static (Document doc,Floor floor,Wall wall) Model(long wallId=2)
    {
        var doc=new Document();var floor=new Floor{Id=new ElementId(1),Box=Box()};var wall=new Wall{Id=new ElementId(wallId),Box=Box()};doc.Elements.AddRange(new Element[]{floor,wall});return(doc,floor,wall);
    }
    static void True(bool condition,string message){if(!condition)throw new Exception(message);}
    static void Equal(int actual,int expected,string message){if(actual!=expected)throw new Exception(message+": expected "+expected+", actual "+actual);}
    static bool FloorCuts(Document doc,Floor floor,Wall wall)=>doc.Joins.TryGetValue(new(floor.Id.Value,wall.Id.Value),out var state)&&state.Joined&&state.FloorCuts;
    (int count,int failed,List<string> log) Execute(Document doc,Floor floor,List<ElementId> hosts=null)
    {
        var method=typeof(Handler).GetMethod("UnirSueloConMurosIntersectantes",BindingFlags.Instance|BindingFlags.NonPublic);
        var parameters=method.GetParameters();var args=new object[parameters.Length];var log=new List<string>();
        for(int i=0;i<parameters.Length;i++)
        {
            var t=parameters[i].ParameterType;
            args[i]=t==typeof(Document)?doc:t==typeof(Floor)?floor:t==typeof(List<ElementId>)?hosts:t==typeof(List<string>)?log:t==typeof(int).MakeByRefType()?0:throw new Exception("Unknown production argument: "+parameters[i]);
        }
        try
        {
            int count=(int)method.Invoke(this,args);int failed=0;
            for(int i=0;i<parameters.Length;i++)if(parameters[i].ParameterType==typeof(int).MakeByRefType())failed+=(int)args[i];
            return(count,failed,log);
        }
        catch(TargetInvocationException e){System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(e.InnerException).Throw();throw;}
    }
    void NewWallDefaultCutter()
    {
        var(doc,floor,wall)=Model();var r=Execute(doc,floor);
        Equal(r.count,1,"new cut confirmed");True(FloorCuts(doc,floor,wall),"floor must be final cutter");
        True(doc.Calls.Contains("join:2")&&doc.Calls.Contains("switch:2"),"native join and switch both called");
        True(doc.RegenerationCount>=3,"regenerated before candidate search and after join/switch");
    }
    void ExistingWrongOrder()
    {
        var(doc,floor,wall)=Model();doc.Joins[new(1,2)]=new(true,false);var r=Execute(doc,floor);
        Equal(r.count,1,"existing join corrected and counted");True(FloorCuts(doc,floor,wall),"existing join order corrected");True(!doc.Calls.Contains("join:2"),"existing join not recreated");
    }
    void ExistingFloorCutter()
    {
        var(doc,floor,wall)=Model();doc.Joins[new(1,2)]=new(true,true);var r=Execute(doc,floor);
        Equal(r.count,1,"already-correct join verified and counted");True(FloorCuts(doc,floor,wall),"already floor cutter retained");True(!doc.Calls.Contains("switch:2"),"no unnecessary switch");
    }
    void NewFloorDefaultCutter()
    {
        var(doc,floor,wall)=Model();wall.DefaultFloorCutter=true;var r=Execute(doc,floor);
        Equal(r.count,1,"native floor-first join confirmed");True(FloorCuts(doc,floor,wall),"floor default order retained");True(!doc.Calls.Contains("switch:2"),"no switch away from correct cutter");
    }
    void NativeRejectionAndContinue()
    {
        var(doc,floor,wall)=Model();wall.JoinAccept=false;
        var next=new Wall{Id=new ElementId(3),Box=Box(),DefaultFloorCutter=true};doc.Elements.Add(next);var r=Execute(doc,floor);
        Equal(r.count,1,"rejected pair does not block next wall");True(!doc.Joins.ContainsKey(new(1,2)),"rejected pair leaves no join");True(FloorCuts(doc,floor,next),"next pair succeeds");True(r.log.Any(x=>x.Contains("2")),"rejected wall identified");
    }
    void SwitchFailureRollsBackNewJoin()
    {
        var(doc,floor,wall)=Model();wall.SwitchThrows=true;var r=Execute(doc,floor);
        Equal(r.count,0,"wall-prevailing join never counted as success");True(r.failed>0,"unconfirmed floor-priority pair counted");True(!doc.Joins.ContainsKey(new(1,2)),"new join rolled back if priority fails");True(r.log.Any(x=>x.Contains("2")),"failed wall identified");
    }
    void SilentSwitchFailureDetected()
    {
        var(doc,floor,wall)=Model();wall.SwitchSilent=true;var r=Execute(doc,floor);
        Equal(r.count,0,"silent no-op switch not accepted");True(r.failed>0,"silent order failure reported");True(!doc.Joins.ContainsKey(new(1,2)),"no-op cutter outcome rolled back");
    }
    void ExistingJoinPreservedOnRollback()
    {
        var(doc,floor,wall)=Model();wall.SwitchThrows=true;doc.Joins[new(1,2)]=new(true,false);var r=Execute(doc,floor);
        Equal(r.count,0,"uncorrected existing join not successful");True(doc.Joins[new(1,2)].Joined&&!doc.Joins[new(1,2)].FloorCuts,"rollback preserves preexisting join");
    }
    void RealFloorHeightAndOutsideWall()
    {
        var(doc,floor,wall)=Model();wall.DefaultFloorCutter=true;
        var highWall=new Wall{Id=new ElementId(3),Box=Box(13)};doc.Elements.Add(highWall);var r=Execute(doc,floor);
        Equal(r.count,1,"only slab-height wall searched");True(!doc.Calls.Contains("join:3"),"wall at different height never joined by bbox search");
        True(doc.LastFilterBox.MinimumPoint.Z>9.9&&doc.LastFilterBox.MaximumPoint.Z<10.3,"uses actual floor box at picked elevation");
    }
    void ContactOnlyNativeAcceptance()
    {
        var(doc,floor,wall)=Model();
        // Shared face only: no positive-volume intersection. Native acceptance is
        // deliberately independent from an interference-report classification.
        wall.Box=new BoundingBoxXYZ{Min=new XYZ(5,0,10),Max=new XYZ(6,5,10.2)};
        wall.DefaultFloorCutter=false;var r=Execute(doc,floor);
        Equal(r.count,1,"native join accepted contact despite no volume overlap");
        True(FloorCuts(doc,floor,wall),"floor prevails for contact-only join");
        True(doc.Calls.Contains("join:2"),"no interference prefilter blocks native attempt");
    }
    void ExistingJoinOutsideCurrentBox()
    {
        var(doc,floor,wall)=Model();wall.Box=Box(13);
        doc.Joins[new(1,2)]=new(true,false);var r=Execute(doc,floor);
        Equal(r.count,1,"existing join checked even if current cut geometry no longer overlaps bbox");
        True(FloorCuts(doc,floor,wall),"outside-box existing join corrected");
    }
    void TwoSlabsCutSameWall()
    {
        var(doc,lower,wall)=Model();
        lower.Box=new BoundingBoxXYZ{Min=new XYZ(0,0,10),Max=new XYZ(5,5,10.05)};
        var upper=new Floor{Id=new ElementId(4),Box=new BoundingBoxXYZ{Min=new XYZ(0,0,10.05),Max=new XYZ(5,5,10.062)}};
        wall.Box=new BoundingBoxXYZ{Min=new XYZ(0,0,9),Max=new XYZ(5,5,13)};doc.Elements.Add(upper);
        var first=Execute(doc,lower);var second=Execute(doc,upper);
        Equal(first.count,1,"lower layer cut verified");Equal(second.count,1,"upper layer cut verified");
        True(FloorCuts(doc,lower,wall)&&FloorCuts(doc,upper,wall),"both layers prevail independently over same wall");
    }
    void KnownHostDeduplicated()
    {
        var(doc,floor,wall)=Model();wall.DefaultFloorCutter=true;var r=Execute(doc,floor,new(){wall.Id,wall.Id});
        Equal(r.count,1,"duplicate host counted once");Equal(doc.Calls.Count(x=>x=="join:2"),1,"native join attempted once per pair");
    }
    void FatalRegenerationPropagates()
    {
        var(doc,floor,wall)=Model();doc.ThrowOnRegenerate=true;bool thrown=false;
        try{Execute(doc,floor);}catch(Autodesk.Revit.Exceptions.RegenerationFailedException){thrown=true;}
        True(thrown,"fatal Revit regeneration errors must propagate");
    }
    static void Main()
    {
        var h=new Handler();var cases=new (string,Action)[]{
            ("native join then floor-priority switch",h.NewWallDefaultCutter),
            ("existing wall-priority join corrected",h.ExistingWrongOrder),
            ("existing floor-priority join verified",h.ExistingFloorCutter),
            ("native floor-priority join retained",h.NewFloorDefaultCutter),
            ("native rejection isolated and subsequent wall processed",h.NativeRejectionAndContinue),
            ("switch failure rolls back new join",h.SwitchFailureRollsBackNewJoin),
            ("silent switch failure detected",h.SilentSwitchFailureDetected),
            ("preexisting join preserved on rollback",h.ExistingJoinPreservedOnRollback),
            ("actual floor elevation limits candidates",h.RealFloorHeightAndOutsideWall),
            ("contact-only candidate reaches native join",h.ContactOnlyNativeAcceptance),
            ("existing join outside bbox still verified",h.ExistingJoinOutsideCurrentBox),
            ("both slab layers prevail over same wall",h.TwoSlabsCutSameWall),
            ("host deduplication",h.KnownHostDeduplicated),
            ("fatal regeneration error propagates",h.FatalRegenerationPropagates)};
        foreach(var c in cases){c.Item2();Console.WriteLine("PASS "+c.Item1);}Console.WriteLine($"{cases.Length} passed; 0 failed. Deterministic orchestration doubles only; no Revit integration executed.");
    }
}
