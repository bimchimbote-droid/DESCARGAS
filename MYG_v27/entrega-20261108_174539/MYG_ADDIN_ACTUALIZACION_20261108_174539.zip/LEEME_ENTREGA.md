# Unión con prioridad del suelo sobre los muros

## A. Cambio implementado

Cada suelo creado, único o cada una de las dos capas, busca muros del documento actual alrededor de su geometría a la altura real. Ya no se exige que pasen el filtro de interferencias para intentar la unión: ese filtro no equivale a la operación Unir geometría.

Por cada pareja candidata se ejecuta la API nativa JoinGeometryUtils.JoinGeometry cuando hace falta, se regenera el documento, se consulta IsCuttingElementInJoin y se usa SwitchJoinOrder si el muro es el cortante. Se regenera nuevamente y se exige estar unidos Y que el suelo sea el cortante antes de confirmar la operación. También se revisan uniones existentes.

Si no puede confirmarse el orden, se revierte esa operación individual y se registra el par por ID; ya no se conserva ni contabiliza como éxito una unión nueva que deje prevalecer al muro. El informe distingue parejas con orden de corte confirmado y candidatos sin unión/corte confirmado. Una unión preexistente que Revit rechace invertir conserva su estado anterior y se informa como no confirmada.

Los muros dejan de restarse del boceto también cuando no hay quiebres de puertas. Así se conserva el solape que la unión necesita para cortar el muro con el suelo. Se mantiene el descuento de otras categorías. No se modificaron las cotas de superficie picada, el apilamiento, los quiebres de 0.13 m ni la selección de superficies vinculadas de la entrega anterior.

## Base utilizada

Checkout bimchimbote-droid/MYG_v27_reestructurado, HEAD da11b13a3f5ce35b9565bf4d5bd27cb761091102, MÁS el cambio local completo publicado en DESCARGAS en commit a92e2796ad0b02e9f40a1ba2417c24091ae85b46:
MYG_v27/entrega-20261108_173346/MYG_ADDIN_ACTUALIZACION_20261108_173346.zip.

Se comprobó que el archivo al iniciar esta corrección coincidía byte por byte con ese ZIP. Se conservaron sus cambios y no se reemplazó por main de MYG_v27.

SHA-256 del handler anterior: 3647358d29b6e6fd8cc6fecb03627d2f925107c89791dfe855d30a43ece09309
SHA-256 del handler nuevo: c385f7482fd020ebc10248f7480e598d94004ab0f92587cebf65f68160593e33

## B. Intervenciones

| Ruta exacta | Acción | Descripción |
| --- | --- | --- |
| MYG/Funcionalidades/Arquitectura/Habitaciones/SUELOSDESDEROOM_EJECUCION_HANDLER.cs | REEMPLAZAR | Archivo completo actualizado; única fuente del add-in afectada. |
| CAMBIOS_UNION.patch | CREAR, alternativa de instalación | Parche puntual desde la entrega anterior; no aplicar además del reemplazo completo. |
| tests/UnionSueloMuro/Regression.csproj | CREAR, prueba opcional | Ejecutable .NET 8 independiente. |
| tests/UnionSueloMuro/RevitDoubles.cs | CREAR, prueba opcional | Dobles deterministas de la API. |
| tests/UnionSueloMuro/Program.cs | CREAR, prueba opcional | 14 casos de regresión de unión/orden/transacción. |
| tests/UnionSueloMuro/extract_methods.py | CREAR, prueba opcional | Extrae el método real del archivo final. |
| tests/UnionSueloMuro/run.sh | CREAR, prueba opcional | Ejecuta las pruebas. |
| tests/UnionSueloMuro/README.md | CREAR, documentación | Alcance y ejecución de pruebas. |
| LEEME_ENTREGA.md | CREAR, documentación | Este archivo. |
| MANIFIESTO.json | CREAR, documentación | Relación de archivos y hashes. |

SIN CAMBIOS y fuera del ZIP: formulario, comando, proyecto, paquetes, recursos y pruebas de la entrega anterior. No hay eliminaciones ni DLL compilada.

## C/D. Instalación

Respalde su handler actual y su DLL funcional. Compare el archivo con la base y hashes indicados; reemplazarlo completo puede sobrescribir modificaciones locales o posteriores.

Elija UNA alternativa:

1. REEMPLAZAR: extraiga en una carpeta temporal y copie solo el handler a la misma ruta relativa de su solución. Ya está incluido en MYG.csproj; no hace falta agregarlo.
2. MODIFICAR: si conserva cambios locales, compare primero el parche y, desde la raíz de su solución, ejecute `git apply --check CAMBIOS_UNION.patch` y luego `git apply CAMBIOS_UNION.patch`. Si no aplica limpiamente, integre los bloques con comparación de archivos; no fuerce ni sobrescriba sus avances. El parche fue aplicado a la base anterior en una carpeta de validación y produjo exactamente los mismos bytes del archivo completo entregado.

No aplique ambos procedimientos. No agregue los dobles ni el proyecto de pruebas al add-in. En Windows, revise el diff y compile con las herramientas y referencias reales de Revit/Office que ya requiere su proyecto. Cierre Revit antes de sustituir la DLL, conserve el .addin y los iconos y pruebe en una copia del modelo.

## E. Configuración

No se agregaron paquetes, referencias ni ajustes de proyecto. Se usa JoinGeometryUtils para muros y suelos nativos, no vacíos nuevos ni cortes genéricos que requieran otras familias. Se conserva el framework original; su compatibilidad con Revit 2027 sigue pendiente de la compilación Windows.

## F. Validación ejecutada

- 14 pruebas nuevas aprobadas, 0 fallidas. Ejecutan el método final extraído con dobles deterministas y verifican la secuencia de llamadas, regeneración, orden de corte, rollback, continuidad tras rechazos, uniones existentes, caja a altura real, contacto simulado, deduplicación y dos capas.
- 10 regresiones anteriores de quiebres, candidatos y cotas, repetidas: 10 aprobadas, 0 fallidas. No se incluyen nuevamente sus fuentes porque no cambiaron.
- Roslyn C# 7.3: 179 archivos activos completos analizados, 0 errores de sintaxis.
- git diff --check sin errores. El handler sigue incluido una sola vez en el proyecto; no se modificó el proyecto.
- Parche aplicado y comparado byte por byte contra el archivo final: coincide.
- Compilación completa intentada con MSBuild .NET 8 en Linux: FALLÓ por MSB4803, ResolveComReference requiere MSBuild de .NET Framework. Faltan las referencias reales Windows/Revit; el conflicto EPPlus preexistente permanece. No se generó una DLL validada.

Para repetir las pruebas nuevas, con .NET SDK 8 y Python 3, desde la raíz extraída:

```bash
bash tests/UnionSueloMuro/run.sh
```

Los dobles confirman decisiones de código; NO implementan Autodesk Revit ni prueban sólidos, aceptación real de JoinGeometry, transacciones o cortes visibles. AreElementsJoined e IsCuttingElementInJoin confirman relación y orden de corte, no una medición del volumen eliminado del muro.

### Prueba pendiente en el modelo real

1. Crear un suelo único que atraviese el muro de la captura; repetir con dos capas y con superficie picada. Confirmar en sección/3D que cada suelo prevalece sobre el muro en la zona donde ambos sólidos se solapan.
2. Con Unir geometría/Cambiar orden de unión, verificar que el suelo es cortante de cada muro, incluidos muros de acabado y estructurales del documento actual.
3. Repetir con puerta/quiebre 0.13 m y sin puertas, y con Descontar intersecciones activado y desactivado. Revisar que el boceto del suelo no se recorta por los muros.
4. Probar una unión existente con orden contrario y una unión ya correcta. Revisar las cotas y el apilamiento y conservar los quiebres de puerta.
5. Revisar el informe final y el diagnóstico por ID ante rechazos. Comprobar también muros próximos sin contacto, inclinados y en otra altura.

## G. Publicación y GitHub

Publicar este ZIP en bimchimbote-droid/DESCARGAS no actualiza su PC ni MYG_v27/MYG_v27_reestructurado. No se hizo commit ni push del código. Tras instalar y probar en Visual Studio: revise Git Changes, seleccione los cambios deseados, haga Commit y luego Push cuando lo decida.

## H. Límites concretos

La caja de búsqueda puede incluir muros próximos que realmente no se intersectan. Revit decide si acepta la unión; sus advertencias no se ocultan y puede informar elementos unidos sin intersección. Una relación de unión no sustituye comprobar el corte físico dentro del modelo. No se extiende el boceto ni se mueve ningún muro para crear contacto inexistente. No se cambia geometría del modelo vinculado: el alcance confirmado es el documento actual. Si un muro está en un grupo, restringido o no admite unión/cambio de orden, se informa el rechazo y se conserva el resto del lote válido.
