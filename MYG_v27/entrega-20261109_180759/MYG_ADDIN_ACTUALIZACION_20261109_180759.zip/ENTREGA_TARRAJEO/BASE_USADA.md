# Base y conservación

- Checkout de trabajo: bimchimbote-droid/MYG_v27_reestructurado.
- Commit original: da11b13a3f5ce35b9565bf4d5bd27cb761091102 (master).
- Se conserva el estado local de la entrega anterior de alturas:
  DESCARGAS commit 2bbb1f69ea3b9f90ae420735c0685641e3638123,
  MYG_ADDIN_ACTUALIZACION_20261109_175118.zip,
  SHA-256 a310c88101bf92919546e8eb3343826c154c26eb74895d516bdcd45b86c987e5.
- No se reemplazó por MYG_v27 main a41d354e8206e401a881aacfff3f5da7dfe74d00,
  que es la base original anterior a la reestructuración.
- Se preservan los cambios locales anteriores de licencia, LoginCommand,
  ALINEARTUBOS, ProjectElevation, TarrajeoAlturas/Core y sus pruebas.
- MYG.csproj y sus dependencias permanecen byte por byte como al empezar.
- ARCHIVOS.json registra hashes base y finales; CAMBIOS.patch se comprobó y
  aplicó en una copia aislada del estado base, obteniendo bytes finales idénticos.
- Reemplazar archivos completos puede sobrescribir avances locales posteriores:
  si no coinciden los hashes base, combinar con el parche en lugar de sustituir.
