# Tarrajeo / Encofrado: descuentos y búsqueda en vivo

## Comportamiento

- Los recortes de muros planos y suelos examinan TODO el espesor físico del
  revestimiento, sin entrar detrás de la cara. Una invasión a 5–12 mm en un
  revestimiento de 15 mm ya no queda fuera de una sonda de solo 2 mm.
- Se descuenta únicamente la huella del volumen realmente intersectado. Cada
  superficie se procesa por separado y sus huellas se unen con restas sucesivas;
  no se emplea una envolvente convexa para rellenar huecos o unir islas.
- Solo participan sólidos visibles en la vista activa. Se conservan filtros,
  categorías, ocultación temporal, CustomExporter y visibilidad de vínculos.
- Considerar vínculos ahora gobierna también los cortantes vinculados, tanto
  por caras como por elementos, no solo la selección del anfitrión.
- Si una resta/reconstrucción falla, se omite el paño y se informa, en lugar
  de volver a crear el perfil completo que se solaparía con el obstáculo.
- Los tipos de suelo y muro de AMBAS ventanas son editables y filtran por
  subcadena mientras escribes, sin distinguir mayúsculas o tildes. Borrar
  restaura el catálogo; Enter confirma y Escape recupera la selección anterior.
  Selecciona un resultado de la lista antes de iniciar la creación.

## Instalar

1. Cierra Revit y respalda los 10 archivos REEMPLAZAR de ARCHIVOS.json.
2. Esta entrega se aplica sobre la versión reestructurada con la corrección
   de alturas anterior ya instalada. Compara los hashes sha256_base antes de
   reemplazar. Copia la carpeta MYG/ respetando las rutas de tu solución.
3. Si tus archivos tienen cambios posteriores, usa CAMBIOS.patch para combinar
   solo esta intervención. Desde la raíz de tu repositorio, comprueba primero:
   git apply --check ENTREGA_TARRAJEO/CAMBIOS.patch
   Después de revisar y solo si pasa, aplica:
   git apply ENTREGA_TARRAJEO/CAMBIOS.patch
   Elige reemplazar archivos O aplicar el parche; no ambos.
4. No reemplaces MYG.csproj, recursos, dependencias ni configuración. No se
   necesitan inclusiones nuevas: el helper de búsqueda va en TarrajeoForm.cs,
   que ya estaba compilado. Conserva ese archivo junto con ElementosForm.
5. Pruebas/ contiene 3 proyectos separados. No agregues sus Program.cs ni los
   dobles geométricos/WinForms al proyecto del add-in.
6. Recompila en Visual Studio sobre Windows, abre Revit y usa la nueva MYG.dll.
   La corrección afecta nuevas creaciones: no recorta elementos ya generados.

## Configuración y pruebas

Sin paquetes/referencias nuevas para el add-in. Los proyectos de pruebas
separados requieren SDK .NET 10, con Roslyn incluido en el SDK:

dotnet run --project Pruebas/TarrajeoBusqueda.Tests/TarrajeoBusqueda.Tests.csproj -c Release
dotnet run --project Pruebas/TarrajeoRecortes.Tests/TarrajeoRecortes.Tests.csproj -c Release
dotnet run --project Pruebas/TarrajeoSuelosRecortes.Tests/TarrajeoSuelosRecortes.Tests.csproj -c Release

## GitHub

Publicar este ZIP en DESCARGAS no actualiza tu PC ni el repositorio del código.
Tras instalar y probar, en Visual Studio abre Cambios de Git, revisa los cambios,
haz Commit y luego Push cuando tú decidas. No se ha hecho Push del código.

Lee VALIDACION.md: hay límites importantes para muros curvos y booleanos reales.
