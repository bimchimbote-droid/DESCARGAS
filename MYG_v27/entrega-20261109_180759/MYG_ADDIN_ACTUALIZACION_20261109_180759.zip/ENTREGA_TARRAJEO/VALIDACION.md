# Validación ejecutada y límites

## Comprobaciones reales

- 17/17 pruebas aisladas de búsqueda y estado de selectores: helpers reales
  extraídos con Roslyn y dobles WinForms. Incluye tildes, edición, cursor,
  cero coincidencias, catálogo completo al borrar, Enter/Escape y selección.
- 17/17 pruebas aisladas de métodos reales de recorte de muros: espesor físico,
  invasión a 5–12 mm, sólidos detrás/fuera, tangencia, huecos, L e islas.
  Los vectores, clasificación y triangulación son dobles geométricos.
- 11/11 pruebas de proyección de suelos e integración de fuente: contornos
  oblicuos, concavidad, normal negativa, cota, huecos y aristas no admitidas.
- 25/25 comprobaciones anteriores de alturas conservadas y aprobadas.
- Roslyn: 179 fuentes, Debug/Release, sin errores de sintaxis; 9 recursos y
  3 None existentes. git diff --check aprobado.
- Se verificó la propagación de ConsiderarVinculos en los seis selectores y
  que el proyecto y los cambios anteriores de licencia no fueron alterados.
- Parche aplicado a una copia de la base y comparado byte por byte.

## Compilación completa

Intentada Release|x64. Resultado: salida 1, MSB4803 ResolveComReference requiere
MSBuild .NET Framework de Windows. Reaparece advertencia preexistente MSB3277
por EPPlus.Interfaces. No se generó MYG.dll nueva. Las pruebas separadas sí
compilaron con .NET 10, sin ejecutar el motor de Revit.

## Pendiente en Windows/Revit

1. Copia del modelo: muro de 15 mm y obstáculo visible que invade a 5–12 mm.
2. Cortantes L, huecos y dos regiones separadas: conservar concavidad/islas.
3. Elementos tangentes, detrás de la cara o fuera del espesor: no descontar.
4. Ocultar elemento/categoría o aplicar filtro/Hide-Isolate: no debe cortar.
5. Vínculo visible/oculto y casilla activada/desactivada; repetir por elementos.
6. Suelos superiores/inferiores e inclinados: comprobar recorte y contacto.
7. En ambas ventanas escribir, pegar, borrar, usar flechas/Enter/Escape y
   comprobar que el tipo realmente elegido es el utilizado al crear.
8. Confirmar que se conserva la altura corregida con ProjectElevation.

## Límites concretos

- Estas pruebas NO validan booleanos reales de Revit, controles WinForms
  nativos ni el modelo del usuario. No se garantiza una resta universal.
- Se necesitan sólidos con volumen computable por Revit. Una malla abierta
  o geometría sin Solid no permite la misma operación booleana.
- Caras curvas/oblicuas se discretizan donde hace falta. Segmentos menores
  que ShortCurveTolerance o errores de reconstrucción pueden omitir el paño.
- El recorte descuenta la huella de la interferencia a todo el espesor; no
  modela rebajes parciales de espesor variable dentro de un Wall/Floor estándar.
- Revit no permite este perfil arbitrario de recorte conservando un Wall curvo:
  se comprueba su volumen real y, si hay interferencia o no puede comprobarse,
  se revierte su creación y se avisa. No se crea el muro curvo entero solapado.
- Las nuevas reglas no modifican revestimientos existentes; regenerar solo
  los elementos erróneos en una copia del modelo.
