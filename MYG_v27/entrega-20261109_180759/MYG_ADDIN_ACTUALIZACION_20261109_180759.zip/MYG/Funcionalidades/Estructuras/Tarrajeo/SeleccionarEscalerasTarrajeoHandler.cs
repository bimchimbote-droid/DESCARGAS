﻿// =====================================
// HANDLER V24 - SELECCIONAR ESCALERAS - VISTA ACTIVA REAL
// - Mantiene snapshot de caras verticales y procesamiento de tramos/descansos/soportes.
// - Usa Tarrajeo_MurosHandler V75 como autoridad de visibilidad de la vista activa.
// - Antes de extraer caras, ignora temporalmente uniones donde un elemento OCULTO
//   esté cortando un componente nativo de la escalera.
// - Restaura siempre las uniones al finalizar.
// - Caras inferiores/inclinadas usan Tarrajeo_SuelosHandler V29.
// =====================================
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

public class SeleccionarEscalerasTarrajeoHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public TarrajeoElementosForm Form;

    public FloorType TipoSuelo;
    public WallType TipoMuro;
    public bool PermitirUnion;
    public bool ConsiderarVinculos;

    // Motores comunes de creación.
    public Tarrajeo_MurosHandler CreadorMuros;
    public Tarrajeo_SuelosHandler CreadorSuelos;

    public List<ElementId> ElementosSeleccionados = new List<ElementId>();

    // Se admite una pequeña desviación para no perder contrapasos o laterales
    // que Revit devuelve con una normal casi vertical, pero no exactamente 0.
    private const double TolNormalVertical = 0.02;
    private const double TolCaraSuperior = 0.001;
    private const double MinAreaCara = 0.0001;

    private class CaraTrabajo
    {
        // Elemento perteneciente al documento activo:
        // - nativo: componente real de escalera;
        // - vínculo: RevitLinkInstance.
        public Element HostElem;

        // Elemento geométrico real que aporta la cara:
        // tramo, descanso, soporte o escalera principal.
        public Element GeoElem;

        // Escalera raíz + todos sus tramos, descansos y soportes. Se envían
        // juntos al motor para que no se recorten entre sí.
        public List<Element> OrigenesRecorte;

        // Instancia específica del vínculo, cuando corresponda.
        public RevitLinkInstance LinkOrigen;

        // Para suelos se conserva la PlanarFace original.
        public Face Cara;
        public Transform TransformCara;

        // Para contrapasos y laterales NO se conserva Face, porque los objetos
        // de geometría de Revit pueden invalidarse después de una Transaction.
        // Se guarda un snapshot inmutable del loop ya transformado al host.
        public List<XYZ> PuntosLoopModelo;
        public XYZ NormalModelo;

        public bool CrearComoMuro;
    }

    private class ElementoTrabajo
    {
        // En vínculos será el RevitLinkInstance.
        public Element HostElem;

        // Escalera real dentro del documento nativo o LinkDocument.
        public Element GeoElem;

        // Conjunto completo de la escalera para exclusión de autorrecortes.
        public List<Element> OrigenesRecorte;

        public RevitLinkInstance LinkOrigen;
        public Transform TransformCara;
    }

    private class CaraGeometrica
    {
        public Face Cara;
        public Transform TransformCara;
    }

    public void Execute(UIApplication app)
    {
        UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

        if (uidoc == null)
        {
            TaskDialog.Show("MYG", "No se encontró el documento activo.");
            MostrarFormulario();
            return;
        }

        Document doc = uidoc.Document;

        List<TarrajeoVistaActivaUnionesHelper.UnionOcultaInvertida> unionesOcultasInvertidas =
            new List<TarrajeoVistaActivaUnionesHelper.UnionOcultaInvertida>();

        try
        {
            //-------------------------------------------------
            // TOMAR DATOS DESDE EL FORMULARIO
            //-------------------------------------------------
            if (Form != null)
            {
                TipoSuelo = Form.TipoSueloSeleccionado;
                TipoMuro = Form.TipoMuroSeleccionado;
                PermitirUnion = Form.PermitirUnion;
                ConsiderarVinculos = Form.ConsiderarVinculos;
            }

            //-------------------------------------------------
            // VALIDAR TIPO DE SUELO O MURO
            //-------------------------------------------------
            if (TipoSuelo == null && TipoMuro == null)
            {
                TaskDialog.Show(
                    "MYG",
                    "Debe seleccionar un tipo de suelo o un tipo de muro.");

                MostrarFormulario();
                return;
            }

            //-------------------------------------------------
            // SELECCIONAR ESCALERAS
            //-------------------------------------------------
            ObjectType tipoSeleccion = ConsiderarVinculos
                ? ObjectType.LinkedElement
                : ObjectType.Element;

            IList<Reference> refs = uidoc.Selection.PickObjects(
                tipoSeleccion,
                new EscalerasTarrajeoSelectionFilter(doc, ConsiderarVinculos),
                ConsiderarVinculos
                    ? "Seleccione escaleras de vínculos"
                    : "Seleccione escaleras");

            if (refs == null || refs.Count == 0)
            {
                MostrarFormulario();
                return;
            }

            List<ElementoTrabajo> escalerasSeleccionadas =
                ObtenerElementosTrabajo(doc, refs);

            ElementosSeleccionados = escalerasSeleccionadas
                .Where(x => x != null && x.HostElem != null)
                .Select(x => x.HostElem.Id)
                .Distinct()
                .ToList();

            if (escalerasSeleccionadas.Count == 0)
            {
                MostrarFormulario();
                return;
            }

            //-------------------------------------------------
            // VISTA ACTIVA REAL - PREPARAR MOTORES ANTES DE LEER CARAS
            //-------------------------------------------------
            Tarrajeo_MurosHandler creadorMuros =
                CreadorMuros ?? new Tarrajeo_MurosHandler();

            Tarrajeo_SuelosHandler creadorSuelos =
                CreadorSuelos ?? new Tarrajeo_SuelosHandler();

            creadorMuros.UiDoc = uidoc;
            creadorSuelos.UiDoc = uidoc;
            creadorMuros.ConsiderarVinculos = ConsiderarVinculos;
            creadorSuelos.ConsiderarVinculos = ConsiderarVinculos;

            creadorMuros.PrepararNuevaEjecucion();
            creadorSuelos.PrepararNuevaEjecucion();

            //-------------------------------------------------
            // REUNIR COMPONENTES NATIVOS PARA RECUPERAR CARAS CORTADAS
            // POR ELEMENTOS OCULTOS EN LA VISTA ACTIVA
            //-------------------------------------------------
            List<Element> elementosGeometricosEscalera = new List<Element>();

            foreach (ElementoTrabajo escaleraTrabajo in escalerasSeleccionadas)
            {
                if (escaleraTrabajo == null)
                    continue;

                List<ElementoTrabajo> componentesVista =
                    ObtenerComponentesGeometricosEscalera(escaleraTrabajo);

                foreach (ElementoTrabajo componenteVista in componentesVista)
                {
                    if (componenteVista == null)
                        continue;

                    if (componenteVista.OrigenesRecorte != null &&
                        componenteVista.OrigenesRecorte.Count > 0)
                    {
                        elementosGeometricosEscalera.AddRange(
                            componenteVista.OrigenesRecorte.Where(x => x != null));
                    }
                    else if (componenteVista.GeoElem != null)
                    {
                        elementosGeometricosEscalera.Add(componenteVista.GeoElem);
                    }
                }
            }

            unionesOcultasInvertidas =
                TarrajeoVistaActivaUnionesHelper
                .InvertirTemporalmenteUnionesOcultasQueCortan(
                    doc,
                    elementosGeometricosEscalera,
                    creadorMuros);

            //-------------------------------------------------
            // PREPROCESAR CARAS DE TRAMOS, DESCANSOS Y SOPORTES
            //-------------------------------------------------
            List<CaraTrabajo> carasParaCrear = new List<CaraTrabajo>();
            HashSet<string> keysGlobales = new HashSet<string>();

            int escalerasProcesadas = 0;
            int componentesProcesados = 0;
            int carasOmitidas = 0;
            int carasSuperioresOmitidas = 0;

            foreach (ElementoTrabajo escaleraTrabajo in escalerasSeleccionadas)
            {
                if (escaleraTrabajo == null ||
                    escaleraTrabajo.GeoElem == null ||
                    escaleraTrabajo.HostElem == null)
                {
                    continue;
                }

                escalerasProcesadas++;

                List<ElementoTrabajo> componentes =
                    ObtenerComponentesGeometricosEscalera(escaleraTrabajo);

                foreach (ElementoTrabajo componente in componentes)
                {
                    if (componente == null || componente.GeoElem == null)
                        continue;

                    componentesProcesados++;

                    List<CaraGeometrica> caras = ObtenerCarasValidasEnModelo(
                        componente.GeoElem,
                        componente.TransformCara ?? Transform.Identity,
                        keysGlobales);

                    foreach (CaraGeometrica caraGeo in caras)
                    {
                        Face cara = caraGeo != null ? caraGeo.Cara : null;
                        Transform transformCaraReal =
                            caraGeo != null && caraGeo.TransformCara != null
                                ? caraGeo.TransformCara
                                : Transform.Identity;

                        if (cara == null)
                        {
                            carasOmitidas++;
                            continue;
                        }

                        if (cara.Area <= MinAreaCara)
                        {
                            carasOmitidas++;
                            continue;
                        }

                        XYZ normal = ObtenerNormalCara(
                            cara,
                            transformCaraReal);

                        if (normal == null || normal.GetLength() <= 1e-9)
                        {
                            carasOmitidas++;
                            continue;
                        }

                        normal = normal.Normalize();

                        //-------------------------------------------------
                        // PRIMERO: CARAS VERTICALES
                        // Aquí entran:
                        // - laterales de tramos;
                        // - laterales de descansos;
                        // - contrapasos;
                        // - caras verticales de soportes.
                        //
                        // Esta evaluación debe ocurrir ANTES de omitir caras
                        // superiores, porque algunas caras casi verticales
                        // pueden tener un Normal.Z positivo muy pequeño.
                        //-------------------------------------------------
                        if (Math.Abs(normal.Z) <= TolNormalVertical)
                        {
                            if (TipoMuro == null)
                            {
                                carasOmitidas++;
                                continue;
                            }

                            List<XYZ> snapshotLoop = ObtenerLoopExteriorModelo(
                                cara,
                                transformCaraReal,
                                normal);

                            if (snapshotLoop == null || snapshotLoop.Count < 4)
                            {
                                carasOmitidas++;
                                continue;
                            }

                            carasParaCrear.Add(new CaraTrabajo
                            {
                                HostElem = componente.HostElem,
                                GeoElem = componente.GeoElem,
                                OrigenesRecorte = componente.OrigenesRecorte,
                                LinkOrigen = componente.LinkOrigen,
                                Cara = null,
                                TransformCara = Transform.Identity,
                                PuntosLoopModelo = snapshotLoop,
                                NormalModelo = normal,
                                CrearComoMuro = true
                            });

                            continue;
                        }

                        //-------------------------------------------------
                        // OMITIR HUELLAS Y CARAS SUPERIORES
                        //-------------------------------------------------
                        if (normal.Z > TolCaraSuperior)
                        {
                            carasSuperioresOmitidas++;
                            continue;
                        }

                        //-------------------------------------------------
                        // CARA INFERIOR O INCLINADA HACIA ABAJO → SUELO
                        // Incluye fondo de tramo y fondo de descansos.
                        //-------------------------------------------------
                        if (TipoSuelo == null)
                        {
                            carasOmitidas++;
                            continue;
                        }

                        PlanarFace caraPlana = cara as PlanarFace;

                        if (caraPlana == null)
                        {
                            carasOmitidas++;
                            continue;
                        }

                        carasParaCrear.Add(new CaraTrabajo
                        {
                            HostElem = componente.HostElem,
                            GeoElem = componente.GeoElem,
                            OrigenesRecorte = componente.OrigenesRecorte,
                            LinkOrigen = componente.LinkOrigen,
                            Cara = cara,
                            TransformCara = transformCaraReal,
                            CrearComoMuro = false
                        });
                    }
                }
            }

            if (carasParaCrear.Count == 0)
            {
                TaskDialog.Show(
                    "MYG - Tarrajeo por Escaleras",
                    "No se encontraron caras válidas para crear tarrajeo.\n\n" +
                    "Escaleras procesadas: " + escalerasProcesadas + "\n" +
                    "Componentes procesados: " + componentesProcesados + "\n" +
                    "Caras superiores omitidas: " + carasSuperioresOmitidas + "\n" +
                    "Caras omitidas: " + carasOmitidas);

                MostrarFormulario();
                return;
            }

            //-------------------------------------------------
            // CREAR TARRAJEO / ENCOFRADO
            //-------------------------------------------------
            int murosCreados = 0;
            int suelosCreados = 0;

            foreach (CaraTrabajo item in carasParaCrear)
            {
                if (item == null ||
                    item.HostElem == null ||
                    item.GeoElem == null ||
                    (item.CrearComoMuro
                        ? (item.PuntosLoopModelo == null ||
                           item.PuntosLoopModelo.Count < 4 ||
                           item.NormalModelo == null)
                        : item.Cara == null))
                {
                    carasOmitidas++;
                    continue;
                }

                //-------------------------------------------------
                // CARA VERTICAL → MURO
                //-------------------------------------------------
                if (item.CrearComoMuro)
                {
                    creadorMuros.ConfigurarOrigenesDeRecorte(
                        item.OrigenesRecorte ?? new List<Element>() { item.GeoElem },
                        item.LinkOrigen);

                    List<Wall> murosNuevos =
                        creadorMuros.CrearMurosDesdeLoopPlanarProcesado(
                            doc,
                            uidoc,
                            item.HostElem,
                            item.PuntosLoopModelo,
                            item.NormalModelo,
                            TipoMuro,
                            PermitirUnion);

                    if (murosNuevos != null && murosNuevos.Count > 0)
                        murosCreados += murosNuevos.Count;
                    else
                        carasOmitidas++;

                    continue;
                }

                //-------------------------------------------------
                // CARA INFERIOR / INCLINADA → SUELO
                //-------------------------------------------------
                PlanarFace caraPlanaSuelo = item.Cara as PlanarFace;

                if (caraPlanaSuelo == null)
                {
                    carasOmitidas++;
                    continue;
                }

                creadorSuelos.ConfigurarOrigenesDeRecorte(
                    item.OrigenesRecorte ?? new List<Element>() { item.GeoElem },
                    item.LinkOrigen);

                bool creadoSuelo =
                    creadorSuelos.CrearSueloDesdeCaraPlanarProcesada(
                        doc,
                        uidoc,
                        item.HostElem,
                        caraPlanaSuelo,
                        item.TransformCara ?? Transform.Identity,
                        TipoSuelo);

                if (creadoSuelo)
                    suelosCreados++;
                else
                    carasOmitidas++;
            }

            // Final silencioso.
            MostrarFormulario();
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            MostrarFormulario();
        }
        catch (Exception ex)
        {
            TaskDialog.Show(
                "MYG - Error",
                "Ocurrió un error al crear tarrajeo en escaleras:\n\n" +
                ex.Message);

            MostrarFormulario();
        }
        finally
        {
            TarrajeoVistaActivaUnionesHelper
                .RestaurarUnionesOcultasInvertidas(
                    doc,
                    unionesOcultasInvertidas);
        }
    }

    // =====================================
    // COMPONENTES REALES DE LA ESCALERA
    // =====================================
    private List<ElementoTrabajo> ObtenerComponentesGeometricosEscalera(
        ElementoTrabajo escaleraTrabajo)
    {
        List<ElementoTrabajo> resultado = new List<ElementoTrabajo>();

        if (escaleraTrabajo == null || escaleraTrabajo.GeoElem == null)
            return resultado;

        Element escalera = escaleraTrabajo.GeoElem;
        Document geoDoc = escalera.Document;

        if (geoDoc == null)
            return resultado;

        HashSet<ElementId> ids = new HashSet<ElementId>();

        // API de Stairs: tramos, descansos y soportes.
        AgregarIdsMetodoEscalera(escalera, "GetStairsRuns", ids);
        AgregarIdsMetodoEscalera(escalera, "GetStairsLandings", ids);
        AgregarIdsMetodoEscalera(escalera, "GetStairsSupports", ids);

        // Fallback: algunos tipos/versiones exponen componentes como dependientes.
        try
        {
            ICollection<ElementId> dependientes =
                escalera.GetDependentElements(null);

            if (dependientes != null)
            {
                foreach (ElementId id in dependientes)
                {
                    if (id == null || id == ElementId.InvalidElementId)
                        continue;

                    Element e = geoDoc.GetElement(id);

                    if (EsComponenteGeometricoEscalera(e))
                        ids.Add(id);
                }
            }
        }
        catch
        {
        }

        // V21: armar una sola lista con la escalera raíz y todos sus
        // componentes. Este conjunto se excluirá de los sólidos cortantes.
        List<Element> origenesRecorte = new List<Element>();
        origenesRecorte.Add(escalera);

        foreach (ElementId idOrigen in ids)
        {
            if (idOrigen == null || idOrigen == ElementId.InvalidElementId)
                continue;

            Element eOrigen = geoDoc.GetElement(idOrigen);

            if (eOrigen != null &&
                !origenesRecorte.Any(x => x != null && x.Id.Equals(eOrigen.Id)))
            {
                origenesRecorte.Add(eOrigen);
            }
        }

        foreach (ElementId id in ids)
        {
            if (id == null || id == ElementId.InvalidElementId)
                continue;

            Element componente = geoDoc.GetElement(id);

            if (componente == null)
                continue;

            resultado.Add(new ElementoTrabajo
            {
                HostElem = escaleraTrabajo.LinkOrigen != null
                    ? (Element)escaleraTrabajo.LinkOrigen
                    : componente,
                GeoElem = componente,
                OrigenesRecorte = origenesRecorte,
                LinkOrigen = escaleraTrabajo.LinkOrigen,
                TransformCara = escaleraTrabajo.TransformCara ?? Transform.Identity
            });
        }

        // Si Revit no expuso componentes independientes, se procesa la geometría
        // de la escalera principal como fallback.
        if (resultado.Count == 0)
        {
            resultado.Add(new ElementoTrabajo
            {
                HostElem = escaleraTrabajo.HostElem,
                GeoElem = escaleraTrabajo.GeoElem,
                OrigenesRecorte = origenesRecorte,
                LinkOrigen = escaleraTrabajo.LinkOrigen,
                TransformCara = escaleraTrabajo.TransformCara ?? Transform.Identity
            });
        }

        return resultado;
    }

    private void AgregarIdsMetodoEscalera(
        Element escalera,
        string nombreMetodo,
        HashSet<ElementId> ids)
    {
        if (escalera == null ||
            string.IsNullOrWhiteSpace(nombreMetodo) ||
            ids == null)
        {
            return;
        }

        try
        {
            MethodInfo metodo = escalera.GetType().GetMethod(
                nombreMetodo,
                BindingFlags.Instance | BindingFlags.Public,
                null,
                Type.EmptyTypes,
                null);

            if (metodo == null)
                return;

            object valor = metodo.Invoke(escalera, null);
            IEnumerable enumerable = valor as IEnumerable;

            if (enumerable == null)
                return;

            foreach (object obj in enumerable)
            {
                ElementId id = obj as ElementId;

                if (id != null && id != ElementId.InvalidElementId)
                    ids.Add(id);
            }
        }
        catch
        {
        }
    }

    private bool EsComponenteGeometricoEscalera(Element elem)
    {
        if (elem == null)
            return false;

        try
        {
            string nombreTipo = elem.GetType().Name ?? string.Empty;

            return
                nombreTipo.IndexOf("StairsRun", StringComparison.OrdinalIgnoreCase) >= 0 ||
                nombreTipo.IndexOf("StairsLanding", StringComparison.OrdinalIgnoreCase) >= 0 ||
                nombreTipo.IndexOf("StairsSupport", StringComparison.OrdinalIgnoreCase) >= 0;
        }
        catch
        {
            return false;
        }
    }

    // =====================================
    // OBTENER CARAS SIN HORNEAR EL SÓLIDO
    // Cada cara conserva su Transform acumulado real.
    // =====================================
    private List<CaraGeometrica> ObtenerCarasValidasEnModelo(
        Element elem,
        Transform transformBase,
        HashSet<string> keysGlobales)
    {
        List<CaraGeometrica> caras = new List<CaraGeometrica>();

        if (elem == null)
            return caras;

        HashSet<string> keys =
            keysGlobales ?? new HashSet<string>();

        Options opt = new Options
        {
            ComputeReferences = false,
            IncludeNonVisibleObjects = true,
            DetailLevel = ViewDetailLevel.Fine
        };

        GeometryElement geo = null;

        try
        {
            geo = elem.get_Geometry(opt);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return caras;

        ExtraerCarasValidas(
            geo,
            transformBase ?? Transform.Identity,
            caras,
            keys);

        return caras;
    }

    private void ExtraerCarasValidas(
        GeometryElement geo,
        Transform transformActual,
        List<CaraGeometrica> caras,
        HashSet<string> keys)
    {
        if (geo == null || caras == null || keys == null)
            return;

        Transform tr = transformActual ?? Transform.Identity;

        foreach (GeometryObject obj in geo)
        {
            Solid solid = obj as Solid;

            if (solid != null)
            {
                ProcesarSolido(
                    solid,
                    tr,
                    caras,
                    keys);

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi == null)
                continue;

            bool procesado = false;

            // SymbolGeometry está en coordenadas locales de la instancia.
            try
            {
                GeometryElement symbolGeo = gi.GetSymbolGeometry();

                if (symbolGeo != null)
                {
                    Transform nuevoTransform =
                        tr.Multiply(gi.Transform);

                    ExtraerCarasValidas(
                        symbolGeo,
                        nuevoTransform,
                        caras,
                        keys);

                    procesado = true;
                }
            }
            catch
            {
                procesado = false;
            }

            if (procesado)
                continue;

            // InstanceGeometry ya incluye gi.Transform respecto del padre.
            try
            {
                GeometryElement instanceGeo = gi.GetInstanceGeometry();

                if (instanceGeo != null)
                {
                    ExtraerCarasValidas(
                        instanceGeo,
                        tr,
                        caras,
                        keys);
                }
            }
            catch
            {
            }
        }
    }

    private void ProcesarSolido(
        Solid solid,
        Transform transformActual,
        List<CaraGeometrica> caras,
        HashSet<string> keys)
    {
        if (solid == null || caras == null || keys == null)
            return;

        if (solid.Faces == null || solid.Faces.Size == 0)
            return;

        if (solid.Edges == null || solid.Edges.Size == 0)
            return;

        Transform tr = transformActual ?? Transform.Identity;

        foreach (Face face in solid.Faces)
        {
            if (face == null)
                continue;

            if (face.Area <= MinAreaCara)
                continue;

            bool esSoportada =
                face is PlanarFace ||
                face is CylindricalFace;

            if (!esSoportada)
                continue;

            string key = BuildFaceKey(face, tr);

            if (!string.IsNullOrWhiteSpace(key))
            {
                if (keys.Contains(key))
                    continue;

                keys.Add(key);
            }

            caras.Add(new CaraGeometrica
            {
                Cara = face,
                TransformCara = tr
            });
        }
    }

    private XYZ ObtenerNormalCara(Face face, Transform transformCara)
    {
        if (face == null)
            return null;

        Transform tr = transformCara ?? Transform.Identity;

        try
        {
            PlanarFace pf = face as PlanarFace;

            if (pf != null)
                return tr.OfVector(pf.FaceNormal).Normalize();

            BoundingBoxUV bb = face.GetBoundingBox();

            if (bb != null)
            {
                UV uv = new UV(
                    (bb.Min.U + bb.Max.U) / 2.0,
                    (bb.Min.V + bb.Max.V) / 2.0);

                XYZ n = face.ComputeNormal(uv);

                if (n != null && n.GetLength() > 1e-9)
                    return tr.OfVector(n).Normalize();
            }
        }
        catch
        {
        }

        return null;
    }

    private XYZ ObtenerPuntoReferenciaFace(
        Face face,
        Transform transformCara)
    {
        if (face == null)
            return XYZ.Zero;

        Transform tr = transformCara ?? Transform.Identity;

        try
        {
            IList<CurveLoop> loops = face.GetEdgesAsCurveLoops();

            if (loops != null)
            {
                foreach (CurveLoop loop in loops)
                {
                    foreach (Curve c in loop)
                    {
                        if (c != null)
                            return tr.OfPoint(c.GetEndPoint(0));
                    }
                }
            }
        }
        catch
        {
        }

        try
        {
            BoundingBoxUV bb = face.GetBoundingBox();

            if (bb != null)
            {
                UV uv = new UV(
                    (bb.Min.U + bb.Max.U) / 2.0,
                    (bb.Min.V + bb.Max.V) / 2.0);

                return tr.OfPoint(face.Evaluate(uv));
            }
        }
        catch
        {
        }

        return XYZ.Zero;
    }


    // =====================================
    // SNAPSHOT INMUTABLE DEL LOOP EXTERIOR
    // =====================================
    // Face y GeometryObject pertenecen al estado actual del documento. Después
    // de crear el primer muro/suelo y confirmar una Transaction, Revit puede
    // invalidarlos. Por eso las caras verticales se convierten aquí a XYZ del
    // modelo activo antes de empezar a crear elementos.
    private List<XYZ> ObtenerLoopExteriorModelo(
        Face face,
        Transform transformCara,
        XYZ normalModelo)
    {
        if (face == null || normalModelo == null)
            return null;

        Transform tr = transformCara ?? Transform.Identity;
        XYZ n = normalModelo.Normalize();
        XYZ ejeV = XYZ.BasisZ;
        XYZ ejeU = ejeV.CrossProduct(n);

        if (ejeU.GetLength() <= 1e-9)
            return null;

        ejeU = ejeU.Normalize();

        List<XYZ> mejor = null;
        double mejorArea = 0.0;

        try
        {
            IList<CurveLoop> loops = face.GetEdgesAsCurveLoops();

            if (loops == null)
                return null;

            foreach (CurveLoop loop in loops)
            {
                if (loop == null)
                    continue;

                List<XYZ> puntos = new List<XYZ>();

                foreach (Curve curva in loop)
                {
                    if (curva == null)
                        continue;

                    IList<XYZ> tess = null;

                    try
                    {
                        tess = curva.Tessellate();
                    }
                    catch
                    {
                        tess = new List<XYZ>
                        {
                            curva.GetEndPoint(0),
                            curva.GetEndPoint(1)
                        };
                    }

                    if (tess == null)
                        continue;

                    foreach (XYZ pLocal in tess)
                    {
                        if (pLocal == null)
                            continue;

                        XYZ p = tr.OfPoint(pLocal);

                        if (puntos.Count == 0 ||
                            puntos[puntos.Count - 1].DistanceTo(p) > 1e-6)
                        {
                            puntos.Add(p);
                        }
                    }
                }

                puntos = LimpiarPuntosSnapshot(puntos);

                if (puntos == null || puntos.Count < 3)
                    continue;

                if (puntos[0].DistanceTo(puntos[puntos.Count - 1]) > 1e-6)
                    puntos.Add(puntos[0]);

                double area = AreaLoopVerticalSnapshot(
                    puntos,
                    ejeU,
                    ejeV);

                if (area > mejorArea)
                {
                    mejorArea = area;
                    mejor = puntos;
                }
            }
        }
        catch
        {
            return null;
        }

        return mejor;
    }

    private List<XYZ> LimpiarPuntosSnapshot(List<XYZ> puntos)
    {
        List<XYZ> limpio = new List<XYZ>();

        if (puntos == null)
            return limpio;

        foreach (XYZ p in puntos)
        {
            if (p == null)
                continue;

            if (limpio.Count == 0 ||
                limpio[limpio.Count - 1].DistanceTo(p) > 1e-5)
            {
                limpio.Add(p);
            }
        }

        if (limpio.Count > 2 &&
            limpio[0].DistanceTo(limpio[limpio.Count - 1]) <= 1e-5)
        {
            limpio.RemoveAt(limpio.Count - 1);
        }

        bool cambio = true;
        int guard = 0;

        while (cambio && limpio.Count > 3 && guard < 100)
        {
            cambio = false;
            guard++;

            for (int i = 0; i < limpio.Count; i++)
            {
                XYZ a = limpio[(i - 1 + limpio.Count) % limpio.Count];
                XYZ b = limpio[i];
                XYZ c = limpio[(i + 1) % limpio.Count];

                XYZ ab = b - a;
                XYZ bc = c - b;

                if (ab.GetLength() <= 1e-5 || bc.GetLength() <= 1e-5)
                {
                    limpio.RemoveAt(i);
                    cambio = true;
                    break;
                }

                double seno = ab.Normalize().CrossProduct(bc.Normalize()).GetLength();

                if (seno <= 1e-6 && ab.DotProduct(bc) >= 0.0)
                {
                    limpio.RemoveAt(i);
                    cambio = true;
                    break;
                }
            }
        }

        return limpio;
    }

    private double AreaLoopVerticalSnapshot(
        List<XYZ> puntos,
        XYZ ejeU,
        XYZ ejeV)
    {
        if (puntos == null || puntos.Count < 4)
            return 0.0;

        XYZ origen = puntos[0];
        double area2 = 0.0;

        for (int i = 0; i < puntos.Count - 1; i++)
        {
            XYZ da = puntos[i] - origen;
            XYZ db = puntos[i + 1] - origen;

            double ua = da.DotProduct(ejeU);
            double va = da.DotProduct(ejeV);
            double ub = db.DotProduct(ejeU);
            double vb = db.DotProduct(ejeV);

            area2 += (ua * vb) - (ub * va);
        }

        return Math.Abs(area2) * 0.5;
    }

    private string BuildFaceKey(
        Face face,
        Transform transformCara)
    {
        try
        {
            Transform tr = transformCara ?? Transform.Identity;

            XYZ n = ObtenerNormalCara(face, tr);
            XYZ p = ObtenerPuntoReferenciaFace(face, tr);

            if (n == null)
                return null;

            string tipo = face.GetType().Name;

            return tipo + "|" +
                   Math.Round(n.X, 6) + "|" +
                   Math.Round(n.Y, 6) + "|" +
                   Math.Round(n.Z, 6) + "|" +
                   Math.Round(p.X, 6) + "|" +
                   Math.Round(p.Y, 6) + "|" +
                   Math.Round(p.Z, 6) + "|" +
                   Math.Round(face.Area, 6);
        }
        catch
        {
            return null;
        }
    }

    // =====================================
    // OBTENER ESCALERAS NATIVAS O DE VÍNCULOS
    // =====================================
    private List<ElementoTrabajo> ObtenerElementosTrabajo(
        Document doc,
        IList<Reference> refs)
    {
        List<ElementoTrabajo> resultado = new List<ElementoTrabajo>();

        if (doc == null || refs == null)
            return resultado;

        foreach (Reference r in refs)
        {
            if (r == null)
                continue;

            Element elem = doc.GetElement(r.ElementId);

            if (elem == null)
                continue;

            RevitLinkInstance link = elem as RevitLinkInstance;

            if (link != null)
            {
                if (!ConsiderarVinculos)
                    continue;

                Document linkDoc = null;

                try
                {
                    linkDoc = link.GetLinkDocument();
                }
                catch
                {
                    linkDoc = null;
                }

                if (linkDoc == null)
                    continue;

                ElementId linkedId = r.LinkedElementId;

                if (linkedId == ElementId.InvalidElementId)
                    continue;

                Element linkedElem = linkDoc.GetElement(linkedId);

                if (linkedElem == null || !CategoriaValida(linkedElem))
                    continue;

                Transform tr = Transform.Identity;

                try
                {
                    tr = link.GetTotalTransform();
                }
                catch
                {
                    tr = Transform.Identity;
                }

                resultado.Add(new ElementoTrabajo
                {
                    HostElem = link,
                    GeoElem = linkedElem,
                    OrigenesRecorte = new List<Element>() { linkedElem },
                    LinkOrigen = link,
                    TransformCara = tr
                });

                continue;
            }

            if (!CategoriaValida(elem))
                continue;

            resultado.Add(new ElementoTrabajo
            {
                HostElem = elem,
                GeoElem = elem,
                OrigenesRecorte = new List<Element>() { elem },
                LinkOrigen = null,
                TransformCara = Transform.Identity
            });
        }

        return resultado;
    }

    private bool CategoriaValida(Element elem)
    {
        if (elem == null)
            return false;

        Category cat = null;

        try
        {
            cat = elem.Category;
        }
        catch
        {
            cat = null;
        }

        if (cat == null)
            return false;

        return cat.Id.Equals(
            new ElementId(BuiltInCategory.OST_Stairs));
    }

    private void MostrarFormulario()
    {
        try
        {
            if (Form != null && !Form.IsDisposed)
            {
                Form.RestaurarVentana();
                return;
            }
        }
        catch
        {
        }

        try
        {
            if (Form != null && !Form.IsDisposed)
            {
                Form.Show();
                Form.BringToFront();
                Form.Activate();
            }
        }
        catch
        {
        }
    }

    public string GetName()
    {
        return "MYG - Seleccionar Escaleras para Tarrajeo V22";
    }
}

// =====================================
// FILTRO - SOLO ESCALERAS
// =====================================
public class EscalerasTarrajeoSelectionFilter : ISelectionFilter
{
    private readonly Document _doc;
    private readonly bool _considerarVinculos;

    public EscalerasTarrajeoSelectionFilter()
        : this(null, false)
    {
    }

    public EscalerasTarrajeoSelectionFilter(bool considerarVinculos)
        : this(null, considerarVinculos)
    {
    }

    public EscalerasTarrajeoSelectionFilter(
        Document doc,
        bool considerarVinculos)
    {
        _doc = doc;
        _considerarVinculos = considerarVinculos;
    }

    public bool AllowElement(Element elem)
    {
        if (elem == null)
            return false;

        if (_considerarVinculos && elem is RevitLinkInstance)
            return true;

        return EsCategoriaPermitida(elem);
    }

    public bool AllowReference(Reference reference, XYZ position)
    {
        if (!_considerarVinculos)
            return true;

        if (_doc == null || reference == null)
            return false;

        try
        {
            RevitLinkInstance link =
                _doc.GetElement(reference.ElementId) as RevitLinkInstance;

            if (link == null)
                return true;

            ElementId linkedId = reference.LinkedElementId;

            if (linkedId == ElementId.InvalidElementId)
                return false;

            Document linkDoc = link.GetLinkDocument();

            if (linkDoc == null)
                return false;

            Element linkedElem = linkDoc.GetElement(linkedId);

            return EsCategoriaPermitida(linkedElem);
        }
        catch
        {
            return false;
        }
    }

    private bool EsCategoriaPermitida(Element elem)
    {
        if (elem == null || elem.Category == null)
            return false;

        return elem.Category.Id.Equals(
            new ElementId(BuiltInCategory.OST_Stairs));
    }
}
