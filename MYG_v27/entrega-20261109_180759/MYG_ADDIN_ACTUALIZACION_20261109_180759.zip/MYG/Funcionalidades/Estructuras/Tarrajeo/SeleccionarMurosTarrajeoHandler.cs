﻿// =====================================
// HANDLER V33 - SELECCIONAR MUROS PARA TARRAJEO - VISTA ACTIVA REAL
// Crea tarrajeo en todo el contorno lateral del muro:
// - caras exteriores/interiores principales,
// - tapas laterales sintéticas de inicio/fin calculadas por el sólido real
//   del muro, no por la LocationCurve, para ocupar todo el espesor visible.
// - V31 evita duplicar: si Revit sí devolvió una Face real de tapa lateral,
//   no crea otra tapa sintética encima.
// - V32 simplifica: las tapas de inicio/fin ya NO se toman como Face real.
//   Siempre se crean solo por tapa sintética, así se evita doble muro.
// No crea en eje, capas internas, cara superior ni cara inferior.
// Mantiene recortes por sólidos/intersecciones en el motor común de muros
// y solo considera interferencias visibles en la vista activa.
// - V33: antes de leer las caras de un muro NATIVO, invierte temporalmente
//   solo las uniones donde un elemento OCULTO en la vista activa está cortando
//   al muro. Así HostObjectUtils.GetSideFaces no recibe una cara ya mordida por
//   geometría que el usuario no ve. Al terminar, la unión original se restaura.
// =====================================
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Linq;

public class SeleccionarMurosTarrajeoHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public TarrajeoElementosForm Form;

    public FloorType TipoSuelo;
    public WallType TipoMuro;
    public bool PermitirUnion;
    public bool ConsiderarVinculos;

    // Motores comunes de creación.
    // El comando los inyecta para que por ELEMENTOS use la misma lógica que por CARAS.
    public Tarrajeo_MurosHandler CreadorMuros;
    public Tarrajeo_SuelosHandler CreadorSuelos;

    public List<ElementId> ElementosSeleccionados = new List<ElementId>();

    private const double TolNormalVertical = 0.001;
    private const double MinAreaCara = 0.0001;

    private class CaraTrabajo
    {
        public Element HostElem;
        public Element GeoElem;
        public RevitLinkInstance LinkOrigen;
        public Face Cara;
        public Transform TransformCara;
    }

    private class TapaSinteticaTrabajo
    {
        public Element HostElem;
        public Element GeoElem;
        public RevitLinkInstance LinkOrigen;
        public List<XYZ> Puntos;
        public XYZ Normal;
    }

    private class ElementoTrabajo
    {
        // HostElem es el elemento del documento activo.
        // Si viene de vínculo, HostElem será el RevitLinkInstance.
        public Element HostElem;

        // GeoElem es el elemento real cuya geometría se procesa.
        // Si viene de vínculo, GeoElem será el muro dentro del LinkDocument.
        public Element GeoElem;

        // TransformCara lleva la geometría de GeoElem a coordenadas del modelo activo.
        public Transform TransformCara;
    }

    private class UnionOcultaInvertida
    {
        public ElementId MuroId;
        public ElementId OtroId;
    }

    private class TapaCandidataV26
    {
        public Face Face;
        public double D;
    }

    public void Execute(UIApplication app)
    {
        UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

        if (uidoc == null)
        {
            TaskDialog.Show("MYG", "No se encontró el documento activo.");
            MostrarFormulario();
            return;
        }

        Document doc = uidoc.Document;
        List<UnionOcultaInvertida> unionesOcultasInvertidas =
            new List<UnionOcultaInvertida>();

        try
        {
            //-------------------------------------------------
            // TOMAR DATOS DESDE EL FORMULARIO
            //-------------------------------------------------
            if (Form != null)
            {
                TipoSuelo = Form.TipoSueloSeleccionado;
                TipoMuro = Form.TipoMuroSeleccionado;
                PermitirUnion = Form.PermitirUnion;
                ConsiderarVinculos = Form.ConsiderarVinculos;
            }

            //-------------------------------------------------
            // VALIDAR TIPO DE MURO
            // Para el flujo "Muros" ya no se usa TipoSuelo.
            // Solo se tarrajean las caras externas laterales del muro.
            //-------------------------------------------------
            if (TipoMuro == null)
            {
                TaskDialog.Show(
                    "MYG",
                    "Para muros debe seleccionar un tipo de muro.");

                MostrarFormulario();
                return;
            }

            //-------------------------------------------------
            // SELECCIONAR MUROS
            //-------------------------------------------------
            ObjectType tipoSeleccion = ConsiderarVinculos ? ObjectType.LinkedElement : ObjectType.Element;

            IList<Reference> refs = uidoc.Selection.PickObjects(
                tipoSeleccion,
                new MurosTarrajeoSelectionFilter(doc, ConsiderarVinculos),
                ConsiderarVinculos
                    ? "Seleccione muros de vínculos"
                    : "Seleccione muros");

            if (refs == null || refs.Count == 0)
            {
                MostrarFormulario();
                return;
            }

            List<ElementoTrabajo> elementosTrabajo = ObtenerElementosTrabajo(doc, refs);

            ElementosSeleccionados = elementosTrabajo
                .Where(x => x != null && x.HostElem != null)
                .Select(x => x.HostElem.Id)
                .Distinct()
                .ToList();

            if (elementosTrabajo.Count == 0)
            {
                MostrarFormulario();
                return;
            }

            //-------------------------------------------------
            // V33 - PREPARAR MOTOR Y VISIBILIDAD REAL DE VISTA ACTIVA
            //-------------------------------------------------
            // Se prepara ANTES de leer las caras para que el selector pueda
            // saber qué elementos unidos existen físicamente pero NO forman
            // parte de la vista activa.
            Tarrajeo_MurosHandler creadorMuros =
                CreadorMuros ?? new Tarrajeo_MurosHandler();

            creadorMuros.UiDoc = uidoc;
            creadorMuros.ConsiderarVinculos = ConsiderarVinculos;
            creadorMuros.PrepararNuevaEjecucion();

            //-------------------------------------------------
            // V33 - RECONSTRUIR LA CARA DEL MURO SIN CORTES OCULTOS
            //-------------------------------------------------
            // Un elemento puede estar oculto en la vista y, aun así, haber
            // cortado geométricamente al muro por Join Geometry. En ese caso
            // HostObjectUtils.GetSideFaces devuelve la cara YA recortada y el
            // motor nunca tiene oportunidad de recuperarla.
            //
            // Se invierte temporalmente SOLO esa unión oculta, se leen las
            // caras completas y al final del comando se restaura exactamente
            // el orden de unión original.
            unionesOcultasInvertidas =
                InvertirTemporalmenteUnionesOcultasQueCortan(
                    doc,
                    elementosTrabajo,
                    creadorMuros);

            //-------------------------------------------------
            // PREPROCESAR SOLO CARAS EXTERNAS LATERALES
            //-------------------------------------------------
            List<CaraTrabajo> carasParaCrear = new List<CaraTrabajo>();
            List<TapaSinteticaTrabajo> tapasSinteticasParaCrear = new List<TapaSinteticaTrabajo>();

            int murosProcesados = 0;
            int carasExternasDetectadas = 0;
            int tapasSinteticasDetectadas = 0;
            int carasOmitidas = 0;

            foreach (ElementoTrabajo et in elementosTrabajo)
            {
                Element elemHost = et != null ? et.HostElem : null;
                Element geoElem = et != null ? et.GeoElem : null;
                Transform transformCara = et != null && et.TransformCara != null ? et.TransformCara : Transform.Identity;

                if (elemHost == null || geoElem == null)
                    continue;

                murosProcesados++;

                //-------------------------------------------------
                // V24:
                // En muros NO se extraen todas las caras del sólido.
                // Eso crea tarrajeo en eje, capas internas, caras de extremo
                // y otras caras que no corresponden.
                //
                // Se usan solo ShellLayerType.Exterior e Interior.
                //-------------------------------------------------
                List<Face> carasExternas = ObtenerCarasExternasDeMuro(geoElem, transformCara);

                foreach (Face cara in carasExternas)
                {
                    if (cara == null)
                    {
                        carasOmitidas++;
                        continue;
                    }

                    if (cara.Area <= MinAreaCara)
                    {
                        carasOmitidas++;
                        continue;
                    }

                    XYZ normal = ObtenerNormalCara(cara, transformCara);

                    if (normal == null)
                    {
                        carasOmitidas++;
                        continue;
                    }

                    normal = normal.Normalize();

                    //-------------------------------------------------
                    // Asegurar solo caras laterales verticales.
                    // Las caras de extremo, superior/inferior o geometrías raras
                    // quedan descartadas.
                    //-------------------------------------------------
                    if (Math.Abs(normal.Z) >= TolNormalVertical)
                    {
                        carasOmitidas++;
                        continue;
                    }

                    // V26:
                    // Evitar duplicados entre caras exterior/interior, tapas y caras
                    // provenientes de muros unidos o geometría compuesta.
                    if (ExisteCaraTrabajoSimilar(carasParaCrear, cara, transformCara))
                    {
                        carasOmitidas++;
                        continue;
                    }

                    carasExternasDetectadas++;

                    carasParaCrear.Add(new CaraTrabajo
                    {
                        HostElem = elemHost,
                        GeoElem = geoElem,
                        LinkOrigen = elemHost as RevitLinkInstance,
                        Cara = cara,
                        TransformCara = transformCara
                    });
                }

                //-------------------------------------------------
                // V29:
                // Las tapas del espesor se crean como loops sintéticos.
                // Esto evita depender de que Revit entregue una Face en el
                // sólido del muro. Si algo intersecta, el motor común las
                // recorta con sólidos visibles en la vista activa.
                //-------------------------------------------------
                List<TapaSinteticaTrabajo> tapas = CrearTapasSinteticasInicioFin(
                    elemHost,
                    geoElem,
                    transformCara);

                foreach (TapaSinteticaTrabajo t in tapas)
                {
                    if (t == null || t.Puntos == null || t.Puntos.Count < 4 || t.Normal == null)
                        continue;

                    //-------------------------------------------------
                    // V31:
                    // Evitar doble muro en tapas.
                    // Si la tapa real ya fue detectada como Face y está en
                    // carasParaCrear, no agregamos una sintética encima.
                    //-------------------------------------------------
                    if (ExisteTapaContraCaraReal(carasParaCrear, t))
                    {
                        carasOmitidas++;
                        continue;
                    }

                    if (ExisteTapaSinteticaSimilar(tapasSinteticasParaCrear, t))
                    {
                        carasOmitidas++;
                        continue;
                    }

                    tapasSinteticasParaCrear.Add(t);
                    tapasSinteticasDetectadas++;
                }
            }

            if (carasParaCrear.Count == 0 && tapasSinteticasParaCrear.Count == 0)
            {
                TaskDialog.Show(
                    "MYG - Tarrajeo por Muros",
                    "No se encontraron caras externas laterales válidas para crear tarrajeo.\n\n" +
                    "Muros procesados: " + murosProcesados + "\n" +
                    "Caras externas detectadas: " + carasExternasDetectadas + "\n" +
                    "Tapas laterales detectadas: " + tapasSinteticasDetectadas + "\n" +
                    "Caras omitidas: " + carasOmitidas);

                MostrarFormulario();
                return;
            }

            //-------------------------------------------------
            // CREAR TARRAJEO USANDO EL MOTOR COMÚN DE MUROS
            //-------------------------------------------------
            int murosCreados = 0;

            foreach (CaraTrabajo item in carasParaCrear)
            {
                if (item == null || item.HostElem == null || item.Cara == null)
                {
                    carasOmitidas++;
                    continue;
                }

                //-------------------------------------------------
                // Misma lógica que tarrajeo por cara:
                // - caras planas,
                // - caras cilíndricas,
                // - boceto real,
                // - recortes por sólidos visibles nativos + vínculos.
                //-------------------------------------------------
                creadorMuros.ConfigurarOrigenDeRecorte(
                    item.GeoElem ?? item.HostElem,
                    item.LinkOrigen);

                List<Wall> murosNuevos = creadorMuros.CrearMurosDesdeFaceProcesada(
                    doc,
                    uidoc,
                    item.HostElem,
                    item.Cara,
                    item.TransformCara ?? Transform.Identity,
                    TipoMuro,
                    PermitirUnion);

                if (murosNuevos != null && murosNuevos.Count > 0)
                    murosCreados += murosNuevos.Count;
                else
                    carasOmitidas++;
            }

            //-------------------------------------------------
            // V29:
            // Crear tapas sintéticas de inicio/fin con el mismo motor común.
            // Se recortan solo con elementos visibles en la vista activa.
            //-------------------------------------------------
            foreach (TapaSinteticaTrabajo item in tapasSinteticasParaCrear)
            {
                if (item == null || item.HostElem == null || item.Puntos == null || item.Normal == null)
                {
                    carasOmitidas++;
                    continue;
                }

                creadorMuros.ConfigurarOrigenDeRecorte(
                    item.GeoElem ?? item.HostElem,
                    item.LinkOrigen);

                List<Wall> murosNuevos = creadorMuros.CrearMurosDesdeLoopPlanarProcesado(
                    doc,
                    uidoc,
                    item.HostElem,
                    item.Puntos,
                    item.Normal,
                    TipoMuro,
                    PermitirUnion);

                if (murosNuevos != null && murosNuevos.Count > 0)
                    murosCreados += murosNuevos.Count;
                else
                    carasOmitidas++;
            }

            //-------------------------------------------------
            // FINAL SILENCIOSO
            //-------------------------------------------------
            MostrarFormulario();
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            MostrarFormulario();
        }
        catch (Exception ex)
        {
            TaskDialog.Show(
                "MYG - Error",
                "Ocurrió un error al crear tarrajeo en muros:\n\n" + ex.Message);

            MostrarFormulario();
        }
        finally
        {
            // V33: nunca dejar alterado el modelo original. Las uniones ocultas
            // se restauran aunque el usuario cancele o una cara falle.
            RestaurarUnionesOcultasInvertidas(
                doc,
                unionesOcultasInvertidas);
        }
    }


    // =========================================================
    // V33 - UNIONES OCULTAS QUE CORTAN AL MURO
    // =========================================================
    private List<UnionOcultaInvertida> InvertirTemporalmenteUnionesOcultasQueCortan(
        Document doc,
        List<ElementoTrabajo> elementosTrabajo,
        Tarrajeo_MurosHandler creadorMuros)
    {
        List<UnionOcultaInvertida> resultado =
            new List<UnionOcultaInvertida>();

        if (doc == null ||
            elementosTrabajo == null ||
            elementosTrabajo.Count == 0 ||
            creadorMuros == null)
        {
            return resultado;
        }

        List<UnionOcultaInvertida> candidatas =
            new List<UnionOcultaInvertida>();

        HashSet<string> claves =
            new HashSet<string>();

        foreach (ElementoTrabajo et in elementosTrabajo)
        {
            if (et == null || et.GeoElem == null)
                continue;

            Wall wall = et.GeoElem as Wall;

            if (wall == null)
                continue;

            // Los documentos vinculados son de solo lectura desde el host.
            // Esta corrección se aplica únicamente a muros nativos.
            try
            {
                if (!object.ReferenceEquals(wall.Document, doc))
                    continue;
            }
            catch
            {
                continue;
            }

            ICollection<ElementId> unidos = null;

            try
            {
                unidos = JoinGeometryUtils.GetJoinedElements(
                    doc,
                    wall);
            }
            catch
            {
                unidos = null;
            }

            if (unidos == null || unidos.Count == 0)
                continue;

            foreach (ElementId id in unidos)
            {
                if (id == null ||
                    id == ElementId.InvalidElementId ||
                    id.Equals(wall.Id))
                {
                    continue;
                }

                Element otro = null;

                try
                {
                    otro = doc.GetElement(id);
                }
                catch
                {
                    otro = null;
                }

                if (otro == null)
                    continue;

                // Si el elemento sí aparece en la vista activa, su mordida es
                // válida y NO se modifica.
                bool visible = true;

                try
                {
                    visible =
                        creadorMuros
                        .EsElementoVisibleEnVistaActivaParaTarrajeo(otro);
                }
                catch
                {
                    visible = true;
                }

                if (visible)
                    continue;

                bool otroCortaMuro = false;

                try
                {
                    if (!JoinGeometryUtils.AreElementsJoined(
                            doc,
                            wall,
                            otro))
                    {
                        continue;
                    }

                    otroCortaMuro =
                        JoinGeometryUtils.IsCuttingElementInJoin(
                            doc,
                            otro,
                            wall);
                }
                catch
                {
                    otroCortaMuro = false;
                }

                if (!otroCortaMuro)
                    continue;

                string clave =
                    wall.Id.ToString() + "|" + otro.Id.ToString();

                if (!claves.Add(clave))
                    continue;

                candidatas.Add(new UnionOcultaInvertida()
                {
                    MuroId = wall.Id,
                    OtroId = otro.Id
                });
            }
        }

        if (candidatas.Count == 0)
            return resultado;

        try
        {
            using (Transaction tx =
                new Transaction(
                    doc,
                    "MYG - Ignorar uniones ocultas para leer caras"))
            {
                tx.Start();
                MYG_TarrajeoFallosSilenciosos.Configurar(tx);

                foreach (UnionOcultaInvertida par in candidatas)
                {
                    if (par == null)
                        continue;

                    try
                    {
                        Element wall = doc.GetElement(par.MuroId);
                        Element otro = doc.GetElement(par.OtroId);

                        if (wall == null || otro == null)
                            continue;

                        if (!JoinGeometryUtils.AreElementsJoined(
                                doc,
                                wall,
                                otro))
                        {
                            continue;
                        }

                        // En la situación detectada, "otro" corta al muro.
                        // SwitchJoinOrder restaura temporalmente el volumen del
                        // muro sin eliminar la unión.
                        JoinGeometryUtils.SwitchJoinOrder(
                            doc,
                            wall,
                            otro);

                        resultado.Add(par);
                    }
                    catch
                    {
                    }
                }

                doc.Regenerate();
                TransactionStatus estado = tx.Commit();

                if (estado != TransactionStatus.Committed)
                    resultado.Clear();
            }
        }
        catch
        {
            resultado.Clear();
        }

        return resultado;
    }

    private void RestaurarUnionesOcultasInvertidas(
        Document doc,
        List<UnionOcultaInvertida> uniones)
    {
        if (doc == null ||
            uniones == null ||
            uniones.Count == 0)
        {
            return;
        }

        try
        {
            using (Transaction tx =
                new Transaction(
                    doc,
                    "MYG - Restaurar uniones ocultas"))
            {
                tx.Start();
                MYG_TarrajeoFallosSilenciosos.Configurar(tx);

                foreach (UnionOcultaInvertida par in uniones)
                {
                    if (par == null)
                        continue;

                    try
                    {
                        Element wall = doc.GetElement(par.MuroId);
                        Element otro = doc.GetElement(par.OtroId);

                        if (wall == null || otro == null)
                            continue;

                        if (!JoinGeometryUtils.AreElementsJoined(
                                doc,
                                wall,
                                otro))
                        {
                            continue;
                        }

                        // Después de la inversión temporal el MURO debe estar
                        // cortando al otro. Solo en ese estado se invierte otra
                        // vez para devolver la situación original.
                        bool muroCortaOtro =
                            JoinGeometryUtils.IsCuttingElementInJoin(
                                doc,
                                wall,
                                otro);

                        if (muroCortaOtro)
                        {
                            JoinGeometryUtils.SwitchJoinOrder(
                                doc,
                                wall,
                                otro);
                        }
                    }
                    catch
                    {
                    }
                }

                doc.Regenerate();
                tx.Commit();
            }
        }
        catch
        {
        }
    }


    // =====================================
    // V29 - TAPAS SINTÉTICAS DE INICIO/FIN
    // =====================================
    // Las tapas laterales del espesor se generan por geometría analítica del muro.
    // Esto corrige el caso donde Revit no devuelve una Face de tapa por una unión
    // o limpieza interna del muro. Luego el Tarrajeo_MurosHandler V58 aplica
    // el recorte por sólidos visibles en la vista activa.
    // =====================================

    private List<TapaSinteticaTrabajo> CrearTapasSinteticasInicioFin(
        Element hostElem,
        Element geoElem,
        Transform transformCara)
    {
        List<TapaSinteticaTrabajo> res = new List<TapaSinteticaTrabajo>();

        try
        {
            Wall wall = geoElem as Wall;

            if (hostElem == null || wall == null)
                return res;

            if (transformCara == null)
                transformCara = Transform.Identity;

            LocationCurve lc = wall.Location as LocationCurve;

            if (lc == null || lc.Curve == null)
                return res;

            XYZ p0 = transformCara.OfPoint(lc.Curve.GetEndPoint(0));
            XYZ p1 = transformCara.OfPoint(lc.Curve.GetEndPoint(1));

            XYZ eje = p1 - p0;
            eje = new XYZ(eje.X, eje.Y, 0.0);

            double longitud = eje.GetLength();

            if (longitud <= 0.001)
                return res;

            eje = eje.Normalize();

            XYZ normalEspesor = null;

            try
            {
                XYZ o = wall.Orientation;

                if (o != null)
                {
                    normalEspesor = transformCara.OfVector(o);
                    normalEspesor = new XYZ(normalEspesor.X, normalEspesor.Y, 0.0);

                    if (normalEspesor.GetLength() > 0.001)
                        normalEspesor = normalEspesor.Normalize();
                }
            }
            catch
            {
                normalEspesor = null;
            }

            if (normalEspesor == null || normalEspesor.GetLength() <= 0.001)
                normalEspesor = new XYZ(-eje.Y, eje.X, 0.0).Normalize();

            //-------------------------------------------------
            // V30:
            // Antes la tapa se calculaba desde LocationCurve + wall.Width.
            // Eso funciona solo si la línea de ubicación queda al centro real.
            // En muros unidos o con línea en cara de acabado, la tapa podía
            // quedarse al centro y no ocupar todo el espesor visible.
            //
            // Ahora se toman puntos reales del sólido del muro, se proyectan al
            // eje longitudinal y al eje de espesor, y con esos rangos reales se
            // arma la tapa completa de inicio y fin.
            //-------------------------------------------------
            List<XYZ> puntosSolido = ObtenerPuntosSolidoMuroTransformados(wall, transformCara);

            if (puntosSolido.Count < 4)
                return res;

            double minE, maxE, minN, maxN, minZ, maxZ;

            ObtenerRangosEjeEspesorZ(
                puntosSolido,
                p0,
                eje,
                normalEspesor,
                out minE,
                out maxE,
                out minN,
                out maxN,
                out minZ,
                out maxZ);

            if (maxE - minE <= 0.001)
                return res;

            if (maxN - minN <= 0.001)
                return res;

            if (maxZ - minZ <= 0.001)
                return res;

            //-------------------------------------------------
            // Pequeño control para no tomar un rango absurdo si la geometría
            // devuelta por Revit viene contaminada por una unión rara.
            //-------------------------------------------------
            double anchoTipo = 0.0;

            try { anchoTipo = wall.Width; } catch { anchoTipo = 0.0; }

            if (anchoTipo > 0.001)
            {
                double rangoN = maxN - minN;

                if (rangoN > anchoTipo * 2.50)
                {
                    double centroN = (minN + maxN) / 2.0;
                    minN = centroN - anchoTipo / 2.0;
                    maxN = centroN + anchoTipo / 2.0;
                }
            }

            //-------------------------------------------------
            // Crear exactamente las dos tapas: plano en E=minE y E=maxE.
            // La dimensión N ocupa todo el espesor real proyectado.
            //-------------------------------------------------
            List<XYZ> tapaInicio = CrearRectanguloTapaDesdeRangos(
                p0,
                eje,
                normalEspesor,
                minE,
                minN,
                maxN,
                minZ,
                maxZ);

            List<XYZ> tapaFin = CrearRectanguloTapaDesdeRangos(
                p0,
                eje,
                normalEspesor,
                maxE,
                minN,
                maxN,
                minZ,
                maxZ);

            if (tapaInicio.Count >= 4)
            {
                res.Add(new TapaSinteticaTrabajo()
                {
                    HostElem = hostElem,
                    GeoElem = geoElem,
                    LinkOrigen = hostElem as RevitLinkInstance,
                    Normal = eje.Negate(),
                    Puntos = tapaInicio
                });
            }

            if (tapaFin.Count >= 4)
            {
                res.Add(new TapaSinteticaTrabajo()
                {
                    HostElem = hostElem,
                    GeoElem = geoElem,
                    LinkOrigen = hostElem as RevitLinkInstance,
                    Normal = eje,
                    Puntos = tapaFin
                });
            }
        }
        catch
        {
        }

        return res;
    }

    private List<XYZ> ObtenerPuntosSolidoMuroTransformados(Wall wall, Transform transformCara)
    {
        List<XYZ> pts = new List<XYZ>();

        try
        {
            if (wall == null)
                return pts;

            if (transformCara == null)
                transformCara = Transform.Identity;

            Options opt = new Options()
            {
                ComputeReferences = false,
                IncludeNonVisibleObjects = true,
                DetailLevel = ViewDetailLevel.Fine
            };

            GeometryElement geo = wall.get_Geometry(opt);

            if (geo == null)
                return pts;

            List<Face> faces = new List<Face>();
            ExtraerFacesDeGeometry(geo, faces);

            foreach (Face f in faces)
            {
                if (f == null)
                    continue;

                List<XYZ> pf = ObtenerPuntosFace(f, transformCara);

                foreach (XYZ p in pf)
                {
                    if (p == null)
                        continue;

                    bool existe = false;

                    foreach (XYZ q in pts)
                    {
                        if (q != null && q.DistanceTo(p) < 0.0005)
                        {
                            existe = true;
                            break;
                        }
                    }

                    if (!existe)
                        pts.Add(p);
                }
            }
        }
        catch
        {
        }

        return pts;
    }

    private void ObtenerRangosEjeEspesorZ(
        List<XYZ> pts,
        XYZ origen,
        XYZ eje,
        XYZ normalEspesor,
        out double minE,
        out double maxE,
        out double minN,
        out double maxN,
        out double minZ,
        out double maxZ)
    {
        minE = double.MaxValue;
        maxE = double.MinValue;
        minN = double.MaxValue;
        maxN = double.MinValue;
        minZ = double.MaxValue;
        maxZ = double.MinValue;

        try
        {
            foreach (XYZ p in pts)
            {
                if (p == null)
                    continue;

                XYZ d = p - origen;

                double e = d.DotProduct(eje);
                double n = d.DotProduct(normalEspesor);

                if (e < minE) minE = e;
                if (e > maxE) maxE = e;
                if (n < minN) minN = n;
                if (n > maxN) maxN = n;
                if (p.Z < minZ) minZ = p.Z;
                if (p.Z > maxZ) maxZ = p.Z;
            }
        }
        catch
        {
        }
    }

    private List<XYZ> CrearRectanguloTapaDesdeRangos(
        XYZ origen,
        XYZ eje,
        XYZ normalEspesor,
        double e,
        double minN,
        double maxN,
        double zMin,
        double zMax)
    {
        List<XYZ> pts = new List<XYZ>();

        try
        {
            if (origen == null || eje == null || normalEspesor == null)
                return pts;

            XYZ baseE = origen + eje.Multiply(e);

            XYZ pA = baseE + normalEspesor.Multiply(minN);
            XYZ pB = baseE + normalEspesor.Multiply(maxN);

            XYZ a = new XYZ(pA.X, pA.Y, zMin);
            XYZ b = new XYZ(pB.X, pB.Y, zMin);
            XYZ c = new XYZ(pB.X, pB.Y, zMax);
            XYZ d = new XYZ(pA.X, pA.Y, zMax);

            pts.Add(a);
            pts.Add(b);
            pts.Add(c);
            pts.Add(d);
            pts.Add(a);
        }
        catch
        {
        }

        return pts;
    }

    private List<XYZ> CrearRectanguloTapa(
        XYZ centro,
        XYZ lado,
        double zMin,
        double zMax)
    {
        List<XYZ> pts = new List<XYZ>();

        if (centro == null || lado == null)
            return pts;

        XYZ a = new XYZ((centro - lado).X, (centro - lado).Y, zMin);
        XYZ b = new XYZ((centro + lado).X, (centro + lado).Y, zMin);
        XYZ c = new XYZ((centro + lado).X, (centro + lado).Y, zMax);
        XYZ d = new XYZ((centro - lado).X, (centro - lado).Y, zMax);

        pts.Add(a);
        pts.Add(b);
        pts.Add(c);
        pts.Add(d);
        pts.Add(a);

        return pts;
    }

    private XYZ OffsetCentroSegunLineaUbicacion(Wall wall, XYZ normalEspesor, double ancho)
    {
        try
        {
            if (wall == null || normalEspesor == null || ancho <= 0.001)
                return XYZ.Zero;

            Parameter p = wall.get_Parameter(BuiltInParameter.WALL_KEY_REF_PARAM);
            int key = p != null ? p.AsInteger() : 0;

            //-------------------------------------------------
            // 0 Wall Centerline / 1 Core Centerline: ya está al centro.
            // 2 Finish Face Exterior / 4 Core Face Exterior: centro hacia interior.
            // 3 Finish Face Interior / 5 Core Face Interior: centro hacia exterior.
            //-------------------------------------------------
            if (key == 2 || key == 4)
                return normalEspesor.Multiply(-ancho / 2.0);

            if (key == 3 || key == 5)
                return normalEspesor.Multiply(ancho / 2.0);
        }
        catch
        {
        }

        return XYZ.Zero;
    }


    private bool ExisteTapaContraCaraReal(
        List<CaraTrabajo> carasReales,
        TapaSinteticaTrabajo tapa)
    {
        try
        {
            if (carasReales == null || tapa == null || tapa.Puntos == null || tapa.Puntos.Count < 4 || tapa.Normal == null)
                return false;

            XYZ cTapa = CentroPuntos(tapa.Puntos);
            XYZ nTapa = tapa.Normal.Normalize();

            double areaTapa = AreaPoligono3D(tapa.Puntos);

            foreach (CaraTrabajo cr in carasReales)
            {
                if (cr == null || cr.Cara == null)
                    continue;

                //-------------------------------------------------
                // Solo comparar contra caras del mismo muro/host.
                //-------------------------------------------------
                if (cr.HostElem != null && tapa.HostElem != null && cr.HostElem.Id != tapa.HostElem.Id)
                    continue;

                XYZ nCara = ObtenerNormalCara(cr.Cara, cr.TransformCara);

                if (nCara == null)
                    continue;

                nCara = nCara.Normalize();

                //-------------------------------------------------
                // La tapa real puede venir con normal opuesta según cómo Revit
                // entregue el sólido. Para detectar duplicado basta paralelismo.
                //-------------------------------------------------
                if (Math.Abs(nCara.DotProduct(nTapa)) < 0.985)
                    continue;

                XYZ cCara = ObtenerCentroCaraTransformado(cr.Cara, cr.TransformCara);

                if (cCara == null)
                    continue;

                //-------------------------------------------------
                // Si el centro está prácticamente en el mismo plano/posición,
                // es la misma tapa.
                //-------------------------------------------------
                if (cCara.DistanceTo(cTapa) > 0.05) // aprox. 15 mm
                    continue;

                //-------------------------------------------------
                // Validación extra por área para no eliminar una cara distinta
                // cercana. Si no se puede calcular, el centro + normal ya bastan.
                //-------------------------------------------------
                double areaCara = 0.0;

                try
                {
                    areaCara = cr.Cara.Area;
                }
                catch
                {
                    areaCara = 0.0;
                }

                if (areaCara > 1e-8 && areaTapa > 1e-8)
                {
                    double ratio = areaCara > areaTapa ? areaCara / areaTapa : areaTapa / areaCara;

                    if (ratio > 1.25)
                        continue;
                }

                return true;
            }
        }
        catch
        {
        }

        return false;
    }

    private double AreaPoligono3D(List<XYZ> pts)
    {
        try
        {
            if (pts == null || pts.Count < 4)
                return 0.0;

            XYZ sum = XYZ.Zero;

            for (int i = 0; i < pts.Count - 1; i++)
            {
                XYZ p = pts[i];
                XYZ q = pts[i + 1];

                if (p == null || q == null)
                    continue;

                sum += p.CrossProduct(q);
            }

            return 0.5 * sum.GetLength();
        }
        catch
        {
            return 0.0;
        }
    }

    private bool ExisteTapaSinteticaSimilar(
        List<TapaSinteticaTrabajo> existentes,
        TapaSinteticaTrabajo nueva)
    {
        try
        {
            if (existentes == null || nueva == null || nueva.Puntos == null || nueva.Puntos.Count == 0 || nueva.Normal == null)
                return false;

            XYZ cn = CentroPuntos(nueva.Puntos);
            XYZ nn = nueva.Normal.Normalize();

            foreach (TapaSinteticaTrabajo t in existentes)
            {
                if (t == null || t.Puntos == null || t.Puntos.Count == 0 || t.Normal == null)
                    continue;

                XYZ c = CentroPuntos(t.Puntos);
                XYZ n = t.Normal.Normalize();

                if (Math.Abs(n.DotProduct(nn)) < 0.999)
                    continue;

                if (c.DistanceTo(cn) < 0.01)
                    return true;
            }
        }
        catch
        {
        }

        return false;
    }

    private XYZ CentroPuntos(List<XYZ> pts)
    {
        if (pts == null || pts.Count == 0)
            return XYZ.Zero;

        double x = 0.0;
        double y = 0.0;
        double z = 0.0;
        int n = 0;

        foreach (XYZ p in pts)
        {
            if (p == null)
                continue;

            x += p.X;
            y += p.Y;
            z += p.Z;
            n++;
        }

        if (n == 0)
            return XYZ.Zero;

        return new XYZ(x / n, y / n, z / n);
    }

    // =====================================
    // OBTENER SOLO CARAS EXTERNAS DEL MURO
    // =====================================
    private List<Face> ObtenerCarasExternasDeMuro(Element elem, Transform transformCara)
    {
        List<Face> caras = new List<Face>();

        if (elem == null)
            return caras;

        Wall wall = elem as Wall;

        if (wall == null)
            return caras;

        //-------------------------------------------------
        // 1) Caras principales del muro: exterior e interior.
        // No toma eje ni capas internas.
        //-------------------------------------------------
        AgregarSideFaces(wall, ShellLayerType.Exterior, caras);
        AgregarSideFaces(wall, ShellLayerType.Interior, caras);

        //-------------------------------------------------
        // 2) V32:
        // Las tapas laterales de inicio/fin ya NO se agregan aquí como
        // Face real, porque en algunos casos Revit sí devuelve la tapa y
        // además nosotros generamos la tapa sintética, creando doble muro.
        //
        // Las tapas se crean más abajo únicamente con:
        // CrearTapasSinteticasInicioFin(...)
        //
        // Esto deja una sola fuente para las tapas y evita duplicados.
        //-------------------------------------------------

        return caras;
    }

    private void AgregarSideFaces(
        Wall wall,
        ShellLayerType shellLayerType,
        List<Face> caras)
    {
        if (wall == null || caras == null)
            return;

        IList<Reference> refs = null;

        try
        {
            refs = HostObjectUtils.GetSideFaces(wall, shellLayerType);
        }
        catch
        {
            refs = null;
        }

        if (refs == null || refs.Count == 0)
            return;

        foreach (Reference r in refs)
        {
            if (r == null)
                continue;

            try
            {
                GeometryObject obj = wall.GetGeometryObjectFromReference(r);
                Face face = obj as Face;

                if (face == null)
                    continue;

                if (face.Area <= MinAreaCara)
                    continue;

                if (ExisteCaraSimilar(caras, face))
                    continue;

                caras.Add(face);
            }
            catch
            {
            }
        }
    }

    private void AgregarTapasLateralesInicioFin(
        Wall wall,
        Transform transformCara,
        List<Face> caras)
    {
        if (wall == null || caras == null)
            return;

        if (transformCara == null)
            transformCara = Transform.Identity;

        LocationCurve lc = wall.Location as LocationCurve;

        if (lc == null || lc.Curve == null)
            return;

        XYZ p0;
        XYZ p1;
        XYZ eje;
        double longitud;

        try
        {
            p0 = transformCara.OfPoint(lc.Curve.GetEndPoint(0));
            p1 = transformCara.OfPoint(lc.Curve.GetEndPoint(1));
            eje = p1 - p0;
            longitud = eje.GetLength();

            if (longitud <= 0.001)
                return;

            eje = eje.Normalize();
        }
        catch
        {
            return;
        }

        Options opt = new Options()
        {
            ComputeReferences = false,
            IncludeNonVisibleObjects = true,
            DetailLevel = ViewDetailLevel.Fine
        };

        GeometryElement geo = null;

        try
        {
            geo = wall.get_Geometry(opt);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return;

        List<Face> faces = new List<Face>();
        ExtraerFacesDeGeometry(geo, faces);

        double tolExtremo = 0.25;

        try
        {
            if (wall.Width > 0)
                tolExtremo = Math.Max(0.25, wall.Width * 2.0);
        }
        catch
        {
        }

        List<Face> tapasInicio = new List<Face>();
        List<Face> tapasFin = new List<Face>();

        foreach (Face face in faces)
        {
            if (face == null || face.Area <= MinAreaCara)
                continue;

            PlanarFace pf = face as PlanarFace;

            if (pf == null)
                continue;

            XYZ normal = ObtenerNormalCara(pf, transformCara);

            if (normal == null)
                continue;

            normal = normal.Normalize();

            // Solo tapas verticales; nunca superior/inferior.
            if (Math.Abs(normal.Z) >= TolNormalVertical)
                continue;

            // La tapa inicio/fin tiene normal paralela al eje longitudinal del muro.
            if (Math.Abs(normal.DotProduct(eje)) < 0.90)
                continue;

            XYZ centro = ObtenerCentroCaraTransformado(pf, transformCara);

            if (centro == null)
                continue;

            double d = (centro - p0).DotProduct(eje);

            // Solo extremos reales de la LocationCurve.
            if (d >= -tolExtremo && d <= tolExtremo)
            {
                tapasInicio.Add(pf);
                continue;
            }

            if (d >= longitud - tolExtremo && d <= longitud + tolExtremo)
            {
                tapasFin.Add(pf);
                continue;
            }
        }

        //-------------------------------------------------
        // V27:
        // En cada extremo puede haber varias caras coplanares o parches.
        // Se agrega solo lo no duplicado y se evita repetir la misma tapa.
        //-------------------------------------------------
        AgregarListaTapasSinDuplicar(caras, tapasInicio, transformCara);
        AgregarListaTapasSinDuplicar(caras, tapasFin, transformCara);
    }

    private void AgregarListaTapasSinDuplicar(
        List<Face> carasDestino,
        List<Face> candidatas,
        Transform transformCara)
    {
        if (carasDestino == null || candidatas == null || candidatas.Count == 0)
            return;

        foreach (Face f in candidatas.OrderByDescending(x => x != null ? x.Area : 0.0))
        {
            if (f == null)
                continue;

            if (ExisteCaraSimilarTransformada(carasDestino, f, transformCara))
                continue;

            carasDestino.Add(f);
        }
    }

    private void ExtraerFacesDeGeometry(GeometryElement geo, List<Face> faces)
    {
        if (geo == null || faces == null)
            return;

        foreach (GeometryObject obj in geo)
        {
            Solid solid = obj as Solid;

            if (solid != null)
            {
                if (solid.Faces != null && solid.Faces.Size > 0 && solid.Volume > 0)
                {
                    foreach (Face f in solid.Faces)
                    {
                        if (f != null)
                            faces.Add(f);
                    }
                }

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi == null)
                continue;

            try
            {
                GeometryElement symGeo = gi.GetSymbolGeometry();

                if (symGeo != null)
                    ExtraerFacesDeGeometry(symGeo, faces);
            }
            catch
            {
                try
                {
                    GeometryElement instGeo = gi.GetInstanceGeometry();

                    if (instGeo != null)
                        ExtraerFacesDeGeometry(instGeo, faces);
                }
                catch
                {
                }
            }
        }
    }

    private bool ExisteCaraSimilar(List<Face> caras, Face nueva)
    {
        if (caras == null || nueva == null)
            return false;

        XYZ nNueva = ObtenerNormalCara(nueva, Transform.Identity);

        if (nNueva == null)
            return false;

        XYZ oNueva = ObtenerOrigenCara(nueva);

        if (oNueva == null)
            return false;

        foreach (Face f in caras)
        {
            XYZ nf = ObtenerNormalCara(f, Transform.Identity);
            XYZ of = ObtenerOrigenCara(f);

            if (nf == null || of == null)
                continue;

            double paralelo = Math.Abs(nf.Normalize().DotProduct(nNueva.Normalize()));
            double distancia = Math.Abs((of - oNueva).DotProduct(nNueva.Normalize()));

            if (paralelo > 0.999 && distancia < 0.0005)
                return true;
        }

        return false;
    }

    private XYZ ObtenerOrigenCara(Face face)
    {
        if (face == null)
            return null;

        try
        {
            PlanarFace pf = face as PlanarFace;

            if (pf != null)
                return pf.Origin;
        }
        catch
        {
        }

        try
        {
            BoundingBoxUV bb = face.GetBoundingBox();

            if (bb != null)
            {
                UV uv = new UV(
                    (bb.Min.U + bb.Max.U) / 2.0,
                    (bb.Min.V + bb.Max.V) / 2.0);

                return face.Evaluate(uv);
            }
        }
        catch
        {
        }

        return null;
    }

    private XYZ ObtenerNormalCara(Face face, Transform transformCara)
    {
        if (face == null)
            return null;

        if (transformCara == null)
            transformCara = Transform.Identity;

        try
        {
            PlanarFace pf = face as PlanarFace;

            if (pf != null)
                return transformCara.OfVector(pf.FaceNormal).Normalize();

            BoundingBoxUV bb = face.GetBoundingBox();

            if (bb != null)
            {
                UV uv = new UV(
                    (bb.Min.U + bb.Max.U) / 2.0,
                    (bb.Min.V + bb.Max.V) / 2.0);

                XYZ n = face.ComputeNormal(uv);

                if (n != null)
                    return transformCara.OfVector(n).Normalize();
            }
        }
        catch
        {
        }

        return null;
    }

    private bool ExisteCaraTrabajoSimilar(
        List<CaraTrabajo> existentes,
        Face nueva,
        Transform trNueva)
    {
        if (existentes == null || nueva == null)
            return false;

        XYZ nNueva = ObtenerNormalCara(nueva, trNueva);
        XYZ cNueva = ObtenerCentroCaraTransformado(nueva, trNueva);

        if (nNueva == null || cNueva == null)
            return false;

        nNueva = nNueva.Normalize();

        foreach (CaraTrabajo item in existentes)
        {
            if (item == null || item.Cara == null)
                continue;

            XYZ n = ObtenerNormalCara(item.Cara, item.TransformCara);
            XYZ c = ObtenerCentroCaraTransformado(item.Cara, item.TransformCara);

            if (n == null || c == null)
                continue;

            n = n.Normalize();

            double paralelo = Math.Abs(n.DotProduct(nNueva));
            double distanciaPlano = Math.Abs((c - cNueva).DotProduct(nNueva));

            if (paralelo < 0.999)
                continue;

            // Si están prácticamente en el mismo plano, son candidatos a duplicado.
            if (distanciaPlano > 0.003)
                continue;

            // Valida también que sus cajas proyectadas se solapen.
            double overlap = CalcularSolapeAproximadoEntreCaras(
                item.Cara,
                item.TransformCara,
                nueva,
                trNueva,
                nNueva);

            if (overlap > 0.50)
                return true;
        }

        return false;
    }

    private bool ExisteCaraSimilarTransformada(
        List<Face> existentes,
        Face nueva,
        Transform trNueva)
    {
        if (existentes == null || nueva == null)
            return false;

        XYZ nNueva = ObtenerNormalCara(nueva, trNueva);
        XYZ cNueva = ObtenerCentroCaraTransformado(nueva, trNueva);

        if (nNueva == null || cNueva == null)
            return false;

        nNueva = nNueva.Normalize();

        foreach (Face f in existentes)
        {
            if (f == null)
                continue;

            XYZ n = ObtenerNormalCara(f, Transform.Identity);
            XYZ c = ObtenerCentroCaraTransformado(f, Transform.Identity);

            if (n == null || c == null)
                continue;

            n = n.Normalize();

            double paralelo = Math.Abs(n.DotProduct(nNueva));
            double distanciaPlano = Math.Abs((c - cNueva).DotProduct(nNueva));

            if (paralelo < 0.999 || distanciaPlano > 0.003)
                continue;

            double overlap = CalcularSolapeAproximadoEntreCaras(
                f,
                Transform.Identity,
                nueva,
                trNueva,
                nNueva);

            if (overlap > 0.50)
                return true;
        }

        return false;
    }

    private double CalcularSolapeAproximadoEntreCaras(
        Face a,
        Transform trA,
        Face b,
        Transform trB,
        XYZ normalPlano)
    {
        try
        {
            List<XYZ> pa = ObtenerPuntosFace(a, trA);
            List<XYZ> pb = ObtenerPuntosFace(b, trB);

            if (pa.Count < 3 || pb.Count < 3)
                return 0.0;

            XYZ n = normalPlano != null ? normalPlano.Normalize() : XYZ.BasisX;
            XYZ u = XYZ.BasisZ.CrossProduct(n);

            if (u.GetLength() < 0.001)
                u = XYZ.BasisX;

            u = u.Normalize();
            XYZ v = n.CrossProduct(u).Normalize();
            XYZ o = pa[0];

            double aminU, amaxU, aminV, amaxV;
            double bminU, bmaxU, bminV, bmaxV;

            ObtenerRangoUV(pa, o, u, v, out aminU, out amaxU, out aminV, out amaxV);
            ObtenerRangoUV(pb, o, u, v, out bminU, out bmaxU, out bminV, out bmaxV);

            double overlapU = Math.Min(amaxU, bmaxU) - Math.Max(aminU, bminU);
            double overlapV = Math.Min(amaxV, bmaxV) - Math.Max(aminV, bminV);

            if (overlapU <= 0.0 || overlapV <= 0.0)
                return 0.0;

            double areaOverlap = overlapU * overlapV;
            double areaA = Math.Max((amaxU - aminU) * (amaxV - aminV), 1e-9);
            double areaB = Math.Max((bmaxU - bminU) * (bmaxV - bminV), 1e-9);

            return areaOverlap / Math.Min(areaA, areaB);
        }
        catch
        {
            return 0.0;
        }
    }

    private List<XYZ> ObtenerPuntosFace(Face face, Transform tr)
    {
        List<XYZ> pts = new List<XYZ>();

        if (face == null)
            return pts;

        if (tr == null)
            tr = Transform.Identity;

        try
        {
            IList<CurveLoop> loops = face.GetEdgesAsCurveLoops();

            foreach (CurveLoop loop in loops)
            {
                foreach (Curve c in loop)
                {
                    if (c == null)
                        continue;

                    IList<XYZ> tess = c.Tessellate();

                    if (tess == null || tess.Count == 0)
                        tess = new List<XYZ>() { c.GetEndPoint(0), c.GetEndPoint(1) };

                    foreach (XYZ p in tess)
                    {
                        if (p == null)
                            continue;

                        XYZ pt = tr.OfPoint(p);

                        bool existe = false;

                        foreach (XYZ q in pts)
                        {
                            if (q.DistanceTo(pt) < 0.0005)
                            {
                                existe = true;
                                break;
                            }
                        }

                        if (!existe)
                            pts.Add(pt);
                    }
                }
            }
        }
        catch
        {
        }

        return pts;
    }

    private void ObtenerRangoUV(
        List<XYZ> pts,
        XYZ origen,
        XYZ u,
        XYZ v,
        out double minU,
        out double maxU,
        out double minV,
        out double maxV)
    {
        minU = double.MaxValue;
        maxU = double.MinValue;
        minV = double.MaxValue;
        maxV = double.MinValue;

        foreach (XYZ p in pts)
        {
            double du = (p - origen).DotProduct(u);
            double dv = (p - origen).DotProduct(v);

            if (du < minU) minU = du;
            if (du > maxU) maxU = du;
            if (dv < minV) minV = dv;
            if (dv > maxV) maxV = dv;
        }
    }

    private XYZ ObtenerCentroCaraTransformado(Face face, Transform transformCara)
    {
        if (face == null)
            return null;

        if (transformCara == null)
            transformCara = Transform.Identity;

        try
        {
            BoundingBoxUV bb = face.GetBoundingBox();

            if (bb != null)
            {
                UV uv = new UV(
                    (bb.Min.U + bb.Max.U) / 2.0,
                    (bb.Min.V + bb.Max.V) / 2.0);

                XYZ p = face.Evaluate(uv);

                if (p != null)
                    return transformCara.OfPoint(p);
            }
        }
        catch
        {
        }

        XYZ o = ObtenerOrigenCara(face);

        if (o != null)
            return transformCara.OfPoint(o);

        return null;
    }

    // =====================================
    // OBTENER ELEMENTOS NATIVOS O DE VÍNCULOS
    // =====================================
    private List<ElementoTrabajo> ObtenerElementosTrabajo(Document doc, IList<Reference> refs)
    {
        List<ElementoTrabajo> resultado = new List<ElementoTrabajo>();

        if (doc == null || refs == null)
            return resultado;

        foreach (Reference r in refs)
        {
            if (r == null)
                continue;

            Element elem = doc.GetElement(r.ElementId);

            if (elem == null)
                continue;

            RevitLinkInstance link = elem as RevitLinkInstance;

            if (link != null)
            {
                if (!ConsiderarVinculos)
                    continue;

                Document linkDoc = null;

                try
                {
                    linkDoc = link.GetLinkDocument();
                }
                catch
                {
                    linkDoc = null;
                }

                if (linkDoc == null)
                    continue;

                ElementId linkedId = r.LinkedElementId;

                if (linkedId == ElementId.InvalidElementId)
                    continue;

                Element linkedElem = linkDoc.GetElement(linkedId);

                if (linkedElem == null)
                    continue;

                if (!CategoriaValida(linkedElem))
                    continue;

                Transform tr = Transform.Identity;

                try
                {
                    tr = link.GetTotalTransform();
                }
                catch
                {
                    tr = Transform.Identity;
                }

                resultado.Add(new ElementoTrabajo()
                {
                    HostElem = link,
                    GeoElem = linkedElem,
                    TransformCara = tr
                });

                continue;
            }

            if (!CategoriaValida(elem))
                continue;

            resultado.Add(new ElementoTrabajo()
            {
                HostElem = elem,
                GeoElem = elem,
                TransformCara = Transform.Identity
            });
        }

        return resultado;
    }

    private bool CategoriaValida(Element elem)
    {
        if (elem == null)
            return false;

        Category cat = null;

        try
        {
            cat = elem.Category;
        }
        catch
        {
            cat = null;
        }

        if (cat == null)
            return false;

        return cat.Id.Equals(new ElementId(BuiltInCategory.OST_Walls));
    }

    private void MostrarFormulario()
    {
        try
        {
            if (Form != null && !Form.IsDisposed)
            {
                Form.RestaurarVentana();
                return;
            }
        }
        catch
        {
        }

        try
        {
            if (Form != null && !Form.IsDisposed)
            {
                Form.Show();
                Form.BringToFront();
                Form.Activate();
            }
        }
        catch
        {
        }
    }

    public string GetName()
    {
        return "MYG - Seleccionar Muros para Tarrajeo V32";
    }
}


// =====================================
// FILTRO - SOLO MUROS
// =====================================
public class MurosTarrajeoSelectionFilter : ISelectionFilter
{
    private readonly Document _doc;
    private readonly bool _considerarVinculos;

    public MurosTarrajeoSelectionFilter() : this(null, false)
    {
    }

    public MurosTarrajeoSelectionFilter(bool considerarVinculos) : this(null, considerarVinculos)
    {
    }

    public MurosTarrajeoSelectionFilter(Document doc, bool considerarVinculos)
    {
        _doc = doc;
        _considerarVinculos = considerarVinculos;
    }

    public bool AllowElement(Element elem)
    {
        if (elem == null)
            return false;

        //-------------------------------------------------
        // Si se está seleccionando en vínculo, Revit primero
        // pasa el RevitLinkInstance por AllowElement.
        // Aquí se permite solo para que luego AllowReference
        // valide la categoría REAL del elemento vinculado.
        //-------------------------------------------------
        if (_considerarVinculos && elem is RevitLinkInstance)
            return true;

        return EsCategoriaPermitida(elem);
    }

    public bool AllowReference(Reference reference, XYZ position)
    {
        //-------------------------------------------------
        // Para elementos nativos, AllowElement ya filtró.
        //-------------------------------------------------
        if (!_considerarVinculos)
            return true;

        if (_doc == null || reference == null)
            return false;

        try
        {
            RevitLinkInstance link = _doc.GetElement(reference.ElementId) as RevitLinkInstance;

            if (link == null)
                return true;

            ElementId linkedId = reference.LinkedElementId;

            if (linkedId == ElementId.InvalidElementId)
                return false;

            Document linkDoc = link.GetLinkDocument();

            if (linkDoc == null)
                return false;

            Element linkedElem = linkDoc.GetElement(linkedId);

            return EsCategoriaPermitida(linkedElem);
        }
        catch
        {
            return false;
        }
    }

    private bool EsCategoriaPermitida(Element elem)
    {
        if (elem == null)
            return false;

        if (elem.Category == null)
            return false;

        return elem.Category.Id.Equals(new ElementId(BuiltInCategory.OST_Walls));
    }
}
