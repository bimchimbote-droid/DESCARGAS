using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{


    // =====================================
    // VENTANA EMERGENTE 3.2 (MYG TARRAJEO Y ENCOFRADO)
    // =====================================
    public class TarrajeoForm : WinForms.Form
    {
        // 🔹 PROPIEDADES REALES
        public FloorType TipoSueloSeleccionado => cmbTiposSuelo.SelectedItem as FloorType;
        public WallType TipoMuroSeleccionado => cmbTiposMuro.SelectedItem as WallType;

        // 🔥 CHECK BOOLEANO PARA PERMITIR UNIÓN EN MUROS
        public bool PermitirUnion => chkPermitirUnion.Checked;
        public bool ConsiderarVinculos => chkConsiderarVinculos != null && chkConsiderarVinculos.Checked;

        public WinForms.ComboBox cmbTiposSuelo;
        public WinForms.ComboBox cmbTiposMuro;
        public WinForms.CheckBox chkPermitirUnion;
        public WinForms.CheckBox chkConsiderarVinculos;
        public WinForms.Button btnSeleccionar;

        public ExternalEvent SeleccionarEvent;

        // 🔥 HANDLER SELECTOR
        public SeleccionarCarasHandler Handler;

        public TarrajeoForm()
        {
            // ===== COLORES BASE =====
            Drawing.Color colorFondo = Drawing.Color.FromArgb(248, 249, 251);
            Drawing.Color colorTarjeta = Drawing.Color.White;
            Drawing.Color colorTextoPrincipal = Drawing.Color.FromArgb(32, 33, 36);
            Drawing.Color colorTextoSecundario = Drawing.Color.FromArgb(95, 99, 104);
            Drawing.Color colorBorde = Drawing.Color.FromArgb(225, 229, 235);
            Drawing.Color colorAzul = Drawing.Color.FromArgb(33, 115, 229);
            Drawing.Color colorAzulHover = Drawing.Color.FromArgb(20, 95, 200);
            Drawing.Color colorAzulDown = Drawing.Color.FromArgb(18, 80, 170);

            this.Text = "MYG - Tarrajeo / Encofrado";
            this.Width = 430;
            this.Height = 420;
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = colorFondo;
            this.Font = new Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;

            // ===== ENCABEZADO =====
            var lblTitulo = new WinForms.Label()
            {
                Text = "MYG – Tarrajeo / Encofrado",
                Left = 22,
                Top = 18,
                Width = 360,
                Height = 24,
                Font = new Drawing.Font("Segoe UI", 11F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorFondo
            };

            var lblSubtitulo = new WinForms.Label()
            {
                Text = "Configuración de creación",
                Left = 22,
                Top = 43,
                Width = 360,
                Height = 20,
                Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Regular),
                ForeColor = colorTextoSecundario,
                BackColor = colorFondo
            };

            // ===== TARJETA PRINCIPAL =====
            var pnlContenido = new WinForms.Panel()
            {
                Left = 20,
                Top = 78,
                Width = 372,
                Height = 235,
                BackColor = colorTarjeta,
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };

            // ===== LABEL SUELO =====
            var lblTipoSuelo = new WinForms.Label()
            {
                Text = "01. Tipo de suelo",
                Left = 18,
                Top = 18,
                Width = 250,
                Height = 20,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorTarjeta
            };

            // ===== COMBO SUELO =====
            cmbTiposSuelo = new WinForms.ComboBox()
            {
                Left = 18,
                Top = 42,
                Width = 334,
                Height = 28,
                DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                MaxDropDownItems = 8,
                IntegralHeight = false,
                FlatStyle = WinForms.FlatStyle.Flat,
                BackColor = Drawing.Color.White,
                ForeColor = colorTextoPrincipal
            };

            cmbTiposSuelo.DisplayMember = "Name";
            cmbTiposSuelo.TabIndex = 0;

            cmbTiposSuelo.Format += (s, e) =>
            {
                if (e.ListItem is FloorType ft)
                {
                    e.Value = ft.Name;
                }
            };

            // ===== LABEL MURO =====
            var lblTipoMuro = new WinForms.Label()
            {
                Text = "02. Tipo de muro",
                Left = 18,
                Top = 82,
                Width = 250,
                Height = 20,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorTarjeta
            };

            // ===== COMBO MURO =====
            cmbTiposMuro = new WinForms.ComboBox()
            {
                Left = 18,
                Top = 106,
                Width = 334,
                Height = 28,
                DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                MaxDropDownItems = 8,
                IntegralHeight = false,
                FlatStyle = WinForms.FlatStyle.Flat,
                BackColor = Drawing.Color.White,
                ForeColor = colorTextoPrincipal
            };

            cmbTiposMuro.DisplayMember = "Name";
            cmbTiposMuro.TabIndex = 1;

            cmbTiposMuro.Format += (s, e) =>
            {
                if (e.ListItem is WallType wt)
                {
                    e.Value = wt.Name;
                }
            };

            // ===== SEPARADOR =====
            var lineaOpciones = new WinForms.Panel()
            {
                Left = 18,
                Top = 150,
                Width = 334,
                Height = 1,
                BackColor = colorBorde
            };

            // ===== CHECK PERMITIR UNIÓN =====
            chkPermitirUnion = new WinForms.CheckBox()
            {
                Text = "Permitir Unión",
                Left = 18,
                Top = 164,
                Width = 180,
                Height = 24,
                Checked = false,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorTarjeta,
                FlatStyle = WinForms.FlatStyle.Flat
            };

            chkPermitirUnion.TabIndex = 2;

            // ===== CHECK CONSIDERAR VÍNCULOS =====
            chkConsiderarVinculos = new WinForms.CheckBox()
            {
                Text = "Considerar vínculos",
                Left = 18,
                Top = 194,
                Width = 220,
                Height = 24,
                Checked = false,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorTarjeta,
                FlatStyle = WinForms.FlatStyle.Flat
            };

            chkConsiderarVinculos.TabIndex = 3;

            // ===== BOTÓN =====
            btnSeleccionar = new WinForms.Button()
            {
                Text = "SELECCIONAR CARA",
                Width = 372,
                Height = 40,
                Left = 20,
                Top = 328,
                BackColor = colorAzul,
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9.2F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnSeleccionar.TabIndex = 4;

            btnSeleccionar.FlatAppearance.BorderSize = 0;
            btnSeleccionar.FlatAppearance.MouseOverBackColor = colorAzulHover;
            btnSeleccionar.FlatAppearance.MouseDownBackColor = colorAzulDown;

            btnSeleccionar.Click += (s, e) =>
            {
                if (cmbTiposSuelo.SelectedItem == null && cmbTiposMuro.SelectedItem == null)
                {
                    WinForms.MessageBox.Show(
                        "Debe seleccionar un tipo de suelo o un tipo de muro",
                        "MYG",
                        WinForms.MessageBoxButtons.OK,
                        WinForms.MessageBoxIcon.Warning);
                    return;
                }

                if (Handler != null)
                {
                    Handler.Form = this;
                    Handler.TipoSuelo = TipoSueloSeleccionado;
                    Handler.TipoMuro = TipoMuroSeleccionado;
                    Handler.ConsiderarVinculos = ConsiderarVinculos;
                }

                MinimizarTodo();
                SeleccionarEvent?.Raise();
            };

            // ===== AUTOR / PIE =====
            var lblAutor = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila",
                Left = 22,
                Top = 376,
                Width = 360,
                Height = 18,
                Font = new Drawing.Font("Segoe UI", 8.2F, Drawing.FontStyle.Regular),
                ForeColor = colorTextoSecundario,
                BackColor = colorFondo,
                TextAlign = Drawing.ContentAlignment.MiddleCenter
            };

            // ===== AGREGAR CONTROLES A TARJETA =====
            pnlContenido.Controls.Add(lblTipoSuelo);
            pnlContenido.Controls.Add(cmbTiposSuelo);
            pnlContenido.Controls.Add(lblTipoMuro);
            pnlContenido.Controls.Add(cmbTiposMuro);
            pnlContenido.Controls.Add(lineaOpciones);
            pnlContenido.Controls.Add(chkPermitirUnion);
            pnlContenido.Controls.Add(chkConsiderarVinculos);

            // ===== CONTROLES PRINCIPALES =====
            Controls.Add(lblTitulo);
            Controls.Add(lblSubtitulo);
            Controls.Add(pnlContenido);
            Controls.Add(btnSeleccionar);
            Controls.Add(lblAutor);

            // El comando carga los tipos después del constructor. El catálogo
            // se captura al mostrar la ventana y se conserva al ocultarla/restaurarla.
            FiltroComboTarrajeo.Configurar(cmbTiposSuelo, this);
            FiltroComboTarrajeo.Configurar(cmbTiposMuro, this);

            this.ActiveControl = cmbTiposSuelo;
        }

        // =====================================
        // PUBLIC GENERAL - CONTROL DE VENTANA
        // =====================================
        public void MinimizarTodo()
        {
            MYG_TarrajeoUI.MinimizarTodo(this);
        }

        public void MinimizarVentana()
        {
            MinimizarTodo();
        }

        public void RestaurarVentana()
        {
            MYG_TarrajeoUI.Restaurar(this);
        }
    }


    // Catálogo inmutable de objetos Revit y nombres capturados al cargar la ventana.
    // Filtrar no vuelve a consultar la API de Revit ni convierte tipos a strings.
    internal sealed class CatalogoTiposTarrajeo
    {
        private sealed class Entrada
        {
            internal object Tipo;
            internal string Nombre;
        }

        private readonly List<Entrada> _entradas = new List<Entrada>();

        internal CatalogoTiposTarrajeo(IEnumerable<object> tipos, Func<object, string> obtenerNombre)
        {
            foreach (object tipo in tipos)
            {
                if (tipo != null)
                {
                    _entradas.Add(new Entrada
                    {
                        Tipo = tipo,
                        Nombre = obtenerNombre(tipo) ?? string.Empty
                    });
                }
            }
        }

        internal object[] Buscar(string texto)
        {
            string consulta = (texto ?? string.Empty).Trim();
            CompareInfo comparador = CultureInfo.CurrentCulture.CompareInfo;
            return _entradas
                .Where(e => consulta.Length == 0 || comparador.IndexOf(
                    e.Nombre, consulta, CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace) >= 0)
                .Select(e => e.Tipo)
                .ToArray();
        }

        internal string NombreDe(object tipo)
        {
            Entrada entrada = _entradas.FirstOrDefault(e => object.ReferenceEquals(e.Tipo, tipo));
            return entrada != null ? entrada.Nombre : string.Empty;
        }
    }

    internal sealed class FiltroComboTarrajeo
    {
        private readonly WinForms.ComboBox _combo;
        private CatalogoTiposTarrajeo _catalogo;
        private object _seleccionConfirmada;
        private bool _actualizando;
        private bool _editando;

        private FiltroComboTarrajeo(WinForms.ComboBox combo, WinForms.Form ventana)
        {
            _combo = combo;
            _combo.DropDownStyle = WinForms.ComboBoxStyle.DropDown;
            // El autocompletado nativo puede sustituir la consulta por el primer
            // resultado. La lista se filtra conservando el texto escrito.
            _combo.AutoCompleteMode = WinForms.AutoCompleteMode.None;
            _combo.AutoCompleteSource = WinForms.AutoCompleteSource.None;

            ventana.Load += (s, e) => Inicializar();
            _combo.TextUpdate += (s, e) => Filtrar();
            _combo.KeyDown += AlPulsarTecla;
            _combo.SelectionChangeCommitted += (s, e) => ConfirmarSeleccion();
            _combo.Leave += (s, e) =>
            {
                if (!_actualizando && _combo.SelectedItem != null)
                    ConfirmarSeleccion();
            };
        }

        internal static void Configurar(WinForms.ComboBox combo, WinForms.Form ventana)
        {
            // Los eventos mantienen esta instancia mientras exista su ventana.
            new FiltroComboTarrajeo(combo, ventana);
        }

        private void Inicializar()
        {
            if (_catalogo != null)
                return;

            _catalogo = new CatalogoTiposTarrajeo(
                _combo.Items.Cast<object>().ToArray(),
                tipo => _combo.GetItemText(tipo));
            _seleccionConfirmada = _combo.SelectedItem;
        }

        private void Filtrar()
        {
            if (_actualizando)
                return;

            Inicializar();
            string texto = _combo.Text;
            int inicio = _combo.SelectionStart;
            int longitud = _combo.SelectionLength;
            _editando = true;
            ReponerLista(_catalogo.Buscar(texto), texto, null, inicio, longitud, true);
        }

        private void ReponerLista(
            object[] tipos,
            string texto,
            object seleccionado,
            int inicio,
            int longitud,
            bool desplegar)
        {
            _actualizando = true;
            try
            {
                _combo.BeginUpdate();
                try
                {
                    _combo.Items.Clear();
                    _combo.Items.AddRange(tipos);
                    // Una consulta parcial/sin coincidencias no puede conservar
                    // el tipo anterior, aunque el otro combo siga seleccionado.
                    _combo.SelectedIndex = -1;
                    if (seleccionado != null)
                        _combo.SelectedItem = seleccionado;
                    _combo.Text = texto;
                }
                finally
                {
                    _combo.EndUpdate();
                }

                if (_combo.IsHandleCreated && _combo.Visible && _combo.Focused)
                    _combo.DroppedDown = desplegar && tipos.Length > 0;

                // Abrir o reconstruir el desplegable puede cambiar la selección
                // del editor nativo; restaurarla después permite seguir escribiendo.
                _combo.Text = texto;
                int posicion = Math.Min(inicio, texto.Length);
                _combo.Select(posicion, Math.Min(longitud, texto.Length - posicion));
            }
            finally
            {
                _actualizando = false;
            }
        }

        private void ConfirmarSeleccion()
        {
            if (_actualizando || _combo.SelectedItem == null)
                return;

            _seleccionConfirmada = _combo.SelectedItem;
            _editando = false;
        }

        private void AlPulsarTecla(object sender, WinForms.KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == WinForms.Keys.A)
            {
                _combo.Select(0, _combo.Text.Length);
                e.Handled = true;
                e.SuppressKeyPress = true;
                return;
            }

            if (e.KeyCode == WinForms.Keys.Enter)
            {
                Inicializar();
                if (_combo.SelectedItem == null && _combo.Items.Count > 0)
                    _combo.SelectedIndex = 0;
                ConfirmarSeleccion();
                _combo.DroppedDown = false;
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
            else if (e.KeyCode == WinForms.Keys.Escape && _editando)
            {
                Inicializar();
                string nombre = _catalogo.NombreDe(_seleccionConfirmada);
                ReponerLista(_catalogo.Buscar(string.Empty), nombre,
                    _seleccionConfirmada, nombre.Length, 0, false);
                _editando = false;
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }
    }

}
