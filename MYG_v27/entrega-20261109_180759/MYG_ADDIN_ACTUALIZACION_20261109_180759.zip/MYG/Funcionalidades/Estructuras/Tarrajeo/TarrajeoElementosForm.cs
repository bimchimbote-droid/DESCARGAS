using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Microsoft.Vbe.Interop;
using MYG.Properties;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Drawing = System.Drawing;
using ExcelInterop = Microsoft.Office.Interop.Excel;
using WinForms = System.Windows.Forms;



namespace MYG_Addin
{


    // =====================================
    // VENTANA EMERGENTE - TARRAJEO POR ELEMENTOS
    // =====================================
    public class TarrajeoElementosForm : WinForms.Form
    {
        // 🔹 PROPIEDADES REALES PARA EL FLUJO POR ELEMENTOS
        public FloorType TipoSueloSeleccionado => cmbTiposSuelo.SelectedItem as FloorType;
        public WallType TipoMuroSeleccionado => cmbTiposMuro.SelectedItem as WallType;
        public bool PermitirUnion => chkPermitirUnion.Checked;
        public bool ConsiderarVinculos => chkConsiderarVinculos != null && chkConsiderarVinculos.Checked;

        // 🔥 SELECCIÓN DE FLUJO
        public bool EjecutarVigas => chkVigas.Checked;
        public bool EjecutarColumnas => chkColumnas.Checked;
        public bool EjecutarMuros => chkMuros.Checked;
        public bool EjecutarCimentacion => chkCimentacion.Checked;
        public bool EjecutarLosas => chkLosas.Checked;
        public bool EjecutarEscaleras => chkEscaleras.Checked;

        public WinForms.ComboBox cmbTiposSuelo;
        public WinForms.ComboBox cmbTiposMuro;
        public WinForms.CheckBox chkPermitirUnion;
        public WinForms.CheckBox chkConsiderarVinculos;

        public WinForms.CheckBox chkVigas;
        public WinForms.CheckBox chkColumnas;
        public WinForms.CheckBox chkMuros;
        public WinForms.CheckBox chkCimentacion;
        public WinForms.CheckBox chkLosas;
        public WinForms.CheckBox chkEscaleras;

        public WinForms.Button btnSeleccionarElemento;

        // 🔥 EVENTOS SEPARADOS
        public ExternalEvent SeleccionarVigasEvent;
        public ExternalEvent SeleccionarColumnasEvent;
        public ExternalEvent SeleccionarMurosEvent;
        public ExternalEvent SeleccionarCimentacionEvent;
        public ExternalEvent SeleccionarLosasEvent;
        public ExternalEvent SeleccionarEscalerasEvent;

        // 🔥 HANDLERS SEPARADOS
        public SeleccionarVigasTarrajeoHandler HandlerVigas;
        public SeleccionarColumnasTarrajeoHandler HandlerColumnas;
        public SeleccionarMurosTarrajeoHandler HandlerMuros;
        public SeleccionarCimentacionTarrajeoHandler HandlerCimentacion;
        public SeleccionarLosasTarrajeoHandler HandlerLosas;
        public SeleccionarEscalerasTarrajeoHandler HandlerEscaleras;

        public TarrajeoElementosForm()
        {
            // ===== COLORES BASE =====
            Drawing.Color colorFondo = Drawing.Color.FromArgb(248, 249, 251);
            Drawing.Color colorTarjeta = Drawing.Color.White;
            Drawing.Color colorTextoPrincipal = Drawing.Color.FromArgb(32, 33, 36);
            Drawing.Color colorTextoSecundario = Drawing.Color.FromArgb(95, 99, 104);
            Drawing.Color colorBorde = Drawing.Color.FromArgb(225, 229, 235);
            Drawing.Color colorAzul = Drawing.Color.FromArgb(33, 115, 229);
            Drawing.Color colorAzulHover = Drawing.Color.FromArgb(20, 95, 200);
            Drawing.Color colorAzulDown = Drawing.Color.FromArgb(18, 80, 170);

            this.Text = "MYG - Tarrajeo por Elementos";
            this.Width = 450;
            this.Height = 565;
            this.StartPosition = WinForms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = colorFondo;
            this.Font = new Drawing.Font("Segoe UI", 9F);
            this.TopMost = true;

            // ===== ENCABEZADO =====
            var lblTitulo = new WinForms.Label()
            {
                Text = "MYG – Tarrajeo por Elementos",
                Left = 22,
                Top = 18,
                Width = 380,
                Height = 24,
                Font = new Drawing.Font("Segoe UI", 11F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorFondo
            };

            var lblSubtitulo = new WinForms.Label()
            {
                Text = "Configuración para crear desde elementos",
                Left = 22,
                Top = 43,
                Width = 380,
                Height = 20,
                Font = new Drawing.Font("Segoe UI", 8.8F, Drawing.FontStyle.Regular),
                ForeColor = colorTextoSecundario,
                BackColor = colorFondo
            };

            // ===== TARJETA PRINCIPAL =====
            var pnlContenido = new WinForms.Panel()
            {
                Left = 20,
                Top = 78,
                Width = 392,
                Height = 375,
                BackColor = colorTarjeta,
                BorderStyle = WinForms.BorderStyle.FixedSingle
            };

            // ===== LABEL SUELO =====
            var lblTipoSuelo = new WinForms.Label()
            {
                Text = "01. Tipo de suelo",
                Left = 18,
                Top = 18,
                Width = 250,
                Height = 20,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorTarjeta
            };

            // ===== COMBO SUELO =====
            cmbTiposSuelo = new WinForms.ComboBox()
            {
                Left = 18,
                Top = 42,
                Width = 354,
                Height = 28,
                DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                MaxDropDownItems = 8,
                IntegralHeight = false,
                FlatStyle = WinForms.FlatStyle.Flat,
                BackColor = Drawing.Color.White,
                ForeColor = colorTextoPrincipal
            };

            cmbTiposSuelo.DisplayMember = "Name";
            cmbTiposSuelo.TabIndex = 0;

            cmbTiposSuelo.Format += (s, e) =>
            {
                if (e.ListItem is FloorType ft)
                    e.Value = ft.Name;
            };

            // ===== LABEL MURO =====
            var lblTipoMuro = new WinForms.Label()
            {
                Text = "02. Tipo de muro",
                Left = 18,
                Top = 82,
                Width = 250,
                Height = 20,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorTarjeta
            };

            // ===== COMBO MURO =====
            cmbTiposMuro = new WinForms.ComboBox()
            {
                Left = 18,
                Top = 106,
                Width = 354,
                Height = 28,
                DropDownStyle = WinForms.ComboBoxStyle.DropDown,
                MaxDropDownItems = 8,
                IntegralHeight = false,
                FlatStyle = WinForms.FlatStyle.Flat,
                BackColor = Drawing.Color.White,
                ForeColor = colorTextoPrincipal
            };

            cmbTiposMuro.DisplayMember = "Name";
            cmbTiposMuro.TabIndex = 1;

            cmbTiposMuro.Format += (s, e) =>
            {
                if (e.ListItem is WallType wt)
                    e.Value = wt.Name;
            };

            // ===== SEPARADOR 1 =====
            var lineaOpciones = new WinForms.Panel()
            {
                Left = 18,
                Top = 150,
                Width = 354,
                Height = 1,
                BackColor = colorBorde
            };

            // ===== CHECK PERMITIR UNIÓN =====
            chkPermitirUnion = new WinForms.CheckBox()
            {
                Text = "Permitir Unión",
                Left = 18,
                Top = 164,
                Width = 180,
                Height = 24,
                Checked = false,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorTarjeta,
                FlatStyle = WinForms.FlatStyle.Flat
            };

            chkPermitirUnion.TabIndex = 2;

            // ===== CHECK CONSIDERAR VÍNCULOS =====
            chkConsiderarVinculos = new WinForms.CheckBox()
            {
                Text = "Considerar vínculos",
                Left = 18,
                Top = 190,
                Width = 220,
                Height = 24,
                Checked = false,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorTarjeta,
                FlatStyle = WinForms.FlatStyle.Flat
            };

            chkConsiderarVinculos.TabIndex = 3;

            // ===== SEPARADOR 2 =====
            var lineaElementos = new WinForms.Panel()
            {
                Left = 18,
                Top = 224,
                Width = 354,
                Height = 1,
                BackColor = colorBorde
            };

            // ===== LABEL ELEMENTOS =====
            var lblElementos = new WinForms.Label()
            {
                Text = "03. Elemento a ejecutar",
                Left = 18,
                Top = 238,
                Width = 250,
                Height = 20,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorTarjeta
            };

            // ===== CHECK VIGAS =====
            chkVigas = new WinForms.CheckBox()
            {
                Text = "Vigas",
                Left = 34,
                Top = 266,
                Width = 140,
                Height = 24,
                Checked = true,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorTarjeta,
                FlatStyle = WinForms.FlatStyle.Flat
            };

            chkVigas.TabIndex = 4;

            // ===== CHECK COLUMNAS =====
            chkColumnas = new WinForms.CheckBox()
            {
                Text = "Columnas",
                Left = 210,
                Top = 266,
                Width = 140,
                Height = 24,
                Checked = false,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorTarjeta,
                FlatStyle = WinForms.FlatStyle.Flat
            };

            chkColumnas.TabIndex = 5;

            // ===== CHECK MUROS =====
            chkMuros = new WinForms.CheckBox()
            {
                Text = "Muros",
                Left = 34,
                Top = 296,
                Width = 140,
                Height = 24,
                Checked = false,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorTarjeta,
                FlatStyle = WinForms.FlatStyle.Flat
            };

            chkMuros.TabIndex = 6;

            // ===== CHECK CIMENTACIÓN =====
            chkCimentacion = new WinForms.CheckBox()
            {
                Text = "Cimentación",
                Left = 210,
                Top = 296,
                Width = 150,
                Height = 24,
                Checked = false,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorTarjeta,
                FlatStyle = WinForms.FlatStyle.Flat
            };

            chkCimentacion.TabIndex = 7;

            // ===== CHECK LOSAS =====
            chkLosas = new WinForms.CheckBox()
            {
                Text = "Losas",
                Left = 34,
                Top = 326,
                Width = 140,
                Height = 24,
                Checked = false,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorTarjeta,
                FlatStyle = WinForms.FlatStyle.Flat
            };

            chkLosas.TabIndex = 8;

            // ===== CHECK ESCALERAS =====
            chkEscaleras = new WinForms.CheckBox()
            {
                Text = "Escaleras",
                Left = 210,
                Top = 326,
                Width = 150,
                Height = 24,
                Checked = false,
                Font = new Drawing.Font("Segoe UI", 9F, Drawing.FontStyle.Bold),
                ForeColor = colorTextoPrincipal,
                BackColor = colorTarjeta,
                FlatStyle = WinForms.FlatStyle.Flat
            };

            chkEscaleras.TabIndex = 9;

            // 🔥 HACER CHECKS EXCLUYENTES
            chkVigas.CheckedChanged += (s, e) =>
            {
                if (chkVigas.Checked) DesmarcarOtros(chkVigas);
            };

            chkColumnas.CheckedChanged += (s, e) =>
            {
                if (chkColumnas.Checked) DesmarcarOtros(chkColumnas);
            };

            chkMuros.CheckedChanged += (s, e) =>
            {
                if (chkMuros.Checked) DesmarcarOtros(chkMuros);
            };

            chkCimentacion.CheckedChanged += (s, e) =>
            {
                if (chkCimentacion.Checked) DesmarcarOtros(chkCimentacion);
            };

            chkLosas.CheckedChanged += (s, e) =>
            {
                if (chkLosas.Checked) DesmarcarOtros(chkLosas);
            };

            chkEscaleras.CheckedChanged += (s, e) =>
            {
                if (chkEscaleras.Checked) DesmarcarOtros(chkEscaleras);
            };

            // ===== BOTÓN SELECCIONAR ELEMENTO =====
            btnSeleccionarElemento = new WinForms.Button()
            {
                Text = "SELECCIONAR ELEMENTO",
                Width = 392,
                Height = 40,
                Left = 20,
                Top = 468,
                BackColor = colorAzul,
                ForeColor = Drawing.Color.White,
                FlatStyle = WinForms.FlatStyle.Flat,
                Font = new Drawing.Font("Segoe UI", 9.2F, Drawing.FontStyle.Bold),
                Cursor = WinForms.Cursors.Hand
            };

            btnSeleccionarElemento.TabIndex = 10;

            btnSeleccionarElemento.FlatAppearance.BorderSize = 0;
            btnSeleccionarElemento.FlatAppearance.MouseOverBackColor = colorAzulHover;
            btnSeleccionarElemento.FlatAppearance.MouseDownBackColor = colorAzulDown;

            btnSeleccionarElemento.Click += (s, e) =>
            {
                if (!HayElementoSeleccionado())
                {
                    WinForms.MessageBox.Show(
                        "Debe seleccionar un tipo de elemento a ejecutar.",
                        "MYG",
                        WinForms.MessageBoxButtons.OK,
                        WinForms.MessageBoxIcon.Warning);
                    return;
                }

                // =====================================
                // FLUJO VIGAS
                // =====================================
                if (chkVigas.Checked)
                {
                    if (!ValidarTipoSueloOMuro())
                        return;

                    if (HandlerVigas != null)
                    {
                        HandlerVigas.Form = this;
                        HandlerVigas.TipoSuelo = TipoSueloSeleccionado;
                        HandlerVigas.TipoMuro = TipoMuroSeleccionado;
                        HandlerVigas.PermitirUnion = PermitirUnion;
                        HandlerVigas.ConsiderarVinculos = ConsiderarVinculos;
                    }

                    if (SeleccionarVigasEvent == null)
                    {
                        MostrarEventoNoEncontrado("vigas");
                        return;
                    }

                    MinimizarTodo();
                    SeleccionarVigasEvent.Raise();
                    return;
                }

                // =====================================
                // FLUJO COLUMNAS
                // =====================================
                if (chkColumnas.Checked)
                {
                    if (!ValidarTipoMuro("Para columnas debe seleccionar un tipo de muro."))
                        return;

                    if (HandlerColumnas != null)
                    {
                        HandlerColumnas.Form = this;
                        HandlerColumnas.TipoMuro = TipoMuroSeleccionado;
                        HandlerColumnas.PermitirUnion = PermitirUnion;
                        HandlerColumnas.ConsiderarVinculos = ConsiderarVinculos;
                    }

                    if (SeleccionarColumnasEvent == null)
                    {
                        MostrarEventoNoEncontrado("columnas");
                        return;
                    }

                    MinimizarTodo();
                    SeleccionarColumnasEvent.Raise();
                    return;
                }

                // =====================================
                // FLUJO MUROS
                // =====================================
                if (chkMuros.Checked)
                {
                    if (!ValidarTipoSueloOMuro())
                        return;

                    if (HandlerMuros != null)
                    {
                        HandlerMuros.Form = this;
                        HandlerMuros.TipoSuelo = TipoSueloSeleccionado;
                        HandlerMuros.TipoMuro = TipoMuroSeleccionado;
                        HandlerMuros.PermitirUnion = PermitirUnion;
                        HandlerMuros.ConsiderarVinculos = ConsiderarVinculos;
                    }

                    if (SeleccionarMurosEvent == null)
                    {
                        MostrarEventoNoEncontrado("muros");
                        return;
                    }

                    MinimizarTodo();
                    SeleccionarMurosEvent.Raise();
                    return;
                }

                // =====================================
                // FLUJO CIMENTACIÓN
                // =====================================
                if (chkCimentacion.Checked)
                {
                    if (!ValidarTipoMuro("Para cimentación debe seleccionar un tipo de muro."))
                        return;

                    if (HandlerCimentacion != null)
                    {
                        HandlerCimentacion.Form = this;
                        HandlerCimentacion.TipoMuro = TipoMuroSeleccionado;
                        HandlerCimentacion.PermitirUnion = PermitirUnion;
                        HandlerCimentacion.ConsiderarVinculos = ConsiderarVinculos;
                    }

                    if (SeleccionarCimentacionEvent == null)
                    {
                        MostrarEventoNoEncontrado("cimentación");
                        return;
                    }

                    MinimizarTodo();
                    SeleccionarCimentacionEvent.Raise();
                    return;
                }

                // =====================================
                // FLUJO LOSAS
                // =====================================
                if (chkLosas.Checked)
                {
                    if (!ValidarTipoSueloOMuro())
                        return;

                    if (HandlerLosas != null)
                    {
                        HandlerLosas.Form = this;
                        HandlerLosas.TipoSuelo = TipoSueloSeleccionado;
                        HandlerLosas.TipoMuro = TipoMuroSeleccionado;
                        HandlerLosas.PermitirUnion = PermitirUnion;
                        HandlerLosas.ConsiderarVinculos = ConsiderarVinculos;
                    }

                    if (SeleccionarLosasEvent == null)
                    {
                        MostrarEventoNoEncontrado("losas");
                        return;
                    }

                    MinimizarTodo();
                    SeleccionarLosasEvent.Raise();
                    return;
                }

                // =====================================
                // FLUJO ESCALERAS
                // =====================================
                if (chkEscaleras.Checked)
                {
                    if (!ValidarTipoSueloOMuro())
                        return;

                    if (HandlerEscaleras != null)
                    {
                        HandlerEscaleras.Form = this;
                        HandlerEscaleras.TipoSuelo = TipoSueloSeleccionado;
                        HandlerEscaleras.TipoMuro = TipoMuroSeleccionado;
                        HandlerEscaleras.PermitirUnion = PermitirUnion;
                        HandlerEscaleras.ConsiderarVinculos = ConsiderarVinculos;
                    }

                    if (SeleccionarEscalerasEvent == null)
                    {
                        MostrarEventoNoEncontrado("escaleras");
                        return;
                    }

                    MinimizarTodo();
                    SeleccionarEscalerasEvent.Raise();
                    return;
                }
            };

            // ===== AUTOR / PIE =====
            var lblAutor = new WinForms.Label()
            {
                Text = "Creado por: Ing. Marlon Yacila",
                Left = 22,
                Top = 516,
                Width = 390,
                Height = 18,
                Font = new Drawing.Font("Segoe UI", 8.2F, Drawing.FontStyle.Regular),
                ForeColor = colorTextoSecundario,
                BackColor = colorFondo,
                TextAlign = Drawing.ContentAlignment.MiddleCenter
            };

            // ===== AGREGAR CONTROLES A TARJETA =====
            pnlContenido.Controls.Add(lblTipoSuelo);
            pnlContenido.Controls.Add(cmbTiposSuelo);
            pnlContenido.Controls.Add(lblTipoMuro);
            pnlContenido.Controls.Add(cmbTiposMuro);
            pnlContenido.Controls.Add(lineaOpciones);
            pnlContenido.Controls.Add(chkPermitirUnion);
            pnlContenido.Controls.Add(chkConsiderarVinculos);
            pnlContenido.Controls.Add(lineaElementos);
            pnlContenido.Controls.Add(lblElementos);
            pnlContenido.Controls.Add(chkVigas);
            pnlContenido.Controls.Add(chkColumnas);
            pnlContenido.Controls.Add(chkMuros);
            pnlContenido.Controls.Add(chkCimentacion);
            pnlContenido.Controls.Add(chkLosas);
            pnlContenido.Controls.Add(chkEscaleras);

            // ===== CONTROLES PRINCIPALES =====
            Controls.Add(lblTitulo);
            Controls.Add(lblSubtitulo);
            Controls.Add(pnlContenido);
            Controls.Add(btnSeleccionarElemento);
            Controls.Add(lblAutor);

            // El comando carga los tipos después del constructor. El catálogo
            // se captura al mostrar la ventana y se conserva al ocultarla/restaurarla.
            FiltroComboTarrajeo.Configurar(cmbTiposSuelo, this);
            FiltroComboTarrajeo.Configurar(cmbTiposMuro, this);

            this.ActiveControl = cmbTiposSuelo;
        }

        private void DesmarcarOtros(WinForms.CheckBox seleccionado)
        {
            if (seleccionado != chkVigas) chkVigas.Checked = false;
            if (seleccionado != chkColumnas) chkColumnas.Checked = false;
            if (seleccionado != chkMuros) chkMuros.Checked = false;
            if (seleccionado != chkCimentacion) chkCimentacion.Checked = false;
            if (seleccionado != chkLosas) chkLosas.Checked = false;
            if (seleccionado != chkEscaleras) chkEscaleras.Checked = false;
        }

        private bool HayElementoSeleccionado()
        {
            return chkVigas.Checked ||
                   chkColumnas.Checked ||
                   chkMuros.Checked ||
                   chkCimentacion.Checked ||
                   chkLosas.Checked ||
                   chkEscaleras.Checked;
        }

        private bool ValidarTipoSueloOMuro()
        {
            if (cmbTiposSuelo.SelectedItem == null && cmbTiposMuro.SelectedItem == null)
            {
                WinForms.MessageBox.Show(
                    "Debe seleccionar un tipo de suelo o un tipo de muro.",
                    "MYG",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Warning);

                return false;
            }

            return true;
        }

        private bool ValidarTipoMuro(string mensaje)
        {
            if (cmbTiposMuro.SelectedItem == null)
            {
                WinForms.MessageBox.Show(
                    mensaje,
                    "MYG",
                    WinForms.MessageBoxButtons.OK,
                    WinForms.MessageBoxIcon.Warning);

                return false;
            }

            return true;
        }

        private void MostrarEventoNoEncontrado(string nombre)
        {
            WinForms.MessageBox.Show(
                "No se encontró el evento de selección de " + nombre + ".",
                "MYG",
                WinForms.MessageBoxButtons.OK,
                WinForms.MessageBoxIcon.Warning);
        }

        // =====================================
        // PUBLIC GENERAL - CONTROL DE VENTANA
        // =====================================
        public void MinimizarTodo()
        {
            MYG_TarrajeoUI.MinimizarTodo(this);
        }

        public void MinimizarVentana()
        {
            MinimizarTodo();
        }

        public void RestaurarVentana()
        {
            MYG_TarrajeoUI.Restaurar(this);
        }

        public void RestaurarDespuesDeSeleccion()
        {
            RestaurarVentana();
        }
    }

}
