﻿// =====================================
// HANDLER V19 - SELECCIONAR CIMENTACIÓN - VISTA ACTIVA REAL
// - Usa visibilidad REAL de la vista activa mediante Tarrajeo_MurosHandler V75.
// - Si un elemento oculto corta geométricamente al seleccionado por Join Geometry,
//   invierte temporalmente el orden de unión para recuperar la cara completa.
// - Restaura siempre el orden de unión original al finalizar.
// =====================================
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using MYG_Addin;
using System;
using System.Collections.Generic;
using System.Linq;

public class SeleccionarCimentacionTarrajeoHandler : IExternalEventHandler
{
    public UIDocument UiDoc;
    public TarrajeoElementosForm Form;

    public WallType TipoMuro;
    public bool PermitirUnion;
    public bool ConsiderarVinculos;

    // Motores comunes de creación.
    // El comando los inyecta para que por ELEMENTOS use la misma lógica que por CARAS.
    public Tarrajeo_MurosHandler CreadorMuros;
    public Tarrajeo_SuelosHandler CreadorSuelos;

    public List<ElementId> ElementosSeleccionados = new List<ElementId>();

    private const double TolNormalVertical = 0.001;
    private const double MinAreaCara = 0.0001;

    private class CaraTrabajo
    {
        public Element HostElem;
        public Element GeoElem;
        public RevitLinkInstance LinkOrigen;
        public Face Cara;
        public Transform TransformCara;
    }

    private class ElementoTrabajo
    {
        public Element HostElem;
        public Element GeoElem;
        public Transform TransformCara;
    }

    public void Execute(UIApplication app)
    {
        UIDocument uidoc = UiDoc ?? app.ActiveUIDocument;

        if (uidoc == null)
        {
            TaskDialog.Show("MYG", "No se encontró el documento activo.");
            MostrarFormulario();
            return;
        }

        Document doc = uidoc.Document;

        List<TarrajeoVistaActivaUnionesHelper.UnionOcultaInvertida> unionesOcultasInvertidas =
            new List<TarrajeoVistaActivaUnionesHelper.UnionOcultaInvertida>();

        try
        {
            //-------------------------------------------------
            // TOMAR DATOS DESDE EL FORMULARIO
            //-------------------------------------------------
            if (Form != null)
            {
                TipoMuro = Form.TipoMuroSeleccionado;
                PermitirUnion = Form.PermitirUnion;
                ConsiderarVinculos = Form.ConsiderarVinculos;
            }

            //-------------------------------------------------
            // VALIDAR TIPO DE MURO
            //-------------------------------------------------
            if (TipoMuro == null)
            {
                TaskDialog.Show(
                    "MYG",
                    "Para cimentación debe seleccionar un tipo de muro.");

                MostrarFormulario();
                return;
            }

            //-------------------------------------------------
            // SELECCIONAR CIMENTACIÓN ESTRUCTURAL
            //-------------------------------------------------
            ObjectType tipoSeleccion = ConsiderarVinculos ? ObjectType.LinkedElement : ObjectType.Element;

            IList<Reference> refs = uidoc.Selection.PickObjects(
                tipoSeleccion,
                new CimentacionTarrajeoSelectionFilter(doc, ConsiderarVinculos),
                ConsiderarVinculos
                    ? "Seleccione elementos de cimentación estructural de vínculos"
                    : "Seleccione elementos de cimentación estructural");

            if (refs == null || refs.Count == 0)
            {
                MostrarFormulario();
                return;
            }

            List<ElementoTrabajo> elementosTrabajo = ObtenerElementosTrabajo(doc, refs);

            ElementosSeleccionados = elementosTrabajo
                .Where(x => x != null && x.HostElem != null)
                .Select(x => x.HostElem.Id)
                .Distinct()
                .ToList();

            if (elementosTrabajo.Count == 0)
            {
                MostrarFormulario();
                return;
            }

            //-------------------------------------------------
            // VISTA ACTIVA REAL - PREPARAR MOTOR ANTES DE LEER CARAS
            //-------------------------------------------------
            Tarrajeo_MurosHandler creadorMuros =
                CreadorMuros ?? new Tarrajeo_MurosHandler();

            creadorMuros.UiDoc = uidoc;
            creadorMuros.ConsiderarVinculos = ConsiderarVinculos;
            creadorMuros.PrepararNuevaEjecucion();

            //-------------------------------------------------
            // IGNORAR TEMPORALMENTE SOLO UNIONES DE ELEMENTOS OCULTOS
            //-------------------------------------------------
            unionesOcultasInvertidas =
                TarrajeoVistaActivaUnionesHelper
                .InvertirTemporalmenteUnionesOcultasQueCortan(
                    doc,
                    elementosTrabajo
                        .Where(x => x != null && x.GeoElem != null)
                        .Select(x => x.GeoElem),
                    creadorMuros);

            //-------------------------------------------------
            // PREPROCESAR SOLO CARAS LATERALES VERTICALES
            //-------------------------------------------------
            List<CaraTrabajo> carasParaCrear = new List<CaraTrabajo>();

            int cimentacionesProcesadas = 0;
            int carasOmitidas = 0;
            int carasNoVerticalesOmitidas = 0;

            foreach (ElementoTrabajo et in elementosTrabajo)
            {
                Element elem = et != null ? et.HostElem : null;
                Element geoElem = et != null ? et.GeoElem : null;
                Transform transformCara = et != null && et.TransformCara != null ? et.TransformCara : Transform.Identity;

                if (elem == null || geoElem == null)
                    continue;

                cimentacionesProcesadas++;

                List<Face> caras = ObtenerCarasValidasEnModelo(geoElem, transformCara);

                foreach (Face cara in caras)
                {
                    if (cara == null)
                    {
                        carasOmitidas++;
                        continue;
                    }

                    if (cara.Area <= MinAreaCara)
                    {
                        carasOmitidas++;
                        continue;
                    }

                    XYZ normal = ObtenerNormalCara(cara, Transform.Identity);

                    if (normal == null)
                    {
                        carasOmitidas++;
                        continue;
                    }

                    normal = normal.Normalize();

                    //-------------------------------------------------
                    // SOLO CARAS LATERALES VERTICALES
                    // Se omiten caras superiores, inferiores e inclinadas.
                    //-------------------------------------------------
                    if (Math.Abs(normal.Z) >= TolNormalVertical)
                    {
                        carasNoVerticalesOmitidas++;
                        continue;
                    }

                    carasParaCrear.Add(new CaraTrabajo
                    {
                        HostElem = elem,
                        GeoElem = geoElem,
                        LinkOrigen = elem as RevitLinkInstance,
                        Cara = cara,
                        // Las caras ya fueron transformadas al modelo anfitrión.
                        TransformCara = Transform.Identity
                    });
                }
            }

            if (carasParaCrear.Count == 0)
            {
                TaskDialog.Show(
                    "MYG - Tarrajeo por Cimentación",
                    "No se encontraron caras laterales válidas para crear tarrajeo.\n\n" +
                    "Cimentaciones procesadas: " + cimentacionesProcesadas + "\n" +
                    "Caras no verticales omitidas: " + carasNoVerticalesOmitidas + "\n" +
                    "Caras omitidas: " + carasOmitidas);

                MostrarFormulario();
                return;
            }

            //-------------------------------------------------
            // CREAR TARRAJEO
            //-------------------------------------------------
            int murosCreados = 0;

            foreach (CaraTrabajo item in carasParaCrear)
            {
                if (item == null || item.HostElem == null || item.Cara == null)
                {
                    carasOmitidas++;
                    continue;
                }

                //-------------------------------------------------
                // MISMA LÓGICA QUE TARRAJEO POR CARA:
                // Las caras detectadas del elemento se envían al motor común de muros.
                //-------------------------------------------------
                creadorMuros.ConfigurarOrigenDeRecorte(
                    item.GeoElem ?? item.HostElem,
                    item.LinkOrigen);

                List<Wall> murosNuevos = creadorMuros.CrearMurosDesdeFaceProcesada(
                    doc,
                    uidoc,
                    item.HostElem,
                    item.Cara,
                    item.TransformCara ?? Transform.Identity,
                    TipoMuro,
                    PermitirUnion);

                if (murosNuevos != null && murosNuevos.Count > 0)
                    murosCreados += murosNuevos.Count;
                else
                    carasOmitidas++;
            }

            //-------------------------------------------------
            // V13 - FINAL SILENCIOSO
            // No se muestra TaskDialog al terminar correctamente.
            // La ventana de elementos se restaura automáticamente.
            //-------------------------------------------------
            MostrarFormulario();
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            MostrarFormulario();
        }
        catch (Exception ex)
        {
            TaskDialog.Show(
                "MYG - Error",
                "Ocurrió un error al crear tarrajeo en cimentación:\n\n" + ex.Message);

            MostrarFormulario();
        }
        finally
        {
            TarrajeoVistaActivaUnionesHelper
                .RestaurarUnionesOcultasInvertidas(
                    doc,
                    unionesOcultasInvertidas);
        }
    }

    // =====================================
    // V18 - OBTENER CARAS VÁLIDAS EN MODELO
    // Soporta PlanarFace y CylindricalFace.
    // Las transformaciones del vínculo / instancia se hornean en la geometría,
    // por eso las caras se envían luego al motor común con Transform.Identity.
    // =====================================
    private List<Face> ObtenerCarasValidasEnModelo(Element elem)
    {
        return ObtenerCarasValidasEnModelo(elem, Transform.Identity);
    }

    private List<Face> ObtenerCarasValidasEnModelo(Element elem, Transform transformBase)
    {
        List<Face> caras = new List<Face>();
        HashSet<string> keys = new HashSet<string>();

        Options opt = new Options()
        {
            ComputeReferences = false,
            IncludeNonVisibleObjects = true,
            DetailLevel = ViewDetailLevel.Fine
        };

        GeometryElement geo = null;

        try
        {
            geo = elem.get_Geometry(opt);
        }
        catch
        {
            geo = null;
        }

        if (geo == null)
            return caras;

        ExtraerCarasValidas(
            geo,
            transformBase ?? Transform.Identity,
            caras,
            keys);

        return caras;
    }

    private void ExtraerCarasValidas(
        GeometryElement geo,
        Transform transformActual,
        List<Face> caras,
        HashSet<string> keys)
    {
        if (geo == null)
            return;

        foreach (GeometryObject obj in geo)
        {
            Solid solid = obj as Solid;

            if (solid != null)
            {
                ProcesarSolido(
                    solid,
                    transformActual,
                    caras,
                    keys);

                continue;
            }

            GeometryInstance gi = obj as GeometryInstance;

            if (gi == null)
                continue;

            try
            {
                GeometryElement symbolGeo = gi.GetSymbolGeometry();

                if (symbolGeo != null)
                {
                    Transform nuevoTransform =
                        (transformActual ?? Transform.Identity).Multiply(gi.Transform);

                    ExtraerCarasValidas(
                        symbolGeo,
                        nuevoTransform,
                        caras,
                        keys);
                }
            }
            catch
            {
                try
                {
                    GeometryElement instanceGeo = gi.GetInstanceGeometry();

                    if (instanceGeo != null)
                    {
                        ExtraerCarasValidas(
                            instanceGeo,
                            transformActual ?? Transform.Identity,
                            caras,
                            keys);
                    }
                }
                catch
                {
                }
            }
        }
    }

    private void ProcesarSolido(
        Solid solid,
        Transform transformActual,
        List<Face> caras,
        HashSet<string> keys)
    {
        if (solid == null)
            return;

        if (solid.Faces == null || solid.Faces.Size == 0)
            return;

        if (solid.Edges == null || solid.Edges.Size == 0)
            return;

        Solid solidModelo = solid;

        try
        {
            if (transformActual != null && !transformActual.IsIdentity)
                solidModelo = SolidUtils.CreateTransformed(solid, transformActual);
        }
        catch
        {
            // Si no se pudo llevar el sólido al modelo activo, sus caras
            // siguen en coordenadas locales. No enviarlas con Transform.Identity.
            return;
        }

        if (solidModelo == null)
            return;

        foreach (Face face in solidModelo.Faces)
        {
            if (face == null)
                continue;

            if (face.Area <= MinAreaCara)
                continue;

            bool esSoportada =
                face is PlanarFace ||
                face is CylindricalFace;

            if (!esSoportada)
                continue;

            string key = BuildFaceKey(face);

            if (!string.IsNullOrWhiteSpace(key))
            {
                if (keys.Contains(key))
                    continue;

                keys.Add(key);
            }

            caras.Add(face);
        }
    }

    private XYZ ObtenerNormalCara(Face face, Transform transformCara)
    {
        if (face == null)
            return null;

        if (transformCara == null)
            transformCara = Transform.Identity;

        try
        {
            PlanarFace pf = face as PlanarFace;

            if (pf != null)
                return transformCara.OfVector(pf.FaceNormal).Normalize();

            BoundingBoxUV bb = face.GetBoundingBox();

            if (bb != null)
            {
                UV uv = new UV(
                    (bb.Min.U + bb.Max.U) / 2.0,
                    (bb.Min.V + bb.Max.V) / 2.0);

                XYZ n = face.ComputeNormal(uv);

                if (n != null && n.GetLength() > 1e-9)
                    return transformCara.OfVector(n).Normalize();
            }
        }
        catch
        {
        }

        return null;
    }

    private XYZ ObtenerPuntoReferenciaFace(Face face)
    {
        if (face == null)
            return XYZ.Zero;

        try
        {
            IList<CurveLoop> loops = face.GetEdgesAsCurveLoops();

            if (loops != null)
            {
                foreach (CurveLoop loop in loops)
                {
                    foreach (Curve c in loop)
                    {
                        if (c != null)
                            return c.GetEndPoint(0);
                    }
                }
            }
        }
        catch
        {
        }

        try
        {
            BoundingBoxUV bb = face.GetBoundingBox();

            if (bb != null)
            {
                UV uv = new UV(
                    (bb.Min.U + bb.Max.U) / 2.0,
                    (bb.Min.V + bb.Max.V) / 2.0);

                return face.Evaluate(uv);
            }
        }
        catch
        {
        }

        return XYZ.Zero;
    }

    private string BuildFaceKey(Face face)
    {
        try
        {
            XYZ n = ObtenerNormalCara(face, Transform.Identity);
            XYZ p = ObtenerPuntoReferenciaFace(face);

            if (n == null)
                return null;

            string tipo = face.GetType().Name;

            return tipo + "|" +
                   Math.Round(n.X, 6) + "|" +
                   Math.Round(n.Y, 6) + "|" +
                   Math.Round(n.Z, 6) + "|" +
                   Math.Round(p.X, 6) + "|" +
                   Math.Round(p.Y, 6) + "|" +
                   Math.Round(p.Z, 6) + "|" +
                   Math.Round(face.Area, 6);
        }
        catch
        {
            return null;
        }
    }


    // =====================================
    // V15 - OBTENER ELEMENTOS NATIVOS O DE VÍNCULOS
    // =====================================
    private List<ElementoTrabajo> ObtenerElementosTrabajo(Document doc, IList<Reference> refs)
    {
        List<ElementoTrabajo> resultado = new List<ElementoTrabajo>();

        if (doc == null || refs == null)
            return resultado;

        foreach (Reference r in refs)
        {
            if (r == null)
                continue;

            Element elem = doc.GetElement(r.ElementId);

            if (elem == null)
                continue;

            RevitLinkInstance link = elem as RevitLinkInstance;

            if (link != null)
            {
                if (!ConsiderarVinculos)
                    continue;

                Document linkDoc = null;

                try
                {
                    linkDoc = link.GetLinkDocument();
                }
                catch
                {
                    linkDoc = null;
                }

                if (linkDoc == null)
                    continue;

                ElementId linkedId = r.LinkedElementId;

                if (linkedId == ElementId.InvalidElementId)
                    continue;

                Element linkedElem = linkDoc.GetElement(linkedId);

                if (linkedElem == null)
                    continue;

                if (!CategoriaValida(linkedElem))
                    continue;

                Transform tr = Transform.Identity;

                try
                {
                    tr = link.GetTotalTransform();
                }
                catch
                {
                    tr = Transform.Identity;
                }

                resultado.Add(new ElementoTrabajo()
                {
                    HostElem = link,
                    GeoElem = linkedElem,
                    TransformCara = tr
                });

                continue;
            }

            if (!CategoriaValida(elem))
                continue;

            resultado.Add(new ElementoTrabajo()
            {
                HostElem = elem,
                GeoElem = elem,
                TransformCara = Transform.Identity
            });
        }

        return resultado;
    }

    private bool CategoriaValida(Element elem)
    {
        if (elem == null)
            return false;

        Category cat = null;

        try
        {
            cat = elem.Category;
        }
        catch
        {
            cat = null;
        }

        if (cat == null)
            return false;

        return cat.Id.Equals(new ElementId(BuiltInCategory.OST_StructuralFoundation));
    }

    private void MostrarFormulario()
    {
        try
        {
            if (Form != null && !Form.IsDisposed)
            {
                Form.RestaurarVentana();
                return;
            }
        }
        catch
        {
        }

        try
        {
            if (Form != null && !Form.IsDisposed)
            {
                Form.Show();
                Form.BringToFront();
                Form.Activate();
            }
        }
        catch
        {
        }
    }

    public string GetName()
    {
        return "MYG - Seleccionar Cimentación para Tarrajeo";
    }
}


// =====================================
// FILTRO - SOLO CIMENTACIÓN ESTRUCTURAL
// =====================================
public class CimentacionTarrajeoSelectionFilter : ISelectionFilter
{
    private readonly Document _doc;
    private readonly bool _considerarVinculos;

    public CimentacionTarrajeoSelectionFilter() : this(null, false)
    {
    }

    public CimentacionTarrajeoSelectionFilter(bool considerarVinculos) : this(null, considerarVinculos)
    {
    }

    public CimentacionTarrajeoSelectionFilter(Document doc, bool considerarVinculos)
    {
        _doc = doc;
        _considerarVinculos = considerarVinculos;
    }

    public bool AllowElement(Element elem)
    {
        if (elem == null)
            return false;

        //-------------------------------------------------
        // Si se está seleccionando en vínculo, Revit primero
        // pasa el RevitLinkInstance por AllowElement.
        // Aquí se permite solo para que luego AllowReference
        // valide la categoría REAL del elemento vinculado.
        //-------------------------------------------------
        if (_considerarVinculos && elem is RevitLinkInstance)
            return true;

        return EsCategoriaPermitida(elem);
    }

    public bool AllowReference(Reference reference, XYZ position)
    {
        //-------------------------------------------------
        // Para elementos nativos, AllowElement ya filtró.
        //-------------------------------------------------
        if (!_considerarVinculos)
            return true;

        if (_doc == null || reference == null)
            return false;

        try
        {
            RevitLinkInstance link = _doc.GetElement(reference.ElementId) as RevitLinkInstance;

            if (link == null)
                return true;

            ElementId linkedId = reference.LinkedElementId;

            if (linkedId == ElementId.InvalidElementId)
                return false;

            Document linkDoc = link.GetLinkDocument();

            if (linkDoc == null)
                return false;

            Element linkedElem = linkDoc.GetElement(linkedId);

            return EsCategoriaPermitida(linkedElem);
        }
        catch
        {
            return false;
        }
    }

    private bool EsCategoriaPermitida(Element elem)
    {
        if (elem == null)
            return false;

        if (elem.Category == null)
            return false;

        return elem.Category.Id.Equals(new ElementId(BuiltInCategory.OST_StructuralFoundation));
    }
}