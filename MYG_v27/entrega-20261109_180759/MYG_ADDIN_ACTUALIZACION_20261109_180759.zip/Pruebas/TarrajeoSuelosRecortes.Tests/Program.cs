using System.Collections;
using System.Reflection;
using System.Runtime.Loader;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

string FindRoot(string start)
{
    for (var folder = new DirectoryInfo(start); folder != null; folder = folder.Parent)
        if (File.Exists(Path.Combine(folder.FullName, "MYG", "MYG.csproj"))) return folder.FullName;
    throw new Exception("Run from a repository containing MYG/MYG.csproj.");
}
string path = Path.Combine(FindRoot(AppContext.BaseDirectory), "MYG", "Funcionalidades", "Estructuras", "Tarrajeo", "Tarrajeo_SuelosHandler.cs");
var syntax = CSharpSyntaxTree.ParseText(File.ReadAllText(path)).GetRoot();
MethodDeclarationSyntax Method(string name) => syntax.DescendantNodes().OfType<MethodDeclarationSyntax>().Single(x => x.Identifier.ValueText == name);
string adapter = "using System; using System.Collections.Generic; public class ProjectionAdapter { " +
    Method("ProjectPointToPlane").ToFullString() + Method("ProyectarContornoDeCortante").ToFullString() +
    "public CurveLoop Project(CurveLoop loop, Plane plane, double tolerance) => ProyectarContornoDeCortante(loop, plane, tolerance); }";
var references = ((string)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES")!).Split(Path.PathSeparator)
    .Select(p => MetadataReference.CreateFromFile(p)).ToList();
references.Add(MetadataReference.CreateFromFile(Assembly.GetExecutingAssembly().Location));
var compilation = CSharpCompilation.Create("ActualFloorProjection_" + Guid.NewGuid().ToString("N"),
    new[] { CSharpSyntaxTree.ParseText(adapter) }, references,
    new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
using var stream = new MemoryStream();
var emitted = compilation.Emit(stream);
if (!emitted.Success) throw new Exception(string.Join("\n", emitted.Diagnostics));
stream.Position = 0;
var type = AssemblyLoadContext.Default.LoadFromStream(stream).GetType("ProjectionAdapter")!;
var instance = Activator.CreateInstance(type);
var project = type.GetMethod("Project")!;
CurveLoop Project(CurveLoop loop, Plane plane, double tolerance = 0.001)
    => (CurveLoop)project.Invoke(instance, new object[] { loop, plane, tolerance })!;
CurveLoop Polygon(params XYZ[] points)
{
    var loop = new CurveLoop();
    for (int i = 0; i < points.Length; i++) loop.Append(Line.CreateBound(points[i], points[(i + 1) % points.Length]));
    return loop;
}
double Area(CurveLoop loop)
{
    var points = loop.Select(x => x.GetEndPoint(0)).ToList();
    double sum = 0;
    for (int i = 0; i < points.Count; i++) sum += points[i].X * points[(i + 1) % points.Count].Y - points[(i + 1) % points.Count].X * points[i].Y;
    return Math.Abs(sum) / 2;
}
int passed = 0;
void Check(string name, bool valid) { if (!valid) throw new Exception(name); Console.WriteLine("PASS " + name); passed++; }
var horizontal = new Plane(new XYZ(0, 0, 1), new XYZ(0, 0, 0));
var rectangle = Polygon(new XYZ(0,0,0),new XYZ(2,0,1),new XYZ(2,2,1),new XYZ(0,2,0));
var result = Project(rectangle,horizontal);
Check("Oblique rectangular footprint projects every vertex to target plane", result.All(c => Math.Abs(c.GetEndPoint(0).Z) < 1e-12));
Check("Projected rectangular footprint keeps physical XY size", Math.Abs(Area(result)-4)<1e-12);
var concave=Polygon(new XYZ(0,0,0),new XYZ(2,0,1),new XYZ(2,1,1),new XYZ(1,1,.5),new XYZ(1,2,.5),new XYZ(0,2,0));
var concaveResult=Project(concave,horizontal);
Check("Concave footprint is not replaced with convex hull or box",concaveResult.Count()==6 && Math.Abs(Area(concaveResult)-3)<1e-12);
var reversePlane=new Plane(new XYZ(0,0,-1),new XYZ(0,0,3));
var reverse=Project(rectangle,reversePlane);
Check("Downward floor normal preserves projected XY and target Z", Math.Abs(Area(reverse)-4)<1e-12 && reverse.All(c=>Math.Abs(c.GetEndPoint(0).Z-3)<1e-12));
var divided=Polygon(new XYZ(0,0,0),new XYZ(1,0,.5),new XYZ(2,0,1),new XYZ(2,2,1),new XYZ(0,2,0));
Check("Only collinear edge subdivisions are removed",Project(divided,horizontal).Count()==4);
var hole=Polygon(new XYZ(.5,.5,.25),new XYZ(1.5,.5,.75),new XYZ(1.5,1.5,.75),new XYZ(.5,1.5,.25));
Check("Independent hole contour retains its own area",Math.Abs(Area(Project(hole,horizontal))-1)<1e-12);
bool rejected=false;
try { Project(Polygon(new XYZ(0,0,0),new XYZ(.0001,0,0),new XYZ(1,1,.5)),horizontal); }
catch(TargetInvocationException ex) when(ex.InnerException is InvalidOperationException){rejected=true;}
Check("Unrepresentable short projected edge rejects instead of restoring original",rejected);
var offsetPlane=new Plane(new XYZ(0,0,1),new XYZ(0,0,25));
Check("Changing target elevation preserves XY footprint",Math.Abs(Area(Project(concave,offsetPlane))-3)<1e-12);
var clip=Method("CrearPrismasDeHuellaDeInterseccion");
var faceLoop=clip.DescendantNodes().OfType<ForEachStatementSyntax>().First(x=>x.Identifier.ValueText=="cara");
Check("Planar face loop catalog is scoped inside each physical face",faceLoop.DescendantNodes().OfType<VariableDeclaratorSyntax>().Any(x=>x.Identifier.ValueText=="proyectados"));
Check("Curved cutters use triangle projection rather than a convex footprint",clip.DescendantNodes().OfType<InvocationExpressionSyntax>().Any(x=>x.Expression is MemberAccessExpressionSyntax m&&m.Name.Identifier.ValueText=="Triangulate"));
var create=Method("CrearSueloDesdeCaraPlanarProcesada");
Check("Cutting domain uses actual floor thickness",create.DescendantNodes().OfType<VariableDeclaratorSyntax>().Any(x=>x.Identifier.ValueText=="profundidad"&&x.Initializer?.Value is IdentifierNameSyntax n&&n.Identifier.ValueText=="espesor"));
Console.WriteLine($"{passed}/{passed} floor projection/source checks passed. Geometry types are test doubles; no Revit boolean, Windows or model test was performed.");

// Minimal vector/curve doubles exercise the extracted production projection
// algorithm only. They do not emulate Autodesk solids or certify Revit output.
public class XYZ(double x,double y,double z)
{
    public double X=x,Y=y,Z=z;
    public static XYZ operator-(XYZ a,XYZ b)=>new(a.X-b.X,a.Y-b.Y,a.Z-b.Z);
    public double DotProduct(XYZ b)=>X*b.X+Y*b.Y+Z*b.Z;
    public XYZ CrossProduct(XYZ b)=>new(Y*b.Z-Z*b.Y,Z*b.X-X*b.Z,X*b.Y-Y*b.X);
    public XYZ Multiply(double factor)=>new(X*factor,Y*factor,Z*factor);
    public double GetLength()=>Math.Sqrt(DotProduct(this));
    public double DistanceTo(XYZ b)=>(this-b).GetLength();
}
public class Plane(XYZ normal,XYZ origin) { public XYZ Normal=normal,Origin=origin; }
public abstract class Curve { public abstract XYZ GetEndPoint(int index); public virtual IList<XYZ> Tessellate()=>new List<XYZ>{GetEndPoint(0),GetEndPoint(1)}; }
public class Line(XYZ start,XYZ end):Curve
{
    public static Line CreateBound(XYZ start,XYZ end)=>new(start,end);
    public override XYZ GetEndPoint(int index)=>index==0?start:end;
}
public class CurveLoop:IEnumerable<Curve>
{
    private readonly List<Curve> curves=new();
    public void Append(Curve curve)=>curves.Add(curve);
    public IEnumerator<Curve> GetEnumerator()=>curves.GetEnumerator();
    IEnumerator IEnumerable.GetEnumerator()=>GetEnumerator();
}
