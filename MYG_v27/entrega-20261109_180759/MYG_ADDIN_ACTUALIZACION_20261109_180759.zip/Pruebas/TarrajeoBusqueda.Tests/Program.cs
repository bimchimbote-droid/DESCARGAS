using System.Reflection;
using System.Runtime.Loader;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using WinForms = System.Windows.Forms;

// Compile the two production helper declarations unchanged, isolating only their
// WinForms dependency. These checks do not certify the native Windows controls.
var folder = new DirectoryInfo(AppContext.BaseDirectory);
while (folder != null && !File.Exists(Path.Combine(folder.FullName, "MYG", "MYG.csproj")))
    folder = folder.Parent;
if (folder == null) throw new Exception("Run these checks from the installed repository.");
var file = Path.Combine(folder.FullName, "MYG", "Funcionalidades", "Estructuras", "Tarrajeo", "TarrajeoForm.cs");
var syntax = CSharpSyntaxTree.ParseText(File.ReadAllText(file));
var declarations = syntax.GetRoot().DescendantNodes().OfType<ClassDeclarationSyntax>()
    .Where(c => c.Identifier.ValueText is "CatalogoTiposTarrajeo" or "FiltroComboTarrajeo").ToArray();
if (declarations.Length != 2) throw new Exception("Production search helpers were not found.");
var source = "using System; using System.Linq; using System.Collections.Generic; using System.Globalization; " +
    "using WinForms = System.Windows.Forms; namespace MYG_Addin {\n" +
    string.Join("\n", declarations.Select(c => c.ToFullString())) + "\n}";
var references = ((string)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES")!).Split(Path.PathSeparator)
    .Select(p => MetadataReference.CreateFromFile(p)).ToList();
references.Add(MetadataReference.CreateFromFile(Assembly.GetExecutingAssembly().Location));
var compilation = CSharpCompilation.Create("ProductionSearchHelpers", new[] { CSharpSyntaxTree.ParseText(source) },
    references, new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
using var output = new MemoryStream();
var emitted = compilation.Emit(output);
if (!emitted.Success) throw new Exception(string.Join("\n", emitted.Diagnostics));
output.Position = 0;
var assembly = AssemblyLoadContext.Default.LoadFromStream(output);
var configure = assembly.GetType("MYG_Addin.FiltroComboTarrajeo")!
    .GetMethod("Configurar", BindingFlags.Static | BindingFlags.NonPublic)!;
int passed = 0;
void Check(string name, bool value)
{
    if (!value) throw new Exception("FAIL " + name);
    Console.WriteLine("PASS " + name);
    passed++;
}
var types = new[] {
    new Tipo("FLR_Tarrajeo en vigas"), new Tipo("WLL_Tarrajeo en VIGAS"),
    new Tipo("WLL_Encofrado cimentación"), new Tipo("FLR_Tarrajeo losa")
};
var combo = new WinForms.ComboBox();
var window = new WinForms.Form();
configure.Invoke(null, new object[] { combo, window });
// Match the real command: types are loaded after constructing the form/helper.
combo.Items.AddRange(types.Cast<object>().ToArray());
combo.SelectedIndex = 0;
window.RaiseLoad();
Check("Types loaded after the constructor are captured", combo.Items.Count == 4 && ReferenceEquals(combo.SelectedItem, types[0]));
Check("Search control is editable with native autocomplete disabled", combo.DropDownStyle == WinForms.ComboBoxStyle.DropDown && combo.AutoCompleteMode == WinForms.AutoCompleteMode.None);
combo.TypeText("vigas", 2, 1);
Check("Partial text filters the real item list", combo.Items.Count == 2);
Check("Filtering retains the typed text and caret", combo.Text == "vigas" && combo.SelectionStart == 2 && combo.SelectionLength == 1);
Check("Partial query clears the previous selection", combo.SelectedItem == null);
Check("Search results retain original type objects", ReferenceEquals(combo.Items[0], types[0]) && ReferenceEquals(combo.Items[1], types[1]));
combo.TypeText("CIMENTACION");
Check("Matching ignores case and accents", combo.Items.Count == 1 && ReferenceEquals(combo.Items[0], types[2]));
combo.TypeText("no-existe");
Check("No match leaves no selectable stale result", combo.Items.Count == 0 && combo.SelectedItem == null && combo.Text == "no-existe");
combo.Press(WinForms.Keys.Enter);
Check("Enter cannot select a nonexistent result", combo.SelectedItem == null);
combo.TypeText("");
Check("Clearing search restores the complete catalog", combo.Items.Count == 4 && combo.Text == "");
combo.TypeText("losa");
combo.Press(WinForms.Keys.Enter);
Check("Enter confirms a real matching type", ReferenceEquals(combo.SelectedItem, types[3]) && !combo.DroppedDown);
combo.TypeText("vig");
combo.Press(WinForms.Keys.Escape);
Check("Escape restores the previously confirmed type and full catalog", ReferenceEquals(combo.SelectedItem, types[3]) && combo.Items.Count == 4 && combo.Text == types[3].ToString());
combo.TypeText("encofrado");
combo.Commit(0);
Check("Mouse selection commits a real filtered result", ReferenceEquals(combo.SelectedItem, types[2]));
combo.TypeText("vigas");
window.RaiseLoad();
combo.TypeText("");
Check("Restoring the window does not replace the original catalog with filtered items", combo.Items.Count == 4);
combo.TypeText("losa");
combo.Press(WinForms.Keys.A, control: true);
Check("Ctrl+A selects the entire query for replacement", combo.SelectionStart == 0 && combo.SelectionLength == 4);
combo.TypeText(types[1].ToString());
Check("An exact typed name resolves to its real type", ReferenceEquals(combo.SelectedItem, types[1]));
var empty = new WinForms.ComboBox();
var emptyWindow = new WinForms.Form();
configure.Invoke(null, new object[] { empty, emptyWindow });
emptyWindow.RaiseLoad();
empty.TypeText("x");
empty.Press(WinForms.Keys.Enter);
empty.Press(WinForms.Keys.Escape);
Check("An empty catalog remains safe while typing and confirming", empty.Items.Count == 0 && empty.SelectedItem == null);
Console.WriteLine($"{passed}/{passed} isolated search checks passed. Native WinForms/Revit interaction remains untested.");

sealed class Tipo(string name)
{
    public override string ToString() => name;
}

// Test doubles model edit/selection events only, not a native Windows UI.
namespace System.Windows.Forms
{
    public enum ComboBoxStyle { DropDownList, DropDown }
    public enum AutoCompleteMode { None }
    public enum AutoCompleteSource { None }
    public enum Keys { A, Enter, Escape }
    public sealed class KeyEventArgs(Keys key, bool control = false) : EventArgs
    {
        public Keys KeyCode { get; } = key;
        public bool Control { get; } = control;
        public bool Handled { get; set; }
        public bool SuppressKeyPress { get; set; }
    }
    public sealed class ObjectCollection : List<object>
    {
        public void AddRange(object[] items) => base.AddRange(items);
    }
    public sealed class Form
    {
        public event EventHandler? Load;
        public void RaiseLoad() => Load?.Invoke(this, EventArgs.Empty);
    }
    public sealed class ComboBox
    {
        private string _text = "";
        private int _index = -1;
        public ObjectCollection Items { get; } = new();
        public ComboBoxStyle DropDownStyle { get; set; }
        public AutoCompleteMode AutoCompleteMode { get; set; }
        public AutoCompleteSource AutoCompleteSource { get; set; }
        public bool IsHandleCreated => true;
        public bool Visible => true;
        public bool Focused => true;
        public bool DroppedDown { get; set; }
        public int SelectionStart { get; set; }
        public int SelectionLength { get; set; }
        public int SelectedIndex
        {
            get => _index;
            set { _index = value; _text = value >= 0 ? GetItemText(Items[value]) : ""; }
        }
        public object? SelectedItem
        {
            get => _index >= 0 && _index < Items.Count ? Items[_index] : null;
            set => SelectedIndex = value == null ? -1 : Items.IndexOf(value);
        }
        public string Text
        {
            get => _text;
            set { _text = value; _index = Items.FindIndex(item => GetItemText(item) == value); }
        }
        public event EventHandler? TextUpdate;
        public event EventHandler<KeyEventArgs>? KeyDown;
        public event EventHandler? SelectionChangeCommitted;
        public event EventHandler? Leave;
        public string GetItemText(object item) => item.ToString() ?? "";
        public void BeginUpdate() { }
        public void EndUpdate() { }
        public void Select(int start, int length) { SelectionStart = start; SelectionLength = length; }
        public void TypeText(string text, int? start = null, int length = 0)
        {
            _text = text;
            SelectionStart = start ?? text.Length;
            SelectionLength = length;
            TextUpdate?.Invoke(this, EventArgs.Empty);
        }
        public void Press(Keys key, bool control = false) => KeyDown?.Invoke(this, new KeyEventArgs(key, control));
        public void Commit(int index) { SelectedIndex = index; SelectionChangeCommitted?.Invoke(this, EventArgs.Empty); }
        public void LoseFocus() => Leave?.Invoke(this, EventArgs.Empty);
    }
}
