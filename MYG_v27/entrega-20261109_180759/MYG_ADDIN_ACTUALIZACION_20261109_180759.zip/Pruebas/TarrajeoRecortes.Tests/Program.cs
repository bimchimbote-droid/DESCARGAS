using System.Reflection;
using System.Runtime.Loader;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using GeometryDoubles;

// Execute the unchanged production methods against explicit geometry doubles.
// This validates search depth and projection orchestration, not Autodesk booleans.
var folder = new DirectoryInfo(AppContext.BaseDirectory);
while (folder != null && !File.Exists(Path.Combine(folder.FullName, "MYG", "MYG.csproj"))) folder = folder.Parent;
if (folder == null) throw new Exception("Run these checks from the installed repository.");
var production = Path.Combine(folder.FullName, "MYG", "Funcionalidades", "Estructuras", "Tarrajeo", "Tarrajeo_MurosHandler.cs");
var syntax = CSharpSyntaxTree.ParseText(File.ReadAllText(production));
var names = new[] { "CrearSondaNormalDesdeComponente", "ObtenerSeccionesProyectadasDeInterseccion" };
var methods = syntax.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>()
    .Where(m => names.Contains(m.Identifier.ValueText)).ToArray();
if (methods.Length != 2) throw new Exception("Expected production cut methods were not found.");
var wrapper = """
using System;
using System.Linq;
using System.Collections.Generic;
using GeometryDoubles;
public class ProductionCuts
{
    private const double TOL = 1e-6;
    public readonly List<int> ClassificationCounts = new List<int>();
    public Solid Probe(LoopMuro ext, List<LoopMuro> holes, XYZ normal, double thickness)
        => CrearSondaNormalDesdeComponente(ext, holes, normal, thickness);
    public List<ComponenteMuro> Sections(Solid intersection, MarcoMuro frame, XYZ normal)
        => ObtenerSeccionesProyectadasDeInterseccion(intersection, frame, normal);
    private bool LoopSeguro(LoopMuro loop) => loop != null && loop.Points.Count >= 3;
    private CurveLoop CurveLoopDesdeLoop(LoopMuro loop, bool outer, Transform transform)
        => new CurveLoop(loop.Points.Select(transform.OfPoint).ToList());
    private LoopMuro LoopDesdeCurveLoop(CurveLoop loop, Transform transform, MarcoMuro frame)
        => new LoopMuro(loop.Points.Select(p => frame.Project(transform.OfPoint(p))).ToList());
    private LoopMuro LoopDesdePuntosPlanos(IList<XYZ> points, MarcoMuro frame)
        => new LoopMuro(points.Select(frame.Project).ToList());
    private List<ComponenteMuro> ClasificarComponentes(List<LoopMuro> loops)
    {
        ClassificationCounts.Add(loops.Count);
        return new List<ComponenteMuro> { new ComponenteMuro { Exterior = loops[0], Huecos = loops.Skip(1).ToList() } };
    }
""" + string.Join("\n", methods.Select(m => m.ToFullString())) + "\n}";
var references = ((string)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES")!).Split(Path.PathSeparator)
    .Select(p => MetadataReference.CreateFromFile(p)).ToList();
references.Add(MetadataReference.CreateFromFile(Assembly.GetExecutingAssembly().Location));
var compilation = CSharpCompilation.Create("ActualProductionCutMethods", new[] { CSharpSyntaxTree.ParseText(wrapper) }, references,
    new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
using var output = new MemoryStream();
var result = compilation.Emit(output);
if (!result.Success) throw new Exception(string.Join("\n", result.Diagnostics));
output.Position = 0;
var assembly = AssemblyLoadContext.Default.LoadFromStream(output);
var type = assembly.GetType("ProductionCuts")!;
var instance = Activator.CreateInstance(type)!;
var probeMethod = type.GetMethod("Probe")!;
var sectionsMethod = type.GetMethod("Sections")!;
Solid? Probe(LoopMuro ext, List<LoopMuro> holes, double thickness) =>
    (Solid?)probeMethod.Invoke(instance, new object[] { ext, holes, new XYZ(1, 0, 0), thickness });
List<ComponenteMuro> Sections(Solid solid, MarcoMuro frame) =>
    (List<ComponenteMuro>)sectionsMethod.Invoke(instance, new object[] { solid, frame, new XYZ(1, 0, 0) })!;
int passed = 0;
void Check(string name, bool condition)
{
    if (!condition) throw new Exception("FAIL " + name);
    Console.WriteLine("PASS " + name);
    passed++;
}
static List<XYZ> Rectangle(double x, double y0 = 0, double y1 = 2, double z0 = 0, double z1 = 2) =>
    new() { new(x, y0, z0), new(x, y1, z0), new(x, y1, z1), new(x, y0, z1) };
static bool Overlap(double a0, double a1, double b0, double b1) => Math.Min(a1, b1) - Math.Max(a0, b0) > 1e-10;
const double mm = 1 / 304.8;
var thickness = 15 * mm;
var frame = new MarcoMuro(new XYZ(thickness / 2, 0, 0), new XYZ(1, 0, 0));
var exterior = new LoopMuro(Rectangle(thickness / 2));
var probe = Probe(exterior, new(), thickness)!;
Check("Probe starts on the physical host face", Math.Abs(probe.Profiles[0].Points[0].X) < 1e-12);
Check("Probe spans the complete 15 mm finish thickness", Math.Abs(probe.Depth - thickness) < 1e-12);
Check("Interference at 5 to 12 mm falls inside the real probe", Overlap(0, probe.Depth, 5 * mm, 12 * mm));
Check("Volume only behind the face does not overlap", !Overlap(0, probe.Depth, -10 * mm, 0));
Check("A contact at the outer finish face has no positive volume", !Overlap(0, probe.Depth, 15 * mm, 17 * mm));
Check("A solid outside the finish is excluded", !Overlap(0, probe.Depth, 15.1 * mm, 20 * mm));
var thin = Probe(new LoopMuro(Rectangle(0.25 * mm)), new(), 0.5 * mm)!;
Check("A thin finish is not enlarged to a minimum probe depth", Math.Abs(thin.Depth - 0.5 * mm) < 1e-12);
var hole = new LoopMuro(Rectangle(thickness / 2, 0.5, 1, 0.5, 1));
Check("Physical probe retains the host face opening", Probe(exterior, new() { hole }, thickness)!.Profiles.Count == 2);
Check("Nonpositive thickness does not create a probe", Probe(exterior, new(), 0) == null);

// These doubles preserve supplied polygon loops; they do not implement Revit's
// classification/triangulation. The actual method must keep each face separate.
var lShape = new List<XYZ> { new(3 * mm, 0, 0), new(3 * mm, 3, 0), new(3 * mm, 3, 1), new(3 * mm, 1, 1), new(3 * mm, 1, 3), new(3 * mm, 0, 3) };
var faceA = new PlanarFace(new XYZ(1, 0, 0), new() { new CurveLoop(lShape), new CurveLoop(Rectangle(3 * mm, .2, .7, .2, .7)) });
var faceB = new PlanarFace(new XYZ(-1, 0, 0), new() { new CurveLoop(Rectangle(12 * mm, 10, 12, 0, 2)) });
var sections = Sections(new Solid { Faces = new() { faceA, faceB } }, frame);
Check("Faces at different depths are classified separately", sections.Count == 2 && ((List<int>)type.GetField("ClassificationCounts")!.GetValue(instance)!).SequenceEqual(new[] { 2, 1 }));
Check("A planar L shape retains its concave vertices", sections[0].Exterior.Points.Count == 6);
Check("An opening remains attached to its own projected face", sections[0].Huecos.Count == 1 && sections[1].Huecos.Count == 0);
Check("Separate islands are not bridged by a convex hull", sections[0].Exterior.Points.Max(p => p.Y) < sections[1].Exterior.Points.Min(p => p.Y));
Check("Projected loops lie on the finish creation plane", sections.SelectMany(s => s.Exterior.Points).All(p => Math.Abs(p.X - frame.Origin.X) < 1e-12));
var curve = new CurvedFace(new Mesh(new() {
    new(new XYZ(5*mm,0,0),new XYZ(6*mm,1,0),new XYZ(7*mm,0,1)),
    new(new XYZ(5*mm,8,0),new XYZ(6*mm,9,0),new XYZ(7*mm,8,1)),
    new(new XYZ(5*mm,0,0),new XYZ(6*mm,0,0),new XYZ(7*mm,0,0))
}));
var triangles = Sections(new Solid { Faces = new() { curve } }, frame);
Check("Curved-face triangles remain independent projected patches", triangles.Count == 2 && triangles.All(s => s.Exterior.Points.Count == 3));
Check("Degenerate projected triangles are ignored", triangles.Count == curve.Triangulate().NumTriangles - 1);
var edgeOn = Sections(new Solid { Faces = new() { new PlanarFace(new XYZ(0, 1, 0), new() { new CurveLoop(Rectangle(0)) }) } }, frame);
Check("Edge-on planar faces add no projected area", edgeOn.Count == 0);
Console.WriteLine($"{passed}/{passed} isolated production-method checks passed. Geometry, loops and triangulation are doubles; real Revit booleans and model behavior remain untested.");

namespace GeometryDoubles
{
    public sealed class XYZ(double x, double y, double z)
    {
        public double X = x, Y = y, Z = z;
        public double GetLength() => Math.Sqrt(X * X + Y * Y + Z * Z);
        public XYZ Normalize() => Multiply(1 / GetLength());
        public XYZ Multiply(double factor) => new(X * factor, Y * factor, Z * factor);
        public double DotProduct(XYZ other) => X * other.X + Y * other.Y + Z * other.Z;
        public XYZ CrossProduct(XYZ o) => new(Y * o.Z - Z * o.Y, Z * o.X - X * o.Z, X * o.Y - Y * o.X);
        public static XYZ operator -(XYZ a, XYZ b) => new(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
        public static XYZ operator +(XYZ a, XYZ b) => new(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
    }
    public sealed class Transform(XYZ translation)
    {
        public static Transform Identity => new(new XYZ(0, 0, 0));
        public static Transform CreateTranslation(XYZ translation) => new(translation);
        public XYZ OfPoint(XYZ point) => point + translation;
    }
    public sealed class CurveLoop(List<XYZ> points)
    {
        public List<XYZ> Points = points;
        public bool IsOpen() => false;
    }
    public sealed class LoopMuro(List<XYZ> points) { public List<XYZ> Points = points; }
    public sealed class MarcoMuro(XYZ origin, XYZ normal)
    {
        public XYZ Origin = origin;
        public XYZ Project(XYZ point) => point - normal.Multiply((point - Origin).DotProduct(normal));
    }
    public sealed class ComponenteMuro
    {
        public LoopMuro Exterior = null!;
        public List<LoopMuro> Huecos = new();
    }
    public class Solid
    {
        public List<Face> Faces = new();
        public List<CurveLoop> Profiles = new();
        public double Depth;
    }
    public abstract class Face { public abstract Mesh Triangulate(); }
    public sealed class PlanarFace(XYZ normal, List<CurveLoop> loops) : Face
    {
        public XYZ FaceNormal = normal;
        public List<CurveLoop> GetEdgesAsCurveLoops() => loops;
        public override Mesh Triangulate() => throw new Exception("Valid planar contours should not be triangulated");
    }
    public sealed class CurvedFace(Mesh mesh) : Face { public override Mesh Triangulate() => mesh; }
    public sealed class Mesh(List<MeshTriangle> triangles)
    {
        public int NumTriangles => triangles.Count;
        public MeshTriangle get_Triangle(int index) => triangles[index];
    }
    public sealed class MeshTriangle(XYZ a, XYZ b, XYZ c)
    {
        public XYZ get_Vertex(int index) => index == 0 ? a : index == 1 ? b : c;
    }
    public static class GeometryCreationUtilities
    {
        public static Solid CreateExtrusionGeometry(List<CurveLoop> profiles, XYZ normal, double depth) =>
            new() { Profiles = profiles, Depth = depth };
    }
}
