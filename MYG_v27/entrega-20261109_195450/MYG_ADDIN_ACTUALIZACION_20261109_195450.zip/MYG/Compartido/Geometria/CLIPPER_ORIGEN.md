# Clipper 6.4.2

Autor: Angus Johnson, 27 February 2017. Boost Software License1.0 (incluida).
Fuente del mirror histórico: https://github.com/skyrpex/clipper/blob/b1f1e1672745c1e1d73dd0437d1643f9633e7508/C%23/clipper_library/clipper.cs
SHA256 original:7706bc0005fbc3ccb152d21ff9429ff4ed3cb0897df0e1bf0406fc52c91f0bd2.
Único cambio local de la biblioteca: namespace ClipperLib → MYG_Addin.RecorteClipper para evitar colisiones. Se conservan copyright, licencia, código y finales de línea del proveedor.
Descargado por HTTPS desde un commit fijo. La descarga oficial histórica de SourceForge no estuvo disponible (HTTP403); el encabezado del código identifica versión/autor/origen. No se instala un paquete NuGet ni se cambian versiones de dependencias existentes.
