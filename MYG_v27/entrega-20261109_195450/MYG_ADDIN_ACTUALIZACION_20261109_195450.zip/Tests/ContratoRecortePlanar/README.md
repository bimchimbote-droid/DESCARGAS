# Contrato semántico entre los handlers de suelos y muros

Prueba enfocada del error CS1061 comunicado. Requiere SDK .NET 10 y las DLL reales de la API de Revit. No añade paquetes NuGet y no debe incorporarse al proyecto del add-in.

Desde la raíz del código:

```sh
python3 Tests/ContratoRecortePlanar/run.py .
```

Por defecto lee los dos handlers en `MYG/Funcionalidades/Estructuras/Tarrajeo/` y las referencias del repositorio en `MYG/%APPDATA%/Autodesk/Revit/Addins/2027/MYG/`. Si las DLL están en una instalación local, añade `--api-dir "C:\Program Files\Autodesk\Revit 2027"`. Se necesitan `RevitAPI.dll` y `RevitAPIUI.dll` de esa misma instalación.

Para contrastar versiones sin reemplazar archivos, se admiten `--wall /ruta/al/archivo.cs` y `--floor /ruta/al/archivo.cs`. La prueba no escribe archivos de producción.

Roslyn analiza los dos archivos completos, obtiene la declaración real de `IntentarRecortarPerfilPlanar` y resuelve semánticamente cada invocación real desde suelos mediante `SemanticModel.GetSymbolInfo`. Comprueba que sea pública, devuelva bool, conserve los doce parámetros existentes, sus tipos, las tres salidas `out` y la tolerancia opcional, y añada al final `IDictionary<Solid,string> origenesCandidatos = null`. La llamada actual de suelos debe pasar el mapa en el argumento 13. También exige que no haya errores semánticos en esa invocación.

Dos pequeñas llamadas de compatibilidad se compilan semánticamente contra la declaración real utilizando los 11 y 12 argumentos antiguos. Así se verifica que los parámetros nuevos continúan siendo opcionales y no rompen otros llamadores. No se sustituye el método por una copia ni se usan dobles de los tipos de API. Esta prueba comprueba el tipo y el paso del mapa; no demuestra que su contenido describa correctamente cada sólido en ejecución.

Un método ausente o una llamada incompatible provoca salida distinta de cero y muestra el diagnóstico. La versión incompatible de la entrega anterior falla con CS1061; la versión acumulada corregida debe terminar con `0 failure(s)`.

**Alcance:** se verifican la firma, el enlace entre esos archivos y la compatibilidad de las llamadas antiguas con metadatos reales. Los diagnósticos ajenos a las invocaciones se excluyen deliberadamente; esta prueba no compila el add-in completo, no valida el motor geométrico ni ejecuta Windows o Revit. Sigue siendo necesaria la compilación de la solución en Visual Studio y la prueba funcional.

El runner crea un proyecto temporal y usa Program.cs de esta entrega; no requiere el Contract.csproj anterior ni modifica la solución. En Windows puedes usar py en lugar de python3.
