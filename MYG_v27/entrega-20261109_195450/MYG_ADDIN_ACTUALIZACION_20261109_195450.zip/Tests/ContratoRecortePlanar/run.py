#!/usr/bin/env python3
"""Run the real contract checker in an isolated temporary SDK project."""
import argparse
from pathlib import Path
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('repository',type=Path)
p.add_argument('--dotnet',default=shutil.which('dotnet'))
a,extra=p.parse_known_args()
if not a.dotnet:p.error('Install SDK .NET10 or specify --dotnet')
source=Path(__file__).resolve().parent/'Program.cs'
with tempfile.TemporaryDirectory(prefix='myg-planar-contract-') as tmp:
    project=ET.Element('Project',Sdk='Microsoft.NET.Sdk')
    props=ET.SubElement(project,'PropertyGroup')
    for name,value in [('OutputType','Exe'),('TargetFramework','net10.0'),('ImplicitUsings','enable'),('Nullable','enable'),('EnableDefaultCompileItems','false')]:
        ET.SubElement(props,name).text=value
    items=ET.SubElement(project,'ItemGroup')
    ET.SubElement(items,'Compile',Include=str(source))
    for name in ['Microsoft.CodeAnalysis','Microsoft.CodeAnalysis.CSharp']:
        ref=ET.SubElement(items,'Reference',Include=name)
        ET.SubElement(ref,'HintPath').text='$(MSBuildBinPath)/Roslyn/bincore/'+name+'.dll'
    file=Path(tmp)/'Contract.csproj';ET.ElementTree(project).write(file,encoding='unicode')
    raise SystemExit(subprocess.run([a.dotnet,'run','--project',str(file),'--',str(a.repository.resolve())]+extra).returncode)
