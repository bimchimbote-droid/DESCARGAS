# Regresión del respaldo general de polígonos

Requiere Python3 y SDK .NET10. Desde la raíz del código (después de instalar los archivos de esta entrega):

```sh
python3 Tests/RecortePoligonos/run.py .
```

En Windows puedes usar `py` en lugar de `python3`. No agregues este proyecto al add-in. No necesita descargar paquetes NuGet. El script extrae del handler los métodos reales de diferencia, conversión, clasificación y validación; usa también la fuente Clipper vendorizada real. Genera GeneratedMotor.cs y GeneratedClipper.cs en la carpeta de las pruebas; son salidas locales, no archivos para instalar en el add-in.

Las pruebas directas cubren contornos cóncavos/oblicuos, huecos, islas, cortes solapados y orden invertido, tangencia, cobertura completa, separaciones de1/2/3mm, traslación/rotación, coordenadas inválidas, contornos abiertos y rechazo de resultados no creables. Verifican además el retorno de puntos al marco inclinado original con origen XYZ no nulo, sin desplazamiento fuera de su plano.

Un oráculo independiente compara la pertenencia de103896 puntos con `perfil original MENOS unión de regiones cortantes`; calcula su propia inclusión por raycast y no utiliza Clipper ni la clasificación de producción para determinar el resultado esperado. Dos pruebas adversariales exigen rechazar un hueco cuya arista atraviesa la mordida de un exterior cóncavo y huecos solapados del mismo componente.

La implementación mantiene el respaldo rectangular anterior cuando es aplicable. El respaldo general se ejecuta únicamente después de obtener todas las huellas y reconstruye desde el componente original, sin reutilizar un sólido parcialmente descontado. Un resultado vacío representa eliminación total. Las coordenadas enteras usan una rejilla de0.00003048mm con origen local; no se amplían cortantes para cerrar separaciones. Los huecos/islas pequeños o aristas que no cumplen las tolerancias se rechazan con diagnóstico en vez de suprimirse. La rejilla introduce una cuantización pequeña; no es una promesa de exactitud matemática ilimitada.

**Alcance:** se verifica el cálculo2D real con una sustitución mínima de XYZ para las operaciones algebraicas del marco. No se ejecuta el kernel3D de Revit ni se prueban Floor.Create, uniones, materiales, transacciones o el modelo de las capturas. La compilación y prueba funcional en Revit/Windows siguen siendo necesarias.
