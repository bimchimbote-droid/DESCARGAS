using System;
using System.Collections.Generic;
using System.Linq;

// Independent point-membership oracle. Does not invoke Clipper for expected
// results and does not use production PointInPolygon/ClassificarComponentes.
public static class MembershipChecks
{
    private static int _points;
    public static int Run(
        Func<ComponenteMuro, List<ComponenteMuro>, List<LoopMuro>> difference,
        Func<double[], LoopMuro> loop)
    {
        _points = 0;
        Func<double[], ComponenteMuro> component = xy => new ComponenteMuro
        {
            Exterior = loop(xy), Huecos = new List<LoopMuro>()
        };
        var square = component(new double[] { 0,0, 20,0, 20,18, 0,18 });
        square.Huecos.Add(loop(new double[] { 7,6, 9,6, 9,8, 7,8 }));
        var ring = component(new double[] { 4,3, 15,3, 15,14, 4,14 });
        ring.Huecos.Add(loop(new double[] { 6,5, 13,5, 13,12, 6,12 }));
        var diagonal = component(new double[] { 0,8, 20,6, 18,13, 1,15 });
        var split = component(new double[] { 10,-2, 12,-2, 12,20, 10,20 });
        var concave = component(new double[] { 0,0, 20,0, 20,5, 8,5, 8,13, 20,13, 20,18, 0,18 });
        Check("ring preserves island and subject hole", square, new List<ComponenteMuro> { ring }, difference);
        Check("overlapping ring and diagonal union", square, new List<ComponenteMuro> { ring, diagonal }, difference);
        Check("overlapping ring and diagonal reversed", square, new List<ComponenteMuro> { diagonal, ring }, difference);
        Check("concave subject and diagonal", concave, new List<ComponenteMuro> { diagonal }, difference);
        Check("concave subject and overlapping cutters", concave, new List<ComponenteMuro> { diagonal, split }, difference);
        Check("split into two retained components", square, new List<ComponenteMuro> { split }, difference);
        var far = component(new double[] { 21,0, 25,0, 25,18, 21,18 });
        Check("nonoverlapping cutter", square, new List<ComponenteMuro> { far }, difference);
        var covered = component(new double[] { -2,-2, 22,-2, 22,20, -2,20 });
        Check("full coverage yields no retained material", square, new List<ComponenteMuro> { covered }, difference);
        Console.WriteLine("Independent sampled membership: " + _points + " points checked.");
        return _points;
    }

    private static void Check(string name, ComponenteMuro original, List<ComponenteMuro> cuts,
        Func<ComponenteMuro, List<ComponenteMuro>, List<LoopMuro>> difference)
    {
        List<LoopMuro> result = difference(original, cuts);
        if (result == null) throw new Exception(name + ": difference returned null.");
        var inputLoops = new List<LoopMuro> { original.Exterior };
        inputLoops.AddRange(original.Huecos ?? new List<LoopMuro>());
        foreach (var cut in cuts)
        {
            inputLoops.Add(cut.Exterior);
            inputLoops.AddRange(cut.Huecos ?? new List<LoopMuro>());
        }
        // Offsets avoid grid alignment with polygon vertices. Boundary samples
        // are excluded from both expected and actual assertions.
        for (int row = 0; row < 111; row++)
        for (int column = 0; column < 117; column++)
        {
            double x = -1.2 + (column + 0.371) * 22.4 / 117.0;
            double y = -1.3 + (row + 0.613) * 20.6 / 111.0;
            if (inputLoops.Concat(result).Any(p => NearBoundary(p, x, y))) continue;
            bool expected = InComponent(original, x, y) && !cuts.Any(cut => InComponent(cut, x, y));
            bool actual = false;
            foreach (var path in result) if (Inside(path, x, y)) actual = !actual;
            if (expected != actual)
                throw new Exception(name + ": membership differs at (" + x + "," + y + "), expected " + expected + ", got " + actual);
            _points++;
        }
        Console.WriteLine("PASS sampled " + name);
    }

    private static bool InComponent(ComponenteMuro component, double x, double y)
    {
        return Inside(component.Exterior, x, y)
            && !(component.Huecos ?? new List<LoopMuro>()).Any(hole => Inside(hole, x, y));
    }

    private static bool Inside(LoopMuro loop, double x, double y)
    {
        bool inside = false;
        var points = loop.Puntos2D;
        int count = points.Count;
        if (count > 1 && points[0].U == points[count - 1].U && points[0].V == points[count - 1].V) count--;
        for (int i = 0, j = count - 1; i < count; j = i++)
        {
            var a = points[i]; var b = points[j];
            if ((a.V > y) != (b.V > y) && x < a.U + (y - a.V) * (b.U - a.U) / (b.V - a.V))
                inside = !inside;
        }
        return inside;
    }

    private static bool NearBoundary(LoopMuro loop, double x, double y)
    {
        var points = loop.Puntos2D;
        for (int i = 0; i < points.Count - 1; i++)
        {
            var a = points[i]; var b = points[i + 1];
            double dx = b.U - a.U, dy = b.V - a.V;
            double lengthSquared = dx * dx + dy * dy;
            if (lengthSquared == 0) continue;
            double t = Math.Max(0, Math.Min(1, ((x - a.U) * dx + (y - a.V) * dy) / lengthSquared));
            double ex = x - (a.U + t * dx), ey = y - (a.V + t * dy);
            if (ex * ex + ey * ey < 1e-12) return true;
        }
        return false;
    }
}
