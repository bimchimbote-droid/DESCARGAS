using System;
using System.Collections.Generic;
using System.Linq;

public static class AdversarialChecks
{
    public static void Run(Func<ComponenteMuro, List<ComponenteMuro>, List<LoopMuro>> difference,
        Func<double[], LoopMuro> loop)
    {
        Func<double[], ComponenteMuro> component = xy => new ComponenteMuro
        {
            Exterior = loop(xy), Huecos = new List<LoopMuro>()
        };
        var subject = component(new double[] { 0,0, 20,0, 20,20, 0,20 });
        var invalidRing = component(new double[] { 2,2, 18,2, 18,6, 8,6, 8,14, 18,14, 18,18, 2,18 });
        invalidRing.Huecos.Add(loop(new double[] { 4,4, 16,4, 4,16 }));
        // Every hole vertex is inside the concave outer, but a diagonal crosses
        // its missing notch. This must be rejected or normalized as outer-hole;
        // negative winding outside the outer must not create phantom cut area.
        bool rejected = false;
        try { difference(subject, new List<ComponenteMuro> { invalidRing }); }
        catch { rejected = true; }
        if (!rejected) throw new Exception("Invalid hole crossing concave boundary was accepted.");
        Console.WriteLine("PASS hole-edge crossing concave exterior is rejected");

        var overlappingHoles = component(new double[] { 2,2, 18,2, 18,18, 2,18 });
        overlappingHoles.Huecos.Add(loop(new double[] { 4,4, 12,4, 12,12, 4,12 }));
        overlappingHoles.Huecos.Add(loop(new double[] { 8,8, 16,8, 16,16, 8,16 }));
        rejected = false;
        try { difference(subject, new List<ComponenteMuro> { overlappingHoles }); }
        catch { rejected = true; }
        if (!rejected) throw new Exception("Overlapping holes in one component were accepted.");
        Console.WriteLine("PASS overlapping holes in one component are rejected");
    }
}
