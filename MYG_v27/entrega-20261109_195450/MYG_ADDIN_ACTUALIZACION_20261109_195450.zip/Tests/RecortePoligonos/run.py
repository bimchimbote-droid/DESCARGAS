#!/usr/bin/env python3
"""Execute the real general polygon fallback with Clipper; does not run Revit."""
import argparse
from pathlib import Path
import re
import subprocess
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('repository',type=Path)
a=p.parse_args();root=Path(__file__).resolve().parent
source=(a.repository/'MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs').read_text(encoding='utf-8-sig')
def block(pattern):
 m=re.search(pattern,source)
 if not m:raise ValueError('Production member missing: '+pattern)
 start=source.index('{',m.start());end=start+1;depth=1
 while depth:
  depth+=(source[end]=='{')-(source[end]=='}');end+=1
 return source[m.start():end]
names=['LoopsSeTocanOCruzan','LoopSeguro','TieneSegmentosCortos','LoopTieneCruces','Dist2D','SegmentosIntersectan2D','Orient2D','PuntoEnSegmento2D','EsToqueDeExtremo','ClasificarComponentes','PuntoInteriorSeguro','PuntoEnPoligono','Similar','Igual','Area','AreaAbs']
methods=[block(r'    private [^\n]+\b'+n+r'\s*\(') for n in names]
start=source.index('    private bool RestarPoligonosEnPlano(');end=source.index('    private void AgregarRestoRectangular(',start)
methods.append(source[start:end])
classes=[block(r'public class '+n+r'\b') for n in ['MarcoMuro','LoopMuro','ComponenteMuro','UV2']]
constants=re.findall(r'    private const double (?:TOL|PTOL)\s*=.*?;',source)
xyz='''public class XYZ { public double X,Y,Z; public XYZ(double x,double y,double z){X=x;Y=y;Z=z;} public XYZ Multiply(double s){return new XYZ(X*s,Y*s,Z*s);} public static XYZ operator +(XYZ a,XYZ b){return new XYZ(a.X+b.X,a.Y+b.Y,a.Z+b.Z);} }'''
(root/'GeneratedMotor.cs').write_text('using System;using System.Linq;using System.Collections.Generic;\n'+xyz+'\n'+'\n'.join(classes)+'\npublic partial class Motor {\n'+'\n'.join(constants+methods)+'\n}\n')
(root/'GeneratedClipper.cs').write_bytes((a.repository/'MYG/Compartido/Geometria/Clipper.cs').read_bytes())
raise SystemExit(subprocess.run(['dotnet','run','--project',str(root/'Regression.csproj')]).returncode)
