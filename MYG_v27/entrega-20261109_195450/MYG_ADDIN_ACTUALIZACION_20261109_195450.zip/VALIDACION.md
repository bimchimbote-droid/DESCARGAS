# Validación de esta entrega

- Respaldo 2D general:38 aserciones directas aprobadas sobre helpers REALES y fuente Clipper REAL; perfiles cóncavos/oblicuos, huecos, islas, solapes/orden, cobertura total, tangencias, gaps1/2/3mm, marcos inclinados, coordenadas inválidas y rechazo de resultados no creables.
- Oráculo independiente de pertenencia:103896 puntos en8escenarios aprobados. El resultado esperado se calcula como perfil original menos unión de cortes mediante raycast independiente.
- Dos negativos adversariales aprobados: rechazar hueco cuya arista cruza la mordida del exterior cóncavo y huecos superpuestos en un componente.
- Identidad de candidatos:17 aserciones de helpers reales con dobles de Element/Solid/Link aprobadas. No ejecuta collectors reales. Limpieza por lote revisada en código; no se atribuye al test.
- Flujo de creación de suelos:24 aserciones aprobadas (20anteriores+4nuevas de metadata). Comprueban respaldo tras fallos, uso de perfil/candidatos originales, no reutilizar sólido parcial, huecos/islas y errores. El motor y creación real de Revit son sustitutos en esta prueba.
- Contrato semántico con metadatos reales de Revit: firma13opcional correcta, llamada real de suelos enlazada sin errores en la invocación y llamadas antiguas11/12compatibles;0fallos. Se excluyen diagnósticos ajenos a la llamada; no es compilación completa.
- Regresiones previas ejecutadas sin cambios:10656 aserciones de geometríaUV,575 del adaptadorplanar y15 de orientación aprobadas. Sus scripts sin cambios no se duplican en este ZIP.
- Roslyn C#7.3:180 fuentes activas (incluye nuevaClipper),9EmbeddedResource y3None, sin errores sintácticos, rutas faltantes ni duplicados. No es compilación completa.
- La fuente Clipper compila con C#7.3 contra referenceassemblies de.NET Framework 4.8. No demuestra la compilación completa del add-in.
- Vendoredsource: al revertir únicamente namespaceaislado se reproduce SHA256upstream7706bc0005fbc3ccb152d21ff9429ff4ed3cb0897df0e1bf0406fc52c91f0bd2. FuenteHTTPS decommitinmutable; provenanceylicencia incluidas.
- git diff --check correcto. Los parches de handlers y Compile fueron aplicados a sus bases y reproducen los archivos finales byte por byte.
- Compilación completa intentada en Linux: bloqueada por MSB4803 ResolveComReference (requiereMSBuild de.NETFramework/Windows). Advertencia preexistente MSB3277 EPPlus.Interfaces reproducida. No se generó DLLnueva.

No se ejecutó Windows, WinFormsnativo ni Revit. Pendiente probar el modelo de las capturas, extracción de huellas reales, uniones, vínculos, proyección, espesor y Floor.Create. No se garantiza que todas las geometrías del kernel puedan recuperarse; los casos no representables mantienen el aviso con diagnóstico.
