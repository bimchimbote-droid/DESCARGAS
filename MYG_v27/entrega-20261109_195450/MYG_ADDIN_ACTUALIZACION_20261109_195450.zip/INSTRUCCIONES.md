# Actualización: recorte 2D general e identificación de interferencias

## A. Resumen y versión de trabajo
Se amplía el respaldo del error de las capturas: tras obtener todas las huellas, si falla su resta 3D y no aplica el respaldo rectangular previo, se calcula en 2D el perfil original menos la unión de TODAS las huellas. Se conservan contornos cóncavos/oblicuos, huecos e islas; un resultado vacío representa ocupación completa. No se usa el sólido parcialmente recortado ni se ignora el candidato24. Los resultados no creables o topologías inválidas siguen mostrando diagnóstico.
El aviso de suelos conserva ahora ID del elemento de origen de extracción, categoría e ID de instancia vinculada si corresponde, tanto en el intento principal como en el respaldo. El ordinal del candidato sigue siendo un índice de sólidos, no un ElementId. Geometría anidada se identifica por su origen de extracción, no se afirma conocer cada subelemento interno.
Base: bimchimbote-droid/MYG_v27_reestructurado/master, commit fuente56682a0299f9cb62dacecce6ef269a13c864c4b3, más las entregas acumuladas. Muro base MYG_ADDIN_ACTUALIZACION_20261109_192530.zip, DESCARGAS commit5f5bfc3ff8d31ca532e568d2aebfa7855737c47f; suelo base190311, commit83915c8d0db803d26815342ff7a2d02a4eb1c468. Se mantienen la búsqueda y la orientación exterior corregidas anteriormente. No se sustituyó el código por MYG_v27/main.

## B. Archivos afectados
| Acción | Ruta | Intervención |
|---|---|---|
| REEMPLAZAR | MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_MurosHandler.cs | Respaldo general2D y metadatos del candidato. |
| REEMPLAZAR | MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs | Conserva identidad de sólidos y la pasa al respaldo. |
| CREAR | MYG/Compartido/Geometria/Clipper.cs | Motor de clipping6.4.2, C# compatible, namespace aislado. |
| CREAR | MYG/Compartido/Geometria/CLIPPER_LICENSE.txt | Licencia Boost1.0 obligatoria de distribución. |
| CREAR | MYG/Compartido/Geometria/CLIPPER_ORIGEN.md | Origen, commit y checksum de la dependencia fuente. |
| MODIFICAR | MYG/MYG.csproj | Solo agregar Compile de Clipper.cs mediante PARCHES/PROYECTO_CLIPPER.patch o Agregar elemento existente. No se entrega el proyecto completo. |

Pruebas nuevas/modificadas y documentos: consultar rutas exactas y acciones en RELACION_ARCHIVOS.json. Tests/ContratoRecortePlanar actualiza Program.cs y README; run.py nuevo crea el proyecto temporal y no requiere copiar el Contract.csproj sin cambios de la entrega anterior. Las pruebas son opcionales, fuera del add-in.
TarrajeoForm.cs, recursos, paquetes, lockfiles y demás fuentes SIN CAMBIOS, fuera del ZIP. No hay eliminaciones.

## C. Descarga y contenido
Este ZIP contiene solo dos fuentes existentes modificadas, la fuente nueva de clipping con licencia/origen, pruebas nuevas/modificadas y documentación/parches. No incluye el repositorio completo, DLLs, bin/obj, paquetes restaurables, credenciales ni modelos. El manifiesto registra SHA256 de los archivos (sin hash propio para evitar autorreferencia).

## D. Instalación: pasos necesarios
1. Cierra Revit y respalda la solución, los dos handlers, proyecto y DLL actuales. Reemplazar archivos completos puede sobrescribir cambios locales/posteriores; compáralos antes.
2. REEMPLAZA JUNTOS los DOS handlers de MYG/Funcionalidades/Estructuras/Tarrajeo/. Conserva el formulario actual. Ambos handlers deben corresponder a esta entrega. Ya están incluidos en el proyecto.
3. COPIA la carpeta nueva MYG/Compartido/Geometria/ con Clipper.cs, licencia y origen en esas rutas.
4. AGREGA Clipper.cs a la compilación. En Visual Studio: clic derecho sobre proyecto MYG → Agregar → Elemento existente → seleccionar SOLO MYG/Compartido/Geometria/Clipper.cs. Alternativa desde la raíz del código: git apply --check RUTA/PARCHES/PROYECTO_CLIPPER.patch y después git apply RUTA/PARCHES/PROYECTO_CLIPPER.patch. Usa UNA vía, no ambas. Comprueba que exista una única entrada Compile Include="Compartido\Geometria\Clipper.cs". No reemplaces todo tu .csproj ni cambies referencias/paquetes.
5. Alternativa al reemplazo completo del paso2: aplicar PARCHES/HANDLERS.patch con git apply --check y git apply. Está probado contra los handlers base192530/190311; no aplicar además de reemplazarlos. Si no coincide, combinar sin forzar. Este parche NO agrega el Compile del paso4: ese paso sigue siendo necesario.
6. En Visual Studio: Limpiar solución y Recompilar solución. Con Revit cerrado instala la DLL compilada en una instalación de prueba; conserva manifiesto.addin, iconos y dependencias actuales. No se entrega DLL nueva.
7. Prueba la superficie de las capturas y compara huecos/islas y contacto del revestimiento. Si una geometría no resulta creable, el aviso debe indicar la etapa e IDs; el log se guarda en la ruta que muestra el diálogo.
No agregues las carpetas Pruebas/ o Tests/ al proyecto MYG ni copies sus salidas a Revit.

## E. Configuración
Sin nuevos paquetes NuGet ni actualizaciones de los existentes. Se incorpora Clipper 6.4.2 como fuente con licencia Boost1.0; origen/commit/hash están documentados. Mantener .NET Framework4.8, referencias Revit/Office y configuración actuales. Solo agregar el Compile indicado. SDK .NET 10 y Python3 se usan para las pruebas separadas; no migran el add-in.

## F. Pruebas
Resultados reales en VALIDACION.md. Tras copiar los archivos, desde la raíz del código:

```sh
python3 Tests/RecortePoligonos/run.py .
python3 Pruebas/probar_origenes_suelos_tarrajeo.py MYG/Funcionalidades/Estructuras/Tarrajeo/Tarrajeo_SuelosHandler.cs
python3 Pruebas/probar_respaldo_suelos_tarrajeo.py
python3 Tests/ContratoRecortePlanar/run.py .
```

En Windows puede usarse py en vez de python3; dotnet debe estar en PATH. La prueba de contrato requiere RevitAPI.dll y RevitAPIUI.dll; permite --api-dir "C:\Program Files\Autodesk\Revit 2027" si corresponde. Los proyectos de pruebas no pertenecen a la solución MYG.

## G. GitHub
Autorización vigente: publicar solo el ZIP en una ruta nueva de bimchimbote-droid/DESCARGAS, conservando entregas anteriores. No se hace commit ni push al repositorio del código. Publicar/descargar el ZIP no cambia tu PC ni actualiza MYG_v27/MYG_v27_reestructurado. Después de instalar, revisa Cambios de Git en Visual Studio, compila y prueba; luego crea Commit y usa Push cuando decidas guardar tu código.

## H. Limitaciones
No se ha reproducido el RVT de las capturas. Las pruebas2D no ejecutan el kernel de Revit ni certifican Floor.Create, uniones, vínculos reales o espesor físico final. La resta sigue requiriendo que puedan obtenerse todas las huellas. La rejilla de conversión introduce una cuantización pequeña (0.00003048mm); no garantiza precisión matemática ilimitada. Se conservan tolerancias y espesor del revestimiento; aristas/huecos/islas no representables se rechazan con diagnóstico en vez de suprimirse en el respaldo general. El recorrido rectangular anterior se conserva.
Compilación completa pendiente en Windows/MSBuild Framework/COM; las advertencias existentes de versiones no se corrigen mediante actualizaciones ajenas a este cambio. No se modifican automáticamente revestimientos ya creados.
