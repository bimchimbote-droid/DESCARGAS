#!/usr/bin/env python3
"""Exercise actual floor-candidate metadata helpers with API doubles, not Revit."""
from pathlib import Path
import argparse
import atexit
import json
import re
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('source', type=Path, help='Tarrajeo_SuelosHandler.cs to validate')
parser.add_argument('--dotnet', default=shutil.which('dotnet'), help='Path to a complete .NET SDK executable')
args = parser.parse_args()
if not args.dotnet:
    parser.error('Install a .NET SDK or use --dotnet')
exe = Path(args.dotnet).resolve()
compiler = sorted(exe.parent.glob('sdk/*/Roslyn/bincore/csc.dll'))[-1]
reference = sorted(exe.parent.glob('packs/Microsoft.NETCore.App.Ref/*/ref/net*'))[-1]
runtime = sorted(exe.parent.glob('shared/Microsoft.NETCore.App/*'))[-1]
source = args.source.read_text(encoding='utf-8-sig')


def method(name):
    match = re.search(r'    private [^\n]+\b' + name + r'\s*\(', source)
    if match is None:
        raise ValueError('Production helper missing: ' + name)
    begin = source.index('{', match.start())
    end, depth = begin + 1, 1
    while depth:
        depth += (source[end] == '{') - (source[end] == '}')
        end += 1
    return source[match.start():end]


helpers = '\n'.join(method(n) for n in ['AgregarSolidoCandidato', 'DescribirOrigenCandidato', 'DescribirSolidoCandidato'])
code = r'''
using System;
using System.Collections.Generic;
class ElementId {
    readonly long value;
    public ElementId(long id) { value=id; }
    public override string ToString() { return value.ToString(); }
}
class Category { public string Name; }
class Element {
    public ElementId RawId;
    public Category RawCategory;
    public bool FailId, FailCategory;
    public ElementId Id { get { if(FailId) throw new Exception("invalid object");return RawId; } }
    public Category Category { get { if(FailCategory) throw new Exception("invalid category");return RawCategory; } }
}
class RevitLinkInstance : Element { }
class Solid { public double Volume; }
class Harness {
    private readonly Dictionary<Solid,string> _origenesSolidosCandidatos = new Dictionary<Solid,string>();
__HELPERS__
    static int checks;
    static void Check(bool value,string name) { if(!value) throw new Exception(name);checks++; }
    static bool Has(string text,string part) { return text.IndexOf(part,StringComparison.Ordinal)>=0; }
    void Run() {
        var list = new List<Solid>();
        var native = new Element {RawId=new ElementId(123),RawCategory=new Category{Name="Walls"}};
        var first = new Solid {Volume=1};
        AgregarSolidoCandidato(list,first,native,null);
        Check(list.Count==1 && object.ReferenceEquals(list[0],first),"native solid retained by instance");
        Check(Has(_origenesSolidosCandidatos[first],"nativo ID 123"),"native ElementId retained");
        Check(Has(_origenesSolidosCandidatos[first],"Walls"),"native category retained");
        Check(Has(_origenesSolidosCandidatos[first],"Origen de extracción"),"description states provenance scope");
        string diagnostic=DescribirSolidoCandidato(first,24);
        Check(Has(diagnostic,"nº 24") && Has(diagnostic,"ID 123"),"ordinal and ElementId both present and distinct");
        var link = new RevitLinkInstance {RawId=new ElementId(4000000001)};
        var linked = new Element {RawId=new ElementId(567),RawCategory=new Category{Name="Structural Framing"}};
        var second = new Solid {Volume=2};
        AgregarSolidoCandidato(list,second,linked,link);
        Check(list.Count==2,"linked solid retained");
        Check(Has(_origenesSolidosCandidatos[second],"vínculo ID 4000000001"),"64-bit link ID retained");
        Check(Has(_origenesSolidosCandidatos[second],"elemento vinculado ID 567"),"linked ElementId retained");
        Check(Has(_origenesSolidosCandidatos[second],"Structural Framing"),"linked category retained");
        var third=new Solid {Volume=3};
        AgregarSolidoCandidato(list,third,linked,new RevitLinkInstance {RawId=new ElementId(4000000002)});
        Check(Has(_origenesSolidosCandidatos[third],"vínculo ID 4000000002") && Has(_origenesSolidosCandidatos[second],"vínculo ID 4000000001"),"same linked element in separate occurrences retains each link identity");
        var fourth=new Solid {Volume=1};
        AgregarSolidoCandidato(list,fourth,native,null);
        Check(_origenesSolidosCandidatos.ContainsKey(first)&&_origenesSolidosCandidatos.ContainsKey(fourth),"multiple solids from one owner remain independently mapped");
        int before=list.Count;
        AgregarSolidoCandidato(list,null,native,null);
        AgregarSolidoCandidato(list,new Solid {Volume=0},native,null);
        AgregarSolidoCandidato(list,new Solid {Volume=-1},native,null);
        AgregarSolidoCandidato(list,new Solid {Volume=double.NaN},native,null);
        Check(list.Count==before,"preserves previous positive-volume selection criterion");
        var broken=new Element {FailId=true,FailCategory=true};
        var brokenSolid=new Solid {Volume=1};
        AgregarSolidoCandidato(list,brokenSolid,broken,new RevitLinkInstance {FailId=true});
        Check(list.Contains(brokenSolid)&&_origenesSolidosCandidatos.ContainsKey(brokenSolid),"failed diagnostic properties do not drop an interference");
        Check(Has(_origenesSolidosCandidatos[brokenSolid],"no disponible"),"missing metadata is explicit");
        var unknown=new Solid {Volume=1};
        Check(Has(DescribirSolidoCandidato(unknown,9),"Origen de extracción no disponible"),"unknown solid reports missing provenance");
        Check(Has(DescribirSolidoCandidato(null,7),"nº 7"),"null diagnostic remains safe");
        Check(!Has(diagnostic,"C:\\")&&!Has(diagnostic,".rvt"),"diagnostic helpers output no document path or model name");
        Console.WriteLine("Candidate metadata: "+checks+" assertions passed (API doubles; Revit not executed)");
    }
    static int Main() { try { new Harness().Run();return 0; } catch(Exception ex) { Console.Error.WriteLine(ex);return 1; } }
}
'''.replace('__HELPERS__',helpers)
work = Path(tempfile.mkdtemp(prefix='myg-metadata-'))
atexit.register(shutil.rmtree,work)
(work/'Program.cs').write_text(code)
(work/'compile.rsp').write_text('\n'.join(['-nologo','-langversion:7.3','-nostdlib+','-target:exe','-out:'+str(work/'Metadata.dll')]+['-r:'+str(p) for p in reference.glob('*.dll')]+[str(work/'Program.cs')]))
(work/'Metadata.runtimeconfig.json').write_text(json.dumps({'runtimeOptions':{'framework':{'name':'Microsoft.NETCore.App','version':runtime.name}}}))
subprocess.run([str(exe),str(compiler),'@'+str(work/'compile.rsp')],check=True)
subprocess.run([str(exe),str(work/'Metadata.dll')],check=True)
